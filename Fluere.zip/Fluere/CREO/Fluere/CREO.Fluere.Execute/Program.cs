﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Common.Executive
{
    /// <summary>
    /// メインプログラムクラスです。
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// 指定されたモジュール名が要求を満たしている事を確認します。
        /// </summary>
        /// <param name="moduleName">モジュール名</param>
        /// <exception cref="InvalidOperationException">要求を満たしていない場合</exception>
        internal static void DemandModuleName(string moduleName)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(moduleName) == false, "moduleName == null");

            if (string.Compare(moduleName, "CREO.Fluere.Execute.exe", StringComparison.InvariantCultureIgnoreCase) == 0)
            {
                throw new InvalidOperationException("Require rename module name.");
            }
        }

        /// <summary>
        /// コマンドライン引数が指定されている事を確認します。
        /// </summary>
        /// <param name="args">コマンドライン引数群</param>
        /// <param name="moduleName">モジュール名</param>
        /// <param name="descriptions">引数群を説明する文字列群</param>
        /// <exception cref="ArgumentException">要求を満たしていない場合</exception>
        internal static void DemandCommandLineArguments(string[] args, string moduleName, string[] descriptions)
        {
            Debug.Assert(args != null, "args == null");
            Debug.Assert(string.IsNullOrWhiteSpace(moduleName) == false, "moduleName == null");
            Debug.Assert(descriptions != null, "descriptions == null");

            if (args.Length != descriptions.Length)
            {
                throw new ArgumentException(
                    string.Format(
                        "usage: {0} {1}",
                        moduleName,
                        string.Join(
                            " ",
                            (from description in descriptions
                             select string.Format("<{0}>", description)))));
            }
        }

        /// <summary>
        /// メイン処理のエントリポイントです。
        /// </summary>
        /// <param name="args">コマンドライン引数群</param>
        /// <returns>戻り値</returns>
        public static int Main(string[] args)
        {
            int result = 1;
            using (var initializingLogStream = new MemoryStream())
            {
                bool argFlg = false;
                var tw = new StreamWriter(initializingLogStream, Encoding.UTF8);
                try
                {
                    // プロセスの情報を取得する
                    using (var runnerHost = new FluereRunnerProcessHost(
                        Assembly.GetExecutingAssembly(),
                        tw,
                        tw))
                    {
                        try
                        {
                            // CREO.Fluere.Execute.exeからリネームされている事
                            DemandModuleName(runnerHost.ModuleName);

                            // プロセスの初期化を行う
                            runnerHost.Initialize();

                            // FluereRunnerを生成する
                            using (var runner = new FluereRunner(runnerHost.ModuleName))
                            {
                                // 引数名称群を取得する
                                var descriptions = runner.GetArgumentDescriptions();

                                // コマンドライン引数が指定されている事
                                DemandCommandLineArguments(args, runnerHost.ModuleName, descriptions);
                                argFlg = true;

                                // 開始の表示
                                string msgId = UF_Fluere_MsgId.MSGID_UF00000023;
                                LogUtility.Write(msgId, new string[] { runner.Name });

                                // コマンドラインを取得する
                                var systemDefinitionPath = Path.GetFullPath(args[0]);
                                var configurationPath = Path.GetFullPath(args[1]);

                                // 処理を開始する
                                result = runner.Run(runnerHost, systemDefinitionPath, configurationPath);

                                // 終了の表示
                                if (result == 0)
                                {
                                    msgId = UF_Fluere_MsgId.MSGID_UF00000024;
                                    LogUtility.Write(msgId, new string[] { runner.Name, result.ToString() });
                                }
                                else
                                {
                                    msgId = UF_Fluere_MsgId.MSGID_UF00000027;
                                    LogUtility.Write(msgId, new string[] { runner.Name, result.ToString() });
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            Trace.WriteLine(ex.ToString());
                            Console.WriteLine(ex.ToString()+"\r\n");
                            if (argFlg == true)
                            {
                                Console.WriteLine(string.Format("HandleException:{0}",runnerHost.HandleException(ex)));
                            }
                        }
                    }
                }
                finally
                {
                    tw.Flush();
                    if (initializingLogStream.Length >= 4)  // BOM
                    {
                        initializingLogStream.Position = 0;

                        var path = Assembly.GetExecutingAssembly().Location + ".fatal.log";
                        using (var fs = new FileStream(path, FileMode.Create, FileAccess.ReadWrite, FileShare.None))
                        {
                            initializingLogStream.CopyTo(fs);
                            fs.Close();
                        }
                    }
                    if (result != 0)
                    {
                        result = 1;
                    }
                }
            }
            return result;
        }
    }
}

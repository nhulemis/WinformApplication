﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// アセンブリに関する一般情報は以下の属性セットをとおして制御されます。
// アセンブリに関連付けられている情報を変更するには、
// これらの属性値を変更してください。
[assembly: AssemblyTitle("CREO.Fluere.Execute")]
[assembly: AssemblyDescription("CREO Fluere execution module")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("TOYOTA MAPMASTER INC.")]
[assembly: AssemblyProduct("CREO.Fluere.Execute")]
[assembly: AssemblyCopyright("© TOYOTA MAPMASTER Inc. All Rights Reserved.")]
[assembly: AssemblyTrademark("CREO")]
[assembly: AssemblyCulture("")]
// ComVisible を false に設定すると、その型はこのアセンブリ内で COM コンポーネントから 
// 参照不可能になります。COM からこのアセンブリ内の型にアクセスする場合は、
// その型の ComVisible 属性を true に設定してください。
[assembly: ComVisible(false)]

// 次の GUID は、このプロジェクトが COM に公開される場合の、typelib の ID です
[assembly: Guid("f7e9dc2a-632a-4241-b809-b8b36d38aba2")]

[assembly: AssemblyVersion("1.0.16132.0000")]
[assembly: AssemblyFileVersion("1.0.16132.0000")]

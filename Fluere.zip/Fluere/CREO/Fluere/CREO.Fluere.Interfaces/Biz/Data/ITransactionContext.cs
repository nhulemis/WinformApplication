﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

namespace CREO.Fluere.Biz.Data
{
    /// <summary>
    /// トランザクションを管理する基底インターフェイスです。
    /// </summary>
    public interface ITransactionContext : ITransactionControl
    {
        /// <summary>
        /// トランザクションに割り当てられたIDを取得します。
        /// </summary>
        Guid TransactionID
        {
            get;
        }
    }
}

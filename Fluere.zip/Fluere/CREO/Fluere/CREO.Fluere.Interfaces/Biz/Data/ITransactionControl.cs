﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

namespace CREO.Fluere.Biz.Data
{
    /// <summary>
    /// トランザクション処理を抽象化するインターフェイスです。
    /// </summary>
    /// <remarks>Disposeメソッドの呼び出しは、ロールバックに相当します。</remarks>
    public interface ITransactionControl : IDisposable
    {
        /// <summary>
        /// トランザクションをコミットします。
        /// </summary>
        void Commit();
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.19 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// プロパティにノード名を指定する基底属性クラスです。
    /// </summary>
    public class NodeNameAttributeBase : Attribute
    {
        /// <summary>
        /// ノード名を格納するフィールドです。
        /// </summary>
        private readonly string _nodeName;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="nodeName">ノード名</param>
        /// <remarks>このノードをエレメントとしてマークします。</remarks>
        protected internal NodeNameAttributeBase(string nodeName)
        {
            this._nodeName = nodeName;
        }

        /// <summary>
        /// ノード名を取得します。
        /// </summary>
        public string NodeName
        {
            get
            {
                return this._nodeName;
            }
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// コレクション内のネストした要素のエレメント名群を指定する属性クラスです。
    /// </summary>
    /// <remarks>エレメント名群はネストした要素に対応します。
    /// 例えば、IList&lt;IList&lt;IList&lt;int&gt;&gt;&gt;の場合、外側から順に3個のエレメント名が必要です。"</remarks>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class ItemElementNamesAttribute : Attribute
    {
        /// <summary>
        /// エレメント名群を格納するフィールドです。
        /// </summary>
        private readonly string[] _elementNames;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="elementNames">ネストされたエレメント名群</param>
        public ItemElementNamesAttribute(params string[] elementNames)
        {
            Assertion.Argument(elementNames.Length >= 1, "一つ以上のエレメント名群が必要です");

            this._elementNames = elementNames;
        }

        /// <summary>
        /// エレメント名群を取得します。
        /// </summary>
        public string[] ElementNames
        {
            get
            {
                return this._elementNames;
            }
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Diagnostics;
using System.Runtime.Serialization;
using System.Security;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// 必須のノードが存在しない場合の例外クラスです。
    /// </summary>
    [Serializable]
    public sealed class MissingNodeException : ConfigurationSerializerException
    {
        /// <summary>
        /// 対象のノード名です。
        /// </summary>
        private readonly string _nodeName;

        /// <summary>
        /// 対象の詳細文字列です。
        /// </summary>
        private readonly string _description;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="type">対象のプロパティが定義されている型</param>
        /// <param name="name">プロパティ名</param>
        /// <param name="nodeName">対象のノード名</param>
        public MissingNodeException(Type type, string name, string nodeName)
            : base("プロパティ {0}.{1} は必須ですが、ノード {2} がありません", type, name, nodeName)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(nodeName) == false, "ノード名が必要です");

            this._nodeName = nodeName;
            this._description = nodeName;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="type">対象のプロパティが定義されている型</param>
        /// <param name="name">プロパティ名</param>
        /// <param name="nodeName">対象のノード名</param>
        /// <param name="description">対象の詳細文字列</param>
        public MissingNodeException(Type type, string name, string nodeName, string description)
            : base("プロパティ {0}.{1} は必須ですが、ノード {2} がありません", type, name, nodeName)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(nodeName) == false, "ノード名が必要です");
            Debug.Assert(string.IsNullOrWhiteSpace(description) == false, "詳細文字列が必要です");

            this._nodeName = nodeName;
            this._description = description;
        }

        /// <summary>
        /// 逆シリアル化コンストラクタです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecuritySafeCritical]
        private MissingNodeException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            this._nodeName = info.GetString("nodeName");
            this._description = info.GetString("description");
        }

        /// <summary>
        /// 対象となるノード名を取得します。
        /// </summary>
        public string NodeName
        {
            get
            {
                return this._nodeName;
            }
        }

        /// <summary>
        /// 対象となる詳細文字列を取得します。
        /// </summary>
        public string Description
        {
            get
            {
                return this._description;
            }
        }

        /// <summary>
        /// シリアル化メソッドです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecuritySafeCritical]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);

            info.AddValue("nodeName", this._nodeName);
            info.AddValue("description", this._description);
        }
    }
}

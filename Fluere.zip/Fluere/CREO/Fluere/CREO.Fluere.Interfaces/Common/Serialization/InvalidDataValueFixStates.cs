﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.07.03 TMI K.Matsui

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// データの修正の状態を示す列挙値です。
    /// </summary>
    public enum InvalidDataValueFixStates
    {
        /// <summary>
        /// 修正は行われていません。
        /// </summary>
        NotFixed = 0,

        /// <summary>
        /// 修正済みです。
        /// </summary>
        Fixed = 1,

        /// <summary>
        /// このレコードを無視するように指定されました。
        /// </summary>
        Ignored = 2
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.10.01 TMI I.Yoshimi

using System;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// このノードはnullを許可する事を示す属性クラスです。
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class NodeNullableAttribute : Attribute
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public NodeNullableAttribute()
        {
        }
    }
}

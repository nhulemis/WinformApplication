﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.IO;
using System.Xml;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// XML形式の設定データをインターフェイスとの間でシリアル化するジェネリッククラスです。
    /// </summary>
    /// <typeparam name="T">対象のインターフェイス</typeparam>
    /// <remarks>宣言式のインターフェイス構文を使用して、XMLデータの入出力を実行します。
    /// データ対象はネストを含むインターフェイスで定義され、
    /// タイプコンバータを使用した変換とIListを使用したコレクションへの変換を行います。
    /// また、属性クラスを使用して、エレメント名とXML属性の適用方法を調整する事が出来ます。</remarks>
    public interface IConfigurationSerializer<T> : IConfigurationSerializer
        where T : class
    {
        /// <summary>
        /// 指定されたインスタンスをXmlDocuemntにシリアル化します。
        /// </summary>
        /// <param name="document">出力するXmlDocuemnt</param>
        /// <param name="target">対象のインスタンス</param>
        void Serialize(XmlDocument document, T target);

        /// <summary>
        /// 指定されたインスタンスをストリームにシリアル化します。
        /// </summary>
        /// <param name="stream">出力するストリーム</param>
        /// <param name="target">対象のインスタンス</param>
        void Serialize(Stream stream, T target);

        /// <summary>
        /// 指定されたXmlDocumentからインスタンスを復元します。
        /// </summary>
        /// <param name="document">入力するXmlDocument</param>
        /// <returns>インスタンス</returns>
        new T Deserialize(XmlDocument document);

        /// <summary>
        /// 指定されたストリームからインスタンスを復元します。
        /// </summary>
        /// <param name="stream">入力するストリーム</param>
        /// <returns>インスタンス</returns>
        new T Deserialize(Stream stream);
    }
}

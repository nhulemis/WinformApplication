﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// 不正な値のフィールドを検出した場合に呼び出しを行うデリゲートです。
    /// </summary>
    /// <param name="sender">レコードを処理しているデータソースリーダ</param>
    /// <param name="e">情報を含むクラス</param>
    public delegate void InvalidDataValueEventHandler(object sender, InvalidDataValueEventArgs e);
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.IO;
using System.Xml;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// XML形式の設定データをインターフェイスとの間でシリアル化するインターフェイスです。
    /// </summary>
    /// <remarks>宣言式のインターフェイス構文を使用して、XMLデータの入出力を実行します。
    /// データ対象はネストを含むインターフェイスで定義され、
    /// タイプコンバータを使用した変換とIListを使用したコレクションへの変換を行います。
    /// また、属性クラスを使用して、エレメント名とXML属性の適用方法を調整する事が出来ます。</remarks>
    public interface IConfigurationSerializer : ISerializerBase
    {
        /// <summary>
        /// 不正な値を検出した場合に呼び出されるイベントです。
        /// </summary>
        /// <remarks>データから値を取得する際に、型変換しようとして発生する例外を検出出来ます。
        /// このイベントの処理内で、値を修正するか、別の例外をスローして下さい。
        /// 値を修正せず、かつ例外をスローしないで処理を返した場合、提示されている例外が再スローされます。</remarks>
        event InvalidDataValueEventHandler InvalidDataValue;

        /// <summary>
        /// 指定されたインスタンスをXmlDocuemntにシリアル化します。
        /// </summary>
        /// <param name="document">出力するXmlDocuemnt</param>
        /// <param name="target">対象のインスタンス</param>
        void Serialize(XmlDocument document, object target);

        /// <summary>
        /// 指定されたインスタンスをストリームにシリアル化します。
        /// </summary>
        /// <param name="stream">出力するストリーム</param>
        /// <param name="target">対象のインスタンス</param>
        void Serialize(Stream stream, object target);

        /// <summary>
        /// 指定されたXmlDocumentからインスタンスを復元します。
        /// </summary>
        /// <param name="document">入力するXmlDocument</param>
        /// <returns>インスタンス</returns>
        object Deserialize(XmlDocument document);

        /// <summary>
        /// 指定されたストリームからインスタンスを復元します。
        /// </summary>
        /// <param name="stream">入力するストリーム</param>
        /// <returns>インスタンス</returns>
        object Deserialize(Stream stream);
    }
}

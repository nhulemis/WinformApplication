﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.19 TMI K.Matsui

using System;
using System.Globalization;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// シリアル化を実行する実装に共通の基底インターフェイスです。
    /// </summary>
    public interface ISerializerBase
    {
        /// <summary>
        /// このシリアライザが変換の対象とするインターフェイス型を取得します。
        /// </summary>
        Type TargetType
        {
            get;
        }

        /// <summary>
        /// シリアル化を実行する際に使用するカルチャ情報を取得・設定します。
        /// </summary>
        CultureInfo CultureInfo
        {
            get;
            set;
        }

        /// <summary>
        /// カスタムコンバートに必要な変換インターフェイスを登録します。
        /// </summary>
        /// <typeparam name="T">カスタムコンバートの対象となる属性クラス</typeparam>
        /// <param name="converter">変換インターフェイスのインスタンス</param>
        /// <remarks>CustomConvertAttribute自身が変換を実行しない場合は、
        /// あらかじめこのメソッドを使用して変換インターフェイスを登録する必要があります。</remarks>
        void RegisterCustomConvert<T>(ICustomConvert converter)
            where T : CustomConvertAttribute;
    }
}

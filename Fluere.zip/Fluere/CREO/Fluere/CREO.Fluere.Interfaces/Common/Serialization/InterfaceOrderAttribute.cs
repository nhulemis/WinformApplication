﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// シリアル化を行うインターフェイスの解釈順序を指定する属性クラスです。
    /// </summary>
    /// <remarks>この属性を適用する事で、シリアル化・逆シリアル化時の継承されたインターフェイスの関係性を強制する事が出来ます。
    /// この属性指定が無い場合は、基点となるインターフェイス→継承したインターフェイスの順でメンバの配置が決定されます。</remarks>
    [AttributeUsage(AttributeTargets.Interface, AllowMultiple = false)]
    public sealed class InterfaceOrderAttribute : Attribute
    {
        /// <summary>
        /// エレメント名を格納するフィールドです。
        /// </summary>
        private readonly Type[] _interfaceTypes;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="interfaceTypes">インターフェイス型の並び</param>
        /// <remarks>メンバの配置順に従って、自分自身と、継承したインターフェイス群を全て指定して下さい。</remarks>
        public InterfaceOrderAttribute(params Type[] interfaceTypes)
        {
            Assertion.Argument(interfaceTypes.Length >= 1, "インターフェイス型が必要です");

            ISet<Type> hashSet = new HashSet<Type>();
            for (int i = 0; i < interfaceTypes.Length; i++)
            {
                Assertion.Argument(interfaceTypes[i].IsInterface == true,
                    "インターフェイス型が必要です");
                Assertion.Argument(hashSet.Contains(interfaceTypes[i]) == false,
                    "重複したインターフェイス型を指定しています: {0}",
                    interfaceTypes[i].FullName);

                hashSet.Add(interfaceTypes[i]);
            }

            this._interfaceTypes = interfaceTypes;
        }

        /// <summary>
        /// インターフェイス型の並びを取得します。
        /// </summary>
        public Type[] InterfaceTypes
        {
            get
            {
                return this._interfaceTypes;
            }
        }
    }
}

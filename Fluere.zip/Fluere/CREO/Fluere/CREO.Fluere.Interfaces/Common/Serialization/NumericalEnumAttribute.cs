﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.07.11 TMI K.Matsui

using System;
using System.Globalization;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// 列挙型を数値として入出力を行う属性クラスです。
    /// </summary>
    /// <remarks>この属性を適用したプロパティは、列挙型を数値として自動的に相互変換を行います。</remarks>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class NumericalEnumAttribute : CustomConvertAttribute, ICustomConvert
    {
        /// <summary>
        /// インデクサを除外するための空の引数群です。
        /// </summary>
        private static readonly object[] EmptyIndex = new object[0];

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public NumericalEnumAttribute()
        {
        }

        /// <summary>
        /// シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        public object SerializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo)
        {
            Assertion.NullArgument(pi, "プロパティ情報が必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");

            try
            {
                if (value == null)
                {
                    return null;
                }

                object rawValue = value;

                // 値の型
                Type type = rawValue.GetType();

                // 値がNullableの場合の内包型
                Type nullableUnderlyingType = Nullable.GetUnderlyingType(type);
                if (nullableUnderlyingType != null)
                {
                    // Nullableから値を取得
                    rawValue = typeof(Nullable<>).MakeGenericType(nullableUnderlyingType).GetProperty("Value").GetValue(rawValue, EmptyIndex);

                    // 値の型をNullableの内包型（列挙型）に修正
                    type = nullableUnderlyingType;
                }

                // 列挙型の基底型（Int32など）
                Type underlyingType = Enum.GetUnderlyingType(type);

                // 列挙型の基底型に変換
                return ((IConvertible)rawValue).ToType(underlyingType, cultureInfo);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 逆シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        public object DeserializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo)
        {
            Assertion.NullArgument(pi, "プロパティ情報が必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");

            try
            {
                if (value == null)
                {
                    return null;
                }

                object rawValue = value;

                // プロパティの型
                Type type = pi.PropertyType;

                // プロパティがNullableの場合の内包型
                Type nullableUnderlyingType = Nullable.GetUnderlyingType(type);

                // 列挙型の基底型（Int32など）
                Type underlyingType = (nullableUnderlyingType != null) ?
                    Enum.GetUnderlyingType(nullableUnderlyingType) : Enum.GetUnderlyingType(type);

                // 列挙型の基底型に変換
                rawValue = ((IConvertible)rawValue).ToType(underlyingType, cultureInfo);

                // Nullableの場合
                if (nullableUnderlyingType != null)
                {
                    // Nullableの内包型（列挙型）に変換
                    rawValue = Enum.ToObject(nullableUnderlyingType, rawValue);

                    // Nullable<T>に変換
                    rawValue = Activator.CreateInstance(
                        typeof(Nullable<>).MakeGenericType(nullableUnderlyingType), rawValue);
                }
                else
                {
                    // Nullableではない

                    // 直接列挙型に変換
                    rawValue = Enum.ToObject(type, rawValue);
                }

                return rawValue;
            }
            catch
            {
                return null;
            }
        }
    }
}

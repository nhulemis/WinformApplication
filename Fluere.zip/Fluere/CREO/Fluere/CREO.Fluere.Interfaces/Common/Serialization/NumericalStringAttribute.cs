﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.18 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// 任意の数値を文字列として入出力する属性クラスです。
    /// </summary>
    /// <remarks>この属性を適用したプロパティは、指定されたフォーマット文字列で相互変換を行います。</remarks>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class NumericalStringAttribute : CustomConvertAttribute, ICustomConvert
    {
        #region Fields
        /// <summary>
        /// 逆シリアル化で使用する変換辞書です。
        /// </summary>
        private static readonly Dictionary<Type, MethodInfo> CONVERTERS;

        /// <summary>
        /// シリアル化時に適用するフォーマット文字列です。
        /// </summary>
        private readonly string _serializeFormat;

        /// <summary>
        /// 逆シリアル化時に適用するスタイルです。
        /// </summary>
        private readonly NumberStyles _numberStyles;
        #endregion

        #region Type initializer
        /// <summary>
        /// タイプイニシャライザです。
        /// </summary>
        static NumericalStringAttribute()
        {
            // プリミティブタイプに対応するParseメソッドの辞書を生成する
            var args = new[]
                {
                    typeof(string), typeof(NumberStyles), typeof(IFormatProvider)
                };

            CONVERTERS =
                new[]
                {
                    typeof(byte), typeof(sbyte),
                    typeof(short), typeof(ushort),
                    typeof(int), typeof(uint),
                    typeof(long), typeof(ulong),
                    typeof(float), typeof(double),
                    typeof(decimal),
                }.ToDictionary(
                    type => type,
                    type => type.GetMethod(
                        "Parse",
                        BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly,
                        null,
                        CallingConventions.Standard,
                        args,
                        null));

            // Nullable型の追加
            foreach (var entry in CONVERTERS.ToList())
            {
                CONVERTERS.Add(typeof(Nullable<>).MakeGenericType(entry.Key), entry.Value);
            }
        }
        #endregion

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="serializeFormat">シリアル化時に適用するフォーマット文字列</param>
        /// <remarks>シリアル化のフォーマットは、IFormattable.ToStringメソッドに指定するフォーマットです。</remarks>
        public NumericalStringAttribute(string serializeFormat)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(serializeFormat) == false, "フォーマット文字列が必要です");

            this._serializeFormat = serializeFormat;
            this._numberStyles = NumberStyles.Any;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="numberStyles">逆シリアル化時に適用する数値スタイル</param>
        public NumericalStringAttribute(NumberStyles numberStyles)
        {
            this._serializeFormat = "G";
            this._numberStyles = numberStyles;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="serializeFormat">シリアル化時に適用するフォーマット文字列</param>
        /// <param name="numberStyles">逆シリアル化時に適用する数値スタイル</param>
        /// <remarks>シリアル化のフォーマットは、IFormattable.ToStringメソッドに指定するフォーマットです。</remarks>
        public NumericalStringAttribute(string serializeFormat, NumberStyles numberStyles)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(serializeFormat) == false, "フォーマット文字列が必要です");

            this._serializeFormat = serializeFormat;
            this._numberStyles = numberStyles;
        }

        /// <summary>
        /// シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        public object SerializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo)
        {
            Assertion.NullArgument(pi, "プロパティ情報が必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");

            try
            {
                var rawValue = NullableExtractor.Extract(value);
                if (rawValue != null)
                {
                    rawValue = ((IFormattable)rawValue).ToString(this._serializeFormat, cultureInfo);
                }

                return rawValue;
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 逆シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        public object DeserializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo)
        {
            Assertion.NullArgument(pi, "プロパティ情報が必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");

            try
            {
                var rawValue = NullableExtractor.Extract(value);
                if (rawValue != null)
                {
                    var type = rawValue.GetType();
                    if (type.IsPrimitive == true)
                    {
                        rawValue = Convert.ChangeType(rawValue, pi.PropertyType, cultureInfo);
                    }
                    else
                    {
                        var rawString = rawValue.ToString();
                        if (string.IsNullOrWhiteSpace(rawString) == true)
                        {
                            rawString = null;
                        }
                        else
                        {
                            rawValue =
                                CONVERTERS[pi.PropertyType].Invoke(
                                    null,
                                    new object[] { rawString, this._numberStyles, cultureInfo });
                        }
                    }
                }

                return rawValue;
            }
            catch
            {
                return null;
            }
        }
    }
}

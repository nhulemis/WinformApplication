﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.07.11 TMI K.Matsui

using System;
using System.Globalization;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// 文字列をDateTime型として入出力を行う属性クラスです。
    /// </summary>
    /// <remarks>この属性を適用したプロパティは、指定された日時フォーマットで文字列との相互変換を行います。</remarks>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class DateTimeStringAttribute : CustomConvertAttribute, ICustomConvert
    {
        /// <summary>
        /// シリアル化時に適用する日時フォーマット文字列です。
        /// </summary>
        private readonly string _serializeFormat;

        /// <summary>
        /// 逆シリアル化時に適用する日時フォーマット文字列です。
        /// </summary>
        private readonly string _deserializeFormat;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="serializeFormat">シリアル化時に適用する日時フォーマット文字列</param>
        /// <param name="deserializeFormat">逆シリアル化時に適用する日時フォーマット文字列</param>
        /// <remarks>シリアル化のフォーマットは、DateTime.ToStringメソッドに指定するフォーマット、
        /// 逆シリアル化フォーマットは、DateTime.ParseExactメソッドに指定するフォーマットです。</remarks>
        public DateTimeStringAttribute(string serializeFormat, string deserializeFormat)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(serializeFormat) == false, "日時フォーマット文字列が必要です");
            Assertion.Argument(string.IsNullOrWhiteSpace(deserializeFormat) == false, "日時フォーマット文字列が必要です");

            this._serializeFormat = serializeFormat;
            this._deserializeFormat = deserializeFormat;
        }

        /// <summary>
        /// シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        public object SerializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo)
        {
            Assertion.NullArgument(pi, "プロパティ情報が必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");

            try
            {
                object rawValue = value;
                if (rawValue is DateTime?)
                {
                    rawValue = ((DateTime?)value).Value;
                }

                return ((DateTime)rawValue).ToString(this._serializeFormat, cultureInfo);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// 逆シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        public object DeserializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo)
        {
            Assertion.NullArgument(pi, "プロパティ情報が必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");

            try
            {
                if (value is DateTime)
                {
                    return value;
                }

                if (value is DateTime?)
                {
                    return ((DateTime?)value).Value;
                }

                string stringValue = value.ToString();
                return DateTime.ParseExact(stringValue, this._deserializeFormat, cultureInfo);
            }
            catch
            {
                return null;
            }
        }
    }
}

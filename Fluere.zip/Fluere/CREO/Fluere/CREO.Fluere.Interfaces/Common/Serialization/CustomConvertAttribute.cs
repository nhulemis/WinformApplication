﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// カスタムコンバートを実行するプロパティを指定する基底属性クラスです。
    /// </summary>
    /// <remarks>ConfigurationSerializerでシリアル化を行う場合に、個々のプロパティに対して
    /// 特別な変換を実施する場合、このクラスを継承して独自に属性クラスを定義し、プロパティに適用します。
    /// その後、ConfigurationSerializerを使用する際に、変換インターフェイスを登録します。
    /// 又は、継承した属性クラス自身が、ICustomConvertインターフェイスを実装して処理する事も出来ます。</remarks>
    public abstract class CustomConvertAttribute : Attribute
    {
        // TODO:微妙だ。TypeConverterとITypeDescriptorContextを使うか？

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        protected CustomConvertAttribute()
        {
        }
    }
}

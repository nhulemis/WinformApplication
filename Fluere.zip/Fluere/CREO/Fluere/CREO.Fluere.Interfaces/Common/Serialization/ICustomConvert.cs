﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.Globalization;
using System.Reflection;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// 任意の属性クラスに対応して、値の変換を実行するインターフェイスです。
    /// </summary>
    public interface ICustomConvert
    {
        /// <summary>
        /// シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        object SerializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo);

        /// <summary>
        /// 逆シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        object DeserializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo);
    }
}

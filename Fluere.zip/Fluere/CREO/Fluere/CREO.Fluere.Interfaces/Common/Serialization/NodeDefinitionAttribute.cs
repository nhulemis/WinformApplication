﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// プロパティにノード名とノードタイプを指定する属性クラスです。
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class NodeDefinitionAttribute : NodeNameAttributeBase
    {
        /// <summary>
        /// ノードタイプを格納するフィールドです。
        /// </summary>
        private readonly NodeType _nodeType;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="nodeName">ノード名</param>
        /// <remarks>このノードをエレメントとしてマークします。</remarks>
        public NodeDefinitionAttribute(string nodeName)
            : this(nodeName, NodeType.Element)
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="nodeName">ノード名</param>
        /// <param name="nodeType">ノードタイプ</param>
        public NodeDefinitionAttribute(string nodeName, NodeType nodeType)
            : base(nodeName)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(nodeName) == false, "ノード名が必要です");
            Assertion.Argument(Enum.IsDefined(typeof(NodeType), nodeType) == true, "ノードタイプが不正です");

            // TODO:良くないインターフェイス
            Assertion.Argument(nodeType != NodeType.Text, "このオーバーロードはテキストノードを指定出来ません");

            this._nodeType = nodeType;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="nodeType">ノードタイプ（テキストノードのみ）</param>
        /// <remarks>このノードをテキストノードとしてマークします。</remarks>
        public NodeDefinitionAttribute(NodeType nodeType)
            : base(null)
        {
            Assertion.Argument(nodeType == NodeType.Text, "このオーバーロードはテキストノードのみです");

            this._nodeType = nodeType;
        }

        /// <summary>
        /// ノードタイプを取得します。
        /// </summary>
        public NodeType NodeType
        {
            get
            {
                return this._nodeType;
            }
        }
    }
}

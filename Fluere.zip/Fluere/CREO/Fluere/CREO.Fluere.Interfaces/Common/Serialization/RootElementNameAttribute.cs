﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// シリアル化を行うインターフェイスのルートエレメント名を指定する属性クラスです。
    /// </summary>
    [AttributeUsage(AttributeTargets.Interface, AllowMultiple = false)]
    public class RootElementNameAttribute : Attribute
    {
        /// <summary>
        /// エレメント名を格納するフィールドです。
        /// </summary>
        private readonly string _elementName;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="elementName">エレメント名</param>
        public RootElementNameAttribute(string elementName)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(elementName) == false, "エレメント名が必要です");

            this._elementName = elementName;
        }

        /// <summary>
        /// エレメント名を取得します。
        /// </summary>
        public string ElementName
        {
            get
            {
                return this._elementName;
            }
        }
    }
}

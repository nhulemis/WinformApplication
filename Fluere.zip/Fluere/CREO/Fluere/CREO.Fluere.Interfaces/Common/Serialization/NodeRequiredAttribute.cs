﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// このノードが必ず必要である事を示す属性クラスです。
    /// </summary>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public sealed class NodeRequiredAttribute : Attribute
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public NodeRequiredAttribute()
        {
        }
    }
}

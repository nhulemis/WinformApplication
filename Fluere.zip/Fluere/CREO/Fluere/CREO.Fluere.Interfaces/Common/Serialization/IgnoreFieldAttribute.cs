﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.21 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// 入出力から除外するフィールドを指定する属性クラスです。
    /// </summary>
    /// <remarks>シリアル化・逆シリアル化で入出力を行なわない場合に、この属性を適用します。</remarks>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public sealed class IgnoreFieldAttribute : Attribute
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public IgnoreFieldAttribute()
        {
        }
    }
}

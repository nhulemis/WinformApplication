﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// 不正なデータを検出した場合の情報を格納するクラスです。
    /// </summary>
    /// <remarks>変換時に発生した例外を取得する事が出来ます。</remarks>
    public sealed class InvalidDataValueEventArgs : EventArgs
    {
        #region Fields
        /// <summary>
        /// データ位置を示すインデックスです。
        /// </summary>
        private readonly int _index;

        /// <summary>
        /// データとして必要とする型です。
        /// </summary>
        private readonly Type _requiredType;

        /// <summary>
        /// データを定義する型です。
        /// </summary>
        private readonly Type _declaredType;

        /// <summary>
        /// データを識別する名前です。
        /// </summary>
        private readonly string _identityName;

        /// <summary>
        /// 対象の例外です。
        /// </summary>
        private readonly Exception _ex;

        /// <summary>
        /// データの位置を示す任意の値です。
        /// </summary>
        private readonly object _address;

        /// <summary>
        /// 修正した値です。
        /// </summary>
        private object _value = null;

        /// <summary>
        /// 修正の状態を示す値です。
        /// </summary>
        private InvalidDataValueFixStates _fixState = InvalidDataValueFixStates.NotFixed;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="index">データ位置を示すインデックス</param>
        /// <param name="requiredType">データとして必要とする型</param>
        /// <param name="identityName">データを識別する名前</param>
        /// <param name="ex">対象の例外</param>
        /// <param name="address">データの位置を示す任意の値</param>
        [Obsolete("データを定義する型を指定するコンストラクタを使用して下さい")]
        public InvalidDataValueEventArgs(
            int index,
            Type requiredType,
            string identityName,
            Exception ex,
            object address)
        {
            Assertion.NullArgument(requiredType, "データとして必要とする型が必要です");
            Assertion.Argument(string.IsNullOrWhiteSpace(identityName) == false, "データを識別する名前が必要です");
            Assertion.NullArgument(ex, "例外が必要です");

            this._index = index;
            this._requiredType = requiredType;
            this._identityName = identityName;
            this._ex = ex;
            this._address = address;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="index">データ位置を示すインデックス</param>
        /// <param name="requiredType">データとして必要とする型</param>
        /// <param name="declaredType">データを定義する型</param>
        /// <param name="identityName">データを識別する名前</param>
        /// <param name="ex">対象の例外</param>
        /// <param name="address">データの位置を示す任意の値</param>
        public InvalidDataValueEventArgs(
            int index,
            Type requiredType,
            Type declaredType,
            string identityName,
            Exception ex,
            object address)
        {
            Assertion.NullArgument(requiredType, "データとして必要とする型が必要です");
            Assertion.NullArgument(declaredType, "データを定義する型が必要です");
            Assertion.Argument(string.IsNullOrWhiteSpace(identityName) == false, "データを識別する名前が必要です");
            Assertion.NullArgument(ex, "例外が必要です");

            this._index = index;
            this._requiredType = requiredType;
            this._declaredType = declaredType;
            this._identityName = identityName;
            this._ex = ex;
            this._address = address;
        }
        #endregion

        #region Index
        /// <summary>
        /// データ位置を示すインデックスを取得します。
        /// </summary>
        public int Index
        {
            get
            {
                return this._index;
            }
        }
        #endregion

        #region RequiredType
        /// <summary>
        /// データとして必要な型を取得します。
        /// </summary>
        public Type RequiredType
        {
            get
            {
                return this._requiredType;
            }
        }
        #endregion

        #region DeclaredType
        /// <summary>
        /// データを定義する型を取得します。
        /// </summary>
        public Type DeclaredType
        {
            get
            {
                return this._declaredType;
            }
        }
        #endregion

        #region IdentityName
        /// <summary>
        /// データを識別する名前を取得します。
        /// </summary>
        public string IdentityName
        {
            get
            {
                return this._identityName;
            }
        }
        #endregion

        #region Exception
        /// <summary>
        /// 対象の例外を取得します。
        /// </summary>
        public Exception Exception
        {
            get
            {
                return this._ex;
            }
        }
        #endregion

        #region Address
        /// <summary>
        /// データの位置を示す任意の値を取得します。
        /// </summary>
        /// <remarks>現在データを処理しているクラスによって、表現方法が異なります。</remarks>
        public object Address
        {
            get
            {
                return this._address;
            }
        }
        #endregion

        #region FixedValue
        /// <summary>
        /// 修正した値を取得・設定します。
        /// </summary>
        /// <remarks>変換に失敗したフィールドに対して、代替の値を設定させます。
        /// 値を設定する場合は、RequiredTypeで示される型にキャスト可能である必要があります。</remarks>
        public object FixedValue
        {
            get
            {
                return this._value;
            }

            set
            {
                Assertion.Argument(
                    ((this._requiredType.IsValueType == false) && ((value == null) || this._requiredType.IsInstanceOfType(value))) ||
                    ((this._requiredType.IsValueType == true) && this._requiredType.IsInstanceOfType(value)),
                    "指定された値は、データ型と互換性がありません: 型={0}",
                    this._requiredType.FullName);

                this._value = value;
                this._fixState = InvalidDataValueFixStates.Fixed;
            }
        }
        #endregion

        #region FixState
        /// <summary>
        /// 修正の状態を取得します。
        /// </summary>
        public InvalidDataValueFixStates FixState
        {
            get
            {
                return this._fixState;
            }
        }
        #endregion

        #region SetIgnored
        /// <summary>
        /// このレコードを無視する事を指定します。
        /// </summary>
        /// <remarks>このメソッドを呼び出す事で、現在のレコードを無視し、次のレコードを処理する事を指定します。</remarks>
        public void SetIgnored()
        {
            this._value = null;
            this._fixState = InvalidDataValueFixStates.Ignored;
        }
        #endregion
    }
}

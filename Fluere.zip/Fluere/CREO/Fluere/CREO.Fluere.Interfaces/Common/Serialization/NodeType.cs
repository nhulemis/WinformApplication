﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// ノードタイプを指定する列挙型です。
    /// </summary>
    public enum NodeType
    {
        /// <summary>
        /// このノードをエレメントとします。
        /// </summary>
        Element = 0,

        /// <summary>
        /// このノードをXML属性とします。
        /// </summary>
        Attribute = 1,

        /// <summary>
        /// このノードをテキストノードとします。
        /// </summary>
        /// <remarks>テキストノードは親ノードに付き一件のみ設定出来ます。</remarks>
        Text = 2
    }
}

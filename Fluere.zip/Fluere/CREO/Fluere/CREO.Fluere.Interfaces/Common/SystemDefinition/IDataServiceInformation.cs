﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.SystemDefinition
{
    /// <summary>
    /// データサービスの情報を示すインターフェイスです。
    /// </summary>
    public interface IDataServiceInformation
    {
        /// <summary>
        /// データソースID文字列を取得・設定します。
        /// </summary>
        [NodeRequired]
        [NodeDefinition("id", NodeType.Attribute)]
        string DataSourceId
        {
            get;
            set;
        }

        /// <summary>
        /// データソースキャプション文字列を取得・設定します。
        /// </summary>
        [NodeDefinition("caption", NodeType.Attribute)]
        string Caption
        {
            get;
            set;
        }

        /// <summary>
        /// データソースのコメントを取得・設定します。
        /// </summary>
        [NodeDefinition("comment", NodeType.Attribute)]
        string Comment
        {
            get;
            set;
        }
    }
}

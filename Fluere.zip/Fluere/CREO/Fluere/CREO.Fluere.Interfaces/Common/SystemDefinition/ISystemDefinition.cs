﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.Collections.Generic;
using System.ComponentModel;

using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.SystemDefinition
{
    /// <summary>
    /// システム定義を示すインターフェイスです。
    /// </summary>
    /// <remarks>このインターフェイス定義は、ConfigurationSerializerクラスでシリアル化可能です。</remarks>
    [Description("システム定義ファイル")]
    [RootElementName("Root")]
    public interface ISystemDefinition
    {
        /// <summary>
        /// データサービスの情報を取得・設定します。
        /// </summary>
        [NodeRequired]
        [NodeDefinition("dbinfo")]
        IDataServiceInformation DataServiceInformation
        {
            get;
            set;
        }

        /// <summary>
        /// ジョブ情報を取得・設定します。
        /// </summary>
        [NodeRequired]
        [NodeDefinition("jobinfo")]
        IJobInformation JobInformation
        {
            get;
            set;
        }

        /// <summary>
        /// この工程で作業を行う2次メッシュの範囲を示すコレクションを取得・設定します。
        /// </summary>
        [NodeDefinition("areas")]
        [ItemElementNames("meshCode")]
        IList<int> ProcessSecondMeshCodes
        {
            get;
            set;
        }

        /// <summary>
        /// オプションのパラメータ群を示す列挙子を取得・設定します。
        /// </summary>
        [NodeDefinition("extensions")]
        [ItemElementNames("parameter")]
        IList<string> OptionalParameters
        {
            get;
            set;
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using CREO.Fluere.Common.Configuration;
using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.SystemDefinition
{
    /// <summary>
    /// ジョブ情報を取得するインターフェイスです。
    /// </summary>
    public interface IJobInformation
    {
        /// <summary>
        /// 親ジョブIDを取得・設定します。
        /// </summary>
        [NodeRequired]
        [NodeDefinition("parentjob_id")]
        ulong ParentJobId
        {
            get;
            set;
        }

        /// <summary>
        /// ワークグループIDを取得・設定します。
        /// </summary>
        [NodeRequired]
        [NodeDefinition("wgid")]
        [NodeNullable]
        ulong WorkGroupId
        {
            get;
            set;
        }

        /// <summary>
        /// トリガIDを取得・設定します。
        /// </summary>
        [NodeRequired]
        [NodeDefinition("trigger_id")]
        ulong TriggerId
        {
            get;
            set;
        }

        /// <summary>
        /// 子ジョブIDを取得・設定します。
        /// </summary>
        [NodeDefinition("childjob_id")]
        ulong ChildJobId
        {
            get;
            set;
        }

        /// <summary>
        /// サブワークグループIDを取得・設定します。
        /// </summary>
        [NodeDefinition("swgid")]
        [NodeNullable]
        ulong SubWorkGroupId
        {
            get;
            set;
        }

        /// <summary>
        /// ロットIDを取得・設定します。
        /// </summary>
        [NodeDefinition("lot_id")]
        ulong LotId
        {
            get;
            set;
        }

        /// <summary>
        /// 作業工程IDを取得・設定します。
        /// </summary>
        [NodeDefinition("sgprocess_id")]
        ulong SgProcessId
        {
            get;
            set;
        }

        /// <summary>
        /// 工程情報IDを取得・設定します。
        /// </summary>
        [NodeDefinition("process_id")]
        string ProcessId
        {
            get;
            set;
        }

        /// <summary>
        /// ToDoファイルのパスを取得・設定します。
        /// </summary>
        [NodeDefinition("todopath")]
        [RelativePath]
        string ToDoPath
        {
            get;
            set;
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.Configuration
{
    /// <summary>
    /// Fluere処理で使用する設定ファイルの制御を行う共変性ジェネリックインターフェイスです。
    /// </summary>
    /// <typeparam name="T">設定データに対応するインターフェイス</typeparam>
    public interface IConfigurationManager<out T> : IConfigurationManager
        where T : class
    {
        /// <summary>
        /// 設定データを反映するインスタンスを取得します。
        /// </summary>
        new T Configuration
        {
            get;
        }
    }
}

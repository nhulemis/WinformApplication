﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.Configuration
{
    /// <summary>
    /// Fluere処理で使用する設定データの制御を行うインターフェイスです。
    /// </summary>
    /// <remarks>設定データのインスタンスを割り当てる事が出来ます。</remarks>
    public interface IAssignableConfigurationManager : IConfigurationManager
    {
        /// <summary>
        /// 設定データを反映するインスタンスを取得・設定します。
        /// </summary>
        new object Configuration
        {
            get;
            set;
        }
    }
}

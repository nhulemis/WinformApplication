﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.Configuration
{
    /// <summary>
    /// Fluere処理で使用する設定データの制御を行う基底インターフェイスです。
    /// </summary>
    public interface IConfigurationManager
    {
        /// <summary>
        /// 設定データを識別する名前を取得します。
        /// </summary>
        string Name
        {
            get;
        }

        /// <summary>
        /// 設定データを識別する長い名前を取得します。
        /// </summary>
        /// <remarks>対象がファイルの場合は、設定データを示すファイルのパスが返されます。</remarks>
        string FullName
        {
            get;
        }

        /// <summary>
        /// 設定データを反映するインスタンスを取得します。
        /// </summary>
        object Configuration
        {
            get;
        }

        /// <summary>
        /// 設定データをストレージからロードします。
        /// </summary>
        void Load();

        /// <summary>
        /// 設定データをストレージにセーブします。
        /// </summary>
        void Save();
    }
}

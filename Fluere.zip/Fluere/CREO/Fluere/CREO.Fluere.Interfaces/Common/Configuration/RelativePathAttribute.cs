﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.Configuration
{
    /// <summary>
    /// このノードがフォルダ・ファイルパスを示し、かつ相対パスを想定する事を示す属性クラスです。
    /// </summary>
    /// <remarks>文字列を示すプロパティに適用し、文字列の内容を読み取った時に絶対パスに変換し、
    /// 出力する際には可能であれば相対パスに変換します。</remarks>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public sealed class RelativePathAttribute : CustomConvertAttribute
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public RelativePathAttribute()
        {
        }
    }
}

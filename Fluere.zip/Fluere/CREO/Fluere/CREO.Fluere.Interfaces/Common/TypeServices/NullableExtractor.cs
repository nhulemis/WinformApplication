﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// Nullableのインスタンスから、内包されている実際の値を取得するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal static class NullableExtractor
    {
        /// <summary>
        /// Nullable値抽出インターフェイスの辞書
        /// </summary>
        private static readonly IDictionary<Type, INullableExtractor> EXTRACTORS =
            new Dictionary<Type, INullableExtractor>();

        /// <summary>
        /// Nullableインスタンスから値を取得するための共通のビューを定義するインターフェイスです。
        /// </summary>
        /// <remarks>このインターフェイスは内部で使用します。</remarks>
        internal interface INullableExtractor
        {
            /// <summary>
            /// 指定されたNullableインスタンスから、内包されている値を取得します。
            /// </summary>
            /// <param name="value">Nullableインスタンス</param>
            /// <returns>値</returns>
            object Extract(object value);
        }

        /// <summary>
        /// 指定された型のINullableExtractorのインスタンスを取得します。
        /// </summary>
        /// <param name="nullableType">Nullable&lt;T&gt;のT型</param>
        /// <returns>インスタンス（無ければnull）</returns>
        internal static INullableExtractor GetExtractor(Type nullableType)
        {
            Assertion.Condition(nullableType != null);

            INullableExtractor extractor;
            lock (EXTRACTORS)
            {
                if (EXTRACTORS.TryGetValue(nullableType, out extractor) == false)
                {
                    Type underlyingType = Nullable.GetUnderlyingType(nullableType);
                    if (underlyingType != null)
                    {
                        // InternalNullableExtractorジェネリッククラスをインスタンス化して、辞書に保持する。

                        // Nullable<T>には、T型に依存しないインターフェイスが無いため、
                        // HasValueやValueプロパティを参照するのにリフレクションを使う必要があり、
                        // 呼び出しコストを削減するために、INullableExtractorインターフェイスで
                        // 共通のメソッドを定義し、リフレクションを使わなくても取得出来るようにした。
                        // InternalNullableExtractorの生成はここで行うが、辞書に保持する事で生成コストも削減している。

                        Type extractorType = typeof(InternalNullableExtractor<>).MakeGenericType(underlyingType);
                        extractor = (INullableExtractor)Activator.CreateInstance(extractorType);
                    }

                    // Nullableでは無い場合は、extractor==nullとなる
                    EXTRACTORS.Add(nullableType, extractor);
                }
            }

            return extractor;
        }

        /// <summary>
        /// 指定されたインスタンスがNullableの場合に、内包されている値を取得します。
        /// </summary>
        /// <param name="value">インスタンス</param>
        /// <returns>値</returns>
        /// <remarks>Nullableが値を保持していない場合はnullが返されます。
        /// インスタンスがNullableではない場合は、インスタンスがそのまま返され、nullの場合はnullが返されます。</remarks>
        public static object Extract(object value)
        {
            if (value == null)
            {
                return null;
            }

            // InternalNullableExtractor<T>のインスタンスを取得して抽出する
            Type nullableType = value.GetType();
            INullableExtractor extractor = GetExtractor(nullableType);

            // INullableExtractorのインスタンスがあればExtractメソッドで抽出を実行し、無ければインスタンスをそのまま返す
            return (extractor != null) ? extractor.Extract(value) : value;
        }

        /// <summary>
        /// 指定されたインスタンスがNullableの場合に、内包されている値を取得します。
        /// </summary>
        /// <param name="value">インスタンス</param>
        /// <param name="extractedValue">値</param>
        /// <returns>Nullableであればtrue</returns>
        public static bool Extract(object value, out object extractedValue)
        {
            extractedValue = null;

            if (value == null)
            {
                return false;
            }

            // InternalNullableExtractor<T>のインスタンスを取得して抽出する
            Type nullableType = value.GetType();
            INullableExtractor extractor = GetExtractor(nullableType);
            if (extractor == null)
            {
                return false;
            }

            extractedValue = extractor.Extract(value);
            return true;
        }

        /// <summary>
        /// 指定された型を内包するNullableインスタンスから、値を取得するクラスです。
        /// </summary>
        /// <typeparam name="T">Nullableが内包する型</typeparam>
        /// <remarks>このクラスは内部で使用します。
        /// T型はジェネリック引数として解釈されるため、最小のコストでNullable型から値を抽出出来ます。</remarks>
        internal sealed class InternalNullableExtractor<T> : INullableExtractor
            where T : struct
        {
            /// <summary>
            /// 指定されたNullableインスタンスから、内包されている値を取得します。
            /// </summary>
            /// <param name="value">Nullableインスタンス</param>
            /// <returns>値</returns>
            public object Extract(object value)
            {
                // Unbox
                T? nullableValue = (T?)value;

                if (nullableValue.HasValue == true)
                {
                    return nullableValue.Value;
                }
                else
                {
                    return null;
                }
            }
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.25 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// TypeWrapperクラスが生成したシムクラスが実装する共通のインターフェイスです。
    /// </summary>
    public interface IWrappedInstance : IComparable
    {
    }
}

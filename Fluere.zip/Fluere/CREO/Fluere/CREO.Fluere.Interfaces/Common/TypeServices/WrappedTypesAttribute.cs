﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// ラッパークラスに適用される属性クラスです。
    /// </summary>
    /// <remarks>ラッパークラスのラップ対象クラスと、対応するインターフェイスを関連付けます。
    /// この属性クラスは、TypeWrapperによって自動的に適用されます。</remarks>
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public sealed class WrappedTypesAttribute : Attribute
    {
        /// <summary>
        /// ラップクラスがラップしているクラスです。
        /// </summary>
        private readonly Type _fromType;

        /// <summary>
        /// ラップクラスが実装しているインターフェイスです。
        /// </summary>
        private readonly Type _toType;

        /// <summary>
        /// ラップしているクラスのスタティックメンバが対象かどうかです。
        /// </summary>
        private readonly bool _isStatic;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="fromType">ラップクラスがラップしているクラス</param>
        /// <param name="toType">ラップクラスが実装しているインターフェイス</param>
        /// <param name="isStatic">ラップしているクラスのスタティックメンバが対象ならtrue</param>
        public WrappedTypesAttribute(Type fromType, Type toType, bool isStatic)
        {
            Assertion.Condition(fromType != null);
            Assertion.Condition(toType != null);

            this._fromType = fromType;
            this._toType = toType;
            this._isStatic = isStatic;
        }

        /// <summary>
        /// ラップクラスがラップしているクラスを取得します。
        /// </summary>
        public Type FromType
        {
            get
            {
                return this._fromType;
            }
        }

        /// <summary>
        /// ラップクラスが実装しているインターフェイスを取得します。
        /// </summary>
        public Type ToType
        {
            get
            {
                return this._fromType;
            }
        }

        /// <summary>
        /// ラップしているクラスのスタティックメンバが対象かどうかを取得します。
        /// </summary>
        public bool IsStatic
        {
            get
            {
                return this._isStatic;
            }
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// TypeWrapperが提供するラッパークラスの動作に介入するインターフェイスです。
    /// </summary>
    /// <remarks>TypeWrapperクラスでラッパークラスのインスタンスを取得する際に使用します。
    /// また、IComparer・IEqualityComparerインターフェイスの実装は、
    /// インスタンスに対する比較メソッド群の実装を提供出来るようにします。
    /// GetTargetType以外の各メソッドの引数には、元のインスタンス（又はnull）が渡されるため、
    /// サロゲータの実装内でインスタンスをラップ・アンラップする必要はありません。</remarks>
    public interface ITypeWrapperSurrogator : IComparer, IEqualityComparer
    {
        /// <summary>
        /// インスタンスの実際のクラスから、変換されるべきインターフェイス型を特定します。
        /// </summary>
        /// <param name="realType">インスタンスの実際のクラス</param>
        /// <param name="assignableType">指定された、キャスト可能なインターフェイス</param>
        /// <returns>変換されるべきインターフェイス</returns>
        /// <remarks>インスタンスの型から、ラッパークラスが実装するべき本来のインターフェイスが特定出来る場合に、
        /// このメソッドを実装する事でそのインターフェイス型を供給する事が出来ます。
        /// 返却するインターフェイスは、引数で指定されているキャスト可能なインターフェイスにキャスト出来なければなりません。
        /// この事を式で示すと、次の通りです：assignableType.IsAssignableFrom(returnValue) == true</remarks>
        Type GetTargetType(Type realType, Type assignableType);

        /// <summary>
        /// 指定されたインスタンスの文字列表現を取得します。
        /// </summary>
        /// <param name="realObj">インスタンス</param>
        /// <returns>文字列表現</returns>
        string ToString(object realObj);

        /// <summary>
        /// 対象のインスタンスの有効期間ポリシーを制御する、有効期間サービスオブジェクトを取得します。
        /// </summary>
        /// <param name="realObj">インスタンス</param>
        /// <returns>対象のインスタンスの有効期間ポリシーを制御するときに使用する、ILease 型のオブジェクト</returns>
        object InitializeLifetimeService(object realObj);
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Runtime.Serialization;
using System.Security;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// TypeWrapperクラスで発生する例外クラスです。
    /// </summary>
    [Serializable]
    public sealed class TypeWrapperException : FluereException
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="message">メッセージ</param>
        public TypeWrapperException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public TypeWrapperException(string format, params object[] args)
            : base(format, args)
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="inner">内包する例外</param>
        /// <param name="message">メッセージ</param>
        public TypeWrapperException(Exception inner, string message)
            : base(inner, message)
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="inner">内包する例外</param>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public TypeWrapperException(Exception inner, string format, params object[] args)
            : base(inner, format, args)
        {
        }

        /// <summary>
        /// 逆シリアル化コンストラクタです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecuritySafeCritical]
        private TypeWrapperException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}

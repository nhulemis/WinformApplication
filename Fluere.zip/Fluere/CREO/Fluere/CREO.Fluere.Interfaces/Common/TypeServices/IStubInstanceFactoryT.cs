﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// 型のインスタンスを生成するファクトリインターフェイスです。
    /// </summary>
    /// <typeparam name="T">ファクトリが生成する型</typeparam>
    /// <remarks>StubInstanceFactoryクラスで使用します。
    /// あらかじめこのインターフェイスを取得しておく事で、静的に生成した場合と変わらない速度でインスタンスを生成出来ます。</remarks>
    public interface IStubInstanceFactory<T>
        where T : class
    {
        /// <summary>
        /// インスタンスを生成します。
        /// </summary>
        /// <returns>生成したインスタンス</returns>
        T CreateInstance();
    }
}

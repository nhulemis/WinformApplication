﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// TypeWrapperクラスが生成したシムクラスから、内包するインスタンスを取得するインターフェイスです。
    /// </summary>
    /// <remarks>このインターフェイスは内部で使用します。</remarks>
    public interface IRealInstance : IWrappedInstance
    {
        /// <summary>
        /// ラップした、内包するインスタンスを取得します。
        /// </summary>
        object RealInstance
        {
            get;
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.20 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// StubInstanceFactoryによって生成されたインスタンスが実装するインターフェイスです。
    /// </summary>
    public interface IStubInstance : ICloneable
    {
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.IO;

using CREO.Fluere.Biz.Data;

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// ファイルシステムのトランザクションを管理するインターフェイスです。
    /// </summary>
    /// <remarks>このインターフェイスは内部で使用します。</remarks>
    public interface IFileSystemTransactionContext : ITransactionContext
    {
        /// <summary>
        /// フォルダを生成します。
        /// </summary>
        /// <param name="folderPath">対象のフォルダパス</param>
        /// <returns>代替パス</returns>
        string CreateDirectory(string folderPath);

        /// <summary>
        /// 直接紐付けられない生成ファイルを、エンリストメントアイテムとして追跡します。
        /// </summary>
        /// <param name="filePath">ファイルへのパス</param>
        /// <remarks>トランザクションコンテキストに紐付けられていないファイルを追跡し、
        /// ロールバック時にファイルの削除を行います。</remarks>
        void TrackFilePath(string filePath);

        /// <summary>
        /// トランザクションに関連付けられたストリームを生成します。
        /// </summary>
        /// <param name="filePath">ファイルへのパス</param>
        /// <param name="fileMode">ファイルモード</param>
        /// <param name="fileAccess">ファイルアクセス</param>
        /// <returns>ストリーム</returns>
        Stream CreateStream(string filePath, FileMode fileMode, FileAccess fileAccess);
    }
}

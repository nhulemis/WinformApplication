﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.IO;

using CREO.Fluere.Biz.Data;

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// ファイルトランザクションインターフェイスです。
    /// </summary>
    public interface ITransactionalFileStream : ITransactionControl
    {
        /// <summary>
        /// 対象のファイルのパスを取得します。
        /// </summary>
        string TargetPath
        {
            get;
        }

        /// <summary>
        /// 割り当てられたトランザクションIDを取得します。
        /// </summary>
        Guid TransactionID
        {
            get;
        }

        /// <summary>
        /// ストリームの長さをバイト単位で取得します。
        /// </summary>
        long Length
        {
            get;
        }

        /// <summary>
        /// 現在のストリーム内の位置を取得または設定します。
        /// </summary>
        long Position
        {
            get;
            set;
        }

        /// <summary>
        /// 現在のストリームの長さを設定します。
        /// </summary>
        /// <param name="value">現在のストリームの希望の長さ (バイト数)。</param>
        void SetLength(long value);

        /// <summary>
        /// 現在のストリーム内の位置を設定します。
        /// </summary>
        /// <param name="offset">origin パラメーターからのバイト オフセット。</param>
        /// <param name="origin">新しい位置を取得するために使用する参照ポイントを示す System.IO.SeekOrigin 型の値。</param>
        /// <returns>現在のストリーム内の新しい位置。</returns>
        long Seek(long offset, SeekOrigin origin);

        /// <summary>
        /// 現在のストリームからバイト シーケンスを読み取り、読み取ったバイト数の分だけストリームの位置を進めます。
        /// </summary>
        /// <param name="buffer">バイト配列。このメソッドが戻るとき、指定したバイト配列の offset から (offset + count -1) までの値が、現在のソースから読み取られたバイトに置き換えられます。</param>
        /// <param name="offset">現在のストリームから読み取ったデータの格納を開始する位置を示す buffer 内のバイト オフセット。インデックス番号は 0 から始まります。</param>
        /// <param name="count">現在のストリームから読み取る最大バイト数。</param>
        /// <returns>バッファーに読み取られた合計バイト数。要求しただけのバイト数を読み取ることができなかった場合、この値は要求したバイト数より小さくなります。ストリームの末尾に到達した場合は0 (ゼロ) になることがあります。</returns>
        int Read(byte[] buffer, int offset, int count);

        /// <summary>
        /// 現在のストリームにバイト シーケンスを書き込み、書き込んだバイト数の分だけストリームの現在位置を進めます。
        /// </summary>
        /// <param name="buffer">バイト配列。このメソッドは、buffer から現在のストリームに、count で指定されたバイト数だけコピーします。</param>
        /// <param name="offset">現在のストリームへのバイトのコピーを開始する位置を示す buffer 内のバイト オフセット。インデックス番号は 0 から始まります。</param>
        /// <param name="count">現在のストリームに書き込むバイト数。</param>
        void Write(byte[] buffer, int offset, int count);

        /// <summary>
        /// 非同期の読み込み動作を開始します。
        /// </summary>
        /// <param name="buffer">データを読み込むバッファー。</param>
        /// <param name="offset">ストリームから読み込んだデータの書き込み開始位置を示す buffer 内のバイト オフセット。</param>
        /// <param name="count">読み取る最大バイト数。</param>
        /// <param name="callback">読み取り完了時に呼び出されるオプションの非同期コールバック。</param>
        /// <param name="state">この特定の非同期読み取り要求を他の要求と区別するために使用するユーザー指定のオブジェクト。</param>
        /// <returns>非同期の読み込みを表す System.IAsyncResult。まだ保留状態の場合もあります。</returns>
        IAsyncResult BeginRead(
            byte[] buffer, int offset, int count, AsyncCallback callback, object state);

        /// <summary>
        /// 非同期の書き込み操作を開始します。
        /// </summary>
        /// <param name="buffer">データを書き込む元となるバッファー。</param>
        /// <param name="offset">書き込むデータの開始位置を示す buffer 内のバイト オフセット。</param>
        /// <param name="count">書き込む最大バイト数。</param>
        /// <param name="callback">書き込みの完了時に呼び出されるオプションの非同期コールバック。</param>
        /// <param name="state">この特定の非同期書き込み要求を他の要求と区別するために使用するユーザー指定のオブジェクト。</param>
        /// <returns>非同期の書き込みを表す IAsyncResult。まだ保留状態の場合もあります。</returns>
        IAsyncResult BeginWrite(
            byte[] buffer, int offset, int count, AsyncCallback callback, object state);

        /// <summary>
        /// 保留中の非同期読み取りが完了するまで待機します。
        /// </summary>
        /// <param name="asyncResult">終了させる保留状態の非同期リクエストへの参照。</param>
        /// <returns>ストリームから読み取ったバイト数 (0 ～要求したバイト数の間の数値)。ゼロ (0) が返されるのは、ストリームの末尾で読み取ろうとしたときだけです。それ以外の場合は、少なくとも1 バイトが読み込み可能になるまでブロックします。</returns>
        int EndRead(IAsyncResult asyncResult);

        /// <summary>
        /// 非同期書き込み操作を終了します。
        /// </summary>
        /// <param name="asyncResult">保留状態の非同期 I/O リクエストへの参照。</param>
        void EndWrite(IAsyncResult asyncResult);
    }
}

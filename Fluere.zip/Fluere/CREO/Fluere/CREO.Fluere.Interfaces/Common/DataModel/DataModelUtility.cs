﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataModel
{
    /// <summary>
    /// データモデルのContentID（TypeID）の特定に使用する、固定の実装です。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    [Obsolete]
    public static class DataModelUtility
    {
        /// <summary>
        /// データモデルクラスから、ContentID（TypeID）を取得します。
        /// </summary>
        /// <param name="targetType">データモデルクラス</param>
        /// <returns>ContentID文字列</returns>
        /// <remarks>このメソッドは内部で使用します。</remarks>
        public static string GetContentIDFromDataModelTargetType(Type targetType)
        {
            Assertion.Condition(targetType != null);
            Assertion.Condition(typeof(CREO.DataModel.GeoItem).IsAssignableFrom(targetType) == true);

            // ContentIDとは、つまりクラス名（本当にいいのか？フレームワークは属性ベースでやってほしいのだが...）
            return targetType.Name;
        }
    }
}

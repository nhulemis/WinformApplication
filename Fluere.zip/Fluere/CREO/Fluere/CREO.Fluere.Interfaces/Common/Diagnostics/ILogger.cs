﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Common.Diagnostics
{
    /// <summary>
    /// ログ出力のインターフェイスです。
    /// </summary>
    /// <remarks>フレームワークログ出力の依存を分離するためのインターフェイスです。
    /// Fluere処理を起動したモジュールが処理を提供します。</remarks>
    public interface ILogger
    {
        /// <summary>
        /// ログを出力します。
        /// </summary>
        /// <param name="messageID">メッセージID</param>
        /// <param name="args">ログに出力するメッセージに適用する引数群</param>
        void WriteLog(string messageID, params object[] args);

        /// <summary>
        /// ログを出力します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="messageID">メッセージID</param>
        /// <param name="args">ログに出力するメッセージに適用する引数群</param>
        void WriteLog(Exception ex, string messageID, params object[] args);

        /// <summary>
        /// ログを出力します。
        /// </summary>
        /// <param name="ex">CREOException例外</param>
        /// <returns>エラーコード</returns>
        int WriteLog(CREOException ex);

        /// <summary>
        /// デバッグ用ログを出力します。
        /// </summary>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        void WriteDebugLog(string format, params object[] args);

        /// <summary>
        /// デバッグ用ログを出力します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        void WriteDebugLog(Exception ex, string format, params object[] args);

        /// <summary>
        /// トレース用ログを出力します。
        /// </summary>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        void WriteTraceLog(string format, params object[] args);

        /// <summary>
        /// トレース用ログを出力します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        void WriteTraceLog(Exception ex, string format, params object[] args);
    }
}

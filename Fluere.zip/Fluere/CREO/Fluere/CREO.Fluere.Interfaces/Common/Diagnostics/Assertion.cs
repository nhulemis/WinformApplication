﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Diagnostics;

namespace CREO.Fluere.Common.Diagnostics
{
    /// <summary>
    /// アサーション判定を行うクラスです。
    /// </summary>
    /// <remarks>各判定メソッドのフォーマット文字列は基本的にstring.Formatと同じですが、
    /// 引数群にはFunc&lt;object&gt;によるファンクタを含める事が可能です。
    /// これにより、アサーション条件を満たした場合にのみ、詳細な分析用文字列を生成する事が出来ます。
    /// 条件を満たさない場合はフォーマットが行われないため、ファンクタは実行されません。</remarks>
    [DebuggerNonUserCode]
    public static class Assertion
    {
        #region InterpretArguments
        /// <summary>
        /// 引数群にファンクタが含まれている場合は実行します。
        /// </summary>
        /// <param name="args">引数群</param>
        /// <returns>ファンクタを解釈済みの引数群</returns>
        internal static object[] InterpretArguments(object[] args)
        {
            Debug.Assert(args != null, "引数群が必要です");

            object[] rawArguments = new object[args.Length];
            for (int i = 0; i < args.Length; i++)
            {
                Func<object> functor = args[i] as Func<object>;
                if (functor != null)
                {
                    rawArguments[i] = functor();
                }
                else
                {
                    rawArguments[i] = args[i];
                }
            }

            return rawArguments;
        }
        #endregion

        #region FormatArguments
        /// <summary>
        /// 引数群を使用して文字列をフォーマットします。
        /// </summary>
        /// <param name="format">フォーマット</param>
        /// <param name="args">引数群</param>
        /// <returns>文字列</returns>
        internal static string FormatArguments(string format, object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列が必要です");
            Debug.Assert(args != null, "引数群が必要です");

            return string.Format(format, InterpretArguments(args));
        }
        #endregion

        #region Argument
        /// <summary>
        /// メソッドの事前条件を記述します。
        /// </summary>
        /// <param name="condition">事前条件式</param>
        /// <param name="message">条件を満たさない場合のメッセージ文字列</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、ArgumentExceptionがスローされます。</remarks>
        public static bool Argument(bool condition, string message)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(message) == false, "メッセージが必要です");

            if (condition == false)
            {
                throw new ArgumentException(message);
            }

            return condition;
        }

        /// <summary>
        /// メソッドの事前条件を記述します。
        /// </summary>
        /// <param name="condition">事前条件式</param>
        /// <param name="format">条件を満たさない場合のメッセージを生成するフォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、ArgumentExceptionがスローされます。</remarks>
        public static bool Argument(bool condition, string format, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列が必要です");

            if (condition == false)
            {
                throw new ArgumentException(FormatArguments(format, args));
            }

            return condition;
        }
        #endregion

        #region ArgumentT
        /// <summary>
        /// メソッドの事前条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="condition">事前条件式</param>
        /// <param name="message">条件を満たさない場合のメッセージ文字列</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、T型の例外がスローされます。</remarks>
        public static bool Argument<T>(bool condition, string message)
            where T : Exception
        {
            Debug.Assert(string.IsNullOrWhiteSpace(message) == false, "メッセージが必要です");

            if (condition == false)
            {
                throw (Exception)Activator.CreateInstance(typeof(T), message);
            }

            return condition;
        }

        /// <summary>
        /// メソッドの事前条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="condition">事前条件式</param>
        /// <param name="format">条件を満たさない場合のメッセージを生成するフォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、T型の例外がスローされます。</remarks>
        public static bool Argument<T>(bool condition, string format, params object[] args)
            where T : Exception
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列が必要です");

            if (condition == false)
            {
                throw (Exception)Activator.CreateInstance(typeof(T), FormatArguments(format, args));
            }

            return condition;
        }

        /// <summary>
        /// メソッドの事前条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="condition">事前条件式</param>
        /// <param name="constructorArgs">例外コンストラクタの引数群</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、T型の例外がスローされます。</remarks>
        public static bool Argument<T>(bool condition, object[] constructorArgs)
            where T : Exception
        {
            Debug.Assert(constructorArgs != null, "例外コンストラクタの引数群が必要です");

            if (condition == false)
            {
                throw (Exception)Activator.CreateInstance(typeof(T), InterpretArguments(constructorArgs));
            }

            return condition;
        }
        #endregion

        #region NullArgument
        /// <summary>
        /// メソッドの事前条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="instance">インスタンス</param>
        /// <param name="message">条件を満たさない場合のメッセージ文字列</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、ArgumentNullExceptionがスローされます。</remarks>
        public static bool NullArgument<T>(T instance, string message)
            where T : class
        {
            Debug.Assert(string.IsNullOrWhiteSpace(message) == false, "メッセージが必要です");

            if (instance == null)
            {
                throw new ArgumentNullException(message);
            }

            return true;
        }

        /// <summary>
        /// メソッドの事前条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="instance">インスタンス</param>
        /// <param name="format">条件を満たさない場合のメッセージを生成するフォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、ArgumentNullExceptionがスローされます。</remarks>
        public static bool NullArgument<T>(T instance, string format, params object[] args)
            where T : class
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列が必要です");

            if (instance == null)
            {
                throw new ArgumentNullException(FormatArguments(format, args));
            }

            return true;
        }
        #endregion

        #region Require
        /// <summary>
        /// ロジックの必要条件を記述します。
        /// </summary>
        /// <param name="condition">条件式</param>
        /// <param name="message">条件を満たさない場合のメッセージ文字列</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、InvalidOperationExceptionがスローされます。</remarks>
        public static bool Require(bool condition, string message)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(message) == false, "メッセージが必要です");

            if (condition == false)
            {
                throw new InvalidOperationException(message);
            }

            return condition;
        }

        /// <summary>
        /// ロジックの必要条件を記述します。
        /// </summary>
        /// <param name="condition">条件式</param>
        /// <param name="format">条件を満たさない場合のメッセージを生成するフォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、InvalidOperationExceptionがスローされます。</remarks>
        public static bool Require(bool condition, string format, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列が必要です");

            if (condition == false)
            {
                throw new InvalidOperationException(FormatArguments(format, args));
            }

            return condition;
        }
        #endregion

        #region RequireT
        /// <summary>
        /// ロジックの必要条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="condition">条件式</param>
        /// <param name="message">条件を満たさない場合のメッセージ文字列</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、T型の例外がスローされます。</remarks>
        public static bool Require<T>(bool condition, string message)
            where T : Exception
        {
            Debug.Assert(string.IsNullOrWhiteSpace(message) == false, "メッセージが必要です");

            if (condition == false)
            {
                throw (Exception)Activator.CreateInstance(typeof(T), message);
            }

            return condition;
        }

        /// <summary>
        /// ロジックの必要条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="condition">条件式</param>
        /// <param name="format">条件を満たさない場合のメッセージを生成するフォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、T型の例外がスローされます。</remarks>
        public static bool Require<T>(bool condition, string format, params object[] args)
            where T : Exception
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列が必要です");

            if (condition == false)
            {
                throw (Exception)Activator.CreateInstance(typeof(T), FormatArguments(format, args));
            }

            return condition;
        }

        /// <summary>
        /// ロジックの必要条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="condition">条件式</param>
        /// <param name="constructorArgs">例外コンストラクタの引数群</param>
        /// <returns>true</returns>
        /// <remarks>条件を満たさない場合、T型の例外がスローされます。</remarks>
        public static bool Require<T>(bool condition, object[] constructorArgs)
            where T : Exception
        {
            Debug.Assert(constructorArgs != null, "例外コンストラクタの引数群が必要です");

            if (condition == false)
            {
                throw (Exception)Activator.CreateInstance(typeof(T), InterpretArguments(constructorArgs));
            }

            return condition;
        }
        #endregion

        #region Condition
        /// <summary>
        /// ロジックのデバッグ条件を記述します。
        /// </summary>
        /// <param name="condition">条件式</param>
        /// <remarks>条件を満たさない場合、InvalidOperationExceptionがスローされます。
        /// このオーバーロードはリリースビルドで削除されます。</remarks>
        [Conditional("DEBUG")]
        public static void Condition(bool condition)
        {
            if (condition == false)
            {
                throw new InvalidOperationException();
            }
        }

        /// <summary>
        /// ロジックのデバッグ条件を記述します。
        /// </summary>
        /// <param name="condition">条件式</param>
        /// <param name="message">条件を満たさない場合のメッセージ文字列</param>
        /// <remarks>条件を満たさない場合、InvalidOperationExceptionがスローされます。
        /// このオーバーロードはリリースビルドで削除されます。</remarks>
        [Conditional("DEBUG")]
        public static void Condition(bool condition, string message)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(message) == false, "メッセージが必要です");

            if (condition == false)
            {
                throw new InvalidOperationException(message);
            }
        }

        /// <summary>
        /// ロジックのデバッグ条件を記述します。
        /// </summary>
        /// <param name="condition">条件式</param>
        /// <param name="format">条件を満たさない場合のメッセージを生成するフォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        /// <remarks>条件を満たさない場合、InvalidOperationExceptionがスローされます。
        /// このオーバーロードはリリースビルドで削除されます。</remarks>
        [Conditional("DEBUG")]
        public static void Condition(bool condition, string format, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列が必要です");

            if (condition == false)
            {
                throw new InvalidOperationException(FormatArguments(format, args));
            }
        }
        #endregion

        #region ConditionT
        /// <summary>
        /// ロジックのデバッグ条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="condition">条件式</param>
        /// <param name="message">条件を満たさない場合のメッセージ文字列</param>
        /// <remarks>条件を満たさない場合、T型の例外がスローされます。
        /// このオーバーロードはリリースビルドで削除されます。</remarks>
        [Conditional("DEBUG")]
        public static void Condition<T>(bool condition, string message)
            where T : Exception
        {
            Debug.Assert(string.IsNullOrWhiteSpace(message) == false, "メッセージが必要です");

            if (condition == false)
            {
                throw (Exception)Activator.CreateInstance(typeof(T), message);
            }
        }

        /// <summary>
        /// ロジックのデバッグ条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="condition">条件式</param>
        /// <param name="format">条件を満たさない場合のメッセージを生成するフォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        /// <remarks>条件を満たさない場合、T型の例外がスローされます。
        /// このオーバーロードはリリースビルドで削除されます。</remarks>
        [Conditional("DEBUG")]
        public static void Condition<T>(bool condition, string format, params object[] args)
            where T : Exception
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列が必要です");

            if (condition == false)
            {
                throw (Exception)Activator.CreateInstance(typeof(T), FormatArguments(format, args));
            }
        }

        /// <summary>
        /// ロジックのデバッグ条件を記述します。
        /// </summary>
        /// <typeparam name="T">例外の型</typeparam>
        /// <param name="condition">条件式</param>
        /// <param name="constructorArgs">例外コンストラクタの引数群</param>
        /// <remarks>条件を満たさない場合、T型の例外がスローされます。</remarks>
        [Conditional("DEBUG")]
        public static void Condition<T>(bool condition, object[] constructorArgs)
            where T : Exception
        {
            Debug.Assert(constructorArgs != null, "例外コンストラクタの引数群が必要です");

            if (condition == false)
            {
                throw (Exception)Activator.CreateInstance(typeof(T), InterpretArguments(constructorArgs));
            }
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.Diagnostics
{
    /// <summary>
    /// メッセージ文字列をフォーマットして取得するためのインターフェイスです。
    /// </summary>
    /// <remarks>フレームワークメッセージフォーマットの依存を分離するためのインターフェイスです。
    /// Fluere処理を起動したモジュールが処理を提供します。</remarks>
    public interface IMessageFormatter
    {
        /// <summary>
        /// 指定されたメッセージIDからメッセージをフォーマットして取得します。
        /// </summary>
        /// <param name="messageID">メッセージID</param>
        /// <param name="args">メッセージのフォーマットに使用する引数群</param>
        /// <returns>フォーマットされた文字列</returns>
        string FormatMessage(string messageID, params object[] args);
    }
}

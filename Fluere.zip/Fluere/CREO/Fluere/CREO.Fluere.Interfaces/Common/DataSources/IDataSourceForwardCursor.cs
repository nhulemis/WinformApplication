﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースで使用する前方参照カーソルインターフェイスです。
    /// </summary>
    /// <remarks>このインターフェイスは内部で使用します。</remarks>
    public interface IDataSourceForwardCursor : IDisposable
    {
        /// <summary>
        /// フィールド名群を取得します
        /// </summary>
        /// <remarks>実際に使用されるフィールド名が返されます。</remarks>
        string[] FieldNames
        {
            get;
        }

        /// <summary>
        /// データを1レコード分読み取ります。
        /// </summary>
        /// <param name="values">読み取ったデータを格納する配列</param>
        /// <returns>読み取った場合はtrue</returns>
        /// <remarks>このメソッドを実装する場合、返却する配列は実際のフィールド数によって、以下のように振る舞う事を想定して下さい。
        /// <para>返却するデータ数が不足する場合は、不足分のプロパティに値がセットされません。</para>
        /// <para>返却するデータ数が過剰の場合は、過剰分が無視されます。</para>
        /// この動作は、IPropertyValueAccessor.SetValuesメソッドの既定の実装によって行われます。</remarks>
        bool Read(out object[] values);
    }
}

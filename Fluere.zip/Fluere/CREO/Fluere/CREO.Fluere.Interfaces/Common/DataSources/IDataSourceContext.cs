﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.19 TMI K.Matsui

using System.Collections.Generic;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースをLINQクエリで使用する場合の基点となる、コンテキストソースインターフェイスです。
    /// </summary>
    /// <remarks>データソースを読み取る場合に、このインターフェイスを通じて列挙子を取得する事が出来ます。
    /// データソースと連携し、何度でも再列挙可能です。</remarks>
    public interface IDataSourceContext : IDataSourceContextBase, IEnumerable<object[]>
    {
        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        void Store(IEnumerable<object[]> enumerable);

        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <remarks>このオーバーロードは、自動的に供給されるフィールド名を使用しません。
        /// フィールド名群は、供給されるデータ群と同数か、それ以上が必要です。</remarks>
        void Store(IEnumerable<object[]> enumerable, params string[] fieldNames);
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.Collections.Generic;

using CREO.Fluere.Biz.Data;
using CREO.Fluere.Common.DataSources.Linq;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースのリポジトリを示すインターフェイスです。
    /// </summary>
    /// <remarks>単一のデータソース内に、複数のターゲットとなるデータが格納されている事を示すインターフェイスです。
    /// 例えば、EXCELデータファイルは、複数のシートで区分けされたデータ群を扱います。</remarks>
    public interface IDataSourceRepository : ITransactionControl
    {
        /// <summary>
        /// リポジトリの場所を示す文字列を取得します。
        /// </summary>
        string Location
        {
            get;
        }

        /// <summary>
        /// リポジトリをオープンします。
        /// </summary>
        void Open();

        /// <summary>
        /// このリポジトリが管理するデータソースのターゲット名を指定して、コンテキストとなるLINQソースを取得します。
        /// </summary>
        /// <typeparam name="T">LINQソースに関連付けるインターフェイス型</typeparam>
        /// <param name="targetName">ターゲット名</param>
        /// <returns>コンテキストとなるLINQソース</returns>
        /// <remarks>このメソッドから得られるLINQソースは、対象のデータを何度でも読み直す事が出来ます。</remarks>
        IDataSourceContext<T> Target<T>(string targetName)
            where T : class;

        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <typeparam name="T">LINQソースに関連付けるインターフェイス型</typeparam>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        /// <param name="targetName">ターゲット名</param>
        /// <remarks>出力フォーマットがT型のインターフェイスで型付けされる場合は、このメソッドを使用する事で、
        /// コンテキストを取得することなく直接レコード群を出力出来ます。</remarks>
        void StoreTo<T>(IEnumerable<T> enumerable, string targetName)
            where T : class;

        /// <summary>
        /// 逐次出力を行うインターフェイスを生成します。
        /// </summary>
        /// <typeparam name="T">関連付けるインターフェイス型</typeparam>
        /// <param name="targetName">ターゲット名</param>
        /// <returns>逐次出力インターフェイス</returns>
        IDataSourceStorer<T> CreateStorer<T>(string targetName)
            where T : class;
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.02.01 TMI K.Matsui

using System;
using System.Collections.Generic;

using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.DataSources.Linq
{
    /// <summary>
    /// 指定されたインターフェイスで逐次出力を行うデータソースの出力インターフェイスです。
    /// </summary>
    /// <typeparam name="T">インターフェイス</typeparam>
    /// <remarks>IDataSourceContext.Storeメソッドの代わりに使用して、プッシュ型出力を可能にします。
    /// 出力を完了するには、Disposeメソッドを呼び出します。</remarks>
    public interface IDataSourceStorer<T> : ISerializerBase, IDisposable
        where T : class
    {
        /// <summary>
        /// このインターフェイスのターゲット名を取得します。
        /// </summary>
        /// <remarks>ターゲット名はnullの可能性があります。</remarks>
        string TargetName
        {
            get;
        }

        /// <summary>
        /// 指定されたデータを出力します。
        /// </summary>
        /// <param name="data">データ</param>
        void Write(T data);

        /// <summary>
        /// 指定されたデータ群を出力します。
        /// </summary>
        /// <param name="datas">データ群</param>
        void Write(IEnumerable<T> datas);
    }
}

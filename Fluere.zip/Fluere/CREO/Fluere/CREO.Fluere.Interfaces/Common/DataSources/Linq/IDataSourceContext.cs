﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.Collections.Generic;

using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.DataSources.Linq
{
    /// <summary>
    /// データソースをLINQクエリで使用する場合の基点となる、ジェネリックなコンテキストソースインターフェイスです。
    /// </summary>
    /// <typeparam name="T">データソースのレコード型を示すインターフェイス型</typeparam>
    /// <remarks>データソースを読み取る場合に、このインターフェイスを通じて列挙子を取得する事が出来ます。
    /// データソースと連携し、何度でも再列挙可能です。
    /// このインターフェイスは、データソースのレコード型をT型として指定する事が出来ます。
    /// 結果として、このコンテキストインターフェイスに対してLINQクエリを記述する事が可能です。</remarks>
    public interface IDataSourceContext<T> : IDataSourceContextBase, ISerializerBase, IEnumerable<T>
        where T : class
    {
        /// <summary>
        /// 不正な値を検出した場合に呼び出されるイベントです。
        /// </summary>
        /// <remarks>データから値を取得する際に、型変換しようとして発生する例外を検出出来ます。
        /// このイベントの処理内で、値を修正するか、別の例外をスローして下さい。
        /// 値を修正せず、かつ例外をスローしないで処理を返した場合、提示されている例外が再スローされます。</remarks>
        event InvalidDataValueEventHandler InvalidDataValue;

        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        void Store(IEnumerable<T> enumerable);

        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <remarks>このオーバーロードは、自動的に供給されるフィールド名を使用しません。
        /// フィールド名群は、供給されるデータ群と同数か、それ以上が必要です。</remarks>
        void Store(IEnumerable<T> enumerable, params string[] fieldNames);
    }
}

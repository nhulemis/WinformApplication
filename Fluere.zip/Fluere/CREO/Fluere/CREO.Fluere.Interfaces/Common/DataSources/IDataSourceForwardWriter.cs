﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースで使用する前方方向ライタインターフェイスです。
    /// </summary>
    /// <remarks>このインターフェイスは内部で使用します。</remarks>
    public interface IDataSourceForwardWriter : IDisposable
    {
        /// <summary>
        /// データをフラッシュします。
        /// </summary>
        void Flush();

        /// <summary>
        /// 指定された値群を出力します。
        /// </summary>
        /// <param name="values">値群</param>
        void Write(IList<object> values);
    }
}

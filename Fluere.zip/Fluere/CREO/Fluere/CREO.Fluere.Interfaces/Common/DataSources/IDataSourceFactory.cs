﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.21 TMI K.Matsui

using System.Globalization;
using System.Text;

using CREO.Fluere.Common.DataSources.Text;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースファクトリインターフェイスです。
    /// </summary>
    /// <remarks>ファクトリのインスタンスが管理するリソースから、各種データソースのリポジトリを生成します。</remarks>
    public interface IDataSourceFactory
    {
        /// <summary>
        /// 指定されたパスが示すフォルダ内のテキストファイルに対して入出力を行うリポジトリを生成します。
        /// </summary>
        /// <param name="path">対象のフォルダ又はファイルパス</param>
        /// <param name="encoding">変換に使用するエンコーディング</param>
        /// <param name="cultureInfo">変換に使用するカルチャ情報</param>
        /// <param name="separator">想定するセパレータ文字</param>
        /// <param name="format">テキストデータソースのフォーマット</param>
        /// <param name="bufferSize">バッファサイズ</param>
        /// <returns>リポジトリのインスタンス</returns>
        /// <remarks>フォルダを指定した場合は、コンテキスト取得時にファイルへの相対パス又は絶対パスを指定出来ます。
        /// ファイルを指定した場合は、コンテキスト取得時にファイルへのパスを省略する事が出来ます。</remarks>
        IDataSourceRepository CreateTextDataRepository(
            string path,
            Encoding encoding,
            CultureInfo cultureInfo,
            char separator,
            TextDataFormat format,
            int bufferSize);

        /// <summary>
        /// 指定されたパスが示すフォルダ内のToDoファイルに対して入出力を行うリポジトリを生成します。
        /// </summary>
        /// <param name="path">対象のフォルダ又はファイルパス</param>
        /// <param name="cultureInfo">変換に使用するカルチャ情報</param>
        /// <param name="bufferSize">バッファサイズ</param>
        /// <returns>リポジトリのインスタンス</returns>
        /// <remarks>フォルダを指定した場合は、コンテキスト取得時にファイルへの相対パス又は絶対パスを指定出来ます。
        /// ファイルを指定した場合は、コンテキスト取得時にファイルへのパスを省略する事が出来ます。</remarks>
        IDataSourceRepository CreateToDoDataRepository(
            string path,
            CultureInfo cultureInfo,
            int bufferSize);

        /// <summary>
        /// 指定されたパスが示すOpenXMLスプレッドシートファイルに対して入出力を行うリポジトリを生成します。
        /// </summary>
        /// <param name="filePath">対象のファイルのパス</param>
        /// <param name="cultureInfo">変換に使用するカルチャ情報</param>
        /// <param name="interpretHeader">先頭行をヘッダとして解釈する場合はtrue</param>
        /// <param name="createNotExist">ファイルが存在しない場合に生成する場合はtrue</param>
        /// <returns>リポジトリのインスタンス</returns>
        IDataSourceRepository CreateSpreadSheetDataRepository(
            string filePath,
            CultureInfo cultureInfo,
            bool interpretHeader,
            bool createNotExist);
    }
}

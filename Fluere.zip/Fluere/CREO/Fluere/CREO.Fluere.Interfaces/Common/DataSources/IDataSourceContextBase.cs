﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.11 TMI K.Matsui

using System;
using System.Collections;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースのコンテキストソース基底インターフェイスです。
    /// </summary>
    public interface IDataSourceContextBase : IEnumerable
    {
        /// <summary>
        /// このコンテキストのターゲット名を取得します。
        /// </summary>
        /// <remarks>ターゲット名はnullの可能性があります。</remarks>
        string TargetName
        {
            get;
        }

        /// <summary>
        /// このコンテキストが変換の対象とするインターフェイス型を取得します。
        /// </summary>
        Type TargetType
        {
            get;
        }

        /// <summary>
        /// コンテキストから取得可能なフィールド情報群を取得します。
        /// </summary>
        /// <remarks>データソースが提供するフィールド情報群を取得する事が出来ます。
        /// フィールド情報の取得にデータの読み取り操作が必要な場合は、
        /// このプロパティを参照する事でデータの読み取り処理が発生する場合があります。
        /// また、実際に列挙されるデータの個数と必ずしも一致しない可能性があります。</remarks>
        ITargetFieldInformation[] FieldInformations
        {
            get;
        }

        #region Obsoletes
        /// <summary>
        /// このプロパティは非推奨です。代わりにFieldInformationsを使用します。
        /// </summary>
        string[] FieldNames
        {
            get;
        }
        #endregion
    }
}

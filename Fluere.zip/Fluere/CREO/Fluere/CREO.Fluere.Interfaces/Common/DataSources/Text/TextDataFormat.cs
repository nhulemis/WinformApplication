﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.DataSources.Text
{
    /// <summary>
    /// テキストデータソースのフォーマットを示す列挙値です。
    /// </summary>
    [Flags]
    public enum TextDataFormat
    {
        /// <summary>
        /// 何も指定しません。
        /// </summary>
        None = 0x0000,

        /// <summary>
        /// フィールドがダブルクオートで囲まれている事を示します。
        /// </summary>
        Quoted = 0x0001,

        /// <summary>
        /// データソースにヘッダが存在する事を示します。
        /// </summary>
        WithHeaders = 0x0002,

        /// <summary>
        /// 空文字列をヌルと解釈します。
        /// </summary>
        StringEmptyIsNull = 0x0004,

        /// <summary>
        /// ヌルをDBNullに相互変換します。
        /// </summary>
        [Obsolete("このフラグは廃止されます。DBNullはNullable<T>型を使用して明示的に型指定して下さい")]
        NullIsDBNull = 0x2000,
    }
}

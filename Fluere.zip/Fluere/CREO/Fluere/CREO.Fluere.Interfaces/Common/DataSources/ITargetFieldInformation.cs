﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.30 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースのフィールド情報を示すインターフェイスです。
    /// </summary>
    /// <remarks>データソースが提供する、各フィールドの情報を示します。
    /// 実際の入出力の際には、異なる情報が使われる場合があります。</remarks>
    public interface ITargetFieldInformation
    {
        /// <summary>
        /// フィールド名を取得します。
        /// </summary>
        /// <remarks>フィールド名として使用すべき（インターフェイス定義にて明示的に指定された場合は、その名前を優先する）
        /// フィールド名を取得します。</remarks>
        string FieldName
        {
            get;
        }

        /// <summary>
        /// 生のフィールド名を取得します。
        /// </summary>
        /// <remarks>メタデータに指定された、元々のフィールド名を取得します。
        /// コードのロジック判定に使用する場合は、このプロパティを使用します。</remarks>
        string RawFieldName
        {
            get;
        }

        /// <summary>
        /// フィールドの型を取得します。
        /// </summary>
        /// <remarks>メタデータに指定された、フィールドを示す型を取得します。
        /// データソースから読み取ったデータは、この型そのものか、或いは継承・実装した型となります。</remarks>
        Type FieldType
        {
            get;
        }

        /// <summary>
        /// 指定された型の属性が定義されているかどうかを取得します。
        /// </summary>
        /// <typeparam name="T">属性クラスの型</typeparam>
        /// <returns>定義されていればtrue</returns>
        /// <remarks>メタデータに指定された、属性クラスを確認します。</remarks>
        bool IsDefined<T>()
            where T : Attribute;

        /// <summary>
        /// 指定された型の属性を取得します。
        /// </summary>
        /// <typeparam name="T">属性クラスの型</typeparam>
        /// <returns>定義されている属性クラス群</returns>
        /// <remarks>メタデータに指定された、属性クラスを確認します。</remarks>
        T[] GetCustomAttributes<T>()
            where T : Attribute;
    }
}

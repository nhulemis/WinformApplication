﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// プロパティに対応するフィールド名を指定する属性クラスです。
    /// </summary>
    /// <remarks>データソースで入出力を行うインターフェイス定義のプロパティに、別名を設定する事が出来ます。</remarks>
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public sealed class FieldNameAttribute : NodeNameAttributeBase
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="fieldName">別名とするフィールド名</param>
        public FieldNameAttribute(string fieldName)
            : base(fieldName)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(fieldName) == false, "フィールド名が必要です");
        }
    }
}

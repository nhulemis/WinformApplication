﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoリストのフォーマット識別子を指定する属性クラスです。
    /// </summary>
    /// <remarks>インターフェイスにフォーマット識別子を適用しない場合は、DataFieldAttributeを適用します。</remarks>
    [AttributeUsage(AttributeTargets.Interface)]
    public sealed class ToDoFormatIdentityAttribute : Attribute
    {
        #region Fields
        /// <summary>
        /// ToDoリストのフォーマット識別子です。
        /// </summary>
        private readonly string _formatIdentity;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="formatIdentity">フォーマット識別子</param>
        public ToDoFormatIdentityAttribute(string formatIdentity)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(formatIdentity) == false,
                "ToDoリストフォーマット識別子が必要です");

            this._formatIdentity = formatIdentity;
        }
        #endregion

        #region FormatIdentity
        /// <summary>
        /// フォーマット識別子を取得します。
        /// </summary>
        public string FormatIdentity
        {
            get
            {
                return this._formatIdentity;
            }
        }
        #endregion
    }
}

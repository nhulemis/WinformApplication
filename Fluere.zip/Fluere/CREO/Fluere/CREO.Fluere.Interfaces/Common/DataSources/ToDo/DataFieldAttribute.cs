﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.ComponentModel;

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoリストのデータフィールドの属性を指定する属性クラスです。
    /// </summary>
    /// <remarks>ToDoFormatIdentityAttributeを適用しない場合に指定します。
    /// フィールド名はFieldNameAttributeを使用して設定します。
    /// タイトルのみの場合、DescriptionAttributeを使用する事も出来ます。</remarks>
    [AttributeUsage(AttributeTargets.Property)]
    public sealed class DataFieldAttribute : DescriptionAttribute
    {
        #region Fields
        /// <summary>
        /// 読み取り専用かどうか
        /// </summary>
        private readonly bool _isReadOnly;

        /// <summary>
        /// 可視とするかどうか
        /// </summary>
        private readonly bool _isVisible;

        /// <summary>
        /// 固定とするかどうか
        /// </summary>
        private readonly bool _isFixedColumn;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <remarks>タイトルをプロパティ名・読み取り専用・可視状態のフィールドとして初期化します。これは既定の動作です。</remarks>
        public DataFieldAttribute()
            : base(string.Empty)
        {
            this._isReadOnly = true;
            this._isVisible = true;
            this._isFixedColumn = true;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="isReadOnly">読み取り専用の場合はtrue（ReadOnly）</param>
        /// <param name="isVisible">可視とする場合はtrue（Visibility）</param>
        /// <param name="isFixedColumn">固定とする場合はtrue（FixedColumnFlag）</param>
        /// <remarks>タイトルをプロパティ名として初期化します。</remarks>
        public DataFieldAttribute(bool isReadOnly, bool isVisible, bool isFixedColumn)
            : base(string.Empty)
        {
            this._isReadOnly = isReadOnly;
            this._isVisible = isVisible;
            this._isFixedColumn = isFixedColumn;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="description">タイトル（TitleName）</param>
        /// <remarks>読み取り専用・可視状態のフィールドとして初期化します。
        /// DescriptionAttributeを使用する事も出来ます。</remarks>
        public DataFieldAttribute(string description)
            : base(description)
        {
            this._isReadOnly = true;
            this._isVisible = true;
            this._isFixedColumn = true;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="description">タイトル（TitleName）</param>
        /// <param name="isReadOnly">読み取り専用の場合はtrue（ReadOnly）</param>
        /// <param name="isVisible">可視とする場合はtrue（Visibility）</param>
        /// <param name="isFixedColumn">固定とする場合はtrue（FixedColumnFlag）</param>
        public DataFieldAttribute(string description, bool isReadOnly, bool isVisible, bool isFixedColumn)
            : base(description)
        {
            this._isReadOnly = isReadOnly;
            this._isVisible = isVisible;
            this._isFixedColumn = isFixedColumn;
        }
        #endregion

        #region IsReadOnly
        /// <summary>
        /// 読み取り専用かどうかを取得します。
        /// </summary>
        public bool IsReadOnly
        {
            get
            {
                return this._isReadOnly;
            }
        }
        #endregion

        #region IsVisible
        /// <summary>
        /// 可視とするかどうかを取得します。
        /// </summary>
        public bool IsVisible
        {
            get
            {
                return this._isVisible;
            }
        }
        #endregion

        #region IsFixedColumn
        /// <summary>
        /// 可視とするかどうかを取得します。
        /// </summary>
        public bool IsFixedColumn
        {
            get
            {
                return this._isFixedColumn;
            }
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2013 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013/02/28 17:12:37 MAPMASTER matsuiko

using System.ComponentModel;
using System.Globalization;
using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoリストフォーマットの基底のインターフェイスです。
    /// </summary>
    /// <remarks>ToDoリストフォーマットの固定フィールド定義を含みます。
    /// このインターフェイスを継承して、独自のToDoリストフォーマットインターフェイスを定義出来ます。</remarks>
    public interface IToDoFixedFields
    {
        /// <summary>
        /// 確認
        /// </summary>
        [Description("確認")]
        int? WorkStatus
        {
            get;
            set;
        }

        /// <summary>
        /// 調査対象ID
        /// </summary>
        [FieldName("SurveyObjectId")]
        [Description("調査対象ID")]
        ulong? SurveyObjectID
        {
            get;
            set;
        }

        /// <summary>
        /// 経度
        /// </summary>
        [Description("経度")]
        long? Longitude
        {
            get;
            set;
        }

        /// <summary>
        /// 緯度
        /// </summary>
        [Description("緯度")]
        long? Latitude
        {
            get;
            set;
        }

        /// <summary>
        /// 検索対象DB
        /// </summary>
        [Description("検索対象DB")]
        string QueryObjectDB
        {
            get;
            set;
        }

        /// <summary>
        /// OID
        /// </summary>
//        [NumericalString("X16", NumberStyles.AllowHexSpecifier)]
        ulong? OID
        {
            get;
            set;
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.29 TMI K.Matsui

using System;
using System.ComponentModel;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスの定義を示すインターフェイスです。
    /// </summary>
    /// <remarks>データサービスIDは、データベースロールID又はデータソースIDです。
    /// このインターフェイスを使用して、どちらのIDも同じように一元管理する事が可能です。</remarks>
    public interface IDataServiceDefinition
    {
        /// <summary>
        /// データサービスIDを取得します。
        /// </summary>
        string DataServiceID
        {
            get;
        }

        /// <summary>
        /// データソースIDを取得します。
        /// </summary>
        /// <remarks>通常、DataServiceIDプロパティを使用します。</remarks>
        string RawDataSourceID
        {
            get;
        }

        /// <summary>
        /// データサービスIDタイプを取得します。
        /// </summary>
        DataServiceIDTypes IDType
        {
            get;
        }

        /// <summary>
        /// キャプションを取得します。
        /// </summary>
        string Caption
        {
            get;
        }

        /// <summary>
        /// コメントを取得します。
        /// </summary>
        string Comment
        {
            get;
        }

        /// <summary>
        /// データサービスに対応するプロバイダの型を取得します。
        /// </summary>
        Type ProviderType
        {
            get;
        }

        /// <summary>
        /// DataSourceInfoを取得します。
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        CREO.DS.DataSource.DataSourceInfo RawDataSourceInfo
        {
            get;
        }
    }
}

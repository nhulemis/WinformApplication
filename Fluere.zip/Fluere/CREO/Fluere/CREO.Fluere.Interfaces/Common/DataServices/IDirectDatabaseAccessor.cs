﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.01 TMI K.Matsui

using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データベースへのダイレクトアクセスを実行するインターフェイスです。
    /// </summary>
    public interface IDirectDatabaseAccessor
    {
        /// <summary>
        /// トランザクションを開始します。
        /// </summary>
        /// <param name="isolationLevel">分離レベル</param>
        /// <returns>トランザクションを示す新しいコンテキスト</returns>
        IDirectDatabaseTransactionContext BeginTransaction(
            IsolationLevel isolationLevel = IsolationLevel.ReadCommitted);

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <returns>パラメータオブジェクト</returns>
        IDbDataParameter Parameter(string name);

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <param name="value">パラメータ値</param>
        /// <returns>パラメータオブジェクト</returns>
        IDbDataParameter Parameter(string name, object value);

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <param name="type">パラメータのタイプ</param>
        /// <returns>パラメータオブジェクト</returns>
        IDbDataParameter Parameter(string name, DbType type);

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <param name="type">パラメータのタイプ</param>
        /// <param name="value">パラメータ値</param>
        /// <returns>パラメータオブジェクト</returns>
        IDbDataParameter Parameter(string name, DbType type, object value);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>影響レコード数</returns>
        int ExecuteNonQuery(string queryString, IEnumerable<IDbDataParameter> parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>影響レコード数</returns>
        int ExecuteNonQuery(string queryString, params IDbDataParameter[] parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果</returns>
        object ExecuteScalar(string queryString, IEnumerable<IDbDataParameter> parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果</returns>
        object ExecuteScalar(string queryString, params IDbDataParameter[] parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果レコード群</returns>
        IDataReader ExecuteReader(string queryString, IEnumerable<IDbDataParameter> parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果レコード群</returns>
        IDataReader ExecuteReader(string queryString, params IDbDataParameter[] parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果を格納する新しいデータテーブル</returns>
        DataTable ExecuteToDataTable(string queryString, IEnumerable<IDbDataParameter> parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果を格納する新しいデータテーブル</returns>
        DataTable ExecuteToDataTable(string queryString, params IDbDataParameter[] parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataTable">結果を格納するデータテーブル</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        void ExecuteAndStore(DataTable dataTable, string queryString, IEnumerable<IDbDataParameter> parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataTable">結果を格納するデータテーブル</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        void ExecuteAndStore(DataTable dataTable, string queryString, params IDbDataParameter[] parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataSet">結果を格納するデータセット</param>
        /// <param name="targetTableName">データテーブルを特定するデータセット内のテーブル名</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        void ExecuteAndStore(DataSet dataSet, string targetTableName, string queryString, IEnumerable<IDbDataParameter> parameters);

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataSet">結果を格納するデータセット</param>
        /// <param name="targetTableName">データテーブルを特定するデータセット内のテーブル名</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        void ExecuteAndStore(DataSet dataSet, string targetTableName, string queryString, params IDbDataParameter[] parameters);

        /// <summary>
        /// バルクコピーを実行します。
        /// </summary>
        /// <param name="targetTableName">ストア先のテーブル名</param>
        /// <param name="reader">データを供給するリーダ</param>
        /// <param name="batchSize">バッチレコードサイズ</param>
        /// <param name="options">オプション</param>
        /// <param name="iterationHandler">コピー中に生じる経過イベントのコールバック</param>
        /// <remarks>バルクコピーを実行する場合、プロバイダがSQL Serverに対して構成されていなければなりません。</remarks>
        void ExecuteBulkCopy(
            string targetTableName,
            IDataReader reader,
            int batchSize = 50000,
            SqlBulkCopyOptions options = SqlBulkCopyOptions.Default,
            SqlRowsCopiedEventHandler iterationHandler = null);
    }
}

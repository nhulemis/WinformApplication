﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.21 TMI K.Matsui

using System.Collections.Generic;
using System.ComponentModel;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスの情報を取得するインターフェイスです。
    /// </summary>
    /// <remarks>データソースとデータベースロールの対応を自動的に行い、その情報を取得可能にします。</remarks>
    public interface IDataServiceDefinitionAccessor
    {
        /// <summary>
        /// 指定されたデータサービスIDからデータソースIDを取得します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <returns>データソースID</returns>
        /// <remarks>通常、このメソッドは使用しません。
        /// データサービスの情報が必要な場合はGetDataServiceDefinitionsを使用します。
        /// また、データサービスへの接続はこのメソッドを使用せず、直接データサービスIDを使用します。</remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        string GetDataSourceIDFromDataServiceID(
            string dataServiceID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID);

        /// <summary>
        /// 設定ファイルに定義されているデータサービスに対応する情報群を取得します。
        /// </summary>
        /// <param name="extractTypes">抽出条件</param>
        /// <returns>データサービス情報の列挙子</returns>
        /// <remarks>引数の指定によって、フレームワークが管理するデータソースの一覧、
        /// 又はアプリケーション構成ファイルで指定されるデータベースロールの一覧、
        /// 又はその両方を取得する事が出来ます。</remarks>
        IEnumerable<IDataServiceDefinition> GetDataServiceDefinitions(
            DataServiceIDExtractTypes extractTypes = DataServiceIDExtractTypes.DatabaseRoleID);
    }
}

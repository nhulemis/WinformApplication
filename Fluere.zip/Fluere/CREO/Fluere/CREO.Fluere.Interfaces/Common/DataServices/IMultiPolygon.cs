﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System.Collections.Generic;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするインターフェイスです。
    /// </summary>
    /// <remarks>SqlGeometryクラスの操作を分離し、マルチポリゴン・ポリゴン・リング・ポイントを
    /// 階層化されたインターフェイスで表現可能にし、不必要な表現変換を不要にします。
    /// また、列挙子を提供し、LINQクエリの記述を可能にします。</remarks>
    public interface IMultiPolygon : IGeometry, IEnumerable<IPolygon>
    {
        /// <summary>
        /// 内包するポリゴン数を取得します。
        /// </summary>
        int Count
        {
            get;
        }

        /// <summary>
        /// インデックスを指定して、ポリゴンを取得します。
        /// </summary>
        /// <param name="index">インデックス</param>
        /// <returns>ポリゴン</returns>
        IPolygon this[int index]
        {
            get;
        }

        /// <summary>
        /// マルチポリゴンをCoordinateの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        /// <remarks>返却する列挙子は、リングを表現出来ません。
        /// そのため、内包するポリゴンに複数のリングが含まれている場合、例外がスローされます。</remarks>
        IEnumerable<IEnumerable<CREO.FW.TMIGeometry.Coordinate>> ToCoordinatesCollection();

        /// <summary>
        /// マルチポリゴンをCoordinateDの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        /// <remarks>返却する列挙子は、リングを表現出来ません。
        /// そのため、内包するポリゴンに複数のリングが含まれている場合、例外がスローされます。</remarks>
        IEnumerable<IEnumerable<CREO.FW.TMIGeometry.CoordinateD>> ToCoordinateDsCollection();

        /// <summary>
        /// マルチポリゴンをCompositePolygonの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        IEnumerable<CREO.FW.TMIGeometry.CompositePolygon> ToCompositePolygonCollection();
    }
}

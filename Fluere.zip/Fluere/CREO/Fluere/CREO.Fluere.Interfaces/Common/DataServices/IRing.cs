﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System.Collections.Generic;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするインターフェイスです。
    /// </summary>
    /// <remarks>ポリゴン内の個々のリングを保持します。
    /// 列挙子を提供し、LINQクエリの記述を可能にします。</remarks>
    public interface IRing : IGeometry, IEnumerable<IPoint>
    {
        /// <summary>
        /// 内包するポイント数を取得します。
        /// </summary>
        int Count
        {
            get;
        }

        /// <summary>
        /// リング長を取得します。
        /// </summary>
        double RingLength
        {
            get;
        }

        /// <summary>
        /// このインスタンスが閉形状かどうかを取得します。
        /// </summary>
        /// <remarks>trueの場合は閉形状です。falseの場合はポリライン・マルチポイント・ポイント・空インスタンスの可能性があります。</remarks>
        bool IsClosed
        {
            get;
        }

        /// <summary>
        /// インデックスを指定して、ポイントを取得します。
        /// </summary>
        /// <param name="index">インデックス</param>
        /// <returns>ポイント</returns>
        IPoint this[int index]
        {
            get;
        }

        /// <summary>
        /// 先端位置を取得します。
        /// </summary>
        /// <returns>先端位置</returns>
        IPoint StartPoint();

        /// <summary>
        /// 終端位置を取得します。
        /// </summary>
        /// <returns>終端位置</returns>
        IPoint EndPoint();

        /// <summary>
        /// Coordinateの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        IEnumerable<CREO.FW.TMIGeometry.Coordinate> ToCoordinateCollection();

        /// <summary>
        /// CoordinateDの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        IEnumerable<CREO.FW.TMIGeometry.CoordinateD> ToCoordinateDCollection();

        /// <summary>
        /// CoordinateRectに変換します。
        /// </summary>
        /// <returns>CoordinateRect</returns>
        /// <remarks>返却するCoordinateRectは、四角形でないポリゴンを表現出来ません。
        /// そのため、これらのポリゴンが含まれている場合、例外がスローされます。</remarks>
        CREO.FW.TMIGeometry.CoordinateRect ToCoordinateRect();
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.26 TMI K.Matsui

using System;
using System.Collections.Generic;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスのファサードインターフェイスです。
    /// </summary>
    /// <remarks>事前バインドされたデータサービスの生存期間を制御するため、
    /// このインターフェイスでラップし、Disposeメソッドの呼び出しをトラップします。</remarks>
    public interface IPreBoundDataService : IDisposable
    {
        //DataServiceのuseCacheが廃止された為、このパラメータも削除する
        /////// <summary>
        /////// キャッシュを使用するかどうかを取得します。
        /////// </summary>
        ////bool UseCache
        ////{
        ////    get;
        ////}

        /// <summary>
        /// 条件を指定してGeoItemの配列を取得する
        /// </summary>
        /// <param name="cond">取得条件</param>
        /// <param name="ignoreCache">ローカルキャッシュを無視する</param>
        /// <para>有効範囲：無視：true；ディフォルト：false </para>
        /// <returns>(List&lt;CREO.DataModel.GeoItem&gt;)GeoItemの配列</returns>
        IList<CREO.DataModel.GeoItem> QueryItems(CREO.DS.QueryItemsCondition cond, bool ignoreCache = false);

        /// <summary>
        /// 条件を指定してGeoItemの統計処理を行う
        /// </summary>
        /// <param name="cond">取得条件</param>
        /// <param name="consumers">自行提供なGeoItem操作クラス</param>
        void ProcessItems(CREO.DS.QueryItemsCondition cond, List<CREO.DS.IDataConsumer> consumers);

        // 改善追加開始 2014/02/17
        /// <summary>
        /// DataServiceのキャッシュ中のデータをすべて破棄する
        /// </summary>
        void ClearCache();
        // 改善追加終了 2014/02/17
    }
}

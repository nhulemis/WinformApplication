﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Xml;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// ジオメトリのタイプを示す列挙値です。
    /// </summary>
    public enum GeometryTypes
    {
        /// <summary>
        /// 空です。
        /// </summary>
        Empty,

        /// <summary>
        /// 点座標です。
        /// </summary>
        Point,

        /// <summary>
        /// 線です（開ポリゴン）。
        /// </summary>
        LineString,

        /// <summary>
        /// ポリゴンです（閉ポリゴン）。
        /// </summary>
        /// <remarks>リング形状を含みます。</remarks>
        Polygon,

        /// <summary>
        /// 複数の線です。
        /// </summary>
        MultiLineString,

        /// <summary>
        /// 複数のポリゴンです。
        /// </summary>
        MultiPolygon,

        /// <summary>
        /// 複数のタイプが混在しています。
        /// </summary>
        Complex
    }

    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするインターフェイスです。
    /// </summary>
    public interface IGeometry : IEquatable<IGeometry>
    {
        /// <summary>
        /// 生のインスタンスを取得します。
        /// </summary>
        /// <remarks>通常、このプロパティを使用する事はありません。</remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        object RawInstance
        {
            get;
        }

        /// <summary>
        /// インスタンスのタイプを取得します。
        /// </summary>
        GeometryTypes GeometryType
        {
            get;
        }

        /// <summary>
        /// インスタンスが空かどうかを取得します。
        /// </summary>
        bool IsEmpty
        {
            get;
        }

        /// <summary>
        /// インスタンスが正規化されているかどうかを取得します。
        /// </summary>
        bool IsValid
        {
            get;
        }

        /// <summary>
        /// Geography Markup Languageを取得します。
        /// </summary>
        /// <returns>XmlReader</returns>
        XmlReader GetGML();

        /// <summary>
        /// 同じ内容を示すマルチポリゴンインスタンスに変換します。
        /// </summary>
        /// <returns>マルチポリゴン</returns>
        IMultiPolygon ToMultiPolygon();

        /// <summary>
        /// 形状を正規化した結果を取得します。
        /// </summary>
        /// <returns>形状</returns>
        /// <remarks>演算結果が不正な形状を示す場合に、形状を変形させて正規化します。
        /// 例えば、同じ線を共有する2つのポリゴンは、線が取り除かれ、単一のポリゴンに修正されます。
        /// このインターフェイスに定義される様々な演算子は、常に結果が不正となる可能性がある事に注意して下さい。</remarks>
        IMultiPolygon MakeValid();

        /// <summary>
        /// 境界を表す形状を取得します。
        /// </summary>
        /// <returns>形状</returns>
        IRing Boundary();

        /// <summary>
        /// 拡張または縮退した形状を取得する演算子です。
        /// </summary>
        /// <param name="tolerance">拡張または縮退する距離</param>
        /// <returns>形状</returns>
        IMultiPolygon Buffer(double tolerance);

        /// <summary>
        /// 重心座標を取得します。
        /// </summary>
        /// <returns>重心を示す座標</returns>
        IPoint Centroid();

        /// <summary>
        /// 指定された形状が、現在の形状に完全に含まれているかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>部分的に含まれていればtrue</returns>
        /// <remarks>Withinは逆演算子です。Touchesが成立する形状との演算ではfalseを返します。</remarks>
        bool Contains(IGeometry rhs);

        /// <summary>
        /// 凸包を表す形状を取得する演算子です。
        /// </summary>
        /// <returns>形状</returns>
        IMultiPolygon ConvexHull();

        /// <summary>
        /// 指定された形状が交差するかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>交差していればtrue</returns>
        /// <remarks>CrossesはIntersectsよりも狭範囲です。
        /// 形状同士が、隣り合う次元（線と面など）で交差する場合にtrueとなります。</remarks>
        bool Crosses(IGeometry rhs);

        /// <summary>
        /// 指定されたポリゴンとの差集合形状を返す演算子です。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>差集合形状</returns>
        /// <remarks>ポリゴンの除外演算を行います。</remarks>
        IMultiPolygon Difference(IGeometry rhs);

        /// <summary>
        /// 指定された形状が連結していないかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>連結していなればtrue</returns>
        /// <remarks>Intersectsは逆演算子です。
        /// Disjointは効率的ではない可能性があります。その場合は、Intersectsを使用して下さい。</remarks>
        bool Disjoint(IGeometry rhs);

        /// <summary>
        /// 指定された形状との最短距離を取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>最短距離</returns>
        double Distance(IGeometry rhs);

        /// <summary>
        /// 最小軸に沿って外接する四角形を返す演算子です。
        /// </summary>
        /// <returns>四角形を示すポリゴン</returns>
        IRing Envelope();

        /// <summary>
        /// 指定された形状との積集合形状を返す演算子です。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>積集合形状</returns>
        IMultiPolygon Intersection(IGeometry rhs);

        /// <summary>
        /// 指定された形状が交差するかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>交差していればtrue</returns>
        /// <remarks>Disjointは逆演算子です。</remarks>
        bool Intersects(IGeometry rhs);

        /// <summary>
        /// 指定された形状が部分的に重なるかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>部分的に重なっていればtrue</returns>
        /// <remarks>完全に重なっている、又は完全に含まれる場合は、falseを返します。</remarks>
        bool Overlaps(IGeometry rhs);

        /// <summary>
        /// 指定された形状を簡略化する演算子です。
        /// </summary>
        /// <param name="tolerance">Douglas-Peucker アルゴリズムへの入力の許容範囲</param>
        /// <returns>簡略化形状</returns>
        IMultiPolygon Reduce(double tolerance);

        /// <summary>
        /// 指定した値で移動した形状を取得する演算子です。
        /// </summary>
        /// <param name="xOffset">x座標方向の移動量</param>
        /// <param name="yOffset">y座標方向の移動量</param>
        /// <returns>移動した形状</returns>
        /// <remarks>大量の計算を行う場合は、TransformByを使用して下さい。</remarks>
        IMultiPolygon Slide(double xOffset, double yOffset);

        /// <summary>
        /// 指定された形状のいずれかが接しているかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>接していればtrue</returns>
        /// <remarks>ポリゴンのポイントが一部で共有され、積集合が存在しない場合にtrueとなります。</remarks>
        bool Touches(IGeometry rhs);

        /// <summary>
        /// 指定したアフィン変換演算子を適用する演算子です。
        /// </summary>
        /// <param name="matrix">アフィン変換演算子を示す行列</param>
        /// <returns>形状</returns>
        IMultiPolygon TransformBy(System.Windows.Media.Matrix matrix);

        /// <summary>
        /// 指定された形状との和集合形状を返す演算子です。
        /// </summary>
        /// <typeparam name="T">引数の型</typeparam>
        /// <param name="rhss">結合する形状群</param>
        /// <returns>和集合形状</returns>
        IMultiPolygon Union<T>(params T[] rhss)
            where T : IGeometry;

        /// <summary>
        /// 指定された形状との和集合形状を返す演算子です。
        /// </summary>
        /// <typeparam name="T">引数の型</typeparam>
        /// <param name="rhss">結合する形状群</param>
        /// <returns>和集合形状</returns>
        IMultiPolygon Union<T>(IEnumerable<T> rhss)
            where T : IGeometry;

        /// <summary>
        /// 現在の形状が、指定された形状に完全に含まれているかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>完全に含まれていればtrue</returns>
        /// <remarks>Containsは逆演算子です。Touchesが成立する形状との演算ではfalseを返します。</remarks>
        bool Within(IGeometry rhs);
    }
}

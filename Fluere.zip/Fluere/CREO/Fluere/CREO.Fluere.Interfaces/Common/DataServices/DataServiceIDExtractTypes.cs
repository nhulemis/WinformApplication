﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.30 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスIDの抽出条件を指定する列挙値です。
    /// </summary>
    [Flags]
    public enum DataServiceIDExtractTypes
    {
        /// <summary>
        /// データソースIDを抽出します。
        /// </summary>
        DataSourceID = 0x01,

        /// <summary>
        /// データベースロールIDを抽出します。
        /// </summary>
        DatabaseRoleID = 0x02,

        /// <summary>
        /// 全てのIDを抽出します。
        /// </summary>
        All = 0x03
    }
}

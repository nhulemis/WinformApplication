﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.26 TMI K.Matsui

using System;
using System.Collections.Generic;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// 事前にバインドされているデータサービスファクトリインターフェイスです。
    /// </summary>
    public interface IPreBoundDataServiceFactory : IDisposable
    {
        /// <summary>
        /// 事前バインドを識別するGUIDです。
        /// </summary>
        /// <remarks>この値はデバッグに使用します。</remarks>
        Guid BoundID
        {
            get;
        }

        /// <summary>
        /// バインドされたデータサービスIDを取得します。
        /// </summary>
        string DataServiceID
        {
            get;
        }

        /// <summary>
        /// バインドされたデータソースIDを取得します。
        /// </summary>
        /// <remarks>通常、DataServiceIDプロパティを使用します。</remarks>
        string RawDataSourceID
        {
            get;
        }

        /// <summary>
        /// バインドされたワークグループIDを取得します。
        /// </summary>
        ulong WorkGroupID
        {
            get;
        }

        /// <summary>
        /// バインドされたサブワークグループIDを取得します。
        /// </summary>
        ulong SubWorkGroupID
        {
            get;
        }

        /// <summary>
        /// 生成されたデータサービス数を取得します。
        /// </summary>
        /// <remarks>この値はデバッグに使用します。</remarks>
        int DataServiceCount
        {
            get;
        }

        /// <summary>
        /// バインドがデタッチされているかどうかを取得します。
        /// </summary>
        /// <remarks>この値はデバッグに使用します。</remarks>
        bool IsDetached
        {
            get;
        }

        /// <summary>
        /// データサービスを取得します。
        /// </summary>
        /// <param name="useCache">キャッシュを使用するかどうか</param>
        /// <returns>データサービスのインスタンス</returns>
        /// <remarks>キャッシュを使用する場合、並列実行性が失われる可能性があります。</remarks>
        // TODO: DataServiceのuseCacheが廃止された為、このパラメータは無効。別途削除する。
        IPreBoundDataService GetDataService(bool useCache = false);  

        /// <summary>
        /// 結果にデータサービス群を設定してデタッチします。
        /// </summary>
        /// <typeparam name="T">列挙子の要素型</typeparam>
        /// <param name="results">結果を示す列挙子</param>
        /// <returns>列挙可能なインスタンス</returns>
        /// <remarks>データサービス群の管理は、列挙子の列挙が完了するまで維持されます。
        /// これにより、データサービス群を列挙子の寿命に合わせる事が出来ます。</remarks>
        IEnumerable<T> DetachWithResults<T>(IEnumerable<T> results);
    }
}

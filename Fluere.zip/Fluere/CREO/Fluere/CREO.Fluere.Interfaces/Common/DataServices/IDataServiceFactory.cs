﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスを生成するファクトリインターフェイスです。
    /// </summary>
    /// <remarks>データサービスとの接続に関する処理を隠蔽します。</remarks>
    public interface IDataServiceFactory : IDataServiceDefinitionAccessor
    {
        /// <summary>
        /// 事前バインドしたデータサービスファクトリを取得します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <param name="connectionPooling">接続プールを有効化する場合はtrue</param>
        /// <returns>事前バインドしたファクトリ</returns>
        /// <remarks>データサービスIDを事前に設定する事により、
        /// トランザクションの有無のみでデータサービスを生成する事が出来ます。
        /// 接続プールを有効化した場合は、同一のスレッドに対して同じデータサービスのインスタンスを返し、
        /// 異なるスレッドに対してユニークなデータサービスのインスタンスを返します。
        /// これにより、マルチスレッド動作時に高いパフォーマンスを維持し、かつデータサービスへの接続を最小化します。</remarks>
        IPreBoundDataServiceFactory PreBindDataService(
            string dataServiceID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID,
            bool connectionPooling = true);

        /// <summary>
        /// 事前バインドしたデータサービスファクトリを取得します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="workGroupID">ワークグループID</param>
        /// <param name="subWorkGroupID">サブワークグループID</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <param name="connectionPooling">接続プールを有効化する場合はtrue</param>
        /// <returns>事前バインドしたファクトリ</returns>
        /// <remarks>データサービスID・ワークグループID等を事前に設定する事により、
        /// トランザクションの有無のみでデータサービスを生成する事が出来ます。
        /// 接続プールを有効化した場合は、同一のスレッドに対して同じデータサービスのインスタンスを返し、
        /// 異なるスレッドに対してユニークなデータサービスのインスタンスを返します。
        /// これにより、マルチスレッド動作時に高いパフォーマンスを維持し、かつデータサービスへの接続を最小化します。</remarks>
        IPreBoundDataServiceFactory PreBindDataService(
            string dataServiceID,
            ulong workGroupID,
            ulong subWorkGroupID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID,
            bool connectionPooling = true);

        /// <summary>
        /// データサービスに接続します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="transactionMode">トランザクションモード</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <returns>データサービスのインスタンス</returns>
        CREO.DS.DataService ConnectToDataService(
            string dataServiceID,
            TransactionMode transactionMode,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID);

        /// <summary>
        /// データサービスに接続します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="workGroupID">ワークグループID</param>
        /// <param name="subWorkGroupID">サブワークグループID</param>
        /// <param name="transactionMode">トランザクションモード</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <returns>データサービスのインスタンス</returns>
        CREO.DS.DataService ConnectToDataService(
            string dataServiceID,
            ulong workGroupID,
            ulong subWorkGroupID,
            TransactionMode transactionMode,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID);
    }
}

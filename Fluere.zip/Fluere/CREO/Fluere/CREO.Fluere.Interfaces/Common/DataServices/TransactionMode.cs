﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスのトランザクションモードを指定する列挙値です。
    /// </summary>
    public enum TransactionMode
    {
        /// <summary>
        /// トランザクションを使用しません。
        /// </summary>
        NoTransacted = 0,

        /// <summary>
        /// 更新トランザクションを使用します。
        /// </summary>
        Transacted = 1
    }
}

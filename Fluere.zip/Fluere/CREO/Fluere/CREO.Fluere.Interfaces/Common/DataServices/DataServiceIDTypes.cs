﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.29 TMI K.Matsui

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスIDの種別を指定する列挙値です。
    /// </summary>
    public enum DataServiceIDTypes
    {
        /// <summary>
        /// データベースロールIDとして解釈を試行し、その後データソースIDとして解釈します。
        /// </summary>
        AutoFallBack,

        /// <summary>
        /// データソースIDです。
        /// </summary>
        DataSourceID,

        /// <summary>
        /// データベースロールIDです。
        /// </summary>
        DatabaseRoleID
    }
}

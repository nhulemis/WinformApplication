﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.31 TMI K.Matsui

using System;
using System.ComponentModel;
using System.Data;
using System.Data.Common;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データベースへのダイレクトアクセスを実行するデータプロバイダのインターフェイスです。
    /// </summary>
    public interface IDirectDatabaseProvider : IDirectDatabaseAccessor, IDisposable
    {
        /// <summary>
        /// 接続文字列を取得します。
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        string ConnectionString
        {
            get;
        }

        /// <summary>
        /// 接続文字列を取得します。
        /// </summary>
        string EntitiesConnectionString
        {
            get;
        }

        /// <summary>
        /// ファクトリを取得します。
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        DbProviderFactory Factory
        {
            get;
        }

        /// <summary>
        /// 現在のデータベース接続を取得します。
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        IDbConnection Connection
        {
            get;
        }

        /// <summary>
        /// データベースを開きます。
        /// </summary>
        void Open();
    }
}

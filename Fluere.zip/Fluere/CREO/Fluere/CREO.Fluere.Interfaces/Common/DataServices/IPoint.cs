﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするインターフェイスです。
    /// </summary>
    public interface IPoint : IGeometry
    {
        /// <summary>
        /// X座標を取得します。
        /// </summary>
        double X
        {
            get;
        }

        /// <summary>
        /// Y座標を取得します。
        /// </summary>
        double Y
        {
            get;
        }

        /// <summary>
        /// Coordinateに変換します。
        /// </summary>
        /// <returns>Coordinate</returns>
        CREO.FW.TMIGeometry.Coordinate ToCoordinate();

        /// <summary>
        /// CoordinateDに変換します。
        /// </summary>
        /// <returns>CoordinateD</returns>
        CREO.FW.TMIGeometry.CoordinateD ToCoordinateD();
    }
}

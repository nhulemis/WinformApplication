﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.01 TMI K.Matsui

using System.ComponentModel;
using System.Data;
using CREO.Fluere.Biz.Data;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データベースへのダイレクトアクセスを実行するトランザクションコンテキストインターフェイスです。
    /// </summary>
    public interface IDirectDatabaseTransactionContext : IDirectDatabaseAccessor, ITransactionContext
    {
        /// <summary>
        /// 現在のトランザクションオブジェクトを取得します。
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        IDbTransaction Transaction
        {
            get;
        }
    }
}

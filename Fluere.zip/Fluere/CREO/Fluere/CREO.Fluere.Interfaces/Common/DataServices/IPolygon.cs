﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System.Collections.Generic;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするインターフェイスです。
    /// </summary>
    /// <remarks>マルチポリゴン内の個々のポリゴンを保持します。
    /// 列挙子を提供し、LINQクエリの記述を可能にします。</remarks>
    public interface IPolygon : IGeometry, IEnumerable<IRing>
    {
        /// <summary>
        /// 内包するリング数を取得します。
        /// </summary>
        int Count
        {
            get;
        }

        /// <summary>
        /// インデックスを指定して、リングを取得します。
        /// </summary>
        /// <param name="index">インデックス</param>
        /// <returns>リング</returns>
        IRing this[int index]
        {
            get;
        }

        /// <summary>
        /// ポリゴンをCoordinateの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        /// <remarks>返却する列挙子は、リングを表現出来ません。
        /// そのため、内包するポリゴンに複数のリングが含まれている場合、例外がスローされます。</remarks>
        IEnumerable<CREO.FW.TMIGeometry.Coordinate> ToCoordinateCollection();

        /// <summary>
        /// ポリゴンをCoordinateDの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        /// <remarks>返却する列挙子は、リングを表現出来ません。
        /// そのため、内包するポリゴンに複数のリングが含まれている場合、例外がスローされます。</remarks>
        IEnumerable<CREO.FW.TMIGeometry.CoordinateD> ToCoordinateDCollection();

        /// <summary>
        /// ポリゴンをCoordinateRectに変換します。
        /// </summary>
        /// <returns>CoordinateRect</returns>
        /// <remarks>返却するCoordinateRectは、四角形でないポリゴンやリングを表現出来ません。
        /// そのため、これらのポリゴンが含まれている場合、例外がスローされます。</remarks>
        CREO.FW.TMIGeometry.CoordinateRect ToCoordinateRect();

        /// <summary>
        /// ポリゴンをCompositePolygonに変換します。
        /// </summary>
        /// <returns>CompositePolygon</returns>
        CREO.FW.TMIGeometry.CompositePolygon ToCompositePolygon();
    }
}

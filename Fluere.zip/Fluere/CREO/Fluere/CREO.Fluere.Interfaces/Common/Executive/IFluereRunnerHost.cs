﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.Configuration;
using CREO.Fluere.Common.DataServices;
using CREO.Fluere.Common.DataSources;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Executive
{
    /// <summary>
    /// Fluere処理を実行する際に必要な処理を提供するインターフェイスです。
    /// </summary>
    /// <remarks>Fluere処理を実行するモジュールに関連する、モジュール名や処理実装モジュールのパス、
    /// 関連付けられる設定ファイルを制御するConfigurationManagerのインスタンス生成、
    /// メッセージ・ログ出力の処理を行うための処理を提供します。</remarks>
    public interface IFluereRunnerHost
        : IDataServiceFactory,
        IDataSourceFactory,
        IMessageFormatter,
        ILogger,
        IDisposable
    {
        /// <summary>
        /// 親モジュール名を取得します。
        /// </summary>
        string ModuleName
        {
            get;
        }

        /// <summary>
        /// ConfigurationManagerを生成します。
        /// </summary>
        /// <param name="configurationType">対象の型（インターフェイス）</param>
        /// <param name="configurationPath">対象を格納するファイルのパス</param>
        /// <returns>インスタンス</returns>
        /// <remarks>指定されたパスに従って、ConfigurationManagerのインスタンスを生成します。</remarks>
        IConfigurationManager CreateConfigurationManager(
            Type configurationType,
            string configurationPath);

        /// <summary>
        /// ConfigurationManagerを生成します。
        /// </summary>
        /// <typeparam name="T">対象の型（インターフェイス）</typeparam>
        /// <param name="configurationPath">対象を格納するファイルのパス</param>
        /// <returns>インスタンス</returns>
        /// <remarks>指定されたパスに従って、ConfigurationManagerのインスタンスを生成します。</remarks>
        IAssignableConfigurationManager<T> CreateConfigurationManager<T>(string configurationPath)
            where T : class;

    }
}

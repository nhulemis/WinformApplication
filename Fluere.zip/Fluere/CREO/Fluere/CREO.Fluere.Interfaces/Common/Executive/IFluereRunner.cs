﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using CREO.Fluere.Common.Configuration;

namespace CREO.Fluere.Common.Executive
{
    /// <summary>
    /// Fluereの処理を制御するインターフェイスです。
    /// </summary>
    /// <remarks>指定されたモジュールから、Fluere処理を実装するクラス
    /// （IFluereRunnableインターフェイスを実装したシールクラス）を検索し、
    /// システム設定データと処理固有の設定データを与えて実行します。</remarks>
    public interface IFluereRunner : IFluereRunnable
    {
        /// <summary>
        /// Fluere処理のエントリポイントが必要とするインターフェイスの名称群を取得します。
        /// </summary>
        /// <returns>インターフェイスの名称群</returns>
        string[] GetArgumentDescriptions();

        /// <summary>
        /// Fluereの処理を実行します。
        /// </summary>
        /// <param name="runnerHost">Fluere処理を実行するための情報を提供するインターフェイス</param>
        /// <param name="configurationManagers">Runメソッドの追加引数に対応するConfigurationManager群</param>
        /// <returns>戻り値</returns>
        int Run(IFluereRunnerHost runnerHost, params IConfigurationManager[] configurationManagers);

        /// <summary>
        /// Fluereの処理を実行します。
        /// </summary>
        /// <param name="runnerHost">Fluere処理を実行するための情報を提供するインターフェイス</param>
        /// <param name="args">コマンドラインで指定されたファイルへのパス群</param>
        /// <returns>戻り値</returns>
        int Run(IFluereRunnerHost runnerHost, params string[] args);
    }
}

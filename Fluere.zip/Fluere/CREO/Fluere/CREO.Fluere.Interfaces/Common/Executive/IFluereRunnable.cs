﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.Executive
{
    /// <summary>
    /// Fluere処理のエントリポイントを示すインターフェイスです。
    /// </summary>
    /// <remarks>Fluere処理対象のクラスはこのインターフェイスを実装し、シールクラスとして宣言する必要があります。
    /// FluereRunnerクラスは、このインターフェイスを標的として検索を行います。
    /// また、Runメソッドを定義する必要があります。</remarks>
    /// <example>
    /// // ■Runメソッドのサンプル
    /// // ・戻り値はint
    /// // ・先頭にIFluereRunnerInformationが必ず必要
    /// // ・追加引数はIConfigurationManager&lt;T&gt;でなければならない
    /// // ・追加引数の数が、コマンドラインの数に一致しなければならない
    /// int Run(IFluereRunnerInformation information,
    ///   IConfigurationManager&lt;ISystemDefinition&gt; systemDefinition,
    ///   IConfigurationManager&lt;ICitySummaryImportDef&gt; configuration);
    /// </example>
    public interface IFluereRunnable : IDisposable
    {
        /// <summary>
        /// 処理名称を取得します。
        /// </summary>
        string Name
        {
            get;
        }

        // ■Runメソッドのサンプル
        // ・戻り値はint
        // ・先頭にIFluereRunnerInformationが必ず必要
        // ・追加引数はIConfigurationManager<T>でなければならない
        // ・追加引数の数が、コマンドラインの数に一致しなければならない
        // int Run(IFluereRunnerInformation information,
        //   IConfigurationManager<ISystemDefinition> systemDefinition,
        //   IConfigurationManager<ICitySummaryImportDef> configuration);
    }
}

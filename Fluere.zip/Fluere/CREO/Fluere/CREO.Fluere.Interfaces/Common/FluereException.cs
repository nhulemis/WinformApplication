﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Runtime.Serialization;
using System.Security;

namespace CREO.Fluere.Common
{
    /// <summary>
    /// Fluere処理全体で共通の例外基底クラスです。
    /// </summary>
    [Serializable]
    public class FluereException : Exception
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="message">メッセージ</param>
        protected internal FluereException(string message)
            : base(message)
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="format">フォーマット</param>
        /// <param name="args">メッセージに適用する追加引数群</param>
        protected internal FluereException(string format, params object[] args)
            : base(string.Format(format, args))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="inner">内包する例外</param>
        /// <param name="message">メッセージ</param>
        protected internal FluereException(Exception inner, string message)
            : base(message, inner)
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="inner">内包する例外</param>
        /// <param name="format">フォーマット</param>
        /// <param name="args">メッセージに適用する追加引数群</param>
        protected internal FluereException(Exception inner, string format, params object[] args)
            : base(string.Format(format, args), inner)
        {
        }

        /// <summary>
        /// 逆シリアル化コンストラクタです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecuritySafeCritical]
        protected FluereException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.IO;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// トランザクション操作のためにエンリストメント可能なファイルストリームのカプセル化実装クラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class FileStreamEnlistmentItem : IPseudoTransactionEnlistmentItem
    {
        #region Fields
        /// <summary>
        /// フルパス
        /// </summary>
        private readonly string _fullPath;

        /// <summary>
        /// テンポラリパス
        /// </summary>
        private readonly string _temporaryPath;

        /// <summary>
        /// バックアップパス
        /// </summary>
        private readonly string _backupPath;

        /// <summary>
        /// メソッド
        /// </summary>
        private readonly MethodBase _method;

        /// <summary>
        /// 対象のストリーム
        /// </summary>
        private Stream _targetStream;

        /// <summary>
        /// 状態
        /// </summary>
        private CompleteStates _completeState = CompleteStates.Before;

        /// <summary>
        /// 元のファイルを保存したかどうか
        /// </summary>
        private bool _backupedOriginal;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="fullPath">ファイルへのパス</param>
        /// <param name="fileMode">ファイルモード</param>
        /// <param name="fileAccess">ファイルアクセス</param>
        /// <param name="fileShare">ファイルシェア</param>
        /// <param name="method">メソッド</param>
        public FileStreamEnlistmentItem(
            string fullPath,
            FileMode fileMode,
            FileAccess fileAccess,
            FileShare fileShare,
            MethodBase method)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(fullPath) == false);
            Assertion.Condition(method != null);

            this._fullPath = fullPath;
            this._temporaryPath = string.Format("{0}_{1}", this._fullPath, Guid.NewGuid());
            this._backupPath = string.Format("{0}_{1}", this._fullPath, Guid.NewGuid());
            this._method = method;

            switch (fileMode)
            {
                case FileMode.Create:
                    this._targetStream = new FileStream(
                        this._temporaryPath,
                        FileMode.Create,
                        fileAccess,
                        fileShare);
                    break;

                case FileMode.CreateNew:
                    if (File.Exists(this._fullPath) == true)
                    {
                        throw new IOException(this._fullPath + " が存在します");
                    }

                    this._targetStream = new FileStream(
                        this._temporaryPath,
                        FileMode.Create,
                        fileAccess,
                        fileShare);
                    break;

                case FileMode.Append:
                case FileMode.OpenOrCreate:
                    // ファイルが存在する
                    if (File.Exists(this._fullPath) == true)
                    {
                        try
                        {
                            File.Copy(this._fullPath, this._temporaryPath);
                            this._targetStream = new FileStream(
                                this._temporaryPath,
                                fileMode,
                                fileAccess,
                                fileShare);
                        }
                        catch (FileNotFoundException)
                        {
                            // ファイルが存在しない（Copy直前に移動又は生成された→新たに作成）
                            this._targetStream = new FileStream(
                                this._temporaryPath,
                                fileMode,
                                fileAccess,
                                fileShare);
                        }
                    }
                    else
                    {
                        // ファイルが存在しない（次の瞬間、ファイルが存在する可能性があるが仕方がない）
                        this._targetStream = new FileStream(
                            this._temporaryPath,
                            fileMode,
                            fileAccess,
                            fileShare);
                    }

                    break;

                case FileMode.Open:
                    File.Copy(this._fullPath, this._temporaryPath);
                    this._targetStream = new FileStream(
                        this._temporaryPath,
                        FileMode.Open,
                        fileAccess,
                        fileShare);
                    break;

                case FileMode.Truncate:
                    if (File.Exists(_fullPath) == false)
                    {
                        throw new FileNotFoundException(this._fullPath + " が存在しません");
                    }

                    this._targetStream = new FileStream(
                        this._temporaryPath,
                        FileMode.Create,
                        fileAccess,
                        fileShare);
                    break;
            }
        }
        #endregion

        #region CompleteStates
        /// <summary>
        /// コミット処理のステートです。
        /// </summary>
        private enum CompleteStates
        {
            /// <summary>
            /// コミット前
            /// </summary>
            Before,

            /// <summary>
            /// 元のファイルを保存
            /// </summary>
            ExecutedBackupOriginal,

            /// <summary>
            /// ストリームをクローズ
            /// </summary>
            ClosedStream,

            /// <summary>
            /// 新しいファイルをリネーム
            /// </summary>
            RenamedNewFile,

            /// <summary>
            /// 完了
            /// </summary>
            Done
        }
        #endregion

        #region Name
        /// <summary>
        /// エンリストメントアイテムの名前を取得します。
        /// </summary>
        public string Name
        {
            get
            {
                return "FileStream";
            }
        }
        #endregion

        #region State
        /// <summary>
        /// 現在のステートを示す文字列を取得します。
        /// </summary>
        public string State
        {
            get
            {
                return this._completeState.ToString();
            }
        }
        #endregion

        #region Creator
        /// <summary>
        /// エンリストメントアイテムを生成したメソッドを取得します。
        /// </summary>
        public MethodBase Creator
        {
            get
            {
                return this._method;
            }
        }
        #endregion

        #region TargetStream
        /// <summary>
        /// ターゲットのストリームを取得します。
        /// </summary>
        public Stream TargetStream
        {
            get
            {
                return this._targetStream;
            }
        }
        #endregion

        #region RecreateStream
        /// <summary>
        /// 現在のストリームを破棄して、新しいストリームを生成します。
        /// </summary>
        /// <param name="fileMode">ファイルモード</param>
        /// <param name="fileAccess">ファイルアクセス</param>
        /// <param name="fileShare">ファイルシェア</param>
        /// <returns>ストリーム</returns>
        public Stream RecreateStream(FileMode fileMode, FileAccess fileAccess, FileShare fileShare)
        {
            Assertion.Require(this._targetStream.CanRead == false, "以前のストリームがクローズされていません");

            this._targetStream = new FileStream(this._temporaryPath, fileMode, fileAccess, fileShare);
            return this._targetStream;
        }
        #endregion

        #region BeforePreComplete
        /// <summary>
        /// フェーズ１コミットです。
        /// </summary>
        public void BeforePreComplete()
        {
            // 途中で失敗したステートを認識できるように、逐次ステート処理を行う
            while (true)
            {
                switch (this._completeState)
                {
                    // コミットは開始していない
                    case CompleteStates.Before:
                        // 元のファイルがある
                        if (File.Exists(this._fullPath) == true)
                        {
                            try
                            {
                                // 元のファイルをバックアップファイル名に変更する
                                File.Move(this._fullPath, this._backupPath);
                                this._backupedOriginal = true;
                            }
                            catch (FileNotFoundException)
                            {
                                // 元のファイルがない（Move直前に削除または移動された）
                            }
                        }
                        else
                        {
                            // 元のファイルがない（次の瞬間、ファイルが存在する可能性があるが仕方がない）
                        }

                        this._completeState = CompleteStates.ExecutedBackupOriginal;
                        break;

                    // オリジナルファイルのバックアップ処理を行った
                    case CompleteStates.ExecutedBackupOriginal:
                        // ストリームをクローズする
                        this._targetStream.Close();
                        this._targetStream = null;
                        this._completeState = CompleteStates.ClosedStream;
                        break;

                    // ストリームをクローズした
                    case CompleteStates.ClosedStream:
                        // テンポラリファイルを正規のファイル名に変更する
                        File.Move(this._temporaryPath, this._fullPath);
                        this._completeState = CompleteStates.RenamedNewFile;
                        return;

                    // テンポラリファイルを正規のファイル名に変更した
                    case CompleteStates.RenamedNewFile:
                        return;

                    default:
                        throw new InvalidOperationException();
                }
            }
        }
        #endregion

        #region AfterPreComplete
        /// <summary>
        /// フェーズ１コミットを実行します。
        /// </summary>
        public void AfterPreComplete()
        {
        }
        #endregion

        #region BeforeComplete
        /// <summary>
        /// フェーズ２コミットです。
        /// </summary>
        public void BeforeComplete()
        {
            switch (this._completeState)
            {
                // テンポラリファイルを正規のファイル名に変更した
                case CompleteStates.RenamedNewFile:
                    // バックアップしていれば
                    if (this._backupedOriginal == true)
                    {
                        // オリジナルファイルを削除する
                        File.Delete(this._backupPath);
                    }

                    this._completeState = CompleteStates.Done;
                    return;

                // 完了しているのですることはない
                case CompleteStates.Done:
                    return;

                default:
                    throw new InvalidOperationException();
            }
        }
        #endregion

        #region AfterComplete
        /// <summary>
        /// フェーズ２コミットです。
        /// </summary>
        public void AfterComplete()
        {
        }
        #endregion

        #region BeforeRollback
        /// <summary>
        /// ロールバックを実行します。
        /// </summary>
        public void BeforeRollback()
        {
            // 現在のステートに応じて復元処理を行う
            switch (this._completeState)
            {
                // コミットは開始していない
                case CompleteStates.Before:
                    // ストリームを閉じる
                    this._targetStream.Close();
                    this._targetStream = null;

                    // テンポラリファイルを削除する
                    File.Delete(this._temporaryPath);

                    this._completeState = CompleteStates.Done;
                    break;

                // オリジナルファイルのバックアップ処理を行った
                case CompleteStates.ExecutedBackupOriginal:

                    // ストリームを閉じる
                    this._targetStream.Close();
                    this._targetStream = null;

                    // テンポラリファイルを削除する
                    File.Delete(this._temporaryPath);

                    // バックアップしていれば元に戻す
                    if (this._backupedOriginal == true)
                    {
                        File.Move(this._backupPath, this._fullPath);
                    }

                    this._completeState = CompleteStates.Done;
                    break;

                // ストリームをクローズした
                case CompleteStates.ClosedStream:
                    // テンポラリファイルを削除する
                    File.Delete(this._temporaryPath);

                    // バックアップしていれば元に戻す
                    if (this._backupedOriginal == true)
                    {
                        File.Move(this._backupPath, this._fullPath);
                    }

                    this._completeState = CompleteStates.Done;
                    return;

                // テンポラリファイルを正規のファイル名に変更した
                case CompleteStates.RenamedNewFile:
                    // テンポラリファイル（正規のファイル名）を削除する
                    File.Delete(this._fullPath);

                    // バックアップしていれば元に戻す
                    if (this._backupedOriginal == true)
                    {
                        File.Move(this._backupPath, this._fullPath);
                    }

                    this._completeState = CompleteStates.Done;
                    return;

                // 完了しているのですることはない
                case CompleteStates.Done:
                    return;

                default:
                    throw new InvalidOperationException();
            }
        }
        #endregion

        #region AfterRollback
        /// <summary>
        /// ロールバックを実行します。
        /// </summary>
        public void AfterRollback()
        {
        }
        #endregion
    }
}

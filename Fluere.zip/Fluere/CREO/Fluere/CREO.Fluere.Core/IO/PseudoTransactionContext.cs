﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// 擬似トランザクションを実行するトランザクションコンテキストクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class PseudoTransactionContext : IFileSystemTransactionContext
    {
        #region Fields
        /// <summary>
        /// トランザクションID
        /// </summary>
        private readonly Guid _transactionID = Guid.NewGuid();

        /// <summary>
        /// エンリストメントアイテムリスト
        /// </summary>
        private readonly IList<IPseudoTransactionEnlistmentItem> _items =
            new List<IPseudoTransactionEnlistmentItem>();

        /// <summary>
        /// パスに対応するエンリストメントアイテムの辞書
        /// </summary>
        private readonly IDictionary<string, IPseudoTransactionEnlistmentItem> _itemDictionary =
            new Dictionary<string, IPseudoTransactionEnlistmentItem>();
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public PseudoTransactionContext()
        {
        }
        #endregion

        #region TransactionID
        /// <summary>
        /// トランザクションに割り当てられたIDを取得します。
        /// </summary>
        public Guid TransactionID
        {
            get
            {
                return this._transactionID;
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        /// <remarks>割り当てられているトランザクション要素があればロールバックされます。</remarks>
        public void Dispose()
        {
            lock (this)
            {
                try
                {
                    // ロールバック
                    for (var i = 0; i < this._items.Count; i++)
                    {
                        try
                        {
                            this._items[i].BeforeRollback();
                        }
                        catch
                        {
                        }
                    }

                    for (var i = this._items.Count - 1; i >= 0; i--)
                    {
                        try
                        {
                            this._items[i].AfterRollback();
                        }
                        catch
                        {
                        }
                    }
                }
                finally
                {
                    this._items.Clear();
                    this._itemDictionary.Clear();
                }
            }
        }
        #endregion

        #region Commit
        /// <summary>
        /// トランザクションをコミットします。
        /// </summary>
        public void Commit()
        {
            lock (this)
            {
                // フェーズ１コミット
                for (var i = 0; i < this._items.Count; i++)
                {
                    this._items[i].BeforePreComplete();
                }

                // フェーズ１コミット
                for (var i = this._items.Count - 1; i >= 0; i--)
                {
                    this._items[i].AfterPreComplete();
                }

                try
                {
                    // 全て成功した場合のみフェーズ２コミットに移行
                    for (var i = 0; i < this._items.Count; i++)
                    {
                        try
                        {
                            this._items[i].BeforeComplete();
                        }
                        catch
                        {
                        }
                    }

                    for (var i = this._items.Count - 1; i >= 0; i--)
                    {
                        try
                        {
                            this._items[i].AfterComplete();
                        }
                        catch
                        {
                        }
                    }
                }
                finally
                {
                    this._items.Clear();
                    this._itemDictionary.Clear();
                }
            }
        }
        #endregion

        #region GetFileShare
        /// <summary>
        /// ファイルアクセスからファイルシェアを取得します。
        /// </summary>
        /// <param name="fileAccess">ファイルアクセス</param>
        /// <returns>ファイルシェア</returns>
        internal static FileShare GetFileShare(FileAccess fileAccess)
        {
            return ((fileAccess & FileAccess.Write) == FileAccess.Write) ?
                FileShare.None : FileShare.Read;
        }
        #endregion

        #region CreateDirectory
        /// <summary>
        /// フォルダを生成します。
        /// </summary>
        /// <param name="folderPath">対象のフォルダパス</param>
        /// <returns>代替パス</returns>
        public string CreateDirectory(string folderPath)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(folderPath) == false);

            lock (this)
            {
                IPseudoTransactionEnlistmentItem item;
                if (this._itemDictionary.TryGetValue(folderPath, out item) == true)
                {
                    Assertion.Require(
                        item is CreateDirectoryEnlistmentItem,
                        "指定されたパスは {0} として使用中です: パス={1}",
                        item.Name,
                        folderPath);
                }
                else
                {
                    item = new CreateDirectoryEnlistmentItem(folderPath, new StackFrame(1).GetMethod());
                    this._items.Add(item);
                    this._itemDictionary.Add(folderPath, item);
                }

                return ((CreateDirectoryEnlistmentItem)item).TargetPath;
            }
        }
        #endregion

        #region TrackFilePath
        /// <summary>
        /// 直接紐付けられない生成ファイルを、エンリストメントアイテムとして追跡します。
        /// </summary>
        /// <param name="filePath">ファイルへのパス</param>
        /// <remarks>トランザクションコンテキストに紐付けられていないファイルを追跡し、
        /// ロールバック時にファイルの削除を行います。</remarks>
        public void TrackFilePath(string filePath)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(filePath) == false);

            lock (this)
            {
                IPseudoTransactionEnlistmentItem item;
                if (this._itemDictionary.TryGetValue(filePath, out item) == true)
                {
                    Assertion.Require(
                        item is FileTrackingEnlistmentItem,
                        "指定されたパスは {0} として使用中です: パス={1}",
                        item.Name,
                        filePath);
                }
                else
                {
                    item = new FileTrackingEnlistmentItem(filePath, new StackFrame(1).GetMethod());
                    this._items.Add(item);
                    this._itemDictionary.Add(filePath, item);
                }
            }
        }
        #endregion

        #region CreateStream
        /// <summary>
        /// トランザクションに関連付けられたストリームを生成します。
        /// </summary>
        /// <param name="filePath">ファイルへのパス</param>
        /// <param name="fileMode">ファイルモード</param>
        /// <param name="fileAccess">ファイルアクセス</param>
        /// <returns>ストリーム</returns>
        public Stream CreateStream(string filePath, FileMode fileMode, FileAccess fileAccess)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(filePath) == false, "ファイルへのパスが必要です");

            var fullPath = Path.GetFullPath(filePath);

            // CreateNew以外で（後でファイル存在チェックするため除外）、書き込みを行おうとしている場合の読み取り専用のチェック
            if ((fileMode != FileMode.CreateNew) &&
                ((fileAccess & FileAccess.Write) == FileAccess.Write))
            {
                if (File.Exists(fullPath) == true)
                {
                    if ((File.GetAttributes(fullPath) & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
                    {
                        throw new IOException(filePath + " は読み取り専用です");
                    }
                }
            }

            var fileShare = GetFileShare(fileAccess);

            lock (this)
            {
                // エンリストメントされていれば
                IPseudoTransactionEnlistmentItem item;
                if (this._itemDictionary.TryGetValue(fullPath, out item) == true)
                {
                    var realItem = item as FileStreamEnlistmentItem;

                    Assertion.Require(
                        realItem != null,
                        "指定されたパスは {0} として使用中です: パス={1}",
                        item.Name,
                        fullPath);

                    // 以前に使用していた場合は、ストリームを再生成する
                    return realItem.RecreateStream(fileMode, fileAccess, fileShare);
                }
                else
                {
                    // 読み取り専用の場合は、ファイルを直接開く
                    if ((fileAccess & FileAccess.Write) != FileAccess.Write)
                    {
                        return new FileStream(fullPath, fileMode, fileAccess, fileShare);
                    }

                    var realItem = new FileStreamEnlistmentItem(
                        fullPath,
                        fileMode,
                        fileAccess,
                        fileShare,
                        new StackFrame(1).GetMethod());
                    this._items.Add(realItem);
                    this._itemDictionary.Add(fullPath, realItem);

                    return realItem.TargetStream;
                }
            }
        }
        #endregion
    }
}

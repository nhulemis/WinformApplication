﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.12 TMI K.Matsui

using System;
using System.IO;
using System.Reflection;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// トランザクション操作のためにエンリストメント可能なファイル追跡のカプセル化実装クラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class FileTrackingEnlistmentItem : IPseudoTransactionEnlistmentItem
    {
        #region Fields
        /// <summary>
        /// フルパス
        /// </summary>
        private readonly string _fullPath;

        /// <summary>
        /// メソッド
        /// </summary>
        private readonly MethodBase _method;

        /// <summary>
        /// 状態
        /// </summary>
        private CompleteStates _completeState = CompleteStates.Before;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="fullPath">ファイルへのパス</param>
        /// <param name="method">メソッド</param>
        public FileTrackingEnlistmentItem(
            string fullPath,
            MethodBase method)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(fullPath) == false);
            Assertion.Condition(method != null);

            this._fullPath = fullPath;
            this._method = method;
        }
        #endregion

        #region CompleteStates
        /// <summary>
        /// コミット処理のステートです。
        /// </summary>
        private enum CompleteStates
        {
            /// <summary>
            /// コミット前
            /// </summary>
            Before,

            /// <summary>
            /// 完了
            /// </summary>
            Done
        }
        #endregion

        #region Name
        /// <summary>
        /// エンリストメントアイテムの名前を取得します。
        /// </summary>
        public string Name
        {
            get
            {
                return "FileTracking";
            }
        }
        #endregion

        #region State
        /// <summary>
        /// 現在のステートを示す文字列を取得します。
        /// </summary>
        public string State
        {
            get
            {
                return this._completeState.ToString();
            }
        }
        #endregion

        #region Creator
        /// <summary>
        /// エンリストメントアイテムを生成したメソッドを取得します。
        /// </summary>
        public MethodBase Creator
        {
            get
            {
                return _method;
            }
        }
        #endregion

        #region BeforePreComplete
        /// <summary>
        /// フェーズ１コミットです。
        /// </summary>
        public void BeforePreComplete()
        {
        }
        #endregion

        #region AfterPreComplete
        /// <summary>
        /// フェーズ１コミットを実行します。
        /// </summary>
        public void AfterPreComplete()
        {
        }
        #endregion

        #region BeforeComplete
        /// <summary>
        /// フェーズ２コミットです。
        /// </summary>
        public void BeforeComplete()
        {
            switch (this._completeState)
            {
                // コミットは開始していない
                case CompleteStates.Before:
                    this._completeState = CompleteStates.Done;
                    return;

                // 完了しているのですることはない
                case CompleteStates.Done:
                    return;

                default:
                    throw new InvalidOperationException();
            }
        }
        #endregion

        #region AfterComplete
        /// <summary>
        /// フェーズ２コミットです。
        /// </summary>
        public void AfterComplete()
        {
        }
        #endregion

        #region BeforeRollback
        /// <summary>
        /// ロールバックを実行します。
        /// </summary>
        public void BeforeRollback()
        {
            // 現在のステートに応じて復元処理を行う
            switch (this._completeState)
            {
                // コミットは開始していない
                case CompleteStates.Before:
                    // ファイルを削除する
                    File.Delete(_fullPath);

                    this._completeState = CompleteStates.Done;
                    break;

                // 完了しているのですることはない
                case CompleteStates.Done:
                    return;

                default:
                    throw new InvalidOperationException();
            }
        }
        #endregion

        #region AfterRollback
        /// <summary>
        /// ロールバックを実行します。
        /// </summary>
        public void AfterRollback()
        {
        }
        #endregion
    }
}

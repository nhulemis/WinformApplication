﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.IO;
using System.Reflection;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// トランザクション操作のためにエンリストメント可能なディレクトリ生成のカプセル化実装クラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class CreateDirectoryEnlistmentItem : IPseudoTransactionEnlistmentItem
    {
        #region Fields
        /// <summary>
        /// フルパス
        /// </summary>
        private readonly string _fullPath;

        /// <summary>
        /// テンポラリパス
        /// </summary>
        private readonly string _temporaryPath;

        /// <summary>
        /// バックアップパス
        /// </summary>
        private readonly string _backupPath;

        /// <summary>
        /// メソッド
        /// </summary>
        private readonly MethodBase _method;

        /// <summary>
        /// 状態
        /// </summary>
        private CompleteStates _completeState = CompleteStates.Before;

        /// <summary>
        /// 元のディレクトリを保存したかどうか
        /// </summary>
        private bool _backupedOriginal;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="fullPath">ディレクトリへのパス</param>
        /// <param name="method">メソッド</param>
        public CreateDirectoryEnlistmentItem(
            string fullPath,
            MethodBase method)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(fullPath) == false);
            Assertion.Condition(method != null);

            this._fullPath = fullPath;
            this._method = method;

            // 指定されたディレクトリが存在しない
            if (Directory.Exists(fullPath) == false)
            {
                this._temporaryPath = string.Format("{0}_{1}", _fullPath, Guid.NewGuid());
                this._backupPath = string.Format("{0}_{1}", _fullPath, Guid.NewGuid());

                Directory.CreateDirectory(this._temporaryPath);
            }
            else
            {
                // 指定されたディレクトリが存在する
                this._temporaryPath = _fullPath;
            }
        }
        #endregion

        #region CompleteStates
        /// <summary>
        /// コミット処理のステートです。
        /// </summary>
        private enum CompleteStates
        {
            /// <summary>
            /// コミット前
            /// </summary>
            Before,

            /// <summary>
            /// 元のディレクトリを保存
            /// </summary>
            ExecutedBackupOriginal,

            /// <summary>
            /// ディレクトリの置き換え
            /// </summary>
            Replaced,

            /// <summary>
            /// 完了
            /// </summary>
            Done
        }
        #endregion

        #region TargetPath
        /// <summary>
        /// ターゲットのパスを取得します。
        /// </summary>
        public string TargetPath
        {
            get
            {
                return this._temporaryPath;
            }
        }
        #endregion

        #region Name
        /// <summary>
        /// エンリストメントアイテムの名前を取得します。
        /// </summary>
        public string Name
        {
            get
            {
                return "CreateDirectory";
            }
        }
        #endregion

        #region State
        /// <summary>
        /// 現在のステートを示す文字列を取得します。
        /// </summary>
        public string State
        {
            get
            {
                return this._completeState.ToString();
            }
        }
        #endregion

        #region Creator
        /// <summary>
        /// エンリストメントアイテムを生成したメソッドを取得します。
        /// </summary>
        public MethodBase Creator
        {
            get
            {
                return this._method;
            }
        }
        #endregion

        #region BeforePreComplete
        /// <summary>
        /// フェーズ１コミットです。
        /// </summary>
        public void BeforePreComplete()
        {
            if (this._fullPath == this._temporaryPath)
            {
                return;
            }

            // 途中で失敗したステートを認識できるように、逐次ステート処理を行う
            while (true)
            {
                switch (this._completeState)
                {
                    // コミットは開始していない
                    case CompleteStates.Before:
                        // 元のディレクトリがある
                        if (Directory.Exists(this._fullPath) == true)
                        {
                            try
                            {
                                // 元のディレクトリをバックアップファイル名に変更する
                                Directory.Move(this._fullPath, this._backupPath);
                                this._backupedOriginal = true;
                            }
                            catch (DirectoryNotFoundException)
                            {
                                // 元のディレクトリがない（Move直前に削除または移動された）
                            }
                        }
                        else
                        {
                            // 元のディレクトリがない（次の瞬間、ディレクトリが存在する可能性があるが仕方がない）
                        }

                        this._completeState = CompleteStates.ExecutedBackupOriginal;
                        break;

                    // オリジナルファイルのバックアップ処理を行った
                    case CompleteStates.ExecutedBackupOriginal:
                        return;

                    default:
                        throw new InvalidOperationException();
                }
            }
        }
        #endregion

        #region AfterPreComplete
        /// <summary>
        /// フェーズ１コミットを実行します。
        /// </summary>
        public void AfterPreComplete()
        {
        }
        #endregion

        #region BeforeComplete
        /// <summary>
        /// フェーズ２コミットです。
        /// </summary>
        public void BeforeComplete()
        {
        }
        #endregion

        #region AfterComplete
        /// <summary>
        /// フェーズ２コミットです。
        /// </summary>
        public void AfterComplete()
        {
            if (this._fullPath == this._temporaryPath)
            {
                return;
            }

            switch (this._completeState)
            {
                // オリジナルファイルのバックアップ処理を行った
                case CompleteStates.ExecutedBackupOriginal:
                    Directory.Move(this._temporaryPath, this._fullPath);

                    this._completeState = CompleteStates.Replaced;

                    // バックアップしていれば
                    if (this._backupedOriginal == true)
                    {
                        // オリジナルを削除
                        Directory.Delete(this._backupPath, true);
                    }

                    this._completeState = CompleteStates.Done;
                    return;

                // 完了しているのですることはない
                case CompleteStates.Done:
                    return;

                default:
                    throw new InvalidOperationException();
            }
        }
        #endregion

        #region BeforeRollback
        /// <summary>
        /// ロールバックを実行します。
        /// </summary>
        public void BeforeRollback()
        {
        }
        #endregion

        #region AfterRollback
        /// <summary>
        /// ロールバックを実行します。
        /// </summary>
        public void AfterRollback()
        {
            if (this._fullPath == this._temporaryPath)
            {
                return;
            }

            // 現在のステートに応じて復元処理を行う
            switch (this._completeState)
            {
                // コミットは開始していない
                case CompleteStates.Before:
                    Directory.Delete(this._temporaryPath, true);
                    this._completeState = CompleteStates.Done;
                    break;

                // オリジナルファイルのバックアップ処理を行った
                case CompleteStates.ExecutedBackupOriginal:
                    Directory.Delete(this._temporaryPath, true);

                    // バックアップしていれば
                    if (this._backupedOriginal == true)
                    {
                        Directory.Move(this._backupPath, this._fullPath);
                    }

                    this._completeState = CompleteStates.Done;
                    break;

                // リプレースした
                case CompleteStates.Replaced:
                    Directory.Delete(this._fullPath, true);

                    // バックアップしていれば元に戻す
                    if (this._backupedOriginal == true)
                    {
                        Directory.Move(this._backupPath, this._fullPath);
                    }

                    this._completeState = CompleteStates.Done;
                    return;

                // 完了しているのですることはない
                case CompleteStates.Done:
                    return;

                default:
                    throw new InvalidOperationException();
            }
        }
        #endregion
    }
}

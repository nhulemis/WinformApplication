﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.IO;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// トランザクションをサポートしたファイルストリームです。
    /// </summary>
    public sealed class TransactionalFileStream : Stream, ITransactionalFileStream
    {
        #region Fields
        /// <summary>
        /// 自身でトランザクションを保持しているかどうか
        /// </summary>
        private readonly bool _ownedTransaction;

        /// <summary>
        /// 対象のパス
        /// </summary>
        private readonly string _targetPath;

        /// <summary>
        /// トランザクションコンテキスト
        /// </summary>
        private IFileSystemTransactionContext _transactionContext;

        /// <summary>
        /// 内包するストリーム
        /// </summary>
        private Stream _stream;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="targetPath">ファイルへのパス</param>
        /// <param name="fileMode">ファイルオープンのモード</param>
        /// <param name="fileAccess">ファイルオープンのアクセス</param>
        /// <param name="transactionContext">トランザクションコンテキスト（指定しない場合はnull）</param>
        /// <param name="ownedTransaction">指定されたトランザクションコンテキストを管理するかどうか</param>
        /// <remarks>トランザクションコンテキストにnullを指定した場合は、自動的にトランザクションを管理します。
        /// その場合は、ownedTransactionは無視されます。</remarks>
        public TransactionalFileStream(
            string targetPath,
            FileMode fileMode,
            FileAccess fileAccess,
            IFileSystemTransactionContext transactionContext,
            bool ownedTransaction)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(targetPath) == false, "ファイルへのパスが必要です");

            this._transactionContext = transactionContext;
            this._ownedTransaction = ownedTransaction;
            this._targetPath = Path.GetFullPath(targetPath);

            // トランザクションコンテキストが指定されなかった場合
            if (this._transactionContext == null)
            {
                // 自動トランザクション
                this._transactionContext = FileSystemTransactionContextFactory.CreateContext();
                this._ownedTransaction = true;
            }

            // ストリームを生成
            this._stream = this._transactionContext.CreateStream(targetPath, fileMode, fileAccess);
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="targetPath">ファイルへのパス</param>
        /// <param name="fileMode">ファイルオープンのモード</param>
        /// <param name="fileAccess">ファイルオープンのアクセス</param>
        /// <param name="bufferSize">バッファサイズ</param>
        /// <param name="transactionContext">トランザクションコンテキスト（指定しない場合はnull）</param>
        /// <param name="ownedTransaction">指定されたトランザクションコンテキストを管理するかどうか</param>
        /// <remarks>トランザクションコンテキストにnullを指定した場合は、自動的にトランザクションを管理します。
        /// その場合は、ownedTransactionは無視されます。</remarks>
        public TransactionalFileStream(
            string targetPath,
            FileMode fileMode,
            FileAccess fileAccess,
            int bufferSize,
            IFileSystemTransactionContext transactionContext,
            bool ownedTransaction)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(targetPath) == false, "ファイルへのパスが必要です");
            Assertion.Argument(bufferSize >= 4096, "バッファサイズは4096バイト以上必要です");

            this._transactionContext = transactionContext;
            this._ownedTransaction = ownedTransaction;
            this._targetPath = Path.GetFullPath(targetPath);

            // トランザクションコンテキストが指定されなかった場合
            if (this._transactionContext == null)
            {
                // 自動トランザクション
                this._transactionContext = FileSystemTransactionContextFactory.CreateContext();
                this._ownedTransaction = true;
            }

            // ストリームホルダを生成
            var innerStream = this._transactionContext.CreateStream(targetPath, fileMode, fileAccess);

            // BufferedStreamでラップする
            this._stream = new BufferedStream(innerStream, bufferSize);
        }
        #endregion

        #region TargetPath
        /// <summary>
        /// 対象のファイルのパスを取得します。
        /// </summary>
        public string TargetPath
        {
            get
            {
                return this._targetPath;
            }
        }
        #endregion

        #region TransactionID
        /// <summary>
        /// 割り当てられたトランザクションIDを取得します。
        /// </summary>
        public Guid TransactionID
        {
            get
            {
                return this._transactionContext.TransactionID;
            }
        }
        #endregion

        #region Stream implementations
        /// <summary>
        /// 現在のストリームが読み取りをサポートするかどうかを示す値を取得します。
        /// </summary>
        public override bool CanRead
        {
            get
            {
                return this._stream.CanRead;
            }
        }

        /// <summary>
        /// 現在のストリームがシークをサポートするかどうかを示す値を取得します。
        /// </summary>
        public override bool CanSeek
        {
            get
            {
                return this._stream.CanSeek;
            }
        }

        /// <summary>
        /// 現在のストリームが書き込みをサポートするかどうかを示す値を取得します。
        /// </summary>
        public override bool CanWrite
        {
            get
            {
                return this._stream.CanWrite;
            }
        }

        /// <summary>
        /// ストリームの長さをバイト単位で取得します。
        /// </summary>
        public override long Length
        {
            get
            {
                return this._stream.Length;
            }
        }

        /// <summary>
        /// 現在のストリーム内の位置を取得または設定します。
        /// </summary>
        public override long Position
        {
            get
            {
                return this._stream.Position;
            }

            set
            {
                this._stream.Position = value;
            }
        }
        #endregion

        #region Close
        /// <summary>
        /// 現在のストリームを閉じます。
        /// </summary>
        public override void Close()
        {
            if (this._stream != null)
            {
                this._stream.Close();
                this._stream = null;
            }

            if (this._transactionContext != null)
            {
                if (this._ownedTransaction == true)
                {
                    this._transactionContext.Dispose();
                }

                this._transactionContext = null;
            }
        }
        #endregion

        #region Commit
        /// <summary>
        /// トランザクションをコミットします。
        /// </summary>
        public void Commit()
        {
            Assertion.Require(this._transactionContext != null, "トランザクションが開始していません");
            Assertion.Condition(this._stream != null);

            this._stream.Close();
            this._stream = null;

            if (this._ownedTransaction == true)
            {
                this._transactionContext.Commit();
            }

            this._transactionContext = null;
        }
        #endregion

        #region ToString
        /// <summary>
        /// インスタンスの文字列表現を取得します。
        /// </summary>
        /// <returns>文字列</returns>
        public override string ToString()
        {
            if (this._transactionContext != null)
            {
                return string.Format(
                    "Transaction Context={0}, TargetPath=\"{1}\", TransactionID={2:D}",
                    this._transactionContext.GetType().Name,
                    this._targetPath,
                    this._transactionContext.TransactionID);
            }
            else
            {
                return "Transaction closed";
            }
        }
        #endregion

        #region Stream implementations
        /// <summary>
        /// ストリームに対応するすべてのバッファーをクリアし、バッファー内のデータを基になるデバイスに書き込みます。
        /// </summary>
        public override void Flush()
        {
            this._stream.Flush();
        }

        /// <summary>
        /// 非同期の読み込み動作を開始します。
        /// </summary>
        /// <param name="buffer">データを読み込むバッファー。</param>
        /// <param name="offset">ストリームから読み込んだデータの書き込み開始位置を示す buffer 内のバイト オフセット。</param>
        /// <param name="count">読み取る最大バイト数。</param>
        /// <param name="callback">読み取り完了時に呼び出されるオプションの非同期コールバック。</param>
        /// <param name="state">この特定の非同期読み取り要求を他の要求と区別するために使用するユーザー指定のオブジェクト。</param>
        /// <returns>非同期の読み込みを表す System.IAsyncResult。まだ保留状態の場合もあります。</returns>
        public override IAsyncResult BeginRead(
            byte[] buffer,
            int offset,
            int count,
            AsyncCallback callback,
            object state)
        {
            return this._stream.BeginRead(buffer, offset, count, callback, state);
        }

        /// <summary>
        /// 非同期の書き込み操作を開始します。
        /// </summary>
        /// <param name="buffer">データを書き込む元となるバッファー。</param>
        /// <param name="offset">書き込むデータの開始位置を示す buffer 内のバイト オフセット。</param>
        /// <param name="count">書き込む最大バイト数。</param>
        /// <param name="callback">書き込みの完了時に呼び出されるオプションの非同期コールバック。</param>
        /// <param name="state">この特定の非同期書き込み要求を他の要求と区別するために使用するユーザー指定のオブジェクト。</param>
        /// <returns>非同期の書き込みを表す IAsyncResult。まだ保留状態の場合もあります。</returns>
        public override IAsyncResult BeginWrite(
            byte[] buffer,
            int offset,
            int count,
            AsyncCallback callback,
            object state)
        {
            return this._stream.BeginWrite(buffer, offset, count, callback, state);
        }

        /// <summary>
        /// 保留中の非同期読み取りが完了するまで待機します。
        /// </summary>
        /// <param name="asyncResult">終了させる保留状態の非同期リクエストへの参照。</param>
        /// <returns>ストリームから読み取ったバイト数 (0 ～要求したバイト数の間の数値)。ゼロ (0) が返されるのは、ストリームの末尾で読み取ろうとしたときだけです。それ以外の場合は、少なくとも1 バイトが読み込み可能になるまでブロックします。</returns>
        public override int EndRead(IAsyncResult asyncResult)
        {
            return this._stream.EndRead(asyncResult);
        }

        /// <summary>
        /// 非同期書き込み操作を終了します。
        /// </summary>
        /// <param name="asyncResult">保留状態の非同期 I/O リクエストへの参照。</param>
        public override void EndWrite(IAsyncResult asyncResult)
        {
            this._stream.EndWrite(asyncResult);
        }

        /// <summary>
        /// 現在のストリームからバイト シーケンスを読み取り、読み取ったバイト数の分だけストリームの位置を進めます。
        /// </summary>
        /// <param name="buffer">バイト配列。このメソッドが戻るとき、指定したバイト配列の offset から (offset + count -1) までの値が、現在のソースから読み取られたバイトに置き換えられます。</param>
        /// <param name="offset">現在のストリームから読み取ったデータの格納を開始する位置を示す buffer 内のバイト オフセット。インデックス番号は 0 から始まります。</param>
        /// <param name="count">現在のストリームから読み取る最大バイト数。</param>
        /// <returns>バッファーに読み取られた合計バイト数。要求しただけのバイト数を読み取ることができなかった場合、この値は要求したバイト数より小さくなります。ストリームの末尾に到達した場合は0 (ゼロ) になることがあります。</returns>
        public override int Read(byte[] buffer, int offset, int count)
        {
            return this._stream.Read(buffer, offset, count);
        }

        /// <summary>
        /// 現在のストリームにバイト シーケンスを書き込み、書き込んだバイト数の分だけストリームの現在位置を進めます。
        /// </summary>
        /// <param name="buffer">バイト配列。このメソッドは、buffer から現在のストリームに、count で指定されたバイト数だけコピーします。</param>
        /// <param name="offset">現在のストリームへのバイトのコピーを開始する位置を示す buffer 内のバイト オフセット。インデックス番号は 0 から始まります。</param>
        /// <param name="count">現在のストリームに書き込むバイト数。</param>
        public override void Write(byte[] buffer, int offset, int count)
        {
            this._stream.Write(buffer, offset, count);
        }

        /// <summary>
        /// ストリームから 1 バイトを読み取り、ストリーム内の位置を 1 バイト進めます。ストリームの末尾の場合は -1 を返します。
        /// </summary>
        /// <returns>Int32 にキャストされた符号なしバイト。ストリームの末尾の場合は -1。</returns>
        public override int ReadByte()
        {
            return this._stream.ReadByte();
        }

        /// <summary>
        /// ストリームの現在位置にバイトを書き込み、ストリームの位置を 1 バイトだけ進めます。
        /// </summary>
        /// <param name="value">ストリームに書き込むバイト。</param>
        public override void WriteByte(byte value)
        {
            this._stream.WriteByte(value);
        }

        /// <summary>
        /// 現在のストリーム内の位置を設定します。
        /// </summary>
        /// <param name="offset">origin パラメーターからのバイト オフセット。</param>
        /// <param name="origin">新しい位置を取得するために使用する参照ポイントを示す System.IO.SeekOrigin 型の値。</param>
        /// <returns>現在のストリーム内の新しい位置。</returns>
        public override long Seek(long offset, SeekOrigin origin)
        {
            return this._stream.Seek(offset, origin);
        }

        /// <summary>
        /// 現在のストリームの長さを設定します。
        /// </summary>
        /// <param name="value">現在のストリームの希望の長さ (バイト数)。</param>
        public override void SetLength(long value)
        {
            this._stream.SetLength(value);
        }
        #endregion
    }
}

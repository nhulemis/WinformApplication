﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// ファイルシステムに対応したトランザクションコンテキストを生成するファクトリクラスです。
    /// </summary>
    public static class FileSystemTransactionContextFactory
    {
        // KTMは将来廃止される、らしい？  USE_KTMで切り分けた。
        //   http://msdn.microsoft.com/ja-jp/library/hh802690.aspx
#if USE_KTM
        /// <summary>
        /// KTMが無効かどうかを示します。
        /// </summary>
        private static bool _ktmNotValid;

        /// <summary>
        /// タイプイニシャライザです。
        /// </summary>
        static FileSystemTransactionContextFactory()
        {
            // Vista以前にKTMはない
            OperatingSystem osInformation = Environment.OSVersion;
            _ktmNotValid = osInformation.Version.Major < 6;
        }

        /// <summary>
        /// トランザクションコンテキストを生成します。
        /// </summary>
        /// <returns>トランザクションコンテキスト</returns>
        /// <remarks>システムでKTMが使用出来る場合は、カーネルレベルのトランザクションを管理するコンテキストが生成されます。
        /// また、その際にアンビエントトランザクションがあれば、自動的にDTC管理に昇格します。</remarks>
        public static IFileSystemTransactionContext CreateContext()
        {
            // 無効と分かっている場合はカーネルトランザクションを使用しない（開始に時間がかかるため）
            if (_ktmNotValid == true)
            {
                return new PseudoTransactionContext();
            }

            try
            {
                // カーネルトランザクションコンテキストを返す
                return new KernelTransactionContext();
            }
            // カーネルトランザクションを使えない
            catch (NotSupportedException)
            {
                _ktmNotValid = true;
                return new PseudoTransactionContext();
            }
            // その他の例外の場合、何故KTMが使えないのかが分からないので、無効化はしない
            catch
            {
                return new PseudoTransactionContext();
            }
        }
#else
        /// <summary>
        /// トランザクションコンテキストを生成します。
        /// </summary>
        /// <returns>トランザクションコンテキスト</returns>
        public static IFileSystemTransactionContext CreateContext()
        {
            return new PseudoTransactionContext();
        }
#endif
    }
}

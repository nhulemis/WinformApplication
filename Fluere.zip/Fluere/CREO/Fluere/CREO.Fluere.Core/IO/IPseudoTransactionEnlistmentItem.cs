﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.Reflection;

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// トランザクション操作のためにエンリストメント可能なカプセル化を行うインターフェイスです。
    /// </summary>
    internal interface IPseudoTransactionEnlistmentItem
    {
        /// <summary>
        /// エンリストメントアイテムの名前を取得します。
        /// </summary>
        string Name
        {
            get;
        }

        /// <summary>
        /// 現在のステートを示す文字列を取得します。
        /// </summary>
        string State
        {
            get;
        }

        /// <summary>
        /// エンリストメントアイテムを生成したメソッドを取得します。
        /// </summary>
        MethodBase Creator
        {
            get;
        }

        /// <summary>
        /// フェーズ１コミットを実行します。
        /// </summary>
        /// <remarks>キューの昇順で実行します。</remarks>
        void BeforePreComplete();

        /// <summary>
        /// フェーズ１コミットを実行します。
        /// </summary>
        /// <remarks>キューの逆順で実行します。</remarks>
        void AfterPreComplete();

        /// <summary>
        /// フェーズ２コミットを実行します。
        /// </summary>
        /// <remarks>キューの昇順で実行します。</remarks>
        void BeforeComplete();

        /// <summary>
        /// フェーズ２コミットを実行します。
        /// </summary>
        /// <remarks>キューの逆順で実行します。</remarks>
        void AfterComplete();

        /// <summary>
        /// ロールバックを実行します。
        /// </summary>
        /// <remarks>キューの昇順で実行します。</remarks>
        void BeforeRollback();

        /// <summary>
        /// ロールバックを実行します。
        /// </summary>
        /// <remarks>キューの逆順で実行します。</remarks>
        void AfterRollback();
    }
}

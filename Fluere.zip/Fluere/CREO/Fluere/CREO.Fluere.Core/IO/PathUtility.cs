﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.IO;
using System.Text;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.IO
{
    /// <summary>
    /// パス変換のユーティリティクラスです。
    /// </summary>
    /// <remarks>通常、このクラスを使用する必要はありません。
    /// 設定ファイルに関するパスの変換は、RelativePathAttributeを参照して下さい。</remarks>
    internal static class PathUtility
    {
        /// <summary>
        /// セパレータ文字
        /// </summary>
        private static readonly string SEPARATOR = new string(Path.DirectorySeparatorChar, 1);

        /// <summary>
        /// セパレータ文字
        /// </summary>
        private static readonly string SEPARATOR2 = SEPARATOR + SEPARATOR;

        /// <summary>
        /// 指定されたフォルダパスに対応する、正規化されたUri表現を取得します。
        /// </summary>
        /// <param name="path">パス</param>
        /// <returns>Uri</returns>
        /// <remarks>通常、このメソッドを使用する必要はありません。
        /// 設定ファイルに関するパスの変換は、RelativePathAttributeを参照して下さい。</remarks>
        public static Uri GetNormalizedFolderUri(string path)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(path) == false);

            var fullPath = Path.GetFullPath(path);
            return new Uri((fullPath.EndsWith(SEPARATOR) == true) ?
                fullPath : (fullPath + SEPARATOR));
        }

        /// <summary>
        /// 相対パスに変換します。
        /// </summary>
        /// <param name="path">変換元のパス</param>
        /// <param name="baseFolderUri">基底フォルダを示すUri</param>
        /// <returns>変換したパス</returns>
        /// <remarks>通常、このメソッドを使用する必要はありません。
        /// 設定ファイルに関するパスの変換は、RelativePathAttributeを参照して下さい。</remarks>
        public static string ToRelativePath(string path, Uri baseFolderUri)
        {
            Assertion.Condition(baseFolderUri != null);

            // 変換前文字列を取得
            var currentPath = path;

            // 文字列が存在すれば
            if (string.IsNullOrWhiteSpace(currentPath) == false)
            {
                try
                {
                    // 絶対パス（かもしれない）を相対パスに変換
                    var currentUri = new Uri(baseFolderUri, currentPath);
                    var relativeUri = baseFolderUri.MakeRelativeUri(currentUri);

                    var sb = new StringBuilder(relativeUri.ToString());
                    sb.Replace("file:///", string.Empty).Replace("file://", SEPARATOR2).Replace("+", "%2B").Replace(Path.AltDirectorySeparatorChar, Path.DirectorySeparatorChar);

                    currentPath = Uri.UnescapeDataString(sb.ToString());
                }
                catch
                {
                    // 変換中に例外が発生した場合は、変換を諦める（設定されている値のままとなる）
                }
            }

            return currentPath;
        }

        /// <summary>
        /// 絶対パスに変換します。
        /// </summary>
        /// <param name="path">変換元のパス</param>
        /// <param name="baseFolderUri">基底フォルダを示すUri</param>
        /// <returns>変換したパス</returns>
        /// <remarks>通常、このメソッドを使用する必要はありません。
        /// 設定ファイルに関するパスの変換は、RelativePathAttributeを参照して下さい。</remarks>
        public static string ToAbsolutePath(string path, Uri baseFolderUri)
        {
            Assertion.Condition(baseFolderUri != null);

            // 変換前文字列を取得
            var currentPath = path;

            // 文字列が存在しなければ
            if (string.IsNullOrWhiteSpace(currentPath) == true)
            {
                // （baseFolderUriの）カレントを示す
                currentPath = ".";
            }

            try
            {
                // 相対パス（かもしれない）を絶対パスに変換
                var currentUri = new Uri(baseFolderUri, currentPath);
                currentPath = currentUri.LocalPath;
            }
            catch
            {
                // 変換中に例外が発生した場合は、変換を諦める（設定されている値のままとなる）
            }

            return currentPath;
        }
    }
}

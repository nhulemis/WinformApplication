﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Threading;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// 任意のクラスを実行時に動的にインターフェイス実装させるクラスです。
    /// </summary>
    /// <remarks>インターフェイス型と全く関係の無いクラスのインスタンスに、
    /// 実行時に動的にインターフェイスを実装したかのように扱える、シムクラスを生成します。
    /// 要求したインターフェイスにキャストが可能になりますが、インターフェイスに定義されているプロパティとメソッドは、
    /// 対応するインスタンスにも（同じシグネチャを持つメンバとして）実装されている必要があります。</remarks>
    public static class TypeWrapper
    {
        #region メンバアクセスのためのリフレクション情報群
        /// <summary>
        /// MarshalByRefObjectのコンストラクタを取得します。
        /// </summary>
        private static readonly ConstructorInfo MARSHAL_BY_REF_OBJECT_CONSTRUCTOR =
            typeof(MarshalByRefObject).GetConstructor(
            BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly,
            null,
            Type.EmptyTypes,
            null);

        /// <summary>
        /// ITypeWrapperSurrogatorのToStringメソッドを取得します。
        /// </summary>
        private static readonly MethodInfo TO_STRING_METHOD =
            typeof(ITypeWrapperSurrogator).GetMethod("ToString");

        /// <summary>
        /// IEqualityComparerのGetHashCodeメソッドを取得します。
        /// </summary>
        private static readonly MethodInfo GET_HASH_CODE_METHOD =
            typeof(IEqualityComparer).GetMethod("GetHashCode");

        /// <summary>
        /// IEqualityComparerのEqualsメソッドを取得します。
        /// </summary>
        private static readonly MethodInfo EQUALS_METHOD =
            typeof(IEqualityComparer).GetMethod("Equals");

        /// <summary>
        /// IComparerのCompareメソッドを取得します。
        /// </summary>
        private static readonly MethodInfo COMPARE_METHOD =
            typeof(IComparer).GetMethod("Compare");

        /// <summary>
        /// IComparableのCompareToメソッドを取得します。
        /// </summary>
        private static readonly MethodInfo COMPARE_TO_METHOD =
            typeof(IComparable).GetMethod("CompareTo");

        /// <summary>
        /// ITypeWrapperSurrogatorのInitializeLifetimeServiceメソッドを取得します。
        /// </summary>
        private static readonly MethodInfo INITIALIZE_LIFETIME_SERVICE_METHOD =
            typeof(ITypeWrapperSurrogator).GetMethod("InitializeLifetimeService");

        /// <summary>
        /// TypeWrapperFactoryBaseクラスのコンストラクタを取得します。
        /// </summary>
        private static readonly ConstructorInfo WRAPPER_FACTORY_CONSTRUCTOR =
            typeof(TypeWrapperFactoryBase).GetConstructor(
            BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly,
            null,
            Type.EmptyTypes,
            null);

        /// <summary>
        /// TypeWrapperFactoryBaseクラスのCreateWrapperメソッドを取得します。
        /// </summary>
        private static readonly MethodInfo CREATE_WRAPPER_METHOD =
            typeof(TypeWrapperFactoryBase).GetMethod("CreateWrapper",
            BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.DeclaredOnly);

        /// <summary>
        /// IRealInstanceインターフェイスのgetterメソッドを取得します。
        /// </summary>
        private static readonly MethodInfo REAL_INSTANCE_GETTER_METHOD =
            typeof(IRealInstance).GetProperty("RealInstance").GetGetMethod();
        #endregion

        #region フィールド
        /// <summary>
        /// ラッパーファクトリを定義するアセンブリです。
        /// </summary>
        private static readonly AssemblyBuilder ASSEMBLY_BUILDER;

        /// <summary>
        /// ラッパーファクトリを定義するモジュールです。
        /// </summary>
        private static readonly ModuleBuilder MODULE_BUILDER;

        /// <summary>
        /// ラッパーファクトリを格納する辞書です。
        /// </summary>
        private static readonly Dictionary<TypeWrapperKey, TypeWrapperFactoryBase> WRAPPER_FACTORIES =
            new Dictionary<TypeWrapperKey, TypeWrapperFactoryBase>();

        /// <summary>
        /// ガベージコレクタスレッドです。
        /// </summary>
        private static readonly Thread GARBAGE_COLLECTOR;

        /// <summary>
        /// ガベージコレクションを実行するイベントです。
        /// </summary>
        private static readonly AutoResetEvent TRIGGER_GARBAGE_COLLECT = new AutoResetEvent(false);

        /// <summary>
        /// デフォルトのサロゲータです。
        /// </summary>
        private static readonly ITypeWrapperSurrogator DEFAULT_SURROGATOR = new DefaultSurrogator();
        #endregion

        #region タイプイニシャライザ
        /// <summary>
        /// タイプイニシャライザです。
        /// </summary>
        static TypeWrapper()
        {
            Assertion.Condition(MARSHAL_BY_REF_OBJECT_CONSTRUCTOR != null);
            Assertion.Condition(TO_STRING_METHOD != null);
            Assertion.Condition(GET_HASH_CODE_METHOD != null);
            Assertion.Condition(EQUALS_METHOD != null);
            Assertion.Condition(COMPARE_METHOD != null);
            Assertion.Condition(COMPARE_TO_METHOD != null);
            Assertion.Condition(INITIALIZE_LIFETIME_SERVICE_METHOD != null);
            Assertion.Condition(WRAPPER_FACTORY_CONSTRUCTOR != null);
            Assertion.Condition(CREATE_WRAPPER_METHOD != null);
            Assertion.Condition(REAL_INSTANCE_GETTER_METHOD != null);

            // ラッパーとラッパーファクトリの定義を格納するアセンブリを生成する
            AssemblyName assemblyName = new AssemblyName("TypeWrapper");
#if DEBUG
            ASSEMBLY_BUILDER = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.RunAndSave);
            MODULE_BUILDER = ASSEMBLY_BUILDER.DefineDynamicModule("TypeWrapper.dll");
#else
            ASSEMBLY_BUILDER = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
            MODULE_BUILDER = ASSEMBLY_BUILDER.DefineDynamicModule(assemblyName.Name);
#endif

            // ガベージコレクタを動作させる
            GARBAGE_COLLECTOR = new Thread(GarbageCollectorEntry);
            GARBAGE_COLLECTOR.IsBackground = true;
            GARBAGE_COLLECTOR.Priority = ThreadPriority.BelowNormal;
            GARBAGE_COLLECTOR.Start();
        }
        #endregion

        /// <summary>
        /// アセンブリを保存します。
        /// </summary>
        [Conditional("DEBUG")]
        public static void Save()
        {
            ASSEMBLY_BUILDER.Save("TypeWrapper.dll");
        }

        #region CreateWrapperType
        /// <summary>
        /// ラッパークラスを生成します。
        /// </summary>
        /// <param name="wrapperKey">型の組み合わせを示すキー</param>
        /// <returns>ラッパークラス</returns>
        internal static Type CreateWrapperType(TypeWrapperKey wrapperKey)
        {
            Assertion.Condition(wrapperKey != null);

            // ラッパークラス名を生成する
            // タイプハンドル値は、同じ名前の異なる実装がロードされている場合に重複を避けるため。
            var nameSpace = string.Format(
                "{0}.{1}",
                wrapperKey.ToType.Namespace,
                TypeUtility.SanitizeName(wrapperKey.ToType.Name));
            var typeName = TypeUtility.SanitizeName(wrapperKey.FromType.FullName);
            var realTypeName = string.Format(
                "{0}.{1}_{2}Wrapper_{3}_{4}",
                nameSpace,
                typeName,
                wrapperKey.IsStatic ? "Static" : string.Empty,
                wrapperKey.ToType.TypeHandle.Value,
                wrapperKey.FromType.TypeHandle.Value);

            // ラッパークラスを生成する
            // スタティックラッパーはIRealInstanceを実装しない。
            // メンバーの実際の定義は ITypeWrapperMemberCreator で行う。
            var wrapperType = MODULE_BUILDER.DefineType(
                realTypeName,
                TypeAttributes.NotPublic | TypeAttributes.Sealed | TypeAttributes.Class,
                MARSHAL_BY_REF_OBJECT_CONSTRUCTOR.DeclaringType,
                wrapperKey.IsStatic ? new Type[] { typeof(IWrappedInstance), wrapperKey.ToType } : new Type[] { typeof(IRealInstance), wrapperKey.ToType });

            // ラップクラスにCompilerGeneratedAttributeを適用する
            var compilerGeneratedAttribute =
                TypeUtility.DefineCustomAttribute(typeof(CompilerGeneratedAttribute));
            wrapperType.SetCustomAttribute(compilerGeneratedAttribute);

            // ラップクラスにWrappedTypesAttributeを適用する
            var wrappedTypesAttribute =
                TypeUtility.DefineCustomAttribute(typeof(WrappedTypesAttribute),
                wrapperKey.FromType,
                wrapperKey.ToType,
                wrapperKey.IsStatic);
            wrapperType.SetCustomAttribute(wrappedTypesAttribute);

            // 元のクラスのインスタンスを格納するフィールドを生成する
            // スタティックラッパーの場合は生成しない。
            var realInstanceField =
                wrapperKey.IsStatic ? null :
                wrapperType.DefineField(
                "_realInstance",
                wrapperKey.FromType,
                FieldAttributes.Private);

            // サロゲータのインスタンスを格納するフィールドを生成する
            var surrogatorField = wrapperType.DefineField(
                "_surrogator",
                typeof(ITypeWrapperSurrogator),
                FieldAttributes.Private);

            // インスタンスラッパーなら
            if (wrapperKey.IsStatic == false)
            {
                // 元のクラスのインスタンスを取得するプロパティを生成する
                var realInstanceProperty = wrapperType.DefineProperty(
                    "RealInstance",
                    PropertyAttributes.None,
                    typeof(object),
                    Type.EmptyTypes);

                var realInstanceGetterMethod = wrapperType.DefineMethod(
                    "get_RealInstance",
                    MethodAttributes.Private | MethodAttributes.Virtual,
                    typeof(object),
                    Type.EmptyTypes);

                var generator = realInstanceGetterMethod.GetILGenerator();
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Ldfld, realInstanceField);
                generator.Emit(OpCodes.Ret);

                realInstanceProperty.SetGetMethod(realInstanceGetterMethod);
                wrapperType.DefineMethodOverride(realInstanceGetterMethod, REAL_INSTANCE_GETTER_METHOD);
            }

            // ToStringメソッドを定義する
            TypeWrapperHelper.DefineSurrogationMethod(
                wrapperType,
                "ToString",
                TO_STRING_METHOD,
                realInstanceField,
                surrogatorField);

            // GetHashCodeメソッドを定義する
            TypeWrapperHelper.DefineSurrogationMethod(
                wrapperType,
                "GetHashCode",
                GET_HASH_CODE_METHOD,
                realInstanceField,
                surrogatorField);

            // Equalsメソッドを定義する
            TypeWrapperHelper.DefineSurrogationMethod(
                wrapperType,
                "Equals",
                EQUALS_METHOD,
                realInstanceField,
                surrogatorField);

            // IComparable.CompareToメソッドを定義する
            var compareToMethod = TypeWrapperHelper.DefineSurrogationMethod(
                wrapperType,
                "CompareTo",
                COMPARE_METHOD,
                realInstanceField,
                surrogatorField);
            wrapperType.DefineMethodOverride(compareToMethod, COMPARE_TO_METHOD);

            // InitializeLifetimeServiceメソッドを定義する
            TypeWrapperHelper.DefineSurrogationMethod(
                wrapperType,
                "InitializeLifetimeService",
                INITIALIZE_LIFETIME_SERVICE_METHOD,
                realInstanceField,
                surrogatorField);

            // オーバーライドされたメソッド群の辞書
            var overrided = new HashSet<MethodInfo>();

            // プロパティを生成する
            TypeWrapperMembersCreator.DefineProperties(wrapperKey, wrapperType, realInstanceField, surrogatorField, overrided);

            // イベントを生成する
            TypeWrapperMembersCreator.DefineEvents(wrapperKey, wrapperType, realInstanceField, surrogatorField, overrided);

            // メソッドを生成する
            TypeWrapperMembersCreator.DefineMethods(wrapperKey, wrapperType, realInstanceField, surrogatorField, overrided);

            // コンストラクタを生成する
            ConstructorBuilder constructorBuilder;
            if (wrapperKey.IsStatic == false)
            {
                constructorBuilder = wrapperType.DefineConstructor(
                    MethodAttributes.Public,
                    CallingConventions.Standard,
                    new Type[] { wrapperKey.FromType, typeof(ITypeWrapperSurrogator) });

                var constructorGenerator = constructorBuilder.GetILGenerator();
                constructorGenerator.Emit(OpCodes.Ldarg_0);
                constructorGenerator.Emit(OpCodes.Call, MARSHAL_BY_REF_OBJECT_CONSTRUCTOR);
                constructorGenerator.Emit(OpCodes.Ldarg_0);
                constructorGenerator.Emit(OpCodes.Ldarg_1);
                constructorGenerator.Emit(OpCodes.Stfld, realInstanceField);
                constructorGenerator.Emit(OpCodes.Ldarg_0);
                constructorGenerator.Emit(OpCodes.Ldarg_2);
                constructorGenerator.Emit(OpCodes.Stfld, surrogatorField);
                constructorGenerator.Emit(OpCodes.Ret);
            }
            else
            {
                constructorBuilder = wrapperType.DefineConstructor(
                    MethodAttributes.Public,
                    CallingConventions.Standard,
                    new Type[] { typeof(ITypeWrapperSurrogator) });

                var constructorGenerator = constructorBuilder.GetILGenerator();
                constructorGenerator.Emit(OpCodes.Ldarg_0);
                constructorGenerator.Emit(OpCodes.Call, MARSHAL_BY_REF_OBJECT_CONSTRUCTOR);
                constructorGenerator.Emit(OpCodes.Ldarg_0);
                constructorGenerator.Emit(OpCodes.Ldarg_1);
                constructorGenerator.Emit(OpCodes.Stfld, surrogatorField);
                constructorGenerator.Emit(OpCodes.Ret);
            }

            // クラスを生成する
            return wrapperType.CreateType();
        }
        #endregion

        #region CreateWrapperFactoryType
        /// <summary>
        /// ラッパーファクトリクラスを生成します。
        /// </summary>
        /// <param name="wrapperKey">型の組み合わせを示すキー</param>
        /// <param name="wrapperType">対象のラッパークラス</param>
        /// <param name="isStatic">スタティックラッパーならtrue</param>
        /// <returns>ラッパーファクトリクラス</returns>
        internal static Type CreateWrapperFactoryType(TypeWrapperKey wrapperKey, Type wrapperType, bool isStatic)
        {
            Assertion.Condition(wrapperKey != null);
            Assertion.Condition(wrapperType != null);
            Assertion.Condition(wrapperType.IsClass == true);
            Assertion.Condition(wrapperType.IsAbstract == false);

            // ラッパーファクトリクラスを生成する
            var wrapperFactoryType = MODULE_BUILDER.DefineType(
                wrapperType.FullName + "_Factory",
                TypeAttributes.Public | TypeAttributes.Sealed | TypeAttributes.Class,
                isStatic ? typeof(TypeWrapperStaticFactoryBase) : typeof(TypeWrapperInstanceFactoryBase),
                Type.EmptyTypes);

            // ラップクラスにDebuggerNonUserCodeAttributeを適用する
            var debuggerNonUserCodeAttribute =
                TypeUtility.DefineCustomAttribute(typeof(DebuggerNonUserCodeAttribute));
            wrapperFactoryType.SetCustomAttribute(debuggerNonUserCodeAttribute);

            // ラッパークラスのコンストラクタを取得する
            var ci = wrapperType.GetConstructor(
                isStatic ?
                    new Type[] { typeof(ITypeWrapperSurrogator) } :
                    new Type[] { wrapperKey.FromType, typeof(ITypeWrapperSurrogator) });
            Assertion.Condition(ci != null);

            // CreateWrapperメソッドを生成する
            var createWrapper = wrapperFactoryType.DefineMethod(
                CREATE_WRAPPER_METHOD.Name,
                MethodAttributes.Family | MethodAttributes.Virtual,
                CREATE_WRAPPER_METHOD.CallingConvention,
                CREATE_WRAPPER_METHOD.ReturnType,
                new Type[] { typeof(object), typeof(ITypeWrapperSurrogator) });

            var generator = createWrapper.GetILGenerator();

            // return new WrapperType((FromType)instance, surrogator);
            if (isStatic == false)
            {
                generator.Emit(OpCodes.Ldarg_1);
                generator.Emit(OpCodes.Castclass, wrapperKey.FromType);
            }
            else
            {
            }

            generator.Emit(OpCodes.Ldarg_2);
            generator.Emit(OpCodes.Newobj, ci);
            generator.Emit(OpCodes.Ret);

            // デフォルトコンストラクタを生成する
            wrapperFactoryType.DefineDefaultConstructor(MethodAttributes.Public);

            // クラスを生成する
            return wrapperFactoryType.CreateType();
        }
        #endregion

        #region CreateWrapperFactory
        /// <summary>
        /// 指定された型の組み合わせに対応するファクトリを生成します。
        /// </summary>
        /// <param name="wrapperKey">型の組み合わせを示すキー</param>
        /// <returns>ファクトリ</returns>
        internal static TypeWrapperFactoryBase CreateWrapperFactory(TypeWrapperKey wrapperKey)
        {
            Assertion.Condition(wrapperKey != null);

            var wrapperType = CreateWrapperType(wrapperKey);

            Assertion.Condition(wrapperType != null);
            Assertion.Condition(wrapperType.IsClass == true);
            Assertion.Condition(wrapperType.IsAbstract == false);
            Assertion.Condition(wrapperType.IsSealed == true);

            var wrapperFactoryType = CreateWrapperFactoryType(
                wrapperKey,
                wrapperType,
                wrapperKey.IsStatic);

            Assertion.Condition(wrapperFactoryType != null);
            Assertion.Condition(wrapperFactoryType.IsClass == true);
            Assertion.Condition(wrapperFactoryType.IsAbstract == false);
            Assertion.Condition(wrapperFactoryType.IsSealed == true);

            return (TypeWrapperFactoryBase)Activator.CreateInstance(wrapperFactoryType);
        }
        #endregion

        #region GetWrapperFactory
        /// <summary>
        /// 指定された型の組み合わせに対応するファクトリを取得します。
        /// </summary>
        /// <param name="wrapperKey">型の組み合わせを示すキー</param>
        /// <returns>ファクトリ</returns>
        internal static TypeWrapperFactoryBase GetWrapperFactory(TypeWrapperKey wrapperKey)
        {
            Assertion.Condition(wrapperKey != null);

            lock (WRAPPER_FACTORIES)
            {
                TypeWrapperFactoryBase factory;
                if (WRAPPER_FACTORIES.TryGetValue(wrapperKey, out factory) == false)
                {
                    factory = CreateWrapperFactory(wrapperKey);
                    WRAPPER_FACTORIES.Add(wrapperKey, factory);
                }

                return factory;
            }
        }
        #endregion

        #region Cleanup
        /// <summary>
        /// TypeWrapperが保持している不要な辞書エントリを削除します。
        /// </summary>
        /// <returns>削除されたエントリの比</returns>
        internal static double Cleanup()
        {
            // ラッパーファクトリ辞書のロック期間を削減するため、一旦リストに抽出する
            List<TypeWrapperFactoryBase> list;
            lock (WRAPPER_FACTORIES)
            {
                if (WRAPPER_FACTORIES.Count == 0)
                {
                    return 0;
                }

                list = new List<TypeWrapperFactoryBase>(WRAPPER_FACTORIES.Values);
            }

            Assertion.Condition(list.Count >= 1);

            // それぞれのファクトリ内をクリーンアップする
            double ratioSum = 0;
            for (var i = 0; i < list.Count; i++)
            {
                ratioSum += list[i].Cleanup();
            }

            return ratioSum / (double)list.Count;
        }
        #endregion

        #region Unsafe accessors
        /// <summary>
        /// 指定されたインスタンスのラッパーインスタンスを取得します。
        /// </summary>
        /// <typeparam name="T">ラップするインターフェイス型</typeparam>
        /// <param name="instance">ラップ対象のインスタンス</param>
        /// <param name="surrogator">インターフェイスの特定に使用するサロゲータ</param>
        /// <returns>ラップされたインスタンス</returns>
        /// <remarks>このメソッドは内部で使用します。
        /// パフォーマンスに影響するチェックを行いません。</remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        [DebuggerNonUserCode]
        public static T UnsafeGetWrapper<T>(object instance, ITypeWrapperSurrogator surrogator)
        {
            // このメソッドは、生成したラッパークラスの内部実装から呼び出される。
            // 例えば、ラッパークラスのプロパティの型が動的に共変性をサポートする場合（getter）、
            // このメソッドを呼び出して、元のインスタンスをラップする。
            // そのため、このメソッドでは引数チェックを行わない（内部チェックも行わない）。
            // サロゲータが返却するインスタンスのチェックだけがリスクとして残る。
            // （但し、その場合も、InvalidCastExceptionがスローされるだけで、誤動作はしない）

            // nullならnullを返す
            if (instance == null)
            {
                return default(T);
            }

            // そのままキャスト可能なら
            if (instance is T)
            {
                // そのまま返す
                return (T)instance;
            }

            // このインスタンスはラップ済みなら
            var realType = instance.GetType();
            if (instance is IRealInstance)
            {
                // デバッグビルドでのみチェック
                Assertion.Condition<TypeWrapperException>(
                    typeof(T).IsAssignableFrom(realType) == true,
                    "返却しようとしているインスタンス {0} はラップされていますが、{1} にキャスト可能ではありません",
                    realType.FullName,
                    typeof(T).FullName);

                // そのまま返す
                return (T)instance;
            }

            // サロゲータを使用して、より実装に適したインターフェイスを特定する
            var interfaceType = surrogator.GetTargetType(realType, typeof(T));

            // デバッグビルドでのみチェック
            Assertion.Condition<TypeWrapperException>(
                typeof(T).IsAssignableFrom(interfaceType) == true,
                "サロゲータが返却したインターフェイス {0} は、{1} にキャスト可能ではありません",
                interfaceType.FullName,
                typeof(T).FullName);

            // ラッパーファクトリを取得する
            var factory = GetWrapperFactory(new TypeWrapperKey(realType, interfaceType, false));

            // インスタンスを取得する
            return (T)factory.GetWrapper(instance, surrogator);
        }

        /// <summary>
        /// 指定されたラッパーインスタンスから、元のインスタンスを取得します。
        /// </summary>
        /// <typeparam name="T">元のインスタンスに相当する型</typeparam>
        /// <param name="instance">インスタンス</param>
        /// <returns>元のインスタンス</returns>
        /// <remarks>ラップされていない場合はそのまま返します。
        /// 通常、このメソッドを使う事はありません。パフォーマンスに影響するチェックを行いません。</remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        [DebuggerNonUserCode]
        public static T UnsafeUnwrap<T>(object instance)
        {
            var retrievedInstance = instance;

            // このインスタンスはラップ済みなら
            var real = retrievedInstance as IRealInstance;
            if (real != null)
            {
                retrievedInstance = real.RealInstance;
            }

            // デバッグビルドでのみチェック
            Assertion.Condition<TypeWrapperException>(
                (retrievedInstance is T) || (retrievedInstance == null),
                "返却しようとしているインスタンス {0} は、{1} にキャスト可能ではありません",
                retrievedInstance.GetType().FullName,
                typeof(T).FullName);

            return (T)retrievedInstance;
        }
        #endregion

        #region GetWrapper
        /// <summary>
        /// 指定されたインスタンスのラッパーインスタンスを取得します。
        /// </summary>
        /// <param name="toType">ラップするインターフェイス型</param>
        /// <param name="instance">ラップ対象のインスタンス</param>
        /// <param name="surrogator">インターフェイスの特定に使用するサロゲータ</param>
        /// <returns>ラップされたインスタンス</returns>
        /// <remarks>同じラップ対象のインスタンスでも、要求するインターフェイス型が異なる場合は、
        /// 返されるインスタンスは同一になりません。
        /// そのため、インスタンスの参照を比較する場合は注意が必要です。
        /// 但しEqualsメソッドは実装されており、ラップ対象のインスタンスのEqualsが呼び出されるため、
        /// Equalsで比較する場合は安全です。</remarks>
        [DebuggerNonUserCode]
        public static object GetWrapper(Type toType, object instance, ITypeWrapperSurrogator surrogator)
        {
            Assertion.NullArgument(toType, "ラップするインターフェイス型が必要です");
            Assertion.Argument(toType.IsInterface == true, "ラップするインターフェイス型が必要です");
            Assertion.NullArgument(surrogator, "サロゲータが必要です");

            // nullならnullを返す
            if (instance == null)
            {
                return null;
            }

            // そのままキャスト可能なら
            if (toType.IsInstanceOfType(instance) == true)
            {
                // そのまま返す
                return instance;
            }

            // このインスタンスはラップ済みなら
            var realType = instance.GetType();
            if (instance is IRealInstance)
            {
                Assertion.Require<TypeWrapperException>(
                    toType.IsAssignableFrom(realType) == true,
                    "返却しようとしているインスタンス {0} はラップされていますが、{1} にキャスト可能ではありません",
                    realType.FullName,
                    toType.FullName);

                // そのまま返す
                return instance;
            }

            // サロゲータを使用して、より実装に適したインターフェイスを特定する
            var interfaceType = surrogator.GetTargetType(realType, toType);

            Assertion.Require<TypeWrapperException>(
                toType.IsAssignableFrom(interfaceType) == true,
                "サロゲータが返却したインターフェイス {0} は、{1} にキャスト可能ではありません",
                interfaceType.FullName,
                toType.FullName);

            // ラッパーファクトリを取得する
            var factory = GetWrapperFactory(new TypeWrapperKey(realType, interfaceType, false));

            // インスタンスを取得する
            return factory.GetWrapper(instance, surrogator);
        }

        /// <summary>
        /// 指定されたインスタンスのラッパーインスタンスを取得します。
        /// </summary>
        /// <param name="toType">ラップするインターフェイス型</param>
        /// <param name="instance">ラップ対象のインスタンス</param>
        /// <returns>ラップされたインスタンス</returns>
        /// <remarks>同じラップ対象のインスタンスでも、要求するインターフェイス型が異なる場合は、
        /// 返されるインスタンスは同一になりません。
        /// そのため、インスタンスの参照を比較する場合は注意が必要です。
        /// 但しEqualsメソッドは実装されており、ラップ対象のインスタンスのEqualsが呼び出されるため、
        /// Equalsで比較する場合は安全です。</remarks>
        [DebuggerNonUserCode]
        public static object GetWrapper(Type toType, object instance)
        {
            return GetWrapper(toType, instance, DEFAULT_SURROGATOR);
        }

        /// <summary>
        /// 指定されたインスタンスのラッパーインスタンスを取得します。
        /// </summary>
        /// <typeparam name="T">ラップするインターフェイス型</typeparam>
        /// <param name="instance">ラップ対象のインスタンス</param>
        /// <param name="surrogator">インターフェイスの特定に使用するサロゲータ</param>
        /// <returns>ラップされたインスタンス</returns>
        /// <remarks>同じラップ対象のインスタンスでも、要求するインターフェイス型が異なる場合は、
        /// 返されるインスタンスは同一になりません。
        /// そのため、インスタンスの参照を比較する場合は注意が必要です。
        /// 但しEqualsメソッドは実装されており、ラップ対象のインスタンスのEqualsが呼び出されるため、
        /// Equalsで比較する場合は安全です。</remarks>
        [DebuggerNonUserCode]
        public static T GetWrapper<T>(object instance, ITypeWrapperSurrogator surrogator)
            where T : class
        {
            return (T)GetWrapper(typeof(T), instance, surrogator);
        }

        /// <summary>
        /// 指定されたインスタンスのラッパーインスタンスを取得します。
        /// </summary>
        /// <typeparam name="T">ラップするインターフェイス型</typeparam>
        /// <param name="instance">ラップ対象のインスタンス</param>
        /// <returns>ラップされたインスタンス</returns>
        /// <remarks>同じラップ対象のインスタンスでも、要求するインターフェイス型が異なる場合は、
        /// 返されるインスタンスは同一になりません。
        /// そのため、インスタンスの参照を比較する場合は注意が必要です。
        /// 但しEqualsメソッドは実装されており、ラップ対象のインスタンスのEqualsが呼び出されるため、
        /// Equalsで比較する場合は安全です。</remarks>
        [DebuggerNonUserCode]
        public static T GetWrapper<T>(object instance)
            where T : class
        {
            return GetWrapper<T>(instance, DEFAULT_SURROGATOR);
        }
        #endregion

        #region CreateStaticWrapper
        /// <summary>
        /// 指定されたクラスの静的なメンバに対応するラッパーインスタンスを取得します。
        /// </summary>
        /// <typeparam name="T">ラップするインターフェイス型</typeparam>
        /// <param name="targetClass">ラップ対象のクラスを示す型</param>
        /// <param name="surrogator">インターフェイスの特定に使用するサロゲータ</param>
        /// <returns>ラップされたインスタンス</returns>
        /// <remarks>同じラップ対象のインスタンスでも、要求するインターフェイス型が異なる場合は、
        /// 返されるインスタンスは同一になりません。
        /// そのため、インスタンスの参照を比較する場合は注意が必要です。
        /// 但しEqualsメソッドは実装されており、ラップ対象のインスタンスのEqualsが呼び出されるため、
        /// Equalsで比較する場合は安全です。</remarks>
        [DebuggerNonUserCode]
        public static T CreateStaticWrapper<T>(Type targetClass, ITypeWrapperSurrogator surrogator)
            where T : class
        {
            Assertion.NullArgument(targetClass, "対象のクラスが必要です");
            Assertion.Argument(targetClass.IsClass == true, "対象のクラスが必要です");

            var toType = typeof(T);
            Assertion.Argument(toType.IsInterface == true, "ラップするインターフェイス型が必要です");

            // サロゲータを使用して、より実装に適したインターフェイスを特定する
            var interfaceType = surrogator.GetTargetType(targetClass, toType);

            Assertion.Require<TypeWrapperException>(
                toType.IsAssignableFrom(interfaceType) == true,
                "サロゲータが返却したインターフェイス {0} は、{1} にキャスト可能ではありません",
                interfaceType.FullName,
                toType.FullName);

            // ラッパーファクトリを取得する
            var factory = GetWrapperFactory(new TypeWrapperKey(targetClass, interfaceType, true));

            // インスタンスを取得する
            return (T)factory.GetWrapper(null, surrogator);
        }

        /// <summary>
        /// 指定されたクラスの静的なメンバに対応するラッパーインスタンスを取得します。
        /// </summary>
        /// <typeparam name="T">ラップするインターフェイス型</typeparam>
        /// <param name="targetClass">ラップ対象のクラスを示す型</param>
        /// <returns>ラップされたインスタンス</returns>
        /// <remarks>同じラップ対象のインスタンスでも、要求するインターフェイス型が異なる場合は、
        /// 返されるインスタンスは同一になりません。
        /// そのため、インスタンスの参照を比較する場合は注意が必要です。
        /// 但しEqualsメソッドは実装されており、ラップ対象のインスタンスのEqualsが呼び出されるため、
        /// Equalsで比較する場合は安全です。</remarks>
        [DebuggerNonUserCode]
        public static T CreateStaticWrapper<T>(Type targetClass)
            where T : class
        {
            return CreateStaticWrapper<T>(targetClass, DEFAULT_SURROGATOR);
        }

        /// <summary>
        /// 指定されたクラスの静的なメンバに対応するラッパーインスタンスを取得します。
        /// </summary>
        /// <typeparam name="T">ラップするインターフェイス型</typeparam>
        /// <typeparam name="U">ラップ対象のクラスを示す型</typeparam>
        /// <param name="surrogator">インターフェイスの特定に使用するサロゲータ</param>
        /// <returns>ラップされたインスタンス</returns>
        /// <remarks>同じラップ対象のインスタンスでも、要求するインターフェイス型が異なる場合は、
        /// 返されるインスタンスは同一になりません。
        /// そのため、インスタンスの参照を比較する場合は注意が必要です。
        /// 但しEqualsメソッドは実装されており、ラップ対象のインスタンスのEqualsが呼び出されるため、
        /// Equalsで比較する場合は安全です。</remarks>
        [DebuggerNonUserCode]
        public static T CreateStaticWrapper<T, U>(ITypeWrapperSurrogator surrogator)
            where T : class
            where U : class
        {
            return CreateStaticWrapper<T>(typeof(U), surrogator);
        }

        /// <summary>
        /// 指定されたクラスの静的なメンバに対応するラッパーインスタンスを取得します。
        /// </summary>
        /// <typeparam name="T">ラップするインターフェイス型</typeparam>
        /// <typeparam name="U">ラップ対象のクラスを示す型</typeparam>
        /// <returns>ラップされたインスタンス</returns>
        /// <remarks>同じラップ対象のインスタンスでも、要求するインターフェイス型が異なる場合は、
        /// 返されるインスタンスは同一になりません。
        /// そのため、インスタンスの参照を比較する場合は注意が必要です。
        /// 但しEqualsメソッドは実装されており、ラップ対象のインスタンスのEqualsが呼び出されるため、
        /// Equalsで比較する場合は安全です。</remarks>
        [DebuggerNonUserCode]
        public static T CreateStaticWrapper<T, U>()
            where T : class
            where U : class
        {
            return CreateStaticWrapper<T>(typeof(U), DEFAULT_SURROGATOR);
        }
        #endregion

        #region Unwrap
        /// <summary>
        /// 指定されたラッパーインスタンスから、元のインスタンスを取得します。
        /// </summary>
        /// <param name="instance">インスタンス</param>
        /// <returns>元のインスタンス</returns>
        /// <remarks>ラップされていない場合はそのまま返します。
        /// 通常、このメソッドを使う事はありません。</remarks>
        [DebuggerNonUserCode]
        public static object Unwrap(object instance)
        {
            // このインスタンスはラップ済みなら
            var real = instance as IRealInstance;
            if (real != null)
            {
                return real.RealInstance;
            }

            return instance;
        }

        /// <summary>
        /// 指定されたラッパーインスタンスから、元のインスタンスを取得します。
        /// </summary>
        /// <typeparam name="T">元のインスタンスに相当する型</typeparam>
        /// <param name="instance">インスタンス</param>
        /// <returns>元のインスタンス</returns>
        /// <remarks>ラップされていない場合はそのまま返します。
        /// 通常、このメソッドを使う事はありません。</remarks>
        [DebuggerNonUserCode]
        public static T Unwrap<T>(object instance)
        {
            var retrievedInstance = instance;

            // このインスタンスはラップ済みなら
            var real = retrievedInstance as IRealInstance;
            if (real != null)
            {
                retrievedInstance = real.RealInstance;
            }

            Assertion.Require<TypeWrapperException>(
                (retrievedInstance is T) || (retrievedInstance == null),
                "返却しようとしているインスタンス {0} は、{1} にキャスト可能ではありません",
                retrievedInstance.GetType().FullName,
                typeof(T).FullName);

            return (T)retrievedInstance;
        }
        #endregion

        #region Collect
        /// <summary>
        /// TypeWrapperが保持している不要な辞書エントリを削除します。
        /// </summary>
        [DebuggerNonUserCode]
        public static void Collect()
        {
            TRIGGER_GARBAGE_COLLECT.Set();
        }
        #endregion

        #region GarbageCollectorEntry
        /// <summary>
        /// ガベージコレクタスレッドのエントリポイントです。
        /// </summary>
        private static void GarbageCollectorEntry()
        {
            Thread.CurrentThread.Name = "TypeWrapper.GarbageCollector";

            var timeout = 10000;
            while (true)
            {
                // 待機する
                TRIGGER_GARBAGE_COLLECT.WaitOne(timeout);

                // クリーンアップを実行する
                var ratio = Cleanup();

                // 削除したエントリの比率が高いほど、次のタイムアウトを短くする
                timeout = (int)(10000 - (10000 * ratio));
                if (timeout < 0)
                {
                    timeout = 0;
                }
            }
        }
        #endregion
    }
}

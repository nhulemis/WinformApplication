﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// 辞書のインターフェイスを簡略化したインターフェイスです。
    /// </summary>
    /// <typeparam name="T">キーとなる型</typeparam>
    /// <typeparam name="U">値となる型</typeparam>
    /// <remarks>このインターフェイスは内部で使用します。
    /// 実際の辞書の型を隠蔽するために使用します。</remarks>
    internal interface ISimpleDictionary<T, U>
    {
        /// <summary>
        /// 辞書に値を追加します。
        /// </summary>
        /// <param name="key">キー</param>
        /// <param name="value">値</param>
        void Add(T key, U value);

        /// <summary>
        /// 辞書に値があるかどうかを調べます。
        /// </summary>
        /// <param name="key">キー</param>
        /// <param name="value">見つかった場合の値</param>
        /// <returns>見つかればtrue</returns>
        bool TryGetValue(T key, out U value);
    }
}

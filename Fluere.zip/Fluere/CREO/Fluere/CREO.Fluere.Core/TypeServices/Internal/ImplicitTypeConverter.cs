﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

using System;
using System.ComponentModel;
using System.Globalization;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// 暗黙の型変換が可能な場合に実変換処理を行わないタイプコンバータです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class ImplicitTypeConverter : TypeConverter
    {
        /// <summary>
        /// 型
        /// </summary>
        private readonly Type _type;

        /// <summary>
        /// タイプコンバータ
        /// </summary>
        private readonly TypeConverter _typeConverter;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="type">変換対象の型</param>
        /// <param name="typeConverter">内包するタイプコンバータ</param>
        public ImplicitTypeConverter(Type type, TypeConverter typeConverter)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(typeConverter != null);

            this._type = type;
            this._typeConverter = typeConverter;
        }

        /// <summary>
        /// 指定されたインスタンスを、このタイプコンバータの型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            if (value == null)
            {
                return null;
            }

            var type = value.GetType();
            if (this._type.IsAssignableFrom(type) == true)
            {
                return value;
            }

            return this._typeConverter.ConvertFrom(context, culture, value);
        }

        /// <summary>
        /// 指定されたタイプコンバータが識別する型のインスタンスを、指定された型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <param name="destinationType">変換する型</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            // 未テスト
            if (value == null)
            {
                return null;
            }

            var type = value.GetType();
            if (destinationType.IsAssignableFrom(type) == true)
            {
                return value;
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
    }
}

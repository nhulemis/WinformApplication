﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Reflection.Emit;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// ILコード生成を行うヘルパクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal static class ILEmitters
    {
        /// <summary>
        /// Ldarg用のオペコード定義群です。
        /// </summary>
        private static readonly OpCode[] LDARG_VARIABLES =
            new OpCode[] { OpCodes.Ldarg_0, OpCodes.Ldarg_1, OpCodes.Ldarg_2, OpCodes.Ldarg_3, OpCodes.Ldarg_S, OpCodes.Ldarg };

        /// <summary>
        /// Ldloc用のオペコード定義群です。
        /// </summary>
        private static readonly OpCode[] LDLOC_VARIABLES =
            new OpCode[] { OpCodes.Ldloc_0, OpCodes.Ldloc_1, OpCodes.Ldloc_2, OpCodes.Ldloc_3, OpCodes.Ldloc_S, OpCodes.Ldloc };

        /// <summary>
        /// Stloc用のオペコード定義群です。
        /// </summary>
        private static readonly OpCode[] STLOC_VARIABLES =
            new OpCode[] { OpCodes.Stloc_0, OpCodes.Stloc_1, OpCodes.Stloc_2, OpCodes.Stloc_3, OpCodes.Stloc_S, OpCodes.Stloc };

        /// <summary>
        /// Ldind用のオペコード辞書です。
        /// </summary>
        private static readonly IDictionary<Type, OpCode> LDIND_DICTIONARY = new Dictionary<Type, OpCode>();

        /// <summary>
        /// Stind用のオペコード辞書です。
        /// </summary>
        private static readonly IDictionary<Type, OpCode> STIND_DICTIONARY = new Dictionary<Type, OpCode>();

        /// <summary>
        /// タイプイニシャライザです。
        /// </summary>
        static ILEmitters()
        {
            // 辞書の生成
            LDIND_DICTIONARY.Add(typeof(byte), OpCodes.Ldind_U1);
            LDIND_DICTIONARY.Add(typeof(sbyte), OpCodes.Ldind_I1);
            LDIND_DICTIONARY.Add(typeof(ushort), OpCodes.Ldind_U2);
            LDIND_DICTIONARY.Add(typeof(short), OpCodes.Ldind_I2);
            LDIND_DICTIONARY.Add(typeof(uint), OpCodes.Ldind_U4);
            LDIND_DICTIONARY.Add(typeof(int), OpCodes.Ldind_I4);
            LDIND_DICTIONARY.Add(typeof(ulong), OpCodes.Ldind_I8);   // 間違いではない
            LDIND_DICTIONARY.Add(typeof(long), OpCodes.Ldind_I8);
            LDIND_DICTIONARY.Add(typeof(float), OpCodes.Ldind_R4);
            LDIND_DICTIONARY.Add(typeof(double), OpCodes.Ldind_R8);

            STIND_DICTIONARY.Add(typeof(byte), OpCodes.Stind_I1);
            STIND_DICTIONARY.Add(typeof(sbyte), OpCodes.Stind_I1);
            STIND_DICTIONARY.Add(typeof(ushort), OpCodes.Stind_I2);
            STIND_DICTIONARY.Add(typeof(short), OpCodes.Stind_I2);
            STIND_DICTIONARY.Add(typeof(uint), OpCodes.Stind_I4);
            STIND_DICTIONARY.Add(typeof(int), OpCodes.Stind_I4);
            STIND_DICTIONARY.Add(typeof(ulong), OpCodes.Stind_I8);
            STIND_DICTIONARY.Add(typeof(long), OpCodes.Stind_I8);
            STIND_DICTIONARY.Add(typeof(float), OpCodes.Stind_R4);
            STIND_DICTIONARY.Add(typeof(double), OpCodes.Stind_R8);
        }

        /// <summary>
        /// オペランドのインデックスに応じて最適なオペコードを発行します。
        /// </summary>
        /// <param name="generator">ジェネレータ</param>
        /// <param name="index">インデックス</param>
        /// <param name="opCodes">オペコード群</param>
        private static void EmitVariable(ILGenerator generator, int index, OpCode[] opCodes)
        {
            Assertion.Condition(generator != null);
            Assertion.Condition((index >= 0) && (index <= 65534));
            Assertion.Condition(opCodes != null);
            Assertion.Condition(opCodes.Length == 6);

            switch (index)
            {
                case 0:
                    generator.Emit(opCodes[0]);
                    break;
                case 1:
                    generator.Emit(opCodes[1]);
                    break;
                case 2:
                    generator.Emit(opCodes[2]);
                    break;
                case 3:
                    generator.Emit(opCodes[3]);
                    break;
                default:
                    // 255ではなく225
                    if ((index >= 4) && (index <= 225))
                    {
                        generator.Emit(opCodes[4], (byte)index);
                    }
                    else
                    {
                        generator.Emit(opCodes[5], (ushort)index);
                    }

                    break;
            }
        }

        /// <summary>
        /// Ldargオペコードを発行します。
        /// </summary>
        /// <param name="generator">ジェネレータ</param>
        /// <param name="index">インデックス</param>
        public static void EmitLdarg(ILGenerator generator, int index)
        {
            EmitVariable(generator, index, LDARG_VARIABLES);
        }

        /// <summary>
        /// Ldlocオペコードを発行します。
        /// </summary>
        /// <param name="generator">ジェネレータ</param>
        /// <param name="index">インデックス</param>
        public static void EmitLdloc(ILGenerator generator, int index)
        {
            EmitVariable(generator, index, LDLOC_VARIABLES);
        }

        /// <summary>
        /// Stlocオペコードを発行します。
        /// </summary>
        /// <param name="generator">ジェネレータ</param>
        /// <param name="index">インデックス</param>
        public static void EmitStloc(ILGenerator generator, int index)
        {
            EmitVariable(generator, index, STLOC_VARIABLES);
        }

        /// <summary>
        /// Ldindオペコードを発行します。
        /// </summary>
        /// <param name="generator">ジェネレータ</param>
        /// <param name="targetType">対象の型</param>
        public static void EmitLdind(ILGenerator generator, Type targetType)
        {
            OpCode opCode;
            if (LDIND_DICTIONARY.TryGetValue(targetType, out opCode) == false)
            {
                opCode = OpCodes.Ldind_Ref;
            }

            generator.Emit(opCode);
        }

        /// <summary>
        /// Stindオペコードを発行します。
        /// </summary>
        /// <param name="generator">ジェネレータ</param>
        /// <param name="targetType">対象の型</param>
        public static void EmitStind(ILGenerator generator, Type targetType)
        {
            OpCode opCode;
            if (STIND_DICTIONARY.TryGetValue(targetType, out opCode) == false)
            {
                opCode = OpCodes.Stind_Ref;
            }

            generator.Emit(opCode);
        }
    }
}

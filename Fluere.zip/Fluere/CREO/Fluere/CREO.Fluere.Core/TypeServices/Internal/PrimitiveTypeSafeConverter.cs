﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

using System;
using System.ComponentModel;
using System.Globalization;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// プリミティブ型の相互変換を直接実行出来るタイプコンバータのラッパークラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class PrimitiveTypeSafeConverter : TypeConverter
    {
        /// <summary>
        /// 目標の型
        /// </summary>
        private readonly Type _targetType;

        /// <summary>
        /// 元のタイプコンバータ
        /// </summary>
        private readonly TypeConverter _original;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="targetType">このコンバータが対応する型</param>
        /// <param name="original">このコンバータがラップするタイプコンバータ</param>
        public PrimitiveTypeSafeConverter(Type targetType, TypeConverter original)
        {
            Assertion.Condition(targetType != null);
            Assertion.Condition(targetType.IsPrimitive == true);
            Assertion.Condition(original != null);

            this._targetType = targetType;
            this._original = original;
        }

        /// <summary>
        /// 指定されたインスタンスを、このタイプコンバータの型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            var rawValue = NullableExtractor.Extract(value);
            if (rawValue == null)
            {
                return null;
            }

            var type = rawValue.GetType();
            if (type.IsPrimitive == true)
            {
                return Convert.ChangeType(rawValue, this._targetType, culture);
            }

            return this._original.ConvertFrom(context, culture, rawValue);
        }

        /// <summary>
        /// 指定されたタイプコンバータが識別する型のインスタンスを、指定された型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <param name="destinationType">変換する型</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            // 未テスト
            if (value != null)
            {
                var type = value.GetType();
                if (type.IsPrimitive == true)
                {
                    return Convert.ChangeType(value, destinationType, culture);
                }
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// メンバのメタデータを操作するユーティリティクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal static class MemberList
    {
        /// <summary>
        /// 指定された型のメンバキャッシュを削除します。
        /// </summary>
        /// <param name="type">型</param>
        /// <param name="memberCacheMemberName">メンバキャッシュのメンバ名</param>
        /// <remarks>このメソッドは内部で使用します。
        /// メンバ取得時に、キャッシュの状態によって結果の並びが一定にならない場合があるため、
        /// このメソッドでメンバキャッシュを削除します。</remarks>
        internal static void FlushMemberInfoCache(Type type, string memberCacheMemberName)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(string.IsNullOrWhiteSpace(memberCacheMemberName) == false);

            // 注意：Typeをロックしても、このメソッドは安全だが、他からの操作を排除できない
            lock (type)
            {
                var typeCacheType = type.GetType();
                var cacheProperty = typeCacheType.GetProperty(
                    "Cache",
                    BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.NonPublic);
                Assertion.Condition(cacheProperty != null);

                var cache = cacheProperty.GetValue(type, null);
                Assertion.Condition(cache != null);

                var cacheType = cache.GetType();
                var memberCacheField = cacheType.GetField(
                    memberCacheMemberName,
                    BindingFlags.FlattenHierarchy | BindingFlags.Instance | BindingFlags.NonPublic);
                Assertion.Condition(memberCacheField != null);

                memberCacheField.SetValue(cache, null);
            }
        }

        /// <summary>
        /// 指定された型に定義されているメンバを収集します。
        /// </summary>
        /// <typeparam name="T">メンバ情報の型</typeparam>
        /// <param name="members">結果を格納するコレクション</param>
        /// <param name="memberInfos">メンバの列挙子</param>
        /// <param name="memberInfoOperator">メンバ情報オペレータ</param>
        public static void GetList<T>(
            ISimpleDictionary<OverridedMemberKey, IList<T>> members,
            IEnumerable<T> memberInfos,
            IMemberInfoOperator<T> memberInfoOperator)
            where T : MemberInfo
        {
            Assertion.Condition(members != null);
            Assertion.Condition(memberInfos != null);
            Assertion.Condition(memberInfoOperator != null);

            // メンバを列挙
            foreach (T memberInfo in memberInfos)
            {
                // このメンバがまだ収集されていなければ
                var key = new OverridedMemberKey(memberInfo.Name,
                    memberInfoOperator.GetMemberType(memberInfo),
                    memberInfoOperator.GetParameters(memberInfo).Select(parameterInfo => parameterInfo.ParameterType).ToArray());
                IList<T> list;
                if (members.TryGetValue(key, out list) == false)
                {
                    // 新規にリストを作成（今のところオーバーライドされていない）
                    list = new List<T>();
                    members.Add(key, list);

                    // リストに追加
                    list.Add(memberInfo);
                }
                else
                {
                    // 既に存在する（オーバーライドされている）
                    // リストに存在しなければ追加
                    // 線形探索だが、オーバーライドが大量にあるとは思えないので、このままとする。
                    if (list.Contains(memberInfo) == false)
                    {
                        list.Add(memberInfo);
                    }
                }
            }
        }

        /// <summary>
        /// 指定されたクラスが継承する全てのクラスとインターフェイスに定義されているメンバをオーバーライド毎に収集します。
        /// </summary>
        /// <typeparam name="T">メンバ情報の型</typeparam>
        /// <param name="members">収集したメンバ情報を格納するコレクション</param>
        /// <param name="type">対象の型</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <param name="memberInfoOperator">メンバ情報オペレータ</param>
        /// <remarks>メンバはオーバーライドされている可能性があるため、
        /// オーバーライド毎にグループを形成して収集します。
        /// 各オーバーライドの識別には、OverridedMemberKeyクラスを使用します。</remarks>
        public static void GetListByOverrided<T>(
            ISimpleDictionary<OverridedMemberKey, IList<T>> members,
            Type type,
            bool isStatic,
            IMemberInfoOperator<T> memberInfoOperator)
            where T : MemberInfo
        {
            Assertion.Condition(type != null);
            Assertion.Condition(type.IsClass == true);
            Assertion.Condition(memberInfoOperator != null);

            // オーバーライドの可能性のあるメンバをオーバーライド別に列挙する
            var currentType = type;
            while (true)
            {
                // このクラスに定義されているメンバの収集
                GetList(members, memberInfoOperator.GetMembers(currentType, isStatic), memberInfoOperator);

                // このクラスが直接実装しているインターフェイスの列挙
                foreach (var interfaceType in currentType.GetInterfaces())
                {
                    Assertion.Condition(interfaceType.IsInterface == true);

                    // このインターフェイスに定義されているプロパティの収集
                    GetList(members, memberInfoOperator.GetMembers(interfaceType, isStatic), memberInfoOperator);
                }

                // これがobject型なら抜ける
                if (currentType == typeof(object))
                {
                    break;
                }

                // 継承階層を辿る
                currentType = currentType.BaseType;
            }
        }

        /// <summary>
        /// 指定された型が実装する全てのインターフェイスに定義されているメンバをオーバーライド毎に収集します。
        /// </summary>
        /// <typeparam name="T">メンバ情報の型</typeparam>
        /// <param name="members">収集したメンバ情報を格納するコレクション</param>
        /// <param name="interfaceTypes">インターフェイスのリスト</param>
        /// <param name="memberInfoOperator">メンバ情報オペレータ</param>
        /// <remarks>メンバはオーバーライドされている可能性があるため、
        /// オーバーライド毎にグループを形成して収集します。
        /// 各オーバーライドの識別には、OverridedMemberKeyクラスを使用します。</remarks>
        public static void GetImplementedListByOverrided<T>(
            ISimpleDictionary<OverridedMemberKey, IList<T>> members,
            IEnumerable<Type> interfaceTypes,
            IMemberInfoOperator<T> memberInfoOperator)
            where T : MemberInfo
        {
            Assertion.Condition(members != null);
            Assertion.Condition(interfaceTypes != null);
            Assertion.Condition(memberInfoOperator != null);

            // オーバーライドの可能性のあるメンバをオーバーライド別に列挙する
            foreach (var interfaceType in interfaceTypes)
            {
                Assertion.Argument(
                    interfaceType.IsInterface == true,
                    "型 {0} はインターフェイスではありません",
                    interfaceType.FullName);

                // このインターフェイスに定義されているメンバの収集
                GetList(members, memberInfoOperator.GetMembers(interfaceType, false), memberInfoOperator);
            }
        }
    }
}

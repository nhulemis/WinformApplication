﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

using System.Collections.Generic;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// 辞書としてDictionaryジェネリッククラスを使用する、ISimpleDictionaryの実装です。
    /// </summary>
    /// <typeparam name="T">キーとなる型</typeparam>
    /// <typeparam name="U">値となる型</typeparam>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal class DictionaryWrapper<T, U> : ISimpleDictionary<T, U>
    {
        // TypeWrapperを使いたくなるが再帰してしまうので使えない

        /// <summary>
        /// 辞書
        /// </summary>
        private readonly Dictionary<T, U> _dictionary = new Dictionary<T, U>();

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public DictionaryWrapper()
        {
        }

        /// <summary>
        /// 内包する辞書を取得します。
        /// </summary>
        public IDictionary<T, U> RealDictionary
        {
            get
            {
                return this._dictionary;
            }
        }

        /// <summary>
        /// 辞書に値を追加します。
        /// </summary>
        /// <param name="key">キー</param>
        /// <param name="value">値</param>
        public virtual void Add(T key, U value)
        {
            this._dictionary.Add(key, value);
        }

        /// <summary>
        /// 辞書に値があるかどうかを調べます。
        /// </summary>
        /// <param name="key">キー</param>
        /// <param name="value">見つかった場合の値</param>
        /// <returns>見つかればtrue</returns>
        public bool TryGetValue(T key, out U value)
        {
            return this._dictionary.TryGetValue(key, out value);
        }
    }
}

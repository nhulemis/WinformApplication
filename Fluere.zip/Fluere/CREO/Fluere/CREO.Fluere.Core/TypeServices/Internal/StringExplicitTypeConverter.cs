﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

using System;
using System.ComponentModel;
using System.Globalization;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// 文字列のnullをnullとして扱うタイプコンバータです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。
    /// 標準のStringConverterはnullを空文字列に変換するため、このクラスを使用します。</remarks>
    internal sealed class StringExplicitTypeConverter : TypeConverter
    {
        /// <summary>
        /// 指定されたインスタンスを、このタイプコンバータの型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            if (value is string)
            {
                return value;
            }

            var rawValue = NullableExtractor.Extract(value);
            if (rawValue == null)
            {
                return null;
            }

            var convertible = rawValue as IConvertible;
            if (convertible != null)
            {
                return convertible.ToString(culture);
            }

            var formattable = rawValue as IFormattable;
            if (formattable != null)
            {
                return formattable.ToString(null, culture);
            }

            return rawValue.ToString();
        }

        /// <summary>
        /// 指定されたタイプコンバータが識別する型のインスタンスを、指定された型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <param name="destinationType">変換する型</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            // 未テスト
            if (value != null)
            {
                var type = value.GetType();
                if (type.IsPrimitive == true)
                {
                    return Convert.ChangeType(value, destinationType, culture);
                }
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
    }
}

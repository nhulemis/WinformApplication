﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.22 TMI K.Matsui

using System;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// フィールド情報を取得するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class FieldInfoOperator : IValueAccessOperator<FieldInfo>
    {
        /// <summary>
        /// 空のパラメータ情報群です。
        /// </summary>
        /// <remarks>イベント情報を収集する際に使用します。</remarks>
        private static readonly ParameterInfo[] EMPTY_PARAMETERS = new ParameterInfo[0];

        /// <summary>
        /// 指定された型に定義されているフィールド情報群を取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <returns>フィールド情報群</returns>
        public FieldInfo[] GetMembers(Type type, bool isStatic)
        {
            Assertion.Condition(type != null);

            // プロパティではキャッシュをクリアしているが、フィールドは順序を維持する必要がないのでクリアしない
            // MemberList.FlushMemberInfoCache(type, "m_fieldInfoCache");
            return type.GetFields(
                BindingFlags.Public | BindingFlags.DeclaredOnly |
                (isStatic ? BindingFlags.Static : BindingFlags.Instance));
        }

        /// <summary>
        /// 指定されたフィールドがジェネリックかどうかを取得します。
        /// </summary>
        /// <param name="memberInfo">フィールド情報</param>
        /// <returns>フィールドにジェネリック構築は存在しないので、常にfalse</returns>
        public bool IsGenericMember(FieldInfo memberInfo)
        {
            return false;
        }

        /// <summary>
        /// フィールドを表現する型を取得します。
        /// </summary>
        /// <param name="memberInfo">フィールド情報</param>
        /// <returns>フィールド型</returns>
        public Type GetMemberType(FieldInfo memberInfo)
        {
            Assertion.Condition(memberInfo != null);

            return memberInfo.FieldType;
        }

        /// <summary>
        /// フィールドのパラメータ情報群を取得します。
        /// </summary>
        /// <param name="memberInfo">プロパティ情報</param>
        /// <returns>常に空の配列</returns>
        /// <remarks>フィールドにパラメータは存在しないので、常に空の配列が返されます。</remarks>
        public ParameterInfo[] GetParameters(FieldInfo memberInfo)
        {
            Assertion.Condition(memberInfo != null);

            return EMPTY_PARAMETERS;
        }

        /// <summary>
        /// 指定されたフィールドから値を取得します。
        /// </summary>
        /// <param name="memberInfo">プロパティ情報</param>
        /// <param name="instance">インスタンス</param>
        /// <returns>値</returns>
        public object GetValue(FieldInfo memberInfo, object instance)
        {
            Assertion.Condition(memberInfo != null);

            return memberInfo.GetValue(instance);
        }
    }
}

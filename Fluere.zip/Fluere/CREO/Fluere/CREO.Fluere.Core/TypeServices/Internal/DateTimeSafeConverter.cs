﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.17 TMI K.Matsui

using System;
using System.ComponentModel;
using System.Globalization;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// DateTime型の相互変換を実行出来るタイプコンバータのラッパークラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class DateTimeSafeConverter : TypeConverter
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public DateTimeSafeConverter()
        {
        }

        /// <summary>
        /// 指定されたインスタンスを、このタイプコンバータの型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context, CultureInfo culture, object value)
        {
            var rawValue = NullableExtractor.Extract(value);
            if (rawValue == null)
            {
                return null;
            }

            var type = rawValue.GetType();
            if (type == typeof(DateTime))
            {
                return rawValue;
            }

            if (type.IsPrimitive == true)
            {
                var converted = Convert.ToDouble(rawValue, culture);
                return DateTime.FromOADate(converted);
            }
            else if (type == typeof(string))
            {
                DateTime dateTimeValue;
                if (DateTime.TryParse(
                    (string)rawValue,
                    culture,
                    DateTimeStyles.AssumeLocal | DateTimeStyles.AllowInnerWhite | DateTimeStyles.AllowLeadingWhite | DateTimeStyles.AllowTrailingWhite | DateTimeStyles.AllowWhiteSpaces | DateTimeStyles.NoCurrentDateDefault,
                    out dateTimeValue) == true)
                {
                    return dateTimeValue;
                }

                var converted = Convert.ToDouble(rawValue, culture);
                return DateTime.FromOADate(converted);
            }

            return base.ConvertFrom(context, culture, rawValue);
        }

        /// <summary>
        /// 指定されたタイプコンバータが識別する型のインスタンスを、指定された型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <param name="destinationType">変換する型</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertTo(
            ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType)
        {
            // 未テスト
            if (value != null)
            {
                var type = value.GetType();
                if (type.IsPrimitive == true)
                {
                    if (type == typeof(DateTime))
                    {
                        return value;
                    }

                    return Convert.ChangeType(value, destinationType, culture);
                }
            }

            return base.ConvertTo(context, culture, value, destinationType);
        }
    }
}

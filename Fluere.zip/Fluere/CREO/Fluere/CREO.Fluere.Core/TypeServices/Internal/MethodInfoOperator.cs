﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// メソッド情報を取得するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class MethodInfoOperator : IMemberInfoOperator<MethodInfo>
    {
        /// <summary>
        /// 指定された型に定義されているメソッド情報群を取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <returns>メソッド情報群</returns>
        public MethodInfo[] GetMembers(Type type, bool isStatic)
        {
            Assertion.Condition(type != null);

            // プロパティではキャッシュをクリアしているが、メソッドは順序を維持する必要がないのでクリアしない
            // （なお、メソッドキャッシュをクリアした場合は、それが割り当てられているプロパティ・イベントの整合性も
            // 確保する必要があるためクリアしなければならない）
            // MemberList.FlushMemberInfoCache(type, "m_methodInfoCache");
            return type.GetMethods(BindingFlags.Public | BindingFlags.DeclaredOnly |
                (isStatic ? BindingFlags.Static : BindingFlags.Instance));
        }

        /// <summary>
        /// 指定されたメソッドがジェネリックかどうかを取得します。
        /// </summary>
        /// <param name="memberInfo">メソッド情報</param>
        /// <returns>ジェネリックメソッドならtrue</returns>
        public bool IsGenericMember(MethodInfo memberInfo)
        {
            return memberInfo.IsGenericMethod;
        }

        /// <summary>
        /// メソッドを表現する型を取得します。
        /// </summary>
        /// <param name="memberInfo">メソッド情報</param>
        /// <returns>メソッド戻り値の型</returns>
        public Type GetMemberType(MethodInfo memberInfo)
        {
            Assertion.Condition(memberInfo != null);

            return memberInfo.ReturnType;
        }

        /// <summary>
        /// メソッドのパラメータ情報群を取得します。
        /// </summary>
        /// <param name="memberInfo">メソッド情報</param>
        /// <returns>パラメータ情報群</returns>
        public ParameterInfo[] GetParameters(MethodInfo memberInfo)
        {
            Assertion.Condition(memberInfo != null);

            return memberInfo.GetParameters();
        }
    }
}

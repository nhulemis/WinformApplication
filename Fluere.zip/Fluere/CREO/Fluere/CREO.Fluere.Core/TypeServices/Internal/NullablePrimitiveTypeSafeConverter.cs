﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

using System;
using System.ComponentModel;
using System.Globalization;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// Nullableの内包型がプリミティブ型の相互変換を直接実行出来るタイプコンバータのラッパークラスです。
    /// </summary>
    /// <typeparam name="T">Nullableが内包する型（プリミティブ型）</typeparam>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class NullablePrimitiveTypeSafeConverter<T> : TypeConverter
        where T : struct
    {
        /// <summary>
        /// 元のタイプコンバータ
        /// </summary>
        private readonly TypeConverter _original;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="original">このコンバータがラップするタイプコンバータ</param>
        public NullablePrimitiveTypeSafeConverter(TypeConverter original)
        {
            Assertion.Condition(typeof(T).IsPrimitive == true);
            Assertion.Condition(original != null);

            this._original = original;
        }

        /// <summary>
        /// 指定されたインスタンスを、このタイプコンバータの型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertFrom(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value)
        {
            if ((value == null) || (string.Empty.Equals(value) == true))
            {
                return new T?();
            }

            var converted = this._original.ConvertFrom(context, culture, value);
            if (converted == null)
            {
                return new T?();
            }

            var newValue = new T?((T)converted);
            return newValue;
        }

        /// <summary>
        /// 指定されたタイプコンバータが識別する型のインスタンスを、指定された型に変換します。
        /// </summary>
        /// <param name="context">タイプデスクリプタコンテキスト</param>
        /// <param name="culture">カルチャ情報</param>
        /// <param name="value">インスタンス</param>
        /// <param name="destinationType">変換する型</param>
        /// <returns>変換したインスタンス</returns>
        public override object ConvertTo(
            ITypeDescriptorContext context,
            CultureInfo culture,
            object value,
            Type destinationType)
        {
            // 未テスト
            var rawValue = value;

            var nullableValue = (T?)rawValue;
            if (nullableValue.HasValue == true)
            {
                rawValue = nullableValue.Value;
            }

            return this._original.ConvertTo(context, culture, rawValue, destinationType);
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

using System.Collections.Generic;

using CREO.Fluere.Common.Collections;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// 辞書としてListジェネリッククラスを使用する、ISimpleDictionaryの実装です。
    /// </summary>
    /// <typeparam name="T">キーとなる型</typeparam>
    /// <typeparam name="U">値となる型</typeparam>
    /// <remarks>このクラスは内部で使用します。
    /// TryGetValueには、DictionaryWrapperの実装が使用されます。</remarks>
    internal sealed class ListWrapper<T, U> : DictionaryWrapper<T, U>
    {
        /// <summary>
        /// リスト
        /// </summary>
        private readonly List<KeyValuePair<T, U>> _list = new List<KeyValuePair<T, U>>();

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public ListWrapper()
        {
        }

        /// <summary>
        /// 内包するリストを取得します。
        /// </summary>
        public IEnumerable<KeyValuePair<T, U>> RealList
        {
            get
            {
                return this._list;
            }
        }

        /// <summary>
        /// 辞書に値を追加します。
        /// </summary>
        /// <param name="key">キー</param>
        /// <param name="value">値</param>
        public override void Add(T key, U value)
        {
            base.Add(key, value);
            this._list.Add(KeyValuePair.Create(key, value));
        }
    }
}

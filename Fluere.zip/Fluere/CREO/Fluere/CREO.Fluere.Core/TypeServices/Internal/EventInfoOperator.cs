﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices.Internal
{
    /// <summary>
    /// イベント情報を取得するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class EventInfoOperator : IMemberInfoOperator<EventInfo>
    {
        /// <summary>
        /// 空のパラメータ情報群です。
        /// </summary>
        /// <remarks>イベント情報を収集する際に使用します。</remarks>
        private static readonly ParameterInfo[] EMPTY_PARAMETERS = new ParameterInfo[0];

        /// <summary>
        /// 指定された型に定義されているイベント情報群を取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <returns>イベント情報群</returns>
        public EventInfo[] GetMembers(Type type, bool isStatic)
        {
            Assertion.Condition(type != null);

            // プロパティではキャッシュをクリアしているが、イベントは順序を維持する必要がないのでクリアしない
            // MemberList.FlushMemberInfoCache(type, "m_eventInfoCache");
            return type.GetEvents(BindingFlags.Public | BindingFlags.DeclaredOnly |
                (isStatic ? BindingFlags.Static : BindingFlags.Instance));
        }

        /// <summary>
        /// 指定されたイベントがジェネリックかどうかを取得します。
        /// </summary>
        /// <param name="memberInfo">イベント情報</param>
        /// <returns>イベントにジェネリック構築は存在しないので、常にfalse</returns>
        public bool IsGenericMember(EventInfo memberInfo)
        {
            return false;
        }

        /// <summary>
        /// イベントを表現する型を取得します。
        /// </summary>
        /// <param name="memberInfo">イベント情報</param>
        /// <returns>イベントハンドラ型</returns>
        public Type GetMemberType(EventInfo memberInfo)
        {
            Assertion.Condition(memberInfo != null);

            return memberInfo.EventHandlerType;
        }

        /// <summary>
        /// イベントのパラメータ情報群を取得します。
        /// </summary>
        /// <param name="memberInfo">プロパティ情報</param>
        /// <returns>常に空の配列</returns>
        /// <remarks>イベントにパラメータは存在しないので、常に空の配列が返されます。</remarks>
        public ParameterInfo[] GetParameters(EventInfo memberInfo)
        {
            Assertion.Condition(memberInfo != null);

            return EMPTY_PARAMETERS;
        }
    }
}

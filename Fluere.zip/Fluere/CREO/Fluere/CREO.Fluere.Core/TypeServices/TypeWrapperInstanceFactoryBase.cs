﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.22 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Diagnostics;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// TypeWrapperでインスタンスラッパーのインスタンスを生成するファクトリの基底クラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    [DebuggerNonUserCode]
    public abstract class TypeWrapperInstanceFactoryBase : TypeWrapperFactoryBase
    {
        /// <summary>
        /// 参照IDからWeakReferenceを特定するための辞書です。
        /// </summary>
        private readonly Dictionary<int, WeakReference> _instances = new Dictionary<int, WeakReference>();

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        protected TypeWrapperInstanceFactoryBase()
        {
        }

        /// <summary>
        /// 辞書をクリーンアップします。
        /// </summary>
        /// <returns>削除されたエントリの比</returns>
        /// <remarks>不要なWeakReferenceを辞書から削除します。</remarks>
        public override double Cleanup()
        {
            lock (this._instances)
            {
                if (this._instances.Count == 0)
                {
                    return 0;
                }

                // インスタンスが破棄されているエントリを収集する
                var list = new List<int>();
                foreach (var entry in this._instances)
                {
                    if (entry.Value.IsAlive == false)
                    {
                        list.Add(entry.Key);
                    }
                }

                // 無ければ終了
                if (list.Count == 0)
                {
                    return 0;
                }

                // 辞書から削除
                for (var i = 0; i < list.Count; i++)
                {
                    this._instances.Remove(list[i]);
                }

                return (double)list.Count / (double)this._instances.Count;
            }
        }

        /// <summary>
        /// 指定されたインスタンスのラッパーインスタンスを取得します。
        /// </summary>
        /// <param name="instance">インスタンス</param>
        /// <param name="surrogator">サロゲータ</param>
        /// <returns>ラッパーインスタンス</returns>
        public override object GetWrapper(object instance, ITypeWrapperSurrogator surrogator)
        {
            Assertion.Condition(surrogator != null);

            // nullならnullを返す
            if (instance == null)
            {
                return null;
            }

            // 参照IDを取得する
            var id = TypeUtility.GetReferenceID(instance);

            lock (this._instances)
            {
                // 辞書から参照IDに該当するWeakReferenceを取得する
                object wrapper = null;
                WeakReference weak;
                if (this._instances.TryGetValue(id, out weak) == false)
                {
                    // 無い場合は新規に生成
                    wrapper = this.CreateWrapper(instance, surrogator);
                    weak = new WeakReference(wrapper);
                    this._instances.Add(id, weak);
                }
                else
                {
                    // エントリはあったがインスタンスが無い
                    wrapper = weak.Target;
                    if (wrapper == null)
                    {
                        // 生成
                        wrapper = this.CreateWrapper(instance, surrogator);
                        weak.Target = wrapper;
                    }
                }

                return wrapper;
            }
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Reflection;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// メンバ情報を取得するインターフェイスです。
    /// </summary>
    /// <typeparam name="T">対象のメンバ情報</typeparam>
    /// <remarks>このインターフェイスは内部で使用します。
    /// MemberInfoクラスの共通のビューを提供します。</remarks>
    internal interface IMemberInfoOperator<T>
        where T : MemberInfo
    {
        /// <summary>
        /// 指定された型に定義されているメンバ情報群を取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <returns>メンバ情報群</returns>
        T[] GetMembers(Type type, bool isStatic);

        /// <summary>
        /// 指定されたメンバがジェネリックかどうかを取得します。
        /// </summary>
        /// <param name="memberInfo">メンバ情報</param>
        /// <returns>メンバがジェネリックならtrue</returns>
        bool IsGenericMember(T memberInfo);

        /// <summary>
        /// メンバを表現する型を取得します。
        /// </summary>
        /// <param name="memberInfo">メンバ情報</param>
        /// <returns>メンバを表現する型（メソッド戻り値型・プロパティ型・イベントハンドラ型）</returns>
        Type GetMemberType(T memberInfo);

        /// <summary>
        /// メンバのパラメータ情報群を取得します。
        /// </summary>
        /// <param name="memberInfo">メンバ情報</param>
        /// <returns>パラメータ情報群</returns>
        ParameterInfo[] GetParameters(T memberInfo);
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.Serialization;
using System.Text;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// 型のメタデータを操作するユーティリティクラスです。
    /// </summary>
    public static class TypeUtility
    {
        #region フィールド
        /// <summary>
        /// 無効な文字のリストです。
        /// </summary>
        internal static readonly char[] INVALID_NAME_CHARS = new char[]
        {
            '!', '"', '#', '$', '%', '&', '\'', '(', ')', '=',
            '-', '~', '|', '\\', '^', '`', '{', '}', '[', ']',
            '@', '+', '*', ';', ':', '<', '>', ',', '.', '?',
            '/', ' '
        };

        /// <summary>
        /// 参照のIDを取得するメソッドへのデリゲートです。
        /// </summary>
        private static readonly Func<object, int> GET_REFERENCE_ID;

        /// <summary>
        /// 空のインデクサ引数配列です。
        /// </summary>
        private static readonly object[] EMPTY_INDEXES = new object[0];

        /// <summary>
        /// GetGenericArgumentsByTargetGenericDefinitionTypeで使用する検索済みのリスト
        /// </summary>
        private static readonly ConcurrentDictionary<Tuple<Type, Type>, Type[]> INTERFACE_LIST =
            new ConcurrentDictionary<Tuple<Type, Type>, Type[]>(new TupleComparer());
        #endregion

        #region タイプイニシャライザ
        /// <summary>
        /// タイプイニシャライザです。
        /// </summary>
        static TypeUtility()
        {
            // GetReferenceIDメソッドを生成する
            var getReferenceIDMethod = new DynamicMethod(
                "GetReferenceID", typeof(int), new Type[] { typeof(object) }, typeof(TypeUtility));

            var generator = getReferenceIDMethod.GetILGenerator();
            generator.Emit(OpCodes.Ldarg_0);

            var getHashCodeMethod = typeof(object).GetMethod("GetHashCode");
            Assertion.Condition(getHashCodeMethod != null);

            generator.Emit(OpCodes.Call, getHashCodeMethod);
            generator.Emit(OpCodes.Ret);

            GET_REFERENCE_ID = (Func<object, int>)getReferenceIDMethod.CreateDelegate(
                typeof(Func<object, int>));
        }
        #endregion

        #region SanitizeName
        /// <summary>
        /// 文字列から問題のある文字を削除します。
        /// </summary>
        /// <param name="fromName">型名などの文字列</param>
        /// <returns>削除した文字列</returns>
        public static string SanitizeName(string fromName)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(fromName) == false, "文字列が必要です");

            var sb = new StringBuilder(fromName);
            var index = 0;
            while (true)
            {
                var position = fromName.IndexOfAny(INVALID_NAME_CHARS, index);
                if (position == -1)
                {
                    break;
                }

                sb[position] = '_';
                index = position + 1;
            }

            return sb.ToString();
        }
        #endregion

        #region SafeToString
        /// <summary>
        /// 安全な文字列変換を実行します。
        /// </summary>
        /// <param name="value">変換するインスタンス、又はnull</param>
        /// <returns>文字列</returns>
        /// <remarks>対象がnullの場合は"(null)"、DBNullの場合は"(DBNull)"、文字列の場合はダブルクオートされます。</remarks>
        public static string SafeToString(object value)
        {
            object rawValue;
            if (NullableExtractor.Extract(value, out rawValue) == false)
            {
                rawValue = value;
            }

            if (rawValue == null)
            {
                return "(null)";
            }

            if (DBNull.Value.Equals(rawValue) == true)
            {
                return "(DBNull)";
            }

            if (rawValue is string)
            {
                return string.Format("\"{0}\"", rawValue);
            }

            var convertible = rawValue as IConvertible;
            if (convertible != null)
            {
                return convertible.ToString(CultureInfo.InvariantCulture);
            }

            return rawValue.ToString();
        }
        #endregion

        #region GetReferenceID
        /// <summary>
        /// 指定されたインスタンスの参照IDを取得します。
        /// </summary>
        /// <param name="target">インスタンス</param>
        /// <returns>参照ID</returns>
        [DebuggerNonUserCode]
        public static int GetReferenceID(object target)
        {
            return GET_REFERENCE_ID(target);
        }
        #endregion

        #region GetDefaultValue
        /// <summary>
        /// 指定された型に対応するデフォルト値のインスタンスを取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <returns>デフォルト値</returns>
        public static object GetDefaultValue(Type type)
        {
            Assertion.Condition(type != null);

            // 値型なら
            if (type.IsValueType == true)
            {
                return FormatterServices.GetUninitializedObject(type);
            }
            else
            {
                // それ以外
                return null;
            }
        }
        #endregion

        #region GetGenericArgumentsByTargetGenericDefinitionType
        /// <summary>
        /// 指定された型を探索し、ジェネリック型の引数の型群を取得します。
        /// </summary>
        /// <param name="type">基点となる型</param>
        /// <param name="compareGenericDefinitionType">目標となるジェネリック型の定義型</param>
        /// <returns>ジェネリック型があればその引数の型。実装していなければnull</returns>
        /// <remarks>例えば、List&lt;int&gt;クラスがIEnumerable&lt;&gt;を実装しているかどうかを確認出来ます。
        /// 実装している場合、戻り値によって、ジェネリックインターフェイスの引数型を取得する事ができます。</remarks>
        public static Type[] GetGenericArgumentsByTargetGenericDefinitionType(
            Type type,
            Type compareGenericDefinitionType)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(compareGenericDefinitionType != null);
            Assertion.Condition(compareGenericDefinitionType.IsGenericTypeDefinition == true);

            return
                INTERFACE_LIST.GetOrAdd(
                    Tuple.Create(type, compareGenericDefinitionType),
                    entry =>
                    {
                        // 指定された型が実装するインターフェイス群を探索する
                        foreach (var baseInterfaceType in entry.Item1.GetInterfaces())
                        {
                            // 再帰する
                            var results = GetGenericArgumentsByTargetGenericDefinitionType(
                                baseInterfaceType,
                                entry.Item2);

                            // 見つかっていれば抜ける
                            if (results != null)
                            {
                                return results;
                            }
                        }

                        // この型がジェネリック型なら
                        if (entry.Item1.IsGenericType == true)
                        {
                            // この型（具象インターフェイス）からジェネリック型の定義型を得る
                            var genericDefinitionType = entry.Item1.GetGenericTypeDefinition();

                            // この型がターゲットの型なら
                            if (genericDefinitionType == entry.Item2)
                            {
                                // ジェネリック型引数群を返す
                                return entry.Item1.GetGenericArguments();
                            }
                        }

                        // この型にはない
                        return null;
                    });
        }
        #endregion

        #region GetImplementedInterfaceList
        /// <summary>
        /// 指定されたインターフェイスを収集します。
        /// </summary>
        /// <param name="interfaceType">対象のインターフェイス</param>
        /// <param name="collectedList">収集したインターフェイスを格納するリスト</param>
        /// <param name="baseIndex">検索の基点となるリストのインデックス</param>
        private static void TraverseInterface(Type interfaceType, List<Type> collectedList, int baseIndex)
        {
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);
            Assertion.Condition(collectedList != null);
            Assertion.Condition(baseIndex <= collectedList.Count);

            // 未発見のインターフェイスなら
            var index = collectedList.IndexOf(interfaceType);
            if (index == -1)
            {
                // 終端に追加する
                collectedList.Add(interfaceType);

                // 再帰探索する
                TraverseInterfaceList(interfaceType, collectedList, collectedList.Count);
            }
            else
            {
                // 発見済みのインターフェイスなら
                // 基底のインデックスより前方に発見したら
                if (index < baseIndex)
                {
                    // 終端に移動する
                    collectedList.RemoveAt(index);
                    collectedList.Add(interfaceType);
                }
            }
        }

        /// <summary>
        /// 指定された型に実装しているインターフェイスを収集します。
        /// </summary>
        /// <param name="type">対象の型</param>
        /// <param name="collectedList">収集したインターフェイスを格納するリスト</param>
        /// <param name="baseIndex">検索の基点となるリストのインデックス</param>
        private static void TraverseInterfaceList(Type type, List<Type> collectedList, int baseIndex)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(collectedList != null);
            Assertion.Condition(baseIndex <= collectedList.Count);

            // 型に実装するインターフェイスを列挙する
            foreach (var interfaceType in type.GetInterfaces())
            {
                TraverseInterface(interfaceType, collectedList, baseIndex);
            }
        }

        /// <summary>
        /// 指定された型が実装する全てのインターフェイスの一意なリストを取得します。
        /// </summary>
        /// <param name="type">対象の型</param>
        /// <returns>インターフェイス型を示すリスト</returns>
        /// <remarks>インターフェイスのリストは、インターフェイス継承の末端（指定された型）に近い順に列挙されます。</remarks>
        public static IEnumerable<Type> GetImplementedInterfaceList(Type type)
        {
            Assertion.Condition(type != null);

            var collectedList = new List<Type>();

            // 指定された型がインターフェイスなら
            if (type.IsInterface == true)
            {
                // インターフェイスを探索する
                TraverseInterface(type, collectedList, 0);
            }
            else
            {
                // インターフェイスのリストを探索する
                TraverseInterfaceList(type, collectedList, 0);
            }

            return collectedList;
        }
        #endregion

        #region PropertiesPredicator
        /// <summary>
        /// 指定されたインスタンスのプロパティ群に対して処理を実行します。
        /// </summary>
        /// <typeparam name="T">インスタンス1の型</typeparam>
        /// <typeparam name="U">インスタンス2の型</typeparam>
        /// <param name="lhs">インスタンス1</param>
        /// <param name="rhs">インスタンス2</param>
        /// <param name="predict">プロパティ毎に処理を行うデリゲート（処理を中断する場合はtrue）</param>
        /// <remarks>インスタンスには代入互換性がなければなりません。
        /// また、プロパティはインターフェイスに定義されていなければなりません。
        /// プロパティはインデクサでないものだけが対象です。</remarks>
        internal static void PropertiesPredicator<T, U>(T lhs, U rhs, Action<PropertyInfo> predict)
            where T : class
            where U : class, T
        {
            Assertion.NullArgument(lhs, "インスタンスが必要です");
            Assertion.NullArgument(rhs, "インスタンスが必要です");
            Assertion.NullArgument(predict, "処理を行うデリゲートが必要です");

            foreach (var entry in PropertyList.GetImplementedListByOverrided(typeof(T)))
            {
                // オーバーライドされたプロパティが存在しても無視する
                Assertion.Condition(entry.Value.Count >= 1);
                var pi = entry.Value[0];

                if (pi.GetIndexParameters().Length == 0)
                {
                    predict(pi);
                }
            }
        }
        #endregion

        #region CopyProperties
        /// <summary>
        /// 指定されたインスタンスのプロパティ群をコピーします。
        /// </summary>
        /// <typeparam name="T">コピー先のインスタンスの型</typeparam>
        /// <typeparam name="U">コピー元のインスタンスの型</typeparam>
        /// <param name="copyTo">コピー先のインスタンス</param>
        /// <param name="copyFrom">コピー元のインスタンス</param>
        /// <param name="makeClone">プロパティのインスタンスがICloneableを実装する場合に使用するかどうか</param>
        /// <remarks>コピー元とコピー先のインスタンスには代入互換性がなければなりません。
        /// また、コピーを行うプロパティはインターフェイスに定義されていなければなりません。
        /// プロパティはgetter/setterを持っており、インデクサでないものだけが対象です。
        /// getter/setterのどちらか一方のみ実装されている場合やインデクサの場合は、無視されます。</remarks>
        public static void CopyProperties<T, U>(T copyTo, U copyFrom, bool makeClone)
            where T : class
            where U : class, T
        {
            Assertion.NullArgument(copyTo, "インスタンスが必要です");
            Assertion.NullArgument(copyFrom, "インスタンスが必要です");

            PropertiesPredicator(
                copyTo,
                copyFrom,
                pi =>
                {
                    if ((pi.CanRead == false) || (pi.CanWrite == false))
                    {
                        return;
                    }

                    var value = pi.GetValue(copyFrom, EMPTY_INDEXES);

                    if (makeClone == true)
                    {
                        var cloneable = value as ICloneable;
                        if (cloneable != null)
                        {
                            var clone = cloneable.Clone();
                            pi.SetValue(copyTo, clone, EMPTY_INDEXES);
                        }
                        else
                        {
                            pi.SetValue(copyTo, value, EMPTY_INDEXES);
                        }
                    }
                    else
                    {
                        pi.SetValue(copyTo, value, EMPTY_INDEXES);
                    }
                });
        }
        #endregion

        #region CompareProperties
        /// <summary>
        /// 指定されたインスタンスのプロパティ群を比較します。
        /// </summary>
        /// <typeparam name="T">比較元のインスタンスの型</typeparam>
        /// <typeparam name="U">比較先のインスタンスの型</typeparam>
        /// <param name="lhs">比較元のインスタンス</param>
        /// <param name="rhs">比較先のインスタンス</param>
        /// <param name="action">比較デリゲート（対象のプロパティを示す情報とプロパティの値の組を引数で指定）</param>
        /// <remarks>インスタンスには代入互換性がなければなりません。
        /// また、プロパティはインターフェイスに定義されていなければなりません。
        /// プロパティはgetterが存在し、インデクサでないものだけが対象です。</remarks>
        public static void CompareProperties<T, U>(T lhs, U rhs, Action<PropertyInfo, object, object> action)
            where T : class
            where U : class, T
        {
            Assertion.NullArgument(lhs, "インスタンスが必要です");
            Assertion.NullArgument(rhs, "インスタンスが必要です");
            Assertion.NullArgument(action, "処理を行うデリゲートが必要です");

            PropertiesPredicator(
                lhs,
                rhs,
                pi =>
                {
                    if (pi.CanRead == false)
                    {
                        return;
                    }

                    var lhsValue = pi.GetValue(lhs, EMPTY_INDEXES);
                    var rhsValue = pi.GetValue(rhs, EMPTY_INDEXES);

                    action(pi, lhsValue, rhsValue);
                });
        }

        /// <summary>
        /// 指定されたインスタンスのプロパティ群を比較します。
        /// </summary>
        /// <typeparam name="T">比較元のインスタンスの型</typeparam>
        /// <typeparam name="U">比較先のインスタンスの型</typeparam>
        /// <param name="lhs">比較元のインスタンス</param>
        /// <param name="rhs">比較先のインスタンス</param>
        /// <param name="comparer">比較演算子</param>
        /// <remarks>インスタンスには代入互換性がなければなりません。
        /// また、プロパティはインターフェイスに定義されていなければなりません。
        /// プロパティはgetterが存在し、インデクサでないものだけが対象です。</remarks>
        public static void CompareProperties<T, U>(T lhs, U rhs, IComparer comparer)
            where T : class
            where U : class, T
        {
            Assertion.NullArgument(lhs, "インスタンスが必要です");
            Assertion.NullArgument(rhs, "インスタンスが必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            CompareProperties(
                lhs,
                rhs,
                (pi, lhsValue, rhsValue) =>
                {
                    if (comparer.Compare(lhsValue, rhsValue) != 0)
                    {
                        throw new TypeUtilityException(
                            "プロパティ {0}.{1} の値が異なります: {2} != {3}",
                            pi.DeclaringType.FullName,
                            pi.Name,
                            SafeToString(lhsValue),
                            SafeToString(rhsValue));
                    }
                });
        }

        /// <summary>
        /// 指定されたインスタンスのプロパティ群を比較します。
        /// </summary>
        /// <typeparam name="T">比較元のインスタンスの型</typeparam>
        /// <typeparam name="U">比較先のインスタンスの型</typeparam>
        /// <param name="lhs">比較元のインスタンス</param>
        /// <param name="rhs">比較先のインスタンス</param>
        /// <param name="cultureInfo">比較に使用するカルチャ情報</param>
        /// <remarks>インスタンスには代入互換性がなければなりません。
        /// また、プロパティはインターフェイスに定義されていなければなりません。
        /// プロパティはgetterが存在し、インデクサでないものだけが対象です。</remarks>
        public static void CompareProperties<T, U>(T lhs, U rhs, CultureInfo cultureInfo)
            where T : class
            where U : class, T
        {
            Assertion.NullArgument(lhs, "インスタンスが必要です");
            Assertion.NullArgument(rhs, "インスタンスが必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");

            CompareProperties(lhs, rhs, new Comparer(cultureInfo));
        }
        #endregion

        #region DefineCustomAttribute
        /// <summary>
        /// カスタム属性を生成します。
        /// </summary>
        /// <param name="attributeType">生成する属性クラス</param>
        /// <param name="args">属性クラスのコンストラクタに指定する引数群</param>
        /// <returns>カスタム属性ビルダ</returns>
        internal static CustomAttributeBuilder DefineCustomAttribute(Type attributeType, params object[] args)
        {
            object state = null;
            var constructor = (ConstructorInfo)Type.DefaultBinder.BindToMethod(
                BindingFlags.Public | BindingFlags.Instance,
                attributeType.GetConstructors(),
                ref args,
                null,
                null,
                null,
                out state);

            return new CustomAttributeBuilder(constructor, args);
        }
        #endregion

        #region TupleComparer
        /// <summary>
        /// Tupleの比較演算子です。
        /// </summary>
        private sealed class TupleComparer : IEqualityComparer<Tuple<Type, Type>>
        {
            /// <summary>
            /// インスタンスが一致する事を確認します。
            /// </summary>
            /// <param name="x">比較元</param>
            /// <param name="y">比較先</param>
            /// <returns>一致すればtrue</returns>
            public bool Equals(Tuple<Type, Type> x, Tuple<Type, Type> y)
            {
                return (x.Item1 == y.Item1) && (x.Item2 == y.Item2);
            }

            /// <summary>
            /// ハッシュコードを取得します。
            /// </summary>
            /// <param name="obj">対象</param>
            /// <returns>ハッシュコード</returns>
            public int GetHashCode(Tuple<Type, Type> obj)
            {
                return obj.Item1.GetHashCode() ^ obj.Item2.GetHashCode();
            }
        }
        #endregion
    }
}

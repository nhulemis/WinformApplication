﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.Serialization;
using System.Text;

using CREO.Fluere.Common.Collections;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// 指定されたインターフェイスに対応する既定の実装を提供するクラスです。
    /// </summary>
    /// <remarks>このクラスを使用して、インターフェイス定義に対応するデータ保持のクラスとインスタンスを
    /// 動的に生成することが出来ます。</remarks>
    public static class StubInstanceFactory
    {
        #region フィールド
        /// <summary>
        /// System.Objectのコンストラクタです。
        /// </summary>
        private static readonly ConstructorInfo OBJECT_CONSTRUCTOR =
            typeof(object).GetConstructor(Type.EmptyTypes);

        /// <summary>
        /// StubInstanceFactoryExceptionコンストラクタ
        /// </summary>
        private static readonly ConstructorInfo STUB_INSTANCE_FACTORY_EXCEPTION_CONSTRUCTOR =
            typeof(StubInstanceFactoryException).GetConstructor(new Type[] { typeof(string) });

        /// <summary>
        /// MemberwiseCloneメソッド
        /// </summary>
        private static readonly MethodInfo MEMBERWISE_CLONE_METHOD =
            typeof(object).GetMethod("MemberwiseClone", BindingFlags.NonPublic | BindingFlags.Instance);

        /// <summary>
        /// Cloneメソッド
        /// </summary>
        private static readonly MethodInfo CLONE_METHOD =
            typeof(ICloneable).GetMethod("Clone");

        /// <summary>
        /// SafeToStringメソッド
        /// </summary>
        private static readonly MethodInfo SAFE_TO_STRING_METHOD =
            typeof(TypeUtility).GetMethod("SafeToString",
            BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly,
            null,
            new Type[] { typeof(object) },
            null);

        /// <summary>
        /// ToStringメソッド
        /// </summary>
        private static readonly MethodInfo TO_STRING_METHOD =
            typeof(object).GetMethod("ToString");

        /// <summary>
        /// StringBuilderコンストラクタ
        /// </summary>
        private static readonly ConstructorInfo STRING_BUILDER_CONSTRUCTOR =
            typeof(StringBuilder).GetConstructor(Type.EmptyTypes);

        /// <summary>
        /// Appendメソッド
        /// </summary>
        private static readonly MethodInfo APPEND_METHOD =
            typeof(StringBuilder).GetMethod("Append", new Type[] { typeof(string) });

        /// <summary>
        /// アセンブリビルダ
        /// </summary>
        private static readonly AssemblyBuilder ASSEMBLY_BUILDER;

        /// <summary>
        /// メソッドビルダ
        /// </summary>
        private static readonly ModuleBuilder MODULE_BUILDER;

        /// <summary>
        /// バインダ
        /// </summary>
        private static readonly SerializationBinder BINDER = new AssemblySerializationBinder();

        /// <summary>
        /// スタブファクトリを保持する辞書です。
        /// </summary>
        private static readonly Dictionary<Type, IStubInstanceFactory> STUB_INSTANCE_FACTORIES =
            new Dictionary<Type, IStubInstanceFactory>();
        #endregion

        #region タイプイニシャライザ
        /// <summary>
        /// タイプイニシャライザです。
        /// </summary>
        static StubInstanceFactory()
        {
            Assertion.Condition(OBJECT_CONSTRUCTOR != null);
            Assertion.Condition(STUB_INSTANCE_FACTORY_EXCEPTION_CONSTRUCTOR != null);
            Assertion.Condition(MEMBERWISE_CLONE_METHOD != null);
            Assertion.Condition(CLONE_METHOD != null);
            Assertion.Condition(SAFE_TO_STRING_METHOD != null);
            Assertion.Condition(TO_STRING_METHOD != null);
            Assertion.Condition(STRING_BUILDER_CONSTRUCTOR != null);
            Assertion.Condition(APPEND_METHOD != null);

            // スタブとスタブファクトリの定義を格納するアセンブリを生成する
            AssemblyName assemblyName = new AssemblyName("StubInstanceFactory");
#if DEBUG
            ASSEMBLY_BUILDER = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.RunAndSave);
            MODULE_BUILDER = ASSEMBLY_BUILDER.DefineDynamicModule("StubInstanceFactory.dll");
#else
            ASSEMBLY_BUILDER = AppDomain.CurrentDomain.DefineDynamicAssembly(assemblyName, AssemblyBuilderAccess.Run);
            MODULE_BUILDER = ASSEMBLY_BUILDER.DefineDynamicModule("StubInstanceFactory");
#endif

            BINDER = new AssemblySerializationBinder();
        }
        #endregion

        #region Binder
        /// <summary>
        /// シリアル化バインダを取得します。
        /// </summary>
        /// <remarks>このバインダを使用して、逆シリアル化プロセスで型を特定出来ます。</remarks>
        public static SerializationBinder Binder
        {
            get
            {
                return BINDER;
            }
        }
        #endregion

        /// <summary>
        /// アセンブリを保存します。
        /// </summary>
        [Conditional("DEBUG")]
        internal static void Save()
        {
            ASSEMBLY_BUILDER.Save("StubInstanceFactory.dll");
        }

        #region DefineDummyIndexer
        /// <summary>
        /// ダミーのインデクサとインデクサメソッドを定義します。
        /// </summary>
        /// <param name="typeBuilder">対象のタイプビルダ</param>
        /// <param name="overrided">オーバーライドしたメソッド群を格納する辞書</param>
        /// <param name="entry">プロパティ情報群</param>
        private static void DefineDummyIndexer(
            TypeBuilder typeBuilder,
            ISet<MethodInfo> overrided,
            KeyValuePair<OverridedMemberKey, IList<PropertyInfo>> entry)
        {
            Assertion.Condition(typeBuilder != null);
            Assertion.Condition(overrided != null);
            Assertion.Condition(entry.Key.AdditionalTypes.Length >= 1);

            // 他のメンバと重複しない安全な名前を生成する
            var safeName = TypeUtility.SanitizeName(string.Format("{0}_{1}", entry.Key.Type.FullName, entry.Key.Name));

            // インデクサを定義する
            var propertyBuilder = typeBuilder.DefineProperty(
                entry.Key.Name,
                PropertyAttributes.None,
                entry.Key.Type,
                entry.Key.AdditionalTypes);

            // 個々のインデクサ情報を処理する
            MethodBuilder getterBuilder = null;
            MethodBuilder setterBuilder = null;
            foreach (var pi in entry.Value)
            {
                // インデクサのGetterを定義する
                if (pi.CanRead == true)
                {
                    // まだ定義されていなければ生成
                    if (getterBuilder == null)
                    {
                        var getterName = string.Format("get_{0}", safeName);
                        getterBuilder = typeBuilder.DefineMethod(
                            getterName,
                            MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                            pi.PropertyType,
                            entry.Key.AdditionalTypes);

                        var getterGenerator = getterBuilder.GetILGenerator();
                        getterGenerator.Emit(OpCodes.Ldstr, "スタブのインデクサは使用出来ません");
                        getterGenerator.Emit(OpCodes.Newobj, STUB_INSTANCE_FACTORY_EXCEPTION_CONSTRUCTOR);
                        getterGenerator.Emit(OpCodes.Throw);

                        propertyBuilder.SetGetMethod(getterBuilder);
                    }

                    // このインデクサとgetter実装を結びつける
                    typeBuilder.DefineMethodOverride(getterBuilder, pi.GetGetMethod());

                    // オーバーライドした事を記憶
                    overrided.Add(pi.GetGetMethod());
                }

                // インデクサのSetterを定義する
                if (pi.CanWrite == true)
                {
                    // まだ定義されていなければ生成
                    if (setterBuilder == null)
                    {
                        var setterName = string.Format("set_{0}", safeName);
                        setterBuilder = typeBuilder.DefineMethod(
                            setterName,
                            MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                            typeof(void),
                            entry.Key.AdditionalTypes.Concat(new Type[] { pi.PropertyType }).ToArray());
                        propertyBuilder.SetSetMethod(setterBuilder);

                        var setterGenerator = setterBuilder.GetILGenerator();
                        setterGenerator.Emit(OpCodes.Ldstr, "スタブのインデクサは使用出来ません");
                        setterGenerator.Emit(OpCodes.Newobj, STUB_INSTANCE_FACTORY_EXCEPTION_CONSTRUCTOR);
                        setterGenerator.Emit(OpCodes.Throw);
                    }

                    // このインデクサとsetter実装を結びつける
                    typeBuilder.DefineMethodOverride(setterBuilder, pi.GetSetMethod());

                    // オーバーライドした事を記憶
                    overrided.Add(pi.GetSetMethod());
                }
            }
        }
        #endregion

        #region DefineProperty
        /// <summary>
        /// プロパティとプロパティメソッドを定義します。
        /// </summary>
        /// <param name="typeBuilder">対象のタイプビルダ</param>
        /// <param name="fields">プロパティに対応するフィールド群を格納するコレクション</param>
        /// <param name="overrided">オーバーライドしたメソッド群を格納する辞書</param>
        /// <param name="entry">プロパティ情報群</param>
        private static void DefineProperty(
            TypeBuilder typeBuilder,
            List<KeyValuePair<string, FieldBuilder>> fields,
            ISet<MethodInfo> overrided,
            KeyValuePair<OverridedMemberKey, IList<PropertyInfo>> entry)
        {
            Assertion.Condition(typeBuilder != null);
            Assertion.Condition(fields != null);
            Assertion.Condition(overrided != null);
            Assertion.Condition(entry.Key.AdditionalTypes.Length == 0);

            // 他のメンバと重複しない安全な名前を生成する
            var safeName = TypeUtility.SanitizeName(string.Format("{0}_{1}", entry.Key.Type.FullName, entry.Key.Name));

            // フィールドを定義する
            var fieldName = string.Format("_{0}", safeName);
            var fieldBuilder = typeBuilder.DefineField(
                fieldName,
                entry.Key.Type,
                FieldAttributes.Private);

            // 後でToStringの実装を生成する際に参照するため、フィールド情報を保存する
            fields.Add(KeyValuePair.Create(entry.Key.Name, fieldBuilder));

            // プロパティを定義する
            var propertyBuilder = typeBuilder.DefineProperty(
                entry.Key.Name,
                PropertyAttributes.None,
                entry.Key.Type,
                entry.Key.AdditionalTypes);

            // 個々のプロパティ情報を処理する
            MethodBuilder getterBuilder = null;
            MethodBuilder setterBuilder = null;
            foreach (var pi in entry.Value)
            {
                // プロパティのGetterを定義する
                if (pi.CanRead == true)
                {
                    // まだ定義されていなければ生成
                    if (getterBuilder == null)
                    {
                        var getterName = string.Format("get_{0}", safeName);
                        getterBuilder = typeBuilder.DefineMethod(
                            getterName,
                            MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                            pi.PropertyType,
                            Type.EmptyTypes);

                        var getterGenerator = getterBuilder.GetILGenerator();
                        getterGenerator.Emit(OpCodes.Ldarg_0);
                        getterGenerator.Emit(OpCodes.Ldfld, fieldBuilder);
                        getterGenerator.Emit(OpCodes.Ret);

                        propertyBuilder.SetGetMethod(getterBuilder);
                    }

                    // このプロパティとgetter実装を結びつける
                    typeBuilder.DefineMethodOverride(getterBuilder, pi.GetGetMethod());

                    // オーバーライドした事を記憶
                    overrided.Add(pi.GetGetMethod());
                }

                // プロパティのSetterを定義する
                if (pi.CanWrite == true)
                {
                    // まだ定義されていなければ生成
                    if (setterBuilder == null)
                    {
                        var setterName = string.Format("set_{0}", safeName);
                        setterBuilder = typeBuilder.DefineMethod(
                            setterName,
                            MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                            typeof(void),
                            new Type[] { pi.PropertyType });
                        propertyBuilder.SetSetMethod(setterBuilder);

                        var setterGenerator = setterBuilder.GetILGenerator();
                        setterGenerator.Emit(OpCodes.Ldarg_0);
                        setterGenerator.Emit(OpCodes.Ldarg_1);
                        setterGenerator.Emit(OpCodes.Stfld, fieldBuilder);
                        setterGenerator.Emit(OpCodes.Ret);
                    }

                    // このプロパティとsetter実装を結びつける
                    typeBuilder.DefineMethodOverride(setterBuilder, pi.GetSetMethod());

                    // オーバーライドした事を記憶
                    overrided.Add(pi.GetSetMethod());
                }
            }
        }
        #endregion

        #region CreateProperties
        /// <summary>
        /// プロパティ群を生成します。
        /// </summary>
        /// <param name="typeBuilder">対象のタイプビルダ</param>
        /// <param name="interfaceType">クラスが実装するインターフェイス</param>
        /// <param name="fields">プロパティに対応するフィールド群を格納するコレクション</param>
        /// <param name="overrided">オーバーライドしたメソッド群を格納する辞書</param>
        private static void CreateProperties(
            TypeBuilder typeBuilder,
            Type interfaceType,
            List<KeyValuePair<string, FieldBuilder>> fields,
            ISet<MethodInfo> overrided)
        {
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);
            Assertion.Condition(typeBuilder != null);
            Assertion.Condition(fields != null);
            Assertion.Condition(overrided != null);

            // インターフェイスを探索して、自身と継承している全てのプロパティ情報を得る
            var properties = PropertyList.GetImplementedListByOverrided(interfaceType);

            // オーバーライド毎にプロパティ情報を列挙する
            foreach (var entry in properties)
            {
                if (entry.Key.AdditionalTypes.Length >= 1)
                {
                    DefineDummyIndexer(typeBuilder, overrided, entry);
                }
                else
                {
                    DefineProperty(typeBuilder, fields, overrided, entry);
                }
            }
        }
        #endregion

        #region DefineDummyEvent
        /// <summary>
        /// ダミーのイベントとイベントメソッドを定義します。
        /// </summary>
        /// <param name="typeBuilder">対象のタイプビルダ</param>
        /// <param name="overrided">オーバーライドしたメソッド群を格納する辞書</param>
        /// <param name="entry">イベント情報群</param>
        private static void DefineDummyEvent(
            TypeBuilder typeBuilder,
            ISet<MethodInfo> overrided,
            KeyValuePair<OverridedMemberKey, IList<EventInfo>> entry)
        {
            Assertion.Condition(typeBuilder != null);
            Assertion.Condition(overrided != null);
            Assertion.Condition(entry.Key.AdditionalTypes.Length == 0);

            // 他のメンバと重複しない安全な名前を生成する
            var safeName = TypeUtility.SanitizeName(string.Format("{0}_{1}", entry.Key.Type.FullName, entry.Key.Name));

            // イベントを定義する
            var eventBuilder = typeBuilder.DefineEvent(
                entry.Key.Name,
                EventAttributes.None,
                entry.Key.Type);

            // 個々のイベント情報を処理する
            MethodBuilder addBuilder = null;
            MethodBuilder removeBuilder = null;
            foreach (var ei in entry.Value)
            {
                // まだ定義されていなければ生成
                if (addBuilder == null)
                {
                    var getterName = string.Format("add_{0}", safeName);
                    addBuilder = typeBuilder.DefineMethod(
                        getterName,
                        MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                        typeof(void),
                        new Type[] { ei.EventHandlerType });

                    var addGenerator = addBuilder.GetILGenerator();
                    addGenerator.Emit(OpCodes.Ldstr, "スタブのイベントは使用出来ません");
                    addGenerator.Emit(OpCodes.Newobj, STUB_INSTANCE_FACTORY_EXCEPTION_CONSTRUCTOR);
                    addGenerator.Emit(OpCodes.Throw);

                    eventBuilder.SetAddOnMethod(addBuilder);
                }

                // このインデクサとgetter実装を結びつける
                typeBuilder.DefineMethodOverride(addBuilder, ei.GetAddMethod());

                // オーバーライドした事を記憶
                overrided.Add(ei.GetAddMethod());

                // まだ定義されていなければ生成
                if (removeBuilder == null)
                {
                    var setterName = string.Format("remove_{0}", safeName);
                    removeBuilder = typeBuilder.DefineMethod(
                        setterName,
                        MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                        typeof(void),
                        new Type[] { ei.EventHandlerType });
                    eventBuilder.SetRemoveOnMethod(removeBuilder);

                    var removeGenerator = removeBuilder.GetILGenerator();
                    removeGenerator.Emit(OpCodes.Ldstr, "スタブのイベントは使用出来ません");
                    removeGenerator.Emit(OpCodes.Newobj, STUB_INSTANCE_FACTORY_EXCEPTION_CONSTRUCTOR);
                    removeGenerator.Emit(OpCodes.Throw);
                }

                // このインデクサとsetter実装を結びつける
                typeBuilder.DefineMethodOverride(removeBuilder, ei.GetRemoveMethod());

                // オーバーライドした事を記憶
                overrided.Add(ei.GetRemoveMethod());
            }
        }
        #endregion

        #region CreateEvents
        /// <summary>
        /// イベント群を生成します。
        /// </summary>
        /// <param name="typeBuilder">対象のタイプビルダ</param>
        /// <param name="interfaceType">クラスが実装するインターフェイス</param>
        /// <param name="overrided">オーバーライドしたメソッド群を格納する辞書</param>
        private static void CreateEvents(
            TypeBuilder typeBuilder,
            Type interfaceType,
            ISet<MethodInfo> overrided)
        {
            Assertion.Condition(typeBuilder != null);
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);
            Assertion.Condition(overrided != null);

            // インターフェイスを探索して、自身と継承している全てのイベント情報を得る
            var events = EventList.GetImplementedListByOverrided(interfaceType);

            // オーバーライド毎にイベント情報を列挙する
            foreach (var entry in events)
            {
                DefineDummyEvent(typeBuilder, overrided, entry);
            }
        }
        #endregion

        #region CreateCloneMethod
        /// <summary>
        /// Cloneメソッドを生成します。
        /// </summary>
        /// <param name="typeBuilder">対象のタイプビルダ</param>
        /// <param name="interfaceType">クラスが実装するインターフェイス</param>
        /// <param name="overrided">オーバーライドしたメソッド群を格納する辞書</param>
        private static void CreateCloneMethod(
            TypeBuilder typeBuilder,
            Type interfaceType,
            ISet<MethodInfo> overrided)
        {
            Assertion.Condition(typeBuilder != null);
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);
            Assertion.Condition(overrided != null);

            // インターフェイスを探索して、Cloneメソッド情報を得る
            var cloneMethods =
                (from entry in MethodList.GetImplementedListByOverrided(interfaceType)
                 where  // "Clone"という名前で、戻り値がvoid以外で、引数がないメソッド
                    (entry.Key.Name == "Clone") && (entry.Key.Type != typeof(void)) &&
                    (entry.Key.AdditionalTypes.Length == 0)
                 select entry.Value into methods
                 from method in methods
                 select method).Concat(new MethodInfo[] { CLONE_METHOD });

            // Cloneメソッドを実装する
            foreach (var cloneMethod in cloneMethods)
            {
                // オーバーライドされていれば
                if (overrided.Contains(cloneMethod) == true)
                {
                    // 無視
                    continue;
                }

                // 他のメンバと重複しない安全な名前を生成する
                var safeName = TypeUtility.SanitizeName(
                    string.Format("{0}_{1}", cloneMethod.DeclaringType.FullName, cloneMethod.Name));

                // Cloneを実装する
                var cloneBuilder = typeBuilder.DefineMethod(
                    safeName,
                    MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                    cloneMethod.ReturnType,
                    Type.EmptyTypes);

                var cloneGenerator = cloneBuilder.GetILGenerator();
                cloneGenerator.Emit(OpCodes.Ldarg_0);
                cloneGenerator.Emit(OpCodes.Call, MEMBERWISE_CLONE_METHOD);

                // 暗黙キャストが出来ないなら
                if (cloneMethod.ReturnType.IsAssignableFrom(interfaceType) == false)
                {
                    cloneGenerator.Emit(OpCodes.Castclass, cloneMethod.ReturnType);
                }

                cloneGenerator.Emit(OpCodes.Ret);

                typeBuilder.DefineMethodOverride(cloneBuilder, cloneMethod);

                // オーバーライドした事を記憶
                overrided.Add(cloneMethod);
            }
        }
        #endregion

        #region CreateToStringMethod
        /// <summary>
        /// ToStringメソッドを生成します。
        /// </summary>
        /// <param name="typeBuilder">対象のタイプビルダ</param>
        /// <param name="fields">プロパティに対応するフィールド群を格納するコレクション</param>
        /// <param name="overrided">オーバーライドしたメソッド群を格納する辞書</param>
        private static void CreateToStringMethod(
            TypeBuilder typeBuilder,
            List<KeyValuePair<string, FieldBuilder>> fields,
            ISet<MethodInfo> overrided)
        {
            Assertion.Condition(typeBuilder != null);
            Assertion.Condition(fields != null);
            Assertion.Condition(overrided != null);

            // ToStringを実装する
            // （全てのフィールドを列挙し、文字列として繋げた結果を返す。高速化のため、StringBuilderを使う）
            var toStringBuilder = typeBuilder.DefineMethod(
                "ToString",
                MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.Final,
                typeof(string),
                Type.EmptyTypes);

            var toStringGenerator = toStringBuilder.GetILGenerator();

            toStringGenerator.Emit(OpCodes.Newobj, STRING_BUILDER_CONSTRUCTOR);

            for (var i = 0; i < fields.Count; i++)
            {
                if (i >= 1)
                {
                    toStringGenerator.Emit(OpCodes.Ldstr, ", ");
                    toStringGenerator.Emit(OpCodes.Call, APPEND_METHOD);
                }

                {
                    toStringGenerator.Emit(OpCodes.Ldstr, fields[i].Key);
                    toStringGenerator.Emit(OpCodes.Call, APPEND_METHOD);
                }

                {
                    toStringGenerator.Emit(OpCodes.Ldstr, "=");
                    toStringGenerator.Emit(OpCodes.Call, APPEND_METHOD);
                }

                {
                    toStringGenerator.Emit(OpCodes.Ldarg_0);
                    toStringGenerator.Emit(OpCodes.Ldfld, fields[i].Value);

                    // 値型
                    if (fields[i].Value.FieldType.IsValueType == true)
                    {
                        toStringGenerator.Emit(OpCodes.Box, fields[i].Value.FieldType);
                    }

                    toStringGenerator.Emit(OpCodes.Call, SAFE_TO_STRING_METHOD);
                    toStringGenerator.Emit(OpCodes.Call, APPEND_METHOD);
                }
            }

            toStringGenerator.Emit(OpCodes.Callvirt, TO_STRING_METHOD);
            toStringGenerator.Emit(OpCodes.Ret);

            // オーバーライドした事を記憶
            overrided.Add(TO_STRING_METHOD);
        }
        #endregion

        #region DefineDummyMethod
        /// <summary>
        /// ダミーのメソッドを定義します。
        /// </summary>
        /// <param name="typeBuilder">対象のタイプビルダ</param>
        /// <param name="overrided">オーバーライドしたメソッド群を格納する辞書</param>
        /// <param name="method">メソッド情報群</param>
        private static void DefineDummyMethod(
            TypeBuilder typeBuilder,
            ISet<MethodInfo> overrided,
            KeyValuePair<OverridedMemberKey, IList<MethodInfo>> method)
        {
            Assertion.Condition(typeBuilder != null);
            Assertion.Condition(overrided != null);

            // 個々のメソッド情報を処理する
            MethodBuilder methodBuilder = null;
            foreach (var mi in method.Value)
            {
                // 既にオーバーライドしていれば無視
                if (overrided.Contains(mi) == true)
                {
                    continue;
                }

                // まだ定義されていなければ生成
                if (methodBuilder == null)
                {
                    // メソッドを定義する
                    methodBuilder = typeBuilder.DefineMethod(
                        method.Key.Name,
                        MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                        method.Key.Type,
                        method.Key.AdditionalTypes);

                    var getterGenerator = methodBuilder.GetILGenerator();
                    getterGenerator.Emit(OpCodes.Ldstr, "スタブのメソッドは使用出来ません");
                    getterGenerator.Emit(OpCodes.Newobj, STUB_INSTANCE_FACTORY_EXCEPTION_CONSTRUCTOR);
                    getterGenerator.Emit(OpCodes.Throw);
                }

                // このメソッドとメソッド実装を結びつける
                typeBuilder.DefineMethodOverride(methodBuilder, mi);

                // オーバーライドした事を記憶
                overrided.Add(mi);
            }
        }
        #endregion

        #region CreateMethods
        /// <summary>
        /// メソッド群を生成します。
        /// </summary>
        /// <param name="typeBuilder">対象のタイプビルダ</param>
        /// <param name="interfaceType">クラスが実装するインターフェイス</param>
        /// <param name="overrided">オーバーライドしたメソッド群を格納する辞書</param>
        private static void CreateMethods(
            TypeBuilder typeBuilder,
            Type interfaceType,
            ISet<MethodInfo> overrided)
        {
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);
            Assertion.Condition(typeBuilder != null);
            Assertion.Condition(overrided != null);

            // インターフェイスを探索して、自身と継承している全てのメソッド情報を得る
            var methods = MethodList.GetImplementedListByOverrided(interfaceType);

            // オーバーライド毎にメソッド情報を列挙する
            foreach (var entry in methods)
            {
                DefineDummyMethod(typeBuilder, overrided, entry);
            }
        }
        #endregion

        #region CreateStubType
        /// <summary>
        /// 指定されたインターフェイス型から、スタブとなるクラスを動的に生成して返します。
        /// </summary>
        /// <param name="interfaceType">インターフェイス型</param>
        /// <returns>スタブクラスの型</returns>
        internal static Type CreateStubType(Type interfaceType)
        {
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);

            // クラス名をインターフェイス名から決定する
            // タイプハンドル値は、同じ名前の異なる実装がロードされている場合に重複を避けるため。
            var typeName = string.Format(
                "{0}.{1}_Stub_{2}",
                interfaceType.Namespace,
                interfaceType.Name,
                interfaceType.TypeHandle.Value);

            // スタブクラスを定義する
            var typeBuilder = MODULE_BUILDER.DefineType(
                typeName,
                TypeAttributes.NotPublic | TypeAttributes.Sealed | TypeAttributes.Class | TypeAttributes.Serializable,
                typeof(object));
            typeBuilder.AddInterfaceImplementation(typeof(IStubInstance));
            typeBuilder.AddInterfaceImplementation(interfaceType);

            // スタブクラスにDebuggerNonUserCodeAttributeを適用する
            var debuggerNonUserCodeAttribute =
                TypeUtility.DefineCustomAttribute(typeof(DebuggerNonUserCodeAttribute));
            typeBuilder.SetCustomAttribute(debuggerNonUserCodeAttribute);

            // オーバーライド済みのメソッド群を保持
            var overrided = new HashSet<MethodInfo>();

            // プロパティ群を生成する
            var fields = new List<KeyValuePair<string, FieldBuilder>>();
            CreateProperties(typeBuilder, interfaceType, fields, overrided);

            // イベント群を生成する
            CreateEvents(typeBuilder, interfaceType, overrided);

            // Cloneメソッドを生成する
            CreateCloneMethod(typeBuilder, interfaceType, overrided);

            // ToStringメソッドを生成する
            CreateToStringMethod(typeBuilder, fields, overrided);

            // TODO:スタブクラスにEqualsとGetHashCodeを実装する

            // メソッド群を生成する
            CreateMethods(typeBuilder, interfaceType, overrided);

            // コンストラクタを生成する
            typeBuilder.DefineDefaultConstructor(MethodAttributes.Public);

            // スタブクラスを生成する
            return typeBuilder.CreateType();
        }
        #endregion

        #region CreateInstanceFactory
        /// <summary>
        /// 指定されたスタブクラスの型から、インスタンスファクトリを動的に生成して返します。
        /// </summary>
        /// <param name="interfaceType">インターフェイス型</param>
        /// <param name="stubType">スタブクラスの型</param>
        /// <returns>インスタンスファクトリ</returns>
        internal static IStubInstanceFactory CreateInstanceFactory(Type interfaceType, Type stubType)
        {
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);
            Assertion.Condition(stubType != null);
            Assertion.Condition(interfaceType.IsAssignableFrom(stubType) == true);

            // クラス名をインターフェイス名から決定する
            var typeName = string.Format("{0}_Factory", stubType.FullName);

            // 実装するファクトリインターフェイスを取得する
            var implementType = typeof(IStubInstanceFactory<>).MakeGenericType(interfaceType);

            // ファクトリクラスを定義する
            var typeBuilder = MODULE_BUILDER.DefineType(
                typeName,
                TypeAttributes.Public | TypeAttributes.Sealed | TypeAttributes.Class,
                typeof(object));
            typeBuilder.AddInterfaceImplementation(typeof(IStubInstanceFactory));
            typeBuilder.AddInterfaceImplementation(implementType);

            // ファクトリクラスにCompilerGeneratedAttributeを適用する
            var debuggerNonUserCodeAttribute =
                TypeUtility.DefineCustomAttribute(typeof(DebuggerNonUserCodeAttribute));
            typeBuilder.SetCustomAttribute(debuggerNonUserCodeAttribute);

            // スタブクラスのデフォルトコンストラクタを得る
            var ci = stubType.GetConstructor(Type.EmptyTypes);

            {
                // TargetTypeプロパティの定義
                var propertyBuilder = typeBuilder.DefineProperty(
                    "TargetType",
                    PropertyAttributes.None,
                    typeof(Type),
                    Type.EmptyTypes);

                var methodBuilder = typeBuilder.DefineMethod(
                    "get_TargetType",
                    MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                    typeof(Type),
                    Type.EmptyTypes);

                var generator = methodBuilder.GetILGenerator();
                generator.Emit(OpCodes.Ldtoken, interfaceType);
                generator.Emit(OpCodes.Call, typeof(Type).GetMethod("GetTypeFromHandle"));
                generator.Emit(OpCodes.Ret);

                propertyBuilder.SetGetMethod(methodBuilder);

                // メソッドをインターフェイスに結びつける
                var targetProperty = typeof(IStubInstanceFactory).GetProperty(
                    "TargetType",
                    BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
                typeBuilder.DefineMethodOverride(methodBuilder, targetProperty.GetGetMethod());
            }

            {
                // CreateInstance()メソッドの定義
                var methodBuilder = typeBuilder.DefineMethod(
                    "CreateInstance",
                    MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                    typeof(object),
                    Type.EmptyTypes);

                var generator = methodBuilder.GetILGenerator();
                generator.Emit(OpCodes.Newobj, ci);
                generator.Emit(OpCodes.Ret);

                // メソッドをインターフェイスに結びつける
                var targetMethod = typeof(IStubInstanceFactory).GetMethod(
                    "CreateInstance",
                    BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
                typeBuilder.DefineMethodOverride(methodBuilder, targetMethod);
            }

            {
                // CreateInstance<T>()メソッドの定義
                var methodBuilder = typeBuilder.DefineMethod(
                    "CreateInstance",
                    MethodAttributes.Private | MethodAttributes.Virtual | MethodAttributes.Final,
                    interfaceType,
                    Type.EmptyTypes);

                var generator = methodBuilder.GetILGenerator();
                generator.Emit(OpCodes.Newobj, ci);
                generator.Emit(OpCodes.Ret);

                // メソッドをインターフェイスに結びつける
                var targetMethod = implementType.GetMethod(
                    "CreateInstance",
                    BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
                typeBuilder.DefineMethodOverride(methodBuilder, targetMethod);
            }

            // コンストラクタを生成する
            typeBuilder.DefineDefaultConstructor(MethodAttributes.Public);

            // ファクトリクラスを生成する
            var factoryType = typeBuilder.CreateType();

            // ファクトリを生成する
            return (IStubInstanceFactory)Activator.CreateInstance(factoryType);
        }
        #endregion

        #region SafeGetInstanceFactory
        /// <summary>
        /// 指定された型を実装するクラスのファクトリを取得します。
        /// </summary>
        /// <param name="interfaceType">型</param>
        /// <returns>スタブファクトリ</returns>
        internal static IStubInstanceFactory SafeGetInstanceFactory(Type interfaceType)
        {
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);

            // スタブクラスを定義済みなら辞書から取得し、無ければ生成する。
            IStubInstanceFactory factory = null;
            lock (STUB_INSTANCE_FACTORIES)
            {
                if (STUB_INSTANCE_FACTORIES.TryGetValue(interfaceType, out factory) == false)
                {
                    var stubType = CreateStubType(interfaceType);
                    factory = CreateInstanceFactory(interfaceType, stubType);
                    STUB_INSTANCE_FACTORIES.Add(interfaceType, factory);
                }
            }

            return factory;
        }
        #endregion

        #region GetInstanceFactory
        /// <summary>
        /// 指定されたインターフェイスのファクトリを取得します。
        /// </summary>
        /// <param name="interfaceType">インターフェイス型</param>
        /// <returns>ファクトリ</returns>
        /// <remarks>ファクトリインターフェイスを使用する事で、型検索の時間を短縮し、静的に生成する場合と同等の時間で生成する事が出来ます。</remarks>
        [DebuggerNonUserCode]
        public static IStubInstanceFactory GetInstanceFactory(Type interfaceType)
        {
            Assertion.NullArgument(interfaceType, "インターフェイス型が必要です");
            Assertion.Argument(interfaceType.IsInterface == true, "インターフェイス型が必要です");

            return SafeGetInstanceFactory(interfaceType);
        }

        /// <summary>
        /// 指定されたインターフェイスのファクトリを取得します。
        /// </summary>
        /// <typeparam name="T">インターフェイス型</typeparam>
        /// <returns>ファクトリ</returns>
        /// <remarks>ファクトリインターフェイスを使用する事で、型検索の時間を短縮し、静的に生成する場合と同等の時間で生成する事が出来ます。</remarks>
        [DebuggerNonUserCode]
        public static IStubInstanceFactory<T> GetInstanceFactory<T>()
            where T : class
        {
            Assertion.Argument(typeof(T).IsInterface == true, "インターフェイス型が必要です");

            return (IStubInstanceFactory<T>)SafeGetInstanceFactory(typeof(T));
        }
        #endregion

        #region CreateInstance
        /// <summary>
        /// 指定されたインターフェイスのスタブを生成します。
        /// </summary>
        /// <param name="interfaceType">インターフェイス型</param>
        /// <returns>スタブインスタンス</returns>
        /// <remarks>大量のインスタンスを生成する場合は、ファクトリインターフェイスを取得してから生成するほうが効率的です。</remarks>
        [DebuggerNonUserCode]
        public static object CreateInstance(Type interfaceType)
        {
            return GetInstanceFactory(interfaceType).CreateInstance();
        }

        /// <summary>
        /// インターフェイス型を指定してスタブを生成します。
        /// </summary>
        /// <typeparam name="T">インターフェイス型</typeparam>
        /// <returns>スタブインスタンス</returns>
        /// <remarks>大量のインスタンスを生成する場合は、ファクトリインターフェイスを取得してから生成するほうが効率的です。</remarks>
        [DebuggerNonUserCode]
        public static T CreateInstance<T>()
            where T : class
        {
            return GetInstanceFactory<T>().CreateInstance();
        }
        #endregion

        #region AssemblySerializationBinder
        /// <summary>
        /// スタブクラスを特定する事が出来るシリアル化バインダの実装です。
        /// </summary>
        /// <remarks>このクラスは内部的に使用します。</remarks>
        [DebuggerNonUserCode]
        internal sealed class AssemblySerializationBinder : SerializationBinder
        {
            /// <summary>
            /// 指定されたアセンブリ名と型名から、メタデータ情報を取得します。
            /// </summary>
            /// <param name="assemblyName">アセンブリ名</param>
            /// <param name="typeName">型名</param>
            /// <returns>タイプ情報</returns>
            public override Type BindToType(string assemblyName, string typeName)
            {
                if (assemblyName == ASSEMBLY_BUILDER.FullName)
                {
                    return ASSEMBLY_BUILDER.GetType(typeName, true);
                }
                else
                {
                    return null;
                }
            }
        }
        #endregion
    }
}

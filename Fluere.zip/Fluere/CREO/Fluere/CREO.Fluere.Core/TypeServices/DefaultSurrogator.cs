﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections;
using System.Diagnostics;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// TypeWrapperが提供するラッパークラスの動作に介入する、既定の実装です。
    /// </summary>
    /// <remarks>このクラスを継承して、独自のサロゲータを実装できます。</remarks>
    [DebuggerNonUserCode]
    public class DefaultSurrogator : ITypeWrapperSurrogator
    {
        /// <summary>
        /// Comparer
        /// </summary>
        private static readonly IComparer COMPARER = Comparer.DefaultInvariant;

        /// <summary>
        /// DefaultLifetimeCreator
        /// </summary>
        private static readonly DefaultLifetimeCreator DEFAULT_LIFETIME_CREATOR = new DefaultLifetimeCreator();

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public DefaultSurrogator()
        {
        }

        /// <summary>
        /// インスタンスの実際のクラスから、変換されるべきインターフェイス型を特定します。
        /// </summary>
        /// <param name="realType">インスタンスの実際のクラス</param>
        /// <param name="assignableType">指定された、キャスト可能なインターフェイス</param>
        /// <returns>変換されるべきインターフェイス</returns>
        /// <remarks>既定の実装では、キャスト可能なインターフェイスをそのまま返します。</remarks>
        public virtual Type GetTargetType(Type realType, Type assignableType)
        {
            Assertion.Condition(realType != null);
            Assertion.Condition(realType.IsClass == true);
            Assertion.Condition(assignableType != null);
            Assertion.Condition(assignableType.IsInterface == true);

            return assignableType;
        }

        /// <summary>
        /// 2 つのオブジェクトを比較し、一方が他方より小さいか、等しいか、大きいかを示す値を返します。
        /// </summary>
        /// <param name="x">比較する最初のオブジェクトです。</param>
        /// <param name="y">比較する 2 番目のオブジェクト。</param>
        /// <returns>x と y の相対的な値を示す符号付き整数。</returns>
        /// <remarks>既定の実装では、Comparerクラスを使用して比較を実行します。</remarks>
        public virtual int Compare(object x, object y)
        {
            // スタティックラッパーの比較
            if (x == null)
            {
                return int.MinValue;
            }

            return COMPARER.Compare(x, y);
        }

        /// <summary>
        /// 指定したオブジェクトが等しいかどうかを判断します。
        /// </summary>
        /// <param name="x">比較対象の第 1 オブジェクト。</param>
        /// <param name="y">2 番目に比較するオブジェクト。</param>
        /// <returns>指定したオブジェクトが等しい場合は true。それ以外の場合は false。</returns>
        /// <remarks>既定の実装では、object.Equalsメソッドを呼び出して比較します。</remarks>
        public new virtual bool Equals(object x, object y)
        {
            // スタティックラッパーの比較
            if (x == null)
            {
                return false;
            }

            // newキーワードを使用しているが、基底メソッドはstaticなので問題ない。
            return x.Equals(y);
        }

        /// <summary>
        /// 指定したオブジェクトのハッシュ コードを返します。
        /// </summary>
        /// <param name="realObj">ハッシュ コードが返される対象の System.Object。</param>
        /// <returns>指定したオブジェクトのハッシュ コード。</returns>
        /// <remarks>既定の実装では、object.GetHashCodeメソッドを呼び出します。</remarks>
        public virtual int GetHashCode(object realObj)
        {
            // スタティックラッパー
            if (realObj == null)
            {
                return 0;
            }

            return realObj.GetHashCode();
        }

        /// <summary>
        /// 指定されたインスタンスの文字列表現を取得します。
        /// </summary>
        /// <param name="realObj">インスタンス</param>
        /// <returns>文字列表現</returns>
        /// <remarks>既定の実装では、object.ToStringメソッドを呼び出して文字列を取得します。</remarks>
        public virtual string ToString(object realObj)
        {
            // スタティックラッパー
            if (realObj == null)
            {
                return "(Static wrapper)";
            }

            return realObj.ToString();
        }

        /// <summary>
        /// 対象のインスタンスの有効期間ポリシーを制御する、有効期間サービスオブジェクトを取得します。
        /// </summary>
        /// <param name="realObj">インスタンス</param>
        /// <returns>対象のインスタンスの有効期間ポリシーを制御するときに使用する、ILease 型のオブジェクト</returns>
        public virtual object InitializeLifetimeService(object realObj)
        {
            return DEFAULT_LIFETIME_CREATOR.InitializeLifetimeService();
        }

        /// <summary>
        /// デフォルトの有効期間ポリシーを生成するクラスです。
        /// </summary>
        private sealed class DefaultLifetimeCreator : MarshalByRefObject
        {
            /// <summary>
            /// コンストラクタです。
            /// </summary>
            public DefaultLifetimeCreator()
            {
            }
        }
    }
}

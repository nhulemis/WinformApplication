﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Text;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// メンバのオーバーライド情報を辞書にキーとするクラスです。
    /// </summary>
    /// <remarks>メンバ情報でオーバーライドされているものを収集するためのキーとして使用します。
    /// オーバーライドの判定は、メンバの型群と名前が一致する事が条件です。
    /// 追加引数群は、プロパティであればインデクサ引数群、メソッドであれば引数群の型です。</remarks>
    internal sealed class OverridedMemberKey
        : IEquatable<OverridedMemberKey>, IComparable<OverridedMemberKey>, IComparable
    {
        /// <summary>
        /// メンバ名
        /// </summary>
        private readonly string _name;

        /// <summary>
        /// メンバ型
        /// </summary>
        private readonly Type _type;

        /// <summary>
        /// メンバ引数型群
        /// </summary>
        private readonly Type[] _additionalTypes;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="name">メンバ名</param>
        /// <param name="type">メンバを示す型</param>
        /// <param name="additionalTypes">メンバの追加型群</param>
        /// <remarks>追加引数群は、プロパティであればインデクサ引数群、メソッドであれば引数群の型です。</remarks>
        public OverridedMemberKey(string name, Type type, params Type[] additionalTypes)
        {
            Assertion.Condition(name != null);
            Assertion.Condition(type != null);
            Assertion.Condition(additionalTypes != null);

            this._name = name;
            this._type = type;
            this._additionalTypes = additionalTypes;
        }

        /// <summary>
        /// 名前を取得します。
        /// </summary>
        public string Name
        {
            get
            {
                return this._name;
            }
        }

        /// <summary>
        /// 型を取得します。
        /// </summary>
        public Type Type
        {
            get
            {
                return this._type;
            }
        }

        /// <summary>
        /// 追加型群を取得します。
        /// </summary>
        /// <remarks>プロパティであればインデクサ引数群、メソッドであれば引数群の型です。</remarks>
        public Type[] AdditionalTypes
        {
            get
            {
                return this._additionalTypes;
            }
        }

        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <returns>ハッシュコード</returns>
        public override int GetHashCode()
        {
            var hashCode = _name.GetHashCode() ^ this._type.GetHashCode();
            for (var i = 0; i < this._additionalTypes.Length; i++)
            {
                hashCode ^= this._additionalTypes[i].GetHashCode();
            }

            return hashCode;
        }

        /// <summary>
        /// 別のインスタンスを比較します。
        /// </summary>
        /// <param name="key">別のインスタンス</param>
        /// <returns>一致すればtrue</returns>
        /// <remarks>一致判定は、名前と型群が一致する事が条件です。</remarks>
        public bool Equals(OverridedMemberKey key)
        {
            if (key == null)
            {
                return false;
            }

            if (this._name.Equals(key._name) == false)
            {
                return false;
            }

            if (this._type.Equals(key._type) == false)
            {
                return false;
            }

            if (this._additionalTypes.Length != key._additionalTypes.Length)
            {
                return false;
            }

            for (int i = 0; i < this._additionalTypes.Length; i++)
            {
                if (this._additionalTypes[i].Equals(key._additionalTypes[i]) == false)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// 別のインスタンスを比較します。
        /// </summary>
        /// <param name="obj">別のインスタンス</param>
        /// <returns>一致すればtrue</returns>
        /// <remarks>一致判定は、名前と型群が一致する事が条件です。</remarks>
        public override bool Equals(object obj)
        {
            return this.Equals(obj as OverridedMemberKey);
        }

        /// <summary>
        /// 指定されたインスタンスを比較します。
        /// </summary>
        /// <param name="other">比較するインスタンス</param>
        /// <returns>辞書順で大小を識別する値</returns>
        public int CompareTo(OverridedMemberKey other)
        {
            if (other == null)
            {
                return int.MinValue;
            }

            var result = this._name.CompareTo(other._name);
            if (result != 0)
            {
                return result;
            }

            result = this._type.AssemblyQualifiedName.CompareTo(other._type.AssemblyQualifiedName);
            if (result != 0)
            {
                return result;
            }

            result = this._additionalTypes.Length.CompareTo(other._additionalTypes.Length);
            if (result != 0)
            {
                return result;
            }

            for (var i = 0; i < this._additionalTypes.Length; i++)
            {
                result = this._additionalTypes[i].AssemblyQualifiedName.CompareTo(
                    other._additionalTypes[i].AssemblyQualifiedName);
                if (result != 0)
                {
                    return result;
                }
            }

            return 0;
        }

        /// <summary>
        /// このインスタンスの文字列表現を取得します。
        /// </summary>
        /// <returns>文字列</returns>
        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendFormat("{0} {1}(", this._type, this._name);
            for (var i = 0; i < this._additionalTypes.Length; i++)
            {
                if (i >= 1)
                {
                    sb.Append(", ");
                }

                sb.Append(this._additionalTypes[i].FullName);
            }

            sb.Append(')');
            return sb.ToString();
        }

        /// <summary>
        /// 指定されたインスタンスを比較します。
        /// </summary>
        /// <param name="other">比較するインスタンス</param>
        /// <returns>辞書順で大小を識別する値</returns>
        int IComparable.CompareTo(object other)
        {
            return CompareTo(other as OverridedMemberKey);
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012/11/16 14:23:12 MAPMASTER matsuiko

using System;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// "弱い参照" を表します。
    /// 弱い参照は、オブジェクトがガベージ コレクションによるクリアの対象になっている状態のままで、
    /// そのオブジェクトを参照します。
    /// </summary>
    /// <typeparam name="T">参照する型</typeparam>
    [Serializable]
    public sealed class WeakReference<T>
        where T : class
    {
        /// <summary>
        /// WeakReference
        /// </summary>
        private readonly WeakReference _rawWeakReference;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="target">追跡するオブジェクト</param>
        public WeakReference(T target)
        {
            this._rawWeakReference = new WeakReference(target);
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="target">追跡するオブジェクト</param>
        /// <param name="trackResurrection">オブジェクト追跡の停止時期を示します。
        /// true を設定すると、終了後にオブジェクトが追跡されます。
        /// false を設定すると、オブジェクトの追跡は終了が実行される時点で停止します。</param>
        public WeakReference(T target, bool trackResurrection)
        {
            this._rawWeakReference = new WeakReference(target, trackResurrection);
        }

        /// <summary>
        /// オブジェクトが、ガベージ コレクションで収集されているかどうかを示す値を取得します。
        /// </summary>
        public bool IsAlive
        {
            get
            {
                return this._rawWeakReference.IsAlive;
            }
        }

        /// <summary>
        /// オブジェクト (ターゲット) を取得または設定します。
        /// </summary>
        public T Target
        {
            get
            {
                return (T)this._rawWeakReference.Target;
            }

            set
            {
                this._rawWeakReference.Target = value;
            }
        }

        /// <summary>
        /// オブジェクトを、その終了後に追跡するかどうかを示す値を取得します。
        /// </summary>
        public bool TrackResurrection
        {
            get
            {
                return this._rawWeakReference.TrackResurrection;
            }
        }
    }
}

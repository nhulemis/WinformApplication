﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.22 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices.Internal;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// フィールドのメタデータを操作するユーティリティクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal static class FieldList
    {
        /// <summary>
        /// フィールド情報のオペレータです。
        /// </summary>
        private static readonly IValueAccessOperator<FieldInfo> FIELD_INFO_OPERATOR = new FieldInfoOperator();

        /// <summary>
        /// フィールド情報のオペレータを取得します。
        /// </summary>
        public static IValueAccessOperator<FieldInfo> Operator
        {
            get
            {
                return FIELD_INFO_OPERATOR;
            }
        }

        /// <summary>
        /// 指定されたクラスが継承する全てのクラスに定義されているフィールドをオーバーライド毎に収集します。
        /// </summary>
        /// <param name="type">対象の型</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <returns>収集したフィールド情報を格納するコレクション</returns>
        /// <remarks>フィールドはオーバーライドされている可能性があるため、
        /// オーバーライド毎にグループを形成して収集します。
        /// 各オーバーライドの識別には、OverridedMemberKeyクラスを使用します。</remarks>
        public static IDictionary<OverridedMemberKey, IList<FieldInfo>>
            GetListByOverrided(Type type, bool isStatic)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(type.IsClass == true);

            var members = new DictionaryWrapper<OverridedMemberKey, IList<FieldInfo>>();

            MemberList.GetListByOverrided(members, type, isStatic, FIELD_INFO_OPERATOR);

            return members.RealDictionary;
        }
    }
}

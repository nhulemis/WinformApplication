﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices.Internal;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// TypeWrapperクラスのヘルパクラスです。
    /// </summary>
    /// <remarks>アセンブリのコード生成・メソッド探索を行います。</remarks>
    internal static class TypeWrapperHelper
    {
        #region 固定定義
        /// <summary>
        /// TypeWrapperクラスのUnsafeGetWrapper&lt;T&gt;メソッドを取得します。
        /// </summary>
        private static readonly MethodInfo GET_WRAPPER_T_METHOD =
            typeof(TypeWrapper).GetMethods(BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly).Where(mi =>
                    (mi.Name == "UnsafeGetWrapper") &&
                    (mi.IsGenericMethod == true) &&
                    (mi.GetParameters().Length == 2)).First();

        /// <summary>
        /// TypeWrapperクラスのUnsafeUnwrap&lt;T&gt;メソッドを取得します。
        /// </summary>
        private static readonly MethodInfo UNWRAP_T_METHOD =
            typeof(TypeWrapper).GetMethods(BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly).Where(mi =>
                    (mi.Name == "UnsafeUnwrap") &&
                    (mi.IsGenericMethod == true) &&
                    (mi.GetParameters().Length == 1)).First();
        #endregion

        #region DefineWrapperMethodIL
        /// <summary>
        /// 指定されたジェネレータに対して、対象のメソッドを呼び出すラッパーメソッドのILを生成します。
        /// </summary>
        /// <param name="methodBuilder">生成対象のメソッド</param>
        /// <param name="defineReturnType">メソッドの戻り値の型</param>
        /// <param name="defineParameterTypes">メソッドのパラメータ型群</param>
        /// <param name="defineParameters">メソッドのパラメータ情報群</param>
        /// <param name="targetMethod">呼び出し対象のインスタンスメソッド</param>
        /// <param name="realInstanceField">メソッドが定義されているクラスのインスタンスが格納されているフィールド</param>
        /// <param name="surrogatorField">サロゲータのインスタンスを保持するフィールド</param>
        /// <remarks>変換が不要な戻り値・引数は、そのまま呼び出し対象のメソッドにバイパスし、
        /// 変換が必要な戻り値・引数は、UnsafeGetWrapper・Unwrapを呼び出して変換するコードを生成します。
        /// 変換を行う事により、擬似的に共変性・反変性規則を与えます。</remarks>
        public static void DefineWrapperMethodIL(
            MethodBuilder methodBuilder,
            Type defineReturnType,
            Type[] defineParameterTypes,
            ParameterBuilder[] defineParameters,
            MethodInfo targetMethod,
            FieldInfo realInstanceField,
            FieldInfo surrogatorField)
        {
            Assertion.Condition(methodBuilder != null);
            Assertion.Condition(defineReturnType != null);
            Assertion.Condition(defineParameterTypes != null);
            Assertion.Condition(defineParameters != null);
            Assertion.Condition(defineParameterTypes.Length == defineParameters.Length);
            Assertion.Condition(targetMethod != null);
            Assertion.Condition(surrogatorField != null);
            Assertion.Condition(defineParameters.Length == targetMethod.GetParameters().Length);

            // 呼び出し対象のメソッドが仮想関数か、スタティックメソッドが、そうでなければフィールドの型にキャスト可能であること
            // （仮想関数なら、メソッド情報を正確な型から取得していなくても良い）
            Assertion.Condition((targetMethod.IsVirtual == true) || (targetMethod.IsStatic == true) ||
                (targetMethod.DeclaringType.IsAssignableFrom(realInstanceField.FieldType) == true));

            // ジェネレータを取得
            var generator = methodBuilder.GetILGenerator();

            // スタティックメソッドでなければ
            if (targetMethod.IsStatic == false)
            {
                Assertion.Condition(realInstanceField != null);

                // フィールドからインスタンスの参照を得る
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Ldfld, realInstanceField);
            }

            // 引数リストを抽出する
            // 抽出したParameterMatchedに対して変更を加えるので、配列化しておく
            var parameterEntries =
                (from defineParameter in defineParameters
                 let defineParameterPosition = defineParameter.Position - 1
                 join targetParameter in targetMethod.GetParameters()
                    on defineParameterPosition equals targetParameter.Position
                 orderby targetParameter.Position
                 select new ParameterMatched
                 {
                     Define = defineParameter,
                     DefineParameterType = defineParameterTypes[defineParameterPosition],
                     Target = targetParameter
                 }).ToArray();

            // 引数をプッシュする
            foreach (var parameterEntry in parameterEntries)
            {
                // 定義側と転送側のout属性の有無が同じである事
                Assertion.Condition(parameterEntry.Define.IsOut == parameterEntry.Target.IsOut);

                // 定義側が参照引数なら
                if (parameterEntry.DefineParameterType.IsByRef == true)
                {
                    // 転送側にもrefの指定がある事
                    Assertion.Condition(parameterEntry.Target.ParameterType.IsByRef == true);

                    // 参照外し（ParameterMatchedに記憶）
                    parameterEntry.DefineUnreferencedType = parameterEntry.DefineParameterType.GetElementType();
                    parameterEntry.TargetUnreferencedType = parameterEntry.Target.ParameterType.GetElementType();

                    // Unwrapが必要なら（キャスト不能）
                    if (parameterEntry.TargetUnreferencedType.IsAssignableFrom(
                        parameterEntry.DefineUnreferencedType) == false)
                    {
                        // ローカル変数を宣言
                        parameterEntry.Local = generator.DeclareLocal(parameterEntry.TargetUnreferencedType);

                        // refなら（outではない）
                        if (parameterEntry.Define.IsOut == false)
                        {
                            // 引数の参照から値を取得
                            ILEmitters.EmitLdarg(generator, parameterEntry.Define.Position);
                            ILEmitters.EmitLdind(generator, parameterEntry.DefineUnreferencedType);

                            // Unwrapを呼び出す
                            var unwrapMethod = UNWRAP_T_METHOD.MakeGenericMethod(parameterEntry.TargetUnreferencedType);
                            generator.Emit(OpCodes.Call, unwrapMethod);

                            // ローカル変数に代入
                            ILEmitters.EmitStloc(generator, parameterEntry.Local.LocalIndex);
                        }

                        // ローカル変数の参照を取得
                        generator.Emit(OpCodes.Ldloca_S, parameterEntry.Local.LocalIndex);
                    }
                    else
                    {
                        // 変換不要
                        // 引数を取得
                        ILEmitters.EmitLdarg(generator, parameterEntry.Define.Position);
                    }
                }
                else
                {
                    // 参照引数ではない
                    ILEmitters.EmitLdarg(generator, parameterEntry.Define.Position);

                    // Unwrapが必要なら（キャスト不能）
                    if (parameterEntry.Target.ParameterType.IsAssignableFrom(parameterEntry.DefineParameterType) == false)
                    {
                        // Unwrapを呼び出す
                        var unwrapMethod = UNWRAP_T_METHOD.MakeGenericMethod(parameterEntry.Target.ParameterType);
                        generator.Emit(OpCodes.Call, unwrapMethod);
                    }
                }
            }

            // メソッドが仮想関数なら
            if (targetMethod.IsVirtual == true)
            {
                generator.Emit(OpCodes.Callvirt, targetMethod);
            }
            else
            {
                generator.Emit(OpCodes.Call, targetMethod);
            }

            // パラメータ（out/ref）の後処理
            foreach (var parameterEntry in
                from parameterEntry in parameterEntries
                where parameterEntry.Local != null
                select parameterEntry)
            {
                // 定義側・参照側の両方がrefであること
                Assertion.Condition(parameterEntry.DefineParameterType.IsByRef == true);
                Assertion.Condition(parameterEntry.Target.ParameterType.IsByRef == true);

                // 定義側・参照側の参照外し型が指定されている事
                Assertion.Condition(parameterEntry.DefineUnreferencedType != null);
                Assertion.Condition(parameterEntry.TargetUnreferencedType != null);

                // 引数を取得
                ILEmitters.EmitLdarg(generator, parameterEntry.Define.Position);

                // ローカル変数から取得する
                ILEmitters.EmitLdloc(generator, parameterEntry.Local.LocalIndex);

                // Wrapが必要なら（キャスト不能）
                if (parameterEntry.DefineUnreferencedType.IsAssignableFrom(parameterEntry.TargetUnreferencedType) == false)
                {
                    // サロゲータをプッシュ
                    generator.Emit(OpCodes.Ldarg_0);
                    generator.Emit(OpCodes.Ldfld, surrogatorField);

                    // Wrapを呼び出す
                    var getWrapperMethod = GET_WRAPPER_T_METHOD.MakeGenericMethod(parameterEntry.DefineUnreferencedType);
                    generator.Emit(OpCodes.Call, getWrapperMethod);
                }

                // 呼び出し元の参照に代入
                ILEmitters.EmitStind(generator, parameterEntry.DefineUnreferencedType);
            }

            // Wrapが必要なら（キャスト不能）
            if (defineReturnType.IsAssignableFrom(targetMethod.ReturnType) == false)
            {
                // サロゲータをプッシュ
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Ldfld, surrogatorField);

                // Wrapを呼び出す
                var getWrapperMethod = GET_WRAPPER_T_METHOD.MakeGenericMethod(defineReturnType);
                generator.Emit(OpCodes.Call, getWrapperMethod);
            }

            generator.Emit(OpCodes.Ret);
        }
        #endregion

        #region DefineWrapperMethod
        /// <summary>
        /// ラッパーメソッドを生成します。
        /// </summary>
        /// <param name="wrapperType">生成対象の型ビルダ</param>
        /// <param name="templateMethod">テンプレートとなるメソッド</param>
        /// <param name="targetMethod">ラップするターゲットメソッド</param>
        /// <param name="realInstanceField">ターゲットメソッドが定義されている型のインスタンスを保持するフィールド</param>
        /// <param name="surrogatorField">サロゲータのインスタンスを保持するフィールド</param>
        /// <returns>メソッド</returns>
        /// <remarks>メソッドの戻り値と引数の型から、自動的にラッパーメソッドを生成します。
        /// ポインタ型を含むメソッドには対応していません。</remarks>
        public static MethodBuilder DefineWrapperMethod(
            TypeBuilder wrapperType,
            MethodInfo templateMethod,
            MethodInfo targetMethod,
            FieldInfo realInstanceField,
            FieldInfo surrogatorField)
        {
            Assertion.Condition(wrapperType != null);
            Assertion.Condition(wrapperType.IsClass == true);
            Assertion.Condition(templateMethod != null);
            Assertion.Condition(templateMethod.DeclaringType.IsAssignableFrom(wrapperType) == true);
            Assertion.Condition(targetMethod != null);
            Assertion.Condition(surrogatorField != null);

            // 呼び出し対象のメソッドが仮想関数か、スタティックメソッドが、そうでなければフィールドの型にキャスト可能であること
            // （仮想関数なら、メソッド情報を正確な型から取得していなくても良い）
            Assertion.Condition((targetMethod.IsVirtual == true) || (targetMethod.IsStatic == true) ||
                (targetMethod.DeclaringType.IsAssignableFrom(realInstanceField.FieldType) == true));

            // テンプレートメソッドからパラメータ情報群を取得する
            var templateParameterInfos = templateMethod.GetParameters();

            // パラメータ型の配列を抽出する
            var templateParameterTypes =
                (from parameterInfo in templateParameterInfos
                 select parameterInfo.ParameterType).ToArray();

            // メソッドを定義する
            var method = wrapperType.DefineMethod(
                templateMethod.Name,
                MethodAttributes.Public | MethodAttributes.Final | MethodAttributes.Virtual,
                templateMethod.CallingConvention,
                templateMethod.ReturnType,
                templateParameterTypes);

            // パラメータ定義を生成する
            var templateParameters =
                (from parameterInfo in templateParameterInfos
                 select method.DefineParameter(parameterInfo.Position + 1, parameterInfo.Attributes, parameterInfo.Name)).ToArray();

            // ILを生成する
            DefineWrapperMethodIL(
                method,
                templateMethod.ReturnType,
                templateParameterTypes,
                templateParameters,
                targetMethod,
                realInstanceField,
                surrogatorField);

            return method;
        }
        #endregion

        #region DefineFieldGetterMethod
        /// <summary>
        /// フィールドから値を取得するメソッドを生成します。
        /// </summary>
        /// <param name="wrapperType">生成対象の型ビルダ</param>
        /// <param name="templateMethod">テンプレートとなるメソッド</param>
        /// <param name="targetField">ターゲットフィールド</param>
        /// <param name="realInstanceField">ターゲットフィールドが定義されている型のインスタンスを保持するフィールド</param>
        /// <param name="surrogatorField">サロゲータのインスタンスを保持するフィールド</param>
        /// <returns>メソッドビルダ</returns>
        public static MethodBuilder DefineFieldGetterMethod(
            TypeBuilder wrapperType,
            MethodInfo templateMethod,
            FieldInfo targetField,
            FieldBuilder realInstanceField,
            FieldBuilder surrogatorField)
        {
            Assertion.Condition(wrapperType != null);
            Assertion.Condition(wrapperType.IsClass == true);
            Assertion.Condition(templateMethod != null);
            Assertion.Condition(templateMethod.GetParameters().Length == 0);
            Assertion.Condition(templateMethod.ReturnType != typeof(void));
            Assertion.Condition(targetField != null);
            Assertion.Condition(surrogatorField != null);

            // メソッドを定義する
            var method = wrapperType.DefineMethod(
                templateMethod.Name,
                MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.Final,
                templateMethod.CallingConvention,
                templateMethod.ReturnType,
                Type.EmptyTypes);

            // ジェネレータを取得
            var generator = method.GetILGenerator();

            // インスタンスフィールドが存在すれば（インスタンスラッパー）
            if (realInstanceField != null)
            {
                // フィールドからインスタンスの参照を得る
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Ldfld, realInstanceField);

                // ターゲットフィールドから値を取得する
                generator.Emit(OpCodes.Ldfld, targetField);
            }
            else
            {
                // スタティックラッパーなら
                // ターゲットフィールドから値を取得する
                generator.Emit(OpCodes.Ldsfld, targetField);
            }

            // Wrapが必要なら（キャスト不能）
            if (templateMethod.ReturnType.IsAssignableFrom(targetField.FieldType) == false)
            {
                // サロゲータをプッシュ
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Ldfld, surrogatorField);

                // Wrapを呼び出す
                var getWrapperMethod = GET_WRAPPER_T_METHOD.MakeGenericMethod(templateMethod.ReturnType);
                generator.Emit(OpCodes.Call, getWrapperMethod);
            }

            generator.Emit(OpCodes.Ret);

            return method;
        }
        #endregion

        #region DefineFieldSetterMethod
        /// <summary>
        /// フィールドに値を設定するメソッドを生成します。
        /// </summary>
        /// <param name="wrapperType">生成対象の型ビルダ</param>
        /// <param name="templateMethod">テンプレートとなるメソッド</param>
        /// <param name="targetField">ターゲットフィールド</param>
        /// <param name="realInstanceField">ターゲットフィールドが定義されている型のインスタンスを保持するフィールド</param>
        /// <param name="surrogatorField">サロゲータのインスタンスを保持するフィールド</param>
        /// <returns>メソッドビルダ</returns>
        public static MethodBuilder DefineFieldSetterMethod(
            TypeBuilder wrapperType,
            MethodInfo templateMethod,
            FieldInfo targetField,
            FieldBuilder realInstanceField,
            FieldBuilder surrogatorField)
        {
            Assertion.Condition(wrapperType != null);
            Assertion.Condition(wrapperType.IsClass == true);
            Assertion.Condition(templateMethod != null);
            Assertion.Condition(templateMethod.GetParameters().Length == 1);
            Assertion.Condition(templateMethod.ReturnType == typeof(void));
            Assertion.Condition(targetField != null);
            Assertion.Condition((targetField.IsInitOnly == false) && (targetField.IsLiteral == false));
            Assertion.Condition(surrogatorField != null);

            // パラメータの型を得る
            var parameterTypes =
                (from parameterInfo in templateMethod.GetParameters()
                 select parameterInfo.ParameterType).ToArray();

            // メソッドを定義する
            var method = wrapperType.DefineMethod(
                templateMethod.Name,
                MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.Final,
                templateMethod.CallingConvention,
                templateMethod.ReturnType,
                parameterTypes);

            // ジェネレータを取得
            var generator = method.GetILGenerator();

            // インスタンスフィールドが存在すれば（インスタンスラッパー）
            if (realInstanceField != null)
            {
                // フィールドからインスタンスの参照を得る
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Ldfld, realInstanceField);
            }

            // 引数をロード
            generator.Emit(OpCodes.Ldarg_1);

            // Unwrapが必要なら（キャスト不能）
            if (targetField.FieldType.IsAssignableFrom(parameterTypes[0]) == false)
            {
                // Unwrapを呼び出す
                var unwrapMethod = UNWRAP_T_METHOD.MakeGenericMethod(targetField.FieldType);
                generator.Emit(OpCodes.Call, unwrapMethod);
            }

            // インスタンスフィールドが存在すれば（インスタンスラッパー）
            if (realInstanceField != null)
            {
                // ターゲットフィールドに値を設定する
                generator.Emit(OpCodes.Stfld, targetField);
            }
            else
            {
                // スタティックラッパーなら
                // ターゲットフィールドに値を設定する
                generator.Emit(OpCodes.Stsfld, targetField);
            }

            generator.Emit(OpCodes.Ret);

            return method;
        }
        #endregion

        #region DefineSurrogationMethod
        /// <summary>
        /// サロゲータの実装を呼び出すメソッドを生成します。
        /// </summary>
        /// <param name="wrapperType">生成対象の型ビルダ</param>
        /// <param name="methodName">メソッド名</param>
        /// <param name="targetMethod">サロゲータのターゲットメソッド</param>
        /// <param name="realInstanceField">ターゲットメソッドが定義されている型のインスタンスを保持するフィールド</param>
        /// <param name="surrogatorField">サロゲータのインスタンスを保持するフィールド</param>
        /// <returns>メソッドビルダ</returns>
        /// <remarks>生成されるメソッドの引数群は、ターゲットメソッドの引数群の2番目以降の定義が使用されます。</remarks>
        public static MethodBuilder DefineSurrogationMethod(
            TypeBuilder wrapperType,
            string methodName,
            MethodInfo targetMethod,
            FieldBuilder realInstanceField,
            FieldBuilder surrogatorField)
        {
            Assertion.Condition(wrapperType != null);
            Assertion.Condition(wrapperType.IsClass == true);
            Assertion.Condition(string.IsNullOrWhiteSpace(methodName) == false);
            Assertion.Condition(targetMethod != null);
            Assertion.Condition(targetMethod.GetParameters().Length >= 1);
            Assertion.Condition(targetMethod.GetParameters()[0].ParameterType == typeof(object));
            Assertion.Condition(surrogatorField != null);

            // ターゲットメソッドからパラメータ情報群を取得する
            var targetParameterInfos = targetMethod.GetParameters();

            // パラメータ型の配列を抽出する（先頭はサロゲータを指定するので除外）
            var targetParameterTypes =
                (from parameterInfo in targetParameterInfos
                 select parameterInfo.ParameterType).Skip(1).ToArray();

            // メソッドを定義する
            var method = wrapperType.DefineMethod(
                methodName,
                MethodAttributes.Public | MethodAttributes.Virtual | MethodAttributes.Final,
                targetMethod.CallingConvention,
                targetMethod.ReturnType,
                targetParameterTypes);

            // ジェネレータを取得
            var generator = method.GetILGenerator();

            // フィールドからサロゲータの参照を得る（this）
            generator.Emit(OpCodes.Ldarg_0);
            generator.Emit(OpCodes.Ldfld, surrogatorField);

            // インスタンスフィールドが存在すれば（インスタンスラッパー）
            if (realInstanceField != null)
            {
                // フィールドからインスタンスの参照を得る（arg0）
                generator.Emit(OpCodes.Ldarg_0);
                generator.Emit(OpCodes.Ldfld, realInstanceField);
            }
            else
            {
                // スタティックラッパーなら
                // nullをプッシュ
                generator.Emit(OpCodes.Ldnull);
            }

            // 引数をプッシュ（arg1...n）
            for (var i = 1; i < targetParameterInfos.Length; i++)
            {
                // 引数をロード
                ILEmitters.EmitLdarg(generator, i - ((realInstanceField != null) ? 0 : 1));

                // Unwrapを呼び出す
                var unwrapMethod = UNWRAP_T_METHOD.MakeGenericMethod(targetParameterInfos[i].ParameterType);
                generator.Emit(OpCodes.Call, unwrapMethod);
            }

            // サロゲータのメソッドを呼び出す
            generator.Emit(OpCodes.Callvirt, targetMethod);
            generator.Emit(OpCodes.Ret);

            return method;
        }
        #endregion

        #region InternalFindMember
        /// <summary>
        /// 指定された引数の型を比較します。
        /// </summary>
        /// <param name="parameterType">比較する型</param>
        /// <param name="resultParameterType">比較される型（代入可能性）</param>
        /// <param name="equalCount">一致件数</param>
        /// <param name="assignableCount">代入可能件数</param>
        /// <param name="genericCount">ジェネリック型件数</param>
        /// <param name="genericParameterCount">ジェネリックパラメータの再帰一致件数</param>
        internal static void CheckArgumentType(
            Type parameterType,
            Type resultParameterType,
            ref int equalCount,
            ref int assignableCount,
            ref int genericCount,
            ref int genericParameterCount)
        {
            // 完全一致している場合
            if (resultParameterType == parameterType)
            {
                equalCount++;
            }

            // キャスト可能な場合（System.Object引数はカウントしない）
            if ((resultParameterType != typeof(object)) &&
                (resultParameterType.IsAssignableFrom(parameterType) == true))
            {
                assignableCount++;
            }

            // ジェネリックの一致
            if (resultParameterType.IsGenericType == parameterType.IsGenericType)
            {
                genericCount++;

                if (resultParameterType.IsGenericType == true)
                {
                    CheckArgumentTypes(
                        parameterType.GetGenericArguments(),
                        resultParameterType.GetGenericArguments(),
                        ref genericParameterCount,
                        ref genericParameterCount,
                        ref genericParameterCount,
                        ref genericParameterCount);
                }
            }
        }

        /// <summary>
        /// 指定された引数群の型を比較します。
        /// </summary>
        /// <param name="parameterTypes">比較する型群</param>
        /// <param name="resultParameterTypes">比較される型群（代入可能性）</param>
        /// <param name="equalCount">一致件数</param>
        /// <param name="assignableCount">代入可能件数</param>
        /// <param name="genericCount">ジェネリック型件数</param>
        /// <param name="genericParameterCount">ジェネリックパラメータの再帰一致件数</param>
        internal static void CheckArgumentTypes(
            Type[] parameterTypes,
            Type[] resultParameterTypes,
            ref int equalCount,
            ref int assignableCount,
            ref int genericCount,
            ref int genericParameterCount)
        {
            Assertion.Condition(parameterTypes != null);
            Assertion.Condition(resultParameterTypes != null);

            // 引数群のチェック
            for (var i = 0; i < parameterTypes.Length; i++)
            {
                CheckArgumentType(
                    parameterTypes[i],
                    resultParameterTypes[i],
                    ref equalCount,
                    ref assignableCount,
                    ref genericCount,
                    ref genericParameterCount);
            }
        }

        /// <summary>
        /// 指定されたシグネチャを持つ候補となるメンバ群を検索します。
        /// </summary>
        /// <typeparam name="T">メンバ情報の型</typeparam>
        /// <param name="type">検索する型</param>
        /// <param name="memberName">メンバ名</param>
        /// <param name="memberType">メンバを表現する型（メソッド戻り値型・プロパティ型・イベントハンドラ型）</param>
        /// <param name="parameterTypes">メンバ引数型群</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <param name="memberInfoOperator">メンバ情報オペレータ</param>
        /// <returns>候補となるメンバ</returns>
        /// <returns>候補となるメンバが無い場合はnull</returns>
        internal static T InternalFindMember<T>(
            Type type,
            string memberName,
            Type memberType,
            Type[] parameterTypes,
            bool isStatic,
            IMemberInfoOperator<T> memberInfoOperator)
            where T : MemberInfo
        {
            Assertion.Condition(type != null);
            Assertion.Condition(string.IsNullOrWhiteSpace(memberName) == false);
            Assertion.Condition(memberType != null);
            Assertion.Condition(parameterTypes != null);
            Assertion.Condition(memberInfoOperator != null);

            // 当初、デフォルトバインダを使って判定していたが、結局通常では考えられない（キャストできない）場合でも
            // マッチ判定させる必要があるため、独自に判定する。
            // なお、ラップ可能性の確率までは判定していない（今の構造では無理）ので、ベストなアルゴリズムではない。

            // 指定された型からメンバ情報群を得る
            var memberInfos =
                from memberInfo in memberInfoOperator.GetMembers(type, isStatic)
                where memberInfo.Name == memberName
                select memberInfo;

            // メンバの型と引数の個数が同じメソッドに絞り込む
            var memberTypeIsVoid = memberType == typeof(void);
            var equalParameterCountResults =
                from memberInfo in memberInfos
                let parameterInfos = memberInfoOperator.GetParameters(memberInfo)
                where

                    // メンバの型がvoidならこのメンバもvoid、そうでなければメンバも戻り値を持つ
                    ((memberInfoOperator.GetMemberType(memberInfo) == typeof(void)) == memberTypeIsVoid) &&
                    (parameterInfos.Length == parameterTypes.Length)
                select new
                {
                    // メソッド情報
                    Member = memberInfo,

                    // パラメータ型群に変換
                    ParameterTypes =
                        (from parameter in parameterInfos
                         select parameter.ParameterType).ToArray()
                };

            // 戻り値と引数群が完全に一致している個数（EqualCount）と、キャスト可能な個数（AssignableCount）を集計する。
            // System.Objectへのキャストは必ず成功してしまうため、集計から除外する
            var statResults =
                equalParameterCountResults.Select((equalParameterCountResult) =>
                {
                    Assertion.Condition(equalParameterCountResult.ParameterTypes.Length == parameterTypes.Length);

                    int equalCount = 0, assignableCount = 0, genericCount = 0, genericParameterCount = 0;

                    // 戻り値のチェック
                    // （完全一致・キャスト可能（System.Object引数はカウントしない）・ジェネリック一致・ジェネリック引数）
                    var resultMemberType = memberInfoOperator.GetMemberType(equalParameterCountResult.Member);
                    CheckArgumentType(
                        memberType,
                        resultMemberType,
                        ref equalCount,
                        ref assignableCount,
                        ref genericCount,
                        ref genericParameterCount);

                    // 引数群のチェック
                    CheckArgumentTypes(
                        parameterTypes,
                        equalParameterCountResult.ParameterTypes,
                        ref equalCount,
                        ref assignableCount,
                        ref genericCount,
                        ref genericParameterCount);

                    // テンポラリに入れる
                    return new
                    {
                        Member = equalParameterCountResult.Member,
                        EqualCount = equalCount,
                        AssignableCount = assignableCount,
                        GenericCount = genericCount,
                        GenericParameterCount = genericParameterCount
                    };
                });

            // 一致件数・キャスト可能件数・ジェネリック一致件数・ジェネリック引数件数・ジェネリック型・ジェネリックメンバの順でソートする
            // ジェネリックについて、例えばCountの場合、
            // ICollection.Countよりも、ICollection<T>.Countにマッチしたほうがより望ましいため。
            var mostAcceptableResults =
                from result in statResults
                let isGenericType = result.Member.DeclaringType.IsGenericType ? 1 : 0
                let isGenericMember = memberInfoOperator.IsGenericMember(result.Member) ? 1 : 0
                orderby
                    result.EqualCount descending, result.AssignableCount descending,
                    result.GenericCount descending, result.GenericParameterCount descending,
                    isGenericType descending, isGenericMember descending
                select result.Member;

            // 先頭を返す（一致の可能性が高い順にソートされている）
            return mostAcceptableResults.FirstOrDefault();
        }
        #endregion

        #region InternalFindMemberFromClass
        /// <summary>
        /// 指定されたクラスに定義されている、指定された名前と引数型群を持つメンバを取得します。
        /// </summary>
        /// <typeparam name="T">メンバ情報の型</typeparam>
        /// <param name="type">クラスの型</param>
        /// <param name="memberName">メンバ名</param>
        /// <param name="memberType">メンバを表現する型（メソッド戻り値型・プロパティ型・イベントハンドラ型）</param>
        /// <param name="parameterTypes">メンバ引数型群</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <param name="memberInfoOperator">メンバ情報オペレータ</param>
        /// <returns>メンバが存在しない場合はnull</returns>
        /// <remarks>引数と戻り値が出来るだけ一致するように、オーバーロードされたメンバ群から選択して返します。
        /// 検索は、引数で指定されたクラス（末端）から、クラス階層上部（System.Object）に向かって行われます。</remarks>
        public static T InternalFindMemberFromClass<T>(
            Type type,
            string memberName,
            Type memberType,
            Type[] parameterTypes,
            bool isStatic,
            IMemberInfoOperator<T> memberInfoOperator)
            where T : MemberInfo
        {
            Assertion.Condition(type != null);
            Assertion.Condition(type.IsClass == true);
            Assertion.Condition(string.IsNullOrWhiteSpace(memberName) == false);
            Assertion.Condition(memberType != null);
            Assertion.Condition(parameterTypes != null);
            Assertion.Condition(memberInfoOperator != null);

            var currentType = type;
            while (true)
            {
                // クラスに定義されているメンバの候補を検索する
                T mostAcceptableResult = InternalFindMember(
                    currentType,
                    memberName,
                    memberType,
                    parameterTypes,
                    isStatic,
                    memberInfoOperator);

                // 候補があれば
                if (mostAcceptableResult != null)
                {
                    return mostAcceptableResult;
                }

                // このクラスに実装されているインターフェイスを列挙
                // TODO:全部のインターフェイスがいつも列挙されている
                foreach (var interfaceType in currentType.GetInterfaces())
                {
                    // インターフェイスに定義されているメンバの候補を検索する
                    mostAcceptableResult = InternalFindMember(
                        interfaceType,
                        memberName,
                        memberType,
                        parameterTypes,
                        isStatic,
                        memberInfoOperator);

                    // 候補があれば
                    if (mostAcceptableResult != null)
                    {
                        return mostAcceptableResult;
                    }
                }

                // これがSystem.Objectではない事（クラスの基底に達したかどうか）
                if (currentType == typeof(object))
                {
                    return default(T);
                }

                // 一つ上のクラスへ
                currentType = currentType.BaseType;
            }
        }
        #endregion

        #region FindPropertyOrField
        /// <summary>
        /// 指定されたクラスに定義されている、指定された名前と引数型群を持つプロパティ又はインデクサを取得します。
        /// </summary>
        /// <param name="type">クラスの型</param>
        /// <param name="propertyName">プロパティ名</param>
        /// <param name="propertyType">プロパティの型</param>
        /// <param name="parameterTypes">インデクサ引数型群</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <returns>プロパティ又はフィールド情報</returns>
        /// <remarks>引数と戻り値が出来るだけ一致するように、オーバーロードされたプロパティ・インデクサ・フィールド群から選択して返します。
        /// 検索は、引数で指定されたクラス（末端）から、クラス階層上部（System.Object）に向かって行われます。</remarks>
        public static MemberInfo FindPropertyOrField(
            Type type,
            string propertyName,
            Type propertyType,
            Type[] parameterTypes,
            bool isStatic)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(type.IsClass == true);
            Assertion.Condition(string.IsNullOrWhiteSpace(propertyName) == false);
            Assertion.Condition(propertyType != null);
            Assertion.Condition(parameterTypes != null);

            var propertyInfo = InternalFindMemberFromClass(
                type,
                propertyName,
                propertyType,
                parameterTypes,
                isStatic,
                PropertyList.Operator);
            if (propertyInfo != null)
            {
                return propertyInfo;
            }

            Assertion.Require<TypeWrapperException>(
                parameterTypes.Length == 0,
                "型 {0} には、推論可能なプロパティ又はインデクサ {1}{2} が定義されていません",
                type.FullName,
                isStatic ? "static " : string.Empty,
                propertyName);

            var fieldInfo = InternalFindMemberFromClass(
                type,
                propertyName,
                propertyType,
                parameterTypes,
                isStatic,
                FieldList.Operator);

            Assertion.Require<TypeWrapperException>(
                fieldInfo != null,
                "型 {0} には、推論可能なプロパティ・インデクサ・フィールド {1}{2} が定義されていません",
                type.FullName,
                isStatic ? "static " : string.Empty,
                propertyName);

            return fieldInfo;
        }
        #endregion

        #region FindEvent
        /// <summary>
        /// 指定されたクラスに定義されている、指定された名前を持つイベントを取得します。
        /// </summary>
        /// <param name="type">クラスの型</param>
        /// <param name="eventName">イベント名</param>
        /// <param name="eventType">イベントハンドラの型</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <returns>イベント</returns>
        /// <remarks>イベントハンドラの型が出来るだけ一致するように、オーバーロードされたイベント群から選択して返します。
        /// 検索は、引数で指定されたクラス（末端）から、クラス階層上部（System.Object）に向かって行われます。</remarks>
        public static EventInfo FindEvent(
            Type type,
            string eventName,
            Type eventType,
            bool isStatic)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(type.IsClass == true);
            Assertion.Condition(string.IsNullOrWhiteSpace(eventName) == false);
            Assertion.Condition(eventType != null);

            var eventInfo = InternalFindMemberFromClass(
                type,
                eventName,
                eventType,
                Type.EmptyTypes,
                isStatic,
                EventList.Operator);

            Assertion.Require<TypeWrapperException>(
                eventInfo != null,
                "型 {0} には、推論可能なイベント {1}{2} が定義されていません",
                type.FullName,
                isStatic ? "static " : string.Empty,
                eventName);

            return eventInfo;
        }
        #endregion

        #region FindMethod
        /// <summary>
        /// 指定されたクラスに定義されている、指定された名前と引数型群を持つメソッドを取得します。
        /// </summary>
        /// <param name="type">クラスの型</param>
        /// <param name="methodName">メソッド名</param>
        /// <param name="returnType">戻り値の型</param>
        /// <param name="parameterTypes">メソッド引数型群</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <returns>メソッド</returns>
        /// <remarks>引数と戻り値が出来るだけ一致するように、オーバーロードされたメソッド群から選択して返します。
        /// 検索は、引数で指定されたクラス（末端）から、クラス階層上部（System.Object）に向かって行われます。</remarks>
        public static MethodInfo FindMethod(
            Type type,
            string methodName,
            Type returnType,
            Type[] parameterTypes,
            bool isStatic)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(type.IsClass == true);
            Assertion.Condition(string.IsNullOrWhiteSpace(methodName) == false);
            Assertion.Condition(returnType != null);
            Assertion.Condition(parameterTypes != null);

            var methodInfo = InternalFindMemberFromClass(
                type,
                methodName,
                returnType,
                parameterTypes,
                isStatic,
                MethodList.Operator);

            Assertion.Require<TypeWrapperException>(
                methodInfo != null,
                "型 {0} には、推論可能なメソッド {1}{2} が定義されていません",
                type.FullName,
                isStatic ? "static " : string.Empty,
                methodName);

            return methodInfo;
        }
        #endregion

        #region ParameterMatched
        /// <summary>
        /// 一致したパラメータの情報を格納するクラスです。
        /// </summary>
        internal sealed class ParameterMatched
        {
            /// <summary>
            /// 定義側のパラメータ型を取得・設定します。
            /// </summary>
            public Type DefineParameterType
            {
                get;
                set;
            }

            /// <summary>
            /// 定義側のパラメータ情報を取得・設定します。
            /// </summary>
            public ParameterBuilder Define
            {
                get;
                set;
            }

            /// <summary>
            /// 転送側のパラメータ情報を取得・設定します。
            /// </summary>
            public ParameterInfo Target
            {
                get;
                set;
            }

            /// <summary>
            /// 定義側の参照外しを行った型を取得・設定します。
            /// </summary>
            public Type DefineUnreferencedType
            {
                get;
                set;
            }

            /// <summary>
            /// 転送側の参照外しを行った型を取得・設定します。
            /// </summary>
            public Type TargetUnreferencedType
            {
                get;
                set;
            }

            /// <summary>
            /// このパラメータに対応するローカル変数定義を取得・設定します。
            /// </summary>
            public LocalBuilder Local
            {
                get;
                set;
            }
        }
        #endregion
    }
}

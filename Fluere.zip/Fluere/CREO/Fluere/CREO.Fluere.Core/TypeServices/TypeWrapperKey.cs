﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// 元となる型と動的に実装させるインターフェイスとの対応付けを管理するクラスです。
    /// </summary>
    internal sealed class TypeWrapperKey
    {
        /// <summary>
        /// 元の型
        /// </summary>
        private readonly Type _fromType;

        /// <summary>
        /// インターフェイス
        /// </summary>
        private readonly Type _toType;

        /// <summary>
        /// 元の型のスタティックメンバをラップ
        /// </summary>
        private readonly bool _isStatic;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="fromType">元の型</param>
        /// <param name="toType">ラッパーのインターフェイス</param>
        /// <param name="isStatic">スタティックメンバのラップならtrue</param>
        public TypeWrapperKey(Type fromType, Type toType, bool isStatic)
        {
            Assertion.Condition(fromType != null);
            Assertion.Condition(toType != null);
            Assertion.Condition(toType.IsInterface == true);

            this._fromType = fromType;
            this._toType = toType;
            this._isStatic = isStatic;
        }

        /// <summary>
        /// 元の型を取得します。
        /// </summary>
        public Type FromType
        {
            get
            {
                return this._fromType;
            }
        }

        /// <summary>
        /// ラッパーのインターフェイスを取得します。
        /// </summary>
        public Type ToType
        {
            get
            {
                return this._toType;
            }
        }

        /// <summary>
        /// スタティックメンバのラップかどうかを取得します。
        /// </summary>
        public bool IsStatic
        {
            get
            {
                return this._isStatic;
            }
        }

        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <returns>ハッシュコード</returns>
        public override int GetHashCode()
        {
            return this._fromType.GetHashCode() ^ this._toType.GetHashCode() ^ this._isStatic.GetHashCode();
        }

        /// <summary>
        /// インスタンスが同じかどうかを取得します。
        /// </summary>
        /// <param name="obj">対象のインスタンス</param>
        /// <returns>同じ値であればtrue</returns>
        public bool Equals(TypeWrapperKey obj)
        {
            if (obj == null)
            {
                return false;
            }

            return
                this._fromType.Equals(obj._fromType) &&
                this._toType.Equals(obj._toType) &&
                this._isStatic.Equals(obj._isStatic);
        }

        /// <summary>
        /// インスタンスが同じかどうかを取得します。
        /// </summary>
        /// <param name="obj">対象のインスタンス</param>
        /// <returns>同じ値であればtrue</returns>
        public override bool Equals(object obj)
        {
            return this.Equals(obj as TypeWrapperKey);
        }

        /// <summary>
        /// このインスタンスの文字列表現を取得します。
        /// </summary>
        /// <returns>文字列</returns>
        public override string ToString()
        {
            return string.Format(
                "[{0}{1}] --> [{2}]",
                this._isStatic ? "static " : string.Empty,
                this._fromType.FullName,
                this._toType.FullName);
        }
    }
}

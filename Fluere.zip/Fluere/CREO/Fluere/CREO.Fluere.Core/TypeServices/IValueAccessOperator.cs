﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.22 TMI K.Matsui

using System.Reflection;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// メンバから値を取得するインターフェイスです。
    /// </summary>
    /// <typeparam name="T">対象のメンバ情報型</typeparam>
    internal interface IValueAccessOperator<T> : IMemberInfoOperator<T>
        where T : MemberInfo
    {
        /// <summary>
        /// 指定されたメンバから値を取得します。
        /// </summary>
        /// <param name="memberInfo">メンバ情報</param>
        /// <param name="instance">インスタンス</param>
        /// <returns>値</returns>
        object GetValue(T memberInfo, object instance);
    }
}

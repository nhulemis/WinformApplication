﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.22 TMI K.Matsui

using System.Diagnostics;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// TypeWrapperでスタティックラッパーのインスタンスを生成するファクトリの基底クラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    [DebuggerNonUserCode]
    public abstract class TypeWrapperStaticFactoryBase : TypeWrapperFactoryBase
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        protected TypeWrapperStaticFactoryBase()
        {
        }

        /// <summary>
        /// 辞書をクリーンアップします。
        /// </summary>
        /// <returns>削除されたエントリの比</returns>
        /// <remarks>不要なWeakReferenceを辞書から削除します。</remarks>
        public override double Cleanup()
        {
            return 0;
        }

        /// <summary>
        /// 指定されたインスタンスのラッパーインスタンスを取得します。
        /// </summary>
        /// <param name="instance">インスタンス</param>
        /// <param name="surrogator">サロゲータ</param>
        /// <returns>ラッパーインスタンス</returns>
        public override object GetWrapper(object instance, ITypeWrapperSurrogator surrogator)
        {
            Assertion.Condition(instance == null);
            Assertion.Condition(surrogator != null);

            return this.CreateWrapper(instance, surrogator);
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.07.02 TMI K.Matsui

using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// メンバ群を動的に定義するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal static class TypeWrapperMembersCreator
    {
        /// <summary>
        /// ラッパークラスにプロパティを定義します。
        /// </summary>
        /// <param name="wrapperKey">型の組み合わせを示すキー</param>
        /// <param name="wrapperType">プロパティを定義する動的に生成したクラス</param>
        /// <param name="realInstanceField">元のクラスのインスタンスを格納するフィールド</param>
        /// <param name="surrogatorField">サロゲータのインスタンスを保持するフィールド</param>
        /// <param name="overrided">オーバーライド済みのメソッドを格納する辞書</param>
        /// <remarks>元のクラスに定義されている、パブリックかつオーバーライドの最上位に位置するプロパティ群に
        /// 対応したラッパークラスのプロパティを生成し、全てのラップインターフェイスのプロパティを関連付け、
        /// バイパスするコードを生成します。</remarks>
        public static void DefineProperties(
            TypeWrapperKey wrapperKey,
            TypeBuilder wrapperType,
            FieldBuilder realInstanceField,
            FieldBuilder surrogatorField,
            ISet<MethodInfo> overrided)
        {
            Assertion.Condition(wrapperKey != null);
            Assertion.Condition(wrapperType != null);
            Assertion.Condition(surrogatorField != null);
            Assertion.Condition(overrided != null);

            // 元のクラスが公開するプロパティを全て列挙する
            var fromDictionary = PropertyList.GetListByOverrided(wrapperKey.FromType, wrapperKey.IsStatic);

            // ラップインターフェイスのプロパティを全て列挙する
            foreach (var toEntry in PropertyList.GetImplementedListByOverrided(wrapperKey.ToType))
            {
                // 名前と引数型群を指定してプロパティを取得する
                var fromMember = TypeWrapperHelper.FindPropertyOrField(
                    wrapperKey.FromType,
                    toEntry.Key.Name,
                    toEntry.Key.Type,
                    toEntry.Key.AdditionalTypes,
                    wrapperKey.IsStatic);

                // プロパティを生成する
                var propertyBuilder = wrapperType.DefineProperty(
                    toEntry.Key.Name,
                    PropertyAttributes.None,
                    toEntry.Key.Type,
                    toEntry.Key.AdditionalTypes);

                // プロパティなら
                var fromProperty = fromMember as PropertyInfo;
                if (fromProperty != null)
                {
                    // クラスプロパティのgetter/setterを取得する
                    var fromGetter = fromProperty.GetGetMethod();
                    var fromSetter = fromProperty.GetSetMethod();

                    // ラップインターフェイスのプロパティ群を全て列挙し、同一のクラスプロパティにバイパスする
                    MethodBuilder wrapperGetter = null;
                    MethodBuilder wrapperSetter = null;
                    foreach (var toProperty in toEntry.Value)
                    {
                        // ラップインターフェイスにgetterがある
                        if (toProperty.CanRead == true)
                        {
                            // クラス側にgetterが必要
                            Assertion.Require<TypeWrapperException>(
                                fromGetter != null,
                                "プロパティ {0}.{1} に get がありません: インターフェイス={2}",
                                fromProperty.DeclaringType.FullName,
                                fromProperty.Name,
                                toProperty.DeclaringType.FullName);

                            // ラップインターフェイスのgetterを取得する
                            var toGetter = toProperty.GetGetMethod();
                            Assertion.Condition(toGetter != null);
                            Assertion.Condition(toGetter.ReturnType == propertyBuilder.PropertyType);

                            // ラッパーのgetterがまだ定義されていない
                            if (wrapperGetter == null)
                            {
                                // getterメソッドを生成する
                                wrapperGetter = TypeWrapperHelper.DefineWrapperMethod(
                                    wrapperType, toGetter, fromGetter, realInstanceField, surrogatorField);

                                // クラスプロパティに実装
                                propertyBuilder.SetGetMethod(wrapperGetter);
                            }

                            // ラッパークラスのgetterをインターフェイスに実装
                            wrapperType.DefineMethodOverride(wrapperGetter, toGetter);

                            // このメソッドを実装済み
                            overrided.Add(toGetter);
                        }

                        // ラップインターフェイスにsetterがある
                        if (toProperty.CanWrite == true)
                        {
                            // クラス側にsetterが必要
                            Assertion.Require<TypeWrapperException>(
                                fromSetter != null,
                                "プロパティ {0}.{1} に set がありません: インターフェイス={2}",
                                fromProperty.DeclaringType.FullName,
                                fromProperty.Name,
                                toProperty.DeclaringType.FullName);

                            Assertion.Condition(fromSetter.ReturnType == typeof(void));

                            // ラップインターフェイスのsetterを取得する
                            var toSetter = toProperty.GetSetMethod();
                            Assertion.Condition(toSetter != null);
                            Assertion.Condition(toSetter.ReturnType == typeof(void));

                            // ラッパーのgetterがまだ定義されていない
                            if (wrapperSetter == null)
                            {
                                // setterメソッドを生成する
                                wrapperSetter = TypeWrapperHelper.DefineWrapperMethod(
                                    wrapperType, toSetter, fromSetter, realInstanceField, surrogatorField);

                                // クラスプロパティに実装
                                propertyBuilder.SetSetMethod(wrapperSetter);
                            }

                            // ラッパークラスのsetterをインターフェイスに実装
                            wrapperType.DefineMethodOverride(wrapperSetter, toSetter);

                            // このメソッドを実装済み
                            overrided.Add(toSetter);
                        }
                    }
                }
                else
                {
                    // フィールドなら
                    var fromField = fromMember as FieldInfo;

                    Assertion.Condition(fromField != null);

                    // ラップインターフェイスのプロパティ群を全て列挙し、同一のクラスフィールドにバイパスする
                    MethodBuilder wrapperGetter = null;
                    MethodBuilder wrapperSetter = null;
                    foreach (var toProperty in toEntry.Value)
                    {
                        // ラップインターフェイスにgetterがある
                        if (toProperty.CanRead == true)
                        {
                            // ラップインターフェイスのgetterを取得する
                            var toGetter = toProperty.GetGetMethod();
                            Assertion.Condition(toGetter != null);
                            Assertion.Condition(toGetter.ReturnType == propertyBuilder.PropertyType);

                            // ラッパーのgetterがまだ定義されていない
                            if (wrapperGetter == null)
                            {
                                // getterメソッドを生成する
                                wrapperGetter = TypeWrapperHelper.DefineFieldGetterMethod(
                                    wrapperType, toGetter, fromField, realInstanceField, surrogatorField);

                                // クラスプロパティに実装
                                propertyBuilder.SetGetMethod(wrapperGetter);
                            }

                            // ラッパークラスのgetterをインターフェイスに実装
                            wrapperType.DefineMethodOverride(wrapperGetter, toGetter);

                            // このメソッドを実装済み
                            overrided.Add(toGetter);
                        }

                        // ラップインターフェイスにsetterがある
                        if (toProperty.CanWrite == true)
                        {
                            // クラス側のフィールドは設定可能でなければならない
                            Assertion.Require<TypeWrapperException>(
                                (fromField.Attributes & (FieldAttributes.InitOnly | FieldAttributes.Literal)) == new FieldAttributes(),
                                "フィールド {0}.{1} は読み取り専用です: インターフェイス={2}",
                                fromField.DeclaringType.FullName,
                                fromField.Name,
                                toProperty.DeclaringType.FullName);

                            // ラップインターフェイスのsetterを取得する
                            var toSetter = toProperty.GetSetMethod();
                            Assertion.Condition(toSetter != null);
                            Assertion.Condition(toSetter.ReturnType == typeof(void));

                            // ラッパーのgetterがまだ定義されていない
                            if (wrapperSetter == null)
                            {
                                // setterメソッドを生成する
                                wrapperSetter = TypeWrapperHelper.DefineFieldSetterMethod(
                                    wrapperType, toSetter, fromField, realInstanceField, surrogatorField);

                                // クラスプロパティに実装
                                propertyBuilder.SetSetMethod(wrapperSetter);
                            }

                            // ラッパークラスのsetterをインターフェイスに実装
                            wrapperType.DefineMethodOverride(wrapperSetter, toSetter);

                            // このメソッドを実装済み
                            overrided.Add(toSetter);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// ラッパークラスにイベントを定義します。
        /// </summary>
        /// <param name="wrapperKey">型の組み合わせを示すキー</param>
        /// <param name="wrapperType">イベントを定義する動的に生成したクラス</param>
        /// <param name="realInstanceField">元のクラスのインスタンスを格納するフィールド</param>
        /// <param name="surrogatorField">サロゲータのインスタンスを保持するフィールド</param>
        /// <param name="overrided">オーバーライド済みのメソッドを格納する辞書</param>
        /// <remarks>元のクラスに定義されている、パブリックかつオーバーライドの最上位に位置するイベント群に
        /// 対応したラッパークラスのイベントを生成し、全てのラップインターフェイスのプロパティを関連付け、
        /// バイパスするコードを生成します。</remarks>
        public static void DefineEvents(
            TypeWrapperKey wrapperKey,
            TypeBuilder wrapperType,
            FieldBuilder realInstanceField,
            FieldBuilder surrogatorField,
            ISet<MethodInfo> overrided)
        {
            Assertion.Condition(wrapperKey != null);
            Assertion.Condition(wrapperType != null);
            Assertion.Condition(surrogatorField != null);
            Assertion.Condition(overrided != null);

            // 元のクラスが公開するイベントを全て列挙する
            var fromDictionary = EventList.GetListByOverrided(wrapperKey.FromType, wrapperKey.IsStatic);

            // ラップインターフェイスのイベントを全て列挙する
            foreach (var toEntry in EventList.GetImplementedListByOverrided(wrapperKey.ToType))
            {
                // 名前と引数型群を指定してイベントを取得する
                var fromEvent = TypeWrapperHelper.FindEvent(
                    wrapperKey.FromType,
                    toEntry.Key.Name,
                    toEntry.Key.Type,
                    wrapperKey.IsStatic);

                // イベントを生成する
                var eventBuilder = wrapperType.DefineEvent(
                    toEntry.Key.Name,
                    EventAttributes.None,
                    toEntry.Key.Type);

                // クラスイベントのadder/removerを取得する
                var fromAdder = fromEvent.GetAddMethod();
                Assertion.Condition(fromAdder != null);
                var fromRemover = fromEvent.GetRemoveMethod();
                Assertion.Condition(fromRemover != null);

                // ラップインターフェイスのイベント群を全て列挙し、同一のクラスイベントにバイパスする
                MethodBuilder wrapperAdder = null;
                MethodBuilder wrapperRemover = null;
                foreach (var toEvent in toEntry.Value)
                {
                    // adderの実装
                    {
                        // ラップインターフェイスのadderを取得する
                        var toAdder = toEvent.GetAddMethod();
                        Assertion.Condition(toAdder != null);
                        Assertion.Condition(toAdder.ReturnType == typeof(void));
                        Assertion.Condition(toAdder.GetParameters().Length == 1);

                        // ラッパーのadderがまだ定義されていない
                        if (wrapperAdder == null)
                        {
                            // adderメソッドを生成する
                            wrapperAdder = TypeWrapperHelper.DefineWrapperMethod(
                                wrapperType,
                                toAdder,
                                fromAdder,
                                realInstanceField,
                                surrogatorField);

                            // クラスイベントに実装
                            eventBuilder.SetAddOnMethod(wrapperAdder);
                        }

                        // ラッパークラスのadderをインターフェイスに実装
                        wrapperType.DefineMethodOverride(wrapperAdder, toAdder);

                        // このメソッドを実装済み
                        overrided.Add(toAdder);
                    }

                    // removerの実装
                    {
                        // ラップインターフェイスのremoverを取得する
                        var toRemover = toEvent.GetRemoveMethod();
                        Assertion.Condition(toRemover != null);
                        Assertion.Condition(toRemover.ReturnType == typeof(void));
                        Assertion.Condition(toRemover.GetParameters().Length == 1);

                        // ラッパーのremoverがまだ定義されていない
                        if (wrapperRemover == null)
                        {
                            // removerメソッドを生成する
                            wrapperRemover = TypeWrapperHelper.DefineWrapperMethod(
                                wrapperType,
                                toRemover,
                                fromRemover,
                                realInstanceField,
                                surrogatorField);

                            // クラスイベントに実装
                            eventBuilder.SetRemoveOnMethod(wrapperRemover);
                        }

                        // ラッパークラスのsetterをインターフェイスに実装
                        wrapperType.DefineMethodOverride(wrapperRemover, toRemover);

                        // このメソッドを実装済み
                        overrided.Add(toRemover);
                    }
                }
            }
        }

        /// <summary>
        /// ラッパークラスにメソッドを定義します。
        /// </summary>
        /// <param name="wrapperKey">型の組み合わせを示すキー</param>
        /// <param name="wrapperType">メソッドを定義する動的に生成したクラス</param>
        /// <param name="realInstanceField">元のクラスのインスタンスを格納するフィールド</param>
        /// <param name="surrogatorField">サロゲータのインスタンスを保持するフィールド</param>
        /// <param name="overrided">オーバーライド済みのメソッドを格納する辞書</param>
        /// <remarks>元のクラスに定義されている、パブリックかつオーバーライドの最上位に位置するメソッド群に
        /// 対応したラッパークラスのメソッドを生成し、全てのラップインターフェイスのメソッドを関連付け、
        /// バイパスするコードを生成します。</remarks>
        public static void DefineMethods(
            TypeWrapperKey wrapperKey,
            TypeBuilder wrapperType,
            FieldBuilder realInstanceField,
            FieldBuilder surrogatorField,
            ISet<MethodInfo> overrided)
        {
            Assertion.Condition(wrapperKey != null);
            Assertion.Condition(wrapperType != null);
            Assertion.Condition(surrogatorField != null);
            Assertion.Condition(overrided != null);

            // 元のクラスが公開するメソッドを全て列挙する
            var fromDictionary = MethodList.GetListByOverrided(wrapperKey.FromType, wrapperKey.IsStatic);

            // ラップインターフェイスのメソッドを全て列挙する
            foreach (var toEntry in MethodList.GetImplementedListByOverrided(wrapperKey.ToType))
            {
                // ラップインターフェイスのメソッド群を全て列挙し、同一のクラスメソッドにバイパスする
                MethodInfo fromMethod = null;
                MethodBuilder wrapperMethod = null;
                foreach (var toMethod in toEntry.Value)
                {
                    // 既に処理済みのメソッドは無視する
                    if (overrided.Contains(toMethod) == true)
                    {
                        continue;
                    }

                    // まだラップ対象のメソッドを検索していなければ
                    if (fromMethod == null)
                    {
                        // 名前と引数型群を指定してメソッドを取得する
                        fromMethod = TypeWrapperHelper.FindMethod(
                            wrapperKey.FromType,
                            toEntry.Key.Name,
                            toEntry.Key.Type,
                            toEntry.Key.AdditionalTypes,
                            wrapperKey.IsStatic);

                        // メソッドを生成する
                        Assertion.Condition(wrapperMethod == null);
                        wrapperMethod = TypeWrapperHelper.DefineWrapperMethod(
                            wrapperType,
                            toMethod,
                            fromMethod,
                            realInstanceField,
                            surrogatorField);
                    }

                    Assertion.Condition(fromMethod != null);
                    Assertion.Condition(wrapperMethod != null);

                    // メソッドをインターフェイスに実装する
                    wrapperType.DefineMethodOverride(wrapperMethod, toMethod);

                    // このメソッドを実装済み
                    overrided.Add(toMethod);
                }
            }
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Concurrent;
using System.ComponentModel;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices.Internal;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// 変換が安全なタイプコンバータのファクトリクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。
    /// プリミティブ型・Nullable型に内包されたプリミティブ型・null値の変換等が安全に操作できる
    /// タイプコンバータを返却します。</remarks>
    internal static class SafeTypeConverterFactory
    {
        /// <summary>
        /// 取得済みのタイプコンバータを保持する辞書です。
        /// </summary>
        private static readonly ConcurrentDictionary<Type, TypeConverter> TYPE_CONVERTERS =
            new ConcurrentDictionary<Type, TypeConverter>();

        /// <summary>
        /// タイプイニシャライザです。
        /// </summary>
        static SafeTypeConverterFactory()
        {
            TYPE_CONVERTERS.TryAdd(typeof(string), new StringExplicitTypeConverter());
            TYPE_CONVERTERS.TryAdd(typeof(bool), new BooleanSafeConverter());
            TYPE_CONVERTERS.TryAdd(typeof(DateTime), new DateTimeSafeConverter());
        }

        /// <summary>
        /// 指定された型に対応するタイプコンバータを取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <returns>タイプコンバータ</returns>
        public static TypeConverter GetConverter(Type type)
        {
            Assertion.Condition(type != null);

            var typeConverter = TYPE_CONVERTERS.GetOrAdd(
                type,
                t =>
                {
                    // 型がNullableでかつ内包型がプリミティブであれば
                    var underlyingType = Nullable.GetUnderlyingType(type);
                    if ((underlyingType != null) && (underlyingType.IsPrimitive == true))
                    {
                        // NullablePrimitiveTypeSafeConverter<T>を使用する
                        var genericType = typeof(NullablePrimitiveTypeSafeConverter<>).MakeGenericType(underlyingType);
                        return (TypeConverter)Activator.CreateInstance(genericType, GetConverter(underlyingType));
                    }
                    else
                    {
                        // それ以外
                        // 普通にタイプコンバータを取得
                        var tc = TypeDescriptor.GetConverter(type);

                        // 型がプリミティブ型の場合は、PrimitiveTypeSafeConverterでラップする
                        if (type.IsPrimitive == true)
                        {
                            tc = new PrimitiveTypeSafeConverter(type, tc);
                        }
                        else
                        {
                            // それ以外の場合は、ImplicitTypeConverterでラップする
                            tc = new ImplicitTypeConverter(type, tc);
                        }

                        return tc;
                    }
                });

            return typeConverter;
        }
    }
}

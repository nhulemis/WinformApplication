﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.ComponentModel;
using System.Globalization;
using System.Reflection;
using System.Runtime.Serialization;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// 型に対応するデフォルト値との比較を抽象化するクラスです。
    /// </summary>
    /// <remarks>指定された型について、デフォルト値となる値を取得したり、
    /// デフォルト値と比較するためのEqualsメソッドを提供します。
    /// また、デフォルト値としてDBNullとの比較も行います。
    /// デフォルト値はValueプロパティで参照出来ますが、この値を使用して比較せず、必ずEqualsメソッドを使用して下さい。</remarks>
    internal sealed class DefaultValue
    {
        /// <summary>
        /// デフォルト値
        /// </summary>
        private readonly object _defaultValue;

        /// <summary>
        /// デフォルト値をnullとするかどうか
        /// </summary>
        private readonly bool _defaultValueIsNull;

        /// <summary>
        /// null値をDBNullとするかどうか
        /// </summary>
        private readonly bool _nullIsDBNull;

        /// <summary>
        /// 空文字列をnullと同一視するかどうか
        /// </summary>
        private readonly bool _stringEmptyIsNull;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="type">対応する型</param>
        /// <param name="nullIsDBNull">null値をDBNullとするかどうか</param>
        /// <param name="stringEmptyIsNull">空文字列をnullと同一視するかどうか</param>
        public DefaultValue(Type type, bool nullIsDBNull, bool stringEmptyIsNull)
        {
            Assertion.Condition(type != null);

            this._defaultValue = GetDefaultValue(type, nullIsDBNull);

            this._defaultValueIsNull = IsNull(this._defaultValue, true);
            this._nullIsDBNull = nullIsDBNull;
            this._stringEmptyIsNull = stringEmptyIsNull;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="pi">プロパティ</param>
        /// <param name="nullIsDBNull">null値をDBNullとするかどうか</param>
        /// <param name="stringEmptyIsNull">空文字列をnullと同一視するかどうか</param>
        public DefaultValue(PropertyInfo pi, bool nullIsDBNull, bool stringEmptyIsNull)
        {
            Assertion.Condition(pi != null);

            // DefaultValueAttributeが適用されていれば
            var attributes =
                (DefaultValueAttribute[])pi.GetCustomAttributes(
                typeof(DefaultValueAttribute),
                false);
            if (attributes.Length >= 1)
            {
                Assertion.Condition(attributes.Length == 1);

                // 指定された値をデフォルト値とする
                this._defaultValue = attributes[0].Value;
            }
            else
            {
                // 型からデフォルト値を取得する
                this._defaultValue = GetDefaultValue(pi.PropertyType, nullIsDBNull);
            }

            this._defaultValueIsNull = IsNull(this._defaultValue, true);
            this._nullIsDBNull = nullIsDBNull;
            this._stringEmptyIsNull = stringEmptyIsNull;
        }

        /// <summary>
        /// デフォルト値に対応するインスタンスを取得します。
        /// </summary>
        /// <remarks>このプロパティはデフォルト値を参照するために使用します。
        /// デフォルト値との比較が必要な場合はこの値を使用して比較せず、必ずEqualsメソッドを使用して下さい。</remarks>
        public object Value
        {
            get
            {
                return this._defaultValue;
            }
        }

        /// <summary>
        /// 値がnullと等価かどうかを確認します。
        /// </summary>
        /// <param name="value">値</param>
        /// <param name="nullIsDBNull">null値をDBNullとするかどうか</param>
        /// <returns>null又はDBNullならtrue</returns>
        internal static bool IsNull(object value, bool nullIsDBNull)
        {
            if (value == null)
            {
                return true;
            }

            if (nullIsDBNull == true)
            {
                return DBNull.Value.Equals(value);
            }

            return false;
        }

        /// <summary>
        /// 指定された型に対応するデフォルト値を取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <param name="nullIsDBNull">null値をDBNullとするかどうか</param>
        /// <returns>デフォルト値</returns>
        internal static object GetDefaultValue(Type type, bool nullIsDBNull)
        {
            Assertion.Condition(type != null);

            // 型が参照型なら
            if ((type.IsClass == true) || (type.IsInterface == true))
            {
                // nullがデフォルト値
                return nullIsDBNull ? DBNull.Value : null;
            }
            else if (type.IsPrimitive == true)
            {
                // 型がプリミティブ型なら
                // 指定された型に対応する0を返す
                return Convert.ChangeType(0, type, CultureInfo.InvariantCulture);
            }

            // 型がNullable<T>なら
            if (Nullable.GetUnderlyingType(type) != null)
            {
                // nullがデフォルト値
                return nullIsDBNull ? DBNull.Value : null;
            }

            // それ以外
            Assertion.Argument(
                type.IsValueType == true,
                "対応出来ない型です: Type={0}",
                type.FullName);

            // 構造体と仮定してインスタンスを取得
            return FormatterServices.GetUninitializedObject(type);
        }

        /// <summary>
        /// 指定されたインスタンスをデフォルト値と比較します。
        /// </summary>
        /// <param name="obj">対象のインスタンス</param>
        /// <returns>一致すればtrue</returns>
        public override bool Equals(object obj)
        {
            // デフォルト値がnullなら（DBNull含む）
            if (this._defaultValueIsNull == true)
            {
                // 文字列のハンドリング
                var stringValue = obj as string;
                if (stringValue != null)
                {
                    // 空文字なら
                    if ((this._stringEmptyIsNull == true) && (stringValue.Length == 0))
                    {
                        return true;
                    }
                }

                // 両方ともnull
                var valueIsNull = IsNull(obj, this._nullIsDBNull);
                if (valueIsNull == true)
                {
                    return true;
                }
            }
            else
            {
                // デフォルト値がnullではない
                // 両方ともnullではない
                var valueIsNull = IsNull(obj, this._nullIsDBNull);
                if (valueIsNull == false)
                {
                    // 比較する
                    return this._defaultValue.Equals(obj);
                }
            }

            // 片方がnull
            return false;
        }

        /// <summary>
        /// デフォルト値のハッシュコードを取得します。
        /// </summary>
        /// <returns>ハッシュコード</returns>
        public override int GetHashCode()
        {
            // 未検証
            return (this._defaultValue != null) ? this._defaultValue.GetHashCode() : 0;
        }

        /// <summary>
        /// インスタンスの文字列表現を取得します。
        /// </summary>
        /// <returns>文字列</returns>
        public override string ToString()
        {
            // 未検証
            return string.Format("DefaultValue=\"{0}\"", TypeUtility.SafeToString(this._defaultValue));
        }
    }
}

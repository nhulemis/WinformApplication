﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.15 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices.Internal;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// メソッドのメタデータを操作するユーティリティクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal static class MethodList
    {
        /// <summary>
        /// メソッド情報のオペレータです。
        /// </summary>
        private static readonly IMemberInfoOperator<MethodInfo> METHOD_INFO_OPERATOR = new MethodInfoOperator();

        /// <summary>
        /// メソッド情報のオペレータを取得します。
        /// </summary>
        public static IMemberInfoOperator<MethodInfo> Operator
        {
            get
            {
                return METHOD_INFO_OPERATOR;
            }
        }

        /// <summary>
        /// 指定されたクラスが継承する全てのクラスとインターフェイスに定義されているメソッドをオーバーライド毎に収集します。
        /// </summary>
        /// <param name="type">対象の型</param>
        /// <param name="isStatic">スタティックメンバを収集する場合はtrue</param>
        /// <returns>収集したメソッド情報を格納するコレクション</returns>
        /// <remarks>メソッドはオーバーライドされている可能性があるため、
        /// オーバーライド毎にグループを形成して収集します。
        /// 各オーバーライドの識別には、OverridedMemberKeyクラスを使用します。</remarks>
        public static IDictionary<OverridedMemberKey, IList<MethodInfo>>
            GetListByOverrided(Type type, bool isStatic)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(type.IsClass == true);

            var members = new DictionaryWrapper<OverridedMemberKey, IList<MethodInfo>>();

            MemberList.GetListByOverrided(members, type, isStatic, METHOD_INFO_OPERATOR);

            return members.RealDictionary;
        }

        /// <summary>
        /// 指定された型が実装する全てのインターフェイスに定義されているメソッドをオーバーライド毎に収集します。
        /// </summary>
        /// <param name="type">対象の型</param>
        /// <returns>収集したメソッド情報を格納するコレクション</returns>
        /// <remarks>メソッドはオーバーライドされている可能性があるため、
        /// オーバーライド毎にグループを形成して収集します。
        /// 各オーバーライドの識別には、OverridedMemberKeyクラスを使用します。</remarks>
        public static IDictionary<OverridedMemberKey, IList<MethodInfo>>
            GetImplementedListByOverrided(Type type)
        {
            Assertion.Condition(type != null);

            // 実装しているインターフェイスを列挙する
            var interfaceTypes = TypeUtility.GetImplementedInterfaceList(type);

            var members = new DictionaryWrapper<OverridedMemberKey, IList<MethodInfo>>();

            MemberList.GetImplementedListByOverrided(members, interfaceTypes, METHOD_INFO_OPERATOR);

            return members.RealDictionary;
        }

        /// <summary>
        /// 指定されたインターフェイス群に定義されているメソッドをオーバーライド毎に収集します。
        /// </summary>
        /// <param name="interfaceTypes">対象のインターフェイス型群</param>
        /// <returns>収集したメソッド情報を格納するコレクション</returns>
        /// <remarks>このオーバーロードでは、指定されたインターフェイスのリストの順にメンバが列挙され、
        /// 順序性を維持した状態で返します。
        /// メソッドはオーバーライドされている可能性があるため、
        /// オーバーライド毎にグループを形成して収集します。
        /// 各オーバーライドの識別には、OverridedMemberKeyクラスを使用します。</remarks>
        public static IEnumerable<KeyValuePair<OverridedMemberKey, IList<MethodInfo>>>
            GetOrderedImplementedListByOverrided(IEnumerable<Type> interfaceTypes)
        {
            Assertion.Condition(interfaceTypes != null);

            var members = new ListWrapper<OverridedMemberKey, IList<MethodInfo>>();

            MemberList.GetImplementedListByOverrided(members, interfaceTypes, METHOD_INFO_OPERATOR);

            return members.RealList;
        }
    }
}

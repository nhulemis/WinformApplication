﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.Diagnostics;

namespace CREO.Fluere.Common.TypeServices
{
    /// <summary>
    /// TypeWrapperでインスタンスを生成するファクトリの基底クラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    [DebuggerNonUserCode]
    public abstract class TypeWrapperFactoryBase
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        protected TypeWrapperFactoryBase()
        {
        }

        /// <summary>
        /// 辞書をクリーンアップします。
        /// </summary>
        /// <returns>削除されたエントリの比</returns>
        /// <remarks>不要なWeakReferenceを辞書から削除します。</remarks>
        public abstract double Cleanup();

        /// <summary>
        /// 指定されたインスタンスのラッパーインスタンスを生成します。
        /// </summary>
        /// <param name="instance">インスタンス</param>
        /// <param name="surrogator">サロゲータ</param>
        /// <returns>ラッパーインスタンス</returns>
        protected internal abstract object CreateWrapper(object instance, ITypeWrapperSurrogator surrogator);

        /// <summary>
        /// 指定されたインスタンスのラッパーインスタンスを取得します。
        /// </summary>
        /// <param name="instance">インスタンス</param>
        /// <param name="surrogator">サロゲータ</param>
        /// <returns>ラッパーインスタンス</returns>
        public abstract object GetWrapper(object instance, ITypeWrapperSurrogator surrogator);
    }
}

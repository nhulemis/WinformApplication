﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.Serialization.Internal;
using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// インスタンスのプロパティと値の交換を行うクラスです。
    /// </summary>
    /// <typeparam name="T">プロパティにアクセスする対象のインターフェイス型</typeparam>
    /// <remarks>このクラスは内部で使用します。
    /// T型に定義されたプロパティの情報を事前収集し、かつ適用されている属性クラスに基づいて値の交換を行います。</remarks>
    internal sealed class PropertyValueAccessor<T> : IPropertyValueAccessor
        where T : class
    {
        #region Fields
        /// <summary>
        /// InterfaceAccessor
        /// </summary>
        private readonly InterfaceAccessor _accessor;

        /// <summary>
        /// 生のプロパティ名
        /// </summary>
        private readonly string[] _rawPropertyNames;

        /// <summary>
        /// プロパティ名
        /// </summary>
        private readonly string[] _propertyNames;

        /// <summary>
        /// プロパティの型
        /// </summary>
        private readonly Type[] _propertyTypes;

        /// <summary>
        /// デフォルト値
        /// </summary>
        private readonly DefaultValue[] _defaultValues;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="allowNestedInterfaces">ネストしたインターフェイスを使用するかどうか</param>
        /// <remarks>事前にT型のプロパティ情報を抽出します。</remarks>
        public PropertyValueAccessor(bool allowNestedInterfaces)
        {
            Assertion.Argument(
                typeof(T).IsInterface == true,
                "型 {0} はインターフェイスではありません",
                typeof(T).FullName);

            this._accessor = InterfaceAccessor.GetAccessor(typeof(T), allowNestedInterfaces);

            var pis = this._accessor.PropertyInfos;

            this._rawPropertyNames =
                pis.Select(pi => pi.Name).ToArray();

            this._propertyNames =
                pis.Select(pi =>
                    {
                        // NodeNameAttributeが適用されている場合はその名前を使用する
                        var nodeNameAttribute =
                            (NodeNameAttributeBase)pi.GetCustomAttributes(typeof(NodeNameAttributeBase), true).FirstOrDefault();
                        return (nodeNameAttribute != null) ? nodeNameAttribute.NodeName : pi.Name;
                    }).ToArray();

            this._propertyTypes =
                pis.Select(pi => pi.PropertyType).ToArray();

            this._defaultValues =
                pis.Select(pi => new DefaultValue(pi, false, false)).ToArray();
        }
        #endregion

        /// <summary>
        /// プロパティ数を取得します。
        /// </summary>
        public int Count
        {
            get
            {
                return this._propertyNames.Length;
            }
        }

        /// <summary>
        /// プロパティ名群を取得します。
        /// </summary>
        public string[] PropertyNames
        {
            get
            {
                return this._propertyNames;
            }
        }

        /// <summary>
        /// 生のプロパティ名群を取得します。
        /// </summary>
        public string[] RawPropertyNames
        {
            get
            {
                return this._rawPropertyNames;
            }
        }

        /// <summary>
        /// プロパティ型群を取得します。
        /// </summary>
        public Type[] PropertyTypes
        {
            get
            {
                return this._propertyTypes;
            }
        }

        /// <summary>
        /// 指定された型の属性が定義されているかどうかを取得します。
        /// </summary>
        /// <typeparam name="U">属性クラスの型</typeparam>
        /// <param name="index">インデックス</param>
        /// <returns>定義されていればtrue</returns>
        public bool IsDefined<U>(int index) where U : Attribute
        {
            return this._accessor.PropertyInfos[index].IsDefined(typeof(U), true);
        }

        /// <summary>
        /// 指定された型の属性を取得します。
        /// </summary>
        /// <typeparam name="U">属性クラスの型</typeparam>
        /// <param name="index">インデックス</param>
        /// <returns>定義されている属性クラス群</returns>
        public U[] GetCustomAttributes<U>(int index) where U : Attribute
        {
            return (U[])this._accessor.PropertyInfos[index].GetCustomAttributes(typeof(U), true);
        }

        /// <summary>
        /// 指定された位置のデフォルト値を取得します。
        /// </summary>
        /// <param name="index">インデックス</param>
        /// <returns>デフォルト値</returns>
        public DefaultValue GetDefaultValue(int index)
        {
            return this._defaultValues[index];
        }

        /// <summary>
        /// 指定された値を、指定されたインスタンスのプロパティに設定します。
        /// </summary>
        /// <param name="instance">インスタンス</param>
        /// <param name="fieldIndex">インデックス</param>
        /// <param name="value">値</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <param name="address">データの位置を示す任意の値</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="converters">事前定義されたコンバータの辞書</param>
        /// <param name="onInvalidDataValue">エラーが発生した場合に呼び出されるデリゲート</param>
        /// <returns>値を設定した場合はtrue、無視された場合はfalse</returns>
        /// <remarks>フィールド名群は参考値で、SetValueの処理では使用していません。エラーハンドラに情報として引き渡されます。</remarks>
        public bool SetValue(
            object instance,
            int fieldIndex,
            object value,
            string[] fieldNames,
            object address,
            CultureInfo cultureInfo,
            IDictionary<Type, ICustomConvert> converters,
            Action<InvalidDataValueEventArgs> onInvalidDataValue)
        {
            Assertion.Condition(instance != null);
            Assertion.Condition(fieldNames != null);
            Assertion.Condition(cultureInfo != null);
            Assertion.Condition(converters != null);
            Assertion.Condition(onInvalidDataValue != null);

            var context = new FetchContext(
                new[] { value },
                false,
                address,
                cultureInfo,
                converters,
                onInvalidDataValue);

            return this._accessor.Deserialize(context, instance, fieldIndex, fieldNames) != AccessorDeserializeResults.IgnoreInstance;
        }

        /// <summary>
        /// 配列に格納された値群を、指定されたインスタンスのプロパティに設定します。
        /// </summary>
        /// <param name="instance">インスタンス</param>
        /// <param name="values">値群</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <param name="address">データの位置を示す任意の値</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="converters">事前定義されたコンバータの辞書</param>
        /// <param name="onInvalidDataValue">エラーが発生した場合に呼び出されるデリゲート</param>
        /// <returns>値を全て設定した場合はtrue、無視された場合はfalse</returns>
        /// <remarks>再帰探索を行う場合、複数の可変フィールドが含まれていると例外が発生します。
        /// フィールド名群は参考値で、SetValuesの処理では使用していません。エラーハンドラに情報として引き渡されます。</remarks>
        public bool SetValues(
            object instance,
            object[] values,
            string[] fieldNames,
            object address,
            CultureInfo cultureInfo,
            IDictionary<Type, ICustomConvert> converters,
            Action<InvalidDataValueEventArgs> onInvalidDataValue)
        {
            Assertion.Condition(instance is T);
            Assertion.Condition(values != null);
            Assertion.Condition(fieldNames != null);
            Assertion.Condition(cultureInfo != null);
            Assertion.Condition(converters != null);
            Assertion.Condition(onInvalidDataValue != null);

            var context = new FetchContext(
                values,
                true,
                address,
                cultureInfo,
                converters,
                onInvalidDataValue);

            return this._accessor.Deserialize(context, instance, fieldNames) != AccessorDeserializeResults.IgnoreInstance;
        }

        /// <summary>
        /// 指定されたインスタンスのプロパティから値を取得します。
        /// </summary>
        /// <param name="instance">インスタンス</param>
        /// <param name="index">インデックス</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="converters">事前定義されたコンバータの辞書</param>
        /// <param name="value">取得した値</param>
        /// <returns>値を取得した場合はtrue、値を無視する必要がある場合はfalse</returns>
        /// <remarks>プロパティにNodeRequiredAttributeが適用されていない場合は、値を無視する必要がある場合があります。</remarks>
        public bool GetValue(
            object instance,
            int index,
            CultureInfo cultureInfo,
            IDictionary<Type, ICustomConvert> converters,
            out object value)
        {
            Assertion.Condition(instance != null);
            Assertion.Condition(cultureInfo != null);
            Assertion.Condition(converters != null);

            var fixedValues = new object[1];
            var context = new StoreContext(
                fixedValues,
                false,
                false,
                cultureInfo,
                converters);

            var result = this._accessor.Serialize(context, instance, index);

            var resultValues = context.GetResultValues();
            Assertion.Condition(resultValues.Count == 1);
            value = resultValues[0];

            return result;
        }

        /// <summary>
        /// 指定されたインスタンスのプロパティから値を取得し、配列に代入します。
        /// </summary>
        /// <param name="fixedValues">格納する配列</param>
        /// <param name="instance">インスタンス</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="converters">事前定義されたコンバータの辞書</param>
        /// <returns>格納した配列</returns>
        /// <remarks>引数で指定する配列は、使用されない場合があります。
        /// 結果は必ず戻り値を使用して下さい。</remarks>
        public IList<object> GetValues(
            object[] fixedValues,
            object instance,
            CultureInfo cultureInfo,
            IDictionary<Type, ICustomConvert> converters)
        {
            Assertion.Condition(fixedValues != null);
            Assertion.Condition(instance is T);
            Assertion.Condition(cultureInfo != null);
            Assertion.Condition(converters != null);

            var context = new StoreContext(
                fixedValues,
                true,
                true,
                cultureInfo,
                converters);

            this._accessor.Serialize(context, instance);

            return context.GetResultValues();
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// XML形式の設定データをインターフェイスとの間でシリアル化するクラスです。
    /// </summary>
    /// <remarks>宣言式のインターフェイス構文を使用して、XMLデータの入出力を実行します。
    /// データ対象はネストを含むインターフェイスで定義され、
    /// タイプコンバータを使用した変換とIListを使用したコレクションへの変換を行います。
    /// また、属性クラス群を使用して、エレメント名とXML属性の適用方法を調整する事が出来ます。</remarks>
    public sealed class ConfigurationSerializer : IConfigurationSerializer
    {
        /// <summary>
        /// コレクションの要素群に適用するエレメント名が未定義である事を示す配列です。
        /// </summary>
        /// <remarks>ItemElementNamesAttributeクラスで指定されていない要素は、エレメント名が未定義である事を空の配列で示します。</remarks>
        private static readonly string[] EMPTY_NAMES = new string[0];

        /// <summary>
        /// 文字列タイプコンバータです。
        /// </summary>
        private static readonly TypeConverter STRING_TYPE_CONVERTER =
            SafeTypeConverterFactory.GetConverter(typeof(string));

        /// <summary>
        /// 対象のインターフェイス型を格納するフィールドです。
        /// </summary>
        /// <remarks>この型が基点となります。</remarks>
        private readonly Type _rootInterfaceType;

        /// <summary>
        /// カスタムコンバータを保持する辞書です。
        /// </summary>
        private readonly IDictionary<Type, ICustomConvert> _converters =
            new Dictionary<Type, ICustomConvert>();

        /// <summary>
        /// カルチャ情報です。
        /// </summary>
        private CultureInfo _cultureInfo = CultureInfo.InvariantCulture;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="interfaceType">対象のインターフェイス型</param>
        public ConfigurationSerializer(Type interfaceType)
        {
            Assertion.NullArgument(interfaceType, "インターフェイス型が必要です");
            Assertion.Argument(
                interfaceType.IsInterface == true,
                "インターフェイス型が必要です: 型={0}",
                interfaceType.FullName);

            this._rootInterfaceType = interfaceType;
        }

        /// <summary>
        /// 再帰探索対象のメソッドを表現するデリゲートです。
        /// </summary>
        /// <param name="node">格納するXmlNode</param>
        /// <param name="definitionType">メタデータを参照する型</param>
        /// <param name="target">対象のインスタンス</param>
        /// <param name="itemElementNames">列挙要素のエレメント名群</param>
        /// <param name="itemElementNameIndex">この要素に使用する要素名のインデックス</param>
        /// <param name="context">コンテキスト</param>
        /// <param name="recursiveTarget">再帰ターゲット</param>
        internal delegate void InternalSerializeDelegate(
            XmlNode node,
            Type definitionType,
            object target,
            string[] itemElementNames,
            int itemElementNameIndex,
            SerializeContext context,
            InternalSerializeDelegate recursiveTarget);

        /// <summary>
        /// 再帰探索対象のメソッドを表現するデリゲートです。
        /// </summary>
        /// <param name="node">格納するXmlNode</param>
        /// <param name="definitionType">メタデータを参照する型</param>
        /// <param name="itemElementNames">列挙要素のエレメント名群</param>
        /// <param name="itemElementNameIndex">この要素に使用する要素名のインデックス</param>
        /// <param name="context">コンテキスト</param>
        /// <param name="recursiveTarget">再帰ターゲット</param>
        /// <returns>復元されたインスタンス</returns>
        internal delegate object InternalDeserializeDelegate(
            XmlNode node,
            Type definitionType,
            string[] itemElementNames,
            int itemElementNameIndex,
            SerializeContext context,
            InternalDeserializeDelegate recursiveTarget);

        /// <summary>
        /// 不正な値を検出した場合に呼び出されるイベントです。
        /// </summary>
        /// <remarks>データから値を取得する際に、型変換しようとして発生する例外を検出出来ます。
        /// このイベントの処理内で、値を修正するか、別の例外をスローして下さい。
        /// 値を修正せず、かつ例外をスローしないで処理を返した場合、提示されている例外が再スローされます。</remarks>
        public event InvalidDataValueEventHandler InvalidDataValue;

        /// <summary>
        /// このシリアライザが変換の対象とするインターフェイス型を取得します。
        /// </summary>
        public Type TargetType
        {
            get
            {
                return this._rootInterfaceType;
            }
        }

        /// <summary>
        /// シリアル化を実行する際に使用するカルチャ情報を取得・設定します。
        /// </summary>
        public CultureInfo CultureInfo
        {
            get
            {
                return _cultureInfo;
            }

            set
            {
                Assertion.NullArgument(value, "カルチャ情報が必要です");

                this._cultureInfo = value;
            }
        }

        /// <summary>
        /// ルートエレメント名を取得します。
        /// </summary>
        internal string RootElementName
        {
            get
            {
                // RootElementNameAttributeを取得する
                var attributes =
                    (RootElementNameAttribute[])this._rootInterfaceType.GetCustomAttributes(
                    typeof(RootElementNameAttribute),
                    false);

                // 定義されているかに応じて、指定値と型名を変える
                var rootElementName = (attributes.Length >= 1) ?
                    attributes[0].ElementName : _rootInterfaceType.Name;

                return rootElementName;
            }
        }

        /// <summary>
        /// 指定されたプロパティに対応する、列挙する要素に適用するエレメント名を取得します。
        /// </summary>
        /// <param name="accessor">プロパティアクセサ</param>
        /// <param name="index">プロパティのインデックス</param>
        /// <returns>列挙する要素に適用するエレメント名群</returns>
        internal static string[] GetItemElementNames(IPropertyValueAccessor accessor, int index)
        {
            Assertion.Condition(accessor != null);
            Assertion.Condition(index < accessor.Count);

            var attributes = accessor.GetCustomAttributes<ItemElementNamesAttribute>(index);
            return (attributes.Length >= 1) ? attributes[0].ElementNames : EMPTY_NAMES;
        }

        /// <summary>
        /// 指定されたノードまでのパスをダンプするファンクタを取得します。
        /// </summary>
        /// <param name="node">ノード</param>
        /// <returns>文字列</returns>
        /// <remarks>デバッグ用です。</remarks>
        internal static Func<object> DumpNode(XmlNode node)
        {
            Assertion.Condition(node != null);

            return () =>
                {
                    var sb = new StringBuilder();
                    var currentNode = node;
                    while ((currentNode is XmlDocument) == false)
                    {
                        if (sb.Length >= 1)
                        {
                            sb.Insert(0, '/');
                        }

                        sb.Insert(0, currentNode.Name);
                        if (currentNode is XmlAttribute)
                        {
                            sb.Insert(0, '@');
                            currentNode = ((XmlAttribute)currentNode).OwnerElement;
                        }
                        else
                        {
                            currentNode = currentNode.ParentNode;
                        }
                    }

                    sb.Insert(0, '/');
                    return sb.ToString();
                };
        }

        /// <summary>
        /// カスタムコンバートに必要な変換インターフェイスを登録します。
        /// </summary>
        /// <typeparam name="T">カスタムコンバートの対象となる属性クラス</typeparam>
        /// <param name="converter">変換インターフェイスのインスタンス</param>
        public void RegisterCustomConvert<T>(ICustomConvert converter)
            where T : CustomConvertAttribute
        {
            Assertion.NullArgument(converter, "変換コンバータのインスタンスが必要です");

            this._converters.Add(typeof(T), converter);
        }

        #region Serialize
        /// <summary>
        /// 指定されたエレメント内に、プロパティに関連付けられたノードを生成します。
        /// </summary>
        /// <param name="element">エレメント</param>
        /// <param name="accessor">プロパティアクセサ</param>
        /// <param name="index">プロパティのインデックス</param>
        /// <returns>生成されたノード</returns>
        internal static XmlNode CreateNode(XmlElement element, IPropertyValueAccessor accessor, int index)
        {
            Assertion.Condition(element != null);
            Assertion.Condition(accessor != null);
            Assertion.Condition(index < accessor.Count);

            // NodeDefinitionAttributeが適用されていなければ
            var attributes = accessor.GetCustomAttributes<NodeDefinitionAttribute>(index);
            if (attributes.Length == 0)
            {
                // プロパティ名をエレメント名としてエレメントを生成する
                var newElement = element.OwnerDocument.CreateElement(accessor.PropertyNames[index]);

                // エレメントに追加する
                element.AppendChild(newElement);

                return newElement;
            }

            // ノード名を取得する
            var nodeName = attributes[0].NodeName;

            // ノードタイプを確認する
            switch (attributes[0].NodeType)
            {
                // エレメント
                case NodeType.Element:
                    Assertion.Condition(string.IsNullOrWhiteSpace(nodeName) == false);

                    // 指定されたノード名でエレメントを生成する
                    var newElement = element.OwnerDocument.CreateElement(nodeName);

                    // エレメントに追加する
                    element.AppendChild(newElement);

                    return newElement;

                // XML属性
                case NodeType.Attribute:
                    Assertion.Condition(string.IsNullOrWhiteSpace(nodeName) == false);

                    // 指定されたノード名でXML属性を生成する
                    var newAttribute = element.OwnerDocument.CreateAttribute(nodeName);

                    // エレメントに追加する
                    element.SetAttributeNode(newAttribute);

                    return newAttribute;

                // テキストノード
                case NodeType.Text:
                    Assertion.Condition(nodeName == null);

                    // テキストノードを生成する
                    var newText = element.OwnerDocument.CreateTextNode(string.Empty);

                    // エレメントに追加する
                    element.AppendChild(newText);

                    return newText;
            }

            throw new ConfigurationSerializerException("不明なノードタイプ");
        }

        /// <summary>
        /// 指定されたノードに、値を設定します。
        /// </summary>
        /// <param name="node">XMLノード</param>
        /// <param name="value">値</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        internal static void SetNodeValue(XmlNode node, object value, CultureInfo cultureInfo)
        {
            Assertion.Condition(node != null);
            Assertion.Condition(value != null);
            Assertion.Condition(cultureInfo != null);

            // 文字列表現に変換する
            var stringValue = (string)STRING_TYPE_CONVERTER.ConvertFrom(null, cultureInfo, value);

            // ノードのテキストノードに設定する
            node.InnerText = stringValue;
        }

        /// <summary>
        /// エレメントをコピーします。
        /// </summary>
        /// <param name="toElement">コピー先</param>
        /// <param name="fromElement">コピー元</param>
        /// <remarks>エレメント名はコピーされません。</remarks>
        internal static void CopyElement(XmlElement toElement, XmlElement fromElement)
        {
            Assertion.Condition(toElement != null);
            Assertion.Condition(fromElement != null);

            toElement.InnerXml = fromElement.InnerXml;
            foreach (XmlAttribute attribute in fromElement.Attributes)
            {
                toElement.SetAttribute(attribute.Name, attribute.Value);
            }
        }

        /// <summary>
        /// 指定されたインスタンスを指定された型を元にシリアル化します。
        /// </summary>
        /// <param name="node">格納するXmlNode</param>
        /// <param name="definitionType">メタデータを参照する型</param>
        /// <param name="target">対象のインスタンス</param>
        /// <param name="itemElementNames">列挙要素のエレメント名群</param>
        /// <param name="itemElementNameIndex">この要素に使用する要素名のインデックス</param>
        /// <param name="context">コンテキスト</param>
        /// <param name="recursiveTarget">再帰ターゲット</param>
        internal static void InternalSerialize(
            XmlNode node,
            Type definitionType,
            object target,
            string[] itemElementNames,
            int itemElementNameIndex,
            SerializeContext context,
            InternalSerializeDelegate recursiveTarget)
        {
            Assertion.Condition(node != null);
            Assertion.Condition(target != null);
            Assertion.Condition(definitionType != null);
            Assertion.Condition(itemElementNames != null);
            Assertion.Condition(itemElementNameIndex >= 0);
            Assertion.Condition(context != null);
            Assertion.Condition(recursiveTarget != null);

            // インスタンスがプリミティブでも文字列でもない
            // （逆シリアル化と異なり、実行時型で判定する事でシリアル化の条件を緩和する）
            var type = target.GetType();
            if ((type.IsPrimitive == false) && (type != typeof(string)))
            {
                // インスタンスがIEnumerable<T>を実装していれば
                // （逆シリアル化と異なり、実行時型で判定する事でシリアル化の条件を緩和する）
                var genericArgumentTypes = TypeUtility.GetGenericArgumentsByTargetGenericDefinitionType(
                    type, typeof(IEnumerable<>));
                if (genericArgumentTypes != null)
                {
                    Assertion.Condition(genericArgumentTypes.Length == 1);
                    Assertion.Require<ConfigurationSerializerException>(
                        node is XmlElement,
                        "ノード {0} はエレメントでなければなりません",
                        DumpNode(node));

                    // 要素名を取得する（定義が不足する場合はItem固定とする）
                    var itemElementName = (itemElementNameIndex < itemElementNames.Length) ?
                        itemElementNames[itemElementNameIndex] : "Item";

                    // 要素型に対応するデフォルト値を取得する
                    var defaultValue = new DefaultValue(genericArgumentTypes[0], false, true);

                    // 列挙を実行する
                    foreach (var value in (IEnumerable)target)
                    {
                        // 要素のエレメントを生成する
                        var itemElement = node.OwnerDocument.CreateElement(itemElementName);
                        node.AppendChild(itemElement);

                        // 要素からインスタンスが得られなければ（デフォルト値と一致）
                        if (defaultValue.Equals(value) == true)
                        {
                            // 無視する（インスタンスがデフォルト値の場合は、結果として空のノードが要素として追加される）
                            continue;
                        }

                        // 再帰実行する（テスト可能性を向上させるため、デリゲートにしてある）
                        recursiveTarget(
                            itemElement,
                            genericArgumentTypes[0],
                            value,
                            itemElementNames,
                            itemElementNameIndex + 1,
                            context,
                            recursiveTarget);
                    }

                    return;
                }

                // 型がインターフェイスなら
                if (definitionType.IsInterface == true)
                {
                    Assertion.Require<ConfigurationSerializerException>(
                        node is XmlElement,
                        "ノード {0} はエレメントでなければなりません",
                        DumpNode(node));

                    // 型に定義されたプロパティを列挙する
                    var accessor = PropertyValueAccessorFactory.GetAccessor(definitionType, false);
                    for (int index = 0; index < accessor.Count; index++)
                    {
                        // プロパティからインスタンスが得られなければ（デフォルト値と一致）
                        object value;
                        if (accessor.GetValue(
                            target,
                            index,
                            context.CultureInfo,
                            context.Converters,
                            out value) == false)
                        {
                            // 無視
                            continue;
                        }

                        // プロパティに対応したノードを生成する
                        var newNode = CreateNode((XmlElement)node, accessor, index);

                        // 矯正された値がnull以外なら
                        if (value != null)
                        {
                            // 列挙する要素に適用するエレメント名を取得する
                            var newItemElementNames = GetItemElementNames(accessor, index);

                            // 再帰実行する（テスト可能性を向上させるため、デリゲートにしてある）
                            var propertyType = accessor.PropertyTypes[index];
                            recursiveTarget(
                                newNode,
                                propertyType,
                                value,
                                newItemElementNames,
                                0,
                                context,
                                recursiveTarget);
                        }
                    }

                    return;
                }

                // XmlElementにキャスト可能なら
                // （逆シリアル化と異なり、実行時型で判定する事でシリアル化の条件を緩和する）
                if (typeof(XmlElement).IsAssignableFrom(type) == true)
                {
                    Assertion.Require<ConfigurationSerializerException>(
                        node is XmlElement,
                        "ノード {0} はエレメントでなければなりません",
                        DumpNode(node));

                    // ノードにXMLを設定する
                    CopyElement((XmlElement)node, (XmlElement)target);

                    return;
                }

                // 上記以外はタイプコンバータによる変換にフォールバックする
            }

            // ノードに値を設定する
            SetNodeValue(node, target, context.CultureInfo);
        }

        /// <summary>
        /// 指定されたインスタンスをXmlDocuemntにシリアル化します。
        /// </summary>
        /// <param name="document">出力するXmlDocuemnt</param>
        /// <param name="target">対象のインスタンス</param>
        public void Serialize(XmlDocument document, object target)
        {
            Assertion.NullArgument(document, "XmlDocumentのインスタンスが必要です");
            Assertion.Argument(document.DocumentElement == null, "ルートノードが設定されています");

            // インスタンスがnullの場合は何もしない
            if (target == null)
            {
                return;
            }

            // ルートノードを生成する
            var rootElement = document.CreateElement(this.RootElementName);
            document.AppendChild(rootElement);

            // シリアル化を行う
            InternalSerialize(
                rootElement,
                this._rootInterfaceType,
                target,
                EMPTY_NAMES,
                0,
                new SerializeContext(this._converters, this._cultureInfo, OnInvalidDataValue),
                InternalSerialize);
        }

        /// <summary>
        /// 指定されたインスタンスをストリームにシリアル化します。
        /// </summary>
        /// <param name="stream">出力するストリーム</param>
        /// <param name="target">対象のインスタンス</param>
        public void Serialize(Stream stream, object target)
        {
            Assertion.NullArgument(stream, "ストリームが必要です");
            Assertion.Argument(stream.CanWrite, "ストリームに出力出来る必要があります");

            // XmlDocumentのインスタンスを生成し、プロセッシングインストラクションを設定する
            var document = new XmlDocument();
            var pi = document.CreateProcessingInstruction("xml", "version=\"1.0\"");
            document.AppendChild(pi);

            // シリアル化を行う
            this.Serialize(document, target);

            // ストリームに出力する
            document.Save(stream);
        }
        #endregion

        #region Deserialize
        /// <summary>
        /// 指定されたエレメント内の、プロパティに関連付けられたノードを取得します。
        /// </summary>
        /// <param name="element">エレメント</param>
        /// <param name="accessor">プロパティアクセサ</param>
        /// <param name="index">プロパティのインデックス</param>
        /// <param name="nodeName">ノード名</param>
        /// <param name="description">詳細文字列</param>
        /// <returns>定義されていればそのノード</returns>
        internal static XmlNode GetNode(
            XmlElement element, IPropertyValueAccessor accessor, int index, out string nodeName, out string description)
        {
            Assertion.Condition(element != null);
            Assertion.Condition(accessor != null);
            Assertion.Condition(index < accessor.Count);

            // DescriptionAttributeが適用されていれば
            var descriptionAttributes = accessor.GetCustomAttributes<DescriptionAttribute>(index);
            if (descriptionAttributes.Length >= 1)
            {
                description = descriptionAttributes[0].Description;
            }
            else
            {
                description = null;
            }

            // NodeDefinitionAttributeが適用されていなければ
            var nodeDefinitionAttributes = accessor.GetCustomAttributes<NodeDefinitionAttribute>(index);
            if (nodeDefinitionAttributes.Length == 0)
            {
                // プロパティ名でエレメントを取得する
                nodeName = accessor.PropertyNames[index];

                // 詳細文字列が得られていなければ、ノード名で代用する
                description = description ?? nodeName;

                return element[nodeName];
            }

            // ノード名を取得する
            nodeName = nodeDefinitionAttributes[0].NodeName;

            // 詳細文字列が得られていなければ、ノード名で代用する
            description = description ?? nodeName;

            // ノードタイプを確認する
            switch (nodeDefinitionAttributes[0].NodeType)
            {
                // エレメント
                case NodeType.Element:
                    Assertion.Condition(string.IsNullOrWhiteSpace(nodeName) == false);

                    // 指定されたノード名でエレメントを取得する
                    return element[nodeName];

                // XML属性
                case NodeType.Attribute:
                    Assertion.Condition(string.IsNullOrWhiteSpace(nodeName) == false);

                    // 指定されたノード名でXML属性を取得する
                    return element.GetAttributeNode(nodeName);

                // エレメント
                case NodeType.Text:
                    Assertion.Condition(nodeName == null);

                    // テキストノードを取得する
                    return element.SelectSingleNode("text()");
            }

            throw new ConfigurationSerializerException("不明なノードタイプ");
        }

        /// <summary>
        /// 指定された型をジェネリック引数に持つList&lt;T&gt;クラスのインスタンスを生成します。
        /// </summary>
        /// <param name="genericArgumentType">ジェネリック引数</param>
        /// <returns>List&lt;T&gt;クラスのインスタンス</returns>
        internal static IList CreateList(Type genericArgumentType)
        {
            Assertion.Condition(genericArgumentType != null);

            Type listType = typeof(List<>).MakeGenericType(genericArgumentType);
            return (IList)Activator.CreateInstance(listType);
        }

        /// <summary>
        /// 指定されたエレメントからインスタンスを復元します。
        /// </summary>
        /// <param name="node">入力するXmlNode</param>
        /// <param name="definitionType">メタデータを参照する型</param>
        /// <param name="itemElementNames">列挙要素のエレメント名群</param>
        /// <param name="itemElementNameIndex">この要素に使用する要素名のインデックス</param>
        /// <param name="context">コンテキスト</param>
        /// <param name="recursiveTarget">再帰ターゲット</param>
        /// <returns>インスタンス</returns>
        internal static object InternalDeserialize(
            XmlNode node,
            Type definitionType,
            string[] itemElementNames,
            int itemElementNameIndex,
            SerializeContext context,
            InternalDeserializeDelegate recursiveTarget)
        {
            Assertion.Condition(node != null);
            Assertion.Condition(definitionType != null);
            Assertion.Condition(itemElementNames != null);
            Assertion.Condition(itemElementNameIndex >= 0);
            Assertion.Condition(context != null);
            Assertion.Condition(recursiveTarget != null);

            // 指定された型がプリミティブでも文字列でもない
            if ((definitionType.IsPrimitive == false) && (definitionType != typeof(string)))
            {
                // 型がIList<T>を実装していれば
                // （シリアル化時より要件は厳しい）
                Type[] genericArgumentTypes = TypeUtility.GetGenericArgumentsByTargetGenericDefinitionType(
                    definitionType,
                    typeof(IList<>));
                if (genericArgumentTypes != null)
                {
                    Assertion.Condition(genericArgumentTypes.Length == 1);
                    Assertion.Require<ConfigurationSerializerException>(
                        node is XmlElement,
                        "ノード {0} はエレメントでなければなりません",
                        DumpNode(node));

                    // 要素名を取得する（定義が不足する場合はItem固定とする）
                    string itemElementName = (itemElementNameIndex < itemElementNames.Length) ?
                        itemElementNames[itemElementNameIndex] : "Item";

                    // テンポラリのコレクションを準備する
                    // （IList<T>を使いたいが、Tは実行時に決定するので、IListを使用する）
                    IList collection = CreateList(genericArgumentTypes[0]);

                    // 要素に対応するデフォルト値を取得する
                    DefaultValue defaultValue = new DefaultValue(genericArgumentTypes[0], false, true);

                    // タイプコンバータを得る
                    TypeConverter tc = SafeTypeConverterFactory.GetConverter(genericArgumentTypes[0]);

                    // 子エレメントの列挙を実行する
                    foreach (XmlElement itemElement in node.SelectNodes(itemElementName))
                    {
                        // 再帰実行する（テスト可能性を向上させるため、デリゲートにしてある）
                        object value = recursiveTarget(
                            itemElement,
                            genericArgumentTypes[0],
                            itemElementNames,
                            itemElementNameIndex + 1,
                            context,
                            recursiveTarget);

                        // 2次メッシュコードでかつ値が空白の場合はコレクションに追加しない
                        if (!itemElementName.ToUpper().Equals("MESHCODE") ||
                            !value.ToString().Equals(string.Empty))
                        {
                            // 変換する（カスタムコンバータを使用していない→コレクションにはカスタムコンバータを適用出来ていない）
                            value = tc.ConvertFrom(null, context.CultureInfo, value);

                            // デフォルト値と同じなら
                            if (defaultValue.Equals(value) == true)
                            {
                                // デフォルト値に正規化する（あいまいな値を統一する）
                                value = defaultValue.Value;
                            }

                            // コレクションに追加
                            collection.Add(value);
                        }
                    }

                    // 完成したコレクションを返す
                    return collection;
                }

                // 型がインターフェイスなら
                if (definitionType.IsInterface == true)
                {
                    Assertion.Require<ConfigurationSerializerException>(
                        node is XmlElement,
                        "ノード {0} はエレメントでなければなりません",
                        DumpNode(node));

                    // インターフェイスに対応するスタブを生成する
                    var target = StubInstanceFactory.CreateInstance(definitionType);

                    // ノードからプロパティを特定するのは困難（エレメント・XML属性の対応が分からない）ので、
                    // インターフェイスから列挙する。
                    // （暗黙的に、無関係のノードが定義されていても無視される）
                    var accessor = PropertyValueAccessorFactory.GetAccessor(definitionType, false);
                    for (var index = 0; index < accessor.Count; index++)
                    {
                        // プロパティに対応するデフォルト値を取得する
                        var defaultValue = accessor.GetDefaultValue(index);

                        // ノードが定義されていないなら
                        string nodeName;
                        string description;
                        var targetNode = GetNode((XmlElement)node, accessor, index, out nodeName, out description);
                        if (targetNode == null)
                        {
                            // NodeRequiredAttributeが適用されていれば
                            if (accessor.IsDefined<NodeRequiredAttribute>(index) == true)
                            {
                                // このノードは必須なのでエラー
                                throw new MissingNodeException(
                                    definitionType,
                                    accessor.PropertyNames[index],
                                    nodeName,
                                    description);
                            }

                            // デフォルト値をプロパティに設定する
                            if (accessor.SetValue(
                                target,
                                index,
                                defaultValue.Value,
                                accessor.PropertyNames,
                                node,
                                context.CultureInfo,
                                context.Converters,
                                context.OnInvalidDataValue) == false)
                            {
                                // 無視されたら抜ける
                                break;
                            }
                        }
                        else
                        {
                            // 列挙する要素に適用するエレメント名を取得する
                            var newItemElementNames = GetItemElementNames(accessor, index);

                            // 再帰実行する（テスト可能性を向上させるため、デリゲートにしてある）
                            var value = recursiveTarget(
                                targetNode,
                                accessor.PropertyTypes[index],
                                newItemElementNames,
                                0,
                                context,
                                recursiveTarget);

                            // NodeNullableAttributeが適用されており、値が空白であれば0とする
                            if (accessor.IsDefined<NodeNullableAttribute>(index) &&
                                value.ToString().Equals(string.Empty))
                            {
                                value = 0;
                            }

                            // プロパティに設定する
                            if (accessor.SetValue(
                                target,
                                index,
                                value,
                                accessor.PropertyNames,
                                node,
                                context.CultureInfo,
                                context.Converters,
                                context.OnInvalidDataValue) == false)
                            {
                                // 無視されたら抜ける
                                break;
                            }
                        }
                    }

                    // 完成したスタブインスタンスを返す
                    return target;
                }

                // 型がXmlElementにキャスト可能なら
                if (typeof(XmlElement).IsAssignableFrom(definitionType) == true)
                {
                    Assertion.Require<ConfigurationSerializerException>(
                        node is XmlElement,
                        "ノード {0} はエレメントでなければなりません",
                        DumpNode(node));

                    // このノードをそのまま返す
                    return node;
                }

                // 上記以外はノードからの文字列取得にフォールバックする
            }

            // ノードから値を得る
            return node.InnerText;
        }

        /// <summary>
        /// 指定されたXmlDocumentからインスタンスを復元します。
        /// </summary>
        /// <param name="document">入力するXmlDocument</param>
        /// <returns>インスタンス</returns>
        public object Deserialize(XmlDocument document)
        {
            Assertion.NullArgument(document, "XmlDocumentが必要です");

            // ルートエレメントが必要
            var rootElement = document.DocumentElement;
            Assertion.Require<ConfigurationSerializerException>(
                rootElement != null,
                "ルートエレメントがありません");

            // ルートエレメント名が一致する事
            Assertion.Require<ConfigurationSerializerException>(
                rootElement.Name == this.RootElementName,
                "ルートエレメント名が異なります: エレメント名={0}, XML={1}",
                this.RootElementName,
                rootElement.Name);

            // 処理する
            return InternalDeserialize(
                document.DocumentElement,
                this._rootInterfaceType,
                EMPTY_NAMES,
                0,
                new SerializeContext(this._converters, this._cultureInfo, OnInvalidDataValue),
                InternalDeserialize);
        }

        /// <summary>
        /// 指定されたストリームからインスタンスを復元します。
        /// </summary>
        /// <param name="stream">入力するストリーム</param>
        /// <returns>インスタンス</returns>
        public object Deserialize(Stream stream)
        {
            Assertion.NullArgument(stream, "ストリームが必要です");
            Assertion.Argument(stream.CanRead, "ストリームから入力出来る必要があります");

            // XmlDocumentに読み込む
            var document = new XmlDocument();
            document.Load(stream);

            // 処理する
            return this.Deserialize(document);
        }
        #endregion
        /// <summary>
        /// 列挙中に発生したエラーを伝播します。
        /// </summary>
        /// <param name="e">イベントの情報</param>
        internal void OnInvalidDataValue(InvalidDataValueEventArgs e)
        {
            Assertion.Condition(e != null);

            if (this.InvalidDataValue != null)
            {
                this.InvalidDataValue(this, e);
            }
        }
    }
}

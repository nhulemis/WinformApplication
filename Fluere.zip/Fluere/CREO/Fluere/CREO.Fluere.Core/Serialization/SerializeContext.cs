﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.20 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// シリアル化・逆シリアル化時に使用する、共通の情報を保持するコンテキストクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class SerializeContext
    {
        /// <summary>
        /// コンバータ辞書
        /// </summary>
        private readonly IDictionary<Type, ICustomConvert> _converters;

        /// <summary>
        /// カルチャ情報
        /// </summary>
        private readonly CultureInfo _cultureInfo;

        /// <summary>
        /// 変換時のエラーを検出するハンドラデリゲート
        /// </summary>
        private readonly Action<InvalidDataValueEventArgs> _onInvalidDataValue;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="converters">カスタムコンバータの辞書</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="onInvalidDataValue">変換時のエラーを検出するハンドラデリゲート</param>
        public SerializeContext(
            IDictionary<Type, ICustomConvert> converters,
            CultureInfo cultureInfo,
            Action<InvalidDataValueEventArgs> onInvalidDataValue)
        {
            Assertion.Condition(converters != null);
            Assertion.Condition(cultureInfo != null);
            Assertion.Condition(onInvalidDataValue != null);

            this._converters = converters;
            this._cultureInfo = cultureInfo;
            this._onInvalidDataValue = onInvalidDataValue;
        }

        /// <summary>
        /// カスタムコンバータ辞書です。
        /// </summary>
        public IDictionary<Type, ICustomConvert> Converters
        {
            get
            {
                return this._converters;
            }
        }

        /// <summary>
        /// カルチャ情報です。
        /// </summary>
        public CultureInfo CultureInfo
        {
            get
            {
                return this._cultureInfo;
            }
        }

        /// <summary>
        /// 変換時のエラーを検出するハンドラデリゲートです。
        /// </summary>
        public Action<InvalidDataValueEventArgs> OnInvalidDataValue
        {
            get
            {
                return this._onInvalidDataValue;
            }
        }
    }
}

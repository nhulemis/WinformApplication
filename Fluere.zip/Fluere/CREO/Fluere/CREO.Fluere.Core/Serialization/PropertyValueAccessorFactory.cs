﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.19 TMI K.Matsui

using System;
using System.Collections.Concurrent;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// インスタンスのプロパティと値の交換を行う実装を生成するファクトリクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal static class PropertyValueAccessorFactory
    {
        /// <summary>
        /// 生成済みアクセサの辞書
        /// </summary>
        private static readonly ConcurrentDictionary<Type, Tuple<IPropertyValueAccessor, IPropertyValueAccessor>> ACCESSORS =
            new ConcurrentDictionary<Type, Tuple<IPropertyValueAccessor, IPropertyValueAccessor>>();

        /// <summary>
        /// 指定されたインターフェイスに対応するプロパティのアクセサを取得します。
        /// </summary>
        /// <typeparam name="T">インターフェイス</typeparam>
        /// <param name="allowNestedInterfaces">ネストしたインターフェイスを使用するかどうか</param>
        /// <returns>アクセサ</returns>
        public static IPropertyValueAccessor GetAccessor<T>(bool allowNestedInterfaces)
            where T : class
        {
            Assertion.Condition(typeof(T).IsInterface == true);

            var accessors = ACCESSORS.GetOrAdd(
                typeof(T),
                type =>
                    Tuple.Create(
                        (IPropertyValueAccessor)new PropertyValueAccessor<T>(true),
                        (IPropertyValueAccessor)new PropertyValueAccessor<T>(false)));

            return allowNestedInterfaces ? accessors.Item1 : accessors.Item2;
        }

        /// <summary>
        /// 指定されたインターフェイスに対応するプロパティのアクセサを取得します。
        /// </summary>
        /// <param name="interfaceType">インターフェイス</param>
        /// <param name="allowNestedInterfaces">ネストしたインターフェイスを使用するかどうか</param>
        /// <returns>アクセサ</returns>
        public static IPropertyValueAccessor GetAccessor(Type interfaceType, bool allowNestedInterfaces)
        {
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);

            var accessors = ACCESSORS.GetOrAdd(
                interfaceType,
                type =>
                {
                    var realType = typeof(PropertyValueAccessor<>).MakeGenericType(interfaceType);
                    return Tuple.Create(
                        (IPropertyValueAccessor)Activator.CreateInstance(realType, new object[] { true }),
                        (IPropertyValueAccessor)Activator.CreateInstance(realType, new object[] { false }));
                });

            return allowNestedInterfaces ? accessors.Item1 : accessors.Item2;
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.01.30 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.Serialization.Internal
{
    /// <summary>
    /// インターフェイスアクセサです。
    /// </summary>
    internal sealed class InterfaceAccessor : IInstanceAccessor
    {
        #region Fields
        /// <summary>
        /// プロパティ用のダミー引数
        /// </summary>
        private static readonly object[] DUMMY_INDEX = new object[0];

        /// <summary>
        /// インターフェイスアクセサの辞書
        /// </summary>
        private static readonly Dictionary<Type, Tuple<InterfaceAccessor, InterfaceAccessor>> ACCESSORS =
            new Dictionary<Type, Tuple<InterfaceAccessor, InterfaceAccessor>>();

        /// <summary>
        /// スタブファクトリ
        /// </summary>
        private readonly IStubInstanceFactory _factory;

        /// <summary>
        /// アクセサと対になる、実際にアクセスするプロパティ情報群
        /// </summary>
        private PropertyInfo[] _rawPis;

        /// <summary>
        /// アクセサ群
        /// </summary>
        private IInstanceAccessor[] _accessors;

        /// <summary>
        /// NodeRequiredAttributeを集約した配列
        /// </summary>
        private bool[] _nodeRequired;

        /// <summary>
        /// 名目上のプロパティ情報群（ネストしたインターフェイスをサポートする場合は、ネストしたプロパティを含む）
        /// </summary>
        private PropertyInfo[] _pis;

        /// <summary>
        /// 列挙子が複数定義されているかどうか
        /// </summary>
        private bool _containsMultipleEnumerable;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="interfaceType">インターフェイス型</param>
        private InterfaceAccessor(Type interfaceType)
        {
            Assertion.Condition(interfaceType != null);
            Assertion.Condition(interfaceType.IsInterface == true);

            this._factory = StubInstanceFactory.GetInstanceFactory(interfaceType);
        }
        #endregion

        #region NodeRequired
        /// <summary>
        /// NodeRequiredAttributeの適用状態を取得します。
        /// </summary>
        private bool[] NodeRequired
        {
            get
            {
                return this._nodeRequired;
            }
        }
        #endregion

        #region FieldCount
        /// <summary>
        /// このアクセサが管理するフィールド数を取得します。
        /// </summary>
        /// <remarks>可変フィールドが含まれている場合は、不足する結果を返す可能性があります。</remarks>
        public int FieldCount
        {
            get
            {
                return this._accessors.Sum(accessor => accessor.FieldCount);
            }
        }
        #endregion

        #region HasNestedAccessors
        /// <summary>
        /// このアクセサがネストしたアクセサを保持するかどうかを取得します。
        /// </summary>
        /// <remarks>trueを返した場合でも、ネストしたアクセサが含まれない場合があります。</remarks>
        public bool HasNestedAccessors
        {
            get
            {
                return true;
            }
        }
        #endregion

        #region PropertyInfos
        /// <summary>
        /// このアクセサが保持する、名目上のプロパティ情報群を取得します。
        /// </summary>
        public PropertyInfo[] PropertyInfos
        {
            get
            {
                return this._pis;
            }
        }
        #endregion

        #region Initialize
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="allowNestedInterfaces">ネストしたインターフェイスを使用するかどうか</param>
        private void Initialize(bool allowNestedInterfaces)
        {
            var rawPis = new List<PropertyInfo>();
            var accessors = new List<IInstanceAccessor>();
            var nodeRequired = new List<bool>();
            var pis = new List<PropertyInfo>();
            var enumerables = 0;

            // IgnoreFieldAttributeが適用されたプロパティを無視する
            foreach (var list in
                from e in PropertyList.GetOrderedImplementedListByOverrided(
                    SerializationUtility.GetInterfaceListByOrdered(this._factory.TargetType))
                where e.Value[0].IsDefined(typeof(IgnoreFieldAttribute), true) == false
                select e.Value)
            {
                Assertion.Condition(list.Count >= 1);
                var pi = list[0];

                // インデクサは、見た目ではアクセス可能に見えるが、実のところは複数の引数を持ったメソッドである。
                // そのため、インデクサ引数（メソッドの引数）が確定しないと、値にアクセスできず、
                // 引数に指定すべき値は列挙不可能なので、対応出来ない。
                // indexer decl: var result = target[index];        // indexの範囲が不明
                // method decl : var result = target.Items(index);  // indexの範囲が不明
                Assertion.Argument(
                    pi.GetIndexParameters().Length == 0,
                    "インデクサ {0}.{1} はデータフィールドとして使用出来ません",
                    pi.DeclaringType.FullName,
                    pi.Name);

                // オーバーライドされたプロパティが存在する場合、リスト（entry.Value）は複数のプロパティ情報を保持する。
                // しかし、リストの先頭だけを対象とする。
                // （つまり、最も「オモテ」のプロパティにのみアクセスさせ、newslotで隠されたプロパティは対象としない）

                // このプロパティ情報を保存
                rawPis.Add(pi);

                // NodeRequiredAttributeを保存
                nodeRequired.Add(pi.IsDefined(typeof(NodeRequiredAttribute), true));

                // プリミティブ型なら
                if (StandardAccessor.IsPrimitiveType(pi.PropertyType) == true)
                {
                    // StandardAccessorを使用する
                    accessors.Add(StandardAccessor.GetAccessor(pi));

                    pis.Add(pi);
                }
                else
                {
                    // 列挙可能なら
                    var genericTypeArgument = EnumerableAccessor.GetElementType(pi.PropertyType);
                    if (genericTypeArgument != null)
                    {
                        // EnumerableAccessorを使用する
                        accessors.Add(EnumerableAccessor.GetAccessor(pi, genericTypeArgument));

                        // 列挙子数を増加
                        enumerables++;

                        pis.Add(pi);
                    }
                    else if (pi.PropertyType.IsInterface == true)
                    {
                        // インターフェイスなら
                        // InterfaceAccessorを使用する
                        var accessor = GetAccessor(pi.PropertyType, allowNestedInterfaces);
                        accessors.Add(accessor);

                        // ネストしたインターフェイスを使用するなら
                        if (allowNestedInterfaces == true)
                        {
                            // ネスト分を追加する
                            pis.AddRange(accessor.PropertyInfos);
                        }
                        else
                        {
                            pis.Add(pi);
                        }
                    }
                    else
                    {
                        // それ以外
                        // StandardAccessorを使用する
                        accessors.Add(StandardAccessor.GetAccessor(pi));

                        pis.Add(pi);
                    }
                }
            }

            Assertion.Condition(rawPis.Count == nodeRequired.Count);
            Assertion.Condition(rawPis.Count == accessors.Count);
            Assertion.Condition(rawPis.Count <= pis.Count);

            this._rawPis = rawPis.ToArray();
            this._accessors = accessors.ToArray();
            this._nodeRequired = nodeRequired.ToArray();
            this._pis = pis.ToArray();
            this._containsMultipleEnumerable = enumerables >= 2;
        }
        #endregion

        #region GetAccessor
        /// <summary>
        /// インターフェイスアクセサを取得します。
        /// </summary>
        /// <param name="interfaceType">インターフェイス型</param>
        /// <param name="allowNestedInterfaces">ネストしたインターフェイスを使用するかどうか</param>
        /// <returns>アクセサ</returns>
        public static InterfaceAccessor GetAccessor(Type interfaceType, bool allowNestedInterfaces)
        {
            Assertion.Condition(interfaceType != null);

            lock (ACCESSORS)
            {
                Tuple<InterfaceAccessor, InterfaceAccessor> accessors;
                if (ACCESSORS.TryGetValue(interfaceType, out accessors) == false)
                {
                    // TODO:同じT型がネストする構造の場合、Initializeが再帰しようとする。
                    //   あらかじめTupleを辞書に保存しているので、スタックオーバーフローは回避されるが、
                    //   Initialize処理中の情報取得（PropertyInfosのget）で、正しい配列を取得出来ない。
                    accessors = Tuple.Create(
                        new InterfaceAccessor(interfaceType),
                        new InterfaceAccessor(interfaceType));

                    ACCESSORS.Add(interfaceType, accessors);

                    accessors.Item2.Initialize(false);
                    accessors.Item1.Initialize(true);
                }

                return allowNestedInterfaces ? accessors.Item1 : accessors.Item2;
            }
        }
        #endregion

        #region Serialize
        /// <summary>
        /// 指定されたインスタンスからコンテキストにシリアル化を実行します。
        /// </summary>
        /// <param name="context">保存するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <param name="index">プロパティの位置を示すインデックス</param>
        /// <returns>要素を無視する必要がある場合はtrue</returns>
        public bool Serialize(StoreContext context, object instance, int index)
        {
            Assertion.Condition(context != null);
            Assertion.Condition(index < this._rawPis.Length);

            var pi = this._rawPis[index];
            var accessor = this._accessors[index];

            // プロパティから値を取得
            var value = (instance != null) ? pi.GetValue(instance, DUMMY_INDEX) : null;

            // カスタムコンバートを実行
            var converted = SerializationUtility.ApplySerializationConverts(
                value,
                pi,
                context.CultureInfo,
                context.Converters);

            // 再帰探索が必要か、又はネストエントリでなければ
            if ((context.RequireRecursive == true) || (accessor.HasNestedAccessors == false))
            {
                // 下層を処理
                if (accessor.Serialize(context, converted, this._nodeRequired[index]) == false)
                {
                    // この要素を無視
                    return false;
                }
            }
            else
            {
                // 直接格納する
                context.Add(converted);
            }

            return true;
        }

        /// <summary>
        /// 指定されたインスタンスからコンテキストにシリアル化を実行します。
        /// </summary>
        /// <param name="context">保存するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        public void Serialize(StoreContext context, object instance)
        {
            Assertion.Condition(context != null);

            for (var index = 0; index < this._rawPis.Length; index++)
            {
                this.Serialize(context, instance, index);
            }
        }

        /// <summary>
        /// 指定されたインスタンスからコンテキストにシリアル化を実行します。
        /// </summary>
        /// <param name="context">保存するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <param name="nodeRequired">このノードが必要かどうか</param>
        /// <returns>保存した場合はtrue</returns>
        bool IInstanceAccessor.Serialize(StoreContext context, object instance, bool nodeRequired)
        {
            Assertion.Condition(context != null);

            this.Serialize(context, instance);

            return true;
        }
        #endregion

        #region Deserialize
        /// <summary>
        /// 指定されたコンテキストからインスタンスに逆シリアル化を実行します。
        /// </summary>
        /// <param name="context">取得するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <param name="index">プロパティの位置を示すインデックス</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <returns>結果</returns>
        private AccessorDeserializeResults InternalDeserialize(
            FetchContext context,
            object instance,
            int index,
            IEnumerable<string> fieldNames)
        {
            Assertion.Condition(context != null);
            Assertion.Condition(instance != null);
            Assertion.Condition(index < this._rawPis.Length);
            Assertion.Condition(fieldNames != null);

            var accessor = this._accessors[index];

            // 残りのデータ数を更新
            context.DecrementRemainingFieldCount(accessor.FieldCount);

            var pi = this._rawPis[index];

            try
            {
                // 再帰探索が必要か、又はネストエントリでなければ
                object value = null;
                if ((context.RequireRecursive == true) || (accessor.HasNestedAccessors == false))
                {
                    // 下層から値を取得
                    var result = accessor.Deserialize(context, ref value);
                    if (result != AccessorDeserializeResults.Deserialized)
                    {
                        // これ以上取得出来ない
                        return result;
                    }
                }
                else
                {
                    // 直接取得
                    if (context.Fetch(out value) == false)
                    {
                        // これ以上取得出来ない
                        return AccessorDeserializeResults.NoMoreData;
                    }
                }

                // プロパティに設定
                pi.SetValue(instance, value, DUMMY_INDEX);
            }
            catch (Exception ex)
            {
                // 変換時に例外が発生
                // エラーハンドラの引数を生成する
                var e = new InvalidDataValueEventArgs(
                    index,
                    pi.PropertyType,
                    pi.DeclaringType,
                    fieldNames.ElementAt(index),
                    ex,
                    context.Address);

                // エラーハンドラを呼び出す
                context.OnInvalidDataValue(e);

                // 修正の状態に応じて処理を行う
                switch (e.FixState)
                {
                    // 修正された
                    case InvalidDataValueFixStates.Fixed:
                        // プロパティに設定する
                        pi.SetValue(instance, e.FixedValue, DUMMY_INDEX);
                        break;

                    // レコードの無視が指定された
                    case InvalidDataValueFixStates.Ignored:
                        // これ以上取得しない
                        return AccessorDeserializeResults.IgnoreInstance;

                    // 修正されなかった
                    default:
                        // 再スロー
                        throw;
                }
            }

            return AccessorDeserializeResults.Deserialized;
        }

        /// <summary>
        /// 指定されたコンテキストからインスタンスに逆シリアル化を実行します。
        /// </summary>
        /// <param name="context">取得するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <param name="index">プロパティの位置を示すインデックス</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <returns>結果</returns>
        public AccessorDeserializeResults Deserialize(
            FetchContext context,
            object instance,
            int index,
            IEnumerable<string> fieldNames)
        {
            Assertion.Condition(context != null);
            Assertion.Condition(instance != null);
            Assertion.Condition(index < this._rawPis.Length);
            Assertion.Condition(fieldNames != null);

            // 初期フィールド数を設定
            context.SetRemainingFieldCount(this._accessors[index].FieldCount);

            return this.InternalDeserialize(context, instance, index, fieldNames);
        }

        /// <summary>
        /// 指定されたコンテキストからインスタンスに逆シリアル化を実行します。
        /// </summary>
        /// <param name="context">取得するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <returns>結果</returns>
        public AccessorDeserializeResults Deserialize(
            FetchContext context,
            object instance,
            string[] fieldNames)
        {
            Assertion.Condition(context != null);
            Assertion.Condition(instance != null);
            Assertion.Condition(fieldNames != null);

            Assertion.Require(
                this._containsMultipleEnumerable == false,
                "複数の列挙子が定義されています: 型={0}",
                this._factory.TargetType.FullName);

            // 初期フィールド数を設定
            context.SetRemainingFieldCount(this.FieldCount);

            // プロパティを列挙
            for (var index = 0; index < this._rawPis.Length; index++)
            {
                // 下層を処理する（プロパティ名群は指定されたものを使用）
                var result = this.InternalDeserialize(context, instance, index, fieldNames);
                if (result != AccessorDeserializeResults.Deserialized)
                {
                    // これ以上取得出来ない
                    return result;
                }
            }

            return AccessorDeserializeResults.Deserialized;
        }

        /// <summary>
        /// 指定されたコンテキストからインスタンスに逆シリアル化を実行します。
        /// </summary>
        /// <param name="context">取得するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <returns>結果</returns>
        AccessorDeserializeResults IInstanceAccessor.Deserialize(FetchContext context, ref object instance)
        {
            Assertion.Require(
                this._containsMultipleEnumerable == false,
                "複数の列挙子が定義されています: 型={0}",
                this._factory.TargetType.FullName);

            // インスタンスを生成
            instance = instance ?? this._factory.CreateInstance();

            // プロパティを列挙
            for (var index = 0; index < this._rawPis.Length; index++)
            {
                // 下層を処理する（プロパティ名群はプロパティから取得）
                var result = this.InternalDeserialize(context, instance, index, this._rawPis.Select(pi => pi.Name));
                if (result != AccessorDeserializeResults.Deserialized)
                {
                    // これ以上取得出来ない
                    return result;
                }
            }

            return AccessorDeserializeResults.Deserialized;
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.01.30 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.Serialization.Internal
{
    /// <summary>
    /// 列挙子アクセサです。
    /// </summary>
    internal sealed class EnumerableAccessor : IInstanceAccessor
    {
        #region Fields
        /// <summary>
        /// このアクセサの具象インスタンス群を保持する辞書
        /// </summary>
        private static readonly ConcurrentDictionary<PropertyInfo, EnumerableAccessor> ACCESSORS =
            new ConcurrentDictionary<PropertyInfo, EnumerableAccessor>();

        /// <summary>
        /// インスタンスの再現にListクラスが必要かどうか
        /// </summary>
        private readonly bool _requireList;

        /// <summary>
        /// 列挙子の要素型
        /// </summary>
        private readonly Type _elementType;

        /// <summary>
        /// 要素へのアクセサ
        /// </summary>
        private readonly IInstanceAccessor _elementAccessor;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="declaredProperty">列挙子を定義するプロパティ</param>
        /// <param name="elementType">列挙子の要素型</param>
        private EnumerableAccessor(PropertyInfo declaredProperty, Type elementType)
        {
            Assertion.Condition(declaredProperty != null);
            Assertion.Condition(elementType != null);

            this._elementType = elementType;

            var propertyType = declaredProperty.PropertyType;
            this._requireList =
                (propertyType.IsGenericType == true) &&
                (propertyType.GetGenericTypeDefinition() == typeof(List<>));

            // プリミティブ型なら
            if (StandardAccessor.IsPrimitiveType(this._elementType) == true)
            {
                // StandardAccessorを使用する
                this._elementAccessor = StandardAccessor.GetAccessor(this._elementType);
            }
            else
            {
                // 列挙可能なら（ネストしている）
                var genericTypeArgument = GetElementType(this._elementType);
                if (genericTypeArgument != null)
                {
                    // EnumerableAccessorを使用する
                    this._elementAccessor = GetAccessor(declaredProperty, genericTypeArgument);
                }
                else if (this._elementType.IsInterface == true)
                {
                    // インターフェイスなら
                    // InterfaceAccessorを使用する
                    // （列挙子内のインスタンスは数が特定出来ないため、これ以降、ネストしたインターフェイスは使用出来ない）
                    this._elementAccessor = InterfaceAccessor.GetAccessor(this._elementType, false);
                }
                else
                {
                    // それ以外
                    // StandardAccessorを使用する
                    this._elementAccessor = StandardAccessor.GetAccessor(this._elementType);
                }
            }
        }
        #endregion

        #region FieldCount
        /// <summary>
        /// このアクセサが管理するフィールド数を取得します。
        /// </summary>
        /// <remarks>可変フィールドが含まれている場合は、不足する結果を返す可能性があります。</remarks>
        public int FieldCount
        {
            get
            {
                return 0;
            }
        }
        #endregion

        #region HasNestedAccessors
        /// <summary>
        /// このアクセサがネストしたアクセサを保持するかどうかを取得します。
        /// </summary>
        /// <remarks>trueを返した場合でも、ネストしたアクセサが含まれない場合があります。</remarks>
        public bool HasNestedAccessors
        {
            get
            {
                return true;
            }
        }
        #endregion

        #region GetElementType
        /// <summary>
        /// 指定された型が列挙型であれば、エレメント型を取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <returns>列挙型ならエレメント型</returns>
        public static Type GetElementType(Type type)
        {
            Assertion.Condition(type != null);

            // 列挙可能なら
            var genericTypeArguments =
                TypeUtility.GetGenericArgumentsByTargetGenericDefinitionType(
                type,
                typeof(IEnumerable<>));
            if ((genericTypeArguments != null) && (genericTypeArguments.Length == 1))
            {
                return genericTypeArguments[0];
            }

            return null;
        }
        #endregion

        #region GetAccessor
        /// <summary>
        /// 列挙子アクセサを取得します。
        /// </summary>
        /// <param name="declaredProperty">列挙子を定義するプロパティ</param>
        /// <param name="elementType">列挙子の要素型</param>
        /// <returns>アクセサ</returns>
        public static EnumerableAccessor GetAccessor(PropertyInfo declaredProperty, Type elementType)
        {
            Assertion.Condition(declaredProperty != null);
            Assertion.Condition(elementType != null);

            return ACCESSORS.GetOrAdd(declaredProperty, pi => new EnumerableAccessor(declaredProperty, elementType));
        }
        #endregion

        #region Serialize
        /// <summary>
        /// 指定されたインスタンスからコンテキストにシリアル化を実行します。
        /// </summary>
        /// <param name="context">保存するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <param name="nodeRequired">このノードが必要かどうか</param>
        /// <returns>保存した場合はtrue</returns>
        public bool Serialize(StoreContext context, object instance, bool nodeRequired)
        {
            Assertion.Condition(context != null);

            // 列挙子が取得出来なければ
            var enumerable = instance as IEnumerable;
            if (enumerable == null)
            {
                // ノードが必須なら
                if (nodeRequired == true)
                {
                    // 直接格納する
                    context.Add(null);
                    return true;
                }
                else
                {
                    // 何も格納しない
                    return false;
                }
            }

            // 再帰探索が必要か、又はネストエントリでなければ
            if ((context.RequireRecursive == true) || (this._elementAccessor.HasNestedAccessors == false))
            {
                foreach (var value in enumerable)
                {
                    // 下層を処理
                    if (this._elementAccessor.Serialize(context, value, nodeRequired) == false)
                    {
                        // この要素を無視
                        return false;
                    }
                }
            }
            else
            {
                foreach (var value in enumerable)
                {
                    // 直接格納する
                    context.Add(value);
                }
            }

            return true;
        }
        #endregion

        #region Deserialize
        /// <summary>
        /// 指定されたコンテキストからインスタンスに逆シリアル化を実行します。
        /// </summary>
        /// <param name="context">取得するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <returns>結果</returns>
        public AccessorDeserializeResults Deserialize(FetchContext context, ref object instance)
        {
            Assertion.Condition(context != null);

            // フィールド数が0の逆シリアル化は出来ない（フィールド数の予測が出来ないため）
            Assertion.Require(
                this._elementAccessor.FieldCount >= 1,
                "ネストした列挙子を逆シリアル化出来ません: 型={0}",
                this._elementType.FullName);

            Assertion.Condition(
                (context.CanEnumerateCountHint % this._elementAccessor.FieldCount) == 0);

            // 要素数を計算
            var elementCount = context.CanEnumerateCountHint / this._elementAccessor.FieldCount;

            // インスタンスを生成
            var list =
                (IList)(instance ??
                    (this._requireList ?
                        SerializationUtility.CreateTypedList(this._elementType, elementCount) :
                        Array.CreateInstance(this._elementType, elementCount)));

            // 再帰探索が必要か、又はネストエントリでなければ
            if ((context.RequireRecursive == true) || (this._elementAccessor.HasNestedAccessors == false))
            {
                for (var index = 0; index < elementCount; index++)
                {
                    // 下層から値を取得
                    object value = null;
                    var result = this._elementAccessor.Deserialize(context, ref value);
                    if (result != AccessorDeserializeResults.Deserialized)
                    {
                        // これ以上取得出来ない
                        instance = list;
                        return result;
                    }

                    // リストに設定
                    list[index] = value;
                }
            }
            else
            {
                for (var index = 0; index < elementCount; index++)
                {
                    // 直接取得
                    object value = null;
                    if (context.Fetch(out value) == false)
                    {
                        // これ以上取得出来ない
                        instance = list;
                        return AccessorDeserializeResults.NoMoreData;
                    }

                    // リストに設定
                    list[index] = value;
                }
            }

            instance = list;
            return AccessorDeserializeResults.Deserialized;
        }
        #endregion
    }
}

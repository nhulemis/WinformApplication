﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.01.30 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization.Internal
{
    /// <summary>
    /// シリアル化コンテキストの基底クラスです。
    /// </summary>
    internal abstract class SerializeContextBase
    {
        /// <summary>
        /// 再帰探索が必要かどうか
        /// </summary>
        private readonly bool _requireRecursive;

        /// <summary>
        /// カルチャ情報
        /// </summary>
        private readonly CultureInfo _cultureInfo;

        /// <summary>
        /// カスタムコンバータ辞書
        /// </summary>
        private readonly IDictionary<Type, ICustomConvert> _converters;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="requireRecursive">再帰探索が必要かどうか</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="converters">カスタムコンバータ辞書</param>
        protected SerializeContextBase(
            bool requireRecursive,
            CultureInfo cultureInfo,
            IDictionary<Type, ICustomConvert> converters)
        {
            Assertion.Condition(cultureInfo != null);
            Assertion.Condition(converters != null);

            this._requireRecursive = requireRecursive;
            this._cultureInfo = cultureInfo;
            this._converters = converters;
        }

        /// <summary>
        /// 再帰探索が必要かどうかを取得します。
        /// </summary>
        public bool RequireRecursive
        {
            get
            {
                return this._requireRecursive;
            }
        }

        /// <summary>
        /// カルチャ情報を取得します。
        /// </summary>
        public CultureInfo CultureInfo
        {
            get
            {
                return this._cultureInfo;
            }
        }

        /// <summary>
        /// カスタムコンバータ辞書を取得します。
        /// </summary>
        public IDictionary<Type, ICustomConvert> Converters
        {
            get
            {
                return this._converters;
            }
        }
    }
}

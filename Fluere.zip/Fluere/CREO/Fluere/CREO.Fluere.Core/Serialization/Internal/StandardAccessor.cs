﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.01.30 TMI K.Matsui

using System;
using System.Collections.Concurrent;
using System.ComponentModel;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.Serialization.Internal
{
    /// <summary>
    /// 標準のアクセサです。
    /// </summary>
    internal sealed class StandardAccessor : IInstanceAccessor
    {
        #region Fields
        /// <summary>
        /// このアクセサの具象インスタンス群を保持する辞書（プロパティ基準）
        /// </summary>
        private static readonly ConcurrentDictionary<PropertyInfo, StandardAccessor> PROPERTY_ACCESSORS =
            new ConcurrentDictionary<PropertyInfo, StandardAccessor>();

        /// <summary>
        /// このアクセサの具象インスタンス群を保持する辞書（型基準）
        /// </summary>
        private static readonly ConcurrentDictionary<Type, StandardAccessor> TYPE_ACCESSORS =
            new ConcurrentDictionary<Type, StandardAccessor>();

        /// <summary>
        /// アクセサが対象とするプロパティ
        /// </summary>
        private readonly PropertyInfo _declaredProperty;

        /// <summary>
        /// タイプコンバータ
        /// </summary>
        private readonly TypeConverter _tc;

        /// <summary>
        /// デフォルト値
        /// </summary>
        private readonly DefaultValue _defaultValue;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="declaredProperty">型を定義するプロパティ</param>
        private StandardAccessor(PropertyInfo declaredProperty)
        {
            Assertion.Condition(declaredProperty != null);

            this._declaredProperty = declaredProperty;
            this._tc = SafeTypeConverterFactory.GetConverter(declaredProperty.PropertyType);
            this._defaultValue = new DefaultValue(declaredProperty, false, false);
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="type">型</param>
        private StandardAccessor(Type type)
        {
            Assertion.Condition(type != null);

            this._tc = SafeTypeConverterFactory.GetConverter(type);
            this._defaultValue = new DefaultValue(type, false, false);
        }
        #endregion

        #region FieldCount
        /// <summary>
        /// このアクセサが管理するフィールド数を取得します。
        /// </summary>
        /// <remarks>可変フィールドが含まれている場合は、不足する結果を返す可能性があります。</remarks>
        public int FieldCount
        {
            get
            {
                return 1;
            }
        }
        #endregion

        #region HasNestedAccessors
        /// <summary>
        /// このアクセサがネストしたアクセサを保持するかどうかを取得します。
        /// </summary>
        /// <remarks>trueを返した場合でも、ネストしたアクセサが含まれない場合があります。</remarks>
        public bool HasNestedAccessors
        {
            get
            {
                return false;
            }
        }
        #endregion

        #region TraverseUnderlyingType
        /// <summary>
        /// 指定された型がNullableの場合に、内包する型を取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <returns>Nullableの場合は内包する型、プリミティブ型はその型</returns>
        private static Type TraverseUnderlyingType(Type type)
        {
            Assertion.Condition(type != null);

            var underlyingType = Nullable.GetUnderlyingType(type);
            if (underlyingType != null)
            {
                return TraverseUnderlyingType(underlyingType);
            }
            else
            {
                return type;
            }
        }
        #endregion

        #region IsPrimitiveType
        /// <summary>
        /// 指定された型がプリミティブ型としてこのクラスで処理可能かどうかを取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <returns>標準型ならtrue</returns>
        /// <remarks>結果がfalseでも、このアクセサで処理可能な場合があります。</remarks>
        public static bool IsPrimitiveType(Type type)
        {
            Assertion.Condition(type != null);

            var underlyingType = TraverseUnderlyingType(type);

            if ((underlyingType.IsPrimitive == true) ||
                (underlyingType == typeof(string)) ||
                (underlyingType == typeof(DateTime)))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion

        #region GetAccessor
        /// <summary>
        /// 標準のアクセサを取得します。
        /// </summary>
        /// <param name="declaredProperty">型を定義するプロパティ</param>
        /// <returns>アクセサ</returns>
        public static StandardAccessor GetAccessor(PropertyInfo declaredProperty)
        {
            Assertion.Condition(declaredProperty != null);

            return PROPERTY_ACCESSORS.GetOrAdd(declaredProperty, pi => new StandardAccessor(declaredProperty));
        }

        /// <summary>
        /// 標準のアクセサを取得します。
        /// </summary>
        /// <param name="type">型</param>
        /// <returns>アクセサ</returns>
        public static StandardAccessor GetAccessor(Type type)
        {
            Assertion.Condition(type != null);

            return TYPE_ACCESSORS.GetOrAdd(type, t => new StandardAccessor(type));
        }
        #endregion

        #region Serialize
        /// <summary>
        /// 指定されたインスタンスからコンテキストにシリアル化を実行します。
        /// </summary>
        /// <param name="context">保存するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <param name="nodeRequired">このノードが必要かどうか</param>
        /// <returns>保存した場合はtrue</returns>
        public bool Serialize(StoreContext context, object instance, bool nodeRequired)
        {
            Assertion.Condition(context != null);

            // 指定されたインスタンスがそのまま起点
            var value = instance;

            // デフォルト値と一致していれば
            if (this._defaultValue.Equals(value) == true)
            {
                // ノードが不要なら
                if ((context.RequireFieldValue == false) && (nodeRequired == false))
                {
                    // この要素を無視
                    context.Add(null);
                    return false;
                }

                // デフォルト値に正規化する（あいまいな値を統一する）
                value = this._defaultValue.Value;
            }
            else if (value == null)
            {
                // 値がnullなら
                // ノードが不要なら
                if ((context.RequireFieldValue == false) && (nodeRequired == false))
                {
                    // この要素を無視
                    context.Add(null);
                    return false;
                }

                // デフォルト値に正規化する（あいまいな値を統一する）
                value = this._defaultValue.Value;
            }

            // カーソルに追加
            context.Add(value);

            return true;
        }
        #endregion

        #region Deserialize
        /// <summary>
        /// 指定されたコンテキストからインスタンスに逆シリアル化を実行します。
        /// </summary>
        /// <param name="context">取得するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <returns>結果</returns>
        public AccessorDeserializeResults Deserialize(FetchContext context, ref object instance)
        {
            Assertion.Condition(context != null);

            // カーソルから値を取得
            if (context.Fetch(out instance) == false)
            {
                // 取得出来ない
                return AccessorDeserializeResults.NoMoreData;
            }

            // 定義されたプロパティが与えられていれば
            if (this._declaredProperty != null)
            {
                // プロパティの定義を使用してカスタムコンバートを実行
                instance = SerializationUtility.ApplyDeserializationConverts(
                    instance,
                    this._declaredProperty,
                    context.CultureInfo,
                    context.Converters);
            }

            // デフォルト値と同じなら
            if (this._defaultValue.Equals(instance) == true)
            {
                // デフォルト値に正規化する（あいまいな値を統一する）
                instance = this._defaultValue.Value;
            }
            else if (instance == null)
            {
                // 値がnullなら
                // デフォルト値に正規化する（あいまいな値を統一する）
                instance = this._defaultValue.Value;
            }
            else
            {
                // 値をプロパティの型に変換
                instance = this._tc.ConvertFrom(null, context.CultureInfo, instance);

                // デフォルト値と同じなら
                if (this._defaultValue.Equals(instance) == true)
                {
                    // デフォルト値に正規化する（あいまいな値を統一する）
                    instance = this._defaultValue.Value;
                }
                else if (instance == null)
                {
                    // 値がnullなら
                    // デフォルト値に正規化する（あいまいな値を統一する）
                    instance = this._defaultValue.Value;
                }
            }

            return AccessorDeserializeResults.Deserialized;
        }
        #endregion
    }
}

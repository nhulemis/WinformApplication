﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.01.30 TMI K.Matsui

namespace CREO.Fluere.Common.Serialization.Internal
{
    /// <summary>
    /// 逆シリアル化の結果を示す列挙値です。
    /// </summary>
    internal enum AccessorDeserializeResults
    {
        /// <summary>
        /// 逆シリアル化に成功しました。
        /// </summary>
        Deserialized,

        /// <summary>
        /// データが不足しています。
        /// </summary>
        /// <remarks>復元されたインスタンスは取得可能ですが、状態は中途半端です。</remarks>
        NoMoreData,

        /// <summary>
        /// データ異常のイベント処理の結果、インスタンスを無視する必要がある事を示します。
        /// </summary>
        IgnoreInstance
    }

    /// <summary>
    /// インスタンスのシリアル化をサポートするアクセサインターフェイスです。
    /// </summary>
    /// <remarks>階層化されたアクセサを実現し、プロパティのシリアル化を容易にします。</remarks>
    internal interface IInstanceAccessor
    {
        /// <summary>
        /// このアクセサが管理するフィールド数を取得します。
        /// </summary>
        /// <remarks>可変フィールドが含まれている場合は、不足する結果を返す可能性があります。</remarks>
        int FieldCount
        {
            get;
        }

        /// <summary>
        /// このアクセサがネストしたアクセサを保持する可能性があるかどうかを取得します。
        /// </summary>
        /// <remarks>trueを返した場合でも、ネストしたアクセサが含まれない場合があります。</remarks>
        bool HasNestedAccessors
        {
            get;
        }

        /// <summary>
        /// 指定されたインスタンスからコンテキストにシリアル化を実行します。
        /// </summary>
        /// <param name="context">保存するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <param name="nodeRequired">このノードが必要かどうか</param>
        /// <returns>保存した場合はtrue</returns>
        bool Serialize(StoreContext context, object instance, bool nodeRequired);

        /// <summary>
        /// 指定されたコンテキストからインスタンスに逆シリアル化を実行します。
        /// </summary>
        /// <param name="context">取得するコンテキスト</param>
        /// <param name="instance">対象のインスタンス</param>
        /// <returns>結果</returns>
        AccessorDeserializeResults Deserialize(FetchContext context, ref object instance);
    }
}

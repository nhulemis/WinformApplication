﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.01.30 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization.Internal
{
    /// <summary>
    /// 逆シリアル化のために、リストからデータを取得するためのコンテキストです。
    /// </summary>
    internal sealed class FetchContext : SerializeContextBase
    {
        #region Fields
        /// <summary>
        /// 取得データ群を格納するリスト
        /// </summary>
        private readonly IList _values;

        /// <summary>
        /// リスト位置を示す値
        /// </summary>
        private readonly object _address;

        /// <summary>
        /// データ異常を処理するイベント用デリゲート
        /// </summary>
        private readonly Action<InvalidDataValueEventArgs> _onInvalidDataValue;

        /// <summary>
        /// リスト内の現在位置
        /// </summary>
        private int _currentIndex = -1;

        /// <summary>
        /// 列挙可能なデータ数を逆算するためのフィールド数
        /// </summary>
        private int _remainingFieldCount = -1;
        #endregion

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="values">データ群</param>
        /// <param name="requireRecursive">再帰探索が必要かどうか</param>
        /// <param name="address">逆シリアル化を処理する場所を示す値</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="converters">カスタムコンバータ辞書</param>
        /// <param name="onInvalidDataValue">データ異常イベントハンドラ</param>
        public FetchContext(
            IList values,
            bool requireRecursive,
            object address,
            CultureInfo cultureInfo,
            IDictionary<Type, ICustomConvert> converters,
            Action<InvalidDataValueEventArgs> onInvalidDataValue)
            : base(requireRecursive, cultureInfo, converters)
        {
            Assertion.Condition(values != null);
            Assertion.Condition(onInvalidDataValue != null);

            this._values = values;
            this._address = address;
            this._onInvalidDataValue = onInvalidDataValue;
        }

        /// <summary>
        /// 逆シリアル化を処理する場所を示す値を取得します。
        /// </summary>
        /// <remarks>逆シリアル化時のデータ位置を示す任意の値です。</remarks>
        public object Address
        {
            get
            {
                return this._address;
            }
        }

        /// <summary>
        /// 列挙可能なデータ数を取得します。
        /// </summary>
        /// <remarks>列挙子の逆シリアル化の際に、要素数を計算する為に使用します。
        /// 現在のカーソル位置で、列挙可能なデータ数を取得します。</remarks>
        public int CanEnumerateCountHint
        {
            get
            {
                return (this._values.Count - this._currentIndex - 1) - this._remainingFieldCount;
            }
        }

        /// <summary>
        /// 残っているフィールド数を設定します。
        /// </summary>
        /// <param name="count">フィールド数</param>
        /// <remarks>CanEnumerateCountHintプロパティの計算に使用します。</remarks>
        public void SetRemainingFieldCount(int count)
        {
            this._remainingFieldCount = count;
        }

        /// <summary>
        /// 残っているフィールド数を減算します。
        /// </summary>
        /// <param name="count">減算数</param>
        /// <remarks>CanEnumerateCountHintプロパティの計算に使用します。</remarks>
        public void DecrementRemainingFieldCount(int count)
        {
            this._remainingFieldCount -= count;
        }

        /// <summary>
        /// 次のデータを取得します。
        /// </summary>
        /// <param name="value">データ</param>
        /// <returns>取得した場合はtrue</returns>
        public bool Fetch(out object value)
        {
            // これ以上取得出来ない
            if (this._currentIndex >= (this._values.Count - 1))
            {
                value = null;
                return false;
            }

            // 次の位置に進める
            this._currentIndex++;

            // データを取得する
            value = this._values[this._currentIndex];

            return true;
        }

        /// <summary>
        /// データ異常を示す情報を使用して、イベントハンドラを実行します。
        /// </summary>
        /// <param name="e">データ異常を示す情報</param>
        public void OnInvalidDataValue(InvalidDataValueEventArgs e)
        {
            this._onInvalidDataValue(e);
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.01.30 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Serialization.Internal
{
    /// <summary>
    /// シリアル化されたインスタンスをリストに格納するためのコンテキストです。
    /// </summary>
    internal sealed class StoreContext : SerializeContextBase
    {
        /// <summary>
        /// フィールド値が必要であるかどうか
        /// </summary>
        private readonly bool _requireFieldValue;

        /// <summary>
        /// データの格納先となるリスト
        /// </summary>
        private IList<object> _values;

        /// <summary>
        /// 次の格納先位置
        /// </summary>
        private int _nextIndex;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="fixedValues">初期のリストとして使用する固定長の配列</param>
        /// <param name="requireRecursive">再帰探索が必要かどうか</param>
        /// <param name="requireFieldValue">フィールド値が必要であるかどうか</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="converters">カスタムコンバータ辞書</param>
        public StoreContext(
            object[] fixedValues,
            bool requireRecursive,
            bool requireFieldValue,
            CultureInfo cultureInfo,
            IDictionary<Type, ICustomConvert> converters)
            : base(requireRecursive, cultureInfo, converters)
        {
            Assertion.Condition(fixedValues != null);

            this._values = fixedValues;
            this._requireFieldValue = requireFieldValue;
        }

        /// <summary>
        /// フィールド値が必要であるかどうかを取得します。
        /// </summary>
        /// <remarks>falseの場合、条件を満たすとフィールド値が出力されない事を示します。</remarks>
        public bool RequireFieldValue
        {
            get
            {
                return this._requireFieldValue;
            }
        }

        /// <summary>
        /// 結果を示すリストを取得します。
        /// </summary>
        /// <returns>結果を示すリスト</returns>
        /// <remarks>コンストラクタで指定されたリストは、後で別のリストに置き換わる可能性があります。
        /// 処理後はこのプロパティからリストを取得して下さい。</remarks>
        public IList<object> GetResultValues()
        {
            // 要素数が少ない場合はリストを置き換える
            if (this._nextIndex < this._values.Count)
            {
                this._values = this._values.Take(this._nextIndex).ToList();
            }

            return this._values;
        }

        /// <summary>
        /// インスタンスをリストに格納します。
        /// </summary>
        /// <param name="value">インスタンス</param>
        public void Add(object value)
        {
            // 要素数が超える場合
            if (this._nextIndex >= this._values.Count)
            {
                // 配列ならリストに変換する
                if (this._values is Array)
                {
                    this._values = this._values.ToList();
                }

                this._values.Add(value);
            }
            else
            {
                // 超えない場合
                // 現在位置に格納する
                this._values[this._nextIndex] = value;
            }

            // 次の位置に更新
            this._nextIndex++;
        }
    }
}

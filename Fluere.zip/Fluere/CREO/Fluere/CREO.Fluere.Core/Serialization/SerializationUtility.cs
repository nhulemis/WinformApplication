﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.18 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.Serialization
{
    /// <summary>
    /// シリアル化で使用するユーティリティクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal static class SerializationUtility
    {
        #region Fields
        /// <summary>
        /// 辞書化されたインターフェイスのリスト
        /// </summary>
        private static readonly ConcurrentDictionary<Type, IEnumerable<Type>> INTERFACE_LIST =
            new ConcurrentDictionary<Type, IEnumerable<Type>>();

        /// <summary>
        /// 辞書化されたコンバータ属性群
        /// </summary>
        private static readonly ConcurrentDictionary<PropertyInfo, CustomConvertAttribute[]> CONVERTERS =
            new ConcurrentDictionary<PropertyInfo, CustomConvertAttribute[]>();
        #endregion

        #region CreateTypedList
        /// <summary>
        /// 指定した要素型を持つList&lt;T&gt;クラスのインスタンスを生成します。
        /// </summary>
        /// <param name="type">要素型</param>
        /// <param name="count">要素数</param>
        /// <returns>インスタンス</returns>
        public static IList CreateTypedList(Type type, int count)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(count >= 0);

            var listType = typeof(List<>).MakeGenericType(type);
            var list = (IList)Activator.CreateInstance(listType, count);
            if (count >= 1)
            {
                var defaultValue = new DefaultValue(type, false, false);
                for (var index = 0; index < count; index++)
                {
                    list.Add(defaultValue.Value);
                }
            }

            return list;
        }
        #endregion

        #region GetInterfaceListByOrdered
        /// <summary>
        /// 指定されたインターフェイスが実装するインターフェイスのリストをソートします。
        /// </summary>
        /// <param name="targetInterface">対象のインターフェイス</param>
        /// <returns>実装しているインターフェイスのリストが一致している事を確認し、
        /// InterfacePriorityAttributeが指定されている場合はその指定の順序に従います。</returns>
        public static IEnumerable<Type> GetInterfaceListByOrdered(Type targetInterface)
        {
            Assertion.Condition(targetInterface != null);
            Assertion.Condition(targetInterface.IsInterface == true);

            return
                INTERFACE_LIST.GetOrAdd(
                    targetInterface,
                    type =>
                    {
                        // インターフェイスリストを取得する
                        var interfaces = TypeUtility.GetImplementedInterfaceList(targetInterface).Reverse();

                        // InterfaceOrderAttributeが適用されていなければ
                        var attributes = (InterfaceOrderAttribute[])
                            targetInterface.GetCustomAttributes(typeof(InterfaceOrderAttribute), false);
                        if (attributes.Length == 0)
                        {
                            // そのまま返す
                            return interfaces;
                        }

                        Assertion.Condition(attributes.Length == 1);

                        // それぞれをハッシュセットに入れ、全てが存在するかどうかを確認する
                        var metaDataInterfaces = new HashSet<Type>();
                        foreach (var metaDataInterface in interfaces)
                        {
                            metaDataInterfaces.Add(metaDataInterface);
                        }

                        var attributeInterfaces = new HashSet<Type>();
                        for (var i = 0; i < attributes[0].InterfaceTypes.Length; i++)
                        {
                            attributeInterfaces.Add(attributes[0].InterfaceTypes[i]);
                        }

                        foreach (var metaDataInterface in metaDataInterfaces)
                        {
                            Assertion.Argument(
                                attributeInterfaces.Contains(metaDataInterface) == true,
                                "属性 {0} に指定するインターフェイスのリストが不足しています: 対象の型={1}",
                                typeof(InterfaceOrderAttribute).FullName,
                                metaDataInterface.FullName);
                        }

                        foreach (var attributeInterface in attributeInterfaces)
                        {
                            Assertion.Argument(
                                metaDataInterfaces.Contains(attributeInterface) == true,
                                "属性 {0} に指定されたインターフェイスは無関係です: 対象の型={1}",
                                typeof(InterfaceOrderAttribute).FullName,
                                attributeInterface.FullName);
                        }

                        // 結局、最後は指定されたとおりのリストを返す
                        return attributes[0].InterfaceTypes;
                    });
        }
        #endregion

        #region ApplySerializationConverts
        /// <summary>
        /// シリアル化時のカスタムコンバートを実行します。
        /// </summary>
        /// <param name="value">変換前の値</param>
        /// <param name="pi">対応するプロパティ情報</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="preDefinedConverters">事前定義されたカスタムコンバータの辞書</param>
        /// <returns>変換後の値</returns>
        /// <remarks>カスタムコンバートが定義されていない場合は、そのまま返します。</remarks>
        public static object ApplySerializationConverts(
            object value,
            PropertyInfo pi,
            CultureInfo cultureInfo,
            IDictionary<Type, ICustomConvert> preDefinedConverters)
        {
            Assertion.Condition(pi != null);
            Assertion.Condition(preDefinedConverters != null);
            Assertion.Condition(cultureInfo != null);

            var convertedValue = value;

            foreach (var convert in CONVERTERS.GetOrAdd(
                pi,
                pi2 => (CustomConvertAttribute[])pi2.GetCustomAttributes(typeof(CustomConvertAttribute), true)))
            {
                // 属性クラスに対応するコンテキストを取得する
                ICustomConvert converter;

                // 登録されていなければ
                if (preDefinedConverters.TryGetValue(convert.GetType(), out converter) == false)
                {
                    // 属性クラスが直接実装を提供するか？
                    converter = convert as ICustomConvert;
                    Assertion.Require<ConfigurationSerializerException>(
                        converter != null,
                        "プロパティ {0}.{1} に指定されている属性 {0} に対応する変換がありません",
                        pi.DeclaringType.FullName,
                        pi.Name,
                        convert.GetType().FullName);
                }

                // 変換を実行する
                convertedValue = converter.SerializationConvert(convertedValue, pi, cultureInfo);
            }

            return convertedValue;
        }
        #endregion

        #region ApplyDeserializationConverts
        /// <summary>
        /// 逆シリアル化時のカスタムコンバートを実行します。
        /// </summary>
        /// <param name="value">変換前の値</param>
        /// <param name="pi">対応するプロパティ情報</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="preDefinedConverters">事前定義されたカスタムコンバータの辞書</param>
        /// <returns>変換後の値</returns>
        /// <remarks>カスタムコンバートが定義されていない場合は、そのまま返します。</remarks>
        public static object ApplyDeserializationConverts(
            object value,
            PropertyInfo pi,
            CultureInfo cultureInfo,
            IDictionary<Type, ICustomConvert> preDefinedConverters)
        {
            Assertion.Condition(pi != null);
            Assertion.Condition(preDefinedConverters != null);
            Assertion.Condition(cultureInfo != null);

            var convertedValue = value;

            foreach (var convert in CONVERTERS.GetOrAdd(
                pi,
                pi2 => (CustomConvertAttribute[])pi2.GetCustomAttributes(typeof(CustomConvertAttribute), true)))
            {
                // 属性クラスに対応するコンテキストを取得する
                ICustomConvert converter;

                // 登録されていなければ
                if (preDefinedConverters.TryGetValue(convert.GetType(), out converter) == false)
                {
                    // 属性クラスが直接実装を提供するか？
                    converter = convert as ICustomConvert;
                    Assertion.Require<ConfigurationSerializerException>(
                        converter != null,
                        "プロパティ {0}.{1} に指定されている属性 {0} に対応する変換がありません",
                        pi.DeclaringType.FullName,
                        pi.Name,
                        convert.GetType().FullName);
                }

                // 変換を実行する
                convertedValue = converter.DeserializationConvert(convertedValue, pi, cultureInfo);
            }

            return convertedValue;
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.01.21 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Collections
{
    /// <summary>
    /// キーセレクタを使用する比較演算子です。
    /// </summary>
    /// <typeparam name="T">要素の型</typeparam>
    /// <remarks>キーセレクタデリゲートを与える事で、簡単に比較演算子を生成出来ます。</remarks>
    public sealed class DelegatedComparer<T> : IEqualityComparer<T>, IComparer<T>
    {
        /// <summary>
        /// キーセレクタ群
        /// </summary>
        private readonly Func<T, object>[] _keySelectors;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="keySelector">キーセレクタ</param>
        /// <param name="keySelectors">キーセレクタ群</param>
        public DelegatedComparer(Func<T, object> keySelector, params Func<T, object>[] keySelectors)
        {
            Assertion.NullArgument(keySelector, "キーセレクタが必要です");

            this._keySelectors = keySelector.ToSequence().Concat(keySelectors).ToArray();
        }

        /// <summary>
        /// インスタンスを比較します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>一致すればtrue</returns>
        public bool Equals(T x, T y)
        {
            for (var index = 0; index < this._keySelectors.Length; index++)
            {
                var xvalue = this._keySelectors[index](x);
                var yvalue = this._keySelectors[index](y);
                if (xvalue.Equals(yvalue) == false)
                {
                    return false;
                }
            }

            return true;
        }

        /// <summary>
        /// インスタンスのハッシュコードを取得します。
        /// </summary>
        /// <param name="obj">対象のインスタンス</param>
        /// <returns>ハッシュコード</returns>
        public int GetHashCode(T obj)
        {
            var result = 0;
            for (var index = 0; index < this._keySelectors.Length; index++)
            {
                result = result ^ this._keySelectors[index](obj).GetHashCode();
            }

            return result;
        }

        /// <summary>
        /// インスタンスを比較します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        public int Compare(T x, T y)
        {
            for (var index = 0; index < this._keySelectors.Length; index++)
            {
                var xvalue = this._keySelectors[index](x);
                var yvalue = this._keySelectors[index](y);
                var result = Comparer.Default.Compare(xvalue, yvalue);
                if (result != 0)
                {
                    return result;
                }
            }

            return 0;
        }
    }
}

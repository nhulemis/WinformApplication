﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.21 TMI K.Matsui

using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Collections
{
    /// <summary>
    /// 文字列のあいまい一致を判定する比較クラスです。
    /// </summary>
    public sealed class FuzzyStringComparer : IComparer<string>, IEqualityComparer<string>, IComparer, IEqualityComparer
    {
        /// <summary>
        /// デフォルトインスタンス
        /// </summary>
        private static readonly FuzzyStringComparer DEFAULT = new FuzzyStringComparer();

        /// <summary>
        /// カルチャ情報
        /// </summary>
        private readonly CultureInfo _culture;

        /// <summary>
        /// オプション
        /// </summary>
        private readonly CompareOptions _options;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <remarks>インバリアントカルチャで、大文字小文字と半角全角を無視します。</remarks>
        public FuzzyStringComparer()
        {
            this._culture = CultureInfo.InvariantCulture;
            this._options = CompareOptions.IgnoreCase | CompareOptions.IgnoreWidth;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="culture">指定されたカルチャを使用して比較します</param>
        /// <param name="options">比較のオプションフラグ</param>
        public FuzzyStringComparer(CultureInfo culture, CompareOptions options)
        {
            Assertion.NullArgument(culture, "カルチャ情報が必要です");

            this._culture = culture;
            this._options = options;
        }

        /// <summary>
        /// FuzzyStringComparerの既定のインスタンスを取得します。
        /// </summary>
        public static FuzzyStringComparer Default
        {
            get
            {
                return DEFAULT;
            }
        }

        /// <summary>
        /// 指定されたUNICODEカテゴリが、ステミングの対象かどうかを確認します。
        /// </summary>
        /// <param name="uc">UNICODEカテゴリ</param>
        /// <returns>対象ならtrue</returns>
        internal static bool IsStemTarget(UnicodeCategory uc)
        {
            switch (uc)
            {
                // セパレータ文字
                case UnicodeCategory.SpaceSeparator:
                case UnicodeCategory.LineSeparator:
                case UnicodeCategory.ParagraphSeparator:
                // 区切り文字
                case UnicodeCategory.OpenPunctuation:
                case UnicodeCategory.ClosePunctuation:
                case UnicodeCategory.ConnectorPunctuation:
                case UnicodeCategory.DashPunctuation:
                case UnicodeCategory.InitialQuotePunctuation:
                case UnicodeCategory.FinalQuotePunctuation:
                case UnicodeCategory.OtherPunctuation:
                // 修飾記号
                case UnicodeCategory.ModifierLetter:
                // シンボル文字
                case UnicodeCategory.MathSymbol:
                case UnicodeCategory.ModifierSymbol:
                case UnicodeCategory.CurrencySymbol:
                case UnicodeCategory.OtherSymbol:
                    return true;
                default:
                    return false;
            }
        }

        /// <summary>
        /// 指定された文字列を、あいまい一致用にステミングします。
        /// </summary>
        /// <param name="original">ステミングする文字列</param>
        /// <returns>結果</returns>
        internal static string Stem(string original)
        {
            var sb = new StringBuilder();
            for (var i = 0; i < original.Length; i++)
            {
                var ch = original[i];
                var uc = char.GetUnicodeCategory(ch);
                if (IsStemTarget(uc) == false)
                {
                    sb.Append(ch);
                }
            }

            return sb.ToString();
        }

        /// <summary>
        /// 比較を実行します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        public int Compare(string x, string y)
        {
            if ((x == null) && (y == null))
            {
                return 0;
            }

            if (x == null)
            {
                return int.MinValue;
            }

            if (y == null)
            {
                return int.MaxValue;
            }

            var stemX = Stem(x);
            var stemY = Stem(y);

            return string.Compare(stemX, stemY, this._culture, this._options);
        }

        /// <summary>
        /// 比較を実行します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        public bool Equals(string x, string y)
        {
            return Compare(x, y) == 0;
        }

        /// <summary>
        /// 指定された文字列のあいまい一致用に加工した文字列としてハッシュコードを取得します。
        /// </summary>
        /// <param name="target">文字列</param>
        /// <returns>ハッシュコード</returns>
        public int GetHashCode(string target)
        {
            return Stem(target).GetHashCode();
        }

        /// <summary>
        /// 比較を実行します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        public int Compare(object x, object y)
        {
            return this.Compare(x as string, y as string);
        }

        /// <summary>
        /// 比較を実行します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        public new bool Equals(object x, object y)
        {
            return this.Equals(x as string, y as string);
        }

        /// <summary>
        /// 指定された文字列のあいまい一致用に加工した文字列としてハッシュコードを取得します。
        /// </summary>
        /// <param name="target">文字列</param>
        /// <returns>ハッシュコード</returns>
        public int GetHashCode(object target)
        {
            return this.GetHashCode(target as string);
        }
    }
}

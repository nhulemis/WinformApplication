﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.20 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Data.Objects;
using System.Globalization;
using System.Linq;

namespace CREO.Fluere.Common.Collections
{
    /// <summary>
    /// LINQ向け拡張メソッドです。
    /// </summary>
    public static class LinqExtension
    {
        #region ToTraceString
        /// <summary>
        /// クエリ文字列を取得します。
        /// </summary>
        /// <typeparam name="T">クエリの型</typeparam>
        /// <param name="query">クエリ</param>
        /// <returns>文字列</returns>
        public static string ToTraceString<T>(this IQueryable<T> query)
        {
            var objectQuery = query as ObjectQuery;
            return (objectQuery != null) ? objectQuery.ToTraceString() : "(Not entity query)";
        }
        #endregion

        #region AsParallelAsReleased
#if DEBUG
        /// <summary>
        /// リリースビルド時のみ並列化を実施します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="ordered">順序を維持するかどうか</param>
        /// <returns>並列化列挙子</returns>
        /// <remarks>デバッグビルド時は、orderedは無視されます。</remarks>
        public static IEnumerable<T> AsParallelAsReleased<T>(this IEnumerable<T> enumerable, bool ordered = false)
        {
            return enumerable;
        }
#else
        /// <summary>
        /// リリースビルド時のみ並列化を実施します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="ordered">順序を維持するかどうか</param>
        /// <returns>並列化列挙子</returns>
        /// <remarks>デバッグビルド時は、orderedは無視されます。</remarks>
        public static ParallelQuery<T> AsParallelAsReleased<T>(this IEnumerable<T> enumerable, bool ordered = false)
        {
            return ordered ? enumerable.AsParallel() : enumerable.AsParallel().AsOrdered();
        }
#endif
        #endregion

        #region ToListAsDebugging
        /// <summary>
        /// デバッグビルド時のみ固定化します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">処理前の列挙子</param>
        /// <returns>処理後の列挙子</returns>
        public static IEnumerable<T> ToListAsDebugging<T>(this IEnumerable<T> enumerable)
        {
#if DEBUG
            return enumerable.ToList();
#else
            return enumerable;
#endif
        }
        #endregion

        #region Parse
        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static byte ParseByte(
            this string stringValue,
            byte defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            byte result;
            if (byte.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }

        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static sbyte ParseSByte(
            this string stringValue,
            sbyte defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            sbyte result;
            if (sbyte.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }

        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static short ParseInt16(
            this string stringValue,
            short defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            short result;
            if (short.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }

        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static ushort ParseUInt16(
            this string stringValue,
            ushort defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            ushort result;
            if (ushort.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }

        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static int ParseInt32(
            this string stringValue,
            int defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            int result;
            if (int.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }

        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static uint ParseUInt32(
            this string stringValue,
            uint defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            uint result;
            if (uint.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }

        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static long ParseInt64(
            this string stringValue,
            long defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            long result;
            if (long.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }

        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static ulong ParseUInt64(
            this string stringValue,
            ulong defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            ulong result;
            if (ulong.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }

        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static float ParseFloat(
            this string stringValue,
            float defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            float result;
            if (float.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }

        /// <summary>
        /// 文字列をパースします。
        /// </summary>
        /// <param name="stringValue">文字列</param>
        /// <param name="defaultValue">パース出来ない場合の代替の結果</param>
        /// <param name="numberStyles">数値形式</param>
        /// <param name="formatProvider">フォーマットプロバイダ</param>
        /// <returns>結果</returns>
        public static double ParseDouble(
            this string stringValue,
            double defaultValue = 0,
            NumberStyles numberStyles = NumberStyles.Any,
            IFormatProvider formatProvider = null)
        {
            var fp = formatProvider ?? CultureInfo.InvariantCulture;

            double result;
            if (double.TryParse(stringValue, numberStyles, fp, out result) == false)
            {
                return defaultValue;
            }

            return result;
        }
        #endregion
    }
}

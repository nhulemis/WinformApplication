﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.21 TMI K.Matsui

using System.Collections;
using System.Globalization;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Collections
{
    /// <summary>
    /// 文字列の場合にあいまい一致を判定する比較クラスです。
    /// </summary>
    /// <remarks>このクラスを使用すると、文字列の場合はFuzzyStringComparer、
    /// それ以外の型はComparerクラスを使用して比較を実行します。</remarks>
    public sealed class FuzzyComparer : IComparer, IEqualityComparer
    {
        /// <summary>
        /// デフォルトインスタンス
        /// </summary>
        private static readonly FuzzyComparer DEFAULT = new FuzzyComparer();

        /// <summary>
        /// FuzzyStringComparerのインスタンス
        /// </summary>
        private readonly FuzzyStringComparer _comparer;

        /// <summary>
        /// デフォルト比較演算子
        /// </summary>
        private readonly Comparer _defaultComparer;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <remarks>インバリアントカルチャで、大文字小文字と半角全角を無視します。</remarks>
        public FuzzyComparer()
        {
            this._comparer = FuzzyStringComparer.Default;
            this._defaultComparer = Comparer.DefaultInvariant;
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="culture">指定されたカルチャを使用して比較します</param>
        /// <param name="options">比較のオプションフラグ</param>
        public FuzzyComparer(CultureInfo culture, CompareOptions options)
        {
            Assertion.NullArgument(culture, "カルチャ情報が必要です");

            this._comparer = new FuzzyStringComparer(culture, options);
            this._defaultComparer = new Comparer(culture);
        }

        /// <summary>
        /// FuzzyComparerの既定のインスタンスを取得します。
        /// </summary>
        public static FuzzyComparer Default
        {
            get
            {
                return DEFAULT;
            }
        }

        /// <summary>
        /// 比較を実行します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        public int Compare(object x, object y)
        {
            if ((x is string) || (y is string))
            {
                return this._comparer.Compare(x, y);
            }
            else
            {
                return this._defaultComparer.Compare(x, y);
            }
        }

        /// <summary>
        /// 比較を実行します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        public new bool Equals(object x, object y)
        {
            if ((x is string) || (y is string))
            {
                return this._comparer.Equals(x, y);
            }
            else
            {
                return this._defaultComparer.Compare(x, y) == 0;
            }
        }

        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <param name="target">文字列</param>
        /// <returns>ハッシュコード</returns>
        public int GetHashCode(object target)
        {
            if (target is string)
            {
                return this._comparer.GetHashCode(target);
            }
            else
            {
                return this._defaultComparer.GetHashCode();
            }
        }
    }
}

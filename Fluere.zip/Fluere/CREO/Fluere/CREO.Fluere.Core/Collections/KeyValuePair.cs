﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.15 TMI K.Matsui

using System.Collections.Generic;

namespace CREO.Fluere.Common.Collections
{
    /// <summary>
    /// KeyValuePairのファクトリクラスです。
    /// </summary>
    public static class KeyValuePair
    {
        /// <summary>
        /// KeyValuePairを生成します。
        /// </summary>
        /// <typeparam name="T">キーの型</typeparam>
        /// <typeparam name="U">値の型</typeparam>
        /// <param name="key">キー</param>
        /// <param name="value">値</param>
        /// <returns>生成したインスタンス</returns>
        public static KeyValuePair<T, U> Create<T, U>(T key, U value)
        {
            return new KeyValuePair<T, U>(key, value);
        }
    }
}

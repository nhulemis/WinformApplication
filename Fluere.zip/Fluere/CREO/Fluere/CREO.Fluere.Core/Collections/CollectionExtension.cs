﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.07.18 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Collections
{
    /// <summary>
    /// コレクションの拡張メソッドクラスです。
    /// </summary>
    /// <remarks>LINQでの操作を容易に行うためのユーティリティメソッドを含みます。</remarks>
    public static class CollectionExtension
    {
        #region StoreToCollection
        /// <summary>
        /// 指定された値群をコレクションに格納します。
        /// </summary>
        /// <typeparam name="T">値となる型</typeparam>
        /// <typeparam name="U">辞書の型</typeparam>
        /// <param name="collection">格納するコレクション</param>
        /// <param name="values">値群</param>
        private static void StoreToCollection<T, U>(
            U collection,
            IEnumerable<T> values)
            where U : ICollection<T>
        {
            foreach (var entry in values)
            {
                collection.Add(entry);
            }
        }
        #endregion

        #region StoreToCollectionBySelector
        /// <summary>
        /// 指定された値群をコレクションに格納します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <typeparam name="V">辞書の型</typeparam>
        /// <typeparam name="W">セレクタの入力型</typeparam>
        /// <param name="collection">格納するコレクション</param>
        /// <param name="values">値群</param>
        /// <param name="keySelector">キーのセレクタ</param>
        /// <param name="valueSelector">値のセレクタ</param>
        private static void StoreToCollectionBySelector<T, U, V, W>(
            V collection,
            IEnumerable<W> values,
            Func<W, T> keySelector,
            Func<W, U> valueSelector)
            where V : IDictionary<T, U>
        {
            foreach (var entry in values)
            {
                collection.Add(keySelector(entry), valueSelector(entry));
            }
        }
        #endregion

        #region ForEach
        /// <summary>
        /// 指定された値群に対してデリゲートで処理を実行します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="values">値群</param>
        /// <param name="action">要素を実行するデリゲート</param>
        public static void ForEach<T>(this IEnumerable<T> values, Action<T> action)
        {
            Assertion.NullArgument(values, "列挙子が必要です");

            foreach (T value in values)
            {
                action(value);
            }
        }
        #endregion

        #region Invoke
        /// <summary>
        /// 指定された処理群を逐次実行します。
        /// </summary>
        /// <param name="actions">処理群</param>
        public static void Invoke(params Action[] actions)
        {
            foreach (var action in actions)
            {
                action();
            }
        }
        #endregion

        #region AddRange
        /// <summary>
        /// コレクションに列挙子が示す要素群を追加します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="collection">追加前コレクション</param>
        /// <param name="values">要素群を示す列挙子</param>
        /// <returns>追加後コレクション</returns>
        public static ICollection<T> AddRange<T>(this ICollection<T> collection, IEnumerable<T> values)
        {
            Assertion.NullArgument(collection, "コレクションが必要です");
            Assertion.NullArgument(values, "列挙子が必要です");

            var list = collection as List<T>;
            if (list != null)
            {
                list.AddRange(values);
            }
            else
            {
                foreach (var value in values)
                {
                    collection.Add(value);
                }
            }

            return collection;
        }

        /// <summary>
        /// コレクションに要素群を追加します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="collection">追加前コレクション</param>
        /// <param name="values">要素群</param>
        /// <returns>追加後コレクション</returns>
        public static ICollection<T> AddRange<T>(this ICollection<T> collection, params T[] values)
        {
            return AddRange(collection, (IEnumerable<T>)values);
        }

        /// <summary>
        /// コレクションに列挙子が示す要素群を追加します。
        /// </summary>
        /// <typeparam name="T">要素のキー型</typeparam>
        /// <typeparam name="U">要素の値型</typeparam>
        /// <typeparam name="V">辞書の型</typeparam>
        /// <param name="collection">追加前コレクション</param>
        /// <param name="values">要素群を示す列挙子</param>
        /// <returns>追加後コレクション</returns>
        public static V AddRange<T, U, V>(
            this V collection, IEnumerable<KeyValuePair<T, U>> values)
            where V : class, IDictionary<T, U>
        {
            Assertion.NullArgument(collection, "コレクションが必要です");
            Assertion.NullArgument(values, "列挙子が必要です");

            foreach (var value in values)
            {
                collection.Add(value);
            }

            return collection;
        }

        /// <summary>
        /// コレクションに要素群を追加します。
        /// </summary>
        /// <typeparam name="T">要素のキー型</typeparam>
        /// <typeparam name="U">要素の値型</typeparam>
        /// <typeparam name="V">辞書の型</typeparam>
        /// <param name="collection">追加前コレクション</param>
        /// <param name="values">要素群</param>
        /// <returns>追加後コレクション</returns>
        public static V AddRange<T, U, V>(this V collection, params KeyValuePair<T, U>[] values)
            where V : class, IDictionary<T, U>
        {
            return AddRange(collection, (IEnumerable<KeyValuePair<T, U>>)values);
        }
        #endregion

        #region ToKeyValuePair
        /// <summary>
        /// 指定された値群をKeyValuePairのコレクションに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <typeparam name="V">セレクタの入力型</typeparam>
        /// <param name="values">値群</param>
        /// <param name="keySelector">キーのセレクタ</param>
        /// <param name="valueSelector">値のセレクタ</param>
        /// <returns>変換されたインスタンス</returns>
        public static IEnumerable<KeyValuePair<T, U>> ToKeyValuePair<T, U, V>(
            this IEnumerable<V> values,
            Func<V, T> keySelector,
            Func<V, U> valueSelector)
        {
            Assertion.NullArgument(values, "列挙子が必要です");

            return values.Select(entry => KeyValuePair.Create(keySelector(entry), valueSelector(entry)));
        }
        #endregion

        #region ToDictionary
        /// <summary>
        /// 指定された値群をDictionaryに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <param name="values">値群</param>
        /// <returns>変換されたインスタンス</returns>
        public static Dictionary<T, U> ToDictionary<T, U>(
            this IEnumerable<KeyValuePair<T, U>> values)
        {
            Assertion.NullArgument(values, "列挙子が必要です");

            var dictionary = new Dictionary<T, U>();
            StoreToCollection(dictionary, values);
            return dictionary;
        }

        /// <summary>
        /// 指定された値群をDictionaryに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <param name="values">値群</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>変換されたインスタンス</returns>
        public static Dictionary<T, U> ToDictionary<T, U>(
            this IEnumerable<KeyValuePair<T, U>> values,
            IEqualityComparer<T> comparer)
        {
            Assertion.NullArgument(values, "列挙子が必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            var dictionary = new Dictionary<T, U>(comparer);
            StoreToCollection(dictionary, values);
            return dictionary;
        }
        #endregion

        #region ToSortedDictionary
        /// <summary>
        /// 指定された値群をSortedDictionaryに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <param name="values">値群を示す列挙子</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedDictionary<T, U> ToSortedDictionary<T, U>(
            this IEnumerable<KeyValuePair<T, U>> values)
        {
            Assertion.NullArgument(values, "列挙子が必要です");

            var dictionary = new SortedDictionary<T, U>();
            StoreToCollection(dictionary, values);
            return dictionary;
        }

        /// <summary>
        /// 指定された値群をSortedDictionaryに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <typeparam name="V">セレクタの入力型</typeparam>
        /// <param name="values">値群</param>
        /// <param name="keySelector">キーのセレクタ</param>
        /// <param name="valueSelector">値のセレクタ</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedDictionary<T, U> ToSortedDictionary<T, U, V>(
            this IEnumerable<V> values,
            Func<V, T> keySelector,
            Func<V, U> valueSelector)
        {
            Assertion.NullArgument(values, "列挙子が必要です");

            var dictionary = new SortedDictionary<T, U>();
            StoreToCollectionBySelector(dictionary, values, keySelector, valueSelector);
            return dictionary;
        }

        /// <summary>
        /// 指定された値群をSortedDictionaryに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <param name="values">値群を示す列挙子</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedDictionary<T, U> ToSortedDictionary<T, U>(
            this IEnumerable<KeyValuePair<T, U>> values,
            IComparer<T> comparer)
        {
            Assertion.NullArgument(values, "列挙子が必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            var dictionary = new SortedDictionary<T, U>(comparer);
            StoreToCollection(dictionary, values);
            return dictionary;
        }

        /// <summary>
        /// 指定された値群をSortedDictionaryに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <typeparam name="V">セレクタの入力型</typeparam>
        /// <param name="values">値群</param>
        /// <param name="keySelector">キーのセレクタ</param>
        /// <param name="valueSelector">値のセレクタ</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedDictionary<T, U> ToSortedDictionary<T, U, V>(
            this IEnumerable<V> values,
            Func<V, T> keySelector,
            Func<V, U> valueSelector,
            IComparer<T> comparer)
        {
            Assertion.NullArgument(values, "列挙子が必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            var dictionary = new SortedDictionary<T, U>(comparer);
            StoreToCollectionBySelector(dictionary, values, keySelector, valueSelector);
            return dictionary;
        }
        #endregion

        #region ToSortedList
        /// <summary>
        /// 指定された値群をSortedListに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <param name="values">値群を示す列挙子</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedList<T, U> ToSortedList<T, U>(
            this IEnumerable<KeyValuePair<T, U>> values)
        {
            Assertion.NullArgument(values, "列挙子が必要です");

            var dictionary = new SortedList<T, U>();
            StoreToCollection(dictionary, values);
            return dictionary;
        }

        /// <summary>
        /// 指定された値群をSortedListに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <typeparam name="V">セレクタの入力型</typeparam>
        /// <param name="values">値群</param>
        /// <param name="keySelector">キーのセレクタ</param>
        /// <param name="valueSelector">値のセレクタ</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedList<T, U> ToSortedList<T, U, V>(
            this IEnumerable<V> values,
            Func<V, T> keySelector,
            Func<V, U> valueSelector)
        {
            Assertion.NullArgument(values, "列挙子が必要です");

            var dictionary = new SortedList<T, U>();
            StoreToCollectionBySelector(dictionary, values, keySelector, valueSelector);
            return dictionary;
        }

        /// <summary>
        /// 指定された値群をSortedListに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <param name="values">値群を示す列挙子</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedList<T, U> ToSortedList<T, U>(
            this IEnumerable<KeyValuePair<T, U>> values,
            IComparer<T> comparer)
        {
            Assertion.NullArgument(values, "列挙子が必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            var dictionary = new SortedList<T, U>(comparer);
            StoreToCollection(dictionary, values);
            return dictionary;
        }

        /// <summary>
        /// 指定された値群をSortedListに変換します。
        /// </summary>
        /// <typeparam name="T">キーとなる型</typeparam>
        /// <typeparam name="U">値となる型</typeparam>
        /// <typeparam name="V">セレクタの入力型</typeparam>
        /// <param name="values">値群</param>
        /// <param name="keySelector">キーのセレクタ</param>
        /// <param name="valueSelector">値のセレクタ</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedList<T, U> ToSortedList<T, U, V>(
            this IEnumerable<V> values,
            Func<V, T> keySelector,
            Func<V, U> valueSelector,
            IComparer<T> comparer)
        {
            Assertion.NullArgument(values, "列挙子が必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            var dictionary = new SortedList<T, U>(comparer);
            StoreToCollectionBySelector(dictionary, values, keySelector, valueSelector);
            return dictionary;
        }
        #endregion

        #region ToHashSet
        /// <summary>
        /// 指定された値群をHashSetに変換します。
        /// </summary>
        /// <typeparam name="T">型</typeparam>
        /// <param name="values">値群を示す列挙子</param>
        /// <returns>変換されたインスタンス</returns>
        public static HashSet<T> ToHashSet<T>(
            this IEnumerable<T> values)
        {
            Assertion.NullArgument(values, "列挙子が必要です");

            var hashSet = new HashSet<T>();
            StoreToCollection(hashSet, values);
            return hashSet;
        }

        /// <summary>
        /// 指定された値群をHashSetに変換します。
        /// </summary>
        /// <typeparam name="T">型</typeparam>
        /// <param name="values">値群を示す列挙子</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>変換されたインスタンス</returns>
        public static HashSet<T> ToHashSet<T>(
            this IEnumerable<T> values,
            IEqualityComparer<T> comparer)
        {
            Assertion.NullArgument(values, "列挙子が必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            var hashSet = new HashSet<T>(comparer);
            StoreToCollection(hashSet, values);
            return hashSet;
        }
        #endregion

        #region ToSortedSet
        /// <summary>
        /// 指定された値群をSortedSetに変換します。
        /// </summary>
        /// <typeparam name="T">型</typeparam>
        /// <param name="values">値群を示す列挙子</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedSet<T> ToSortedSet<T>(
            this IEnumerable<T> values)
        {
            Assertion.NullArgument(values, "列挙子が必要です");

            var sortedSet = new SortedSet<T>();
            StoreToCollection(sortedSet, values);
            return sortedSet;
        }

        /// <summary>
        /// 指定された値群をSortedSetに変換します。
        /// </summary>
        /// <typeparam name="T">型</typeparam>
        /// <param name="values">値群を示す列挙子</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>変換されたインスタンス</returns>
        public static SortedSet<T> ToSortedSet<T>(
            this IEnumerable<T> values,
            IComparer<T> comparer)
        {
            Assertion.NullArgument(values, "列挙子が必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            var sortedSet = new SortedSet<T>(comparer);
            StoreToCollection(sortedSet, values);
            return sortedSet;
        }
        #endregion

        #region Concat
        /// <summary>
        /// 指定されたシーケンスに単一の要素を追加します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="lhs">シーケンス</param>
        /// <param name="value">要素</param>
        /// <returns>追加されたシーケンス</returns>
        public static IEnumerable<T> Concat<T>(this IEnumerable<T> lhs, T value)
        {
            Assertion.NullArgument(lhs, "列挙子が必要です");

            return Enumerable.Concat(lhs, new T[] { value });
        }

        /// <summary>
        /// 指定されたシーケンスにシーケンス群を追加します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="lhs">シーケンス</param>
        /// <param name="rhss">シーケンス群</param>
        /// <returns>追加されたシーケンス</returns>
        public static IEnumerable<T> Concat<T>(this IEnumerable<T> lhs, params IEnumerable<T>[] rhss)
        {
            Assertion.NullArgument(lhs, "列挙子が必要です");
            Assertion.NullArgument(rhss, "列挙子が必要です");

            var result = lhs;
            foreach (var rhs in rhss)
            {
                Assertion.NullArgument(rhs, "列挙子が必要です");

                result = Enumerable.Concat(result, rhs);
            }

            return result;
        }

        /// <summary>
        /// 指定されたシーケンスにシーケンス群を追加します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="lhs">シーケンス</param>
        /// <param name="rhss">シーケンス群を示す列挙子</param>
        /// <returns>追加されたシーケンス</returns>
        public static IEnumerable<T> Concat<T>(this IEnumerable<T> lhs, IEnumerable<IEnumerable<T>> rhss)
        {
            Assertion.NullArgument(lhs, "列挙子が必要です");
            Assertion.NullArgument(rhss, "列挙子が必要です");

            var result = lhs;
            foreach (var rhs in rhss)
            {
                Assertion.NullArgument(rhs, "列挙子が必要です");

                result = Enumerable.Concat(result, rhs);
            }

            return result;
        }

        /// <summary>
        /// 指定されたシーケンスに単一の要素を追加します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="lhs">シーケンス</param>
        /// <param name="value">要素</param>
        /// <returns>追加されたシーケンス</returns>
        public static ParallelQuery<T> Concat<T>(this ParallelQuery<T> lhs, T value)
        {
            Assertion.NullArgument(lhs, "列挙子が必要です");

            return ParallelEnumerable.Concat(lhs, new T[] { value }.AsParallel());
        }

        /// <summary>
        /// 指定されたシーケンスにシーケンス群を追加します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="lhs">シーケンス</param>
        /// <param name="rhss">シーケンス群</param>
        /// <returns>追加されたシーケンス</returns>
        public static ParallelQuery<T> Concat<T>(this ParallelQuery<T> lhs, params ParallelQuery<T>[] rhss)
        {
            Assertion.NullArgument(lhs, "列挙子が必要です");
            Assertion.NullArgument(rhss, "列挙子が必要です");

            var result = lhs;
            foreach (var rhs in rhss)
            {
                Assertion.NullArgument(rhs, "列挙子が必要です");

                result = ParallelEnumerable.Concat(result, rhs);
            }

            return result;
        }

        /// <summary>
        /// 指定されたシーケンスにシーケンス群を追加します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="lhs">シーケンス</param>
        /// <param name="rhss">シーケンス群を示す列挙子</param>
        /// <returns>追加されたシーケンス</returns>
        public static ParallelQuery<T> Concat<T>(this ParallelQuery<T> lhs, IEnumerable<ParallelQuery<T>> rhss)
        {
            Assertion.NullArgument(lhs, "列挙子が必要です");
            Assertion.NullArgument(rhss, "列挙子が必要です");

            var result = lhs;
            foreach (var rhs in rhss)
            {
                Assertion.NullArgument(rhs, "列挙子が必要です");

                result = ParallelEnumerable.Concat(result, rhs);
            }

            return result;
        }
        #endregion

        #region ConcatToString
        /// <summary>
        /// 文字群を連結して文字列に変換します。
        /// </summary>
        /// <param name="chars">文字群</param>
        /// <returns>文字列</returns>
        public static string ConcatToString(this IEnumerable<char> chars)
        {
            Assertion.NullArgument(chars, "列挙子が必要です");

            var charArray = chars as char[];
            if (charArray != null)
            {
                return new string(charArray);
            }
            else
            {
                return string.Concat(chars);
            }
        }
        #endregion

        #region ContainsWords
        /// <summary>
        /// 指定された文字列に、後続の文字列群の何れかが含まれているかどうかを取得します。
        /// </summary>
        /// <param name="lhs">調べる文字列</param>
        /// <param name="words">確認する文字列群</param>
        /// <returns>文字列群の何れかが含まれていればtrue</returns>
        public static bool ContainsWords(this string lhs, IEnumerable<string> words)
        {
            Assertion.NullArgument(lhs, "文字列が必要です");
            Assertion.NullArgument(words, "列挙子が必要です");

            foreach (var word in words)
            {
                if (lhs.Contains(word) == true)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region ToSequence
        /// <summary>
        /// 指定された要素を単一のシーケンスに変換します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="value">要素</param>
        /// <returns>シーケンス</returns>
        public static IEnumerable<T> ToSequence<T>(this T value)
        {
            return new T[] { value };
        }
        #endregion

        #region NullableTo
        /// <summary>
        /// Null許容型の値を、別のNull許容型の値に変換します。
        /// </summary>
        /// <typeparam name="T">変換元の型</typeparam>
        /// <typeparam name="U">変換先の型</typeparam>
        /// <param name="value">変換元の値</param>
        /// <param name="predict">変換演算子</param>
        /// <returns>変換後の値</returns>
        public static U? NullableTo<T, U>(this T? value, Func<T, U?> predict)
            where T : struct
            where U : struct
        {
            Assertion.NullArgument(predict, "変換演算子が必要です");

            if (value.HasValue == false)
            {
                return null;
            }

            return predict(value.Value);
        }
        #endregion

        #region GetValue
        /// <summary>
        /// 指定された辞書からキーに対応する値を取得します。
        /// </summary>
        /// <typeparam name="T">キーの型</typeparam>
        /// <typeparam name="U">値の型</typeparam>
        /// <param name="dictionary">辞書</param>
        /// <param name="key">キー</param>
        /// <param name="defaultValue">キーが存在しない場合のデフォルト値</param>
        /// <returns>値</returns>
        public static U GetValue<T, U>(this IDictionary<T, U> dictionary, T key, U defaultValue = default(U))
        {
            Assertion.NullArgument(dictionary, "辞書が必要です");

            U value;
            if (dictionary.TryGetValue(key, out value) == true)
            {
                return value;
            }
            else
            {
                return defaultValue;
            }
        }
        #endregion

        #region Unloop
        /// <summary>
        /// 二重ループ構造のコレクションをアンループして結合し、単一の要素シーケンスに変換します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="doubleLoopCollection">二重ループ構造のコレクション</param>
        /// <returns>列挙子</returns>
        public static IEnumerable<T> Unloop<T>(this IEnumerable<IEnumerable<T>> doubleLoopCollection)
        {
            Assertion.NullArgument(doubleLoopCollection, "列挙子が必要です");

            return
                from inner in doubleLoopCollection
                from value in inner
                select value;
        }

        /// <summary>
        /// 二重ループ構造のコレクションをアンループして結合し、単一の要素シーケンスに変換します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="doubleLoopCollection">二重ループ構造のコレクション</param>
        /// <returns>並列クエリ</returns>
        public static IEnumerable<T> Unloop<T>(this IEnumerable<ParallelQuery<T>> doubleLoopCollection)
        {
            Assertion.NullArgument(doubleLoopCollection, "列挙子が必要です");

            return
                from inner in doubleLoopCollection
                from value in inner
                select value;
        }

        /// <summary>
        /// 二重ループ構造のコレクションをアンループして結合し、単一の要素シーケンスに変換します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="doubleLoopCollection">二重ループ構造のコレクション</param>
        /// <returns>並列クエリ</returns>
        public static ParallelQuery<T> Unloop<T>(this ParallelQuery<IEnumerable<T>> doubleLoopCollection)
        {
            Assertion.NullArgument(doubleLoopCollection, "列挙子が必要です");

            return
                from inner in doubleLoopCollection
                from value in inner
                select value;
        }

        /// <summary>
        /// 二重ループ構造のコレクションをアンループして結合し、単一の要素シーケンスに変換します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="doubleLoopCollection">二重ループ構造のコレクション</param>
        /// <returns>並列クエリ</returns>
        public static ParallelQuery<T> Unloop<T>(this ParallelQuery<ParallelQuery<T>> doubleLoopCollection)
        {
            Assertion.NullArgument(doubleLoopCollection, "列挙子が必要です");

            return
                from inner in doubleLoopCollection
                from value in inner
                select value;
        }
        #endregion

        #region Traverse
        /// <summary>
        /// 指定された要素が示す、別の要素へのリンクを連結した列挙子を返します。
        /// </summary>
        /// <typeparam name="T">要素の型（参照型）</typeparam>
        /// <param name="firstValue">最初の要素</param>
        /// <param name="predict">次の要素を返すデリゲート</param>
        /// <returns>要素を連結した列挙子</returns>
        /// <remarks>デリゲートがnullを返した場合は、リンクはそこで終了とみなされます。</remarks>
        public static IEnumerable<T> Traverse<T>(this T firstValue, Func<T, T> predict)
            where T : class
        {
            Assertion.NullArgument(predict, "次の要素を返すデリゲートが必要です");

            var value = firstValue;
            while (value != null)
            {
                yield return value;

                var next = predict(value);
                if (next == null)
                {
                    yield break;
                }

                value = next;
            }
        }
        #endregion

        #region MakeEmpty
        /// <summary>
        /// 指定された要素型を示す、空のシーケンスを返します。
        /// </summary>
        /// <typeparam name="T">要素型</typeparam>
        /// <param name="dummy">ダミーのインスタンス</param>
        /// <returns>空のシーケンス</returns>
        /// <remarks>引数に指定されたインスタンスは無視されます。</remarks>
        public static IEnumerable<T> MakeEmpty<T>(this T dummy)
        {
            return Enumerable.Empty<T>();
        }
        #endregion

        #region ToSafe
        /// <summary>
        /// シーケンスのインスタンスがnullの場合に、空のシーケンスを返します。
        /// </summary>
        /// <param name="enumerable">シーケンスを示す列挙子又はnull</param>
        /// <returns>シーケンス</returns>
        public static IEnumerable ToSafe(this IEnumerable enumerable)
        {
            return (enumerable != null) ? enumerable : new object[0];
        }

        /// <summary>
        /// シーケンスのインスタンスがnullの場合に、空のシーケンスを返します。
        /// </summary>
        /// <typeparam name="T">要素型</typeparam>
        /// <param name="enumerable">シーケンスを示す列挙子又はnull</param>
        /// <returns>シーケンス</returns>
        public static IEnumerable<T> ToSafe<T>(this IEnumerable enumerable)
        {
            return (enumerable != null) ? enumerable.Cast<T>() : Enumerable.Empty<T>();
        }

        /// <summary>
        /// シーケンスのインスタンスがnullの場合に、空のシーケンスを返します。
        /// </summary>
        /// <typeparam name="T">要素型</typeparam>
        /// <param name="enumerable">シーケンスを示す列挙子又はnull</param>
        /// <returns>シーケンス</returns>
        public static IEnumerable<T> ToSafe<T>(this IEnumerable<T> enumerable)
        {
            return (enumerable != null) ? enumerable : Enumerable.Empty<T>();
        }
        #endregion

        #region WithIndex
        /// <summary>
        /// 指定された列挙子にインデックスを付与します。
        /// </summary>
        /// <typeparam name="T">要素型</typeparam>
        /// <param name="enumerable">付与前の列挙子</param>
        /// <returns>付与後の列挙子</returns>
        public static IEnumerable<Tuple<int, T>> WithIndex<T>(this IEnumerable<T> enumerable)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");

            var index = 0;
            return enumerable.Select(entry => Tuple.Create(index++, entry));
        }

        /// <summary>
        /// 指定された並列列挙子にインデックスを付与します。
        /// </summary>
        /// <typeparam name="T">要素型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <returns>並列クエリ</returns>
        /// <remarks>パラレル化クエリに適用する場合、
        /// OrderedParallelQueryインスタンスであるか、
        /// 又は内部的に順序が維持されているParallelQueryインスタンスのどちらでもない場合は、
        /// インデックスの順序付けが不定となります。</remarks>
        public static ParallelQuery<Tuple<int, T>> WithIndex<T>(this ParallelQuery<T> enumerable)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");

            var index = 0;
            return enumerable.AsSequential().Select(entry => Tuple.Create(index++, entry)).AsParallel();
        }
        #endregion

        #region BinarySearch
        /// <summary>
        /// バイナリサーチを実行します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="list">要素群を格納するコレクション。要素はソートされていなければなりません。</param>
        /// <param name="value">検索対象の要素</param>
        /// <returns>要素が存在するインデックス</returns>
        /// <remarks>指定した値が IList(Of T) に格納されていない場合、
        /// この負の整数に、ビットごとの補数演算 (~) を適用して
        /// 検索値よりも大きい最初の要素のインデックスを取得できます。</remarks>
        public static int BinarySearch<T>(this IList<T> list, T value)
            where T : IComparable<T>
        {
            return BinarySearch(list, 0, list.Count, value);
        }

        /// <summary>
        /// バイナリサーチを実行します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="list">要素群を格納するコレクション。要素はソートされていなければなりません。</param>
        /// <param name="index">検索開始位置</param>
        /// <param name="length">検索範囲</param>
        /// <param name="value">検索対象の要素</param>
        /// <returns>要素が存在するインデックス</returns>
        /// <remarks>指定した値が IList(Of T) に格納されていない場合、
        /// この負の整数に、ビットごとの補数演算 (~) を適用して
        /// 検索値よりも大きい最初の要素のインデックスを取得できます。</remarks>
        public static int BinarySearch<T>(this IList<T> list, int index, int length, T value)
            where T : IComparable<T>
        {
            return BinarySearch(list, index, length, value, Comparer<T>.Default);
        }

        /// <summary>
        /// バイナリサーチを実行します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="list">要素群を格納するコレクション。要素はソートされていなければなりません。</param>
        /// <param name="value">検索対象の要素</param>
        /// <param name="comparer">比較インターフェイス</param>
        /// <returns>要素が存在するインデックス</returns>
        /// <remarks>指定した値が IList(Of T) に格納されていない場合、
        /// この負の整数に、ビットごとの補数演算 (~) を適用して
        /// 検索値よりも大きい最初の要素のインデックスを取得できます。</remarks>
        public static int BinarySearch<T>(this IList<T> list, T value, IComparer<T> comparer)
        {
            return BinarySearch(list, 0, list.Count, value, comparer);
        }

        /// <summary>
        /// バイナリサーチを実行します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="list">要素群を格納するコレクション。要素はソートされていなければなりません。</param>
        /// <param name="index">検索開始位置</param>
        /// <param name="length">検索範囲</param>
        /// <param name="value">検索対象の要素</param>
        /// <param name="comparer">比較インターフェイス</param>
        /// <returns>要素が存在するインデックス</returns>
        /// <remarks>指定した値が IList(Of T) に格納されていない場合、
        /// この負の整数に、ビットごとの補数演算 (~) を適用して
        /// 検索値よりも大きい最初の要素のインデックスを取得できます。</remarks>
        public static int BinarySearch<T>(this IList<T> list, int index, int length, T value, IComparer<T> comparer)
        {
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            return BinarySearch(
                list,
                0,
                list.Count,
                lhs => comparer.Compare(lhs, value));
        }

        /// <summary>
        /// バイナリサーチを実行します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="list">要素群を格納するコレクション。要素はソートされていなければなりません。</param>
        /// <param name="index">検索開始位置</param>
        /// <param name="length">検索範囲</param>
        /// <param name="predict">比較関数</param>
        /// <returns>要素が存在するインデックス</returns>
        /// <remarks>値が IList(Of T) に格納されていない場合、
        /// この負の整数に、ビットごとの補数演算 (~) を適用して
        /// 検索値よりも大きい最初の要素のインデックスを取得できます。</remarks>
        public static int BinarySearch<T>(
            this IList<T> list,
            int index,
            int length,
            Func<T, int> predict)
        {
            Assertion.NullArgument(list, "コレクションが必要です");
            Assertion.Argument((index + length) <= list.Count, "検索範囲が不正です");
            Assertion.NullArgument(predict, "比較関数が必要です");

            var nowIndex = index;
            var lastIndex = nowIndex + length - 1;
            while (nowIndex <= lastIndex)
            {
                var centerIndex = nowIndex + ((lastIndex - nowIndex) / 2);
                var result = predict(list[centerIndex]);
                if (result == 0)
                {
                    return centerIndex;
                }

                if (result < 0)
                {
                    nowIndex = centerIndex + 1;
                }
                else
                {
                    lastIndex = centerIndex - 1;
                }
            }

            return ~nowIndex;
        }
        #endregion

        #region Unique
        /// <summary>
        /// ソートされたシーケンスの重複する要素値を削除します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">シーケンス</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>重複要素値が取り除かれたシーケンス</returns>
        /// <remarks>与えるシーケンスはソートされていなければなりません。</remarks>
        public static IEnumerable<T> Unique<T>(this IEnumerable<T> enumerable, IEqualityComparer<T> comparer)
        {
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            return Unique(enumerable, comparer.Equals);
        }

        /// <summary>
        /// ソートされたシーケンスの重複する要素値を削除します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">シーケンス</param>
        /// <param name="predict">比較関数</param>
        /// <returns>重複要素値が取り除かれたシーケンス</returns>
        /// <remarks>与えるシーケンスはソートされていなければなりません。</remarks>
        public static IEnumerable<T> Unique<T>(this IEnumerable<T> enumerable, Func<T, T, bool> predict)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");
            Assertion.NullArgument(predict, "比較関数が必要です");

            var enumerator = enumerable.GetEnumerator();
            try
            {
                var first = true;
                var lastValue = default(T);
                while (enumerator.MoveNext() == true)
                {
                    var value = enumerator.Current;
                    if ((first == true) || (predict(lastValue, value) == false))
                    {
                        yield return value;
                        lastValue = value;
                        first = false;
                    }
                }
            }
            finally
            {
                var disposable = enumerator as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
            }
        }
        #endregion

        #region Distinct
        /// <summary>
        /// 指定された列挙子の要素を一意化します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">一意化前の列挙子</param>
        /// <param name="keySelector">キーセレクタ</param>
        /// <param name="keySelectors">キーセレクタ群</param>
        /// <returns>一意化後の列挙子</returns>
        public static IEnumerable<T> Distinct<T>(
            this IEnumerable<T> enumerable,
            Func<T, object> keySelector,
            params Func<T, object>[] keySelectors)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");
            Assertion.NullArgument(keySelector, "キーセレクタが必要です");

            return enumerable.Distinct(new DelegatedComparer<T>(keySelector, keySelectors));
        }

        /// <summary>
        /// 指定された列挙子の要素を一意化します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">一意化前の列挙子</param>
        /// <param name="keySelector">キーセレクタ</param>
        /// <param name="keySelectors">キーセレクタ群</param>
        /// <returns>一意化後の列挙子</returns>
        public static ParallelQuery<T> Distinct<T>(
            this ParallelQuery<T> enumerable,
            Func<T, object> keySelector,
            params Func<T, object>[] keySelectors)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");
            Assertion.NullArgument(keySelector, "キーセレクタが必要です");

            return enumerable.Distinct(new DelegatedComparer<T>(keySelector, keySelectors));
        }
        #endregion

        #region Union
        /// <summary>
        /// 指定された列挙子の和集合を生成します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">1つ目の列挙子</param>
        /// <param name="second">2つ目の列挙子</param>
        /// <param name="keySelector">キーセレクタ</param>
        /// <param name="keySelectors">キーセレクタ群</param>
        /// <returns>和集合列挙子</returns>
        public static IEnumerable<T> Union<T>(
            this IEnumerable<T> enumerable,
            IEnumerable<T> second,
            Func<T, object> keySelector,
            params Func<T, object>[] keySelectors)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");
            Assertion.NullArgument(second, "列挙子が必要です");
            Assertion.NullArgument(keySelector, "キーセレクタが必要です");

            return enumerable.Union(second, new DelegatedComparer<T>(keySelector, keySelectors));
        }

        /// <summary>
        /// 指定された列挙子の和集合を生成します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">1つ目の列挙子</param>
        /// <param name="second">2つ目の列挙子</param>
        /// <param name="keySelector">キーセレクタ</param>
        /// <param name="keySelectors">キーセレクタ群</param>
        /// <returns>和集合列挙子</returns>
        public static ParallelQuery<T> Union<T>(
            this ParallelQuery<T> enumerable,
            ParallelQuery<T> second,
            Func<T, object> keySelector,
            params Func<T, object>[] keySelectors)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");
            Assertion.NullArgument(keySelector, "キーセレクタが必要です");

            return enumerable.Union(second, new DelegatedComparer<T>(keySelector, keySelectors));
        }
        #endregion

        #region Intersect
        /// <summary>
        /// 指定された列挙子の積集合を生成します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">1つ目の列挙子</param>
        /// <param name="second">2つ目の列挙子</param>
        /// <param name="keySelector">キーセレクタ</param>
        /// <param name="keySelectors">キーセレクタ群</param>
        /// <returns>積集合列挙子</returns>
        public static IEnumerable<T> Intersect<T>(
            this IEnumerable<T> enumerable,
            IEnumerable<T> second,
            Func<T, object> keySelector,
            params Func<T, object>[] keySelectors)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");
            Assertion.NullArgument(second, "列挙子が必要です");
            Assertion.NullArgument(keySelector, "キーセレクタが必要です");

            return enumerable.Intersect(second, new DelegatedComparer<T>(keySelector, keySelectors));
        }

        /// <summary>
        /// 指定された列挙子の積集合を生成します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">1つ目の列挙子</param>
        /// <param name="second">2つ目の列挙子</param>
        /// <param name="keySelector">キーセレクタ</param>
        /// <param name="keySelectors">キーセレクタ群</param>
        /// <returns>積集合列挙子</returns>
        public static ParallelQuery<T> Intersect<T>(
            this ParallelQuery<T> enumerable,
            ParallelQuery<T> second,
            Func<T, object> keySelector,
            params Func<T, object>[] keySelectors)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");
            Assertion.NullArgument(keySelector, "キーセレクタが必要です");

            return enumerable.Intersect(second, new DelegatedComparer<T>(keySelector, keySelectors));
        }
        #endregion

        #region ZeroOrOne
        /// <summary>
        /// 指定されたシーケンスが空か、単一の要素を持っていることを確認します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <returns>空か、又は単一の要素を持っている場合にtrue</returns>
        public static bool ZeroOrOne<T>(this IEnumerable<T> enumerable)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");

            var enumerator = enumerable.GetEnumerator();
            try
            {
                if (enumerator.MoveNext() == false)
                {
                    return true;
                }

                return enumerator.MoveNext() == false;
            }
            finally
            {
                var disposable = enumerator as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
            }
        }
        #endregion

        #region ExtractDuplicate
        /// <summary>
        /// 指定されたシーケンス内の重複する要素を取得します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <returns>重複する要素</returns>
        public static IEnumerable<T> ExtractDuplicate<T>(
            this IEnumerable<T> enumerable)
        {
            return ExtractDuplicate(enumerable, EqualityComparer<T>.Default);
        }

        /// <summary>
        /// 指定されたシーケンス内の重複する要素を取得します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="keySelector">キーセレクタ</param>
        /// <param name="keySelectors">キーセレクタ群</param>
        /// <returns>重複する要素</returns>
        public static IEnumerable<T> ExtractDuplicate<T>(
            this IEnumerable<T> enumerable,
            Func<T, object> keySelector,
            params Func<T, object>[] keySelectors)
        {
            return ExtractDuplicate(enumerable, new DelegatedComparer<T>(keySelector, keySelectors));
        }

        /// <summary>
        /// 指定されたシーケンス内の重複する要素を取得します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>重複する要素</returns>
        public static IEnumerable<T> ExtractDuplicate<T>(
            this IEnumerable<T> enumerable,
            IEqualityComparer<T> comparer)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            var keys = new HashSet<T>(comparer);
            foreach (var entry in
                from value in enumerable
                where keys.Add(value) == false
                select value)
            {
                yield return entry;
            }
        }

        /// <summary>
        /// 指定されたシーケンス内の重複する要素を取得します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <returns>重複する要素</returns>
        public static ParallelQuery<T> ExtractDuplicate<T>(
            this ParallelQuery<T> enumerable)
        {
            return ExtractDuplicate(enumerable, EqualityComparer<T>.Default);
        }

        /// <summary>
        /// 指定されたシーケンス内の重複する要素を取得します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="keySelector">キーセレクタ</param>
        /// <param name="keySelectors">キーセレクタ群</param>
        /// <returns>重複する要素</returns>
        public static ParallelQuery<T> ExtractDuplicate<T>(
            this ParallelQuery<T> enumerable,
            Func<T, object> keySelector,
            params Func<T, object>[] keySelectors)
        {
            return ExtractDuplicate(enumerable, new DelegatedComparer<T>(keySelector, keySelectors));
        }

        /// <summary>
        /// 指定されたシーケンス内の重複する要素を取得します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>重複する要素</returns>
        public static ParallelQuery<T> ExtractDuplicate<T>(
            this ParallelQuery<T> enumerable,
            IEqualityComparer<T> comparer)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");
            Assertion.NullArgument(comparer, "比較演算子が必要です");

            return InternalExtractDuplicate(enumerable, comparer).AsParallel();
        }

        /// <summary>
        /// 指定されたシーケンス内の重複する要素を取得します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="comparer">比較演算子</param>
        /// <returns>重複する要素</returns>
        private static IEnumerable<T> InternalExtractDuplicate<T>(
            this ParallelQuery<T> enumerable,
            IEqualityComparer<T> comparer)
        {
            Assertion.Condition(enumerable != null);
            Assertion.Condition(comparer != null);

            var keys = new ConcurrentDictionary<T, T>(comparer);
            foreach (var entry in
                from value in enumerable
                where keys.TryAdd(value, value) == false
                select value)
            {
                yield return entry;
            }
        }
        #endregion

        #region ToPairs
        /// <summary>
        /// シーケンスを対にしたシーケンスを生成します。
        /// </summary>
        /// <typeparam name="T">シーケンスの型</typeparam>
        /// <param name="enumerable">シーケンス</param>
        /// <returns>対に変換したシーケンス</returns>
        /// <remarks>隣り合った要素値を格納したTupleを返します。
        /// 結果として、シーケンスの要素数は、元のシーケンス-1となります。</remarks>
        public static IEnumerable<Tuple<T, T>> ToPairs<T>(this IEnumerable<T> enumerable)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");

            var enumerator = enumerable.GetEnumerator();
            try
            {
                if (enumerator.MoveNext() == true)
                {
                    T lastValue = enumerator.Current;
                    while (enumerator.MoveNext() == true)
                    {
                        yield return Tuple.Create(lastValue, enumerator.Current);
                        lastValue = enumerator.Current;
                    }
                }
            }
            finally
            {
                var disposable = enumerator as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
            }
        }
        #endregion

        #region AsQueueing
        /// <summary>
        /// 指定された列挙子を非同期で列挙します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="maxQueueCount">キューの最大要素数</param>
        /// <returns>非同期分離された列挙子</returns>
        public static IEnumerable<T> AsQueueing<T>(this IEnumerable<T> enumerable, int maxQueueCount)
        {
            using (var queue = new BlockingCollection<T>(maxQueueCount))
            {
                Exception ex = null;
                var thread = new Thread(
                    () =>
                    {
                        try
                        {
                            foreach (var value in enumerable)
                            {
                                queue.Add(value);
                            }
                        }
                        catch (Exception ex2)
                        {
                            ex = ex2;
                        }
                        finally
                        {
                            try
                            {
                                queue.CompleteAdding();
                            }
                            catch
                            {
                            }
                        }
                    });
                thread.Start();

                using (var queueEnumerator = queue.GetConsumingEnumerable().GetEnumerator())
                {
                    while (true)
                    {
                        var available = false;
                        try
                        {
                            available = queueEnumerator.MoveNext();
                        }
                        catch (OperationCanceledException)
                        {
                        }

                        if (available == false)
                        {
                            break;
                        }

                        yield return queueEnumerator.Current;
                    }
                }

                if (ex != null)
                {
                    if ((ex is AggregateException) || (ex is TargetInvocationException))
                    {
                        throw ex;
                    }

                    throw new TargetInvocationException(ex);
                }
            }
        }
        #endregion
    }
}

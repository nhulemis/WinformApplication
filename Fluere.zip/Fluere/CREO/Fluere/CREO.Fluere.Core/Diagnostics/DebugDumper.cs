﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.03.15 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Xml;
using CREO.Fluere.Common.Configuration;
using CREO.Fluere.Common.Executive;

namespace CREO.Fluere.Common.Diagnostics
{
    /// <summary>
    /// デバッグ用にXMLを出力するクラスです。
    /// </summary>
    public static class DebugDumper
    {
        #region Fields
        /// <summary>
        /// 空のオブジェクト
        /// </summary>
        private static readonly object[] _empty = new object[0];

        /// <summary>
        /// DumpBasePath
        /// </summary>
        private static readonly Uri _dumpBasePath =
            new Uri(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), @"Dumps\"));
        #endregion

        #region IsDumpRequired
        /// <summary>
        /// DebugDump値
        /// </summary>
        public static bool IsDumpRequired
        {
            get
            {
                return AppSettingsAccessor.GetValue("DebugDump", false);
            }
        }
        #endregion

        #region RecursiveOutput
        /// <summary>
        /// 再帰的にインスタンスを出力します。
        /// </summary>
        /// <param name="writer">XmlWriter</param>
        /// <param name="value">オブジェクト</param>
        private static void RecursiveOutput(XmlWriter writer, object value)
        {
            if (value == null)
            {
                return;
            }

            var type = value.GetType();
            if (type.IsPrimitive || (type == typeof(string)))
            {
                var valueString = Convert.ToString(value, CultureInfo.InvariantCulture);
                writer.WriteValue(valueString);
            }
            else if (typeof(IEnumerable).IsAssignableFrom(type) == true)
            {
                foreach (var element in (IEnumerable)value)
                {
                    var elementType = element.GetType();
                    var typeName = (elementType.Name.StartsWith("<>") && elementType.Name.Contains("Anonymous")) ?
                        "Anonymous" : elementType.Name.Replace("`", string.Empty);

                    writer.WriteStartElement(typeName);
                    RecursiveOutput(writer, element);
                    writer.WriteEndElement();
                }
            }
            else
            {
                foreach (var fi in type.GetFields())
                {
                    if (fi.IsStatic == true)
                    {
                        continue;
                    }

                    var innerValue = fi.GetValue(value);
                    if (innerValue == null)
                    {
                        writer.WriteStartAttribute(fi.Name);
                        writer.WriteEndAttribute();
                    }
                    else
                    {
                        var innerType = innerValue.GetType();
                        if (innerType.IsPrimitive || (innerType == typeof(string)))
                        {
                            writer.WriteStartAttribute(fi.Name);
                            RecursiveOutput(writer, innerValue);
                            writer.WriteEndAttribute();
                        }
                    }
                }

                foreach (var pi in type.GetProperties())
                {
                    if ((pi.CanRead == false) || (pi.GetIndexParameters().Length >= 1))
                    {
                        continue;
                    }

                    if (pi.GetGetMethod().IsStatic == true)
                    {
                        continue;
                    }

                    var innerValue = pi.GetValue(value, _empty);
                    if (innerValue == null)
                    {
                        writer.WriteStartAttribute(pi.Name);
                        writer.WriteEndAttribute();
                    }
                    else
                    {
                        var innerType = innerValue.GetType();
                        if (innerType.IsPrimitive || (innerType == typeof(string)))
                        {
                            writer.WriteStartAttribute(pi.Name);
                            RecursiveOutput(writer, innerValue);
                            writer.WriteEndAttribute();
                        }
                    }
                }

                foreach (var fi in type.GetFields())
                {
                    if (fi.IsStatic == true)
                    {
                        continue;
                    }

                    var innerValue = fi.GetValue(value);
                    if (innerValue != null)
                    {
                        var innerType = innerValue.GetType();
                        if (innerType.IsPrimitive || (innerType == typeof(string)))
                        {
                        }
                        else
                        {
                            writer.WriteStartElement(fi.Name);
                            RecursiveOutput(writer, innerValue);
                            writer.WriteEndElement();
                        }
                    }
                }

                foreach (var pi in type.GetProperties())
                {
                    if ((pi.CanRead == false) || (pi.GetIndexParameters().Length >= 1))
                    {
                        continue;
                    }

                    if (pi.GetGetMethod().IsStatic == true)
                    {
                        continue;
                    }

                    var innerValue = pi.GetValue(value, _empty);
                    if (innerValue != null)
                    {
                        var innerType = innerValue.GetType();
                        if (innerType.IsPrimitive || (innerType == typeof(string)))
                        {
                        }
                        else
                        {
                            writer.WriteStartElement(pi.Name);
                            RecursiveOutput(writer, innerValue);
                            writer.WriteEndElement();
                        }
                    }
                }
            }
        }
        #endregion

        #region InternalDump
        /// <summary>
        /// 列挙子を出力します。
        /// </summary>
        /// <typeparam name="T">列挙子の要素型</typeparam>
        /// <param name="enumerable">処理前の列挙子</param>
        /// <param name="path">出力先のファイル名</param>
        /// <returns>処理後の列挙子</returns>
        private static IEnumerable<T> InternalDump<T>(this IEnumerable<T> enumerable, string path)
        {
            var finished = false;
            try
            {
                var realPath = Path.Combine(
                    Path.GetDirectoryName(path),
                    Path.GetFileNameWithoutExtension(path) + string.Format("_{0:yyyyMMdd_HHmmss}{1}", DateTime.Now, Path.GetExtension(path)));
                var uri = new Uri(_dumpBasePath, realPath);
                realPath = uri.LocalPath;

                var directoryName = Path.GetDirectoryName(realPath);
                if (Directory.Exists(directoryName) == false)
                {
                    Directory.CreateDirectory(directoryName);
                }

                using (var stream = new FileStream(realPath, FileMode.Create, FileAccess.ReadWrite, FileShare.Read))
                {
                    var settings = new XmlWriterSettings();
                    settings.Indent = true;
                    settings.IndentChars = "\t";
                    var writer = XmlWriter.Create(stream, settings);

                    var type = typeof(T);
                    var typeName = (type.Name.StartsWith("<>") && type.Name.Contains("Anonymous")) ?
                        "Anonymous" : type.Name.Replace("`", string.Empty);

                    writer.WriteStartElement(typeName + (typeName.EndsWith("s") ? "es" : "s"));

                    foreach (var value in enumerable)
                    {
                        writer.WriteStartElement(typeName);
                        RecursiveOutput(writer, value);
                        writer.WriteEndElement();

                        yield return value;
                    }

                    writer.WriteEndElement();

                    writer.Flush();
                    stream.Close();

                    InternalLogger.Logger.WriteDebugLog("Debug data dumped: \"{0}\"", realPath);
                }

                finished = true;
            }
            finally
            {
                if (finished == false)
                {
                    File.Delete(path);
                }
            }
        }
        #endregion

        #region Dump
        /// <summary>
        /// 列挙子を出力します。
        /// </summary>
        /// <typeparam name="T">列挙子の要素型</typeparam>
        /// <param name="enumerable">処理前の列挙子</param>
        /// <param name="name">出力先のファイル名</param>
        /// <returns>処理後の列挙子</returns>
        public static IEnumerable<T> Dump<T>(this IEnumerable<T> enumerable, string name)
        {
            if (IsDumpRequired == true)
            {
                return InternalDump(enumerable, CreateDumpFileName(name));
            }

            return enumerable;
        }
        #endregion

        #region DumpAsDebug
        /// <summary>
        /// デバッグビルド時に列挙子を出力します。
        /// </summary>
        /// <typeparam name="T">列挙子の要素型</typeparam>
        /// <param name="enumerable">処理前の列挙子</param>
        /// <param name="name">出力先のファイル名</param>
        /// <returns>処理後の列挙子</returns>
        public static IEnumerable<T> DumpAsDebug<T>(this IEnumerable<T> enumerable, string name)
        {
#if DEBUG
            return InternalDump(enumerable, CreateDumpFileName(name));
#else
            return enumerable;
#endif
        }
        #endregion

        #region CreateDumpFileName
        /// <summary>
        /// ダンプファイル名を取得します。
        /// </summary>
        /// <param name="name">ファイル名</param>
        /// <returns>ダンプファイル名</returns>
        public static string CreateDumpFileName(string name)
        {
            return string.Format("Dump_{0}.xml", name);
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.19 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースの内部情報インターフェイスです。
    /// </summary>
    /// <remarks>このインターフェイスは内部で使用します。
    /// ターゲットプロバイダは、このインターフェイスから得られる情報を、
    /// 前方参照カーソル・前方方向ライタ動作のヒントとして使用する事が出来ます。</remarks>
    internal interface IInternalDataSourceInformation
    {
        /// <summary>
        /// このコンテキストのターゲット名を取得します。
        /// </summary>
        /// <remarks>ターゲット名はnullの可能性があります。</remarks>
        string TargetName
        {
            get;
        }

        /// <summary>
        /// このコンテキストが変換の対象とするインターフェイス型を取得します。
        /// </summary>
        Type TargetType
        {
            get;
        }

        /// <summary>
        /// コンテキストから取得可能な生のフィールド情報群を取得します。
        /// </summary>
        /// <remarks>メタデータで定義されたフィールド情報群を取得します。
        /// メタデータが供給されない場合、空の配列が返されることがあります。</remarks>
        ITargetFieldInformation[] MetadataFieldInformations
        {
            get;
        }
    }
}

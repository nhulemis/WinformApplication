﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// ターゲットを抽象化したデータソースの基底コンテキストクラスです。
    /// </summary>
    /// <typeparam name="T">列挙子の型</typeparam>
    /// <remarks>このクラスは内部で使用します。
    /// ITargetAccessProviderインターフェイスで供給されるカーソル等を使用して、
    /// インスタンスの入出力をサポートします。</remarks>
    internal abstract class TargetContextBase<T> : IDataSourceContextBase, IInternalDataSourceInformation, IEnumerable<T>
        where T : class
    {
        #region Fields
        /// <summary>
        /// プロバイダ
        /// </summary>
        private readonly ITargetAccessProvider _provider;

        /// <summary>
        /// ターゲット名
        /// </summary>
        private readonly string _targetName;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="provider">プロバイダ</param>
        /// <param name="targetName">ターゲット名</param>
        /// <remarks>ターゲット名はnullの可能性があります。</remarks>
        protected TargetContextBase(ITargetAccessProvider provider, string targetName)
        {
            Assertion.Condition(provider != null);

            this._provider = provider;
            this._targetName = targetName;
        }
        #endregion

        #region TargetType
        /// <summary>
        /// このシリアライザが変換の対象とするインターフェイス型を取得します。
        /// </summary>
        public Type TargetType
        {
            get
            {
                return typeof(T);
            }
        }
        #endregion

        #region TargetName
        /// <summary>
        /// このコンテキストのターゲット名を取得します。
        /// </summary>
        /// <remarks>ターゲット名はnullの可能性があります。</remarks>
        public string TargetName
        {
            get
            {
                return this._targetName;
            }
        }
        #endregion

        #region FieldNames
        /// <summary>
        /// フィールド名群を取得します。
        /// </summary>
        [Obsolete("代わりにFieldInformationsを使用します")]
        public string[] FieldNames
        {
            get
            {
                return this.FieldInformations.Select(fi => fi.FieldName).ToArray();
            }
        }
        #endregion

        #region FieldInformations
        /// <summary>
        /// コンテキストから取得可能なフィールド情報群を取得します。
        /// </summary>
        public abstract ITargetFieldInformation[] FieldInformations
        {
            get;
        }
        #endregion

        #region RawFieldInformations
        /// <summary>
        /// コンテキストから取得可能な生のフィールド情報群を取得します。
        /// </summary>
        public abstract ITargetFieldInformation[] MetadataFieldInformations
        {
            get;
        }
        #endregion

        #region CreateForwardCursor
        /// <summary>
        /// 前方参照カーソルを生成します。
        /// </summary>
        /// <returns>前方参照カーソル</returns>
        protected IDataSourceForwardCursor CreateForwardCursor()
        {
            return this._provider.CreateForwardCursor(this);
        }
        #endregion

        #region CreateForwardWriter
        /// <summary>
        /// 前方方向ライタを生成します。
        /// </summary>
        /// <param name="fieldNames">フィールド名群</param>
        /// <returns>前方方向ライタ</returns>
        protected IDataSourceForwardWriter CreateForwardWriter(string[] fieldNames)
        {
            return this._provider.CreateForwardWriter(this, fieldNames);
        }
        #endregion

        #region GetEnumerator
        /// <summary>
        /// 列挙子を生成します。
        /// </summary>
        /// <returns>列挙子</returns>
        public abstract IEnumerator<T> GetEnumerator();

        /// <summary>
        /// 列挙子を生成します。
        /// </summary>
        /// <returns>列挙子</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion
    }
}

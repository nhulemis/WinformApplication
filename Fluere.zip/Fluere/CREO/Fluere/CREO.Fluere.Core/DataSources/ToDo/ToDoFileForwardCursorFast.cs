﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.18 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoファイルアクセサから前方参照カーソルを生成するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class ToDoFileForwardCursorFast : IDataSourceForwardCursor
    {
        #region Fields
        /// <summary>
        /// フィールド名群
        /// </summary>
        private readonly string[] _fieldNames;

        /// <summary>
        /// テンポラリバッファ
        /// </summary>
        private readonly object[] _values;

        /// <summary>
        /// XmlReader
        /// </summary>
        private XmlReader _reader;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="stream">ストリーム</param>
        /// <param name="bufferSize">バッファサイズ</param>
        public ToDoFileForwardCursorFast(Stream stream, int bufferSize)
        {
            Assertion.Condition(stream != null);
            Assertion.Condition(bufferSize >= 4096);

            var bufferedStream = new BufferedStream(stream, bufferSize);

            var settings = new XmlReaderSettings();
            settings.CloseInput = true;
            settings.IgnoreComments = true;
            settings.IgnoreWhitespace = true;

            this._reader = XmlReader.Create(bufferedStream, settings);

            var fieldNameList = new List<string>();
            if (this._reader.ReadToFollowing("Data") == true)
            {
                if (this._reader.ReadToFollowing("HeaderList") == true)
                {
                    while (this._reader.Read() == true)
                    {
                        if (this._reader.NodeType == XmlNodeType.EndElement)
                        {
                            break;
                        }

                        if (this._reader.Name == "HeaderDetails")
                        {
                            // 一項目読み取る
                            var fieldName = this._reader.GetAttribute("FieldName");
                            fieldNameList.Add(fieldName);
                        }
                    }
                }

                this._reader.ReadToFollowing("DataList");
            }

            this._fieldNames = fieldNameList.ToArray();
            this._values = new object[this._fieldNames.Length];
        }
        #endregion

        #region FieldNames
        /// <summary>
        /// フィールド名群を取得します
        /// </summary>
        public string[] FieldNames
        {
            get
            {
                return this._fieldNames;
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            if (this._reader != null)
            {
                this._reader.Close();
                ((IDisposable)this._reader).Dispose();
                this._reader = null;
            }
        }
        #endregion

        #region Read
        /// <summary>
        /// データを1レコード分読み取ります。
        /// </summary>
        /// <param name="values">読み取ったデータを格納する配列</param>
        /// <returns>読み取った場合はtrue</returns>
        public bool Read(out object[] values)
        {
            // From IDataSourceForwardCursor:
            //   このメソッドを実装する場合、返却する配列は実際のフィールド数によって、以下のように振る舞う事を想定して下さい。
            //   ・返却するデータ数が不足する場合は、不足分のプロパティに値がセットされません。
            //   ・返却するデータ数が過剰の場合は、過剰分が無視されます。
            //   この動作は、IPropertyValueAccessor.SetValuesメソッドの既定の実装によって行われます。
            if (this._reader == null)
            {
                values = null;
                return false;
            }

            if (this._reader.ReadToFollowing("DataDetails") == false)
            {
                values = null;
                return false;
            }

            for (var index = 0; index < this._fieldNames.Length; index++)
            {
                var fieldName = this._fieldNames[index];
                var attribute = this._reader.GetAttribute(fieldName);
                this._values[index] = string.IsNullOrWhiteSpace(attribute) ? null : attribute;
            }

            values = this._values;
            return true;
        }
        #endregion
    }
}

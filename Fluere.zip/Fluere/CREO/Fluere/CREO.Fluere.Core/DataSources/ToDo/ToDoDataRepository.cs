﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.11 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

using CREO.Fluere.Common.DataSources.Linq;
using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.IO;

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoファイルを対象とするリポジトリクラスです。
    /// </summary>
    /// <remarks>ToDoファイルを操作するための共通のインターフェイスを提供します。</remarks>
    public sealed class ToDoDataRepository : IDataSourceRepository, ITargetAccessProvider
    {
        #region Fields
        /// <summary>
        /// フォルダ又はファイルへのパスです。
        /// </summary>
        private readonly string _path;

        /// <summary>
        /// 変換に使用するカルチャ情報です。
        /// </summary>
        private readonly CultureInfo _cultureInfo;

        /// <summary>
        /// バッファサイズを示します。
        /// </summary>
        private readonly int _bufferSize;

        /// <summary>
        /// フォーマットファイル名です。(I.Yoshimi)
        /// </summary>
        private string _formatFileName;

        /// <summary>
        /// トランザクションが管理するフォルダへのパスです。
        /// </summary>
        private string _targetFolderPath;

        /// <summary>
        /// トランザクションコンテキストを保持します。
        /// </summary>
        private IFileSystemTransactionContext _transactionContext;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="path">対象のフォルダ又はファイルパス</param>
        /// <param name="cultureInfo">変換に使用するカルチャ情報</param>
        /// <param name="bufferSize">バッファサイズ</param>
        /// <remarks>フォルダを指定した場合は、コンテキスト取得時にファイルへの相対パス又は絶対パスを指定出来ます。
        /// ファイルを指定した場合は、コンテキスト取得時にファイルへのパスを省略する事が出来ます。</remarks>
        public ToDoDataRepository(string path, CultureInfo cultureInfo, int bufferSize)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(path) == false, "フォルダ又はファイルへのパスが必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");
            Assertion.Argument(bufferSize >= 4096, "バッファサイズは4096バイト以上必要です");

            this._path = path;
            this._cultureInfo = cultureInfo;
            this._bufferSize = bufferSize;
        }
        #endregion

        #region FormatFileName
        /// <summary>
        /// フォーマットファイル名を設定・取得します。(I.Yoshimi)
        /// </summary>
        public string FormatFileName
        {
            get
            {
                return this._formatFileName;
            }

            set
            {
                _formatFileName = value;
            }
        }
        #endregion

        #region Location
        /// <summary>
        /// リポジトリの場所を示す文字列を取得します。
        /// </summary>
        public string Location
        {
            get
            {
                return this._path;
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (this._transactionContext != null)
                {
                    this._transactionContext.Dispose();
                    this._transactionContext = null;
                    this._targetFolderPath = null;
                }
            }
        }
        #endregion

        #region Open
        /// <summary>
        /// リポジトリをオープンします。
        /// </summary>
        public void Open()
        {
            lock (this)
            {
                Assertion.Require(this._transactionContext == null, "二回オープンしようとしました");

                this._transactionContext = FileSystemTransactionContextFactory.CreateContext();
            }
        }
        #endregion

        #region Commit
        /// <summary>
        /// コミットします。
        /// </summary>
        public void Commit()
        {
            lock (this)
            {
                if (this._transactionContext != null)
                {
                    this._transactionContext.Commit();
                    this._transactionContext = null;
                    this._targetFolderPath = null;
                }
            }
        }
        #endregion

        #region GetToDoFormatIdentity
        /// <summary>
        /// 指定されたインターフェイス型に定義されている、ToDoフォーマット識別子を取得します。
        /// </summary>
        /// <param name="type">インターフェイス型</param>
        /// <returns>ToDoフォーマットの識別子</returns>
        internal static string GetToDoFormatIdentity(Type type)
        {
            Assertion.Condition(type != null);
            Assertion.Condition(type.IsInterface == true);

            var attributes = (ToDoFormatIdentityAttribute[])
                type.GetCustomAttributes(typeof(ToDoFormatIdentityAttribute), false);

            return (attributes.Length >= 1) ? attributes[0].FormatIdentity : null;
        }
        #endregion

        #region Target
        /// <summary>
        /// このリポジトリが管理するデータソースのターゲット名を指定して、コンテキストとなるLINQソースを取得します。
        /// </summary>
        /// <typeparam name="T">LINQソースに関連付けるインターフェイス型</typeparam>
        /// <param name="targetName">ターゲット名</param>
        /// <returns>コンテキストとなるLINQソース</returns>
        /// <remarks>このメソッドから得られるLINQソースは、対象のデータを何度でも読み直す事が出来ます。</remarks>
        public IDataSourceContext<T> Target<T>(string targetName)
            where T : class
        {
            Assertion.Argument(typeof(T).IsInterface == true, "インターフェイス型が必要です");

            var formatIdentity = GetToDoFormatIdentity(typeof(T));

            return new ToDoTargetContext<T>(this, targetName, this._cultureInfo, formatIdentity);
        }
        #endregion

        #region StoreTo
        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <typeparam name="T">LINQソースに関連付けるインターフェイス型</typeparam>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        /// <param name="targetName">ターゲット名</param>
        /// <remarks>出力フォーマットがT型のインターフェイスで型付けされる場合は、このメソッドを使用する事で、
        /// コンテキストを取得することなく直接レコード群を出力出来ます。</remarks>
        public void StoreTo<T>(IEnumerable<T> enumerable, string targetName)
            where T : class
        {
            this.Target<T>(targetName).Store(enumerable);
        }
        #endregion

        #region CreateStorer
        /// <summary>
        /// 逐次出力を行うインターフェイスを生成します。
        /// </summary>
        /// <typeparam name="T">関連付けるインターフェイス型</typeparam>
        /// <param name="targetName">ターゲット名</param>
        /// <returns>逐次出力インターフェイス</returns>
        public IDataSourceStorer<T> CreateStorer<T>(string targetName)
            where T : class
        {
            Assertion.Argument(typeof(T).IsInterface == true, "インターフェイス型が必要です");

            var formatIdentity = GetToDoFormatIdentity(typeof(T));

            return new ToDoTargetStorer<T>(this, targetName, this._cultureInfo, formatIdentity);
        }
        #endregion

        #region ITargetAccessProvider
        /// <summary>
        /// 指定された内部情報を使用して、前方参照カーソルを生成します。
        /// </summary>
        /// <param name="information">内部情報</param>
        /// <returns>前方参照カーソル</returns>
        IDataSourceForwardCursor ITargetAccessProvider.CreateForwardCursor(
            IInternalDataSourceInformation information)
        {
            Assertion.Condition(information is IToDoDataInformation);

            Assertion.Require(this._transactionContext != null, "オープンしていません");

            var toDoContext = (IToDoDataInformation)information;

            // 正規化されたパスを取得する
            var fullPath = DataSourceUtility.GetRecalculatedNormalizedPath(this._path, toDoContext.TargetName);

            lock (this)
            {
                if (this._targetFolderPath == null)
                {
                    // フォルダを生成
                    var folderPath = Path.GetDirectoryName(fullPath);
                    this._targetFolderPath = this._transactionContext.CreateDirectory(folderPath);
                }
            }

            var targetPath = Path.Combine(this._targetFolderPath, Path.GetFileName(fullPath));

            // ToDoフォーマット識別子を取得する
            var formatIdentity = toDoContext.FormatIdentity;

            if (formatIdentity != null)
            {
                return new ToDoFileForwardCursor(targetPath, formatIdentity);
            }
            else
            {
                var stream = this._transactionContext.CreateStream(targetPath, FileMode.Open, FileAccess.Read);
                return new ToDoFileForwardCursorFast(stream, this._bufferSize);
            }
        }

        /// <summary>
        /// 指定された内部情報を使用して、前方方向ライタを生成します。
        /// </summary>
        /// <param name="information">内部情報</param>
        /// <param name="fieldNames">フィールド名を出力する場合のフィールド名群</param>
        /// <returns>前方方向ライタ</returns>
        IDataSourceForwardWriter ITargetAccessProvider.CreateForwardWriter(
            IInternalDataSourceInformation information,
            string[] fieldNames)
        {
            Assertion.Condition(information is IToDoDataInformation);
            Assertion.Condition(fieldNames != null);

            Assertion.Require(this._transactionContext != null, "オープンしていません");

            var toDoContext = (IToDoDataInformation)information;

            // 正規化されたパスを取得する
            var fullPath = DataSourceUtility.GetRecalculatedNormalizedPath(this._path, toDoContext.TargetName);

            lock (this)
            {
                if (this._targetFolderPath == null)
                {
                    // フォルダを生成
                    var folderPath = Path.GetDirectoryName(fullPath);
                    this._targetFolderPath = this._transactionContext.CreateDirectory(folderPath);
                }
            }

            var targetPath = Path.Combine(this._targetFolderPath, Path.GetFileName(fullPath));

            // ToDoフォーマット識別子を取得する
            var formatIdentity = toDoContext.FormatIdentity;

            // ToDoフォーマットファイル名を取得する I.Yoshimi
            var formatFileName = this._formatFileName;

            if (formatFileName != null)
            {
                var writer = new ToDoFileForwardWriter(targetPath, formatIdentity, formatFileName, this._cultureInfo);

                // 擬似トランザクションの場合、ストリームが必要なので、トランザクションの追従が出来ない
                this._transactionContext.TrackFilePath(targetPath);

                return writer;
            }
            else if (formatIdentity != null)
            {
                // I.Yoshimi
                var writer = new ToDoFileForwardWriter(targetPath, formatIdentity, null, this._cultureInfo);

                // 擬似トランザクションの場合、ストリームが必要なので、トランザクションの追従が出来ない
                this._transactionContext.TrackFilePath(targetPath);

                return writer;
            }
            else
            {
                var stream = this._transactionContext.CreateStream(targetPath, FileMode.Create, FileAccess.ReadWrite);
                return new ToDoFileForwardWriterFast(stream, this._bufferSize, this._cultureInfo, information, fieldNames);
            }
        }
        #endregion
    }
}

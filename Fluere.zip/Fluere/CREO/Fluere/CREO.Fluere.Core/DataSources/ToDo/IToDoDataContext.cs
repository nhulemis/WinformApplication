﻿namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoターゲットコンテキストのインターフェイスです。
    /// </summary>
    /// <remarks>このインターフェイスは内部で使用します。</remarks>
    internal interface IToDoDataContext : IDataSourceContextBase
    {
        /// <summary>
        /// フォーマット識別子を取得します。
        /// </summary>
        string FormatIdentity
        {
            get;
        }
    }
}

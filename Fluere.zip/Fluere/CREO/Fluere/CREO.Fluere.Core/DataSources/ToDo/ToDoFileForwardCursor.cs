﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.18 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using CREO.BusiComm.ToDoFile;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoファイルアクセサから前方参照カーソルを生成するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class ToDoFileForwardCursor : IDataSourceForwardCursor
    {
        #region Fields
        /// <summary>
        /// フィールド名群
        /// </summary>
        private readonly string[] _fieldNames;

        /// <summary>
        /// CommToDoReadWriter
        /// </summary>
        private CommToDoReadWriter _reader;

        /// <summary>
        /// LINQ to XML列挙子
        /// </summary>
        private IEnumerator<XElement> _enumerator;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="path">パス</param>
        /// <param name="formatIdentity">フォーマット識別子</param>
        public ToDoFileForwardCursor(string path, string formatIdentity)
        {
            Assertion.Condition(path != null);
            Assertion.Condition(formatIdentity != null);

            // 出力する場合と異なり、読み取る方はフォーマット識別子（フォーマット定義体）が不要。
            this._reader = new CommToDoReadWriter(path, true, false);

            // ヘッダーレコードを取得する
            this._fieldNames =
                (from headerElement in this._reader.GetHeaders()
                 from headerAttribute in headerElement.Attributes()
                 where headerAttribute.Name.LocalName == "FieldName"
                 select headerAttribute.Value).ToArray();

            // データを読み取る
            this._enumerator = _reader.GetDatas().GetEnumerator();
        }
        #endregion

        #region FieldNames
        /// <summary>
        /// フィールド名群を取得します
        /// </summary>
        public string[] FieldNames
        {
            get
            {
                return this._fieldNames;
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            if (_enumerator != null)
            {
                var disposable = this._enumerator as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }

                this._enumerator = null;
            }

            if (this._reader != null)
            {
                this._reader.Dispose();
                this._reader = null;
            }
        }
        #endregion

        #region Read
        /// <summary>
        /// データを1レコード分読み取ります。
        /// </summary>
        /// <param name="values">読み取ったデータを格納する配列</param>
        /// <returns>読み取った場合はtrue</returns>
        public bool Read(out object[] values)
        {
            // From IDataSourceForwardCursor:
            //   このメソッドを実装する場合、返却する配列は実際のフィールド数によって、以下のように振る舞う事を想定して下さい。
            //   ・返却するデータ数が不足する場合は、不足分のプロパティに値がセットされません。
            //   ・返却するデータ数が過剰の場合は、過剰分が無視されます。
            //   この動作は、IPropertyValueAccessor.SetValuesメソッドの既定の実装によって行われます。
            if (this._enumerator == null)
            {
                values = null;
                return false;
            }

            if (this._enumerator.MoveNext() == false)
            {
                var disposable = _enumerator as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }

                this._enumerator = null;
                values = null;
                return false;
            }

            values =
                (from fieldName in this._fieldNames
                 let attribute = this._enumerator.Current.Attribute(fieldName)
                 select (attribute != null) ? attribute.Value : null).ToArray();

            return true;
        }
        #endregion
    }
}

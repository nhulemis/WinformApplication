﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.18 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.IO;
using System.Xml;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoファイルアクセサから前方方向ライタを生成するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class ToDoFileForwardWriterFast : IDataSourceForwardWriter
    {
        #region Fields
        /// <summary>
        /// カルチャ情報
        /// </summary>
        private readonly CultureInfo _cultureInfo;

        /// <summary>
        /// フィールド名群
        /// </summary>
        private readonly string[] _fieldNames;

        /// <summary>
        /// XmlWriter
        /// </summary>
        private XmlWriter _writer;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="stream">ストリーム</param>
        /// <param name="bufferSize">バッファサイズ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="information">内部情報</param>
        /// <param name="fieldNames">フィールド名群</param>
        public ToDoFileForwardWriterFast(
            Stream stream,
            int bufferSize,
            CultureInfo cultureInfo,
            IInternalDataSourceInformation information,
            string[] fieldNames)
        {
            Assertion.Condition(stream != null);
            Assertion.Condition(bufferSize >= 4096);
            Assertion.Condition(cultureInfo != null);
            Assertion.Condition(information != null);
            Assertion.Condition(fieldNames != null);

            this._cultureInfo = cultureInfo;
            this._fieldNames = fieldNames;

            var bufferedStream = new BufferedStream(stream, bufferSize);

            var settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "  ";
            settings.CloseOutput = true;
            this._writer = XmlWriter.Create(bufferedStream, settings);

            this._writer.WriteStartDocument();
            this._writer.WriteStartElement("Data");

            this._writer.WriteStartElement("HeaderList");
            if (information.MetadataFieldInformations.Length >= 1)
            {
                for (var index = 0; index < information.MetadataFieldInformations.Length; index++)
                {
                    this._writer.WriteStartElement("HeaderDetails");

                    this._writer.WriteAttributeString("FieldName", this._fieldNames[index]);

                    string description = null;
                    var readOnly = true;
                    var visibility = true;
                    var fixedColumn = true;

                    var dataAttributes =
                        information.MetadataFieldInformations[index].GetCustomAttributes<DataFieldAttribute>();
                    if (dataAttributes.Length >= 1)
                    {
                        description = dataAttributes[0].Description;
                        readOnly = dataAttributes[0].IsReadOnly;
                        visibility = dataAttributes[0].IsVisible;
                        fixedColumn = dataAttributes[0].IsFixedColumn;
                    }
                    else
                    {
                        var descriptions =
                            information.MetadataFieldInformations[index].GetCustomAttributes<DescriptionAttribute>();
                        if (descriptions.Length >= 1)
                        {
                            description = descriptions[0].Description;
                        }
                    }

                    this._writer.WriteAttributeString(
                        "TitleName",
                        string.IsNullOrWhiteSpace(description) ? this._fieldNames[index] : description);

                    this._writer.WriteAttributeString("ReadOnly", readOnly ? "true" : "false");
                    this._writer.WriteAttributeString("Visibility", visibility ? "true" : "false");
                    this._writer.WriteAttributeString("FixedColumnFlag", fixedColumn ? "true" : "false");

                    this._writer.WriteEndElement();
                }
            }
            else
            {
                this._writer.WriteComment(
                    "Warning: No metadata description, use Target<T> method or add format identity by option argument.");

                for (var index = 0; index < this._fieldNames.Length; index++)
                {
                    this._writer.WriteStartElement("HeaderDetails");

                    this._writer.WriteAttributeString("FieldName", this._fieldNames[index]);
                    this._writer.WriteAttributeString("TitleName", this._fieldNames[index]);
                    this._writer.WriteAttributeString("ReadOnly", "false");
                    this._writer.WriteAttributeString("Visibility", "true");
                    this._writer.WriteAttributeString("FixedColumnFlag", "true");

                    this._writer.WriteEndElement();
                }
            }

            this._writer.WriteEndElement();

            this._writer.WriteStartElement("DataList");
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            if (this._writer != null)
            {
                this._writer.WriteEndElement(); // DataList
                this._writer.WriteEndElement(); // Data
                this._writer.WriteEndDocument();

                // 仮に異常によって出力を中断した場合、出力途中の（生成された）ファイルを復元するのは
                // トランザクションコンテキストの役割であるので、ここではとにかく出力を完了させる。
                this._writer.Flush();
                this._writer.Close();
                ((IDisposable)this._writer).Dispose();
                this._writer = null;
            }
        }
        #endregion

        #region Flush
        /// <summary>
        /// データをフラッシュします。
        /// </summary>
        public void Flush()
        {
        }
        #endregion

        #region Write
        /// <summary>
        /// 指定された値群を出力します。
        /// </summary>
        /// <param name="values">値群</param>
        public void Write(IList<object> values)
        {
            Assertion.Condition(values != null);
            Assertion.Condition(this._writer != null);

            this._writer.WriteStartElement("DataDetails");

            for (int index = 0, count = (values.Count < this._fieldNames.Length) ? values.Count : this._fieldNames.Length;
                index < count;
                index++)
            {
                var value = values[index];
                var stringValue = (value != null) ? Convert.ToString(value, this._cultureInfo) : string.Empty;

                this._writer.WriteAttributeString(this._fieldNames[index], stringValue);
            }

            this._writer.WriteEndElement();
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.18 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml.Linq;

using CREO.BusiComm.ToDoFile;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoファイルアクセサから前方方向ライタを生成するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class ToDoFileForwardWriter : IDataSourceForwardWriter
    {
        #region Fields
        /// <summary>
        /// カルチャ情報
        /// </summary>
        private readonly CultureInfo _cultureInfo;

        /// <summary>
        /// フィールド名群
        /// </summary>
        private readonly string[] _fieldNames;

        /// <summary>
        /// CommToDoWriter
        /// </summary>
        private CommToDoWriter _writer;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="path">パス</param>
        /// <param name="formatIdentity">フォーマット識別子</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        public ToDoFileForwardWriter(
            string path,
            string formatIdentity,
            CultureInfo cultureInfo)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(path) == false);
            Assertion.Condition(formatIdentity != null);
            Assertion.Condition(cultureInfo != null);

            this._cultureInfo = cultureInfo;

            // CREO.Fluere.configファイルから、ToDoファイルの雛形ファイル名を取得する
            var tag = "/configuration/ToDoFormatFile";
            var toDoFormatFiles =
                CREO.FW.Utilities.ProfileUtility.GetXElement(
                    CREO.FW.Utilities.ProfileUtility.ProfileTypeEnum.PersonalProfile,
                    tag);

            Assertion.Require<DataSourceException>(
                toDoFormatFiles != null,
                "ToDoフォーマット定義体が見つかりません: 識別子={0}",
                formatIdentity);

            var todoPath =
                (from name in toDoFormatFiles.Elements("file")
                 where name.Attribute("name").Value == formatIdentity
                 select name.Attribute("path").Value).FirstOrDefault();

            Assertion.Require<DataSourceException>(
                string.IsNullOrEmpty(todoPath) == false,
                "ノード[{0}]内に指定された属性[name={1}]が見つかりません",
                tag,
                formatIdentity);

            this._writer = new CommToDoWriter(path, todoPath);
            this._fieldNames =
                (from index in Enumerable.Range(0, this._writer.FieldCount)
                 select _writer.GetFieldName(index)).ToArray();
        }
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。(I.Yoshimi)
        /// </summary>
        /// <param name="path">パス</param>
        /// <param name="formatIdentity">フォーマット識別子</param>
        /// <param name="formatFileName">フォーマットファイル名</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        public ToDoFileForwardWriter(
            string path,
            string formatIdentity,
            string formatFileName,
            CultureInfo cultureInfo)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(path) == false);
            Assertion.Condition(cultureInfo != null);

            this._cultureInfo = cultureInfo;

            var todoPath = string.Empty;

            // フォーマットファイル名指定の場合
            if (formatFileName != null)
            {
                todoPath = formatFileName;
            }
            else
            {
                // フォーマットファイル識別子指定の場合
                // CREO.Fluere.configファイルから、ToDoファイルの雛形ファイル名を取得する
                var tag = "/configuration/ToDoFormatFile";
                var toDoFormatFiles =
                    CREO.FW.Utilities.ProfileUtility.GetXElement(
                        CREO.FW.Utilities.ProfileUtility.ProfileTypeEnum.PersonalProfile,
                        tag);

                Assertion.Require<DataSourceException>(
                    toDoFormatFiles != null,
                    "ToDoフォーマット定義体が見つかりません: 識別子={0}",
                    formatIdentity);

                todoPath =
                    (from name in toDoFormatFiles.Elements("file")
                     where name.Attribute("name").Value == formatIdentity
                     select name.Attribute("path").Value).FirstOrDefault();

                Assertion.Require<DataSourceException>(
                    string.IsNullOrEmpty(todoPath) == false,
                    "ノード[{0}]内に指定された属性[name={1}]が見つかりません",
                    tag,
                    formatIdentity);
            }

            this._writer = new CommToDoWriter(path, todoPath);
            this._fieldNames =
                (from index in Enumerable.Range(0, this._writer.FieldCount)
                 select _writer.GetFieldName(index)).ToArray();
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            if (this._writer != null)
            {
                // 仮に異常によって出力を中断した場合、出力途中の（生成された）ファイルを復元するのは
                // トランザクションコンテキストの役割であるので、ここではとにかく出力を完了させる。
                this._writer.Close();
                this._writer.Dispose();
                this._writer = null;
            }
        }
        #endregion

        #region Flush
        /// <summary>
        /// データをフラッシュします。
        /// </summary>
        public void Flush()
        {
        }
        #endregion

        #region Write
        /// <summary>
        /// 指定された値群を出力します。
        /// </summary>
        /// <param name="values">値群</param>
        public void Write(IList<object> values)
        {
            Assertion.Condition(values != null);
            Assertion.Condition(this._writer != null);

            var xmlData = CommToDoWriter.GetNewRecord();
            for (var index = 0; index < values.Count; index++)
            {
                var value = values[index];
                var stringValue = (value != null) ? Convert.ToString(value, this._cultureInfo) : string.Empty;
                xmlData.Add(new XAttribute(this._fieldNames[index], stringValue));
            }

            this._writer.WriteData(xmlData);
        }
        #endregion
    }
}

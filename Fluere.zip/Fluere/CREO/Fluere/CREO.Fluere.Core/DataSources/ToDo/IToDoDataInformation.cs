﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.18 TMI K.Matsui

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoターゲットの内部情報インターフェイスです。
    /// </summary>
    /// <remarks>このインターフェイスは内部で使用します。</remarks>
    internal interface IToDoDataInformation : IInternalDataSourceInformation
    {
        /// <summary>
        /// フォーマット識別子を取得します。
        /// </summary>
        /// <remarks>フォーマット識別子が与えられていない場合はnullが返されます。</remarks>
        string FormatIdentity
        {
            get;
        }
    }
}

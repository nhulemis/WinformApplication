﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.20 TMI K.Matsui

using System.Globalization;

using CREO.Fluere.Common.DataSources.Linq;

namespace CREO.Fluere.Common.DataSources.ToDo
{
    /// <summary>
    /// ToDoのターゲットを抽象化したデータソースのコンテキストクラスです。
    /// </summary>
    /// <typeparam name="T">コンテキストが示す列挙可能な型</typeparam>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class ToDoTargetContext<T> : TargetContext<T>, IToDoDataInformation
        where T : class
    {
        /// <summary>
        /// フォーマット識別子
        /// </summary>
        private readonly string _formatIdentity;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="provider">プロバイダ</param>
        /// <param name="targetName">ターゲット名</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="formatIdentity">フォーマット識別子</param>
        public ToDoTargetContext(
            ITargetAccessProvider provider,
            string targetName,
            CultureInfo cultureInfo,
            string formatIdentity)
            : base(provider, targetName, cultureInfo)
        {
            this._formatIdentity = formatIdentity;
        }

        /// <summary>
        /// フォーマット識別子を取得します。
        /// </summary>
        /// <remarks>フォーマット識別子が与えられていない場合はnullが返されます。</remarks>
        public string FormatIdentity
        {
            get
            {
                return this._formatIdentity;
            }
        }
    }
}

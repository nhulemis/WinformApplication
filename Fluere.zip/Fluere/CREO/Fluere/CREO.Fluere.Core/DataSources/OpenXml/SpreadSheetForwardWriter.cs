﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.30 TMI Inukaim

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

using CREO.Fluere.Common.Diagnostics;

using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace CREO.Fluere.Common.DataSources.OpenXml
{
    /// <summary>
    /// OpenXMLスプレッドシートから前方方向ライタを生成するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class SpreadSheetForwardWriter : IDataSourceForwardWriter
    {
        #region Fields

        /// <summary>
        ///  スプレッドシートドキュメント
        /// </summary>
        private SpreadsheetDocument _document = null;

        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="document">OpenXMLスプレッドシートへの参照</param>
        /// <param name="targetName">ターゲット名(シート名)</param>
        /// <param name="interpretHeader">先頭行をヘッダとして解釈する場合はtrue</param>
        /// <param name="fieldNames">ヘッダー名群</param>
        public SpreadSheetForwardWriter(
            SpreadsheetDocument document,
            string targetName,
            bool interpretHeader,
            string[] fieldNames)
        {
            Assertion.Condition(document != null);
            Assertion.Condition(targetName != null);
            Assertion.Condition(fieldNames != null);

            this._document = document;

            // シートの作成
            CreateSheet(this._document, targetName, fieldNames);

            // ヘッダが必要なら
            if (interpretHeader)
            {
                // フィールド名群を出力する
                Write(fieldNames);
            }
        }
        #endregion

        #region GetColumnName
        /// <summary>
        /// カラムのインデックスから、カラム名（A,B・・・AAなど）を取得します。
        /// </summary>
        /// <param name="index">カラムのインデックス（1オリジン）</param>
        /// <returns>カラム名</returns>
        private static string GetColumnName(int index)
        {
            var columnName = string.Empty;

            // 下一桁
            index--;
            var baseNumber = 26;

            var remainder = index % baseNumber;
            var division = index / baseNumber;

            var name = (char)((int)'A' + remainder);
            columnName = columnName.Insert(0, name.ToString());

            index = division;

            // 下２桁目以上
            while (0 < index)
            {
                remainder = index % baseNumber;
                division = index / baseNumber;

                name = (char)((int)'A' + (remainder - 1));
                columnName = columnName.Insert(0, name.ToString());

                index = division;
            }

            return columnName;
        }
        #endregion

        #region InternalWrite
        /// <summary>
        /// 指定された値群を出力します。
        /// </summary>
        /// <param name="document">スプレッドシートへの参照</param>
        /// <param name="values">値群</param>
        /// <remarks>このメソッドは内部で使用します。</remarks>
        internal static void InternalWrite(
            SpreadsheetDocument document,
            IList<object> values)
        {
            Assertion.Condition(values != null);

            // ブックに存在する最後に追加されたシートを取得
            var wspart = document.WorkbookPart.WorksheetParts.Last();
            var sheetData = wspart.Worksheet.GetFirstChild<SheetData>();
            var rowCount = sheetData.Elements<Row>().Count();

            // ワークシートに出力
            var row = new Row();
            var column = 1;
            foreach (var data in values)
            {
                var outputData = data;
                if (data != null)
                {
                    var cell = new Cell();

                    //// 2012/12/26 inukai A1形式でしか出力できない対応 sta
                    // cell.CellReference = string.Format("R{0}C{1}", rowCount + 1, column);
                    var columnName = GetColumnName(column);
                    cell.CellReference = string.Format("{0}{1}", columnName, rowCount + 1);
                    //// 2012/12/26 inukai A1形式でしか出力できない対応 end

                    if (data is DateTime)
                    {
                        cell.StyleIndex = 1;
                        cell.CellValue = new CellValue { Text = DateTime.Now.ToOADate().ToString() };
                    }
                    else if (data is bool)
                    {
                        cell.DataType = CellValues.Boolean;
                        cell.CellValue = new CellValue(((bool)data ? 1 : 0).ToString());
                    }
                    else if (
                        data is sbyte ||
                        data is byte ||
                        data is short ||
                        data is ushort ||
                        data is int ||
                        data is uint ||
                        data is long ||
                        data is ulong ||
                        data is float ||
                        data is double ||
                        data is decimal)
                    {
                        cell.DataType = CellValues.Number;
                        cell.CellValue = new CellValue(((IFormattable)data).ToString("D", CultureInfo.InvariantCulture));
                    }
                    else
                    {
                        cell.DataType = CellValues.String;
                        cell.CellValue = new CellValue(data.ToString());
                    }

                    row.Append(cell);
                }

                column++;
            }

            sheetData.Append(row);
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
        }
        #endregion

        #region Flush
        /// <summary>
        /// データをフラッシュします。
        /// </summary>
        public void Flush()
        {
        }
        #endregion

        #region CreateSheet
        /// <summary>
        /// 指定された名前のシートを生成します。
        /// </summary>
        /// <param name="document">スプレッドシートへの参照</param>
        /// <param name="targetName">ターゲット名</param>
        /// <param name="fieldNames">ヘッダー名群</param>
        /// <remarks>このメソッドは内部で使用します。</remarks>
        private static void CreateSheet(
            SpreadsheetDocument document,
            string targetName,
            string[] fieldNames)
        {
            Assertion.Condition(document != null);
            Assertion.Condition(targetName != null);
            Assertion.Condition(fieldNames != null);

            // ドキュメント本体への参照を割り当て
            var wbpart = document.WorkbookPart;

            // ワークブック枠に対して、シート枠を追加
            var wspart = wbpart.AddNewPart<WorksheetPart>();

            // シートIDの生成
            uint sheetId = 1;
            if (wbpart.Workbook.Sheets.Elements<Sheet>().Count() > 0)
            {
                sheetId = wbpart.Workbook.Sheets.Elements<Sheet>().Select(s => s.SheetId.Value).Max() + 1;
            }

            // シートの作成
            var sheet = new Sheet()
            {
                Id = wbpart.GetIdOfPart(wspart),
                SheetId = sheetId,
                Name = targetName,
            };

            // 同じシート名が既に存在する場合は削除してから追加
            var existSheet = (from s in wbpart.Workbook.Sheets
                              where ((Sheet)s).Name == targetName
                              select s).FirstOrDefault();
            if (existSheet != null)
            {
                existSheet.Remove();
            }

            // シート枠にシートの追加
            wbpart.Workbook.Sheets.Append(sheet);

            // ワークシートに出力
            wspart.Worksheet = new Worksheet(new SheetData());

            // ワークシートの保存（sheet.xmlの作成）
            wspart.Worksheet.Save();

            // ワークブックの保存（workbook.xmlの作成）
            wbpart.Workbook.Save();
        }
        #endregion

        #region CreateStyleSheet
        /// <summary>
        /// スタイルシートの生成
        /// </summary>
        /// <param name="document">スプレッドシートへの参照</param>
        private void CreateStyleSheet(SpreadsheetDocument document)
        {
            Assertion.Condition(document != null);

            var stypePart = document.WorkbookPart.AddNewPart<WorkbookStylesPart>();
            var stylesheet = new XlsxStylesheet();
            stypePart.Stylesheet = stylesheet;
            stypePart.Stylesheet.Save();
        }
        #endregion

        #region Write
        /// <summary>
        /// 指定された値群を出力します。
        /// </summary>
        /// <param name="values">値群</param>
        public void Write(IList<object> values)
        {
            Assertion.Condition(values != null);

            InternalWrite(this._document, values);
        }
        #endregion
    }
}

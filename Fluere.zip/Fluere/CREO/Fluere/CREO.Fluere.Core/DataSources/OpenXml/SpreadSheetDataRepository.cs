﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.30 TMI Inukaim

using System.Collections.Generic;
using System.Globalization;
using System.IO;

using CREO.Fluere.Common.DataSources.Linq;
using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.IO;

using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace CREO.Fluere.Common.DataSources.OpenXml
{
    /// <summary>
    /// OpenXMLスプレッドシートファイルを対象とするリポジトリクラスです。
    /// </summary>
    /// <remarks>このクラスを使用して、特定のOpenXMLスプレッドシートファイルのタブに位置するデータにアクセス出来ます。</remarks>
    public sealed class SpreadSheetDataRepository : IDataSourceRepository, ITargetAccessProvider
    {
        #region Fields
        /// <summary>
        /// フォルダ又はファイルへのパスです。
        /// </summary>
        private readonly string _path;

        /// <summary>
        /// 変換に使用するカルチャ情報です。
        /// </summary>
        private readonly CultureInfo _cultureInfo;

        /// <summary>
        /// トランザクションが管理するフォルダへのパスです。
        /// </summary>
        private string _targetFolderPath;

        /// <summary>
        /// トランザクションコンテキストを保持します。
        /// </summary>
        private IFileSystemTransactionContext _transactionContext;

        /// <summary>
        ///  スプレッドシートドキュメント
        /// </summary>
        private SpreadsheetDocument _document = null;

        /// <summary>
        /// 先頭行をヘッダとして解釈するかどうかのフラグ
        /// 解釈する場合はtrue
        /// </summary>
        private bool _interpretHeader = false;

        /// <summary>
        /// ファイルを書き込みモードかどうかのフラグ
        /// 書き込みモードでオープンする場合はtrue
        /// </summary>
        private bool _writable = false;

        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="cultureInfo">変換に使用するカルチャ情報</param>
        /// <param name="interpretHeader">先頭行をヘッダとして解釈する場合はtrue</param>
        /// <param name="writable">ファイルを書き込みモードでオープンする場合はtrue</param>
        public SpreadSheetDataRepository(string filePath, CultureInfo cultureInfo, bool interpretHeader, bool writable)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(filePath) == false, "スプレッドシートファイルへのパスが必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");

            this._path = filePath;
            this._cultureInfo = cultureInfo;
            this._interpretHeader = interpretHeader;
            this._writable = writable;
        }
        #endregion

        #region Location
        /// <summary>
        /// リポジトリの場所を示す文字列を取得します。
        /// </summary>
        public string Location
        {
            get
            {
                return this._path;
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (this._document != null)
                {
                    this._document.Close();
                    this._document = null;
                }

                if (this._transactionContext != null)
                {
                    // streamは_transactionContextが管理し解放する
                    this._transactionContext.Dispose();
                    this._transactionContext = null;
                    this._targetFolderPath = null;
                }
            }
        }
        #endregion

        #region Open
        /// <summary>
        /// リポジトリをオープンします。
        /// </summary>
        public void Open()
        {
            lock (this)
            {
                Assertion.Require(this._transactionContext == null, "二回オープンしようとしました");

                this._transactionContext = FileSystemTransactionContextFactory.CreateContext();

                // 正規化されたパスを取得する
                var fullPath = Path.GetFullPath(this._path);

                lock (this)
                {
                    if (this._targetFolderPath == null)
                    {
                        // フォルダを生成
                        var folderPath = Path.GetDirectoryName(fullPath);
                        this._targetFolderPath = this._transactionContext.CreateDirectory(folderPath);
                    }
                }

                var targetPath = Path.Combine(this._targetFolderPath, Path.GetFileName(fullPath));

                var bufferSize = 65536;
                TransactionalFileStream stream = null;
                try
                {
                    // ストリーム生成、トランザクション管理への登録
                    stream = new TransactionalFileStream(
                        targetPath,
                        FileMode.Open,
                        (this._writable == true) ? FileAccess.ReadWrite : FileAccess.Read,
                        bufferSize,
                        this._transactionContext,
                        false);

                    // Streamでスプレッドシートを生成
                    this._document = SpreadsheetDocument.Open(stream, this._writable);
                }
                catch (IOException)
                {
                    if (this._writable)
                    {
                        // ストリーム生成、トランザクション管理への登録
                        stream = new TransactionalFileStream(
                            targetPath,
                            FileMode.Create,
                            FileAccess.ReadWrite,
                            bufferSize,
                            this._transactionContext,
                            false);

                        // Streamでスプレッドシートを生成
                        this._document = SpreadsheetDocument.Create(stream, DocumentFormat.OpenXml.SpreadsheetDocumentType.Workbook);
                        var workbookPart = this._document.AddWorkbookPart();
                        workbookPart.Workbook = new Workbook(new Sheets());

                        // スタイルの生成
                        CreateStyleSheet(this._document);
                    }
                    else
                    {
                        throw;
                    }
                }
            }
        }
        #endregion

        #region CreateStyleSheet
        /// <summary>
        /// スタイルシートの生成
        /// </summary>
        /// <param name="document">スプレッドシートへの参照</param>
        private void CreateStyleSheet(SpreadsheetDocument document)
        {
            Assertion.Condition(document != null);

            var stypePart = document.WorkbookPart.AddNewPart<WorkbookStylesPart>();
            var stylesheet = new XlsxStylesheet();
            stypePart.Stylesheet = stylesheet;
            stypePart.Stylesheet.Save();
        }
        #endregion

        #region Commit
        /// <summary>
        /// コミットします。
        /// </summary>
        public void Commit()
        {
            lock (this)
            {
                Assertion.Require(this._document != null, "対象のファイルオープンされていません。");
                Assertion.Condition(this._transactionContext != null);

                this._document.Close();
                this._document = null;

                this._transactionContext.Commit();
                this._transactionContext = null;
                this._targetFolderPath = null;
            }
        }
        #endregion

        #region Target
        /// <summary>
        /// このリポジトリが管理するデータソースのシート名を指定して、コンテキストとなるLINQソースを取得します。
        /// </summary>
        /// <typeparam name="T">LINQソースに関連付けるインターフェイス型</typeparam>
        /// <param name="targetName">シート名</param>
        /// <returns>コンテキストとなるLINQソース</returns>
        /// <remarks>このメソッドから得られるLINQソースは、対象のデータを何度でも読み直す事が出来ます。</remarks>
        public IDataSourceContext<T> Target<T>(string targetName)
            where T : class
        {
            Assertion.Argument(typeof(T).IsInterface == true, "インターフェイス型が必要です");
            Assertion.Argument(string.IsNullOrWhiteSpace(targetName) == false, "シート名が必要です");

            return new TargetContext<T>(this, targetName, this._cultureInfo);
        }
        #endregion

        #region Target
        /// <summary>
        /// このリポジトリが管理するEXCELのシート名を指定して、コンテキストとなるソースを取得します。
        /// </summary>
        /// <param name="sheetName">シート名</param>
        /// <param name="options">コンテキストに指定するオプション群</param>
        /// <returns>コンテキストとなるソース</returns>
        /// <remarks>このメソッドから得られるソースは、対象のデータを何度でも読み直す事が出来ます。
        /// 対象のデータはobjectの配列で取得出来ます。
        /// この実装で指定するオプションはありません。</remarks>
        public IDataSourceContext Target(string sheetName, params object[] options)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(sheetName) == false, "シート名が必要です");
            Assertion.Argument(options.Length == 0, "認識出来ないオプションが指定されています");

            return new ExcelTargetContext(this, sheetName);
        }
        #endregion

        #region StoreTo
        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <typeparam name="T">LINQソースに関連付けるインターフェイス型</typeparam>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        /// <param name="targetName">ターゲット名</param>
        /// <remarks>出力フォーマットがT型のインターフェイスで型付けされる場合は、このメソッドを使用する事で、
        /// コンテキストを取得することなく直接レコード群を出力出来ます。</remarks>
        public void StoreTo<T>(IEnumerable<T> enumerable, string targetName)
            where T : class
        {
            this.Target<T>(targetName).Store(enumerable);
        }
        #endregion

        #region CreateStorer
        /// <summary>
        /// 逐次出力を行うインターフェイスを生成します。
        /// </summary>
        /// <typeparam name="T">インターフェイス型</typeparam>
        /// <param name="targetName">ターゲット名</param>
        /// <returns>逐次出力インターフェイス</returns>
        public IDataSourceStorer<T> CreateStorer<T>(string targetName)
            where T : class
        {
            Assertion.Argument(typeof(T).IsInterface == true, "インターフェイス型が必要です");
            Assertion.Argument(string.IsNullOrWhiteSpace(targetName) == false, "シート名が必要です");

            return new TargetStorer<T>(this, targetName, this._cultureInfo);
        }
        #endregion

        #region ITargetAccessProvider
        /// <summary>
        /// 指定された内部情報を使用して、前方参照カーソルを生成します。
        /// </summary>
        /// <param name="information">内部情報</param>
        /// <returns>前方参照カーソル</returns>
        IDataSourceForwardCursor ITargetAccessProvider.CreateForwardCursor(
            IInternalDataSourceInformation information)
        {
            Assertion.Condition(information != null);

            Assertion.Require(this._transactionContext != null, "オープンしていません");

            return new SpreadSheetForwardCursor(
                this._document,
                information.TargetName,
                this._interpretHeader);
        }

        /// <summary>
        /// 指定された内部情報を使用して、前方方向ライタを生成します。
        /// </summary>
        /// <param name="information">内部情報</param>
        /// <param name="fieldNames">フィールドを出力する場合のフィールド名群</param>
        /// <returns>前方方向ライタ</returns>
        IDataSourceForwardWriter ITargetAccessProvider.CreateForwardWriter(
            IInternalDataSourceInformation information,
            string[] fieldNames)
        {
            Assertion.Condition(information != null);
            Assertion.Condition(fieldNames != null);

            Assertion.Require(this._transactionContext != null, "オープンしていません");

            return new SpreadSheetForwardWriter(
                this._document,
                information.TargetName,
                this._interpretHeader,
                fieldNames);
        }
        #endregion

        #region GetSheetNames
        /// <summary>
        /// ブック内のシート名を取得する。
        /// </summary>
        /// <returns>シート名</returns>
        public List<string> GetSheetNames()
        {
            List<string> sheetNames = new List<string>();

            if (this._document == null)
            {
                return null;
            }

            foreach (Sheet sheet in this._document.WorkbookPart.Workbook.Descendants<Sheet>())
            {
                sheetNames.Add(sheet.Name);
            }

            return sheetNames;
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.30 TMI Inukaim

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

using CREO.Fluere.Common.Collections;
using CREO.Fluere.Common.Diagnostics;

using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace CREO.Fluere.Common.DataSources.OpenXml
{
    /// <summary>
    /// OpenXMLスプレッドシートから前方方向カーソルを生成するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class SpreadSheetForwardCursor : IDataSourceForwardCursor
    {
        #region Fields
        /// <summary>
        /// アドレス表記を分割するための文字群
        /// </summary>
        private static readonly string[] ADDRESS_SPLITTING_CHARS = new[] { "R", "C" };

        /// <summary>
        /// アドレス表記を判断する正規表現
        /// </summary>
        private static readonly Regex _addressRegex = new Regex(@"R\d+C\d+", RegexOptions.IgnoreCase);

        /// <summary>
        /// 空のフィールド名群
        /// </summary>
        private static readonly string[] EMPTY_FIELD_NAMES = new string[0];

        /// <summary>
        /// フィールド名群
        /// </summary>
        private readonly string[] _fieldNames;

        /// <summary>
        /// SharedStringの辞書
        /// </summary>
        private readonly Dictionary<int, string> _sharedStrings;

        /// <summary>
        /// 行の列挙子
        /// </summary>
        private IEnumerator<Row> _rowEnumerator;

        /// <summary>
        /// プリフェッチデータ
        /// </summary>
        private Row _prefetchedRow;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="document">OpenXMLスプレッドシートへの参照</param>
        /// <param name="targetSheetName">ターゲット名(シート名)</param>
        /// <param name="interpretHeader">先頭行をヘッダとして解釈する場合はtrue</param>
        public SpreadSheetForwardCursor(
            SpreadsheetDocument document,
            string targetSheetName,
            bool interpretHeader)
        {
            Assertion.Condition(document != null);
            Assertion.Condition(targetSheetName != null);

            var workbookPart = document.WorkbookPart;
            var targetSheet =
                workbookPart.Workbook.Descendants<Sheet>().Where(s => s.Name == targetSheetName).FirstOrDefault();

            var worksheetPart = (WorksheetPart)workbookPart.GetPartById(targetSheet.Id);

            // SharedStringを辞書化
            var stringTable =
                workbookPart.GetPartsOfType<SharedStringTablePart>()
                .FirstOrDefault();
            if (stringTable != null)
            {
                var predict1 =
                    from siEntry in stringTable.SharedStringTable.Elements()
                    where siEntry.LocalName == "si"
                    select siEntry;

                var predict2 =
                    from siEntry in predict1
                    select string.Concat(ExtractTextFromElement(siEntry));

                this._sharedStrings =
                    predict2.WithIndex().ToDictionary(
                        entry => entry.Item1,
                        entry => entry.Item2);
            }
            else
            {
                this._sharedStrings = new Dictionary<int, string>();
            }

            var rows = worksheetPart.Worksheet.GetFirstChild<SheetData>().Elements<Row>();
            this._rowEnumerator = rows.GetEnumerator();

            // 読み取り可能なら
            if (this._rowEnumerator.MoveNext() == true)
            {
                // ヘッダが必要なら
                if (interpretHeader == true)
                {
                    var row = this._rowEnumerator.Current;

                    var cells = row.Elements<Cell>();
                    var values = new List<object>();
                    foreach (var cell in cells)
                    {
                        var colNumber = GetColumnNumber(cell.CellReference.Value);

                        while (values.Count != (colNumber - 1))
                        {
                            values.Add(DataSourceUtility.GetDefaultFieldName(values.Count));
                        }

                        values.Add(ReadInnerText(cell));
                    }

                    // 読み取ったデータをフィールド名群とする
                    this._fieldNames = values.Select(value => value.ToString()).ToArray();
                }
                else
                {
                    // ヘッダが不要
                    // プリフェッチされたデータとして保存
                    this._prefetchedRow = this._rowEnumerator.Current;

                    // 読み取ったデータ数だけデフォルトフィールド名を生成
                    var cells = this._prefetchedRow.Elements<Cell>();
                    var values = new List<string>();
                    foreach (var cell in cells)
                    {
                        var colNumber = GetColumnNumber(cell.CellReference.Value);

                        while (values.Count != (colNumber - 1))
                        {
                            values.Add(DataSourceUtility.GetDefaultFieldName(values.Count));
                        }

                        values.Add(DataSourceUtility.GetDefaultFieldName(values.Count));
                    }

                    this._fieldNames = values.ToArray();
                }
            }
            else
            {
                // 先頭で既にデータが読めない
                // 空のフィールド名群を保存
                this._fieldNames = EMPTY_FIELD_NAMES;
            }
        }
        #endregion

        #region FieldNames
        /// <summary>
        /// フィールド名群を取得します
        /// </summary>
        public string[] FieldNames
        {
            get
            {
                return this._fieldNames;
            }
        }
        #endregion

        #region ExtractTextFromElement
        /// <summary>
        /// t又はrエレメントからテキストを抽出します。
        /// </summary>
        /// <param name="siEntry">siエレメント</param>
        /// <returns>テキストのリスト</returns>
        private static IEnumerable<string> ExtractTextFromElement(DocumentFormat.OpenXml.OpenXmlElement siEntry)
        {
            Assertion.Condition(siEntry != null);
            Assertion.Condition(siEntry.LocalName == "si");

            return
                siEntry.Where(entry => (entry.LocalName == "t") || (entry.LocalName == "r")).Select(entry => (entry.LocalName == "t") ?
                        entry.InnerText :
                        string.Concat(entry.Where(inner => inner.LocalName == "t").Select(inner => inner.InnerText)));
        }
        #endregion

        #region GetColumnNumber
        /// <summary>
        /// セルの列番号を取得します。
        /// </summary>
        /// <param name="cellName">セル名称</param>
        /// <returns>セルの列番号</returns>
        /// <remarks>
        /// R2C3の場合、3を返す。
        /// AA1の場合、27を返す。
        /// </remarks>
        private static int GetColumnNumber(string cellName)
        {
            Assertion.Condition(cellName != null);

            var index = 0;

            Match match = _addressRegex.Match(cellName);
            if (match.Success)
            {
                var split = cellName.Split(ADDRESS_SPLITTING_CHARS, StringSplitOptions.RemoveEmptyEntries);
                int.TryParse(split[1], out index);
            }
            else
            {
                foreach (var c in cellName)
                {
                    int num;
                    if (!int.TryParse(c.ToString(), out num))
                    {
                        // アルファベット
                        index = index * 26;
                        index = ((c - 'A') + 1) + index;
                    }
                    else
                    {
                        break;
                    }
                }
            }

            return index;
        }
        #endregion

        #region ConvertDateTime
        /// <summary>
        /// セルの値を日付型に変換して返す。
        /// </summary>
        /// <param name="cell">セル</param>
        /// <param name="cellText">セルの値</param>
        /// <returns>セルの値を書式変換したオブジェクト</returns>
        /// <remarks>日付型に変換できない場合はそのまま返す。</remarks>
        private static object ConvertDateTime(Cell cell, string cellText)
        {
            Assertion.Condition(cell != null);
            Assertion.Condition(cellText != null);

            if ((cell.StyleIndex != null) && (cell.StyleIndex >= 1))
            {
                double oaDate;
                if (double.TryParse(cellText, out oaDate))
                {
                    try
                    {
                        return DateTime.FromOADate(oaDate);
                    }
                    catch
                    {
                    }
                }
            }

            return cellText;
        }
        #endregion

        #region ReadInnerText
        /// <summary>
        /// セルの値を読み取り、書式に合わせて変換して返します。
        /// </summary>
        /// <param name="cell">対象のセル</param>
        /// <returns>セルの値</returns>
        private object ReadInnerText(Cell cell)
        {
            Assertion.Condition(cell != null);

            var cellText = (cell.CellValue != null) ? cell.CellValue.Text : string.Empty;

            if (cell.DataType != null)
            {
                switch (cell.DataType.Value)
                {
                    case CellValues.SharedString:
                        {
                            string fixup;
                            if (this._sharedStrings.TryGetValue(int.Parse(cellText), out fixup) == true)
                            {
                                cellText = fixup;
                            }
                        }

                        break;
                    case CellValues.Number:
                        break;

                    case CellValues.Boolean:
                        switch (cellText)
                        {
                            case "0":
                                return false;
                            default:
                                return true;
                        }

                    case CellValues.Date:
                        // ISO29500 date cell
                        return ConvertDateTime(cell, cellText);

                    default:
                        return cellText;
                }
            }

            return cellText;
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
        }
        #endregion

        #region Read
        /// <summary>
        /// データを1レコード分読み取ります。
        /// </summary>
        /// <param name="values">読み取ったデータを格納する配列</param>
        /// <returns>読み取った場合はtrue</returns>
        public bool Read(out object[] values)
        {
            // From IDataSourceForwardCursor:
            //   このメソッドを実装する場合、返却する配列は実際のフィールド数によって、以下のように振る舞う事を想定して下さい。
            //   ・返却するデータ数が不足する場合は、不足分のプロパティに値がセットされません。
            //   ・返却するデータ数が過剰の場合は、過剰分が無視されます。
            //   この動作は、IPropertyValueAccessor.SetValuesメソッドの既定の実装によって行われます。

            // プリフェッチされた行があれば
            Row row;
            if (this._prefetchedRow != null)
            {
                // その行を使用する
                row = this._prefetchedRow;
                this._prefetchedRow = null;
            }
            else if (this._rowEnumerator.MoveNext() == true)
            {
                // 次の一行を読み取る
                row = this._rowEnumerator.Current;
            }
            else
            {
                // これ以上読み取れない
                values = null;
                return false;
            }

            var valuesList = new List<object>();
            var cells = row.Elements<Cell>();

            foreach (var cell in cells)
            {
                var colNumber = GetColumnNumber(cell.CellReference.Value);

                while (valuesList.Count != (colNumber - 1))
                {
                    // 値がないセルはNULLを設定する
                    valuesList.Add(null);
                }

                valuesList.Add(this.ReadInnerText(cell));
            }

            // 結果の格納
            values = valuesList.ToArray();
            return true;
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.30 TMI Inukaim

using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Spreadsheet;

namespace CREO.Fluere.Common.DataSources.OpenXml
{
    /// <summary>
    /// OpenXMLスプレッドシートのシートを新規生成する際に使用するクラスです。
    /// </summary>
    /// <remarks>
    /// デフォルトで必要なタグと独自のスタイルを生成
    /// </remarks>
    internal sealed class XlsxStylesheet : Stylesheet
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public XlsxStylesheet()
        {
            var fonts = new Fonts();
            var font = new DocumentFormat.OpenXml.Spreadsheet.Font();
            fonts.Append(font);
            fonts.Count = UInt32Value.FromUInt32((uint)fonts.ChildElements.Count);

            var fills = new Fills();
            var fill = new Fill();
            fills.Append(fill);
            fills.Count = UInt32Value.FromUInt32((uint)fills.ChildElements.Count);

            var borders = new Borders();
            var border = new Border();
            borders.Append(border);
            borders.Count = UInt32Value.FromUInt32((uint)borders.ChildElements.Count);

            var cellStyleFormats = new CellStyleFormats();
            var cellFormat = new CellFormat();
            cellStyleFormats.Append(cellFormat);
            cellStyleFormats.Count =
               UInt32Value.FromUInt32((uint)cellStyleFormats.ChildElements.Count);

            var numberingFormats = new NumberingFormats();
            var nformatDateTime = new NumberingFormat
            {
                NumberFormatId = 177,
                FormatCode = StringValue.FromString("yyyy/mm/dd")
            };
            numberingFormats.Append(nformatDateTime);
            numberingFormats.Count = UInt32Value.FromUInt32((uint)numberingFormats.ChildElements.Count);

            var cellFormats = new CellFormats();
            cellFormat = new CellFormat();
            cellFormats.Append(cellFormat);

            // Cell Date time custom format
            cellFormat = new CellFormat
            {
                NumberFormatId = nformatDateTime.NumberFormatId,
                FontId = 0,
                FillId = 0,
                BorderId = 0,
                FormatId = 0,
                ApplyNumberFormat = BooleanValue.FromBoolean(true)
            };
            cellFormats.Append(cellFormat);
            cellFormats.Count = UInt32Value.FromUInt32((uint)cellFormats.ChildElements.Count);

            this.Append(numberingFormats);
            this.Append(fonts);
            this.Append(fills);
            this.Append(borders);
            this.Append(cellStyleFormats);
            this.Append(cellFormats);
        }
    }
}
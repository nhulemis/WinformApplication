﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Linq;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataSources.OpenXml
{
    /// <summary>
    /// EXCELデータソースのコンテキストクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。
    /// ITargetAccessProviderインターフェイスで供給されるカーソル等を使用して、
    /// インスタンスの入出力をサポートします。</remarks>
    internal sealed class ExcelTargetContext : TargetContextBase<object[]>, IDataSourceContext
    {
        #region Fields
        /// <summary>
        /// 空のフィールド名群
        /// </summary>
        private static readonly string[] EMPTY_FIELD_NAMES = new string[0];

        /// <summary>
        /// 空のフィールド情報群
        /// </summary>
        private static readonly ITargetFieldInformation[] EMPTY_FIELD_INFORMATIONS =
            new ITargetFieldInformation[0];

        /// <summary>
        /// フィールド情報群
        /// </summary>
        private ITargetFieldInformation[] _fieldInformations;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="provider">プロバイダ</param>
        /// <param name="targetName">ターゲット名</param>
        public ExcelTargetContext(ITargetAccessProvider provider, string targetName)
            : base(provider, targetName)
        {
        }
        #endregion

        #region FieldInformations
        /// <summary>
        /// コンテキストから取得可能なフィールド情報群を取得します。
        /// </summary>
        public override ITargetFieldInformation[] FieldInformations
        {
            get
            {
                lock (this)
                {
                    if (this._fieldInformations == null)
                    {
                        // 再入防止
                        this._fieldInformations = EMPTY_FIELD_INFORMATIONS;

                        // TODO:カーソルを取得しないと得られないので、ここにもプリフェッチ処理があったほうがいい
                        using (var cursor = this.CreateForwardCursor())
                        {
                            this._fieldInformations =
                                cursor.FieldNames.Select(fieldName => new PseudoTargetFieldInformation(fieldName)).ToArray();
                        }
                    }

                    return this._fieldInformations;
                }
            }
        }
        #endregion

        #region RawFieldInformations
        /// <summary>
        /// コンテキストから取得可能な生のフィールド情報群を取得します。
        /// </summary>
        public override ITargetFieldInformation[] MetadataFieldInformations
        {
            get
            {
                return EMPTY_FIELD_INFORMATIONS;
            }
        }
        #endregion

        #region GetEnumerator
        /// <summary>
        /// 列挙子を生成します。
        /// </summary>
        /// <returns>列挙子</returns>
        public override IEnumerator<object[]> GetEnumerator()
        {
            using (var cursor = this.CreateForwardCursor())
            {
                object[] values;
                while (cursor.Read(out values) == true)
                {
                    // 返却するインスタンスは誤解を生むので使いまわししない
                    var instance = new object[values.Length];

                    Array.Copy(values, instance, values.Length);

                    yield return instance;
                }
            }
        }
        #endregion

        #region Store
        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        public void Store(IEnumerable<object[]> enumerable)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");

            // このメソッドでは、引数からフィールド名を取得する事が出来ない。
            // そのため、イテレータを手動で一回実行し、フィールド数を取得して、ダミーのフィールド名を生成する。
            var enumerator = enumerable.GetEnumerator();
            try
            {
                string[] fieldNames;
                if (enumerator.MoveNext() == true)
                {
                    fieldNames =
                        (from index in Enumerable.Range(0, enumerator.Current.Length)
                         select DataSourceUtility.GetDefaultFieldName(index)).ToArray();
                }
                else
                {
                    fieldNames = EMPTY_FIELD_NAMES;
                }

                // データが取得できなかったとしても、一応ライタを生成する
                using (var writer = this.CreateForwardWriter(fieldNames))
                {
                    if (object.ReferenceEquals(fieldNames, EMPTY_FIELD_NAMES) == false)
                    {
                        do
                        {
                            writer.Write(enumerator.Current);
                        }
                        while (enumerator.MoveNext() == true);
                    }
                }
            }
            finally
            {
                var disposable = enumerator as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
            }
        }

        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <remarks>このオーバーロードは、自動的に供給されるフィールド名を使用しません。
        /// フィールド名群は、供給されるデータ群と同数か、それ以上が必要です。</remarks>
        public void Store(IEnumerable<object[]> enumerable, params string[] fieldNames)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");

            using (var writer = this.CreateForwardWriter(fieldNames))
            {
                var index = 0;
                foreach (var values in enumerable)
                {
                    Assertion.Require<DataSourceException>(
                        values != null,
                        "データがありません: 行位置={0}",
                        index);
                    Assertion.Require<DataSourceException>(
                        values.Length <= fieldNames.Length,
                        "データ数が多いか、フィールド名数が不足しています: 行位置={0}, データ数={1}, フィールド名数={2}",
                        index,
                        values.Length,
                        fieldNames.Length);

                    writer.Write(values);

                    index++;
                }
            }
        }
        #endregion

        #region PseudoTargetFieldInformation
        /// <summary>
        /// フィールド情報を示すクラスです。
        /// </summary>
        private sealed class PseudoTargetFieldInformation : ITargetFieldInformation
        {
            /// <summary>
            /// フィールド名
            /// </summary>
            private readonly string _fieldName;

            /// <summary>
            /// コンストラクタです。
            /// </summary>
            /// <param name="fieldName">フィールド名</param>
            public PseudoTargetFieldInformation(string fieldName)
            {
                Assertion.Condition(string.IsNullOrWhiteSpace(fieldName) == false);

                this._fieldName = fieldName;
            }

            /// <summary>
            /// フィールド名を取得します。
            /// </summary>
            public string FieldName
            {
                get
                {
                    return this._fieldName;
                }
            }

            /// <summary>
            /// 生のフィールド名を取得します。
            /// </summary>
            public string RawFieldName
            {
                get
                {
                    return this._fieldName;
                }
            }

            /// <summary>
            /// フィールドの型を取得します。
            /// </summary>
            public Type FieldType
            {
                get
                {
                    return typeof(object);
                }
            }

            /// <summary>
            /// 指定された型の属性が定義されているかどうかを取得します。
            /// </summary>
            /// <typeparam name="T">属性クラスの型</typeparam>
            /// <returns>定義されていればtrue</returns>
            public bool IsDefined<T>() where T : Attribute
            {
                return false;
            }

            /// <summary>
            /// 指定された型の属性を取得します。
            /// </summary>
            /// <typeparam name="T">属性クラスの型</typeparam>
            /// <returns>定義されている属性クラス群</returns>
            public T[] GetCustomAttributes<T>() where T : Attribute
            {
                return new T[0];
            }
        }
        #endregion
    }
}

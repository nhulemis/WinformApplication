﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.Serialization;
using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.DataSources.Linq
{
    /// <summary>
    /// ターゲットを抽象化したデータソースのコンテキストクラスです。
    /// </summary>
    /// <typeparam name="T">コンテキストが示す列挙可能な型</typeparam>
    /// <remarks>このクラスは内部で使用します。
    /// ITargetAccessProviderインターフェイスで供給されるカーソル等を使用して、
    /// 型指定されたインスタンスの入出力をサポートします。</remarks>
    internal class TargetContext<T> : TargetContextBase<T>, IDataSourceContext<T>
        where T : class
    {
        #region Fields
        /// <summary>
        /// プロパティアクセサです。
        /// </summary>
        private static readonly IPropertyValueAccessor PROPERTY_ACCESSOR =
            PropertyValueAccessorFactory.GetAccessor<T>(true);

        /// <summary>
        /// フィールドアクセサ群です。
        /// </summary>
        private static readonly ITargetFieldInformation[] FIELD_ACCESSORS =
            Enumerable.Range(0, PROPERTY_ACCESSOR.Count).Select(index => new TargetFieldInformation(PROPERTY_ACCESSOR, index, PROPERTY_ACCESSOR.PropertyNames[index])).ToArray();

        /// <summary>
        /// スタブファクトリです。
        /// </summary>
        private static readonly IStubInstanceFactory<T> FACTORY = StubInstanceFactory.GetInstanceFactory<T>();

        /// <summary>
        /// カスタムコンバータの辞書です。
        /// </summary>
        private readonly IDictionary<Type, ICustomConvert> _converters =
            new Dictionary<Type, ICustomConvert>();

        /// <summary>
        /// フィールド情報群です。
        /// </summary>
        private ITargetFieldInformation[] _fieldInformations;

        /// <summary>
        /// カルチャ情報です。
        /// </summary>
        private CultureInfo _cultureInfo;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="provider">プロバイダ</param>
        /// <param name="targetName">ターゲット名</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        public TargetContext(
            ITargetAccessProvider provider,
            string targetName,
            CultureInfo cultureInfo)
            : base(provider, targetName)
        {
            Assertion.Condition(cultureInfo != null);

            this._cultureInfo = cultureInfo;
        }
        #endregion

        #region InvalidDataValue
        /// <summary>
        /// 不正な値のフィールドを検出した場合に呼び出されるイベントです。
        /// </summary>
        /// <remarks>フィールドから値を取得する際に、フィールド値を型変換しようとして発生する例外を検出出来ます。
        /// このイベントの処理内で、別の例外をスローして下さい。
        /// 例外をスローしないで処理を返した場合、提示されている例外が再スローされます。</remarks>
        public event InvalidDataValueEventHandler InvalidDataValue;
        #endregion

        #region CultureInfo
        /// <summary>
        /// シリアル化を実行する際に使用するカルチャ情報を取得・設定します。
        /// </summary>
        public CultureInfo CultureInfo
        {
            get
            {
                return this._cultureInfo;
            }

            set
            {
                Assertion.NullArgument(value, "カルチャ情報が必要です");

                this._cultureInfo = value;
            }
        }
        #endregion

        #region Converters
        /// <summary>
        /// 事前定義されたカスタムコンバータ群の辞書を取得します。
        /// </summary>
        protected IDictionary<Type, ICustomConvert> Converters
        {
            get
            {
                return this._converters;
            }
        }
        #endregion

        #region FieldInformations
        /// <summary>
        /// コンテキストから取得可能なフィールド情報群を取得します。
        /// </summary>
        public override ITargetFieldInformation[] FieldInformations
        {
            get
            {
                lock (this)
                {
                    if (this._fieldInformations == null)
                    {
                        // 再入防止
                        this._fieldInformations = FIELD_ACCESSORS;

                        // TODO:カーソルを取得しないと得られないので、ここにもプリフェッチ処理があったほうがいい
                        using (var cursor = this.CreateForwardCursor())
                        {
                            this._fieldInformations =
                                (from index in Enumerable.Range(0, cursor.FieldNames.Length)
                                 select new TargetFieldInformation(PROPERTY_ACCESSOR, index, cursor.FieldNames[index])).ToArray();
                        }
                    }

                    return this._fieldInformations;
                }
            }
        }

        /// <summary>
        /// コンテキストから取得可能な生のフィールド情報群を取得します。
        /// </summary>
        /// <remarks>インターフェイスで定義されたフィールド情報群を取得します。
        /// 通常、このプロパティは使用しません。代わりにFieldInformationsを使用します。</remarks>
        public override ITargetFieldInformation[] MetadataFieldInformations
        {
            get
            {
                return FIELD_ACCESSORS;
            }
        }
        #endregion

        #region OnInvalidDataValue
        /// <summary>
        /// 列挙中に発生したエラーを伝播します。
        /// </summary>
        /// <param name="e">イベントの情報</param>
        protected void OnInvalidDataValue(InvalidDataValueEventArgs e)
        {
            Assertion.Condition(e != null);

            if (this.InvalidDataValue != null)
            {
                this.InvalidDataValue(this, e);
            }
        }
        #endregion

        #region RegisterCustomConvert
        /// <summary>
        /// カスタムコンバートに必要な変換インターフェイスを登録します。
        /// </summary>
        /// <typeparam name="U">カスタムコンバートの対象となる属性クラス</typeparam>
        /// <param name="converter">変換インターフェイスのインスタンス</param>
        /// <remarks>CustomConvertAttribute自身が変換を実行しない場合は、
        /// あらかじめこのメソッドを使用して変換インターフェイスを登録する必要があります。</remarks>
        public void RegisterCustomConvert<U>(ICustomConvert converter)
            where U : CustomConvertAttribute
        {
            Assertion.NullArgument(converter, "変換コンバータのインスタンスが必要です");

            lock (this)
            {
                this._converters.Add(typeof(U), converter);
            }
        }
        #endregion

        #region GetEnumerator
        /// <summary>
        /// 列挙子を生成します。
        /// </summary>
        /// <returns>列挙子</returns>
        public override IEnumerator<T> GetEnumerator()
        {
            Action<InvalidDataValueEventArgs> handler = this.OnInvalidDataValue;

            long lineIndex = 0;
            using (var cursor = this.CreateForwardCursor())
            {
                object[] values;
                while (cursor.Read(out values) == true)
                {
                    // 返却するインスタンスは誤解を生むので使いまわししない
                    T instance = FACTORY.CreateInstance();

                    if (PROPERTY_ACCESSOR.SetValues(
                        instance,
                        values,
                        PROPERTY_ACCESSOR.PropertyNames,
                        lineIndex,
                        this._cultureInfo,
                        this._converters,
                        handler) == false)
                    {
                        lineIndex++;
                        continue;
                    }

                    lineIndex++;

                    yield return instance;
                }
            }
        }
        #endregion

        #region Store
        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        public void Store(IEnumerable<T> enumerable)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");

            using (var writer = this.CreateForwardWriter(PROPERTY_ACCESSOR.PropertyNames))
            {
                var values = new object[PROPERTY_ACCESSOR.Count];
                foreach (T instance in enumerable)
                {
                    var results = PROPERTY_ACCESSOR.GetValues(
                        values,
                        instance,
                        this._cultureInfo,
                        this._converters);
                    writer.Write(results);
                }
            }
        }

        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <remarks>このオーバーロードは、自動的に供給されるフィールド名を使用しません。
        /// フィールド名群は、供給されるデータ群と同数か、それ以上が必要です。</remarks>
        public void Store(IEnumerable<T> enumerable, params string[] fieldNames)
        {
            Assertion.NullArgument(enumerable, "列挙子が必要です");

            Assertion.Argument(
                fieldNames.Length >= PROPERTY_ACCESSOR.Count,
                "フィールド名群が不足しています: データ数={0}, フィールド名数={1}",
                PROPERTY_ACCESSOR.Count,
                fieldNames.Length);

            using (var writer = this.CreateForwardWriter(fieldNames))
            {
                var values = new object[PROPERTY_ACCESSOR.Count];
                foreach (T instance in enumerable)
                {
                    var results = PROPERTY_ACCESSOR.GetValues(
                        values,
                        instance,
                        this._cultureInfo,
                        this._converters);
                    writer.Write(results);
                }
            }
        }
        #endregion
    }
}

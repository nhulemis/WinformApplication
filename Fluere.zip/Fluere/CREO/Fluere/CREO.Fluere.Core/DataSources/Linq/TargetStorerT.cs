﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.02.01 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.DataSources.Linq
{
    /// <summary>
    /// 逐次出力処理を可能にするクラスです。
    /// </summary>
    /// <typeparam name="T">列挙可能な型</typeparam>
    /// <remarks>このクラスは内部で使用します。
    /// ITargetAccessProviderインターフェイスで供給されるカーソル等を使用して、
    /// 型指定されたインスタンスの逐次出力をサポートします。</remarks>
    internal class TargetStorer<T> : IDataSourceStorer<T>, IInternalDataSourceInformation
        where T : class
    {
        #region Fields
        /// <summary>
        /// プロパティアクセサです。
        /// </summary>
        private static readonly IPropertyValueAccessor PROPERTY_ACCESSOR =
            PropertyValueAccessorFactory.GetAccessor<T>(true);

        /// <summary>
        /// フィールドアクセサ群です。
        /// </summary>
        private static readonly ITargetFieldInformation[] FIELD_ACCESSORS =
            Enumerable.Range(0, PROPERTY_ACCESSOR.Count).Select(index => new TargetFieldInformation(PROPERTY_ACCESSOR, index, PROPERTY_ACCESSOR.PropertyNames[index])).ToArray();

        /// <summary>
        /// ターゲット名
        /// </summary>
        private readonly string _targetName;

        /// <summary>
        /// カスタムコンバータの辞書です。
        /// </summary>
        private readonly IDictionary<Type, ICustomConvert> _converters =
            new Dictionary<Type, ICustomConvert>();

        /// <summary>
        /// ライタ
        /// </summary>
        private IDataSourceForwardWriter _writer;

        /// <summary>
        /// テンポラリバッファ
        /// </summary>
        private object[] _values = new object[PROPERTY_ACCESSOR.Count];

        /// <summary>
        /// カルチャ情報です。
        /// </summary>
        private CultureInfo _cultureInfo;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="provider">プロバイダ</param>
        /// <param name="targetName">ターゲット名</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <remarks>ターゲット名はnullの可能性があります。</remarks>
        public TargetStorer(ITargetAccessProvider provider, string targetName, CultureInfo cultureInfo)
        {
            Assertion.Condition(provider != null);
            Assertion.Condition(cultureInfo != null);

            this._targetName = targetName;
            this._writer = provider.CreateForwardWriter(this, PROPERTY_ACCESSOR.PropertyNames);
            this._cultureInfo = cultureInfo;
        }
        #endregion

        #region TargetType
        /// <summary>
        /// このシリアライザが変換の対象とするインターフェイス型を取得します。
        /// </summary>
        public Type TargetType
        {
            get
            {
                return typeof(T);
            }
        }
        #endregion

        #region TargetName
        /// <summary>
        /// このクラスのターゲット名を取得します。
        /// </summary>
        /// <remarks>ターゲット名はnullの可能性があります。</remarks>
        public string TargetName
        {
            get
            {
                return this._targetName;
            }
        }
        #endregion

        #region MetadataFieldInformations
        /// <summary>
        /// コンテキストから取得可能な生のフィールド情報群を取得します。
        /// </summary>
        /// <remarks>インターフェイスで定義されたフィールド情報群を取得します。
        /// 通常、このプロパティは使用しません。代わりにFieldInformationsを使用します。</remarks>
        public ITargetFieldInformation[] MetadataFieldInformations
        {
            get
            {
                return FIELD_ACCESSORS;
            }
        }
        #endregion

        #region CultureInfo
        /// <summary>
        /// シリアル化を実行する際に使用するカルチャ情報を取得・設定します。
        /// </summary>
        public CultureInfo CultureInfo
        {
            get
            {
                return this._cultureInfo;
            }

            set
            {
                Assertion.NullArgument(value, "カルチャ情報が必要です");

                this._cultureInfo = value;
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (this._writer != null)
                {
                    this._writer.Dispose();
                    this._writer = null;
                    this._values = null;
                }
            }
        }
        #endregion

        #region RegisterCustomConvert
        /// <summary>
        /// カスタムコンバートに必要な変換インターフェイスを登録します。
        /// </summary>
        /// <typeparam name="U">カスタムコンバートの対象となる属性クラス</typeparam>
        /// <param name="converter">変換インターフェイスのインスタンス</param>
        /// <remarks>CustomConvertAttribute自身が変換を実行しない場合は、
        /// あらかじめこのメソッドを使用して変換インターフェイスを登録する必要があります。</remarks>
        public void RegisterCustomConvert<U>(ICustomConvert converter)
            where U : CustomConvertAttribute
        {
            Assertion.NullArgument(converter, "変換コンバータのインスタンスが必要です");

            lock (this)
            {
                this._converters.Add(typeof(U), converter);
            }
        }
        #endregion

        #region Write
        /// <summary>
        /// 指定されたデータを出力します。
        /// </summary>
        /// <param name="data">データ</param>
        public void Write(T data)
        {
            var results = PROPERTY_ACCESSOR.GetValues(
                this._values,
                data,
                this._cultureInfo,
                this._converters);

            lock (this)
            {
                this._writer.Write(results);
            }
        }

        /// <summary>
        /// 指定されたデータ群を出力します。
        /// </summary>
        /// <param name="datas">データ群</param>
        public void Write(IEnumerable<T> datas)
        {
            lock (this)
            {
                foreach (var data in datas)
                {
                    var results = PROPERTY_ACCESSOR.GetValues(
                        this._values,
                        data,
                        this._cultureInfo,
                        this._converters);

                    this._writer.Write(results);
                }
            }
        }
        #endregion
    }
}

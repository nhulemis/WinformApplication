﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.02.01 TMI K.Matsui

using System;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.DataSources.Linq
{
    /// <summary>
    /// フィールド情報を示すクラスです。
    /// </summary>
    internal sealed class TargetFieldInformation : ITargetFieldInformation
    {
        /// <summary>
        /// アクセサ
        /// </summary>
        private readonly IPropertyValueAccessor _accessor;

        /// <summary>
        /// インデックス
        /// </summary>
        private readonly int _index;

        /// <summary>
        /// フィールド名
        /// </summary>
        private readonly string _fieldName;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="accessor">アクセサ</param>
        /// <param name="index">インデックス</param>
        /// <param name="fieldName">フィールド名</param>
        public TargetFieldInformation(
            IPropertyValueAccessor accessor,
            int index,
            string fieldName)
        {
            Assertion.Condition(accessor != null);
            Assertion.Condition(index >= 0);

            this._accessor = accessor;
            this._index = index;
            this._fieldName = (fieldName ?? string.Empty).Trim();
            if (this._fieldName.Length == 0)
            {
                this._fieldName = accessor.PropertyNames[index];
            }
        }

        /// <summary>
        /// フィールド名を取得します。
        /// </summary>
        public string FieldName
        {
            get
            {
                return this._fieldName;
            }
        }

        /// <summary>
        /// 生のフィールド名を取得します。
        /// </summary>
        /// <remarks>元々のフィールド名を取得します。</remarks>
        public string RawFieldName
        {
            get
            {
                return (this._index < this._accessor.Count) ?
                    this._accessor.RawPropertyNames[this._index] : this._fieldName;
            }
        }

        /// <summary>
        /// フィールドの型を取得します。
        /// </summary>
        public Type FieldType
        {
            get
            {
                return (this._index < this._accessor.Count) ?
                    this._accessor.PropertyTypes[this._index] : typeof(object);
            }
        }

        /// <summary>
        /// 指定された型の属性が定義されているかどうかを取得します。
        /// </summary>
        /// <typeparam name="U">属性クラスの型</typeparam>
        /// <returns>定義されていればtrue</returns>
        public bool IsDefined<U>()
            where U : Attribute
        {
            return (this._index < this._accessor.Count) ?
                this._accessor.IsDefined<U>(this._index) : false;
        }

        /// <summary>
        /// 指定された型の属性を取得します。
        /// </summary>
        /// <typeparam name="U">属性クラスの型</typeparam>
        /// <returns>定義されている属性クラス群</returns>
        public U[] GetCustomAttributes<U>()
            where U : Attribute
        {
            return (this._index < this._accessor.Count) ?
                this._accessor.GetCustomAttributes<U>(this._index) : new U[0];
        }
    }
}

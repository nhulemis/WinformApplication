﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

using CREO.Fluere.Common.DataSources.Linq;
using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.IO;

namespace CREO.Fluere.Common.DataSources.Text
{
    /// <summary>
    /// テキストファイルを対象とするリポジトリクラスです。
    /// </summary>
    /// <remarks>テキストファイルを操作するための共通のインターフェイスを提供します。</remarks>
    public sealed class TextDataRepository : IDataSourceRepository, ITargetAccessProvider
    {
        #region Fields
        /// <summary>
        /// フォルダ又はファイルへのパスです。
        /// </summary>
        private readonly string _path;

        /// <summary>
        /// エンコーディングです。
        /// </summary>
        private readonly Encoding _encoding;

        /// <summary>
        /// 変換に使用するカルチャ情報です。
        /// </summary>
        private readonly CultureInfo _cultureInfo;

        /// <summary>
        /// セパレータ文字です。
        /// </summary>
        private readonly char _separator;

        /// <summary>
        /// テキストデータのフォーマットを示すフラグです。
        /// </summary>
        private readonly TextDataFormat _format;

        /// <summary>
        /// バッファサイズを示します。
        /// </summary>
        private readonly int _bufferSize;

        /// <summary>
        /// トランザクションが管理するフォルダへのパスです。
        /// </summary>
        private string _targetFolderPath;

        /// <summary>
        /// トランザクションコンテキストを保持します。
        /// </summary>
        private IFileSystemTransactionContext _transactionContext;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="path">対象のフォルダ又はファイルパス</param>
        /// <param name="encoding">変換に使用するエンコーディング</param>
        /// <param name="cultureInfo">変換に使用するカルチャ情報</param>
        /// <param name="separator">想定するセパレータ文字</param>
        /// <param name="format">テキストデータソースのフォーマット</param>
        /// <param name="bufferSize">バッファサイズ</param>
        /// <remarks>フォルダを指定した場合は、コンテキスト取得時にファイルへの相対パス又は絶対パスを指定出来ます。
        /// ファイルを指定した場合は、コンテキスト取得時にファイルへのパスを省略する事が出来ます。</remarks>
        public TextDataRepository(
            string path,
            Encoding encoding,
            CultureInfo cultureInfo,
            char separator,
            TextDataFormat format,
            int bufferSize)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(path) == false, "フォルダ又はファイルへのパスが必要です");
            Assertion.NullArgument(encoding, "エンコーディングの指定が必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");
            Assertion.Argument(bufferSize >= 4096, "バッファサイズは4096バイト以上必要です");

            this._path = path;
            this._encoding = encoding;
            this._cultureInfo = cultureInfo;
            this._separator = separator;
            this._format = format;
            this._bufferSize = bufferSize;
        }
        #endregion

        #region Location
        /// <summary>
        /// リポジトリの場所を示す文字列を取得します。
        /// </summary>
        public string Location
        {
            get
            {
                return this._path;
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (this._transactionContext != null)
                {
                    this._transactionContext.Dispose();
                    this._transactionContext = null;
                    this._targetFolderPath = null;
                }
            }
        }
        #endregion

        #region Open
        /// <summary>
        /// リポジトリをオープンします。
        /// </summary>
        public void Open()
        {
            lock (this)
            {
                Assertion.Require(this._transactionContext == null, "二回オープンしようとしました");

                this._transactionContext = FileSystemTransactionContextFactory.CreateContext();
            }
        }
        #endregion

        #region Commit
        /// <summary>
        /// コミットします。
        /// </summary>
        public void Commit()
        {
            lock (this)
            {
                if (this._transactionContext != null)
                {
                    this._transactionContext.Commit();
                    this._transactionContext = null;
                    this._targetFolderPath = null;
                }
            }
        }
        #endregion

        #region CreateStream
        /// <summary>
        /// 指定された基本パスとターゲット名から、ストリームを生成します。
        /// </summary>
        /// <param name="targetName">ファイル名</param>
        /// <param name="write">ライタで使用するかどうか</param>
        /// <returns>ストリーム</returns>
        internal Stream CreateStream(
            string targetName,
            bool write)
        {
            Assertion.Condition(this._transactionContext != null);

            // 正規化されたパスを取得する
            var fullPath = DataSourceUtility.GetRecalculatedNormalizedPath(this._path, targetName);

            lock (this)
            {
                if (this._targetFolderPath == null)
                {
                    // フォルダを生成
                    var folderPath = Path.GetDirectoryName(fullPath);
                    this._targetFolderPath = this._transactionContext.CreateDirectory(folderPath);
                }
            }

            var targetPath = Path.Combine(this._targetFolderPath, Path.GetFileName(fullPath));

            if (write == true)
            {
                return new TransactionalFileStream(
                    targetPath,
                    FileMode.Create,
                    FileAccess.ReadWrite,
                    this._bufferSize,
                    this._transactionContext,
                    false);
            }
            else
            {
                return new TransactionalFileStream(
                    targetPath,
                    FileMode.Open,
                    FileAccess.Read,
                    this._bufferSize,
                    this._transactionContext,
                    false);
            }
        }
        #endregion

        #region Target
        /// <summary>
        /// このリポジトリが管理するデータソースのターゲット名を指定して、コンテキストとなるLINQソースを取得します。
        /// </summary>
        /// <typeparam name="T">LINQソースに関連付けるインターフェイス型</typeparam>
        /// <param name="targetName">ターゲット名</param>
        /// <returns>コンテキストとなるLINQソース</returns>
        /// <remarks>このメソッドから得られるLINQソースは、対象のデータを何度でも読み直す事が出来ます。</remarks>
        public IDataSourceContext<T> Target<T>(string targetName)
            where T : class
        {
            Assertion.Argument(typeof(T).IsInterface == true, "インターフェイス型が必要です");

            return new TargetContext<T>(this, targetName, this._cultureInfo);
        }
        #endregion

        #region StoreTo
        /// <summary>
        /// 指定されたレコード群を保存します。
        /// </summary>
        /// <typeparam name="T">LINQソースに関連付けるインターフェイス型</typeparam>
        /// <param name="enumerable">レコードデータを列挙するインスタンス</param>
        /// <param name="targetName">ターゲット名</param>
        /// <remarks>出力フォーマットがT型のインターフェイスで型付けされる場合は、このメソッドを使用する事で、
        /// コンテキストを取得することなく直接レコード群を出力出来ます。</remarks>
        public void StoreTo<T>(IEnumerable<T> enumerable, string targetName)
            where T : class
        {
            this.Target<T>(targetName).Store(enumerable);
        }
        #endregion

        #region CreateStorer
        /// <summary>
        /// 逐次出力を行うインターフェイスを生成します。
        /// </summary>
        /// <typeparam name="T">関連付けるインターフェイス型</typeparam>
        /// <param name="targetName">ターゲット名</param>
        /// <returns>逐次出力インターフェイス</returns>
        public IDataSourceStorer<T> CreateStorer<T>(string targetName)
            where T : class
        {
            Assertion.Argument(typeof(T).IsInterface == true, "インターフェイス型が必要です");

            return new TargetStorer<T>(this, targetName, this._cultureInfo);
        }
        #endregion

        #region ITargetAccessProvider
        /// <summary>
        /// 指定された内部情報を使用して、前方参照カーソルを生成します。
        /// </summary>
        /// <param name="information">内部情報</param>
        /// <returns>前方参照カーソル</returns>
        IDataSourceForwardCursor ITargetAccessProvider.CreateForwardCursor(
            IInternalDataSourceInformation information)
        {
            Assertion.Condition(information != null);

            Assertion.Require(this._transactionContext != null, "オープンしていません");

            return new TextStreamForwardCursor(
                this.CreateStream(information.TargetName, false),
                this._encoding,
                this._separator,
                this._format);
        }

        /// <summary>
        /// 指定された内部情報を使用して、前方方向ライタを生成します。
        /// </summary>
        /// <param name="information">内部情報</param>
        /// <param name="fieldNames">フィールド名を出力する場合のフィールド名群</param>
        /// <returns>前方方向ライタ</returns>
        IDataSourceForwardWriter ITargetAccessProvider.CreateForwardWriter(
            IInternalDataSourceInformation information,
            string[] fieldNames)
        {
            Assertion.Condition(information != null);
            Assertion.Condition(fieldNames != null);

            Assertion.Require(this._transactionContext != null, "オープンしていません");

            return new TextStreamForwardWriter(
                this.CreateStream(information.TargetName, true),
                this._encoding,
                this._cultureInfo,
                this._separator,
                this._format,
                fieldNames);
        }
        #endregion
    }
}

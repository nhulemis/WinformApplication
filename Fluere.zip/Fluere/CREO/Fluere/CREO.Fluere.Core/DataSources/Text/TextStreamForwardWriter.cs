﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.18 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataSources.Text
{
    /// <summary>
    /// テキストストリームから前方方向ライタを生成するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class TextStreamForwardWriter : IDataSourceForwardWriter
    {
        #region Fields
        /// <summary>
        /// フォーマット
        /// </summary>
        private readonly TextDataFormat _format;

        /// <summary>
        /// セパレータ文字
        /// </summary>
        private readonly char _separator;

        /// <summary>
        /// カルチャ情報
        /// </summary>
        private readonly CultureInfo _cultureInfo;

        /// <summary>
        /// テキストライタ
        /// </summary>
        private TextWriter _tw;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="stream">ストリーム</param>
        /// <param name="encoding">エンコーディング</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <param name="separator">セパレータ文字</param>
        /// <param name="format">テキストデータのフォーマット</param>
        /// <param name="fieldNames">フィールド名群</param>
        public TextStreamForwardWriter(
            Stream stream,
            Encoding encoding,
            CultureInfo cultureInfo,
            char separator,
            TextDataFormat format,
            string[] fieldNames)
        {
            Assertion.Condition(stream != null);
            Assertion.Condition(encoding != null);
            Assertion.Condition(cultureInfo != null);
            Assertion.Condition(fieldNames != null);

            this._format = format;
            this._separator = separator;
            this._cultureInfo = cultureInfo;

            this._tw = new StreamWriter(stream, encoding);

            // ヘッダが必要なら
            if ((this._format & TextDataFormat.WithHeaders) == TextDataFormat.WithHeaders)
            {
                // フィールド名群を出力する
                Write(fieldNames);
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            if (this._tw != null)
            {
                // 仮に異常によって出力を中断した場合、出力途中の（生成された）ファイルを復元するのは
                // トランザクションコンテキストの役割であるので、ここではとにかく出力を完了させる。
                this._tw.Flush();
                this._tw.Close();
                this._tw = null;
            }
        }
        #endregion

        #region Flush
        /// <summary>
        /// データをフラッシュします。
        /// </summary>
        public void Flush()
        {
            Assertion.Condition(_tw != null);

            this._tw.Flush();
        }
        #endregion

        #region WriteWithQuoted
        /// <summary>
        /// 指定された値群をダブルクオートで括りながらテキストライタに出力します。
        /// </summary>
        /// <param name="tw">テキストライタ</param>
        /// <param name="values">値群</param>
        /// <param name="separator">セパレータ文字</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        internal static void WriteWithQuoted(
            TextWriter tw,
            IList<object> values,
            char separator,
            CultureInfo cultureInfo)
        {
            Assertion.Condition(tw != null);
            Assertion.Condition(values != null);
            Assertion.Condition(cultureInfo != null);

            // 大量のデータを効率よく出力出来るように配慮する
            var quotedSeparator = separator + "\"";

            for (var index = 0; index < values.Count; index++)
            {
                if (index == 0)
                {
                    tw.Write('"');
                }
                else
                {
                    tw.Write(quotedSeparator);
                }

                // StringEmptyIsNullの状態に関わらず、nullの場合はフィールドを空文字としなければならない
                // （相手はテキストファイルなので）
                var value = values[index];
                if (value != null)
                {
                    tw.Write(Convert.ToString(value, cultureInfo));
                }

                tw.Write('"');
            }

            // 改行
            tw.WriteLine();
        }
        #endregion

        #region WriteWithoutQuoted
        /// <summary>
        /// 指定された値群をテキストライタに出力します。
        /// </summary>
        /// <param name="tw">テキストライタ</param>
        /// <param name="values">値群</param>
        /// <param name="separator">セパレータ文字</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        internal static void WriteWithoutQuoted(
            TextWriter tw,
            IList<object> values,
            char separator,
            CultureInfo cultureInfo)
        {
            Assertion.Condition(tw != null);
            Assertion.Condition(values != null);
            Assertion.Condition(cultureInfo != null);

            // 大量のデータを効率よく出力出来るように配慮する
            for (var index = 0; index < values.Count; index++)
            {
                if (index >= 1)
                {
                    tw.Write(separator);
                }

                // StringEmptyIsNullの状態に関わらず、nullの場合はフィールドを空文字としなければならない
                // （相手はテキストファイルなので）
                var value = values[index];
                if (value != null)
                {
                    tw.Write(Convert.ToString(value, cultureInfo));
                }
            }

            // 改行
            tw.WriteLine();
        }
        #endregion

        #region Write
        /// <summary>
        /// 指定された値群を出力します。
        /// </summary>
        /// <param name="values">値群</param>
        public void Write(IList<object> values)
        {
            Assertion.Condition(values != null);
            Assertion.Condition(this._tw != null);

            // ダブルクオートが必要なら
            if ((this._format & TextDataFormat.Quoted) == TextDataFormat.Quoted)
            {
                // ダブルクオートで括りながら出力する
                WriteWithQuoted(this._tw, values, this._separator, this._cultureInfo);
            }
            else
            {
                // ダブルクオート不要
                // そのまま出力する
                WriteWithoutQuoted(this._tw, values, this._separator, this._cultureInfo);
            }
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.18 TMI K.Matsui

using System.IO;
using System.Text;

using CREO.Fluere.Common.Diagnostics;

using Microsoft.VisualBasic.FileIO;

namespace CREO.Fluere.Common.DataSources.Text
{
    /// <summary>
    /// テキストストリームから前方参照カーソルを生成するクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class TextStreamForwardCursor : IDataSourceForwardCursor
    {
        #region Fields
        /// <summary>
        /// 空のフィールド名群
        /// </summary>
        private static readonly string[] EMPTY_FIELD_NAMES = new string[0];

        /// <summary>
        /// 空文字列をnullとするかどうか
        /// </summary>
        private readonly bool _stringEmptyIsNull;

        /// <summary>
        /// TextFieldParserのインスタンス
        /// </summary>
        private TextFieldParser _parser;

        /// <summary>
        /// フィールド名群
        /// </summary>
        private string[] _fieldNames;

        /// <summary>
        /// プリフェッチデータ
        /// </summary>
        private object[] _prefetchedValues;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="stream">ストリーム</param>
        /// <param name="encoding">エンコーディング</param>
        /// <param name="separator">セパレータ文字</param>
        /// <param name="format">テキストデータのフォーマット</param>
        public TextStreamForwardCursor(Stream stream, Encoding encoding, char separator, TextDataFormat format)
        {
            Assertion.Condition(stream != null);
            Assertion.Condition(encoding != null);

            this._stringEmptyIsNull = (format & TextDataFormat.StringEmptyIsNull) == TextDataFormat.StringEmptyIsNull;

            // パーサの準備
            this._parser = new TextFieldParser(new StreamReader(stream, encoding, true));
            this._parser.TextFieldType = FieldType.Delimited;
            this._parser.HasFieldsEnclosedInQuotes = (format & TextDataFormat.Quoted) == TextDataFormat.Quoted;
            this._parser.TrimWhiteSpace = true;
            this._parser.SetDelimiters(separator.ToString());

            // 読み取り可能なら
            if (this._parser.EndOfData == false)
            {
                // 一行読み取る
                var values = this._parser.ReadFields();

                // ヘッダが必要なら
                if ((format & TextDataFormat.WithHeaders) == TextDataFormat.WithHeaders)
                {
                    // 空文字列の置き換えが必要なら：
                    //   ヘッダに空文字が含まれる場合、このフラグを直解するとnullが格納される事になる。
                    //   それは良くないので、空文字の場合はデフォルトフィールド名を格納する。
                    //   フラグが指定されなかった場合は何もしないので、空文字は空文字のフィールド名となる。
                    if (this._stringEmptyIsNull == true)
                    {
                        // 空文字列があれば、デフォルトのフィールド名とする
                        for (var index = 0; index < values.Length; index++)
                        {
                            if (values[index].Length == 0)
                            {
                                values[index] = DataSourceUtility.GetDefaultFieldName(index);
                            }
                        }
                    }

                    // 読み取ったデータをフィールド名群とする
                    this._fieldNames = values;
                }
                else
                {
                    // ヘッダが不要
                    // データを1行読み取っているので、これを保存しておかないと、先頭行を失ってしまう。
                    // プリフェッチデータとして保持する。

                    // 空文字列の置き換えが必要なら
                    if (this._stringEmptyIsNull == true)
                    {
                        // 空文字列をnullに置き換える
                        FixupEmptyString(values);
                    }

                    // プリフェッチされたデータとして保存
                    this._prefetchedValues = values;

                    // 読み取ったデータ数だけデフォルトフィールド名を生成
                    this._fieldNames = new string[values.Length];
                    for (var index = 0; index < values.Length; index++)
                    {
                        this._fieldNames[index] = DataSourceUtility.GetDefaultFieldName(index);
                    }
                }
            }
            else
            {
                // 先頭で既にデータが読めない
                // 空のフィールド名群を保存
                this._fieldNames = EMPTY_FIELD_NAMES;
            }
        }
        #endregion

        #region FieldNames
        /// <summary>
        /// フィールド名群を取得します
        /// </summary>
        public string[] FieldNames
        {
            get
            {
                return this._fieldNames;
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            if (this._parser != null)
            {
                this._parser.Dispose();
                this._parser = null;
            }
        }
        #endregion

        #region FixupEmptyString
        /// <summary>
        /// 空文字列をnullに置き換えます。
        /// </summary>
        /// <param name="values">文字列群</param>
        internal static void FixupEmptyString(string[] values)
        {
            Assertion.Condition(values != null);

            for (var index = 0; index < values.Length; index++)
            {
                if (values[index].Length == 0)
                {
                    values[index] = null;
                }
            }
        }
        #endregion

        #region Read
        /// <summary>
        /// データを1レコード分読み取ります。
        /// </summary>
        /// <param name="values">読み取ったデータを格納する配列</param>
        /// <returns>読み取った場合はtrue</returns>
        public bool Read(out object[] values)
        {
            // From IDataSourceForwardCursor:
            //   このメソッドを実装する場合、返却する配列は実際のフィールド数によって、以下のように振る舞う事を想定して下さい。
            //   ・返却するデータ数が不足する場合は、不足分のプロパティに値がセットされません。
            //   ・返却するデータ数が過剰の場合は、過剰分が無視されます。
            //   この動作は、IPropertyValueAccessor.SetValuesメソッドの既定の実装によって行われます。

            // 大量のデータを効率よく読み取れるように配慮する

            // プリフェッチされた値群があれば
            if (this._prefetchedValues != null)
            {
                // その値群を返す
                values = this._prefetchedValues;
                this._prefetchedValues = null;
                return true;
            }

            // これ以上読み取れない
            if (this._parser.EndOfData == true)
            {
                values = null;
                return false;
            }

            // 次の一行を読み取る
            var data = this._parser.ReadFields();

            // 空文字列の置き換えを実行
            if (this._stringEmptyIsNull == true)
            {
                FixupEmptyString(data);
            }

            // 結果の格納
            values = data;

            return true;
        }
        #endregion
    }
}

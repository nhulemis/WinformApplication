﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースに供給するカーソル等のインターフェイスです。
    /// </summary>
    /// <remarks>このインターフェイスは内部で使用します。
    /// このインターフェイスの実装をターゲットコンテキストやストアラが受け取り、
    /// 読み取り・出力の要求が発生した場合に、このインターフェイスを経由して前方参照カーソル・前方方向ライタを生成します。
    /// 通常、データソースリポジトリ自身がこのインターフェイスを実装するか、又は移譲されたクラスがこのインターフェイスを実装し、
    /// リクエストに応じて、前方参照カーソル・前方方向ライタを生成する必要があります。</remarks>
    internal interface ITargetAccessProvider
    {
        /// <summary>
        /// 指定された内部情報を使用して、前方参照カーソルを生成します。
        /// </summary>
        /// <param name="information">内部情報</param>
        /// <returns>前方参照カーソル</returns>
        /// <remarks>プロバイダの実装は、与えられた内部コンテキストの情報を使用して、前方参照カーソルを生成する必要があります。</remarks>
        IDataSourceForwardCursor CreateForwardCursor(IInternalDataSourceInformation information);

        /// <summary>
        /// 指定された内部情報を使用して、前方方向ライタを生成します。
        /// </summary>
        /// <param name="information">内部情報</param>
        /// <param name="fieldNames">フィールド名群</param>
        /// <returns>前方方向ライタ</returns>
        /// <remarks>プロバイダの実装は、与えられた内部コンテキストの情報を使用して、前方方向ライタを生成する必要があります。
        /// フィールド名群は、内部コンテキストから提供されるフィールド名と異なる場合があります。
        /// 実際の出力では、この引数で指定されるフィールド名を優先します。</remarks>
        IDataSourceForwardWriter CreateForwardWriter(IInternalDataSourceInformation information, string[] fieldNames);
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.11 TMI K.Matsui

using System.IO;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.IO;

namespace CREO.Fluere.Common.DataSources
{
    /// <summary>
    /// データソースで使用するユーティリティクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal static class DataSourceUtility
    {
        #region GetRecalculatedNormalizedPath
        /// <summary>
        /// 指定された基本パスとターゲット名から解釈される、正規化されたパスを取得します。
        /// </summary>
        /// <param name="path">基本パス</param>
        /// <param name="targetName">ファイル名</param>
        /// <returns>パス</returns>
        public static string GetRecalculatedNormalizedPath(string path, string targetName)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(path) == false);

            // 何かが指定されていれば
            string fullPath;
            if (string.IsNullOrWhiteSpace(targetName) == false)
            {
                // 相対又は絶対パスとして解釈する
                fullPath = PathUtility.ToAbsolutePath(targetName, PathUtility.GetNormalizedFolderUri(path));
            }
            else
            {
                // パスをフルパスに変換する
                fullPath = Path.GetFullPath(path);
            }

            return fullPath;
        }
        #endregion

        #region GetDefaultFieldName
        /// <summary>
        /// デフォルトのフィールド名を生成します。
        /// </summary>
        /// <param name="index">インデックス</param>
        /// <returns>フィールド名</returns>
        public static string GetDefaultFieldName(int index)
        {
            // 命名はJetに習った（F1～）
            return string.Format("F{0}", index + 1);
        }
        #endregion
    }
}

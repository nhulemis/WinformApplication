﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

namespace CREO.Fluere.Common.Configuration
{
    /// <summary>
    /// Fluere処理で使用する設定ファイルの制御を行うジェネリッククラスです。
    /// </summary>
    /// <typeparam name="T">設定データを示すインターフェイスの型</typeparam>
    /// <remarks>このクラスは、Fluere処理で使用する設定ファイル（システム定義・処理固有の設定ファイルなど）の
    /// ロードとセーブを制御します。</remarks>
    public sealed class ConfigurationManager<T> : IAssignableConfigurationManager<T>
        where T : class
    {
        /// <summary>
        /// ConfigurationManagerのインスタンスです。
        /// </summary>
        private readonly ConfigurationManager _configurationManager;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="targetPath">設定データのロード･セーブに使用するファイルへのパス</param>
        public ConfigurationManager(string targetPath)
        {
            this._configurationManager = new ConfigurationManager(typeof(T), targetPath);
        }

        /// <summary>
        /// 設定データを識別する名前です。
        /// </summary>
        public string Name
        {
            get
            {
                return this._configurationManager.Name;
            }
        }

        /// <summary>
        /// 設定データを識別する長い名前を取得します。
        /// </summary>
        public string FullName
        {
            get
            {
                return this._configurationManager.FullName;
            }
        }

        /// <summary>
        /// 設定データを反映するインスタンスを取得します。
        /// </summary>
        public T Configuration
        {
            get
            {
                return (T)this._configurationManager.Configuration;
            }

            set
            {
                this._configurationManager.Configuration = value;
            }
        }

        /// <summary>
        /// 設定データを反映するインスタンスを取得します。
        /// </summary>
        object IConfigurationManager.Configuration
        {
            get
            {
                return this._configurationManager.Configuration;
            }
        }

        /// <summary>
        /// 設定データを反映するインスタンスを取得します。
        /// </summary>
        object IAssignableConfigurationManager.Configuration
        {
            get
            {
                return this._configurationManager.Configuration;
            }

            set
            {
                this._configurationManager.Configuration = value;
            }
        }

        /// <summary>
        /// 設定データをストレージからロードします。
        /// </summary>
        public void Load()
        {
            this._configurationManager.Load();
        }

        /// <summary>
        /// 設定データをストレージにセーブします。
        /// </summary>
        public void Save()
        {
            this._configurationManager.Save();
        }
    }
}

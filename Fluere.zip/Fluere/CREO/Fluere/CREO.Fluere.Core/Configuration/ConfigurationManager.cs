﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.IO;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.IO;
using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.Configuration
{
    /// <summary>
    /// Fluere処理で使用する設定ファイルの制御を行うクラスです。
    /// </summary>
    /// <remarks>このクラスは、Fluere処理で使用する設定ファイル（システム定義・処理固有の設定ファイルなど）の
    /// ロードとセーブを制御します。</remarks>
    public sealed class ConfigurationManager : IAssignableConfigurationManager
    {
        /// <summary>
        /// 空の引数
        /// </summary>
        private static readonly object[] EMPTY_INDEX = new object[0];

        /// <summary>
        /// シリアライザ
        /// </summary>
        private readonly IConfigurationSerializer _serializer;

        /// <summary>
        /// ターゲットのパス
        /// </summary>
        private readonly string _targetPath;

        /// <summary>
        /// インスタンス
        /// </summary>
        private object _configuration;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="configurationType">設定データを示すインターフェイスの型</param>
        /// <param name="targetPath">設定データのロード･セーブに使用するファイルへのパス</param>
        public ConfigurationManager(Type configurationType, string targetPath)
        {
            Assertion.NullArgument(
                configurationType,
                "設定データに対応するインターフェイスの型が必要です");
            Assertion.Argument(
                configurationType.IsInterface == true,
                "設定データに対応する型はインターフェイスである必要があります");
            Assertion.Argument(
                string.IsNullOrWhiteSpace(targetPath) == false,
                "設定データのロード・セーブに使用するファイルへのパスが必要です");

            // フルパスを特定する
            this._targetPath = Path.GetFullPath(targetPath);

            // ConfigurationSerializerを生成する
            this._serializer = new ConfigurationSerializer(configurationType);

            // フォルダへのパスをUriに変換し、変換インターフェイスとして設定する
            var targetDirectoryPath = Path.GetDirectoryName(_targetPath);

            this._serializer.RegisterCustomConvert<RelativePathAttribute>(
                new RelativePathCustomConvert(PathUtility.GetNormalizedFolderUri(targetDirectoryPath)));
        }

        /// <summary>
        /// 設定データを識別する名前です。
        /// </summary>
        public string Name
        {
            get
            {
                return Path.GetFileNameWithoutExtension(this._targetPath);
            }
        }

        /// <summary>
        /// 設定データを識別する長い名前を取得します。
        /// </summary>
        public string FullName
        {
            get
            {
                return this._targetPath;
            }
        }

        /// <summary>
        /// 設定データを反映するインスタンスを取得します。
        /// </summary>
        public object Configuration
        {
            get
            {
                return this._configuration;
            }

            set
            {
                this._configuration = value;
            }
        }

        /// <summary>
        /// 設定データをストレージからロードします。
        /// </summary>
        public void Load()
        {
            using (var stream = new TransactionalFileStream(_targetPath, FileMode.Open, FileAccess.Read, null, false))
            {
                // 処理固有の設定ファイルを逆シリアル化する
                this._configuration = this._serializer.Deserialize(stream);
            }
        }

        /// <summary>
        /// 設定データをストレージにセーブします。
        /// </summary>
        public void Save()
        {
            using (var stream = new TransactionalFileStream(_targetPath, FileMode.Create, FileAccess.ReadWrite, null, false))
            {
                // 処理固有の設定ファイルを逆シリアル化する
                this._serializer.Serialize(stream, this._configuration);

                // コミットする
                stream.Commit();
            }
        }
    }
}

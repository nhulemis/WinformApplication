﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.07.11 TMI K.Matsui

using System;
using System.Globalization;
using System.Reflection;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.IO;
using CREO.Fluere.Common.Serialization;

namespace CREO.Fluere.Common.Configuration
{
    /// <summary>
    /// 相対パス変換を行うカスタムコンバータクラスです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class RelativePathCustomConvert : ICustomConvert
    {
        /// <summary>
        /// 基底ディレクトリを示すURIです。
        /// </summary>
        private readonly Uri _targetDirectoryUri;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="targetDirectoryUri">基底フォルダパス</param>
        public RelativePathCustomConvert(Uri targetDirectoryUri)
        {
            Assertion.Condition(targetDirectoryUri != null);

            this._targetDirectoryUri = targetDirectoryUri;
        }

        /// <summary>
        /// シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        public object SerializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo)
        {
            Assertion.Condition(pi != null);
            Assertion.Condition((value == null) || (value is string));
            Assertion.Condition(cultureInfo != null);

            Assertion.Require<ConfigurationManagerException>(
                pi.PropertyType == typeof(string),
                "プロパティ {0}.{1} は文字列ではありません",
                pi.DeclaringType.FullName,
                pi.Name);

            return PathUtility.ToRelativePath((string)value, this._targetDirectoryUri);
        }

        /// <summary>
        /// 逆シリアル化変換を実行します。
        /// </summary>
        /// <param name="value">変換元の値</param>
        /// <param name="pi">対象のプロパティ</param>
        /// <param name="cultureInfo">カルチャ情報</param>
        /// <returns>変換した値</returns>
        public object DeserializationConvert(object value, PropertyInfo pi, CultureInfo cultureInfo)
        {
            Assertion.Condition(pi != null);
            Assertion.Condition((value == null) || (value is string));
            Assertion.Condition(cultureInfo != null);

            Assertion.Require<ConfigurationManagerException>(
                pi.PropertyType == typeof(string),
                "プロパティ {0}.{1} は文字列ではありません",
                pi.DeclaringType.FullName,
                pi.Name);

            return PathUtility.ToAbsolutePath((string)value, this._targetDirectoryUri);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using CREO.Fluere.Common.Collections;

namespace CREO.Fluere.Common.Configuration
{
    /// <summary>
    /// AppSettingsAccessorクラス
    /// </summary>
    public static class AppSettingsAccessor
    {
        /// <summary>
        /// KeyValuePairの辞書
        /// </summary>
        private static readonly Dictionary<string, string> _pairs;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        static AppSettingsAccessor()
        {
            var appSettings = CREO.FW.Utilities.ProfileUtility.GetXElement(
                CREO.FW.Utilities.ProfileUtility.ProfileTypeEnum.ModuleProfile,
                "/configuration/appSettings");

            _pairs =
                (from add in appSettings.Elements("add")
                 let key = add.Attribute("key")
                 let value = add.Attribute("value")
                 where
                     (key != null) && (string.IsNullOrWhiteSpace(key.Value) == false) &&
                     (value != null)
                 select KeyValuePair.Create(key.Value, value.Value)).ToDictionary();
        }

        /// <summary>
        /// 指定のオブジェクト形式の値を取得する
        /// </summary>
        /// <typeparam name="T">指定のオブジェクト形式</typeparam>
        /// <param name="name">名前</param>
        /// <param name="defaultValue">通常の返し値</param>
        /// <returns>返し値のオブジェクト</returns>
        public static T GetValue<T>(string name, T defaultValue = default(T))
        {
            string value;
            if (_pairs.TryGetValue(name, out value) == false)
            {
                return defaultValue;
            }

            try
            {
                return (T)Convert.ChangeType(value, typeof(T), CultureInfo.InvariantCulture);
            }
            catch
            {
                return defaultValue;
            }
        }
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013.01.28 TMI K.Matsui

using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.Executive
{
    /// <summary>
    /// 内部用ログクラスです。
    /// </summary>
    internal sealed class InternalLogger : ILogger
    {
        /// <summary>
        /// フレームワークライブラリのログマネージャを保持するフィールドです。
        /// </summary>
        private readonly CREO.FW.Log.LogManager _logManager;

        /// <summary>
        /// フレームワークライブラリのメッセージマネージャを保持するフィールドです。
        /// </summary>
        private readonly CREO.FW.Message.MessageManager _messageManager;

        /// <summary>
        /// TextWriter出力
        /// </summary>
        private readonly TextWriter _output;

        /// <summary>
        /// TextWriterエラー
        /// </summary>
        private readonly TextWriter _error;

        /// <summary>
        /// Lock
        /// </summary>
        private static readonly object LOCK = new object();

        /// <summary>
        /// Logger
        /// </summary>
        private static ILogger _logger;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="moduleNumber">モジュール番号</param>
        /// <param name="output">出力ライタ</param>
        /// <param name="error">エラーライタ</param>
        internal InternalLogger(string moduleNumber, TextWriter output, TextWriter error)
        {
            this._logManager = CREO.FW.Log.LogManager.GetLogger(moduleNumber);
            this._messageManager = CREO.FW.Message.MessageManager.GetMessageManager(moduleNumber);
            this._output = output;
            this._error = error;
        }

        /// <summary>
        /// インスタンスを取得します。
        /// </summary>
        public static ILogger Logger
        {
            get
            {
                if (_logger == null)
                {
                    lock (LOCK)
                    {
                        if (_logger == null)
                        {
                            _logger = new InternalLogger("UF", Console.Out, Console.Error);
                        }
                    }
                }

                return _logger;
            }
        }

        /// <summary>
        /// 例外を文字列に変換します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <returns>出力文字列</returns>
        private static string FormatException(Exception ex)
        {
            return string.Format("[{0}: {1}]", ex.GetType().FullName, ex.Message);
        }

        /// <summary>
        /// フォーマット文字列に従って文字列に変換します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">パラメータ</param>
        /// <returns>出力文字列</returns>
        private static string FormatString(Exception ex, string format, object[] args)
        {
            if (ex != null)
            {
                return string.Format("{0} {1}", string.Format(format, args), FormatException(ex));
            }
            else
            {
                return string.Format(format, args);
            }
        }

        /// <summary>
        /// メッセージの改行コードやTabコードを半角スペースに置き換える。
        /// </summary>
        /// <param name="message">修正前のメッセージ</param>
        /// <returns>修正後のメッセージ</returns>
        private static string Sanitize(string message)
        {
            return message.Replace("\r", " ").Replace("\n", " ").Replace("\t", " ");
        }

        /// <summary>
        /// 情報を文字列化します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="messageID">メッセージID</param>
        /// <param name="args">パラメータ</param>
        /// <returns>出力文字列</returns>
        private string FormatMessage(Exception ex, string messageID, object[] args)
        {
            try
            {
                if (this._messageManager.GetMessageInfo(messageID) != null)
                {
                    if (ex != null)
                    {
                        return this._messageManager.GetMessage(ex, messageID, args);
                    }
                    else
                    {
                        return this._messageManager.GetMessage(messageID, args);
                    }
                }
            }
            catch
            {
            }

            string argStr = string.Join(", ",
                    args.Select(arg =>
                    {
                        if (arg == null)
                        {
                            return "(null)";
                        }

                        if (arg is string)
                        {
                            return string.Format("\"{0}\"", arg);
                        }

                        return arg.ToString();
                    }));
            return
                string.Format("{0}: {1} {2}",
                    messageID,
                    argStr,
                    (ex != null) ? FormatException(ex) : string.Empty);
        }

        /// <summary>
        /// ログを出力します。
        /// </summary>
        /// <param name="messageID">メッセージID</param>
        /// <param name="args">ログに出力するメッセージに適用する引数群</param>
        public void WriteLog(string messageID, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(messageID) == false, "メッセージコードが必要です");

            Trace.WriteLine(Sanitize(FormatMessage(null, messageID, args)));

            this._logManager.Write(messageID, args);
        }

        /// <summary>
        /// ログを出力します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="messageID">メッセージID</param>
        /// <param name="args">ログに出力するメッセージに適用する引数群</param>
        public void WriteLog(Exception ex, string messageID, params object[] args)
        {
            Debug.Assert(ex != null, "例外が指定されていません");
            Debug.Assert(string.IsNullOrWhiteSpace(messageID) == false, "メッセージコードが必要です");

            var message = Sanitize(FormatMessage(ex, messageID, args));
            Trace.WriteLine(message);
            this._error.WriteLine(message);

            this._logManager.Write(ex, messageID, args);
        }

        /// <summary>
        /// ログを出力します。
        /// </summary>
        /// <param name="ex">CREOException例外</param>
        /// <returns>エラーコード</returns>
        public int WriteLog(CREO.FW.ExceptionHandling.CREOException ex)
        {
            Debug.Assert(ex != null, "例外が指定されていません");

            int errorCode = FluereRunnerProcessHost.GetErrorCodeFromCREOException(ex);

            var parameters = (ex.MessageParameters != null) ? ex.MessageParameters : new object[0];

            var message = Sanitize(FormatMessage(ex, ex.MessageId, parameters));
            Trace.WriteLine(message);
            this._error.WriteLine(message);

            this._logManager.Write(ex, ex.MessageId, ex.MessageParameters);

            return errorCode;
        }

        /// <summary>
        /// デバッグ用ログを出力します。
        /// </summary>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public void WriteDebugLog(string format, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列を指定する必要があります");

            Trace.WriteLine(Sanitize(FormatString(null, format, args)));

            this._logManager.WriteDebug(format, args);
        }

        /// <summary>
        /// デバッグ用ログを出力します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public void WriteDebugLog(Exception ex, string format, params object[] args)
        {
            Debug.Assert(ex != null, "例外が指定されていません");
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列を指定する必要があります");

            Trace.WriteLine(Sanitize(FormatString(ex, format, args)));

            this._logManager.WriteDebug(ex, format, args);
        }

        /// <summary>
        /// トレース用ログを出力します。
        /// </summary>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public void WriteTraceLog(string format, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列を指定する必要があります");

            Trace.WriteLine(Sanitize(FormatString(null, format, args)));

            this._logManager.WriteTrace(format, args);
        }

        /// <summary>
        /// トレース用ログを出力します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public void WriteTraceLog(Exception ex, string format, params object[] args)
        {
            Debug.Assert(ex != null, "例外が指定されていません");
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列を指定する必要があります");

            Trace.WriteLine(Sanitize(FormatString(ex, format, args)));

            this._logManager.WriteTrace(ex, format, args);
        }
    }
}

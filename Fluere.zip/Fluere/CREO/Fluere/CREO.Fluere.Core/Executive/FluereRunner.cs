﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;

using CREO.Fluere.Common.Configuration;
using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.Executive
{
    /// <summary>
    /// Fluereの処理を制御するクラスです。
    /// </summary>
    /// <remarks>指定されたモジュールから、Fluere処理を実装するクラス
    /// （IFluereRunnableインターフェイスを実装したシールクラス）を検索し、設定データマネージャ群を生成して実行します。</remarks>
    public sealed class FluereRunner : IFluereRunner
    {
        #region Fields
        /// <summary>
        /// ロードしたFluere処理実装クラスのエントリポイントを示すデリゲートです。
        /// </summary>
        private IFluereRunnable _runnable;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="moduleName">親モジュール名</param>
        public FluereRunner(string moduleName)
        {
            Assertion.Argument(
                string.IsNullOrWhiteSpace(moduleName) == false,
                "親モジュール名が必要です");

            // 処理実装クラスのインスタンスを得る
            this._runnable = LoadImplementationModule(moduleName);
        }
        #endregion

        #region Name
        /// <summary>
        /// 処理名称を取得します。
        /// </summary>
        public string Name
        {
            get
            {
                return this._runnable.Name;
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            if (this._runnable != null)
            {
                this._runnable.Dispose();
                this._runnable = null;
            }
        }
        #endregion

        #region IsFluereRunnableImplemented
        /// <summary>
        /// 指定された型がFluere処理実装クラスかどうかを確認します。
        /// </summary>
        /// <param name="type">型</param>
        /// <returns>パブリックシールクラスで、IFluereRunnableを実装していればtrue</returns>
        internal static bool IsFluereRunnableImplemented(Type type)
        {
            return
                ((type.IsPublic == true) || (type.IsNestedPublic == true)) &&
                (type.IsClass == true) &&
                (type.IsSealed == true) &&
                (typeof(IFluereRunnable).IsAssignableFrom(type) == true);
        }
        #endregion

        #region LoadImplementationModule
        /// <summary>
        /// 指定されたモジュール名からロード済みアセンブリ内の処理実装DLLを探し、処理実装クラスのインスタンスを取得します。
        /// </summary>
        /// <param name="moduleName">モジュールの名前</param>
        /// <returns>処理実装クラスのインスタンス</returns>
        internal static IFluereRunnable LoadImplementationModule(string moduleName)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(moduleName) == false);

            // モジュール名からロード済みアセンブリ内の処理実装DLLを特定する
            string implementationModule = string.Format("{0}Module.dll", System.IO.Path.GetFileNameWithoutExtension(moduleName));
            var assembly = AppDomain.CurrentDomain.GetAssemblies().FirstOrDefault(a => a.Location.EndsWith(implementationModule));

            if (assembly == null) 
            {
                throw new ArgumentException(
                    string.Format("処理実装DLLが見つかりません：{0}",
                    implementationModule));
            }

            // 処理実装クラスを検索する
            foreach (var type in assembly.GetTypes())
            {
                // パブリックシールクラスで、IFluereRunnableを実装していれば
                if (IsFluereRunnableImplemented(type) == true)
                {
                    // インスタンスを生成する
                    return (IFluereRunnable)Activator.CreateInstance(type);
                }
            }

            throw new ArgumentException(
                string.Format("{0} に、処理実装クラスが見つかりません",
                implementationModule));
        }
        #endregion

        #region IsCandidateRunMethod
        /// <summary>
        /// Runメソッドの候補かどうかを確認します。
        /// </summary>
        /// <param name="methodInfo">メソッド情報</param>
        /// <returns>候補ならtrue</returns>
        internal static bool IsCandidateRunMethod(MethodInfo methodInfo)
        {
            Assertion.Condition(methodInfo != null);

            // 名前が"Run"であること
            if (methodInfo.Name != "Run")
            {
                return false;
            }

            // 戻り値がintであること
            if (typeof(int).IsAssignableFrom(methodInfo.ReturnType) == false)
            {
                return false;
            }

            // パラメータ長が1以上であること
            var parameters = methodInfo.GetParameters();
            if (parameters.Length == 0)
            {
                return false;
            }

            // 先頭の引数にIFluereRunnerHostを指定可能であること
            if (parameters[0].ParameterType.IsAssignableFrom(typeof(IFluereRunnerHost)) == false)
            {
                return false;
            }

            return true;
        }
        #endregion

        #region GetArgumentTypes
        /// <summary>
        /// 指定されたメソッドの引数の型を取得します。
        /// </summary>
        /// <param name="methodInfo">メソッド情報</param>
        /// <returns>引数の型群</returns>
        internal static IEnumerable<Type> GetArgumentTypes(MethodInfo methodInfo)
        {
            Assertion.Condition(methodInfo != null);

            var parameters = methodInfo.GetParameters();
            Assertion.Condition(parameters.Length >= 1);

            var configurationTypes = new List<Type>();
            for (var i = 1; i < parameters.Length; i++)
            {
                // 引数の型からIConfigurationManager<T>型のジェネリック引数を取得する
                var types = TypeUtility.GetGenericArgumentsByTargetGenericDefinitionType(
                    parameters[i].ParameterType,
                    typeof(IConfigurationManager<>));

                // 定義されていない場合は無視
                if (types == null)
                {
                    return null;
                }

                Assertion.Condition(types.Length == 1);
                Assertion.Require(
                    types[0].IsInterface == true,
                    "メソッド {0}.{1} の引数 {2} のジェネリック引数 {3} は、インターフェイスではありません",
                    methodInfo.DeclaringType.FullName,
                    methodInfo.Name,
                    parameters[i].Name,
                    types[0].FullName);

                configurationTypes.Add(types[0]);
            }

            return configurationTypes;
        }
        #endregion

        #region GetArgumentDescriptions
        /// <summary>
        /// Fluere処理のエントリポイントが必要とするインターフェイスの名称群を取得します。
        /// </summary>
        /// <returns>インターフェイスの名称群</returns>
        public string[] GetArgumentDescriptions()
        {
            // 型のパブリックメソッドを列挙する
            var runnableType = this._runnable.GetType();
            foreach (var methodInfo in runnableType.GetMethods())
            {
                // 候補なら
                if (IsCandidateRunMethod(methodInfo) == true)
                {
                    var types = GetArgumentTypes(methodInfo);
                    if (types != null)
                    {
                        // DescriptionAttributeを収集する（適用されていない場合はインターフェイス名）
                        return
                            (from type in types
                             let attributes = (DescriptionAttribute[])type.GetCustomAttributes(typeof(DescriptionAttribute), false)
                             select (attributes.Length >= 1) ? attributes[0].Description : type.Name).ToArray();
                    }
                }
            }

            // 候補が見つからない
            throw new ArgumentException(
                string.Format("{0} に、対応するRunメソッドが定義されていません",
                runnableType.FullName));
        }
        #endregion

        #region GetConfigurationTypes
        /// <summary>
        /// 指定されたメソッドがRunメソッドに適合する場合、追加のIConfigurationManager引数群に指定されている型群を取得します。
        /// </summary>
        /// <param name="methodInfo">検証するメソッド</param>
        /// <param name="argumentLength">想定する追加引数の長さ</param>
        /// <returns>適合する場合は、型群。適合しない場合はnull</returns>
        internal static IEnumerable<Type> GetConfigurationTypes(MethodInfo methodInfo, int argumentLength)
        {
            Assertion.Condition(methodInfo != null);
            Assertion.Condition(argumentLength >= 0);

            // 候補でなければ
            if (IsCandidateRunMethod(methodInfo) == false)
            {
                return null;
            }

            // パラメータ長が要求数+1（先頭のIFluereRunnerInformationを含む）であること
            var parameters = methodInfo.GetParameters();
            if (parameters.Length != (argumentLength + 1))
            {
                return null;
            }

            // 後続の引数群をチェックする
            return GetArgumentTypes(methodInfo);
        }
        #endregion

        #region GetRunMethodAndConfigurationTypes
        /// <summary>
        /// 指定された型に定義されている、適合するRunメソッドを返します。
        /// </summary>
        /// <param name="runnableType">検索対象の型</param>
        /// <param name="argumentLength">想定する追加引数の長さ</param>
        /// <param name="runMethod">対象のメソッド</param>
        /// <returns>処理固有の設定インターフェイス型群</returns>
        internal static IEnumerable<Type> GetRunMethodAndConfigurationTypes(
            Type runnableType,
            int argumentLength,
            out MethodInfo runMethod)
        {
            Assertion.Condition(runnableType != null);
            Assertion.Condition(argumentLength >= 0);
            Assertion.Condition(typeof(IFluereRunnable).IsAssignableFrom(runnableType) == true);

            // 型のパブリックメソッドを列挙する
            foreach (var methodInfo in runnableType.GetMethods())
            {
                var configurationTypes = GetConfigurationTypes(methodInfo, argumentLength);
                if (configurationTypes != null)
                {
                    runMethod = methodInfo;
                    return configurationTypes;
                }
            }

            throw new ArgumentException(
                string.Format("{0} に、対応するRunメソッドが定義されていません",
                runnableType.FullName));
        }
        #endregion

        #region Run
        /// <summary>
        /// Fluereの処理を実行します。
        /// </summary>
        /// <param name="runnerHost">Fluere処理を実行するための情報を提供するインターフェイス</param>
        /// <param name="configurationManagers">Runメソッドの追加引数に対応するConfigurationManager群</param>
        /// <returns>戻り値</returns>
        public int Run(IFluereRunnerHost runnerHost, params IConfigurationManager[] configurationManagers)
        {
            Assertion.NullArgument(runnerHost, "Fluere処理実行情報が必要です");

            // Runメソッドの先頭の引数をrunnerHostとする
            var runnableArguments = new object[configurationManagers.Length + 1];
            runnableArguments[0] = runnerHost;

            // 処理実装クラスから、パブリックなRunメソッドで引数の数が一致するリストを取得する
            var index = 0;
            MethodInfo runMethod;
            foreach (var configruationType in
                GetRunMethodAndConfigurationTypes(
                    this._runnable.GetType(),
                    configurationManagers.Length,
                    out runMethod))
            {
                Assertion.Condition(
                    configruationType == TypeUtility.GetGenericArgumentsByTargetGenericDefinitionType(
                        configurationManagers[index].GetType(),
                        typeof(IConfigurationManager<>))[0]);

                runnableArguments[index + 1] = configurationManagers[index];
                index++;
            }

            runnerHost.WriteTraceLog(
                "Begin: {0}.{1}()",
                runMethod.DeclaringType.Name,
                runMethod.Name);

            try
            {
                // 処理を実行する
                var result = (int)runMethod.Invoke(this._runnable, runnableArguments);

                runnerHost.WriteTraceLog(
                    "Finished: {0}.{1}()",
                    runMethod.DeclaringType.Name,
                    runMethod.Name);

                return result;
            }
            catch (TargetInvocationException ex)
            {
                runnerHost.WriteTraceLog(
                    "Raise {0}, aborted: {1}.{2}()",
                    ex.InnerException.GetType().Name,
                    runMethod.DeclaringType.Name,
                    runMethod.Name);

                throw;
            }
        }

        /// <summary>
        /// Fluereの処理を実行します。
        /// </summary>
        /// <param name="runnerHost">Fluere処理を実行するための情報を提供するインターフェイス</param>
        /// <param name="args">コマンドラインで指定されたファイルへのパス群</param>
        /// <returns>戻り値</returns>
        public int Run(IFluereRunnerHost runnerHost, params string[] args)
        {
            Assertion.NullArgument(runnerHost, "Fluere処理実行情報が必要です");

            // Runメソッドの先頭の引数をrunnerHostとする
            var runnableArguments = new object[args.Length + 1];
            runnableArguments[0] = runnerHost;

            // 処理実装クラスから、パブリックなRunメソッドで引数の数が一致するリストを取得する
            var index = 0;
            MethodInfo runMethod;
            foreach (var configruationType in
                GetRunMethodAndConfigurationTypes(
                    this._runnable.GetType(),
                    args.Length,
                    out runMethod))
            {
                // ConfigurationManagerのインスタンスを生成して保存する
                runnableArguments[index + 1] = runnerHost.CreateConfigurationManager(configruationType, args[index]);
                index++;
            }

            runnerHost.WriteTraceLog(
                "Begin: {0}.{1}()",
                runMethod.DeclaringType.Name,
                runMethod.Name);

            try
            {
                // 処理を実行する
                var result = (int)runMethod.Invoke(this._runnable, runnableArguments);

                runnerHost.WriteTraceLog(
                    "Finished: {0}.{1}()",
                    runMethod.DeclaringType.Name,
                    runMethod.Name);

                return result;
            }
            catch (TargetInvocationException ex)
            {
                runnerHost.WriteTraceLog(
                    "Raise {0}, aborted: {1}.{2}()",
                    ex.InnerException.GetType().Name,
                    runMethod.DeclaringType.Name,
                    runMethod.Name);

                throw;
            }
        }
        #endregion
    }
}

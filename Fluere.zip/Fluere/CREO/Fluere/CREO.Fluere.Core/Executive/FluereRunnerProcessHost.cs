﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;

using CREO.Fluere.Common.Configuration;
using CREO.Fluere.Common.DataServices;
using CREO.Fluere.Common.DataSources;
using CREO.Fluere.Common.DataSources.OpenXml;
using CREO.Fluere.Common.DataSources.Text;
using CREO.Fluere.Common.DataSources.ToDo;
using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.Message.UF00000;
using CREO.Fluere.Common.TypeServices;
using CREO.FW.ExceptionHandling;
using CREO.FW.Message;

namespace CREO.Fluere.Common.Executive
{
    /// <summary>
    /// Fluere処理の実行をプロセス上で行う制御クラスです。
    /// </summary>
    /// <remarks>Fluere処理を実行する起動プロセスに関連する、モジュール名や処理実装モジュールのパス、
    /// 関連付けられる設定ファイルを制御するConfigurationManagerのインスタンス生成、
    /// メッセージ・ログ出力の処理を行うための情報を保持します。</remarks>
    public sealed class FluereRunnerProcessHost : IFluereRunnerHost
    {
        #region Fields
        /// <summary>
        /// Fluere処理に割り当てるモジュール識別番号を示すフィールドです。
        /// </summary>
        private static readonly string MODULE_NUMBER = "UF";

        /// <summary>
        /// アプリケーションを識別するアセンブリです。
        /// </summary>
        private readonly Assembly _applicationAssembly;

        /// <summary>
        /// 現在のプロセスを起動したモジュールのフォルダです。
        /// </summary>
        private readonly string _baseFolder;

        /// <summary>
        /// テキスト出力に使用するライタを保持するフィールドです。
        /// </summary>
        private readonly TextWriter _output;

        /// <summary>
        /// エラーテキスト出力に使用するライタを保持するフィールドです。
        /// </summary>
        private readonly TextWriter _error;

        /// <summary>
        /// カレントプロセスを保存するフィールドです。
        /// </summary>
        private Process _currentProcess = Process.GetCurrentProcess();

        /// <summary>
        /// データサービス接続ファクトリを保持するフィールドです。
        /// </summary>
        private IDataServiceFactory _dataServiceFactory;

        /// <summary>
        /// フレームワークライブラリのメッセージマネージャを保持するフィールドです。
        /// </summary>
        private MessageManager _messageManager;

        /// <summary>
        /// フレームワークライブラリのログマネージャを保持するフィールドです。
        /// </summary>
        private ILogger _logger;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="output">テキスト出力に使用するライタ</param>
        /// <param name="error">エラーテキスト出力に使用するライタ</param>
        public FluereRunnerProcessHost(TextWriter output, TextWriter error)
            : this(Assembly.GetCallingAssembly(), output, error)
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="applicationAssembly">アプリケーション対象のアセンブリ</param>
        /// <param name="output">テキスト出力に使用するライタ</param>
        /// <param name="error">エラーテキスト出力に使用するライタ</param>
        public FluereRunnerProcessHost(Assembly applicationAssembly, TextWriter output, TextWriter error)
        {
            Assertion.NullArgument(applicationAssembly, "アプリケーション対象のアセンブリが必要です");
            Assertion.NullArgument(output, "テキスト出力に使用するライタが必要です");
            Assertion.NullArgument(error, "エラーテキスト出力に使用するライタが必要です");

            this._applicationAssembly = applicationAssembly;

            // 出力先を保存する
            this._output = output;
            this._error = error;

            // フォルダを保存する
            this._baseFolder = Path.GetDirectoryName(new Uri(this._applicationAssembly.CodeBase).LocalPath);

            // アプリケーションドメインにロードするアセンブリの失敗を監視する
            AppDomain.CurrentDomain.AssemblyResolve += new ResolveEventHandler(this.CurrentDomain_AssemblyResolve);

            // デフォルトのファクトリを生成する
            this._dataServiceFactory = new DataServiceFactory();
        }
        #endregion

        #region ModuleName
        /// <summary>
        /// 親モジュール名を取得します。
        /// </summary>
        /// <remarks>現在実行中のプロセスを起動したモジュール名を返します。</remarks>
        public string ModuleName
        {
            get
            {
                return Path.GetFileName(this._currentProcess.MainModule.FileName);
            }
        }
        #endregion

        #region GetErrorCodeFromCREOException
        /// <summary>
        /// 指定されたCREOExceptionからエラーコードを取得します。
        /// </summary>
        /// <param name="ex">CREOException</param>
        /// <returns>エラーコード</returns>
        internal static int GetErrorCodeFromCREOException(CREOException ex)
        {
            Debug.Assert(ex != null, "例外が必要です");

            string messageID = ex.MessageId;
            if (messageID.Length >= 6)
            {
                int errorCode;
                if (int.TryParse(messageID.Substring(5), out errorCode) == true)
                {
                    return errorCode;
                }
            }

            return ex.ReasonCode;
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            if (this._currentProcess != null)
            {
                this._currentProcess.Dispose();
                this._currentProcess = null;
                this._dataServiceFactory = null;
                this._messageManager = null;
                this._logger = null;

                AppDomain.CurrentDomain.AssemblyResolve -= new ResolveEventHandler(this.CurrentDomain_AssemblyResolve);
            }
        }
        #endregion

        #region CurrentDomain_AssemblyResolve
        /// <summary>
        /// アセンブリの参照解決を実行します。
        /// </summary>
        /// <param name="sender">送信元</param>
        /// <param name="args">ロードに必要なアセンブリの情報</param>
        /// <returns>ロードしたアセンブリ</returns>
        /// <remarks>App.configのアセンブリバインディングにパスを記述しなくても、自動的にアセンブリロードの解決を行います。</remarks>
        internal Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            Assertion.Condition(this._baseFolder != null);

            var referenceFrom =
                (args.RequestingAssembly != null) ? ("[" + args.RequestingAssembly.FullName + "]") : "(Unknown)";

            var name = args.Name;
            var index = name.IndexOf(',');
            if (index != -1)
            {
                name = name.Substring(0, index).Trim();
            }

            var fileName = string.Format("{0}.dll", name);

            Trace.WriteLine(
                string.Format(
                    "{0}: Beginning auto resolving assembly: Name=[{1}], Base=[{2}]",
                    this.GetType().Name,
                    args.Name,
                    this._baseFolder));

            foreach (var path in Directory.EnumerateFiles(this._baseFolder, fileName, SearchOption.AllDirectories))
            {
                try
                {
                    var assembly = Assembly.LoadFrom(path);

                    Trace.WriteLine(
                        string.Format(
                            "{0}: Resolved assembly: Module=[{1}]",
                            this.GetType().Name,
                            path));

                    return assembly;
                }
                catch (Exception ex)
                {
                    InternalLogger.Logger.WriteDebugLog(
                        ex,
                        "指定されたアセンブリはロード出来ません: TargetName=[{0}], Path=\"{1}\", ReferenceFrom={2}",
                        args.Name,
                        path,
                        referenceFrom);
                }
            }

            if (name.EndsWith(".resources", StringComparison.InvariantCultureIgnoreCase) == false)
            {
                InternalLogger.Logger.WriteDebugLog(
                    "指定されたアセンブリが見つかりません: TargetName=[{0}], ReferenceFrom={1}",
                    args.Name,
                    referenceFrom);
            }

            return null;
        }
        #endregion

        #region HandleException
        /// <summary>
        /// 指定された例外を処理します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <returns>例外に対応するエラーコード</returns>
        /// <remarks>例外についてログに情報を出力し、エラーコードを返します。</remarks>
        public int HandleException(Exception ex)
        {
            Assertion.Condition(ex != null);

            // フレームワークのログ出力は、InnerExceptionsを正しく処理していないため、例外の情報を見逃してしまう。
            // そのため、InnerExceptions分岐はここで面倒を見る。
            // （ログファイル的には階層が分断されて出力されるので分かりにくいが、出力されないより良い）

            // はじめに、例外をそのまま出力させる
            int errorCode = 0;
            var creoException = ex as CREOException;
            if (creoException != null)
            {
                // CREOExceptionをログに出力する
                errorCode = WriteLog(creoException);
            }
            else
            {
                var creoExInner = ex.InnerException as CREOException;
                if (creoExInner != null)
                {
                    errorCode = WriteLog(creoExInner);
                    ex = ex.InnerException;
                }
                else 
                {
                    // ラップしてログに出力する
                    var outerException = new Uf00000001Exception(ex);
                    errorCode = WriteLog(outerException);
                }
            }

            // InnerExceptionsを探索する
            Exception exception = ex;
            while (exception != null)
            {
                // この層がAggregateExceptionなら
                var aex = exception as AggregateException;
                if (aex != null)
                {
                    // InnerExceptionsを列挙
                    foreach (var innerException in aex.InnerExceptions)
                    {
                        // InnerExceptionと同一の例外を除外（出力済みなので）
                        if (object.ReferenceEquals(aex.InnerException, innerException) == false)
                        {
                            // 再帰する
                            this.HandleException(innerException);
                        }
                    }
                }

                exception = exception.InnerException;
            }

            return errorCode;
        }
        #endregion

        #region HandleTargetInvocationException
        /// <summary>
        /// 指定されたTargetInvocationException例外を処理します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <returns>例外に対応するエラーコード</returns>
        /// <remarks>例外についてログに情報を出力し、エラーコードを返します。
        /// このメソッドの代わりに、HandleExceptionを使って下さい。</remarks>
        public int HandleTargetInvocationException(TargetInvocationException ex)
        {
            Assertion.NullArgument(ex, "TargetInvocationExceptionのインスタンスが必要です");

            return this.HandleException(ex);
        }
        #endregion

        #region SetModuleNumber
        /// <summary>
        /// モジュール識別番号を設定します。
        /// </summary>
        /// <param name="moduleNumber">モジュール識別番号</param>
        internal void SetModuleNumber(string moduleNumber)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(moduleNumber) == false);

            // モジュール識別番号から、メッセージマネージャとログマネージャを取得する
            this._messageManager = MessageManager.GetMessageManager(moduleNumber);
            this._logger = new InternalLogger(moduleNumber, this._output, this._error);
        }
        #endregion

        #region Initialize
        /// <summary>
        /// 処理化を実行します。
        /// </summary>
        /// <exception cref="ArgumentException">指定されたモジュール識別番号に対応するメッセージが無い</exception>
        /// <remarks>プロセスに固有の初期化処理を実行します。
        /// モジュール識別番号を設定する事で、メッセージ変換とログ出力をフレームワークで処理します。</remarks>
        public void Initialize()
        {
            Assertion.Require(this._messageManager == null, "初期化が2回実行されました");
            Assertion.Require(this._logger == null, "初期化が2回実行されました");

            // CREOフレームワークを初期化する
            Framework.Initialize(this._applicationAssembly);

            // モジュール識別番号を設定する
            SetModuleNumber(MODULE_NUMBER);
        }
        #endregion

        #region GetDataSourceIDFromDataServiceID
        /// <summary>
        /// 指定されたデータサービスIDからデータソースIDを取得します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <returns>データソースID</returns>
        /// <remarks>通常、このメソッドは使用しません。
        /// データサービスの情報が必要な場合はGetDataServiceDefinitionsを使用します。
        /// また、データサービスへの接続はこのメソッドを使用せず、直接データサービスIDを使用します。</remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public string GetDataSourceIDFromDataServiceID(
            string dataServiceID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID)
        {
            return this._dataServiceFactory.GetDataSourceIDFromDataServiceID(dataServiceID, idType);
        }
        #endregion

        #region GetDataServiceIDs
        /// <summary>
        /// 設定ファイルに定義されているデータサービスIDの一覧を取得します。
        /// </summary>
        /// <param name="extractTypes">抽出条件</param>
        /// <returns>データサービス情報の列挙子</returns>
        public IEnumerable<IDataServiceDefinition> GetDataServiceDefinitions(
            DataServiceIDExtractTypes extractTypes = DataServiceIDExtractTypes.DatabaseRoleID)
        {
            return this._dataServiceFactory.GetDataServiceDefinitions(extractTypes);
        }
        #endregion

        #region PreBindDataService
        /// <summary>
        /// 事前バインドしたデータサービスファクトリを取得します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <param name="connectionPooling">接続プールを有効化する場合はtrue</param>
        /// <returns>事前バインドしたファクトリ</returns>
        /// <remarks>データサービスIDを事前に設定する事により、
        /// トランザクションの有無のみでデータサービスを生成する事が出来ます。
        /// 接続プールを有効化した場合は、同一のスレッドに対して同じデータサービスのインスタンスを返し、
        /// 異なるスレッドに対してユニークなデータサービスのインスタンスを返します。
        /// これにより、マルチスレッド動作時に高いパフォーマンスを維持し、かつデータサービスへの接続を最小化します。</remarks>
        public IPreBoundDataServiceFactory PreBindDataService(
            string dataServiceID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID,
            bool connectionPooling = true)
        {
            return this._dataServiceFactory.PreBindDataService(
                dataServiceID,
                idType,
                connectionPooling);
        }

        /// <summary>
        /// 事前バインドしたデータサービスファクトリを取得します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="workGroupID">ワークグループID</param>
        /// <param name="subWorkGroupID">サブワークグループID</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <param name="connectionPooling">接続プールを有効化する場合はtrue</param>
        /// <returns>事前バインドしたファクトリ</returns>
        /// <remarks>データサービスID・ワークグループID等を事前に設定する事により、
        /// トランザクションの有無のみでデータサービスを生成する事が出来ます。
        /// 接続プールを有効化した場合は、同一のスレッドに対して同じデータサービスのインスタンスを返し、
        /// 異なるスレッドに対してユニークなデータサービスのインスタンスを返します。
        /// これにより、マルチスレッド動作時に高いパフォーマンスを維持し、かつデータサービスへの接続を最小化します。</remarks>
        public IPreBoundDataServiceFactory PreBindDataService(
            string dataServiceID,
            ulong workGroupID,
            ulong subWorkGroupID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID,
            bool connectionPooling = true)
        {
            return this._dataServiceFactory.PreBindDataService(
                dataServiceID,
                workGroupID,
                subWorkGroupID,
                idType,
                connectionPooling);
        }
        #endregion

        #region ConnectToDataService
        /// <summary>
        /// データサービスに接続します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="transactionMode">トランザクションモード</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <returns>データサービスのインスタンス</returns>
        public CREO.DS.DataService ConnectToDataService(
            string dataServiceID,
            TransactionMode transactionMode,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID)
        {
            return this._dataServiceFactory.ConnectToDataService(
                dataServiceID,
                transactionMode,
                idType);
        }

        /// <summary>
        /// データサービスに接続します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="workGroupID">ワークグループID</param>
        /// <param name="subWorkGroupID">サブワークグループID</param>
        /// <param name="transactionMode">トランザクションモード</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <returns>データサービスのインスタンス</returns>
        public CREO.DS.DataService ConnectToDataService(
            string dataServiceID,
            ulong workGroupID,
            ulong subWorkGroupID,
            TransactionMode transactionMode,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID)
        {
            return this._dataServiceFactory.ConnectToDataService(
                dataServiceID,
                workGroupID,
                subWorkGroupID,
                transactionMode,
                idType);
        }
        #endregion

        #region CreateConfigurationManager
        /// <summary>
        /// ConfigurationManagerを生成します。
        /// </summary>
        /// <param name="configurationType">対象の型（インターフェイス）</param>
        /// <param name="configurationPath">対象を格納するファイルのパス</param>
        /// <returns>インスタンス</returns>
        /// <remarks>指定されたパスに従って、ConfigurationManagerのインスタンスを生成します。</remarks>
        public IConfigurationManager CreateConfigurationManager(
            Type configurationType,
            string configurationPath)
        {
            Assertion.NullArgument(
                configurationType,
                "対象の型を指定する必要があります");
            Assertion.Argument(
                configurationType.IsInterface == true,
                "対象の型はインターフェイスである必要があります");
            Assertion.Argument(
                string.IsNullOrWhiteSpace(configurationPath) == false,
                "対象を格納するファイルのパスを指定する必要があります");

            // ConfigurationManager<T>から生成する
            Type configruationManagerType = typeof(ConfigurationManager<>).MakeGenericType(configurationType);
            return (IConfigurationManager)Activator.CreateInstance(configruationManagerType, configurationPath);
        }

        /// <summary>
        /// ConfigurationManagerを生成します。
        /// </summary>
        /// <typeparam name="T">対象の型（インターフェイス）</typeparam>
        /// <param name="configurationPath">対象を格納するファイルのパス</param>
        /// <returns>インスタンス</returns>
        /// <remarks>指定されたパスに従って、ConfigurationManagerのインスタンスを生成します。</remarks>
        public IAssignableConfigurationManager<T> CreateConfigurationManager<T>(string configurationPath)
            where T : class
        {
            Assertion.Argument(
                string.IsNullOrWhiteSpace(configurationPath) == false,
                "対象を格納するファイルのパスを指定する必要があります");

            // ConfigurationManager<T>から生成する
            return new ConfigurationManager<T>(configurationPath);
        }
        #endregion

        #region CreateTextDataRepository
        /// <summary>
        /// 指定されたパスが示すフォルダ内のテキストファイルに対して入出力を行うリポジトリを生成します。
        /// </summary>
        /// <param name="path">対象のフォルダ又はファイルパス</param>
        /// <param name="encoding">変換に使用するエンコーディング</param>
        /// <param name="cultureInfo">変換に使用するカルチャ情報</param>
        /// <param name="separator">想定するセパレータ文字</param>
        /// <param name="format">テキストデータソースのフォーマット</param>
        /// <param name="bufferSize">バッファサイズ</param>
        /// <returns>リポジトリのインスタンス</returns>
        /// <remarks>フォルダを指定した場合は、リーダ又はライタ生成時にファイルへの相対パス又は絶対パスを指定出来ます。
        /// ファイルを指定した場合は、リーダ又はライタ生成時にファイルへのパスを省略する事が出来ます。</remarks>
        public IDataSourceRepository CreateTextDataRepository(
            string path,
            Encoding encoding,
            CultureInfo cultureInfo,
            char separator,
            TextDataFormat format,
            int bufferSize)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(path) == false, "フォルダ又はファイルへのパスが必要です");
            Assertion.NullArgument(encoding, "エンコーディングの指定が必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");
            Assertion.Argument(bufferSize >= 4096, "バッファサイズは4096バイト以上必要です");

            return new TextDataRepository(path, encoding, cultureInfo, separator, format, bufferSize);
        }
        #endregion

        #region CreateToDoDataRepository
        /// <summary>
        /// 指定されたパスが示すフォルダ内のToDoファイルに対して入出力を行うリポジトリを生成します。
        /// </summary>
        /// <param name="path">対象のフォルダ又はファイルパス</param>
        /// <param name="cultureInfo">変換に使用するカルチャ情報</param>
        /// <param name="bufferSize">バッファサイズ</param>
        /// <returns>リポジトリのインスタンス</returns>
        /// <remarks>フォルダを指定した場合は、コンテキスト取得時にファイルへの相対パス又は絶対パスを指定出来ます。
        /// ファイルを指定した場合は、コンテキスト取得時にファイルへのパスを省略する事が出来ます。</remarks>
        public IDataSourceRepository CreateToDoDataRepository(
            string path,
            CultureInfo cultureInfo,
            int bufferSize)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(path) == false, "フォルダ又はファイルへのパスが必要です");
            Assertion.NullArgument(cultureInfo, "カルチャ情報が必要です");
            Assertion.Argument(bufferSize >= 4096, "バッファサイズは4096バイト以上必要です");

            return new ToDoDataRepository(path, cultureInfo, bufferSize);
        }
        #endregion

        #region CreateSpreadSheetDataRepository
        /// <summary>
        /// 指定されたパスが示すOpenXMLスプレッドシートファイルに対して入出力を行うリポジトリを生成します。
        /// </summary>
        /// <param name="filePath">対象のファイルのパス</param>
        /// <param name="cultureInfo">変換に使用するカルチャ情報</param>
        /// <param name="interpretHeader">先頭行をヘッダとして解釈する場合はtrue</param>
        /// <param name="createNotExist">ファイルが存在しない場合に生成する場合はtrue</param>
        /// <returns>リポジトリのインスタンス</returns>
        public IDataSourceRepository CreateSpreadSheetDataRepository(string filePath,
            CultureInfo cultureInfo,
            bool interpretHeader,
            bool createNotExist)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(filePath) == false, "ファイルへのパスが必要です");

            return new SpreadSheetDataRepository(filePath, cultureInfo, interpretHeader, createNotExist);
        }
        #endregion

        #region FormatMessage
        /// <summary>
        /// 指定されたメッセージIDからメッセージをフォーマットして取得します。
        /// </summary>
        /// <param name="messageID">メッセージID</param>
        /// <param name="args">メッセージのフォーマットに使用する引数群</param>
        /// <returns>フォーマットされた文字列</returns>
        public string FormatMessage(string messageID, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(messageID) == false, "メッセージコードが必要です");

            // メッセージマネージャが割り当てられていれば
            if (this._messageManager != null)
            {
                return this._messageManager.GetMessage(messageID, args);
            }
            else
            {
                // メッセージマネージャが割り当てられていない
                return string.Format(
                    "{0}: Not assigned module number: MessageCode={1}",
                    this.GetType().Name,
                    messageID);
            }
        }
        #endregion

        #region WriteLog
        /// <summary>
        /// ログを出力します。
        /// </summary>
        /// <param name="messageID">メッセージID</param>
        /// <param name="args">ログに出力するメッセージに適用する引数群</param>
        public void WriteLog(string messageID, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(messageID) == false, "メッセージコードが必要です");

            this._logger.WriteLog(messageID, args);
        }

        /// <summary>
        /// ログを出力します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="messageID">メッセージID</param>
        /// <param name="args">ログに出力するメッセージに適用する引数群</param>
        public void WriteLog(Exception ex, string messageID, params object[] args)
        {
            Debug.Assert(ex != null, "例外が指定されていません");
            Debug.Assert(string.IsNullOrWhiteSpace(messageID) == false, "メッセージコードが必要です");

            this._logger.WriteLog(ex, messageID, args);
        }

        /// <summary>
        /// ログを出力します。
        /// </summary>
        /// <param name="ex">CREOException例外</param>
        /// <returns>エラーコード</returns>
        public int WriteLog(CREOException ex)
        {
            Debug.Assert(ex != null, "例外が指定されていません");

            return this._logger.WriteLog(ex);
        }

        /// <summary>
        /// デバッグ用ログを出力します。
        /// </summary>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public void WriteDebugLog(string format, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列を指定する必要があります");

            this._logger.WriteDebugLog(format, args);
        }

        /// <summary>
        /// デバッグ用ログを出力します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public void WriteDebugLog(Exception ex, string format, params object[] args)
        {
            Debug.Assert(ex != null, "例外が指定されていません");
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列を指定する必要があります");

            this._logger.WriteDebugLog(ex, format, args);
        }

        /// <summary>
        /// トレース用ログを出力します。
        /// </summary>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public void WriteTraceLog(string format, params object[] args)
        {
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列を指定する必要があります");

            this._logger.WriteTraceLog(format, args);
        }

        /// <summary>
        /// トレース用ログを出力します。
        /// </summary>
        /// <param name="ex">例外</param>
        /// <param name="format">フォーマット文字列</param>
        /// <param name="args">追加引数群</param>
        public void WriteTraceLog(Exception ex, string format, params object[] args)
        {
            Debug.Assert(ex != null, "例外が指定されていません");
            Debug.Assert(string.IsNullOrWhiteSpace(format) == false, "フォーマット文字列を指定する必要があります");

            this._logger.WriteTraceLog(ex, format, args);
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.01 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データベースへのダイレクトアクセスを実行するアクセサクラスです。
    /// </summary>
    internal class DirectDatabaseAccessor : IDirectDatabaseAccessor, IDisposable
    {
        #region Fields
        /// <summary>
        /// IDbConnection
        /// </summary>
        private IDbConnection _connection;

        /// <summary>
        /// IDbCommand
        /// </summary>
        private IDbCommand _command;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="connection">データベース接続</param>
        public DirectDatabaseAccessor(IDbConnection connection)
        {
            Assertion.Condition(connection != null);

            this._connection = connection;
            this._command = this._connection.CreateCommand();
        }
        #endregion

        #region Dispose()
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public virtual void Dispose()
        {
            if (this._command != null)
            {
                this._command.Dispose();
                this._command = null;
            }

            this._connection = null;
        }
        #endregion

        #region BeginTransaction
        /// <summary>
        /// トランザクションを開始します。
        /// </summary>
        /// <param name="isolationLevel">分離レベル</param>
        /// <returns>トランザクションを示す新しいアクセサ</returns>
        public IDirectDatabaseTransactionContext BeginTransaction(
            IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            Assertion.Require(this._connection != null, "アクセサが無効です");

            var transaction = this._connection.BeginTransaction(isolationLevel);
            return new DirectDatabaseTransactionContext(this._connection, transaction);
        }
        #endregion

        #region Parameter
        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <returns>パラメータオブジェクト</returns>
        public IDbDataParameter Parameter(string name)
        {
            Assertion.Require(this._command != null, "アクセサが無効です");

            var parameter = this._command.CreateParameter();
            parameter.ParameterName = name;
            return parameter;
        }

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <param name="value">パラメータ値</param>
        /// <returns>パラメータオブジェクト</returns>
        public IDbDataParameter Parameter(string name, object value)
        {
            Assertion.Require(this._command != null, "アクセサが無効です");

            var parameter = this._command.CreateParameter();
            parameter.ParameterName = name;
            parameter.Value = value;
            return parameter;
        }

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <param name="type">パラメータのタイプ</param>
        /// <returns>パラメータオブジェクト</returns>
        public IDbDataParameter Parameter(string name, DbType type)
        {
            Assertion.Require(this._command != null, "アクセサが無効です");

            var parameter = this._command.CreateParameter();
            parameter.ParameterName = name;
            parameter.DbType = type;
            return parameter;
        }

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <param name="type">パラメータのタイプ</param>
        /// <param name="value">パラメータ値</param>
        /// <returns>パラメータオブジェクト</returns>
        public IDbDataParameter Parameter(string name, DbType type, object value)
        {
            Assertion.Require(this._command != null, "アクセサが無効です");

            var parameter = this._command.CreateParameter();
            parameter.ParameterName = name;
            parameter.DbType = type;
            parameter.Value = value;
            return parameter;
        }
        #endregion

        #region GetTransaction
        /// <summary>
        /// トランザクションオブジェクトを取得します。
        /// </summary>
        /// <returns>トランザクションオブジェクト</returns>
        protected virtual IDbTransaction GetTransaction()
        {
            return null;
        }
        #endregion

        #region CreateCommand
        /// <summary>
        /// コマンドオブジェクトを生成します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>コマンドオブジェクト</returns>
        private IDbCommand CreateCommand(string queryString, IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Condition(this._connection != null);

            var command = this._connection.CreateCommand();

            command.CommandType = CommandType.Text;
            command.CommandText = queryString;
            command.Transaction = this.GetTransaction();

            foreach (var parameter in parameters)
            {
                command.Parameters.Add(parameter);
            }

            return command;
        }
        #endregion

        #region ExecuteNonQuery
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>影響レコード数</returns>
        public int ExecuteNonQuery(string queryString, IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(queryString) == false, "クエリが必要です");
            Assertion.NullArgument(parameters, "パラメータ列挙子が必要です");
            Assertion.Require(this._connection != null, "アクセサが無効です");

            using (var command = this.CreateCommand(queryString, parameters))
            {
                return command.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>影響レコード数</returns>
        public int ExecuteNonQuery(string queryString, params IDbDataParameter[] parameters)
        {
            return this.ExecuteNonQuery(queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteScalar
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果</returns>
        public object ExecuteScalar(string queryString, IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(queryString) == false, "クエリが必要です");
            Assertion.NullArgument(parameters, "パラメータ列挙子が必要です");
            Assertion.Require(this._connection != null, "アクセサが無効です");

            using (var command = this.CreateCommand(queryString, parameters))
            {
                return command.ExecuteScalar();
            }
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果</returns>
        public object ExecuteScalar(string queryString, params IDbDataParameter[] parameters)
        {
            return this.ExecuteScalar(queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteReader
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果レコード群</returns>
        public IDataReader ExecuteReader(string queryString, IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(queryString) == false, "クエリが必要です");
            Assertion.NullArgument(parameters, "パラメータ列挙子が必要です");
            Assertion.Require(this._connection != null, "アクセサが無効です");

            using (var command = this.CreateCommand(queryString, parameters))
            {
                return command.ExecuteReader();
            }
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果レコード群</returns>
        public IDataReader ExecuteReader(string queryString, params IDbDataParameter[] parameters)
        {
            return this.ExecuteReader(queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteToDataTable
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果を格納する新しいデータテーブル</returns>
        public DataTable ExecuteToDataTable(string queryString, IEnumerable<IDbDataParameter> parameters)
        {
            var dataTable = new DataTable();
            dataTable.BeginLoadData();
            try
            {
                using (var reader = this.ExecuteReader(queryString, parameters))
                {
                    dataTable.Load(reader);
                }
            }
            finally
            {
                dataTable.EndLoadData();
            }

            return dataTable;
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果を格納する新しいデータテーブル</returns>
        public DataTable ExecuteToDataTable(string queryString, params IDbDataParameter[] parameters)
        {
            return this.ExecuteToDataTable(queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteAndStore
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataTable">結果を格納するデータテーブル</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        public void ExecuteAndStore(DataTable dataTable, string queryString, IEnumerable<IDbDataParameter> parameters)
        {
            dataTable.BeginLoadData();
            try
            {
                using (var reader = this.ExecuteReader(queryString, parameters))
                {
                    dataTable.Rows.Clear();
                    dataTable.Load(reader);
                }
            }
            finally
            {
                dataTable.EndLoadData();
            }
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataTable">結果を格納するデータテーブル</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        public void ExecuteAndStore(
            DataTable dataTable,
            string queryString,
            params IDbDataParameter[] parameters)
        {
            this.ExecuteAndStore(dataTable, queryString, (IEnumerable<IDbDataParameter>)parameters);
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataSet">結果を格納するデータセット</param>
        /// <param name="targetTableName">データテーブルを特定するデータセット内のテーブル名</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        public void ExecuteAndStore(
            DataSet dataSet,
            string targetTableName,
            string queryString,
            IEnumerable<IDbDataParameter> parameters)
        {
            var dataTable = dataSet.Tables[targetTableName];
            if (dataTable != null)
            {
                this.ExecuteAndStore(dataTable, queryString, parameters);
            }
            else
            {
                dataTable = this.ExecuteToDataTable(queryString, parameters);
                dataTable.TableName = targetTableName;
                dataSet.Tables.Add(dataTable);
            }
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataSet">結果を格納するデータセット</param>
        /// <param name="targetTableName">データテーブルを特定するデータセット内のテーブル名</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        public void ExecuteAndStore(
            DataSet dataSet,
            string targetTableName,
            string queryString,
            params IDbDataParameter[] parameters)
        {
            this.ExecuteAndStore(dataSet, targetTableName, queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteBulkCopy
        /// <summary>
        /// バルクコピーを実行します。
        /// </summary>
        /// <param name="targetTableName">ストア先のテーブル名</param>
        /// <param name="reader">データを供給するリーダ</param>
        /// <param name="batchSize">バッチレコードサイズ</param>
        /// <param name="options">オプション</param>
        /// <param name="iterationHandler">コピー中に生じる経過イベントのコールバック</param>
        /// <remarks>バルクコピーを実行する場合、プロバイダがSQL Serverに対して構成されていなければなりません。</remarks>
        public void ExecuteBulkCopy(
            string targetTableName,
            IDataReader reader,
            int batchSize = 50000,
            SqlBulkCopyOptions options = SqlBulkCopyOptions.Default,
            SqlRowsCopiedEventHandler iterationHandler = null)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(targetTableName) == false, "テーブル名が必要です");
            Assertion.NullArgument(reader, "データを供給するリーダが必要です");
            Assertion.Argument(batchSize >= 1, "バッチサイズは1以上である必要があります");
            Assertion.Require(this._connection != null, "アクセサが無効です");

            var sqlConnection = this._connection as SqlConnection;
            Assertion.Require(
                sqlConnection != null,
                "対象のプロバイダはSQL Serverではありません: Type={0}",
                this._connection.GetType().FullName);

            var transaction = this.GetTransaction();
            Assertion.Condition((transaction == null) || (transaction is SqlTransaction));

            using (var sbc = new SqlBulkCopy(sqlConnection, options, (SqlTransaction)transaction))
            {
                sbc.BatchSize = batchSize;
                sbc.DestinationTableName = targetTableName;
                sbc.NotifyAfter = batchSize;
                if (iterationHandler != null)
                {
                    sbc.SqlRowsCopied += iterationHandler;
                }

                sbc.WriteToServer(reader);
            }
        }
        #endregion
    }
}

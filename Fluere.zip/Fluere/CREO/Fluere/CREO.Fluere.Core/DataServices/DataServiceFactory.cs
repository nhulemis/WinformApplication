﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;

using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.Executive;
using CREO.Fluere.Common.Message.UF00000;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスを生成するファクトリクラスです。
    /// </summary>
    /// <remarks>データサービスを操作する処理の依存を分離するクラスを生成します。
    /// また、データソースとデータベースロールの対応を自動的に行い、その情報を取得可能にします。</remarks>
    public sealed class DataServiceFactory : IDataServiceFactory
    {
        #region Fields
        /// <summary>
        /// Lock
        /// </summary>
        private static readonly object LOCK = new object();

        /// <summary>
        /// DataSourceInformationHolder
        /// </summary>
        private static DataServiceDefinitionHolder _holder;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public DataServiceFactory()
        {
        }
        #endregion

        #region GetDataServiceDefinitionHolder
        /// <summary>
        /// DataServiceDefinitionHolderを取得します。
        /// </summary>
        /// <returns>DataServiceDefinitionHolderのインスタンス</returns>
        private static DataServiceDefinitionHolder GetDataServiceDefinitionHolder()
        {
            if (_holder == null)
            {
                lock (LOCK)
                {
                    if (_holder == null)
                    {
                        _holder = new DataServiceDefinitionHolder();
                    }
                }
            }

            return _holder;
        }
        #endregion

        #region InternalConnectToDataService
        /// <summary>
        /// データサービスに接続します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="dataSourceID">データソースID</param>
        /// <param name="workGroupID">ワークグループID</param>
        /// <param name="subWorkGroupID">サブワークグループID</param>
        /// <param name="transactionMode">トランザクションモード</param>
        /// <param name="useCache">キャッシュを使用するかどうか</param>
        /// <returns>データサービスのインスタンス</returns>
        internal static CREO.DS.DataService InternalConnectToDataService(
            string dataServiceID,
            string dataSourceID,
            ulong workGroupID,
            ulong subWorkGroupID,
            TransactionMode transactionMode,
            bool useCache) // TODO: DataServiceのuseCacheは廃止された為、このパラメータも削除する
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(dataServiceID) == false);
            Assertion.Condition(string.IsNullOrWhiteSpace(dataSourceID) == false);

            var definition =
                GetDataServiceDefinitionHolder().GetDataServiceDefinitions(DataServiceIDExtractTypes.All).Where(entry => entry.DataServiceID == dataServiceID).FirstOrDefault();

            var connectionString = (definition != null) ? definition.RawDataSourceInfo.GetDatabase() : null;

            var rawContext = new CREO.DS.DataSource.ConnectionContext();

            rawContext.DataSourceID = dataSourceID;
            rawContext.WorkGroupID = workGroupID;
            rawContext.SubWorkGroupID = subWorkGroupID;
            rawContext.UserGroup = CREO.FW.Logon.UserInformation.ADGroup.Cast<string>().ToArray();
            rawContext.UserID = CREO.FW.Logon.UserInformation.UserID;

            CREO.DS.DataService dataService = null;
            try
            {
                dataService = CREO.DS.DataService.Connect(rawContext);
            }
            catch (Exception ex)
            {
                // "データサービスに接続出来ません"
                throw new Uf00000026Exception(
                    ex,
                    dataServiceID,
                    dataSourceID,
                    workGroupID,
                    subWorkGroupID,
                    transactionMode.ToString(),
                    Thread.CurrentThread.ManagedThreadId,
                    (connectionString != null) ? string.Format("\"{0}\"", connectionString) : "(Unknown)");
            }

            Assertion.Condition(dataService != null);

            // プロパティ廃止の為、削除。
            // ※パラメータの「useCache」は別途削除する。
            ////dataService.UseCache = useCache;
            ////dataService.UseBulk = false;
            if (transactionMode == TransactionMode.Transacted)
            {
                dataService.BeginTransaction();
            }

            // "データサービスに接続しました"
            InternalLogger.Logger.WriteLogUf00000025(
                dataServiceID,
                dataSourceID,
                workGroupID,
                subWorkGroupID,
                transactionMode.ToString(),
                Thread.CurrentThread.ManagedThreadId,
                (connectionString != null) ? string.Format("\"{0}\"", connectionString) : "(Unknown)");

            return dataService;
        }
        #endregion

        #region GetDataSourceIDFromDataServiceID
        /// <summary>
        /// 指定されたデータサービスIDからデータソースIDを取得します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <returns>データソースID</returns>
        /// <remarks>通常、このメソッドは使用しません。
        /// データサービスの情報が必要な場合はGetDataServiceDefinitionsを使用します。
        /// また、データサービスへの接続はこのメソッドを使用せず、直接データサービスIDを使用します。</remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public string GetDataSourceIDFromDataServiceID(
            string dataServiceID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(dataServiceID) == false, "データサービスIDが必要です");

            if (idType == DataServiceIDTypes.DataSourceID)
            {
                return dataServiceID;
            }

            var dataServiceInformation =
                GetDataServiceDefinitionHolder().LookupFromDatabaseRoleID(dataServiceID);
            if (dataServiceInformation == null)
            {
                if (idType == DataServiceIDTypes.AutoFallBack)
                {
                    return dataServiceID;
                }

                throw new ArgumentException(string.Format(
                    "データベースロールIDに対応するデータソースIDが見つかりません: データベースロールID={0}",
                    dataServiceID));
            }

            return dataServiceInformation.RawDataSourceID;
        }
        #endregion

        #region GetDataServiceDefinitions
        /// <summary>
        /// 設定ファイルに定義されているデータサービス情報の一覧を取得します。
        /// </summary>
        /// <param name="extractTypes">抽出条件</param>
        /// <returns>データサービス情報の列挙子</returns>
        /// <remarks>引数の指定によって、フレームワークが管理するデータソースの一覧、
        /// 又はアプリケーション構成ファイルで指定されるデータベースロールの一覧、
        /// 又はその両方を取得する事が出来ます。</remarks>
        public IEnumerable<IDataServiceDefinition> GetDataServiceDefinitions(
            DataServiceIDExtractTypes extractTypes = DataServiceIDExtractTypes.DatabaseRoleID)
        {
            return GetDataServiceDefinitionHolder().GetDataServiceDefinitions(extractTypes);
        }
        #endregion

        #region PreBindDataService
        /// <summary>
        /// 事前バインドしたデータサービスファクトリを取得します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <param name="connectionPooling">接続プールを有効化する場合はtrue</param>
        /// <returns>事前バインドしたファクトリ</returns>
        /// <remarks>データサービスIDを事前に設定する事により、
        /// トランザクションの有無のみでデータサービスを生成する事が出来ます。
        /// 接続プールを有効化した場合は、同一のスレッドに対して同じデータサービスのインスタンスを返し、
        /// 異なるスレッドに対してユニークなデータサービスのインスタンスを返します。
        /// これにより、マルチスレッド動作時に高いパフォーマンスを維持し、かつデータサービスへの接続を最小化します。</remarks>
        public IPreBoundDataServiceFactory PreBindDataService(
            string dataServiceID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID,
            bool connectionPooling = true)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(dataServiceID) == false, "データサービスIDが必要です");

            var dataSourceID = this.GetDataSourceIDFromDataServiceID(dataServiceID, idType);
            return new PreBoundFactory(dataServiceID, dataSourceID, 0, 0, connectionPooling);
        }

        /// <summary>
        /// 事前バインドしたデータサービスファクトリを取得します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="workGroupID">ワークグループID</param>
        /// <param name="subWorkGroupID">サブワークグループID</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <param name="connectionPooling">接続プールを有効化する場合はtrue</param>
        /// <returns>事前バインドしたファクトリ</returns>
        /// <remarks>データサービスID・ワークグループID等を事前に設定する事により、
        /// トランザクションの有無のみでデータサービスを生成する事が出来ます。
        /// 接続プールを有効化した場合は、同一のスレッドに対して同じデータサービスのインスタンスを返し、
        /// 異なるスレッドに対してユニークなデータサービスのインスタンスを返します。
        /// これにより、マルチスレッド動作時に高いパフォーマンスを維持し、かつデータサービスへの接続を最小化します。</remarks>
        public IPreBoundDataServiceFactory PreBindDataService(
            string dataServiceID,
            ulong workGroupID,
            ulong subWorkGroupID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID,
            bool connectionPooling = true)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(dataServiceID) == false, "データサービスIDが必要です");

            var dataSourceID = this.GetDataSourceIDFromDataServiceID(dataServiceID, idType);
            return new PreBoundFactory(dataServiceID, dataSourceID, workGroupID, subWorkGroupID, connectionPooling);
        }
        #endregion

        #region ConnectToDataService
        /// <summary>
        /// データサービスに接続します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="transactionMode">トランザクションモード</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <returns>データサービスのインスタンス</returns>
        public CREO.DS.DataService ConnectToDataService(
            string dataServiceID,
            TransactionMode transactionMode,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(dataServiceID) == false, "データサービスIDが必要です");

            var dataSourceID = this.GetDataSourceIDFromDataServiceID(dataServiceID, idType);
            return InternalConnectToDataService(
                dataServiceID,
                dataSourceID,
                0,
                0,
                transactionMode,
                true); // TODO: DataServiceのuseCacheは廃止された為、このパラメータも削除する
        }

        /// <summary>
        /// データサービスに接続します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="workGroupID">ワークグループID</param>
        /// <param name="subWorkGroupID">サブワークグループID</param>
        /// <param name="transactionMode">トランザクションモード</param>
        /// <param name="idType">データサービスIDの種別</param>
        /// <returns>データサービスのインスタンス</returns>
        public CREO.DS.DataService ConnectToDataService(
            string dataServiceID,
            ulong workGroupID,
            ulong subWorkGroupID,
            TransactionMode transactionMode,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(dataServiceID) == false, "データサービスIDが必要です");

            var dataSourceID = this.GetDataSourceIDFromDataServiceID(dataServiceID, idType);
            return InternalConnectToDataService(
                dataServiceID,
                dataSourceID,
                workGroupID,
                subWorkGroupID,
                transactionMode,
                true); // TODO: DataServiceのuseCacheは廃止された為、このパラメータも削除する
        }
        #endregion
    }
}

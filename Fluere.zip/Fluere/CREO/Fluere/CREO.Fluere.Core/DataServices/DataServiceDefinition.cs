﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.29 TMI K.Matsui

using System;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスに関する情報を保持するクラスです。
    /// </summary>
    /// <remarks>フレームワークのデータソース情報と、データベースロールIDに紐づけられた情報を一元化します。
    /// このクラスはDataServiceDefinitionHolderクラスが内部的に使用します。</remarks>
    internal sealed class DataServiceDefinition : IDataServiceDefinition
    {
        #region Fields
        /// <summary>
        /// データサービスID
        /// </summary>
        private readonly string _dataServiceID;

        /// <summary>
        /// データサービスIDタイプ
        /// </summary>
        private readonly DataServiceIDTypes _idType;

        /// <summary>
        /// DataSourceInfo
        /// </summary>
        private readonly CREO.DS.DataSource.DataSourceInfo _rawDataSourceInfo;

        /// <summary>
        /// プロバイダ型
        /// </summary>
        private readonly Type _providerType;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDタイプ</param>
        /// <param name="rawDataSourceInfo">DataSourceInfo</param>
        /// <param name="providerType">プロバイダの型</param>
        private DataServiceDefinition(
            string dataServiceID,
            DataServiceIDTypes idType,
            CREO.DS.DataSource.DataSourceInfo rawDataSourceInfo,
            Type providerType)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(dataServiceID) == false);
            Assertion.Condition(rawDataSourceInfo != null);
            Assertion.Condition(providerType != null);

            this._dataServiceID = dataServiceID;
            this._idType = idType;
            this._rawDataSourceInfo = rawDataSourceInfo;
            this._providerType = providerType;
        }
        #endregion

        #region IDataServiceInformation
        /// <summary>
        /// データサービスIDを取得します。
        /// </summary>
        public string DataServiceID
        {
            get
            {
                return this._dataServiceID;
            }
        }

        /// <summary>
        /// データソースIDを取得します。
        /// </summary>
        /// <remarks>通常、DataServiceIDプロパティを使用します。</remarks>
        public string RawDataSourceID
        {
            get
            {
                return this._rawDataSourceInfo.Id;
            }
        }

        /// <summary>
        /// データサービスIDタイプを取得します。
        /// </summary>
        public DataServiceIDTypes IDType
        {
            get
            {
                return this._idType;
            }
        }

        /// <summary>
        /// キャプションを取得します。
        /// </summary>
        public string Caption
        {
            get
            {
                return this._rawDataSourceInfo.Caption;
            }
        }

        /// <summary>
        /// コメントを取得します。
        /// </summary>
        public string Comment
        {
            get
            {
                return this._rawDataSourceInfo.Comment;
            }
        }

        /// <summary>
        /// データサービスに対応するプロバイダの型を取得します。
        /// </summary>
        public Type ProviderType
        {
            get
            {
                return this._providerType;
            }
        }
        #endregion

        #region RawDataSourceInfo
        /// <summary>
        /// DataSourceInfoを取得します。
        /// </summary>
        public CREO.DS.DataSource.DataSourceInfo RawDataSourceInfo
        {
            get
            {
                return this._rawDataSourceInfo;
            }
        }
        #endregion

        #region Create
        /// <summary>
        /// インスタンスを生成します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDタイプ</param>
        /// <param name="rawDataSourceInfo">DataSourceInfo</param>
        /// <param name="providerType">プロバイダの型</param>
        /// <returns>インスタンス</returns>
        public static DataServiceDefinition Create(
            string dataServiceID,
            DataServiceIDTypes idType,
            CREO.DS.DataSource.DataSourceInfo rawDataSourceInfo,
            Type providerType)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(dataServiceID) == false);
            Assertion.Condition(rawDataSourceInfo != null);

            if (providerType == null)
            {
                var providerName = rawDataSourceInfo.GetProvider();
                if (string.IsNullOrWhiteSpace(providerName) == true)
                {
                    return null;
                }

                // モジュールのロードが行われ、プロバイダ名が認識されていても、インスタンス生成に失敗する事がある。
                // しかし、例外に対するフォローが無いため、そのままスローされてくる。
                // （主に定義体のプロバイダ名指定ミス）
                // 救いようがないのでそのままスローさせ、呼び出し元で処理する。
                // （プロバイダ名が見つからない場合はnullが返されるので、下で例外に変換する）
                var dataProvider = CREO.DS.DataProvider.DataProviderManager.Current.CreateDataProvider(providerName);

                Assertion.Require(
                    dataProvider != null,
                    "データプロバイダが見つかりません: DataSourceID={0}",
                    rawDataSourceInfo.Id);

                providerType = dataProvider.GetType();
            }

            return new DataServiceDefinition(dataServiceID, idType, rawDataSourceInfo, providerType);
        }
        #endregion

        #region Overrides
        /// <summary>
        /// インスタンスの文字列表現を取得します。
        /// </summary>
        /// <returns>文字列</returns>
        public override string ToString()
        {
            return string.Format(
                "DataServiceID={0}, DataSourceID={1}, IDType={2}, Caption={3}, Comment={4}, ProviderType={5}",
                this._dataServiceID,
                this._rawDataSourceInfo.Id,
                this._idType,
                this._rawDataSourceInfo.Caption,
                this._rawDataSourceInfo.Comment,
                this._providerType.FullName);
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012/11/13 14:15:12 MAPMASTER matsuiko

using System;
using System.Collections;
using System.Collections.Generic;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// 比較演算子の判定方向を指定する列挙値です。
    /// </summary>
    public enum CoordinateCompareDirections
    {
        /// <summary>
        /// 昇順で判定します。
        /// </summary>
        Ascending,

        /// <summary>
        /// 降順で判定します。
        /// </summary>
        Descending
    }

    /// <summary>
    /// Coordinate・CoordinateDクラスの比較演算子です。
    /// </summary>
    /// <remarks>Coordinateクラスの比較演算を実装し、辞書化を可能にします。</remarks>
    public class CoordinateEqualityComparer
        : IEqualityComparer<CREO.FW.TMIGeometry.Coordinate>,
        IEqualityComparer<CREO.FW.TMIGeometry.CoordinateD>,
        IEqualityComparer
    {
        #region Fields
        /// <summary>
        /// デフォルトのインスタンス
        /// </summary>
        private static readonly CoordinateEqualityComparer DEFAULT = new CoordinateEqualityComparer();
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        internal CoordinateEqualityComparer()
        {
        }
        #endregion

        #region Default
        /// <summary>
        /// デフォルトのインスタンスを取得します。
        /// </summary>
        public static CoordinateEqualityComparer Default
        {
            get
            {
                return DEFAULT;
            }
        }
        #endregion

        #region CREO.FW.TMIGeometry.Coordinate
        /// <summary>
        /// Coordinateを比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>一致していればtrue</returns>
        public bool Equals(CREO.FW.TMIGeometry.Coordinate lhs, CREO.FW.TMIGeometry.Coordinate rhs)
        {
            return lhs.Longitude.Equals(rhs.Longitude) && lhs.Latitude.Equals(rhs.Latitude);
        }

        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <param name="obj">インスタンス</param>
        /// <returns>ハッシュコード</returns>
        public int GetHashCode(CREO.FW.TMIGeometry.Coordinate obj)
        {
            return obj.Longitude.GetHashCode() ^ obj.Latitude.GetHashCode();
        }
        #endregion

        #region CREO.FW.TMIGeometry.CoordinateD
        /// <summary>
        /// CoordinateDを比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>一致していればtrue</returns>
        public bool Equals(CREO.FW.TMIGeometry.CoordinateD lhs, CREO.FW.TMIGeometry.CoordinateD rhs)
        {
            return lhs.Longitude.Equals(rhs.Longitude) && lhs.Latitude.Equals(rhs.Latitude);
        }

        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <param name="obj">インスタンス</param>
        /// <returns>ハッシュコード</returns>
        public int GetHashCode(CREO.FW.TMIGeometry.CoordinateD obj)
        {
            return obj.Longitude.GetHashCode() ^ obj.Latitude.GetHashCode();
        }
        #endregion

        #region Non generic implementations
        /// <summary>
        /// インスタンスが同一かどうかを確認します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>同一ならtrue</returns>
        bool IEqualityComparer.Equals(object lhs, object rhs)
        {
            var llhs = lhs as CREO.FW.TMIGeometry.Coordinate;
            var lrhs = rhs as CREO.FW.TMIGeometry.Coordinate;
            if ((llhs != null) && (lrhs != null))
            {
                return this.Equals(llhs, lrhs);
            }

            var dlhs = lhs as CREO.FW.TMIGeometry.CoordinateD;
            var drhs = rhs as CREO.FW.TMIGeometry.CoordinateD;
            if ((dlhs != null) && (drhs != null))
            {
                return this.Equals(dlhs, drhs);
            }

            return false;
        }

        /// <summary>
        /// 指定されたインスタンスのハッシュコードを取得します。
        /// </summary>
        /// <param name="obj">インスタンス</param>
        /// <returns>ハッシュコード</returns>
        int IEqualityComparer.GetHashCode(object obj)
        {
            var lobj = obj as CREO.FW.TMIGeometry.Coordinate;
            if (lobj != null)
            {
                return this.GetHashCode(lobj);
            }

            var dobj = obj as CREO.FW.TMIGeometry.CoordinateD;
            if (dobj != null)
            {
                return this.GetHashCode(dobj);
            }

            throw new ArgumentException();
        }
        #endregion
    }

    /// <summary>
    /// Coordinate・CoordinateDクラス・IPointインターフェイスの比較演算子です。
    /// </summary>
    /// <remarks>Coordinateクラスの比較演算を実装し、辞書化・ソート等を可能にします。
    /// このクラスは、経度→緯度の順に比較を行います。</remarks>
    public sealed class LongitudePriorityCoordinateComparer
        : CoordinateEqualityComparer,
        IComparer<CREO.FW.TMIGeometry.Coordinate>,
        IComparer<CREO.FW.TMIGeometry.CoordinateD>,
        IComparer<IPoint>,
        IComparer
    {
        #region Fields
        /// <summary>
        /// 経度符号を決定する演算子
        /// </summary>
        private readonly bool _longitudeAscending;

        /// <summary>
        /// 緯度符号を決定する演算子
        /// </summary>
        private readonly bool _latitudeAscending;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="longitudeDirection">経度の比較判定方向</param>
        /// <param name="latitudeDirection">緯度の比較判定方向</param>
        public LongitudePriorityCoordinateComparer(
            CoordinateCompareDirections longitudeDirection,
            CoordinateCompareDirections latitudeDirection)
        {
            this._longitudeAscending = longitudeDirection == CoordinateCompareDirections.Ascending;
            this._latitudeAscending = latitudeDirection == CoordinateCompareDirections.Ascending;
        }
        #endregion

        #region CREO.FW.TMIGeometry.Coordinate
        /// <summary>
        /// Coordinateを比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>座標の辞書順の値。</returns>
        public int Compare(FW.TMIGeometry.Coordinate lhs, FW.TMIGeometry.Coordinate rhs)
        {
            if (this._longitudeAscending == true)
            {
                var result = lhs.Longitude.CompareTo(rhs.Longitude);
                if (result != 0)
                {
                    return result;
                }
            }
            else
            {
                var result = rhs.Longitude.CompareTo(lhs.Longitude);
                if (result != 0)
                {
                    return result;
                }
            }

            if (this._latitudeAscending == true)
            {
                return lhs.Latitude.CompareTo(rhs.Latitude);
            }
            else
            {
                return rhs.Latitude.CompareTo(lhs.Latitude);
            }
        }
        #endregion

        #region CREO.FW.TMIGeometry.CoordinateD
        /// <summary>
        /// CoordinateDを比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>座標の辞書順の値。</returns>
        public int Compare(CREO.FW.TMIGeometry.CoordinateD lhs, CREO.FW.TMIGeometry.CoordinateD rhs)
        {
            if (this._longitudeAscending == true)
            {
                var result = lhs.Longitude.CompareTo(rhs.Longitude);
                if (result != 0)
                {
                    return result;
                }
            }
            else
            {
                var result = rhs.Longitude.CompareTo(lhs.Longitude);
                if (result != 0)
                {
                    return result;
                }
            }

            if (this._latitudeAscending == true)
            {
                return lhs.Latitude.CompareTo(rhs.Latitude);
            }
            else
            {
                return rhs.Latitude.CompareTo(lhs.Latitude);
            }
        }
        #endregion

        #region IPoint
        /// <summary>
        /// IPointを比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>座標の辞書順の値。</returns>
        public int Compare(IPoint lhs, IPoint rhs)
        {
            if (this._longitudeAscending == true)
            {
                var result = lhs.X.CompareTo(rhs.X);
                if (result != 0)
                {
                    return result;
                }
            }
            else
            {
                var result = rhs.X.CompareTo(lhs.X);
                if (result != 0)
                {
                    return result;
                }
            }

            if (this._latitudeAscending == true)
            {
                return lhs.Y.CompareTo(rhs.Y);
            }
            else
            {
                return rhs.Y.CompareTo(lhs.Y);
            }
        }
        #endregion

        #region Non generic implementations
        /// <summary>
        /// 指定したインスタンスを辞書順で比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>辞書順の値</returns>
        int IComparer.Compare(object lhs, object rhs)
        {
            var llhs = lhs as CREO.FW.TMIGeometry.Coordinate;
            var lrhs = rhs as CREO.FW.TMIGeometry.Coordinate;
            if ((llhs != null) && (lrhs != null))
            {
                return this.Compare(llhs, lrhs);
            }

            var dlhs = lhs as CREO.FW.TMIGeometry.CoordinateD;
            var drhs = rhs as CREO.FW.TMIGeometry.CoordinateD;
            if ((dlhs != null) && (drhs != null))
            {
                return this.Compare(dlhs, drhs);
            }

            var plhs = lhs as IPoint;
            var prhs = rhs as IPoint;
            if ((plhs != null) && (prhs != null))
            {
                return this.Compare(plhs, prhs);
            }

            throw new ArgumentException();
        }
        #endregion
    }

    /// <summary>
    /// Coordinate・CoordinateDクラス・IPointインターフェイスの比較演算子です。
    /// </summary>
    /// <remarks>Coordinateクラスの比較演算を実装し、辞書化・ソート等を可能にします。
    /// このクラスは、緯度→経度の順に比較を行います。</remarks>
    public sealed class LatitudePriorityCoordinateComparer
        : CoordinateEqualityComparer,
        IComparer<CREO.FW.TMIGeometry.Coordinate>,
        IComparer<CREO.FW.TMIGeometry.CoordinateD>,
        IComparer<IPoint>,
        IComparer
    {
        #region Fields
        /// <summary>
        /// 経度符号を決定する演算子
        /// </summary>
        private readonly bool _longitudeAscending;

        /// <summary>
        /// 緯度符号を決定する演算子
        /// </summary>
        private readonly bool _latitudeAscending;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="longitudeDirection">経度の比較判定方向</param>
        /// <param name="latitudeDirection">緯度の比較判定方向</param>
        public LatitudePriorityCoordinateComparer(
            CoordinateCompareDirections longitudeDirection,
            CoordinateCompareDirections latitudeDirection)
        {
            this._longitudeAscending = longitudeDirection == CoordinateCompareDirections.Ascending;
            this._latitudeAscending = latitudeDirection == CoordinateCompareDirections.Ascending;
        }
        #endregion

        #region CREO.FW.TMIGeometry.Coordinate
        /// <summary>
        /// Coordinateを比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>座標の辞書順の値。</returns>
        public int Compare(FW.TMIGeometry.Coordinate lhs, FW.TMIGeometry.Coordinate rhs)
        {
            if (this._latitudeAscending == true)
            {
                var result = lhs.Latitude.CompareTo(rhs.Latitude);
                if (result != 0)
                {
                    return result;
                }
            }
            else
            {
                var result = rhs.Latitude.CompareTo(lhs.Latitude);
                if (result != 0)
                {
                    return result;
                }
            }

            if (this._longitudeAscending == true)
            {
                return lhs.Longitude.CompareTo(rhs.Longitude);
            }
            else
            {
                return rhs.Longitude.CompareTo(lhs.Longitude);
            }
        }
        #endregion

        #region CREO.FW.TMIGeometry.CoordinateD
        /// <summary>
        /// CoordinateDを比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>座標の辞書順の値。</returns>
        public int Compare(CREO.FW.TMIGeometry.CoordinateD lhs, CREO.FW.TMIGeometry.CoordinateD rhs)
        {
            if (this._latitudeAscending == true)
            {
                var result = lhs.Latitude.CompareTo(rhs.Latitude);
                if (result != 0)
                {
                    return result;
                }
            }
            else
            {
                var result = rhs.Latitude.CompareTo(lhs.Latitude);
                if (result != 0)
                {
                    return result;
                }
            }

            if (this._longitudeAscending == true)
            {
                return lhs.Longitude.CompareTo(rhs.Longitude);
            }
            else
            {
                return rhs.Longitude.CompareTo(lhs.Longitude);
            }
        }
        #endregion

        #region IPoint
        /// <summary>
        /// IPointを比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>座標の辞書順の値。</returns>
        public int Compare(IPoint lhs, IPoint rhs)
        {
            if (this._latitudeAscending == true)
            {
                var result = lhs.Y.CompareTo(rhs.Y);
                if (result != 0)
                {
                    return result;
                }
            }
            else
            {
                var result = rhs.Y.CompareTo(lhs.Y);
                if (result != 0)
                {
                    return result;
                }
            }

            if (this._longitudeAscending == true)
            {
                return lhs.X.CompareTo(rhs.X);
            }
            else
            {
                return rhs.X.CompareTo(lhs.X);
            }
        }
        #endregion

        #region Non generic implementations
        /// <summary>
        /// 指定したインスタンスを辞書順で比較します。
        /// </summary>
        /// <param name="lhs">比較元</param>
        /// <param name="rhs">比較先</param>
        /// <returns>辞書順の値</returns>
        int IComparer.Compare(object lhs, object rhs)
        {
            var llhs = lhs as CREO.FW.TMIGeometry.Coordinate;
            var lrhs = rhs as CREO.FW.TMIGeometry.Coordinate;
            if ((llhs != null) && (lrhs != null))
            {
                return this.Compare(llhs, lrhs);
            }

            var dlhs = lhs as CREO.FW.TMIGeometry.CoordinateD;
            var drhs = rhs as CREO.FW.TMIGeometry.CoordinateD;
            if ((dlhs != null) && (drhs != null))
            {
                return this.Compare(dlhs, drhs);
            }

            var plhs = lhs as IPoint;
            var prhs = rhs as IPoint;
            if ((plhs != null) && (prhs != null))
            {
                return this.Compare(plhs, prhs);
            }

            throw new ArgumentException();
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Security;
using CREO.Fluere.Common.Diagnostics;
using Microsoft.SqlServer.Types;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするラップクラスです。
    /// </summary>
    /// <remarks>ICollectionを実装し、LINQクエリを高速化します。</remarks>
    [Serializable]
    internal sealed class Polygon : GeometryBase, IPolygon, ICollection<IRing>, ICollection
    {
        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="sqlGeometry">SqlGeometry</param>
        public Polygon(SqlGeometry sqlGeometry)
            : base(sqlGeometry)
        {
#if DEBUG
            var type = this.GeometryStructureType;
            Assertion.Condition((type == GeometryStructureTypes.Empty) || (type == GeometryStructureTypes.Single) || (type == GeometryStructureTypes.Point));
#endif
        }

        /// <summary>
        /// 逆シリアル化コンストラクタです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecurityCritical]
        private Polygon(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
        #endregion

        #region Count
        /// <summary>
        /// 内包するリング数を取得します。
        /// </summary>
        public int Count
        {
            get
            {
                var type = this.GeometryStructureType;

                if (type == GeometryStructureTypes.Empty)
                {
                    return 0;
                }

                if (type == GeometryStructureTypes.Single)
                {
                    return this.GEOMETRY.STNumInteriorRing().Value + 1;
                }

                return 1;
            }
        }
        #endregion

        #region Indexer
        /// <summary>
        /// インデックスを指定して、リングを取得します。
        /// </summary>
        /// <param name="index">インデックス</param>
        /// <returns>リング</returns>
        public IRing this[int index]
        {
            get
            {
                var type = this.GeometryStructureType;

                Assertion.Argument<ArgumentOutOfRangeException>(
                    type != GeometryStructureTypes.Empty,
                    "インスタンスは空です");

                if (type == GeometryStructureTypes.Single)
                {
                    Assertion.Argument<ArgumentOutOfRangeException>(
                        index <= this.GEOMETRY.STNumInteriorRing().Value,
                        "インデックスは範囲外です");

                    if (index == 0)
                    {
                        return new Ring(this.GEOMETRY.STExteriorRing());
                    }
                    else
                    {
                        return new Ring(this.GEOMETRY.STInteriorRingN(index));
                    }
                }

                Assertion.Argument<ArgumentOutOfRangeException>(
                    index == 0,
                    "インデックスは範囲外です");

                return new Ring(this.GEOMETRY);
            }
        }
        #endregion

        #region ToCoordinateCollection
        /// <summary>
        /// ポリゴンをCoordinateの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        /// <remarks>返却する列挙子は、リングを表現出来ません。
        /// そのため、内包するポリゴンに複数のリングが含まれている場合、例外がスローされます。</remarks>
        public IEnumerable<CREO.FW.TMIGeometry.Coordinate> ToCoordinateCollection()
        {
            var count = this.Count;

            Assertion.Require(count <= 1, "複数のリングが存在します");

            if (count == 0)
            {
                return Enumerable.Empty<CREO.FW.TMIGeometry.Coordinate>();
            }

            return this[0].ToCoordinateCollection();
        }
        #endregion

        #region ToCoordinateDCollection
        /// <summary>
        /// ポリゴンをCoordinateDの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        /// <remarks>返却する列挙子は、リングを表現出来ません。
        /// そのため、内包するポリゴンに複数のリングが含まれている場合、例外がスローされます。</remarks>
        public IEnumerable<CREO.FW.TMIGeometry.CoordinateD> ToCoordinateDCollection()
        {
            var count = this.Count;

            Assertion.Require(count <= 1, "複数のリングが存在します");

            if (count == 0)
            {
                return Enumerable.Empty<CREO.FW.TMIGeometry.CoordinateD>();
            }

            return this[0].ToCoordinateDCollection();
        }
        #endregion

        #region ToCoordinateRect
        /// <summary>
        /// ポリゴンをCoordinateRectに変換します。
        /// </summary>
        /// <returns>CoordinateRect</returns>
        /// <remarks>返却するCoordinateRectは、四角形でないポリゴンやリングを表現出来ません。
        /// そのため、これらのポリゴンが含まれている場合、例外がスローされます。</remarks>
        public CREO.FW.TMIGeometry.CoordinateRect ToCoordinateRect()
        {
            var count = this.Count;

            Assertion.Require(count <= 1, "複数のリングが存在します");

            if (count == 0)
            {
                throw new InvalidOperationException("インスタンスが空です");
            }

            return this[0].ToCoordinateRect();
        }
        #endregion

        #region ToCompositePolygon
        /// <summary>
        /// ポリゴンをCompositePolygonに変換します。
        /// </summary>
        /// <returns>CompositePolygon</returns>
        public CREO.FW.TMIGeometry.CompositePolygon ToCompositePolygon()
        {
            var result = new CREO.FW.TMIGeometry.CompositePolygon();

            var count = this.Count;
            if (count >= 1)
            {
                result.OuterRing.AddRange(this[0].ToCoordinateCollection());
                for (var index = 1; index < count; index++)
                {
                    result.InnerRingAry.Add(this[index].ToCoordinateCollection().ToList());
                }
            }

            return result;
        }
        #endregion

        #region Transform
        /// <summary>
        /// 指定したアフィン変換演算子を適用します。
        /// </summary>
        /// <param name="matrix">アフィン変換演算子を示す行列</param>
        /// <returns>形状</returns>
        public override IMultiPolygon TransformBy(System.Windows.Media.Matrix matrix)
        {
            // TODO: MultiLineString, LineString, MultiPoint
            var gb = new SqlGeometryBuilder();
            gb.SetSrid(GeometryBase.SRID);

            bool foundRing = false;
            foreach (var ring in this)
            {
                var points = ring.Select(point => new System.Windows.Point(point.X, point.Y)).ToArray();
                if (points.Length >= 1)
                {
                    matrix.Transform(points);

                    bool foundPoint = false;
                    for (var index = 0; index < points.Length; index++)
                    {
                        if (foundRing == false)
                        {
                            gb.BeginGeometry(OpenGisGeometryType.MultiPolygon);
                            gb.BeginGeometry(OpenGisGeometryType.Polygon);
                            foundRing = true;
                        }

                        if (foundPoint == false)
                        {
                            gb.BeginFigure(points[0].X, points[0].Y, null, null);
                            foundPoint = true;
                        }
                        else
                        {
                            gb.AddLine(points[index].X, points[index].Y, null, null);
                        }
                    }

                    if (foundPoint == true)
                    {
                        gb.EndFigure();
                    }
                }
            }

            if (foundRing == true)
            {
                gb.EndGeometry();
                gb.EndGeometry();
            }

            return new MultiPolygon(gb.ConstructedGeometry);
        }
        #endregion

        #region GetEnumerator
        /// <summary>
        /// ポリゴンの列挙子を取得します。
        /// </summary>
        /// <returns>列挙子</returns>
        public IEnumerator<IRing> GetEnumerator()
        {
            var type = this.GeometryStructureType;

            if (type == GeometryStructureTypes.Empty)
            {
                yield break;
            }

            if (type == GeometryStructureTypes.Single)
            {
                yield return new Ring(this.GEOMETRY.STExteriorRing());

                for (int index = 1, count = this.GEOMETRY.STNumInteriorRing().Value; index <= count; index++)
                {
                    yield return new Ring(this.GEOMETRY.STInteriorRingN(index));
                }

                yield break;
            }

            yield return new Ring(this.GEOMETRY);
        }

        /// <summary>
        /// ポリゴンの列挙子を取得します。
        /// </summary>
        /// <returns>列挙子</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion

        #region ICollection
        /// <summary>
        /// インスタンスを追加します。
        /// </summary>
        /// <param name="item">対象のインスタンス</param>
        /// <remarks>実装されていません。</remarks>
        void ICollection<IRing>.Add(IRing item)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// インスタンスが含まれているかどうかを確認します。
        /// </summary>
        /// <param name="item">対象のインスタンス</param>
        /// <returns>なし</returns>
        /// <remarks>実装されていません。</remarks>
        bool ICollection<IRing>.Contains(IRing item)
        {
            return this.Any(ring => ring.Equals(item));
        }

        /// <summary>
        /// 内容を配列にコピーします。
        /// </summary>
        /// <param name="array">配列</param>
        /// <param name="arrayIndex">インデックス</param>
        /// <remarks>実装されていません。</remarks>
        void ICollection<IRing>.CopyTo(IRing[] array, int arrayIndex)
        {
            var index = arrayIndex;
            foreach (var ring in this)
            {
                array[index] = ring;
                index++;
            }
        }

        /// <summary>
        /// 内容を配列にコピーします。
        /// </summary>
        /// <param name="array">配列</param>
        /// <param name="arrayIndex">インデックス</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public override void CopyTo(Array array, int arrayIndex)
        {
            var realArray = (IRing[])array;
            var index = arrayIndex;
            foreach (var ring in this)
            {
                realArray[index] = ring;
                index++;
            }
        }

        /// <summary>
        /// インスタンスを削除します。
        /// </summary>
        /// <param name="item">対象のインスタンス</param>
        /// <returns>なし</returns>
        /// <remarks>実装されていません。</remarks>
        bool ICollection<IRing>.Remove(IRing item)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.06 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Linq;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    #region ConditionalClause
    /// <summary>
    /// 検索条件を示す基底クラスです。
    /// </summary>
    /// <typeparam name="T">結果を示す型</typeparam>
    /// <remarks>Conditional.Ofメソッド群が返すインスタンスの基底クラスです。
    /// このクラスを継承し、検索条件に対応する、タイプセーフなメソッドチェインが記述出来るようにします。</remarks>
    /// <example>
    /// <code>
    /// // メッシュコードを限定してSCrsMainを取得し、05表示交差点番号を列挙する
    /// var meshCode = 623654;
    /// var result1 =
    ///     (from sCrsMain in
    ///         Conditional.
    ///             OfRange&lt;CREO.DataModel.SCrsMain&gt;(meshCode).   // ConditionalClause&lt;CREO.DataModel.SCrsMain&gt;を継承したクラスを取得
    ///             From(dataService).  // 指定されたデータサービスで、検索条件を遅延実行する
    ///             AsParallel()
    ///      where sCrsMain.Geometry.GetMeshCode() == meshCode
    ///      from tmiCrsNo in sCrsMain.Crs05MMNoAry
    ///      where tmiCrsNo.MeshNo == meshCode
    ///      select tmiCrsNo.CrsNo).
    ///      Distinct();
    /// </code>
    /// </example>
    public abstract class ConditionalClause<T>
        where T : CREO.DataModel.GeoItem
    {
        #region Fields
        /// <summary>
        /// TypeIDに相当する型リスト
        /// </summary>
        protected internal readonly HashSet<Type> Types;

        /// <summary>
        /// クエリ条件
        /// </summary>
        protected internal CREO.DS.QueryItemsCondition Condition;

        /// <summary>
        /// 出力フィルタ
        /// </summary>
        protected internal Func<IEnumerable<T>, IEnumerable<T>> Filter;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        internal ConditionalClause()
        {
            this.Condition = new CREO.DS.QueryItemsCondition();
            this.Types = new HashSet<Type>();
            this.Types.Add(typeof(T));
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="condition">元となる検索条件</param>
        /// <param name="types">TypeIDに相当する型リスト</param>
        internal ConditionalClause(CREO.DS.QueryItemsCondition condition, HashSet<Type> types)
        {
            this.Condition = condition;
            this.Types = types;
        }
        #endregion

        #region FixQueryItemsCondition
        /// <summary>
        /// QueryItemsConditionの検索条件を修正します。
        /// </summary>
        private void FixQueryItemsCondition()
        {
            Assertion.Condition(this.Condition != null);

            // 型リストを反映させる
            this.Condition.TypeIDs.Clear();
            this.Condition.TypeIDs.AddRange(
                from type in this.Types
                where
                    (from targetType in this.Types
                     where (type != targetType) && type.IsAssignableFrom(targetType)  // 自分以外で代入互換がある
                     select targetType).Any() == false  // 代入互換のある型が存在しない（より基底への型を排除）
                select type.Name);
        }
        #endregion

        #region ApplyFilter
        /// <summary>
        /// 列挙子にフィルタメソッドを適用します。
        /// </summary>
        /// <param name="from">処理前の列挙子</param>
        /// <returns>処理後の列挙子</returns>
        private IEnumerable<T> ApplyFilter(IEnumerable<T> from)
        {
            Assertion.Condition(from != null);

            return (Filter != null) ? Filter(from) : from;
        }
        #endregion

        #region From
        /// <summary>
        /// 指定されたデータサービスファクトリを使用して、クエリを実行可能にします。
        /// </summary>
        /// <param name="preBoundFactory">事前バインドされたデータサービスファクトリ</param>
        /// <param name="meshType">エリア分割で使用するメッシュタイプ。nullの場合はエリア分割しない</param>
        /// <param name="pipelineQueueCount">パイプラインキューサイズ</param>
        /// <returns>結果を示す列挙子</returns>
        /// <remarks>実際のクエリ実行は、結果が列挙されるまで遅延されます。
        /// フェッチはパイプライン化され、逐次実行が可能です。但し、トランザクションは使用出来ず、読み取り専用で、キャッシュされません。
        /// キャッシュが必要な場合は、Executeを使用する必要があります。</remarks>
        /// <example>
        /// <code>
        /// // 指定されたSCrsMainと位相関係にあるSRoadMainのうち、05探索交差点が存在するものを列挙する
        /// CREO.DataModel.SCrsMain sCrsMain = ...;
        /// var result2 =
        ///     from sRoadMain in
        ///         Conditional.
        ///             OfPositionShared&lt;CREO.DataModel.SRoadMain&gt;(sCrsMain).
        ///             From(preBoundFactory).  // 事前バインドされたデータサービスファクトリを使用する（実行は遅延）
        ///             AsParallel()
        ///     where sRoadMain.Road05GuideNoAry.Any()
        ///     select sRoadMain;
        /// </code>
        /// </example>
        public IEnumerable<T> From(
            IPreBoundDataServiceFactory preBoundFactory,
            int? meshType = 0,
            int pipelineQueueCount = 10000)
        {
            Assertion.NullArgument(preBoundFactory, "事前バインドされたデータサービスファクトリが必要です");
            Assertion.Argument(pipelineQueueCount >= 1, "キューサイズは1以上である必要があります");

            if (this.Condition == null)
            {
                return new T[0];
            }

            this.FixQueryItemsCondition();

            return this.ApplyFilter(preBoundFactory.QueryItemsPipelined<T>(this.Condition, meshType, pipelineQueueCount));
        }

        /// <summary>
        /// 指定されたデータサービスを使用して、クエリを実行可能にします。
        /// </summary>
        /// <param name="dataService">データサービス</param>
        /// <param name="meshType">エリア分割で使用するメッシュタイプ。nullの場合はエリア分割しない</param>
        /// <param name="pipelineQueueCount">パイプラインキューサイズ</param>
        /// <returns>結果を示す列挙子</returns>
        /// <remarks>実際のクエリ実行は、結果が列挙されるまで遅延されます。
        /// フェッチはパイプライン化され、逐次実行が可能です。但し、読み取り専用で、キャッシュされません。
        /// キャッシュが必要な場合は、Executeを使用する必要があります。</remarks>
        /// <example>
        /// <code>
        /// // 指定されたSCrsMainと位相関係にあるSRoadMainのうち、05探索交差点が存在するものを列挙する
        /// CREO.DataModel.SCrsMain sCrsMain = ...;
        /// var result2 =
        ///     from sRoadMain in
        ///         Conditional.
        ///             OfPositionShared&lt;CREO.DataModel.SRoadMain&gt;(sCrsMain).
        ///             From(dataService).  // 指定したデータサービスを使用する（実行は遅延）
        ///             AsParallel()
        ///     where sRoadMain.Road05GuideNoAry.Any()
        ///     select sRoadMain;
        /// </code>
        /// </example>
        public IEnumerable<T> From(
            CREO.DS.DataService dataService,
            int? meshType = 0,
            int pipelineQueueCount = 10000)
        {
            Assertion.NullArgument(dataService, "データサービスが必要です");
            Assertion.Argument(pipelineQueueCount >= 1, "キューサイズは1以上である必要があります");

            if (this.Condition == null)
            {
                return new T[0];
            }

            this.FixQueryItemsCondition();

            return this.ApplyFilter(dataService.QueryItemsPipelined<T>(this.Condition, meshType, pipelineQueueCount));
        }
        #endregion

        #region Execute
        /// <summary>
        /// 指定されたデータサービスファクトリを使用して、クエリをその場で実行します。
        /// </summary>
        /// <param name="preBoundFactory">事前バインドされたデータサービスファクトリ</param>
        /// <param name="ignoreCache">キャッシュを無視するかどうか（デフォルトは無視する）</param>
        /// <returns>結果</returns>
        /// <remarks>
        /// トランザクションは無効で、読み取り専用です。
        /// TODO: DataServiceのuseCacheが廃止された為、ignoreCacheは実質無効になっている。処理の見直しが必要。
        /// </remarks>
        /// <example>
        /// <code>
        /// // 指定されたSCrsMainと位相関係にあるSRoadMainのうち、05探索交差点が存在するものを列挙する
        /// CREO.DataModel.SCrsMain sCrsMain = ...;
        /// var result2 =
        ///     from sRoadMain in
        ///         Conditional.
        ///             OfPositionShared&lt;CREO.DataModel.SRoadMain&gt;(sCrsMain).
        ///             Execute(preBoundFactory).  // 事前バインドされたデータサービスファクトリを使用し、その場で実行する
        ///             AsParallel()
        ///     where sRoadMain.Road05GuideNoAry.Any()
        ///     select sRoadMain;
        /// </code>
        /// </example>
        public IEnumerable<T> Execute(IPreBoundDataServiceFactory preBoundFactory, bool ignoreCache = false)
        {
            Assertion.NullArgument(preBoundFactory, "事前バインドされたデータサービスファクトリが必要です");

            if (this.Condition == null)
            {
                return new T[0];
            }

            this.FixQueryItemsCondition();

            //// TODO: DataServiceのuseCacheが廃止された為、ignoreCacheは無効。処理の見直しが必要。
            using (var dataService = preBoundFactory.GetDataService(!ignoreCache))
            {
                if (typeof(T) == typeof(CREO.DataModel.GeoItem))
                {
                    return this.ApplyFilter((IEnumerable<T>)dataService.QueryItems(this.Condition, ignoreCache));
                }
                else
                {
                    return this.ApplyFilter(dataService.QueryItems(this.Condition, ignoreCache).OfType<T>());
                }
            }
        }

        /// <summary>
        /// 指定されたデータサービスを使用して、クエリをその場で実行します。
        /// </summary>
        /// <param name="dataService">データサービス</param>
        /// <param name="ignoreCache">キャッシュを無視するかどうか（デフォルトは無視しない）</param>
        /// <returns>結果</returns>
        /// <example>
        /// <code>
        /// // 指定されたSCrsMainと位相関係にあるSRoadMainのうち、05探索交差点が存在するものを列挙する
        /// CREO.DataModel.SCrsMain sCrsMain = ...;
        /// var result2 =
        ///     from sRoadMain in
        ///         Conditional.
        ///             OfPositionShared&lt;CREO.DataModel.SRoadMain&gt;(sCrsMain).
        ///             Execute(dataService).  // 指定したデータサービスを使用し、その場で実行する
        ///             AsParallel()
        ///     where sRoadMain.Road05GuideNoAry.Any()
        ///     select sRoadMain;
        /// </code>
        /// </example>
        public IEnumerable<T> Execute(CREO.DS.DataService dataService, bool ignoreCache = false)
        {
            Assertion.NullArgument(dataService, "データサービスが必要です");

            if (this.Condition == null)
            {
                return new T[0];
            }

            this.FixQueryItemsCondition();

            if (typeof(T) == typeof(CREO.DataModel.GeoItem))
            {
                return this.ApplyFilter((IEnumerable<T>)dataService.QueryItems(this.Condition, ignoreCache));
            }
            else
            {
                return this.ApplyFilter(dataService.QueryItems(this.Condition, true).OfType<T>());
            }
        }
        #endregion

        #region Overrides
        /// <summary>
        /// このインスタンスの文字列表現を取得します。
        /// </summary>
        /// <returns>文字列表現</returns>
        public override string ToString()
        {
            return this.Condition.ToString().Replace("\r", " ").Replace("\n", " ");
        }
        #endregion
    }
    #endregion

    #region StandardClause
    /// <summary>
    /// 標準の検索条件を示す構文糖クラスです。
    /// </summary>
    /// <typeparam name="T">結果を示す型</typeparam>
    /// <remarks>Conditional.Ofメソッドが返します。型の収集を追加・詳細検索条件の指定を可能にします。</remarks>
    public sealed class StandardClause<T> : ConditionalClause<T>
        where T : CREO.DataModel.GeoItem
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        internal StandardClause()
        {
        }

        /// <summary>
        /// 指定された型の収集を追加します。
        /// </summary>
        /// <typeparam name="U">対象の型</typeparam>
        /// <returns>クエリ</returns>
        /// <remarks>指定する型は、結果を示す型に内包可能でなければなりません。</remarks>
        public StandardClause<T> Include<U>()
            where U : T
        {
            if (this.Condition != null)
            {
                this.Types.Add(typeof(U));
            }

            return this;
        }

        /// <summary>
        /// 指定された詳細検索条件を追加します。
        /// </summary>
        /// <param name="detailClause">詳細検索条件式</param>
        /// <returns>クエリ</returns>
        /// <remarks>式要素は、詳細検索条件を示します。詳しくはPropertyクラスを参照して下さい。</remarks>
        public StandardClause<T> Details(DetailClause detailClause)
        {
            Assertion.NullArgument(detailClause, "詳細検索条件式が必要です");
            Assertion.Require(this.Condition.ConditionExpression == null, "詳細検索条件は指定済みです");

            this.Condition.ConditionExpression = detailClause.RawConditionExpression;

            return this;
        }
    }
    #endregion

    #region SpatialClause
    /// <summary>
    /// 空間実体の検索条件を示す構文糖クラスです。
    /// </summary>
    /// <typeparam name="T">結果を示す型</typeparam>
    /// <remarks>Conditional.OfPoint、Conditional.OfRangeメソッドが返します。
    /// 型の収集を追加・依存実体検索の追加・詳細検索条件の指定を可能にします。</remarks>
    public class SpatialClause<T> : ConditionalClause<T>
        where T : CREO.DataModel.SItemBase
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        internal SpatialClause()
        {
        }

        /// <summary>
        /// 指定された空間実体型の収集を追加します。
        /// </summary>
        /// <typeparam name="U">対象の型</typeparam>
        /// <returns>クエリ</returns>
        /// <remarks>追加する型は空間実体である必要があります。</remarks>
        public SpatialClause<T> Include<U>()
            where U : CREO.DataModel.SItemBase
        {
            if (this.Condition != null)
            {
                this.Types.Add(typeof(U));
            }

            return this;
        }

        /// <summary>
        /// 指定された依存実体型の収集を追加します。
        /// </summary>
        /// <typeparam name="U">対象の型</typeparam>
        /// <returns>クエリ</returns>
        /// <remarks>追加する型は依存実体である必要があります。</remarks>
        public SpatialWithDependsClause WithDepend<U>()
            where U : CREO.DataModel.DItemBase
        {
            if (this.Condition != null)
            {
                this.Types.Add(typeof(U));
            }

            return new SpatialWithDependsClause(this.Condition, this.Types);
        }

        /// <summary>
        /// 指定された詳細検索条件を追加します。
        /// </summary>
        /// <param name="detailClause">詳細検索条件式</param>
        /// <returns>クエリ</returns>
        /// <remarks>式要素は、詳細検索条件を示します。詳しくはPropertyクラスを参照して下さい。</remarks>
        public SpatialClause<T> Details(DetailClause detailClause)
        {
            Assertion.NullArgument(detailClause, "詳細検索条件式が必要です");
            Assertion.Require(this.Condition.ConditionExpression == null, "詳細検索条件は指定済みです");

            this.Condition.ConditionExpression = detailClause.RawConditionExpression;

            return this;
        }
    }
    #endregion

    #region SpatialWithDependsClause
    /// <summary>
    /// 空間実体と依存実体の検索条件を示す構文糖クラスです。
    /// </summary>
    /// <remarks>SpatialClause.WithDependメソッドが返します。
    /// 依存実体検索の追加・詳細検索条件の指定を可能にします。
    /// 検索結果は空間実体と依存実体の双方が含まれる可能性があるため、GeoItemの列挙型で返却します。</remarks>
    public sealed class SpatialWithDependsClause : ConditionalClause<CREO.DataModel.GeoItem>
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="condition">元となる検索条件</param>
        /// <param name="types">型</param>
        internal SpatialWithDependsClause(CREO.DS.QueryItemsCondition condition, HashSet<Type> types)
            : base(condition, types)
        {
        }

        /// <summary>
        /// 指定された空間実体型の収集を追加します。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <returns>クエリ</returns>
        /// <remarks>追加する型は空間実体である必要があります。</remarks>
        public SpatialWithDependsClause Include<T>()
            where T : CREO.DataModel.SItemBase
        {
            if (this.Condition != null)
            {
                this.Types.Add(typeof(T));
            }

            return this;
        }

        /// <summary>
        /// 指定された依存実体型の収集を追加します。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <returns>クエリ</returns>
        /// <remarks>追加する型は依存実体である必要があります。</remarks>
        public SpatialWithDependsClause WithDepend<T>()
            where T : CREO.DataModel.DItemBase
        {
            if (this.Condition != null)
            {
                this.Types.Add(typeof(T));
            }

            return this;
        }

        /// <summary>
        /// 指定された詳細検索条件を追加します。
        /// </summary>
        /// <param name="detailClause">詳細検索条件式</param>
        /// <returns>クエリ</returns>
        /// <remarks>式要素は、詳細検索条件を示します。詳しくはPropertyクラスを参照して下さい。</remarks>
        public SpatialWithDependsClause Details(DetailClause detailClause)
        {
            Assertion.NullArgument(detailClause, "詳細検索条件式が必要です");
            Assertion.Require(this.Condition.ConditionExpression == null, "詳細検索条件は指定済みです");

            this.Condition.ConditionExpression = detailClause.RawConditionExpression;

            return this;
        }
    }
    #endregion

    #region RelationalClause
    /// <summary>
    /// リレーション検索条件を示す構文糖クラスです。
    /// </summary>
    /// <typeparam name="T">結果を示す型</typeparam>
    /// <remarks>Conditional.OfPositionShared、Conditional.OfDependingTo・Conditional.OfDependedByメソッドが返します。
    /// 型の収集を追加可能にします。</remarks>
    public sealed class RelationalClause<T> : ConditionalClause<T>
        where T : CREO.DataModel.GeoItem
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        internal RelationalClause()
        {
            this.Condition.RelationExpression = new CREO.DS.RelationExpression();
        }

        /// <summary>
        /// 指定された型の収集を追加します。
        /// </summary>
        /// <typeparam name="U">対象の型</typeparam>
        /// <returns>クエリ</returns>
        /// <remarks>指定する型は、結果を示す型に内包可能でなければなりません。</remarks>
        public RelationalClause<T> Include<U>()
            where U : T
        {
            if (this.Condition != null)
            {
                this.Types.Add(typeof(U));
            }

            return this;
        }
    }
    #endregion

    #region GroupingClause
    /// <summary>
    /// グルーピング検索条件を示す構文糖クラスです。
    /// </summary>
    /// <typeparam name="T">結果を示す型</typeparam>
    /// <remarks>Conditional.OfGroupingメソッドが返します。
    /// グループタイプを追加可能にします。</remarks>
    public sealed class GroupingClause<T> : ConditionalClause<T>
        where T : CREO.DataModel.GeoItem
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        internal GroupingClause()
        {
            this.Condition.RelationExpression = new CREO.DS.RelationExpression();
        }

        /// <summary>
        /// 指定されたグループタイプの収集を追加します。
        /// </summary>
        /// <param name="groupType">グループタイプ</param>
        /// <returns>クエリ</returns>
        public GroupingClause<T> Include(int groupType)
        {
            if (this.Condition != null)
            {
                this.Condition.RelationExpression.GroupTypes.Add(groupType);
            }

            return this;
        }
    }
    #endregion

    #region TableClause
    /// <summary>
    /// 表実体検索条件を示す構文糖クラスです。
    /// </summary>
    /// <typeparam name="T">結果を示す型</typeparam>
    /// <remarks>Conditional.OfChild・Conditional.OfParentメソッドが返します。
    /// 検索条件の追加手段はありません。</remarks>
    public sealed class TableClause<T> : ConditionalClause<T>
        where T : CREO.DataModel.TItemBase
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        internal TableClause()
        {
            this.Condition.RelationExpression = new CREO.DS.RelationExpression();
        }
    }
    #endregion

    #region DependedByTypeClause
    /// <summary>
    /// 依存実体の型から空間実体群を検索する検索条件を示す構文糖クラスです。
    /// </summary>
    /// <remarks>Conditional.OfDependedByTypeメソッドが返します。
    /// 型の収集を追加可能にします。</remarks>
    public sealed class DependedByTypeClause : ConditionalClause<CREO.DataModel.SItemBase>
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        internal DependedByTypeClause()
        {
            this.Condition.QueryExpression = new CREO.DS.DependencyTypeToSpatialExpression();
        }

        /// <summary>
        /// 指定された依存実体型の収集を追加します。
        /// </summary>
        /// <typeparam name="T">検索する依存実体の型</typeparam>
        /// <returns>クエリ</returns>
        public DependedByTypeClause WithDepend<T>()
            where T : CREO.DataModel.DItemBase
        {
            if (this.Condition != null)
            {
                ((CREO.DS.DependencyTypeToSpatialExpression)this.Condition.QueryExpression).DependencyTypeIds.Add(typeof(T).Name);
            }

            return this;
        }
    }
    #endregion

    #region TraverseClause
    /// <summary>
    /// 全ての親TItemBase型の要素を取得する検索条件を示す構文糖クラスです。
    /// </summary>
    /// <typeparam name="T">結果を示す型</typeparam>
    /// <remarks>Conditional.OfTraverseメソッドが返します。
    /// 検索条件の追加手段はありません。</remarks>
    public sealed class TraverseClause<T> : ConditionalClause<T>
        where T : CREO.DataModel.TItemBase
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        internal TraverseClause()
        {
            this.Condition.QueryExpression = new CREO.DS.AncestorTableRelationExpression();
        }
    }
    #endregion
}

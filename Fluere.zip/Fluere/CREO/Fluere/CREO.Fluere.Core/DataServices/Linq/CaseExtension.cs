﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using CREO.Fluere.Common.DataModel;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// データサービスで使用する拡張メソッド群です。
    /// </summary>
    /// <remarks>このクラスで拡張されるメソッドは、必ず引数を2個以上指定させるように宣言されています。
    /// これは、既存のCaseメソッドの呼び出しを妨げないようにする為です。</remarks>
    public static class CaseExtension
    {
        #region InternalCase
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <typeparam name="T">型</typeparam>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <param name="comparer">判定演算子</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        private static bool InternalCase<T>(
            T target,
            T rhs1,
            T rhs2,
            IEnumerable<T> args,
            IEqualityComparer<T> comparer)
        {
            Assertion.Condition(args != null);
            Assertion.Condition(comparer != null);

            if (comparer.Equals(target, rhs1) == true)
            {
                return true;
            }

            if (comparer.Equals(target, rhs2) == true)
            {
                return true;
            }

            foreach (T arg in args)
            {
                if (comparer.Equals(target, arg) == true)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <typeparam name="T">型</typeparam>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <param name="comparer">判定演算子</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        private static bool InternalCase<T>(
            T? target,
            T rhs1,
            T rhs2,
            IEnumerable<T> args,
            IEqualityComparer<T?> comparer)
            where T : struct
        {
            Assertion.Condition(args != null);
            Assertion.Condition(comparer != null);

            if (comparer.Equals(target, rhs1) == true)
            {
                return true;
            }

            if (comparer.Equals(target, rhs2) == true)
            {
                return true;
            }

            foreach (T arg in args)
            {
                if (comparer.Equals(target, arg) == true)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <typeparam name="T">型</typeparam>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <param name="comparer">判定演算子</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        private static bool InternalCase<T>(
            IEnumerable<T> targets,
            T rhs1,
            T rhs2,
            IEnumerable<T> args,
            IEqualityComparer<T> comparer)
        {
            Assertion.Condition(comparer != null);

            Assertion.NullArgument(targets, "比較コレクションのインスタンスがnullです");

            // 比較する値にnullが含まれていたら、ハッシュセットでは確認できないのでループで確認する
            try
            {
                ISet<T> dictionary = new HashSet<T>(args, comparer);
                dictionary.Add(rhs1);
                dictionary.Add(rhs2);

                foreach (T target in targets)
                {
                    if (dictionary.Contains(target) == true)
                    {
                        return true;
                    }
                }

                return false;
            }
            catch (NullReferenceException)
            {
            }
            catch (ArgumentNullException)
            {
            }

            foreach (T target in targets)
            {
                if (InternalCase(target, rhs1, rhs2, args, comparer) == true)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region byte
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this byte target, byte rhs1, byte rhs2, params byte[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<byte>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this byte? target, byte rhs1, byte rhs2, params byte[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<byte?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<byte> targets, byte rhs1, byte rhs2, params byte[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<byte>());
        }
        #endregion

        #region sbyte
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this sbyte target, sbyte rhs1, sbyte rhs2, params sbyte[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<sbyte>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this sbyte? target, sbyte rhs1, sbyte rhs2, params sbyte[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<sbyte?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<sbyte> targets, sbyte rhs1, sbyte rhs2, params sbyte[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<sbyte>());
        }
        #endregion

        #region short
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this short target, short rhs1, short rhs2, params short[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<short>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this short? target, short rhs1, short rhs2, params short[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<short?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<short> targets, short rhs1, short rhs2, params short[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<short>());
        }
        #endregion

        #region ushort
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this ushort target, ushort rhs1, ushort rhs2, params ushort[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<ushort>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this ushort? target, ushort rhs1, ushort rhs2, params ushort[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<ushort?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<ushort> targets, ushort rhs1, ushort rhs2, params ushort[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<ushort>());
        }
        #endregion

        #region int
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this int target, int rhs1, int rhs2, params int[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<int>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this int? target, int rhs1, int rhs2, params int[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<int?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<int> targets, int rhs1, int rhs2, params int[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<int>());
        }
        #endregion

        #region uint
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this uint target, uint rhs1, uint rhs2, params uint[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<uint>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this uint? target, uint rhs1, uint rhs2, params uint[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<uint?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<uint> targets, uint rhs1, uint rhs2, params uint[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<uint>());
        }
        #endregion

        #region long
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this long target, long rhs1, long rhs2, params long[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<long>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this long? target, long rhs1, long rhs2, params long[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<long?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<long> targets, long rhs1, long rhs2, params long[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<long>());
        }
        #endregion

        #region ulong
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this ulong target, ulong rhs1, ulong rhs2, params ulong[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<ulong>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this ulong? target, ulong rhs1, ulong rhs2, params ulong[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<ulong?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<ulong> targets, ulong rhs1, ulong rhs2, params ulong[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<ulong>());
        }

        /// <summary>
        /// 指定されたグルーピングタグ群が、後続の引数群で示されるグルーピングタグタイプの何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">グルーピングタグ群</param>
        /// <param name="groupingTagType">グルーピングタグタイプ</param>
        /// <param name="args">グルーピングタグタイプの集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>このメソッドは、グルーピングタグタイプの比較にのみ使用出来ます。
        /// データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool GroupingTagTypes(this IEnumerable<ulong> targets, int groupingTagType, params int[] args)
        {
            Assertion.Condition(args != null);

            Assertion.NullArgument(targets, "比較コレクションのインスタンスがnullです");

            ISet<int> types = new HashSet<int>(args);
            types.Add(groupingTagType);

            foreach (ulong target in targets)
            {
                // グルーピングタグタイプを取得
                int targetType = (ushort)(target >> 40);

                // 含まれていればtrue
                if (types.Contains(targetType) == true)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region float
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this float target, float rhs1, float rhs2, params float[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<float>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this float? target, float rhs1, float rhs2, params float[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<float?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<float> targets, float rhs1, float rhs2, params float[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<float>());
        }
        #endregion

        #region double
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this double target, double rhs1, double rhs2, params double[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<double>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this double? target, double rhs1, double rhs2, params double[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<double?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<double> targets, double rhs1, double rhs2, params double[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<double>());
        }
        #endregion

        #region decimal
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this decimal target, decimal rhs1, decimal rhs2, params decimal[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<decimal>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this decimal? target, decimal rhs1, decimal rhs2, params decimal[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<decimal?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<decimal> targets, decimal rhs1, decimal rhs2, params decimal[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<decimal>());
        }
        #endregion

        #region char
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this char target, char rhs1, char rhs2, params char[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<char>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this char? target, char rhs1, char rhs2, params char[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<char?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<char> targets, char rhs1, char rhs2, params char[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<char>());
        }
        #endregion

        #region Guid
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this Guid target, Guid rhs1, Guid rhs2, params Guid[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<Guid>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this Guid? target, Guid rhs1, Guid rhs2, params Guid[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<Guid?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<Guid> targets, Guid rhs1, Guid rhs2, params Guid[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<Guid>());
        }
        #endregion

        #region DateTime
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this DateTime target, DateTime rhs1, DateTime rhs2, params DateTime[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<DateTime>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this DateTime? target, DateTime rhs1, DateTime rhs2, params DateTime[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ValueTypeComparer<DateTime?>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<DateTime> targets, DateTime rhs1, DateTime rhs2, params DateTime[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ValueTypeComparer<DateTime>());
        }
        #endregion

        #region string
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this string target, string rhs1, string rhs2, params string[] args)
        {
            return InternalCase(target, rhs1, rhs2, args, new ClassComparer<string>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="targets">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(this IEnumerable<string> targets, string rhs1, string rhs2, params string[] args)
        {
            return InternalCase(targets, rhs1, rhs2, args, new ClassComparer<string>());
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>引数に含まれる型はインターフェイスで、IGeoItemインターフェイスを継承し、DataModelTargetAttributeが適用されている必要があります。
        /// データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        [SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "This method is obsolete")]
        [Obsolete("LINQ to CREOは廃止されます。データサービスを直接使用するか、Conditionalヘルパークラスを使用して下さい。")]
        public static bool Case(this string target, Type rhs1, Type rhs2, params Type[] args)
        {
            Assertion.Condition(args != null);

            if (EqualsExtension.Equals(target, rhs1) == true)
            {
                return true;
            }

            if (EqualsExtension.Equals(target, rhs2) == true)
            {
                return true;
            }

            foreach (Type arg in args)
            {
                if (EqualsExtension.Equals(target, arg) == true)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region GeoItem
        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>GeoItemクラスのOIDプロパティを比較します。
        /// データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(
            this CREO.DataModel.GeoItem target,
            CREO.DataModel.GeoItem rhs1,
            CREO.DataModel.GeoItem rhs2,
            params CREO.DataModel.GeoItem[] args)
        {
            Assertion.Condition(args != null);

            if (EqualsExtension.Equals(target, rhs1) == true)
            {
                return true;
            }

            if (EqualsExtension.Equals(target, rhs2) == true)
            {
                return true;
            }

            foreach (CREO.DataModel.GeoItem arg in args)
            {
                if (EqualsExtension.Equals(target, arg) == true)
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 指定された値が、後続の引数群の何れかであるかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="rhs1">値1</param>
        /// <param name="rhs2">値2</param>
        /// <param name="args">値の集合</param>
        /// <returns>何れかに一致すればtrue</returns>
        /// <remarks>GeoItemクラスのOIDプロパティを比較します。
        /// データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Case(
            this CREO.DataModel.GeoItem target,
            ulong rhs1,
            ulong rhs2,
            params ulong[] args)
        {
            Assertion.Condition(args != null);

            if (EqualsExtension.Equals(target, rhs1) == true)
            {
                return true;
            }

            if (EqualsExtension.Equals(target, rhs2) == true)
            {
                return true;
            }

            foreach (ulong arg in args)
            {
                if (EqualsExtension.Equals(target, arg) == true)
                {
                    return true;
                }
            }

            return false;
        }
        #endregion

        #region ValueTypeComparer
        /// <summary>
        /// 値型の比較を行うIEqualityComparer&lt;T&gt;の実装です。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <remarks>このクラスは内部で使用します。</remarks>
        internal sealed class ValueTypeComparer<T> : IEqualityComparer<T>
        {
            /// <summary>
            /// 値を比較します。
            /// </summary>
            /// <param name="x">値1</param>
            /// <param name="y">値2</param>
            /// <returns>一致していればtrue</returns>
            public bool Equals(T x, T y)
            {
                return x.Equals(y);
            }

            /// <summary>
            /// ハッシュコードを取得します。
            /// </summary>
            /// <param name="obj">値</param>
            /// <returns>ハッシュコード</returns>
            public int GetHashCode(T obj)
            {
                return obj.GetHashCode();
            }
        }
        #endregion

        #region ClassComparer
        /// <summary>
        /// 参照型の比較を行うIEqualityComparer&lt;T&gt;の実装です。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <remarks>このクラスは内部で使用します。</remarks>
        internal sealed class ClassComparer<T> : IEqualityComparer<T>
            where T : class
        {
            /// <summary>
            /// インスタンスを比較します。
            /// </summary>
            /// <param name="x">インスタンス1</param>
            /// <param name="y">インスタンス2</param>
            /// <returns>一致していればtrue</returns>
            public bool Equals(T x, T y)
            {
                if ((x == null) && (y == null))
                {
                    return true;
                }

                if ((x == null) || (y == null))
                {
                    return false;
                }

                return x.Equals(y);
            }

            /// <summary>
            /// ハッシュコードを取得します。
            /// </summary>
            /// <param name="obj">値</param>
            /// <returns>ハッシュコード</returns>
            public int GetHashCode(T obj)
            {
                return obj.GetHashCode();
            }
        }
        #endregion
    }
}

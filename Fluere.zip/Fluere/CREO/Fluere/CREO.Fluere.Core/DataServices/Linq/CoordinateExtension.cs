﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Xml;
using CREO.Fluere.Common.Collections;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// Coordinateクラスの拡張メソッド群です。
    /// </summary>
    /// <remarks>Coordinateクラスによる、ポイント・ポリゴン・マルチポリゴンコレクションの操作をサポートします。</remarks>
    public static class CoordinateExtension
    {
        #region Fields
        /// <summary>
        /// 座標値の最低値です。
        /// </summary>
        public const long MinValue = (-(long)int.MaxValue) * 100;

        /// <summary>
        /// 座標値の最高値です。
        /// </summary>
        public const long MaxValue = ((long)int.MaxValue) * 100;
        #endregion

        #region Clone
        /// <summary>
        /// 座標のコピーを生成します。
        /// </summary>
        /// <param name="coordinate">座標</param>
        /// <returns>新しいインスタンス</returns>
        /// <remarks>Coordinateクラスは書き換え可能なため、コピーを生成します。</remarks>
        public static CREO.FW.TMIGeometry.Coordinate Clone(this CREO.FW.TMIGeometry.Coordinate coordinate)
        {
            return new CREO.FW.TMIGeometry.Coordinate(coordinate.Longitude, coordinate.Latitude);
        }

        /// <summary>
        /// 座標のコピーを生成します。
        /// </summary>
        /// <param name="coordinate">座標</param>
        /// <returns>新しいインスタンス</returns>
        /// <remarks>CoordinateDクラスは書き換え可能なため、コピーを生成します。</remarks>
        public static CREO.FW.TMIGeometry.CoordinateD Clone(this CREO.FW.TMIGeometry.CoordinateD coordinate)
        {
            return new CREO.FW.TMIGeometry.CoordinateD(coordinate.Longitude, coordinate.Latitude);
        }

        /// <summary>
        /// 座標のコピーを生成します。
        /// </summary>
        /// <param name="rect">座標</param>
        /// <returns>新しいインスタンス</returns>
        /// <remarks>CoordinateRectクラスは書き換え可能なため、コピーを生成します。</remarks>
        public static CREO.FW.TMIGeometry.CoordinateRect Clone(this CREO.FW.TMIGeometry.CoordinateRect rect)
        {
            var cloned = new CREO.FW.TMIGeometry.CoordinateRect();
            cloned.BottomLeft.Longitude = rect.BottomLeft.Longitude;
            cloned.BottomLeft.Latitude = rect.BottomLeft.Latitude;
            cloned.TopRight.Longitude = rect.TopRight.Longitude;
            cloned.TopRight.Latitude = rect.TopRight.Latitude;
            return cloned;
        }
        #endregion

        #region ContainsPoint
        /// <summary>
        /// 指定されたポイントが含まれているかどうかを取得します。
        /// </summary>
        /// <param name="rect">比較元のCoordinateRect</param>
        /// <param name="point">比較するポイント</param>
        /// <returns>含まれていればtrue</returns>
        public static bool ContainsPoint(
            this CREO.FW.TMIGeometry.CoordinateRect rect,
            CREO.FW.TMIGeometry.Coordinate point)
        {
            Assertion.NullArgument(rect, "CoordinateRectのインスタンスが必要です");
            Assertion.NullArgument(point, "Coordinateのインスタンスが必要です");

            return
                (point.Longitude >= rect.BottomLeft.Longitude) &&
                (point.Longitude <= rect.TopRight.Longitude) &&
                (point.Latitude >= rect.BottomLeft.Latitude) &&
                (point.Latitude <= rect.TopRight.Latitude);
        }
        #endregion

        #region CenterPoint
        /// <summary>
        /// 2点間の中点を取得します。
        /// </summary>
        /// <param name="point0">始点</param>
        /// <param name="point1">終点</param>
        /// <returns>中点</returns>
        public static CREO.FW.TMIGeometry.Coordinate CenterPoint(
            this CREO.FW.TMIGeometry.Coordinate point0,
            CREO.FW.TMIGeometry.Coordinate point1)
        {
            Assertion.NullArgument(point0, "始点が必要です");
            Assertion.NullArgument(point1, "終点が必要です");

            System.Windows.Point position;
            CREO.FW.TMIGeometry.GeometryLib.CalculateCenterPoint(point0.ToPoint(), point1.ToPoint(), out position);

            return position.ToCoordinate();
        }
        #endregion

        #region LogicalCenterPoint
        /// <summary>
        /// ポリラインの中点を取得します。
        /// </summary>
        /// <param name="polyline">ポリライン</param>
        /// <returns>中点</returns>
        /// <remarks>ポリラインの中点は、ポリラインを構成する点数の中間に存在する線分の中点となります。
        /// （始終点距離の中点ではありません）</remarks>
        public static CREO.FW.TMIGeometry.Coordinate LogicalCenterPoint(
            this IEnumerable<CREO.FW.TMIGeometry.Coordinate> polyline)
        {
            Assertion.NullArgument(polyline, "ポリラインが必要です");

            var count = polyline.Count();

            Assertion.Argument(count >= 1, "ポリラインに座標が含まれていません");

            if ((count % 2) == 1)
            {
                return polyline.ElementAt(count / 2);
            }
            else
            {
                var index = count / 2;
                var point0 = polyline.ElementAt(index - 1);
                var point1 = polyline.ElementAt(index);

                return CenterPoint(point0, point1);
            }
        }
        #endregion

        #region ToPolygon
        /// <summary>
        /// CoordinateRectを四角ポリゴンに変換します。
        /// </summary>
        /// <param name="rect">CoordinateRectのインスタンス</param>
        /// <returns>四角ポリゴン</returns>
        public static IEnumerable<CREO.FW.TMIGeometry.Coordinate>
            ToPolygon(this CREO.FW.TMIGeometry.CoordinateRect rect)
        {
            Assertion.NullArgument(rect, "CoordinateRectのインスタンスが必要です");

            var polygon = new CREO.FW.Utilities.DMCollection<FW.TMIGeometry.Coordinate>();

            polygon.Add(rect.BottomLeft);
            polygon.Add(new CREO.FW.TMIGeometry.Coordinate(rect.BottomLeft.Longitude, rect.TopRight.Latitude));
            polygon.Add(rect.TopRight);
            polygon.Add(new CREO.FW.TMIGeometry.Coordinate(rect.TopRight.Longitude, rect.BottomLeft.Latitude));
            polygon.Add(rect.BottomLeft);

            return polygon;
        }
        #endregion

        #region ToCoordinateRectangle
        /// <summary>
        /// 四角ポリゴンをCoordinateRectに変換します。
        /// </summary>
        /// <param name="boxedPolygon">四角ポリゴン</param>
        /// <returns>CoordinateRectのインスタンス</returns>
        public static CREO.FW.TMIGeometry.CoordinateRect ToCoordinateRectangle(
            this IEnumerable<CREO.FW.TMIGeometry.Coordinate> boxedPolygon)
        {
            Assertion.NullArgument(boxedPolygon, "四角ポリゴンのインスタンスが必要です");

            var longitudeList =
                (from coordinate in boxedPolygon
                 orderby coordinate.Longitude
                 select coordinate.Longitude).Distinct().ToList();
            Assertion.Argument(longitudeList.Count == 2, "四角ポリゴンのインスタンスが必要です");

            var latitudeList =
                (from coordinate in boxedPolygon
                 orderby coordinate.Latitude
                 select coordinate.Latitude).Distinct().ToList();
            Assertion.Argument(latitudeList.Count == 2, "四角ポリゴンのインスタンスが必要です");

            var rect = new CREO.FW.TMIGeometry.CoordinateRect();
            rect.BottomLeft.Longitude = longitudeList[0];
            rect.BottomLeft.Latitude = latitudeList[0];
            rect.TopRight.Longitude = longitudeList[1];
            rect.TopRight.Latitude = latitudeList[1];

            return rect;
        }
        #endregion

        #region UnionAll
        /// <summary>
        /// 指定された要素を全て結合します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="geometries">要素群</param>
        /// <returns>マルチポリゴン</returns>
        public static IMultiPolygon UnionAll<T>(this IEnumerable<T> geometries)
            where T : IGeometry
        {
            Assertion.NullArgument(geometries, "マルチポリゴンのインスタンスが必要です");

            var enumerator = geometries.GetEnumerator();
            try
            {
                if (enumerator.MoveNext() == true)
                {
                    var geometry = enumerator.Current.ToMultiPolygon();

                    while (enumerator.MoveNext() == true)
                    {
                        var current = enumerator.Current;
                        geometry = geometry.Union(current);
                    }

                    return geometry;
                }
            }
            finally
            {
                var disposable = enumerator as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }
            }

            return GeometryBase.Empty;
        }
        #endregion

        #region CreateRectangle
        /// <summary>
        /// CoordinateRectのインスタンスを生成します。
        /// </summary>
        /// <param name="bottom">下座標</param>
        /// <param name="left">左座標</param>
        /// <param name="top">上座標</param>
        /// <param name="right">右座標</param>
        /// <returns>インスタンス</returns>
        /// <remarks>引数を全て省略すると、全領域を示す疑似的な値となります。</remarks>
        public static CREO.FW.TMIGeometry.CoordinateRect CreateRectangle(
            long bottom = MinValue,
            long left = MinValue,
            long top = MaxValue,
            long right = MaxValue)
        {
            var rectangle = new CREO.FW.TMIGeometry.CoordinateRect();
            rectangle.BottomLeft.Longitude = left;
            rectangle.BottomLeft.Latitude = bottom;
            rectangle.TopRight.Longitude = right;
            rectangle.TopRight.Latitude = top;
            return rectangle;
        }

        /// <summary>
        /// CoordinateRectのインスタンスを生成します。
        /// </summary>
        /// <param name="bottomLeft">左下座標</param>
        /// <param name="topRight">右上座標</param>
        /// <returns>インスタンス</returns>
        public static CREO.FW.TMIGeometry.CoordinateRect CreateRectangle(
            CREO.FW.TMIGeometry.Coordinate bottomLeft,
            CREO.FW.TMIGeometry.Coordinate topRight)
        {
            Assertion.NullArgument(bottomLeft, "座標が必要です");
            Assertion.NullArgument(topRight, "座標が必要です");

            var rectangle = new CREO.FW.TMIGeometry.CoordinateRect();
            rectangle.BottomLeft.Longitude = bottomLeft.Longitude;
            rectangle.BottomLeft.Latitude = bottomLeft.Latitude;
            rectangle.TopRight.Longitude = topRight.Longitude;
            rectangle.TopRight.Latitude = topRight.Latitude;
            return rectangle;
        }
        #endregion

        #region CreateValidRectangle
        /// <summary>
        /// 2点座標から、正規化された四角矩形を生成します。
        /// </summary>
        /// <param name="point0">座標0</param>
        /// <param name="point1">座標1</param>
        /// <param name="extendFactor">座標が重なっている場合に、座標を広げる単位</param>
        /// <returns>四角矩形</returns>
        /// <remarks>指定された2点座標の位置関係を確認し、正しい矩形を生成します。</remarks>
        public static CREO.FW.TMIGeometry.CoordinateRect CreateValidRectangle(
            CREO.FW.TMIGeometry.Coordinate point0,
            CREO.FW.TMIGeometry.Coordinate point1,
            int extendFactor = 0)
        {
            Assertion.NullArgument(point0, "Coordinateのインスタンスが必要です");
            Assertion.NullArgument(point1, "Coordinateのインスタンスが必要です");

            var point0Longitude = point0.Longitude;
            var point0Latitude = point0.Latitude;
            var point1Longitude = point1.Longitude;
            var point1Latitude = point1.Latitude;

            if ((point0Longitude <= point1Longitude) && (point0Latitude <= point1Latitude))
            {
                if (point0Longitude == point1Longitude)
                {
                    point0Longitude -= extendFactor;
                    point1Longitude += extendFactor;
                }

                if (point0Latitude == point1Latitude)
                {
                    point0Latitude -= extendFactor;
                    point1Latitude += extendFactor;
                }

                return CreateRectangle(point0Latitude, point0Longitude, point1Latitude, point1Longitude);
            }
            else if ((point0Longitude > point1Longitude) && (point0Latitude > point1Latitude))
            {
                return CreateRectangle(point1Latitude, point1Longitude, point0Latitude, point0Longitude);
            }
            else if ((point0Longitude <= point1Longitude) && (point0Latitude > point1Latitude))
            {
                if (point0Longitude == point1Longitude)
                {
                    point0Longitude -= extendFactor;
                    point1Longitude += extendFactor;
                }

                return CreateRectangle(point1Latitude, point0Longitude, point0Latitude, point1Longitude);
            }
            else
            {
                Assertion.Condition((point0Longitude > point1Longitude) && (point0Latitude <= point1Latitude));

                if (point0Latitude == point1Latitude)
                {
                    point0Latitude -= extendFactor;
                    point1Latitude += extendFactor;
                }

                return CreateRectangle(point0Latitude, point1Longitude, point1Latitude, point0Longitude);
            }
        }
        #endregion

        #region CreateValidPolygon
        /// <summary>
        /// 2点座標から、正規化された四角ポリゴンを生成します。
        /// </summary>
        /// <param name="point0">座標0</param>
        /// <param name="point1">座標1</param>
        /// <param name="extendFactor">座標が重なっている場合に、座標を広げる単位</param>
        /// <returns>四角ポリゴン</returns>
        /// <remarks>指定された2点座標の位置関係を確認し、正しいポリゴンを生成します。</remarks>
        public static IEnumerable<CREO.FW.TMIGeometry.Coordinate> CreateValidPolygon(
            CREO.FW.TMIGeometry.Coordinate point0,
            CREO.FW.TMIGeometry.Coordinate point1,
            int extendFactor = 0)
        {
            Assertion.NullArgument(point0, "Coordinateのインスタンスが必要です");
            Assertion.NullArgument(point1, "Coordinateのインスタンスが必要です");

            var polygon = new FW.TMIGeometry.Coordinate[5];

            var point0Longitude = point0.Longitude;
            var point0Latitude = point0.Latitude;
            var point1Longitude = point1.Longitude;
            var point1Latitude = point1.Latitude;

            if ((point0Longitude <= point1Longitude) && (point0Latitude <= point1Latitude))
            {
                if (point0Longitude == point1Longitude)
                {
                    point0Longitude -= extendFactor;
                    point1Longitude += extendFactor;
                }

                if (point0Latitude == point1Latitude)
                {
                    point0Latitude -= extendFactor;
                    point1Latitude += extendFactor;
                }

                polygon[0] = new CREO.FW.TMIGeometry.Coordinate(point0Longitude, point0Latitude);
                polygon[1] = new CREO.FW.TMIGeometry.Coordinate(point0Longitude, point1Latitude);
                polygon[2] = new CREO.FW.TMIGeometry.Coordinate(point1Longitude, point1Latitude);
                polygon[3] = new CREO.FW.TMIGeometry.Coordinate(point1Longitude, point0Latitude);
            }
            else if ((point0Longitude > point1Longitude) && (point0Latitude > point1Latitude))
            {
                polygon[0] = new CREO.FW.TMIGeometry.Coordinate(point1Longitude, point1Latitude);
                polygon[1] = new CREO.FW.TMIGeometry.Coordinate(point1Longitude, point0Latitude);
                polygon[2] = new CREO.FW.TMIGeometry.Coordinate(point0Longitude, point0Latitude);
                polygon[3] = new CREO.FW.TMIGeometry.Coordinate(point0Longitude, point1Latitude);
            }
            else if ((point0Longitude <= point1Longitude) && (point0Latitude > point1Latitude))
            {
                if (point0Longitude == point1Longitude)
                {
                    point0Longitude -= extendFactor;
                    point1Longitude += extendFactor;
                }

                polygon[0] = new CREO.FW.TMIGeometry.Coordinate(point0Longitude, point0Latitude);
                polygon[1] = new CREO.FW.TMIGeometry.Coordinate(point1Longitude, point0Latitude);
                polygon[2] = new CREO.FW.TMIGeometry.Coordinate(point1Longitude, point1Latitude);
                polygon[3] = new CREO.FW.TMIGeometry.Coordinate(point0Longitude, point1Latitude);
            }
            else
            {
                Assertion.Condition((point0Longitude > point1Longitude) && (point0Latitude <= point1Latitude));

                if (point0Latitude == point1Latitude)
                {
                    point0Latitude -= extendFactor;
                    point1Latitude += extendFactor;
                }

                polygon[0] = new CREO.FW.TMIGeometry.Coordinate(point1Longitude, point1Latitude);
                polygon[1] = new CREO.FW.TMIGeometry.Coordinate(point0Longitude, point1Latitude);
                polygon[2] = new CREO.FW.TMIGeometry.Coordinate(point0Longitude, point0Latitude);
                polygon[3] = new CREO.FW.TMIGeometry.Coordinate(point1Longitude, point0Latitude);
            }

            polygon[4] = polygon[0];

            return polygon;
        }
        #endregion

        #region GetDefaultMeshType
        /// <summary>
        /// システムデフォルトのメッシュタイプを取得します。
        /// </summary>
        /// <returns>メッシュタイプ</returns>
        public static int GetDefaultMeshType()
        {
            return int.Parse(
                CREO.FW.Utilities.ProfileUtility.GetAttribute(
                    CREO.FW.Utilities.ProfileUtility.ProfileTypeEnum.MachineProfile,
                    "/configuration/defaultMeshType",
                    "value"),
                CultureInfo.InvariantCulture);
        }
        #endregion

        #region GetDefaultMeshTypes
        /// <summary>
        /// システムデフォルトのメッシュタイプ階層を取得します。
        /// </summary>
        /// <returns>メッシュタイプ階層</returns>
        public static IEnumerable<int> GetDefaultMeshTypes()
        {
            var defaultMeshType = GetDefaultMeshType();

            return
                GetMeshTypes().Where(meshTypes => meshTypes.Any(meshType => meshType == defaultMeshType)).First();
        }
        #endregion

        #region GetMeshTypes
        /// <summary>
        /// 管理している全てのメッシュタイプ階層群を取得します。
        /// </summary>
        /// <returns>メッシュタイプ階層群の列挙子</returns>
        /// <remarks>メッシュタイプ階層を、ルートメッシュタイプを起点とした列挙子の組として取得します。
        /// 例えば、8100を起点とするメッシュ階層は、8100,8101,8102を列挙し、
        /// 9100を起点とするメッシュ階層は、9100,9101,9102,9103のように、8100の階層とは異なる階層で表現されます。
        /// これらを8100の系列・9100の系列のように、n個の階層系列として列挙されます。</remarks>
        public static IEnumerable<IEnumerable<int>> GetMeshTypes()
        {
            var meshTypes =
                CREO.FW.Utilities.MeshCodeUtility.MeshMasterData.MESHREGISTER.Distinct(row => row.MeshType, row => row.SubMeshType).Select(row => new List<int>(new[] { row.MeshType, row.SubMeshType })).ToList();

            while (true)
            {
                var found = false;

                for (var index = 0; index < meshTypes.Count; index++)
                {
                    var nowLastMeshType = meshTypes[index].Last();

                    var inner = 0;
                    while (inner < meshTypes.Count)
                    {
                        if (inner != index)
                        {
                            var innerFirstMeshType = meshTypes[inner].First();
                            if (nowLastMeshType == innerFirstMeshType)
                            {
                                meshTypes[index].AddRange(meshTypes[inner].Skip(1));
                                meshTypes.RemoveAt(inner);
                                found = true;
                                break;
                            }
                        }

                        inner++;
                    }
                }

                if ((found == false) || (meshTypes.Count <= 1))
                {
                    break;
                }
            }

            return meshTypes;
        }
        #endregion

        #region GetOriginateMeshCode
        /// <summary>
        /// 座標位置に該当するメッシュコードを取得します。
        /// </summary>
        /// <param name="coordinate">座標位置</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>メッシュコード（メッシュ左下辺を該当するとみなす）</returns>
        public static int GetOriginateMeshCode(this CREO.FW.TMIGeometry.Coordinate coordinate, int meshType = 0)
        {
            var meshInformation = MeshInformation.GetMeshInformation(meshType);
            return meshInformation.GetOriginateMeshCode(coordinate);
        }
        #endregion

        #region GetOriginateMeshCodes
        /// <summary>
        /// 座標位置群に該当するメッシュコード群を取得します。
        /// </summary>
        /// <param name="coordinates">座標位置群</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>メッシュコード群（メッシュ左下辺を該当するとみなす）</returns>
        public static IEnumerable<int> GetOriginateMeshCodes(
            this IEnumerable<CREO.FW.TMIGeometry.Coordinate> coordinates,
            int meshType = 0)
        {
            var meshInformation = MeshInformation.GetMeshInformation(meshType);
            return from coordinate in coordinates.AsParallel()
                   select meshInformation.GetOriginateMeshCode(coordinate);
        }
        #endregion

        #region GetReverseOriginateMeshCode
        /// <summary>
        /// 座標位置に該当するメッシュコードを取得します。
        /// </summary>
        /// <param name="coordinate">座標位置</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>メッシュコード（メッシュ右上辺を該当するとみなす）</returns>
        public static int GetReverseOriginateMeshCode(this CREO.FW.TMIGeometry.Coordinate coordinate, int meshType = 0)
        {
            var meshInformation = MeshInformation.GetMeshInformation(meshType);
            return meshInformation.GetReverseOriginateMeshCode(coordinate);
        }
        #endregion

        #region GetReverseOriginateMeshCodes
        /// <summary>
        /// 座標位置群に該当するメッシュコード群を取得します。
        /// </summary>
        /// <param name="coordinates">座標位置群</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>メッシュコード群（メッシュ右上辺を該当するとみなす）</returns>
        public static IEnumerable<int> GetReverseOriginateMeshCodes(
            this IEnumerable<CREO.FW.TMIGeometry.Coordinate> coordinates,
            int meshType = 0)
        {
            var meshInformation = MeshInformation.GetMeshInformation(meshType);
            return from coordinate in coordinates.AsParallel()
                   select meshInformation.GetReverseOriginateMeshCode(coordinate);
        }
        #endregion

        #region GetMeshCodesFromRectangle
        /// <summary>
        /// 座標範囲に該当するメッシュコード群を取得します。
        /// </summary>
        /// <param name="rectangle">取得する範囲</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>メッシュコード群</returns>
        public static IEnumerable<int> GetMeshCodesFromRectangle(
            this CREO.FW.TMIGeometry.CoordinateRect rectangle,
            int meshType = 0)
        {
            return
                from meshCodeString in
                    CREO.FW.Utilities.MeshCodeUtility.GetMeshCodeSet(meshType, rectangle)
                let meshCode = meshCodeString.ParseInt32(-1)
                where meshCode != -1
                select meshCode;
        }
        #endregion

        #region GetRectangleFromMeshCode
        /// <summary>
        /// 指定されたメッシュコードから、範囲座標を取得します。
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>範囲座標を示すポリゴン</returns>
        public static CREO.FW.TMIGeometry.CoordinateRect GetRectangleFromMeshCode(
            this int meshCode,
            int meshType = 0)
        {
            return CREO.FW.Utilities.MeshCodeUtility.GetAreaCoordinateSet(
                meshType,
                meshCode.ToString(CultureInfo.InvariantCulture));
        }

        /// <summary>
        /// 指定されたメッシュコードから、範囲座標を取得します。
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>範囲座標を示すポリゴン</returns>
        public static CREO.FW.TMIGeometry.CoordinateRect GetRectangleFromMeshCode(
            this uint meshCode,
            int meshType = 0)
        {
            return CREO.FW.Utilities.MeshCodeUtility.GetAreaCoordinateSet(
                meshType,
                meshCode.ToString(CultureInfo.InvariantCulture));
        }
        #endregion

        #region Calculations
        /// <summary>
        /// 加算
        /// </summary>
        /// <param name="lhs">座標1</param>
        /// <param name="rhs">座標2</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.Coordinate Add(this CREO.FW.TMIGeometry.Coordinate lhs, CREO.FW.TMIGeometry.Coordinate rhs)
        {
            return new CREO.FW.TMIGeometry.Coordinate(
                lhs.Longitude + rhs.Longitude,
                lhs.Latitude + rhs.Latitude);
        }

        /// <summary>
        /// 減算
        /// </summary>
        /// <param name="lhs">座標1</param>
        /// <param name="rhs">座標2</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.Coordinate Sub(this CREO.FW.TMIGeometry.Coordinate lhs, CREO.FW.TMIGeometry.Coordinate rhs)
        {
            return new CREO.FW.TMIGeometry.Coordinate(
                lhs.Longitude - rhs.Longitude,
                lhs.Latitude - rhs.Latitude);
        }

        /// <summary>
        /// 乗算
        /// </summary>
        /// <param name="lhs">座標</param>
        /// <param name="rhs">乗数</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.Coordinate Mult(this CREO.FW.TMIGeometry.Coordinate lhs, double rhs)
        {
            return new CREO.FW.TMIGeometry.Coordinate(
                (long)((double)lhs.Longitude * rhs),
                (long)((double)lhs.Latitude * rhs));
        }

        /// <summary>
        /// 乗算
        /// </summary>
        /// <param name="lhs">座標1</param>
        /// <param name="rhs">座標2</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.Coordinate Mult(this CREO.FW.TMIGeometry.Coordinate lhs, CREO.FW.TMIGeometry.Coordinate rhs)
        {
            return new CREO.FW.TMIGeometry.Coordinate(
                (long)(((double)lhs.Longitude * (double)rhs.Longitude) - ((double)lhs.Latitude * (double)rhs.Latitude)),
                (long)(((double)lhs.Longitude * (double)rhs.Latitude) + ((double)lhs.Latitude * (double)rhs.Longitude)));
        }

        /// <summary>
        /// 乗算
        /// </summary>
        /// <param name="lhs">座標</param>
        /// <param name="rhs">乗数</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.CoordinateRect Mult(this CREO.FW.TMIGeometry.CoordinateRect lhs, double rhs)
        {
            var bl = lhs.BottomLeft.Mult(rhs);
            var tr = lhs.TopRight.Mult(rhs);

            return CreateRectangle(bl, tr);
        }

        /// <summary>
        /// 除算
        /// </summary>
        /// <param name="lhs">座標1</param>
        /// <param name="rhs">座標2</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.Coordinate Divide(this CREO.FW.TMIGeometry.Coordinate lhs, CREO.FW.TMIGeometry.Coordinate rhs)
        {
            var denominator =
                ((double)rhs.Longitude * (double)rhs.Longitude) +
                ((double)rhs.Latitude * (double)rhs.Latitude);

            return new CREO.FW.TMIGeometry.Coordinate(
                (long)((((double)lhs.Longitude * (double)rhs.Longitude) + ((double)lhs.Latitude * (double)rhs.Latitude)) / denominator),
                (long)((((double)lhs.Latitude * (double)rhs.Longitude) - ((double)lhs.Longitude * (double)rhs.Latitude)) / denominator));
        }

        /// <summary>
        /// 絶対値
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>結果</returns>
        public static double Absolute(this CREO.FW.TMIGeometry.Coordinate point)
        {
            return Math.Sqrt(
                ((double)point.Longitude * (double)point.Longitude) +
                ((double)point.Latitude * (double)point.Latitude));
        }

        /// <summary>
        /// 角度
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>結果</returns>
        public static double Degree(this CREO.FW.TMIGeometry.Coordinate point)
        {
            return Math.Atan((double)point.Latitude / (double)point.Longitude);
        }

        /// <summary>
        /// 内積(dot product) : a･b = |a||b|cosΘ
        /// </summary>
        /// <param name="lhs">座標1</param>
        /// <param name="rhs">座標2</param>
        /// <returns>結果</returns>
        public static double Dot(this CREO.FW.TMIGeometry.Coordinate lhs, CREO.FW.TMIGeometry.Coordinate rhs)
        {
            return ((double)lhs.Longitude * (double)rhs.Longitude) + ((double)lhs.Latitude * (double)rhs.Latitude);
        }

        /// <summary>
        /// 外積(cross product) : a×b = |a||b|sinΘ
        /// </summary>
        /// <param name="lhs">座標1</param>
        /// <param name="rhs">座標2</param>
        /// <returns>結果</returns>
        public static double Cross(this CREO.FW.TMIGeometry.Coordinate lhs, CREO.FW.TMIGeometry.Coordinate rhs)
        {
            return ((double)lhs.Longitude * (double)rhs.Latitude) - ((double)lhs.Latitude * (double)rhs.Longitude);
        }
        #endregion

        #region ToCoordinate
        /// <summary>
        /// Coordinateに変換します。
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.Coordinate ToCoordinate(this System.Windows.Point point)
        {
            return new CREO.FW.TMIGeometry.Coordinate((long)(point.X + 0.5), (long)(point.Y + 0.5));
        }

        /// <summary>
        /// Coordinateに変換します。
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.Coordinate ToCoordinate(this CREO.FW.TMIGeometry.CoordinateD point)
        {
            return new CREO.FW.TMIGeometry.Coordinate((long)(point.Longitude + 0.5), (long)(point.Latitude + 0.5));
        }
        #endregion

        #region ToCoordinateD
        /// <summary>
        /// CoordinateDに変換します。
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.CoordinateD ToCoordinateD(this CREO.FW.TMIGeometry.Coordinate point)
        {
            return new CREO.FW.TMIGeometry.CoordinateD(point.Longitude, point.Latitude);
        }

        /// <summary>
        /// CoordinateDに変換します。
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>結果</returns>
        public static CREO.FW.TMIGeometry.CoordinateD ToCoordinateD(this System.Windows.Point point)
        {
            return new CREO.FW.TMIGeometry.CoordinateD(point.X, point.Y);
        }
        #endregion

        #region ToPoint
        /// <summary>
        /// Pointに変換します。
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>結果</returns>
        public static System.Windows.Point ToPoint(this CREO.FW.TMIGeometry.Coordinate point)
        {
            return new System.Windows.Point(point.Longitude, point.Latitude);
        }

        /// <summary>
        /// Pointに変換します。
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>結果</returns>
        public static System.Windows.Point ToPoint(this CREO.FW.TMIGeometry.CoordinateD point)
        {
            return new System.Windows.Point(point.Longitude, point.Latitude);
        }
        #endregion

        #region ToMultiPolygon
        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="wkt">WellKnownText</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this string wkt)
        {
            return new MultiPolygon(wkt);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="gml">Geography Markup Language</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this XmlReader gml)
        {
            return new MultiPolygon(gml);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this System.Windows.Point point)
        {
            return new MultiPolygon(point);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this CREO.FW.TMIGeometry.Coordinate point)
        {
            return new MultiPolygon(point);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this CREO.FW.TMIGeometry.CoordinateD point)
        {
            return new MultiPolygon(point);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="pointCollection">座標のコレクション</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this IEnumerable<CREO.FW.TMIGeometry.Coordinate> pointCollection)
        {
            return new MultiPolygon(pointCollection);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="pointCollection">座標のコレクション</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this IEnumerable<CREO.FW.TMIGeometry.CoordinateD> pointCollection)
        {
            return new MultiPolygon(pointCollection);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="pointsCollection">座標群のコレクション</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this IEnumerable<IEnumerable<CREO.FW.TMIGeometry.Coordinate>> pointsCollection)
        {
            return new MultiPolygon(pointsCollection);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="pointsCollection">座標群のコレクション</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this IEnumerable<IEnumerable<CREO.FW.TMIGeometry.CoordinateD>> pointsCollection)
        {
            return new MultiPolygon(pointsCollection);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="rect">矩形</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this CREO.FW.TMIGeometry.CoordinateRect rect)
        {
            return new MultiPolygon(rect);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="compositePolygon">CompositePolygon</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this CREO.FW.TMIGeometry.CompositePolygon compositePolygon)
        {
            return new MultiPolygon(compositePolygon);
        }

        /// <summary>
        /// マルチポリゴンインターフェイスに変換します。
        /// </summary>
        /// <param name="compositePolygonCollection">CompositePolygonのコレクション</param>
        /// <returns>形状</returns>
        public static IMultiPolygon ToMultiPolygon(this IEnumerable<CREO.FW.TMIGeometry.CompositePolygon> compositePolygonCollection)
        {
            return new MultiPolygon(compositePolygonCollection);
        }
        #endregion

        #region Transform
        /// <summary>
        /// 指定したアフィン変換演算子を適用します。
        /// </summary>
        /// <param name="matrix">アフィン変換演算子を示す行列</param>
        /// <param name="rhs">対象の形状</param>
        /// <returns>形状</returns>
        public static IMultiPolygon Transform(this System.Windows.Media.Matrix matrix, IMultiPolygon rhs)
        {
            return rhs.TransformBy(matrix);
        }
        #endregion
    }
}

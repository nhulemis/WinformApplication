﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.27 TMI K.Matsui

using System.Collections.Generic;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// プロパティ定義との演算に使用する、詳細検索条件式の拡張クラスです。
    /// </summary>
    /// <remarks>Propertyクラスを参照して下さい。</remarks>
    public static class DetailClauseExtension
    {
        #region AndAll
        /// <summary>
        /// 指定された全ての式要素とのAnd演算を実行します。
        /// </summary>
        /// <param name="clauses">式要素群</param>
        /// <returns>式要素</returns>
        /// <remarks>LINQを使用して式要素を結合出来ます。</remarks>
        public static DetailClause AndAll(this IEnumerable<DetailClause> clauses)
        {
            Assertion.NullArgument(clauses, "式が必要です");

            var result = DetailClause.Empty;
            foreach (var rhs in clauses)
            {
                result = result & rhs;
            }

            return result;
        }
        #endregion

        #region OrAny
        /// <summary>
        /// 指定された全ての式要素とのOr演算を実行します。
        /// </summary>
        /// <param name="clauses">式要素群</param>
        /// <returns>式要素</returns>
        /// <remarks>LINQを使用して式要素を結合出来ます。</remarks>
        public static DetailClause OrAny(this IEnumerable<DetailClause> clauses)
        {
            Assertion.NullArgument(clauses, "式が必要です");

            var result = DetailClause.Empty;
            foreach (var rhs in clauses)
            {
                result = result | rhs;
            }

            return result;
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2013/03/19 MAPMASTER matsuiko

using System.Collections;
using System.Collections.Generic;
using System.Linq;
using CREO.Fluere.Common.Collections;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// メッシュ情報を格納するクラスです。
    /// </summary>
    public sealed class MeshInformation : IEnumerable<int>
    {
        #region Fields
        /// <summary>
        /// メッシュ情報
        /// </summary>
        private static readonly Dictionary<int, MeshInformation> _meshInformations =
            new Dictionary<int, MeshInformation>();

        /// <summary>
        /// メッシュ領域
        /// </summary>
        private readonly Dictionary<int, InternalMeshInformation> _meshRegions;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="meshType">メッシュタイプ</param>
        private MeshInformation(int meshType)
        {
            Assertion.Condition(meshType >= 0);

            // 指定されたメッシュタイプの全メッシュコード群を取得
            var allMeshCodes = CoordinateExtension.CreateRectangle().GetMeshCodesFromRectangle(meshType);

            this._meshRegions =
                (from meshCode in allMeshCodes
                 let allRectangle = meshCode.GetRectangleFromMeshCode(meshType)
                 let originateRectangle = CoordinateExtension.CreateRectangle(
                    allRectangle.BottomLeft.Latitude,
                    allRectangle.BottomLeft.Longitude,
                    allRectangle.TopRight.Latitude - 1,
                    allRectangle.TopRight.Longitude - 1)
                 let reverseOriginateRectangle = CoordinateExtension.CreateRectangle(
                    allRectangle.BottomLeft.Latitude + 1,
                    allRectangle.BottomLeft.Longitude + 1,
                    allRectangle.TopRight.Latitude,
                    allRectangle.TopRight.Longitude)
                 select KeyValuePair.Create(
                    meshCode,
                    new InternalMeshInformation
                    {
                        AllRectangle = allRectangle,
                        OriginateRectangle = originateRectangle,
                        ReverseOriginateRectangle = reverseOriginateRectangle,
                        AllRegion = allRectangle.ToMultiPolygon(),
                        OriginateRegion = originateRectangle.ToMultiPolygon(),
                        ReverseOriginateRegion = reverseOriginateRectangle.ToMultiPolygon()
                    })).ToDictionary();
        }
        #endregion

        #region GetMeshInformation
        /// <summary>
        /// メッシュ情報を取得します。
        /// </summary>
        /// <param name="meshType">メッシュタイプ</param>
        /// <returns>メッシュ情報</returns>
        public static MeshInformation GetMeshInformation(int meshType = 0)
        {
            lock (_meshInformations)
            {
                MeshInformation meshInformation;
                if (_meshInformations.TryGetValue(meshType, out meshInformation) == false)
                {
                    meshInformation = new MeshInformation(meshType);
                    _meshInformations.Add(meshType, meshInformation);
                }

                return meshInformation;
            }
        }
        #endregion

        #region GetMeshRectangle
        /// <summary>
        /// 指定されたメッシュコードに対応するメッシュ範囲情報を取得します。
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <returns>範囲（メッシュ範囲全体）</returns>
        public CREO.FW.TMIGeometry.CoordinateRect GetMeshRectangle(int meshCode)
        {
            return this._meshRegions[meshCode].AllRectangle.Clone();
        }
        #endregion

        #region GetOriginateMeshRegion
        /// <summary>
        /// 指定されたメッシュコードに対応するメッシュ範囲情報を取得します。
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <returns>範囲（右上辺を除く範囲）</returns>
        public CREO.FW.TMIGeometry.CoordinateRect GetOriginateMeshRectangle(int meshCode)
        {
            return this._meshRegions[meshCode].OriginateRectangle.Clone();
        }
        #endregion

        #region GetReverseOriginateMeshRegion
        /// <summary>
        /// 指定されたメッシュコードに対応するメッシュ範囲情報を取得します。
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <returns>範囲（左下辺を除く範囲）</returns>
        public CREO.FW.TMIGeometry.CoordinateRect GetReverseOriginateMeshRectangle(int meshCode)
        {
            return this._meshRegions[meshCode].ReverseOriginateRectangle.Clone();
        }
        #endregion

        #region GetMeshRegion
        /// <summary>
        /// 指定されたメッシュコードに対応するメッシュ範囲情報を取得します。
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <returns>範囲（メッシュ範囲全体）</returns>
        public IMultiPolygon GetMeshRegion(int meshCode)
        {
            return this._meshRegions[meshCode].AllRegion;
        }
        #endregion

        #region GetOriginateMeshRegion
        /// <summary>
        /// 指定されたメッシュコードに対応するメッシュ範囲情報を取得します。
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <returns>範囲（右上辺を除く範囲）</returns>
        public IMultiPolygon GetOriginateMeshRegion(int meshCode)
        {
            return this._meshRegions[meshCode].OriginateRegion;
        }
        #endregion

        #region GetReverseOriginateMeshRegion
        /// <summary>
        /// 指定されたメッシュコードに対応するメッシュ範囲情報を取得します。
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <returns>範囲（左下辺を除く範囲）</returns>
        public IMultiPolygon GetReverseOriginateMeshRegion(int meshCode)
        {
            return this._meshRegions[meshCode].ReverseOriginateRegion;
        }
        #endregion

        #region GetOriginateMeshCode
        /// <summary>
        /// 座標位置に該当するメッシュコードを取得します。
        /// </summary>
        /// <param name="coordinate">座標位置</param>
        /// <returns>メッシュコード（メッシュ左下辺を該当するとみなす）</returns>
        public int GetOriginateMeshCode(CREO.FW.TMIGeometry.Coordinate coordinate)
        {
            return
                (from meshCode in this.AsParallel()
                 let meshRectangle = this.GetOriginateMeshRectangle(meshCode)
                 where meshRectangle.ContainsPoint(coordinate)
                 select meshCode).FirstOrDefault();
        }
        #endregion

        #region GetReverseOriginateMeshCode
        /// <summary>
        /// 座標位置に該当するメッシュコードを取得します。
        /// </summary>
        /// <param name="coordinate">座標位置</param>
        /// <returns>メッシュコード（メッシュ右上辺を該当するとみなす）</returns>
        public int GetReverseOriginateMeshCode(CREO.FW.TMIGeometry.Coordinate coordinate)
        {
            return
                (from meshCode in this.AsParallel()
                 let meshRectangle = this.GetReverseOriginateMeshRectangle(meshCode)
                 where meshRectangle.ContainsPoint(coordinate)
                 select meshCode).FirstOrDefault();
        }
        #endregion

        #region GetEnumerator
        /// <summary>
        /// 列挙子を取得する
        /// </summary>
        /// <returns>列挙子</returns>
        public IEnumerator<int> GetEnumerator()
        {
            return this._meshRegions.Keys.GetEnumerator();
        }

        /// <summary>
        /// 列挙子を取得する
        /// </summary>
        /// <returns>列挙子</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion

        #region InternalMeshInformation
        /// <summary>
        /// InternalMeshInformationクラス
        /// </summary>
        private sealed class InternalMeshInformation
        {
            /// <summary>
            /// AllRectangle
            /// </summary>
            public CREO.FW.TMIGeometry.CoordinateRect AllRectangle
            {
                get;
                set;
            }

            /// <summary>
            /// OriginateRectangle
            /// </summary>
            public CREO.FW.TMIGeometry.CoordinateRect OriginateRectangle
            {
                get;
                set;
            }

            /// <summary>
            /// ReverseOriginateRectangle
            /// </summary>
            public CREO.FW.TMIGeometry.CoordinateRect ReverseOriginateRectangle
            {
                get;
                set;
            }

            /// <summary>
            /// AllRegion
            /// </summary>
            public IMultiPolygon AllRegion
            {
                get;
                set;
            }

            /// <summary>
            /// OriginateRegion
            /// </summary>
            public IMultiPolygon OriginateRegion
            {
                get;
                set;
            }

            /// <summary>
            /// ReverseOriginateRegion
            /// </summary>
            public IMultiPolygon ReverseOriginateRegion
            {
                get;
                set;
            }
        }
        #endregion
    }
}

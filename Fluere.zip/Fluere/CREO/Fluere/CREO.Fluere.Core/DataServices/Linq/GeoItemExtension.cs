﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.06 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Linq;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// GeoItemクラスの拡張メソッド群です。
    /// </summary>
    public static class GeoItemExtension
    {
        #region CreateItem
        /// <summary>
        /// データモデルインスタンスを生成します。
        /// </summary>
        /// <typeparam name="T">対象のデータモデルクラス</typeparam>
        /// <param name="dataService">データサービス</param>
        /// <returns>新しいインスタンス</returns>
        public static T CreateItem<T>(this CREO.DS.DataService dataService)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(dataService, "データサービスが必要です");

            return (T)dataService.CreateItem(typeof(T).Name);
        }
        #endregion

        #region GetTopologicalItems
        /// <summary>
        /// 指定されたSItemBase要素の位相関係にある要素を取得します。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="sItemBase">SItemBase要素</param>
        /// <returns>要素群</returns>
        /// <remarks>取得はその場で行われ、固定化されます。</remarks>
        public static IList<T> GetTopologicalItems<T>(
            this CREO.DataModel.SItemBase sItemBase)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(sItemBase, "インスタンスが必要です");

            return sItemBase.GetTopologicalItems(typeof(T).Name).OfType<T>().ToList();
        }

        /// <summary>
        /// 指定されたSItemBase要素の位相関係にある要素を取得します。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="sItemBase">SItemBase要素</param>
        /// <param name="preBoundFactory">事前バインドされたデータサービスファクトリ</param>
        /// <returns>要素群</returns>
        /// <remarks>取得はその場で行われ、固定化されます。</remarks>
        public static IList<T> GetTopologicalItems<T>(
            this CREO.DataModel.SItemBase sItemBase,
            IPreBoundDataServiceFactory preBoundFactory)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(sItemBase, "インスタンスが必要です");
            Assertion.NullArgument(preBoundFactory, "事前バインドされたデータサービスファクトリが必要です");

            return
                Conditional.OfPositionShared<T>(sItemBase).Execute(preBoundFactory).ToList();
        }

        /// <summary>
        /// 指定されたSItemBase要素の位相関係にある要素を取得します。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="sItemBase">SItemBase要素</param>
        /// <param name="dataService">使用するデータサービス</param>
        /// <param name="ignoreCache">キャッシュを無視するかどうか</param>
        /// <returns>要素群</returns>
        /// <remarks>取得はその場で行われ、固定化されます。</remarks>
        public static IList<T> GetTopologicalItems<T>(
            this CREO.DataModel.SItemBase sItemBase,
            CREO.DS.DataService dataService,
            bool ignoreCache = false)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(sItemBase, "インスタンスが必要です");
            Assertion.NullArgument(dataService, "データサービスが必要です");

            return
                Conditional.OfPositionShared<T>(sItemBase).Execute(dataService, ignoreCache).ToList();
        }
        #endregion

        #region DistinctByOID
        /// <summary>
        /// シーケンス中のGeoItem要素をOIDで一意に絞り込みます。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="geoItems">シーケンス</param>
        /// <returns>一意化されたシーケンス</returns>
        /// <remarks>要素の比較はOIDで行われます。</remarks>
        public static IEnumerable<T> DistinctByOID<T>(this IEnumerable<T> geoItems)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(geoItems, "インスタンスが必要です");

            return geoItems.Distinct(GeoItemComparer<T>.Default);
        }

        /// <summary>
        /// シーケンス中のGeoItem要素をOIDで一意に絞り込みます。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="geoItems">シーケンス</param>
        /// <returns>一意化されたシーケンス</returns>
        /// <remarks>要素の比較はOIDで行われます。</remarks>
        public static ParallelQuery<T> DistinctByOID<T>(this ParallelQuery<T> geoItems)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(geoItems, "インスタンスが必要です");

            return geoItems.Distinct(GeoItemComparer<T>.Default);
        }
        #endregion

        #region GetOrderedSPoints
        /// <summary>
        /// SPolylineが示す両端の要素を、開始・終了位置として取得します。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="sPolyline">SPolyline</param>
        /// <param name="sPoints">SPoint</param>
        /// <returns>開始・終了位置の順に設定された配列（必ず要素数2）</returns>
        private static T[] InternalGetOrderdSPoints<T>(CREO.DataModel.SPolyline sPolyline, IList<T> sPoints)
           where T : CREO.DataModel.SPoint
        {
            Assertion.Condition(sPolyline != null);
            Assertion.Condition(sPoints != null);

            Assertion.Require(
                sPoints.Count == 2,
                "SPolylineからSPointが正しく取得出来ません: From={0}, Target={1}, {0}.OID={2}, SPoints.Count={3}",
                sPolyline.GetType().Name,
                typeof(T).Name,
                sPolyline.OID,
                sPoints.Count);

            var startPosition = sPolyline.Geometry[0];
            var endPosition = sPolyline.Geometry[sPolyline.Geometry.Count - 1];

            if ((sPoints[0].Geometry == startPosition) && (sPoints[1].Geometry == endPosition))
            {
                return new[] { sPoints[0], sPoints[1] };
            }
            else if ((sPoints[1].Geometry == startPosition) && (sPoints[0].Geometry == endPosition))
            {
                return new[] { sPoints[1], sPoints[0] };
            }
            else
            {
                throw new InvalidOperationException(
                    string.Format(
                        "SPolylineとSPointの位置が一致しません: From={0}, Target={1}, {0}.OID={2}, {1}[0].OID={3}, {1}[1].OID={4}",
                        sPolyline.GetType().Name,
                        typeof(T).Name,
                        sPolyline.OID,
                        sPoints[0].OID,
                        sPoints[1].OID));
            }
        }

        /// <summary>
        /// SPolylineが示す両端の要素を、開始・終了位置として取得します。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="sPolyline">SPolyline</param>
        /// <returns>開始・終了位置の順に設定された配列（必ず要素数2）</returns>
        /// <remarks>SRoadMainの両端のSCrsMainの取得等に使用します。</remarks>
        public static T[] GetOrderedSPoints<T>(
            this CREO.DataModel.SPolyline sPolyline)
           where T : CREO.DataModel.SPoint
        {
            Assertion.NullArgument(sPolyline, "SPolylineのインスタンスが必要です");
            Assertion.Condition(sPolyline.Geometry.Count >= 2);

            var sPoints = sPolyline.GetTopologicalItems<T>();
            return InternalGetOrderdSPoints<T>(sPolyline, sPoints);
        }

        /// <summary>
        /// SPolylineが示す両端の要素を、開始・終了位置として取得します。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="sPolyline">SPolyline</param>
        /// <param name="preBoundFactory">事前バインドされたデータサービスファクトリ</param>
        /// <returns>開始・終了位置の順に設定された配列（必ず要素数2）</returns>
        /// <remarks>SRoadMainの両端のSCrsMainの取得等に使用します。</remarks>
        public static T[] GetOrderedSPoints<T>(
            this CREO.DataModel.SPolyline sPolyline,
            IPreBoundDataServiceFactory preBoundFactory)
           where T : CREO.DataModel.SPoint
        {
            Assertion.NullArgument(sPolyline, "SPolylineのインスタンスが必要です");
            Assertion.NullArgument(preBoundFactory, "事前バインドされたデータサービスファクトリが必要です");
            Assertion.Condition(sPolyline.Geometry.Count >= 2);

            var sPoints = sPolyline.GetTopologicalItems<T>(preBoundFactory);
            return InternalGetOrderdSPoints<T>(sPolyline, sPoints);
        }

        /// <summary>
        /// SPolylineが示す両端の要素を、開始・終了位置として取得します。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="sPolyline">SPolyline</param>
        /// <param name="dataService">使用するデータサービス</param>
        /// <param name="ignoreCache">キャッシュを無視するかどうか</param>
        /// <returns>開始・終了位置の順に設定された配列（必ず要素数2）</returns>
        /// <remarks>SRoadMainの両端のSCrsMainの取得等に使用します。</remarks>
        public static T[] GetOrderedSPoints<T>(
            this CREO.DataModel.SPolyline sPolyline,
            CREO.DS.DataService dataService,
            bool ignoreCache = false)
           where T : CREO.DataModel.SPoint
        {
            Assertion.NullArgument(sPolyline, "SPolylineのインスタンスが必要です");
            Assertion.NullArgument(dataService, "データサービスが必要です");
            Assertion.Condition(sPolyline.Geometry.Count >= 2);

            var sPoints = sPolyline.GetTopologicalItems<T>(dataService, ignoreCache);
            return InternalGetOrderdSPoints<T>(sPolyline, sPoints);
        }
        #endregion

        #region GetDependingItems
        /// <summary>
        /// 指定された依存実体が依存する、空間実体を取得します。
        /// </summary>
        /// <typeparam name="T">空間実体の型</typeparam>
        /// <param name="dItemBase">依存実体</param>
        /// <returns>空間実体を示す列挙子</returns>
        public static IList<T> GetDependingItems<T>(this CREO.DataModel.DItemBase dItemBase)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(dItemBase, "DItemBaseのインスタンスが必要です");
            return dItemBase.GetDependingItems().OfType<T>().ToList();
        }

        /// <summary>
        /// 指定された依存実体が依存する、空間実体を取得します。
        /// </summary>
        /// <typeparam name="T">空間実体の型</typeparam>
        /// <param name="dItemBase">依存実体</param>
        /// <param name="preBoundFactory">事前バインドされたデータサービスファクトリ</param>
        /// <returns>空間実体を示す列挙子</returns>
        public static IList<T> GetDependingItems<T>(
            this CREO.DataModel.DItemBase dItemBase,
            IPreBoundDataServiceFactory preBoundFactory)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(dItemBase, "DItemBaseのインスタンスが必要です");
            Assertion.NullArgument(preBoundFactory, "事前バインドされたデータサービスファクトリが必要です");
            return

                // TODO: DataServiceのuseCacheが廃止された為、ExecuteのignoreCacheが実質無効になっている。見直しが必要
                Conditional.OfDependedBy<T>(dItemBase).Execute(preBoundFactory).ToList();
        }

        /// <summary>
        /// 指定された依存実体が依存する、空間実体を取得します。
        /// </summary>
        /// <typeparam name="T">空間実体の型</typeparam>
        /// <param name="dItemBase">依存実体</param>
        /// <param name="dataService">使用するデータサービス</param>
        /// <param name="ignoreCache">キャッシュを無視するかどうか</param>
        /// <returns>空間実体を示す列挙子</returns>
        public static IList<T> GetDependingItems<T>(
            this CREO.DataModel.DItemBase dItemBase,
            CREO.DS.DataService dataService,
            bool ignoreCache = false)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(dItemBase, "DItemBaseのインスタンスが必要です");
            Assertion.NullArgument(dataService, "データサービスが必要です");
            return
                Conditional.OfDependedBy<T>(dItemBase).Execute(dataService, ignoreCache).ToList();
        }
        #endregion

        #region GetDependencyItems
        /// <summary>
        /// 指定された空間実体が依存する、依存実体を取得します。
        /// </summary>
        /// <typeparam name="T">依存実体の型</typeparam>
        /// <param name="sItemBase">空間実体</param>
        /// <returns>依存実体を示す列挙子</returns>
        public static IList<T> GetDependencyItems<T>(this CREO.DataModel.SItemBase sItemBase)
            where T : CREO.DataModel.DItemBase
        {
            Assertion.NullArgument(sItemBase, "SItemBaseのインスタンスが必要です");
            return sItemBase.GetDependencyItems(typeof(T).Name).OfType<T>().ToList();
        }

        /// <summary>
        /// 指定された依存実体が依存する、空間実体を取得します。
        /// </summary>
        /// <typeparam name="T">空間実体の型</typeparam>
        /// <param name="sItemBase">依存実体</param>
        /// <param name="preBoundFactory">事前バインドされたデータサービスファクトリ</param>
        /// <returns>空間実体を示す列挙子</returns>
        public static IList<T> GetDependencyItems<T>(
            this CREO.DataModel.SItemBase sItemBase,
            IPreBoundDataServiceFactory preBoundFactory)
            where T : CREO.DataModel.DItemBase
        {
            Assertion.NullArgument(sItemBase, "SItemBaseのインスタンスが必要です");
            Assertion.NullArgument(preBoundFactory, "事前バインドされたデータサービスファクトリが必要です");
            return

                // TODO: DataServiceのuseCacheが廃止された為、ExecuteのignoreCacheは無効となっている。見直しが必要
                Conditional.OfDependingTo<T>(sItemBase).Execute(preBoundFactory).ToList();
        }

        /// <summary>
        /// 指定された依存実体が依存する、空間実体を取得します。
        /// </summary>
        /// <typeparam name="T">空間実体の型</typeparam>
        /// <param name="sItemBase">依存実体</param>
        /// <param name="dataService">使用するデータサービス</param>
        /// <param name="ignoreCache">キャッシュを無視するかどうか</param>
        /// <returns>空間実体を示す列挙子</returns>
        public static IList<T> GetDependencyItems<T>(
            this CREO.DataModel.SItemBase sItemBase,
            CREO.DS.DataService dataService,
            bool ignoreCache = false)
            where T : CREO.DataModel.DItemBase
        {
            Assertion.NullArgument(sItemBase, "SItemBaseのインスタンスが必要です");
            Assertion.NullArgument(dataService, "データサービスが必要です");
            return
                Conditional.OfDependingTo<T>(sItemBase).Execute(dataService, ignoreCache).ToList();
        }
        #endregion

        #region ToComparable
        /// <summary>
        /// シーケンス中のGeoItem要素をOIDで比較可能にします。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="geoItems">シーケンス</param>
        /// <returns>比較可能なシーケンス</returns>
        public static IEnumerable<IComparable<T>> ToComparable<T>(this IEnumerable<T> geoItems)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(geoItems, "インスタンスが必要です");

            return from geoItem in geoItems
                   select new GeoItemComparable<T>(geoItem);
        }

        /// <summary>
        /// シーケンス中のGeoItem要素をOIDで比較可能にします。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="geoItems">シーケンス</param>
        /// <returns>比較可能なシーケンス</returns>
        public static ParallelQuery<IComparable<T>> ToComparable<T>(this ParallelQuery<T> geoItems)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(geoItems, "インスタンスが必要です");

            return from geoItem in geoItems
                   select (IComparable<T>)new GeoItemComparable<T>(geoItem);
        }

        /// <summary>
        /// GeoItem要素をOIDで比較可能にします。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        /// <param name="geoItem">GeoItem要素</param>
        /// <returns>比較可能なインスタンス</returns>
        public static GeoItemComparable<T> ToComparable<T>(this T geoItem)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(geoItem, "インスタンスが必要です");

            return new GeoItemComparable<T>(geoItem);
        }
        #endregion
    }
}

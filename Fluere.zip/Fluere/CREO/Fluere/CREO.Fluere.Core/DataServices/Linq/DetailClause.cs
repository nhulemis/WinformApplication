﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.27 TMI K.Matsui

using System;
using System.Collections.Generic;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// プロパティ定義との演算に使用する、詳細検索条件を示す式要素クラスです。
    /// </summary>
    /// <remarks>Propertyクラスを参照して下さい。</remarks>
    public sealed class DetailClause
    {
        #region Fields
        /// <summary>
        /// 空の式
        /// </summary>
        private static readonly DetailClause EMPTY = new DetailClause();

        /// <summary>
        /// 式
        /// </summary>
        private CREO.DS.SqlConditionExpression _expression;
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        private DetailClause()
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="expression">SqlConditionExpression</param>
        internal DetailClause(CREO.DS.SqlConditionExpression expression)
        {
            Assertion.Condition(expression != null);
            this._expression = expression;
        }
        #endregion

        #region Empty
        /// <summary>
        /// 空の式を取得します。
        /// </summary>
        internal static DetailClause Empty
        {
            get
            {
                return EMPTY;
            }
        }
        #endregion

        #region RawConditionExpression
        /// <summary>
        /// 結果を取得します。
        /// </summary>
        internal CREO.DS.SqlConditionExpression RawConditionExpression
        {
            get
            {
                return this._expression;
            }
        }
        #endregion

        #region operator ==
        /// <summary>
        /// 式要素と値を比較します。
        /// </summary>
        /// <param name="lhs">式要素</param>
        /// <param name="rhs">値</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">式要素同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("式要素同士を比較する事は出来ません")]
        public static DetailClause operator ==(DetailClause lhs, DetailClause rhs)
        {
            throw new InvalidOperationException("式要素同士を比較する事は出来ません");
        }
        #endregion

        #region operator !=
        /// <summary>
        /// 式要素と値を比較します。
        /// </summary>
        /// <param name="lhs">式要素</param>
        /// <param name="rhs">値</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">式要素同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("式要素同士を比較する事は出来ません")]
        public static DetailClause operator !=(DetailClause lhs, DetailClause rhs)
        {
            throw new InvalidOperationException("式要素同士を比較する事は出来ません");
        }
        #endregion

        #region operator !
        /// <summary>
        /// 式要素を否定演算します。
        /// </summary>
        /// <param name="expression">式要素</param>
        /// <returns>否定演算の結果</returns>
        public static DetailClause operator !(DetailClause expression)
        {
            Assertion.NullArgument(expression, "式要素が必要です");
            Assertion.NullArgument(expression._expression, "空の式を否定出来ません");
            return new DetailClause(CREO.DS.SqlConditionExpression.Not(expression._expression));
        }
        #endregion

        #region operator &
        /// <summary>
        /// 式要素同士をAnd演算します。
        /// </summary>
        /// <param name="lhs">式要素(左)</param>
        /// <param name="rhs">式要素(右)</param>
        /// <returns>And演算の結果</returns>
        public static DetailClause operator &(DetailClause lhs, DetailClause rhs)
        {
            Assertion.NullArgument(lhs, "式要素が必要です");
            Assertion.NullArgument(rhs, "式要素が必要です");
            if ((lhs._expression != null) && (rhs._expression != null))
            {
                return new DetailClause(CREO.DS.SqlConditionExpression.And(lhs._expression, rhs._expression));
            }
            else
            {
                return EMPTY;
            }
        }
        #endregion

        #region operator |
        /// <summary>
        /// 式要素同士をOr演算します。
        /// </summary>
        /// <param name="lhs">式要素(左)</param>
        /// <param name="rhs">式要素(右)</param>
        /// <returns>Or演算の結果</returns>
        public static DetailClause operator |(DetailClause lhs, DetailClause rhs)
        {
            Assertion.NullArgument(lhs, "式要素が必要です");
            Assertion.NullArgument(rhs, "式要素が必要です");
            if ((lhs._expression != null) && (rhs._expression != null))
            {
                return new DetailClause(CREO.DS.SqlConditionExpression.Or(lhs._expression, rhs._expression));
            }
            else if ((lhs._expression == null) && (rhs._expression == null))
            {
                return EMPTY;
            }
            else if (lhs._expression == null)
            {
                return new DetailClause(rhs._expression);
            }
            else
            {
                return new DetailClause(lhs._expression);
            }
        }
        #endregion

        #region AndAll
        /// <summary>
        /// 指定された全ての式要素とのAnd演算を実行します。
        /// </summary>
        /// <param name="args">式要素群</param>
        /// <returns>式要素</returns>
        public DetailClause AndAll(params DetailClause[] args)
        {
            return this.AndAll((IEnumerable<DetailClause>)args);
        }

        /// <summary>
        /// 指定された全ての式要素とのAnd演算を実行します。
        /// </summary>
        /// <param name="args">式要素群</param>
        /// <returns>式要素</returns>
        public DetailClause AndAll(IEnumerable<DetailClause> args)
        {
            var result = this;
            foreach (var rhs in args)
            {
                result = result & rhs;
            }

            return result;
        }
        #endregion

        #region OrAny
        /// <summary>
        /// 指定された全ての式要素とのOr演算を実行します。
        /// </summary>
        /// <param name="args">式要素群</param>
        /// <returns>式要素</returns>
        public DetailClause OrAny(params DetailClause[] args)
        {
            return this.OrAny((IEnumerable<DetailClause>)args);
        }

        /// <summary>
        /// 指定された全ての式要素とのOr演算を実行します。
        /// </summary>
        /// <param name="args">式要素群</param>
        /// <returns>式要素</returns>
        public DetailClause OrAny(IEnumerable<DetailClause> args)
        {
            var result = this;
            foreach (var rhs in args)
            {
                result = result | rhs;
            }

            return result;
        }
        #endregion

        #region Equals
        /// <summary>
        /// 式要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <exception cref="InvalidOperationException">式要素同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("式要素同士を比較する事は出来ません")]
        public void Equals(DetailClause rhs)
        {
            throw new InvalidOperationException("式要素同士を比較する事は出来ません");
        }

        /// <summary>
        /// 式要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">式要素同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        public override bool Equals(object rhs)
        {
            throw new InvalidOperationException("式要素同士を比較する事は出来ません");
        }
        #endregion

        #region GetHashCode
        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">ハッシュコードは取得出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        public override int GetHashCode()
        {
            throw new InvalidOperationException("ハッシュコードは取得出来ません");
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.06 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Linq;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// IEnumerableの拡張メソッド群です。
    /// </summary>
    public static class EnumerableExtension
    {
        /// <summary>
        /// 指定されたデリゲートを使用して、コレクションを列挙しながら処理を実行します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="source">コレクション</param>
        /// <param name="action">デリゲート</param>
        public static void ForEach<T>(this IEnumerable<T> source, Action<T> action)
        {
            Assertion.NullArgument(source, "コレクションが必要です");
            Assertion.NullArgument(action, "デリゲートが必要です");

            foreach (var value in source)
            {
                action(value);
            }
        }

        /// <summary>
        /// 指定されたデリゲートを使用して、コレクションを列挙しながら処理を並列実行します。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="source">コレクション</param>
        /// <param name="action">デリゲート</param>
        public static void ForEach<T>(this ParallelQuery<T> source, Action<T> action)
        {
            Assertion.NullArgument(source, "コレクションが必要です");
            Assertion.NullArgument(action, "デリゲートが必要です");

            source.ForAll(action);
        }

        /// <summary>
        /// Distinct演算子です。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="equals">比較演算を実行するデリゲート</param>
        /// <param name="getHashCode">ハッシュコードを取得するデリゲート</param>
        /// <returns>結果</returns>
        public static IEnumerable<T> Distinct<T>(
            this IEnumerable<T> enumerable, Func<T, T, bool> equals, Func<T, int> getHashCode)
        {
            return enumerable.Distinct(new EqualityComparerDelegator<T>(equals, getHashCode));
        }

        /// <summary>
        /// Distinct演算子です。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <param name="enumerable">列挙子</param>
        /// <param name="equals">比較演算を実行するデリゲート</param>
        /// <param name="getHashCode">ハッシュコードを取得するデリゲート</param>
        /// <returns>結果</returns>
        public static ParallelQuery<T> Distinct<T>(
            this ParallelQuery<T> enumerable, Func<T, T, bool> equals, Func<T, int> getHashCode)
        {
            return enumerable.Distinct(new EqualityComparerDelegator<T>(equals, getHashCode));
        }

        #region EqualityComparerDelegator
        /// <summary>
        /// 比較処理を外部のデリゲートに移譲するIEqualityComparerの実装です。
        /// </summary>
        /// <typeparam name="T">対象の型</typeparam>
        private sealed class EqualityComparerDelegator<T> : IEqualityComparer<T>
        {
            /// <summary>
            /// Equalsデリゲート
            /// </summary>
            private readonly Func<T, T, bool> _equals;

            /// <summary>
            /// GetHashCodeデリゲート
            /// </summary>
            private readonly Func<T, int> _getHashCode;

            /// <summary>
            /// コンストラクタです。
            /// </summary>
            /// <param name="equals">比較処理</param>
            /// <param name="getHashCode">ハッシュコード取得</param>
            public EqualityComparerDelegator(Func<T, T, bool> equals, Func<T, int> getHashCode)
            {
                this._equals = equals;
                this._getHashCode = getHashCode;
            }

            /// <summary>
            /// 比較を実行します。
            /// </summary>
            /// <param name="x">比較元</param>
            /// <param name="y">比較先</param>
            /// <returns>一致していればtrue</returns>
            public bool Equals(T x, T y)
            {
                return this._equals(x, y);
            }

            /// <summary>
            /// ハッシュコードを取得します。
            /// </summary>
            /// <param name="obj">インスタンス</param>
            /// <returns>ハッシュコード</returns>
            public int GetHashCode(T obj)
            {
                return this._getHashCode(obj);
            }
        }
        #endregion
    }
}

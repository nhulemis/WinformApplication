﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.05 TMI K.Matsui

using System;
using System.Linq;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// 詳細検索条件式の生成を補助するヘルパークラスです。
    /// </summary>
    /// <remarks>簡便な記述でConditionExpressionの階層構造を記述する事が出来る構文糖クラスです。
    /// Conditionalヘルパークラスと共に使用します。</remarks>
    /// <example>
    /// <code>
    /// // 特定のメッシュコード内のIC番号が100以上で料金所専用ICのSCrsMainを取得する
    /// var meshCode = 623654;
    /// var result1 =
    ///     (from sCrsMain in
    ///         Conditional.
    ///             OfRange&lt;CREO.DataModel.SCrsMain&gt;(meshCode).
    ///             Details(
    ///                 (Property.Name("ICNo") >= 100) &amp;                // IC番号が100以上
    ///                 (Property.Name("TollListExclusiveICFlg") != 0)).    // 料金所専用IC
    ///             From(dataService).
    ///             AsParallel()    // 以降のクエリを並列実行
    ///      where sCrsMain.Geometry.GetMeshCode() == meshCode   // 余分に取得される要素を除外
    ///      select sCrsMain);
    /// </code>
    /// <code>
    /// // 特定のTAdrNameをAdrNameプロパティに持つSPOIFacilityを取得する
    /// CREO.DataModel.TAdrName tAdrName = ...;
    /// var result2 =
    ///     Conditional.
    ///         Of&lt;CREO.DataModel.SPOIFacility&gt;().
    ///         Details(Property.Name("AdrName") == tAdrName).    // AdrNameと一致する
    ///         From(dataService).
    ///         AsParallel();    // 以降のクエリを並列実行
    /// </code>
    /// <code>
    /// // 05探索道路番号がNullでないものを含むSRoadMainを取得する
    /// var result3 =
    ///     Conditional.
    ///         Of&lt;CREO.DataModel.SRoadMain&gt;().
    ///         Details(!Property.IsNull("Road05GuideNoAry[*].RoadNo")).    // RoadNoがNullではない
    ///         From(dataService).
    ///         AsParallel();    // 以降のクエリを並列実行
    /// </code>
    /// <code>
    /// // 詳細検索条件をプログラマブルに構築する
    /// var excludeICNumberDetails =
    ///     from icNumber in icNumbers
    ///     select Property.Name("ICNo") != icNumber;      // 指定されたIC番号以外
    /// var result4 =
    ///     Conditional.
    ///         Of&lt;CREO.DataModel.SRoadMain&gt;().
    ///         Details(excludeICNumberDetails.AndAll()).  // 上記検索条件をAnd結合
    ///         From(dataService).
    ///         AsParallel();    // 以降のクエリを並列実行
    /// </code>
    /// </example>
    public sealed class Property
    {
        #region Fields
        /// <summary>
        /// プロパティ名
        /// </summary>
        private readonly string _name;
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="name">プロパティ名</param>
        private Property(string name)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(name) == false);
            this._name = name;
        }
        #endregion

        #region operator ==
        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, CREO.DataModel.GeoItem rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");
            Assertion.NullArgument(rhs, "GeoItemクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    (rhs != null) ? (object)rhs.OID : null));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, string rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");
            Assertion.NullArgument(rhs, "文字列が必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, bool rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs ? "True" : "False"));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, byte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, sbyte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, ushort rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, short rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, uint rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, int rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, ulong rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, long rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, float rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator ==(Property lhs, double rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義(左)</param>
        /// <param name="rhs">プロパティ定義(右)</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">プロパティ同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("プロパティ同士を比較する事は出来ません")]
        public static DetailClause operator ==(Property lhs, Property rhs)
        {
            throw new InvalidOperationException("プロパティ同士を比較する事は出来ません");
        }
        #endregion

        #region operator !=
        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, CREO.DataModel.GeoItem rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");
            Assertion.NullArgument(rhs, "GeoItemクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    (rhs != null) ? (object)rhs.OID : null));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, string rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");
            Assertion.NullArgument(rhs, "文字列が必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, bool rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs ? "True" : "False"));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, byte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, sbyte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, ushort rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, short rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, uint rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, int rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, ulong rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, long rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, float rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator !=(Property lhs, double rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.NotEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義(左)</param>
        /// <param name="rhs">プロパティ定義(右)</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">プロパティ同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("プロパティ同士を比較する事は出来ません")]
        public static DetailClause operator !=(Property lhs, Property rhs)
        {
            throw new InvalidOperationException("プロパティ同士を比較する事は出来ません");
        }
        #endregion

        #region operator <=
        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, CREO.DataModel.GeoItem rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");
            Assertion.NullArgument(rhs, "GeoItemクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    (rhs != null) ? (object)rhs.OID : null));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, byte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, sbyte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, ushort rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, short rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, uint rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, int rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, ulong rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, long rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, float rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <=(Property lhs, double rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.LessEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義(左)</param>
        /// <param name="rhs">プロパティ定義(右)</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">プロパティ同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("プロパティ同士を比較する事は出来ません")]
        public static DetailClause operator <=(Property lhs, Property rhs)
        {
            throw new InvalidOperationException("プロパティ同士を比較する事は出来ません");
        }
        #endregion

        #region operator <
        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, CREO.DataModel.GeoItem rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");
            Assertion.NullArgument(rhs, "GeoItemクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    (rhs != null) ? (object)rhs.OID : null));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, byte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, sbyte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, ushort rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, short rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, uint rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, int rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, ulong rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, long rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, float rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator <(Property lhs, double rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Less,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義(左)</param>
        /// <param name="rhs">プロパティ定義(右)</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">プロパティ同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("プロパティ同士を比較する事は出来ません")]
        public static DetailClause operator <(Property lhs, Property rhs)
        {
            throw new InvalidOperationException("プロパティ同士を比較する事は出来ません");
        }
        #endregion

        #region operator >=
        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, CREO.DataModel.GeoItem rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");
            Assertion.NullArgument(rhs, "GeoItemクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    (rhs != null) ? (object)rhs.OID : null));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, byte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, sbyte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, ushort rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, short rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, uint rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, int rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, ulong rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, long rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, float rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >=(Property lhs, double rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.GreatEqual,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義(左)</param>
        /// <param name="rhs">プロパティ定義(右)</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">プロパティ同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("プロパティ同士を比較する事は出来ません")]
        public static DetailClause operator >=(Property lhs, Property rhs)
        {
            throw new InvalidOperationException("プロパティ同士を比較する事は出来ません");
        }
        #endregion

        #region operator >
        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, CREO.DataModel.GeoItem rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");
            Assertion.NullArgument(rhs, "GeoItemクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    (rhs != null) ? (object)rhs.OID : null));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, byte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, sbyte rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, ushort rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, short rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, uint rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, int rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, ulong rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, long rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, float rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義</param>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public static DetailClause operator >(Property lhs, double rhs)
        {
            Assertion.NullArgument(lhs, "Propertyクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    lhs._name,
                    CREO.DS.QueryItemOperator.Great,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="lhs">プロパティ定義(左)</param>
        /// <param name="rhs">プロパティ定義(右)</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">プロパティ同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("プロパティ同士を比較する事は出来ません")]
        public static DetailClause operator >(Property lhs, Property rhs)
        {
            throw new InvalidOperationException("プロパティ同士を比較する事は出来ません");
        }
        #endregion

        #region Name
        /// <summary>
        /// データモデルクラスのプロパティ名・又は検索式を定義します。
        /// </summary>
        /// <param name="name">プロパティ名・又は検索式を示す文字列</param>
        /// <returns>Propertyクラスのインスタンス</returns>
        public static Property Name(string name)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(name) == false, "プロパティ名・又は式が必要です");
            return new Property(name);
        }
        #endregion

        #region IsNull
        /// <summary>
        /// 指定されたプロパティ名・又は検索式がNullかどうかを確認します。
        /// </summary>
        /// <param name="name">プロパティ名・又は検索式を示す文字列</param>
        /// <param name="isStringType">プロパティ名・又は検索式の対象が文字列を示す場合はtrue</param>
        /// <returns>式要素</returns>
        public static DetailClause IsNull(string name, bool isStringType = false)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(name) == false, "プロパティ名・又は式が必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    name,
                    CREO.DS.QueryItemOperator.Equal,
                    isStringType ? (object)CREO.DataModel.GeoItem.Code.UNDEFINEDSTR : (object)CREO.DataModel.GeoItem.Code.UNDEFINED));
        }
        #endregion

        #region In
        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <typeparam name="T">値の型</typeparam>
        /// <param name="values">値群</param>
        /// <returns>式要素</returns>
        public DetailClause In<T>(params T[] values)
            where T : struct
        {
            if (typeof(T) == typeof(bool))
            {
                return new DetailClause(
                    new CREO.DS.SqlConditionExpression(
                        this._name,
                        CREO.DS.QueryItemOperator.In,
                        values.Select(value => ((bool)(object)value) ? "True" : "False").ToArray()));
            }
            else
            {
                return new DetailClause(
                    new CREO.DS.SqlConditionExpression(this._name, CREO.DS.QueryItemOperator.In, values));
            }
        }
        #endregion

        #region Like
        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Like(string rhs)
        {
            Assertion.Argument(string.IsNullOrWhiteSpace(rhs) == false, "比較文字列が必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(this._name, CREO.DS.QueryItemOperator.Like, rhs));
        }
        #endregion

        #region Equals
        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(CREO.DataModel.GeoItem rhs)
        {
            Assertion.NullArgument(rhs, "GeoItemクラスのインスタンスが必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    (rhs != null) ? (object)rhs.OID : null));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(string rhs)
        {
            Assertion.NullArgument(rhs, "文字列が必要です");

            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(bool rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs ? "True" : "False"));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(byte rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(sbyte rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(ushort rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(short rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(uint rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(int rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(ulong rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(long rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(float rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>式要素</returns>
        public DetailClause Equals(double rhs)
        {
            return new DetailClause(
                new CREO.DS.SqlConditionExpression(
                    this._name,
                    CREO.DS.QueryItemOperator.Equal,
                    rhs));
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">プロパティ定義</param>
        /// <exception cref="InvalidOperationException">プロパティ同士を比較する事は出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        [Obsolete("プロパティ同士を比較する事は出来ません")]
        public void Equals(Property rhs)
        {
            throw new InvalidOperationException("プロパティ同士を比較する事は出来ません");
        }

        /// <summary>
        /// プロパティ定義の要素と値を比較します。
        /// </summary>
        /// <param name="rhs">値</param>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">任意のインスタンスと比較出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        public override bool Equals(object rhs)
        {
            throw new InvalidOperationException(
                string.Format("無効な型です: {0}", (rhs != null) ? rhs.GetType().FullName : "(null)"));
        }
        #endregion

        #region GetHashCode
        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <returns>（なし）</returns>
        /// <exception cref="InvalidOperationException">ハッシュコードは取得出来ません</exception>
        /// <remarks>メソッドは実装されていません。</remarks>
        public override int GetHashCode()
        {
            throw new InvalidOperationException("ハッシュコードは取得出来ません");
        }
        #endregion
    }
}

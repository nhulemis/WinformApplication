﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.06 TMI K.Matsui

using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// クエリパラメータ生成を補助するヘルパークラスです。
    /// </summary>
    /// <remarks>QueryItemsConditionを使用したクエリ条件記述の構文糖クラスです。
    /// 誤った検索条件指定をコンパイル時に検出します。</remarks>
    /// <example>
    /// <code>
    /// // メッシュコードを限定してSCrsMainを取得し、05表示交差点番号を列挙する
    /// var meshCode = 623654;
    /// var result1 =
    ///     (from sCrsMain in
    ///         Conditional.
    ///             OfRange&lt;CREO.DataModel.SCrsMain&gt;(meshCode).    // メッシュコードを限定
    ///             From(dataService).  // データサービスを指定
    ///             AsParallel()    // 以降のクエリを並列実行
    ///      where sCrsMain.Geometry.GetMeshCode() == meshCode   // 余分に取得される要素を除外
    ///      from tmiCrsNo in sCrsMain.Crs05MMNoAry
    ///      where tmiCrsNo.MeshNo == meshCode   // 隣接交差点を除外
    ///      select tmiCrsNo.CrsNo).    // 05表示交差点番号を抽出
    ///      Distinct();    // 一意化
    /// </code>
    /// <code>
    /// // 指定されたSCrsMainと位相関係にあるSRoadMainのうち、05探索交差点が存在するものを列挙する
    /// CREO.DataModel.SCrsMain sCrsMain = ...;
    /// var result2 =
    ///     from sRoadMain in
    ///         Conditional.
    ///             OfPositionShared&lt;CREO.DataModel.SRoadMain&gt;(sCrsMain). // 位相関係の検索
    ///             From(dataService).  // データサービスを指定
    ///             AsParallel()    // 以降のクエリを並列実行
    ///     where sRoadMain.Road05GuideNoAry.Any()  // 05探索交差点が存在する
    ///     select sRoadMain;    // SRoadMainを抽出
    /// </code>
    /// <code>
    /// // レベル1の住所名称を列挙する
    /// var result3 =
    ///     from tAdrName in
    ///         Conditional.
    ///             Of&lt;CREO.DataModel.TAdrName&gt;().        // 全ての住所名称
    ///             Details(Property.Name("NestLevel") == 1).   // レベル1に絞り込み
    ///             From(dataService).  // データサービスを指定
    ///             AsParallel()    // 以降のクエリを並列実行
    ///     select tAdrName;    // TAdrNameを抽出
    /// </code>
    /// </example>
    public static class Conditional
    {
        #region Of
        /// <summary>
        /// T型の結果を示す汎用クエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <returns>クエリ</returns>
        public static StandardClause<T> Of<T>()
            where T : CREO.DataModel.GeoItem
        {
            return new StandardClause<T>();
        }
        #endregion

        #region OfOID
        /// <summary>
        /// OIDで絞り込みを行うクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="oids">OID群</param>
        /// <returns>クエリ</returns>
        public static StandardClause<T> OfOID<T>(params ulong[] oids)
            where T : CREO.DataModel.GeoItem
        {
            var query = new StandardClause<T>();
            query.Condition.IDs.AddRange(oids);
            if (query.Condition.IDs.Count == 0)
            {
                query.Condition = null;
            }

            return query;
        }

        /// <summary>
        /// OIDで絞り込みを行うクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="oids">OID群</param>
        /// <returns>クエリ</returns>
        public static StandardClause<T> OfOID<T>(IEnumerable<ulong> oids)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(oids, "OID群を示す列挙子が必要です");

            var query = new StandardClause<T>();
            query.Condition.IDs.AddRange(oids);
            if (query.Condition.IDs.Count == 0)
            {
                query.Condition = null;
            }

            return query;
        }
        #endregion

        #region OfSpatial
        /// <summary>
        /// 空間実体の結果を示す汎用クエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <returns>クエリ</returns>
        public static SpatialClause<T> OfSpatial<T>()
            where T : CREO.DataModel.SItemBase
        {
            return new SpatialClause<T>();
        }
        #endregion

        #region OfPoint
        /// <summary>
        /// 指定された座標を示すクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="coordinate">座標</param>
        /// <returns>クエリ</returns>
        public static SpatialClause<T> OfPoint<T>(CREO.FW.TMIGeometry.Coordinate coordinate)
            where T : CREO.DataModel.SPoint
        {
            Assertion.NullArgument(coordinate, "座標の指定が必要です");
            var query = new SpatialClause<T>();

            // 以下の方法は、データプロバイダによってはサポートされていないので、面積を伴うポリゴンで抽出する
            ////query.Condition.Polygon = coordinate.ToSequence().ToList();

            // 点を拡張して面積を生成する
            query.Condition.Polygon =
                CoordinateExtension.CreateValidPolygon(
                    new CREO.FW.TMIGeometry.Coordinate(coordinate.Longitude - 1, coordinate.Latitude - 1),
                    new CREO.FW.TMIGeometry.Coordinate(coordinate.Longitude + 1, coordinate.Latitude + 1)).ToList();

            // 出力に絞り込みフィルタを適用する
            query.Filter = from => from.Where(item => CoordinateEqualityComparer.Default.Equals(item.Geometry, coordinate));

            return query;
        }
        #endregion

        #region OfRange
        /// <summary>
        /// 指定されたメッシュコードの範囲を示すクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="meshCode">メッシュコード</param>
        /// <param name="withNeighbors">隣接メッシュを含む場合はtrue</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>クエリ</returns>
        public static SpatialClause<T> OfRange<T>(int meshCode, bool withNeighbors = false, int meshType = 0)
            where T : CREO.DataModel.SItemBase
        {
            return OfRange<T>((uint)meshCode, withNeighbors, meshType);
        }

        /// <summary>
        /// 指定されたメッシュコードの範囲を示すクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="meshCode">メッシュコード</param>
        /// <param name="withNeighbors">隣接メッシュを含む場合はtrue</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>クエリ</returns>
        public static SpatialClause<T> OfRange<T>(uint meshCode, bool withNeighbors = false, int meshType = 0)
            where T : CREO.DataModel.SItemBase
        {
            IEnumerable<CREO.FW.TMIGeometry.Coordinate> meshRegion;
            if (withNeighbors == true)
            {
                // 未検証
                List<string> neighborMeshCodes;
                CREO.FW.Utilities.MeshCodeUtility.GetAdjacentMeshCodes(meshType, meshCode.ToString(), out neighborMeshCodes);

                var neighborMeshPolygons =
                    from codeString in neighborMeshCodes.AsParallel()
                    select int.Parse(codeString, CultureInfo.InvariantCulture).GetRectangleFromMeshCode(meshType).ToMultiPolygon();

                var neighborBox = neighborMeshPolygons.UnionAll().Envelope();

                meshRegion = neighborBox.ToCoordinateCollection();
            }
            else
            {
                meshRegion = meshCode.GetRectangleFromMeshCode(meshType).ToPolygon();
            }

            var query = new SpatialClause<T>();
            query.Condition.Polygon = meshRegion.ToList();
            return query;
        }

        /// <summary>
        /// 指定された範囲を示すクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="rect">範囲座標</param>
        /// <returns>クエリ</returns>
        public static SpatialClause<T> OfRange<T>(CREO.FW.TMIGeometry.CoordinateRect rect)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(rect, "範囲座標の指定が必要です");
            var query = new SpatialClause<T>();
            query.Condition.Polygon = rect.ToPolygon().ToList();
            return query;
        }

        /// <summary>
        /// 指定されたポリゴンの範囲を示すクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="coordinates">ポリゴン</param>
        /// <returns>クエリ</returns>
        public static SpatialClause<T> OfRange<T>(IEnumerable<CREO.FW.TMIGeometry.Coordinate> coordinates)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(coordinates, "ポリゴンの指定が必要です");
            var query = new SpatialClause<T>();
            query.Condition.Polygon = coordinates.ToList();
            return query;
        }

        /// <summary>
        /// 指定されたマルチポリゴンの範囲を示すクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="polygons">ポリゴン群</param>
        /// <returns>クエリ</returns>
        public static SpatialClause<T> OfRange<T>(IEnumerable<CREO.FW.TMIGeometry.CompositePolygon> polygons)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(polygons, "マルチポリゴンの指定が必要です");
            var query = new SpatialClause<T>();
            query.Condition.MultiPolygon = polygons.ToList();
            return query;
        }

        /// <summary>
        /// 指定されたポリゴンの範囲を示すクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="multiPolygon">マルチポリゴン</param>
        /// <returns>クエリ</returns>
        public static SpatialClause<T> OfRange<T>(IMultiPolygon multiPolygon)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(multiPolygon, "マルチポリゴンの指定が必要です");
            var query = new SpatialClause<T>();
            if (multiPolygon.Count == 1)
            {
                var polygon = multiPolygon[0];
                if (polygon.Count == 1)
                {
                    var ring = polygon[0];
                    query.Condition.Polygon = ring.ToCoordinateCollection().ToList();
                }
                else
                {
                    query.Condition.MultiPolygon = multiPolygon.ToCompositePolygonCollection().ToList();
                }
            }
            else
            {
                query.Condition.MultiPolygon = multiPolygon.ToCompositePolygonCollection().ToList();
            }

            return query;
        }
        #endregion

        #region OfPositionShared
        /// <summary>
        /// 指定されたSItemBase要素の位相関係に対応する、SItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="sItemBase">要素</param>
        /// <returns>クエリ</returns>
        public static RelationalClause<T> OfPositionShared<T>(CREO.DataModel.SItemBase sItemBase)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(sItemBase, "要素のインスタンスが必要です");
            var query = new RelationalClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Position;
            query.Condition.RelationExpression.OID = sItemBase.OID;
            return query;
        }

        /// <summary>
        /// 指定されたOIDの位相関係に対応する、SItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="oid">OID</param>
        /// <returns>クエリ</returns>
        public static RelationalClause<T> OfPositionShared<T>(ulong oid)
            where T : CREO.DataModel.SItemBase
        {
            var query = new RelationalClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Position;
            query.Condition.RelationExpression.OID = oid;
            return query;
        }
        #endregion

        #region OfDependingTo
        /// <summary>
        /// 指定されたSItemBase要素に依存する、DItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="sItemBase">要素</param>
        /// <returns>クエリ</returns>
        public static RelationalClause<T> OfDependingTo<T>(CREO.DataModel.SItemBase sItemBase)
            where T : CREO.DataModel.DItemBase
        {
            Assertion.NullArgument(sItemBase, "要素のインスタンスが必要です");
            var query = new RelationalClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.DependingTo;
            query.Condition.RelationExpression.OID = sItemBase.OID;
            return query;
        }

        /// <summary>
        /// 指定されたOIDに依存する、DItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="oid">OID</param>
        /// <returns>クエリ</returns>
        public static RelationalClause<T> OfDependingTo<T>(ulong oid)
            where T : CREO.DataModel.DItemBase
        {
            var query = new RelationalClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.DependingTo;
            query.Condition.RelationExpression.OID = oid;
            return query;
        }
        #endregion

        #region OfDependedBy
        /// <summary>
        /// 指定されたDItemBase要素が依存する、SItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="dItemBase">要素</param>
        /// <returns>クエリ</returns>
        public static RelationalClause<T> OfDependedBy<T>(CREO.DataModel.DItemBase dItemBase)
            where T : CREO.DataModel.SItemBase
        {
            Assertion.NullArgument(dItemBase, "要素のインスタンスが必要です");
            var query = new RelationalClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.DependedBy;
            query.Condition.RelationExpression.OID = dItemBase.OID;
            return query;
        }

        /// <summary>
        /// 指定されたOIDが依存する、SItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="oid">OID</param>
        /// <returns>クエリ</returns>
        public static RelationalClause<T> OfDependedBy<T>(ulong oid)
            where T : CREO.DataModel.SItemBase
        {
            var query = new RelationalClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.DependedBy;
            query.Condition.RelationExpression.OID = oid;
            return query;
        }
        #endregion

        #region OfGrouping
        /// <summary>
        /// 指定されたGeoItem要素とグルーピング関係にある、GeoItem型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="geoItem">要素</param>
        /// <returns>クエリ</returns>
        public static GroupingClause<T> OfGrouping<T>(CREO.DataModel.GeoItem geoItem)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(geoItem, "要素のインスタンスが必要です");
            var query = new GroupingClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Grouping;
            query.Condition.RelationExpression.OID = geoItem.OID;
            return query;
        }

        /// <summary>
        /// 指定されたOIDとグルーピング関係にある、GeoItem型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="oid">OID</param>
        /// <returns>クエリ</returns>
        public static GroupingClause<T> OfGrouping<T>(ulong oid)
            where T : CREO.DataModel.GeoItem
        {
            var query = new GroupingClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Grouping;
            query.Condition.RelationExpression.OID = oid;
            return query;
        }
        #endregion

        #region OfReference
        /// <summary>
        /// 指定されたGeoItem要素が参照する、GeoItem型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="geoItem">要素</param>
        /// <returns>クエリ</returns>
        public static RelationalClause<T> OfReference<T>(CREO.DataModel.GeoItem geoItem)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(geoItem, "要素のインスタンスが必要です");
            var query = new RelationalClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Reference;
            query.Condition.RelationExpression.OID = geoItem.OID;
            return query;
        }

        /// <summary>
        /// 指定されたOIDが参照する、GeoItem型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="oid">OID</param>
        /// <returns>クエリ</returns>
        public static RelationalClause<T> OfReference<T>(ulong oid)
            where T : CREO.DataModel.GeoItem
        {
            var query = new RelationalClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Reference;
            query.Condition.RelationExpression.OID = oid;
            return query;
        }
        #endregion

        #region OfChild
        /// <summary>
        /// 指定されたTItemBase要素が子となる、親のTItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="tChildItemBase">要素</param>
        /// <returns>クエリ</returns>
        public static TableClause<T> OfChild<T>(T tChildItemBase)
            where T : CREO.DataModel.TItemBase
        {
            Assertion.NullArgument(tChildItemBase, "要素のインスタンスが必要です");
            var query = new TableClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Parent;
            query.Condition.RelationExpression.OID = tChildItemBase.OID;
            return query;
        }

        /// <summary>
        /// 指定されたOIDが子となる、親のTItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="childOid">OID</param>
        /// <returns>クエリ</returns>
        public static TableClause<T> OfChild<T>(ulong childOid)
            where T : CREO.DataModel.TItemBase
        {
            var query = new TableClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Parent;
            query.Condition.RelationExpression.OID = childOid;
            return query;
        }
        #endregion

        #region OfParent
        /// <summary>
        /// 指定されたTItemBase要素が親となる、子のTItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="tParentItemBase">要素</param>
        /// <returns>クエリ</returns>
        public static TableClause<T> OfParent<T>(T tParentItemBase)
            where T : CREO.DataModel.TItemBase
        {
            Assertion.NullArgument(tParentItemBase, "要素のインスタンスが必要です");
            var query = new TableClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Children;
            query.Condition.RelationExpression.OID = tParentItemBase.OID;
            return query;
        }

        /// <summary>
        /// 指定されたOIDが親となる、子のTItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="parentOid">OID</param>
        /// <returns>クエリ</returns>
        public static TableClause<T> OfParent<T>(ulong parentOid)
            where T : CREO.DataModel.TItemBase
        {
            var query = new TableClause<T>();
            query.Condition.RelationExpression.RelationMode = CREO.DS.RelationMode.Children;
            query.Condition.RelationExpression.OID = parentOid;
            return query;
        }
        #endregion

        #region OfDependedByType
        /// <summary>
        /// 指定されたDItemBase型に依存する、全てのSItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">検索する依存実体の型</typeparam>
        /// <returns>クエリ</returns>
        public static DependedByTypeClause OfDependedByType<T>()
            where T : CREO.DataModel.DItemBase
        {
            var query = new DependedByTypeClause();
            return query.WithDepend<T>();
        }

        /// <summary>
        /// 指定されたDItemBase型に依存する、SItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">検索する依存実体の型</typeparam>
        /// <param name="meshCode">メッシュコード</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>クエリ</returns>
        public static DependedByTypeClause OfDependedByType<T>(int meshCode, int meshType = 0)
            where T : CREO.DataModel.DItemBase
        {
            var query = new DependedByTypeClause();
            ((CREO.DS.DependencyTypeToSpatialExpression)query.Condition.QueryExpression).Polygon =
                meshCode.GetRectangleFromMeshCode(meshType).ToPolygon().ToList();
            return query.WithDepend<T>();
        }

        /// <summary>
        /// 指定されたDItemBase型に依存する、SItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">検索する依存実体の型</typeparam>
        /// <param name="meshCode">メッシュコード</param>
        /// <param name="meshType">メッシュタイプ（既定値は通常2次メッシュを示す）</param>
        /// <returns>クエリ</returns>
        public static DependedByTypeClause OfDependedByType<T>(uint meshCode, int meshType = 0)
            where T : CREO.DataModel.DItemBase
        {
            var query = new DependedByTypeClause();
            ((CREO.DS.DependencyTypeToSpatialExpression)query.Condition.QueryExpression).Polygon =
                meshCode.GetRectangleFromMeshCode(meshType).ToPolygon().ToList();
            return query.WithDepend<T>();
        }

        /// <summary>
        /// 指定されたDItemBase型に依存する、SItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">検索する依存実体の型</typeparam>
        /// <param name="rect">範囲座標</param>
        /// <returns>クエリ</returns>
        public static DependedByTypeClause OfDependedByType<T>(
            CREO.FW.TMIGeometry.CoordinateRect rect)
            where T : CREO.DataModel.DItemBase
        {
            Assertion.NullArgument(rect, "範囲座標の指定が必要です");
            var query = new DependedByTypeClause();
            ((CREO.DS.DependencyTypeToSpatialExpression)query.Condition.QueryExpression).Polygon =
                rect.ToPolygon().ToList();
            return query.WithDepend<T>();
        }

        /// <summary>
        /// 指定されたDItemBase型に依存する、SItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">検索する依存実体の型</typeparam>
        /// <param name="coordinates">ポリゴン</param>
        /// <returns>クエリ</returns>
        public static DependedByTypeClause OfDependedByType<T>(
            IEnumerable<CREO.FW.TMIGeometry.Coordinate> coordinates)
            where T : CREO.DataModel.DItemBase
        {
            Assertion.NullArgument(coordinates, "ポリゴンの指定が必要です");
            var query = new DependedByTypeClause();
            ((CREO.DS.DependencyTypeToSpatialExpression)query.Condition.QueryExpression).Polygon =
                coordinates.ToList();
            return query.WithDepend<T>();
        }
        #endregion

        #region OfTraverse
        /// <summary>
        /// 指定されたTItemBase要素が子となる、全ての親TItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="tChildItemBases">要素</param>
        /// <returns>クエリ</returns>
        public static TraverseClause<T> OfTraverse<T>(params T[] tChildItemBases)
            where T : CREO.DataModel.TItemBase
        {
            var query = new TraverseClause<T>();
            ((CREO.DS.AncestorTableRelationExpression)query.Condition.QueryExpression).TypeId = typeof(T).Name;
            ((CREO.DS.AncestorTableRelationExpression)query.Condition.QueryExpression).IDs.AddRange(
                tChildItemBases.Select(tItemBase => tItemBase.OID));
            return query;
        }

        /// <summary>
        /// 指定されたTItemBase要素が子となる、全ての親TItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="tChildItemBases">要素</param>
        /// <returns>クエリ</returns>
        public static TraverseClause<T> OfTraverse<T>(IEnumerable<T> tChildItemBases)
            where T : CREO.DataModel.TItemBase
        {
            Assertion.NullArgument(tChildItemBases, "要素のインスタンスが必要です");
            var query = new TraverseClause<T>();
            ((CREO.DS.AncestorTableRelationExpression)query.Condition.QueryExpression).TypeId = typeof(T).Name;
            ((CREO.DS.AncestorTableRelationExpression)query.Condition.QueryExpression).IDs.AddRange(
                tChildItemBases.Select(tItemBase => tItemBase.OID));
            return query;
        }

        /// <summary>
        /// 指定されたOIDが子となる、全ての親TItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="childOids">OID</param>
        /// <returns>クエリ</returns>
        public static TraverseClause<T> OfTraverse<T>(params ulong[] childOids)
            where T : CREO.DataModel.TItemBase
        {
            var query = new TraverseClause<T>();
            ((CREO.DS.AncestorTableRelationExpression)query.Condition.QueryExpression).TypeId = typeof(T).Name;
            ((CREO.DS.AncestorTableRelationExpression)query.Condition.QueryExpression).IDs.AddRange(childOids);
            return query;
        }

        /// <summary>
        /// 指定されたOIDが子となる、全ての親TItemBase型の要素を取得するクエリを生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="childOids">OID</param>
        /// <returns>クエリ</returns>
        public static TraverseClause<T> OfTraverse<T>(IEnumerable<ulong> childOids)
            where T : CREO.DataModel.TItemBase
        {
            Assertion.NullArgument(childOids, "要素のインスタンスが必要です");
            var query = new TraverseClause<T>();
            ((CREO.DS.AncestorTableRelationExpression)query.Condition.QueryExpression).TypeId = typeof(T).Name;
            ((CREO.DS.AncestorTableRelationExpression)query.Condition.QueryExpression).IDs.AddRange(childOids);
            return query;
        }
        #endregion
    }
}

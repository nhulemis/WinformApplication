﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.06.07 TMI K.Matsui

using System;

using CREO.Fluere.Common.DataModel;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices.Linq
{
    /// <summary>
    /// データサービスで使用する拡張メソッド群です。
    /// </summary>
    public static class EqualsExtension
    {
        #region GeoItem
        /// <summary>
        /// 指定された値が、インターフェイス型と同じかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="item">比較対象の値</param>
        /// <returns>一致すればtrue</returns>
        /// <remarks>GeoItemクラスのOIDプロパティを比較します。
        /// データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Equals(this CREO.DataModel.GeoItem target, CREO.DataModel.GeoItem item)
        {
            if ((target == null) && (item == null))
            {
                return true;
            }

            if ((target == null) || (item == null))
            {
                return false;
            }

            if (target.OID == item.OID)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// 指定された値が、インターフェイス型と同じかどうかを調べます。
        /// </summary>
        /// <param name="target">調べる値</param>
        /// <param name="oid">比較対象のOID値</param>
        /// <returns>一致すればtrue</returns>
        /// <remarks>GeoItemクラスのOIDプロパティを比較します。
        /// データサービスで使用する拡張メソッドですが、他の用途で使用された場合でも判定を行うように実装を提供します。</remarks>
        public static bool Equals(this CREO.DataModel.GeoItem target, ulong oid)
        {
            if (target == null)
            {
                return false;
            }

            if (target.OID == oid)
            {
                return true;
            }

            return false;
        }
        #endregion
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.10 TMI K.Matsui

using System;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// GeoItem要素をOIDで比較可能にするラッパークラスです。
    /// </summary>
    /// <typeparam name="T">対象の型</typeparam>
    /// <remarks>比較対象のインスタンスは、GeoItemComparableとGeoItemです。</remarks>
    public sealed class GeoItemComparable<T>
        : IEquatable<GeoItemComparable<T>>,
        IEquatable<T>,
        IComparable<GeoItemComparable<T>>,
        IComparable<T>,
        IComparable
        where T : CREO.DataModel.GeoItem
    {
        #region Fields
        /// <summary>
        /// インスタンス
        /// </summary>
        private readonly T _geoItem;
        #endregion

        #region Constructor
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="geoItem">左辺値となるインスタンス</param>
        public GeoItemComparable(T geoItem)
        {
            Assertion.NullArgument(geoItem, "インスタンスが必要です");

            this._geoItem = geoItem;
        }
        #endregion

        #region GetHashCode
        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <returns>ハッシュコード</returns>
        public override int GetHashCode()
        {
            return this._geoItem.OID.GetHashCode();
        }
        #endregion

        #region Equals
        /// <summary>
        /// インスタンスを比較します。
        /// </summary>
        /// <param name="other">右辺値</param>
        /// <returns>結果</returns>
        public bool Equals(GeoItemComparable<T> other)
        {
            return this._geoItem.OID.Equals(other._geoItem.OID);
        }

        /// <summary>
        /// インスタンスを比較します。
        /// </summary>
        /// <param name="other">右辺値</param>
        /// <returns>結果</returns>
        public bool Equals(T other)
        {
            return this._geoItem.OID.Equals(other.OID);
        }

        /// <summary>
        /// インスタンスを比較します。
        /// </summary>
        /// <param name="other">右辺値</param>
        /// <returns>結果</returns>
        public override bool Equals(object other)
        {
            var rhs1 = other as GeoItemComparable<T>;
            if (rhs1 != null)
            {
                return this.Equals(rhs1);
            }

            var rhs2 = other as T;
            if (rhs2 != null)
            {
                return this.Equals(rhs2);
            }

            return false;
        }
        #endregion

        #region CompareTo
        /// <summary>
        /// インスタンスを比較します。
        /// </summary>
        /// <param name="other">右辺値</param>
        /// <returns>結果</returns>
        public int CompareTo(GeoItemComparable<T> other)
        {
            return this._geoItem.OID.CompareTo(other._geoItem.OID);
        }

        /// <summary>
        /// インスタンスを比較します。
        /// </summary>
        /// <param name="other">右辺値</param>
        /// <returns>結果</returns>
        public int CompareTo(T other)
        {
            return this._geoItem.OID.CompareTo(other.OID);
        }

        /// <summary>
        /// インスタンスを比較します。
        /// </summary>
        /// <param name="other">右辺値</param>
        /// <returns>結果</returns>
        int IComparable.CompareTo(object other)
        {
            var rhs1 = other as GeoItemComparable<T>;
            if (rhs1 != null)
            {
                return this.CompareTo(rhs1);
            }

            var rhs2 = other as T;
            if (rhs2 != null)
            {
                return this.CompareTo(rhs2);
            }

            return int.MaxValue;
        }
        #endregion
    }
}

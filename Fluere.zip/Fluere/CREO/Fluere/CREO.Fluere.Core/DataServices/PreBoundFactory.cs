﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.29 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;

using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// 事前にバインドされているデータサービスファクトリクラスです。
    /// </summary>
    internal sealed class PreBoundFactory : IPreBoundDataServiceFactory
    {
        #region Fields
        /// <summary>
        /// GUID
        /// </summary>
        private readonly Guid _boundID = Guid.NewGuid();

        /// <summary>
        /// データサービスID
        /// </summary>
        private readonly string _dataServiceID;

        /// <summary>
        /// データソースID
        /// </summary>
        private readonly string _dataSourceID;

        /// <summary>
        /// ワークグループID
        /// </summary>
        private readonly ulong _workGroupID;

        /// <summary>
        /// サブワークグループID
        /// </summary>
        private readonly ulong _subWorkGroupID;

        /// <summary>
        /// StackFrame
        /// </summary>
        private StackFrame _detachedStackFrame;

        /// <summary>
        /// プールされたデータサービス群
        /// </summary>
        private LinkedList<BoundDataServiceFacade> _pooledDataServices;

        /// <summary>
        /// データサービス群
        /// </summary>
        private List<BoundDataServiceFacade> _dataServices = new List<BoundDataServiceFacade>();

        /// <summary>
        /// データサービス群
        /// </summary>
        private List<BoundDataServiceFacade> _detachedDataServices;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="dataSourceID">データソースID</param>
        /// <param name="workGroupID">ワークグループID</param>
        /// <param name="subWorkGroupID">サブワークグループID</param>
        /// <param name="connectionPooling">接続プールを有効化する場合はtrue</param>
        public PreBoundFactory(
            string dataServiceID,
            string dataSourceID,
            ulong workGroupID,
            ulong subWorkGroupID,
            bool connectionPooling)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(dataServiceID) == false);
            Assertion.Condition(string.IsNullOrWhiteSpace(dataSourceID) == false);

            this._dataServiceID = dataServiceID;
            this._dataSourceID = dataSourceID;

            this._workGroupID = workGroupID;
            this._subWorkGroupID = subWorkGroupID;

            this._pooledDataServices = connectionPooling ? new LinkedList<BoundDataServiceFacade>() : null;
        }
        #endregion

        #region Properties
        /// <summary>
        /// 事前バインドを識別するGUIDです。
        /// </summary>
        /// <remarks>この値はデバッグに使用します。</remarks>
        public Guid BoundID
        {
            get
            {
                return this._boundID;
            }
        }

        /// <summary>
        /// バインドされたデータサービスIDを取得します。
        /// </summary>
        public string DataServiceID
        {
            get
            {
                return this._dataServiceID;
            }
        }

        /// <summary>
        /// バインドされたデータソースIDを取得します。
        /// </summary>
        /// <remarks>通常、DataServiceIDプロパティを使用します。</remarks>
        public string RawDataSourceID
        {
            get
            {
                return this._dataSourceID;
            }
        }

        /// <summary>
        /// バインドされたワークグループIDを取得します。
        /// </summary>
        public ulong WorkGroupID
        {
            get
            {
                return this._workGroupID;
            }
        }

        /// <summary>
        /// バインドされたサブワークグループIDを取得します。
        /// </summary>
        public ulong SubWorkGroupID
        {
            get
            {
                return this._subWorkGroupID;
            }
        }

        /// <summary>
        /// 生成されたデータサービス数を取得します。
        /// </summary>
        /// <remarks>この値はデバッグに使用します。</remarks>
        public int DataServiceCount
        {
            get
            {
                lock (this)
                {
                    if (this._dataServices != null)
                    {
                        return this._dataServices.Count;
                    }
                    else if (this._detachedDataServices != null)
                    {
                        return this._detachedDataServices.Count;
                    }
                    else
                    {
                        return 0;
                    }
                }
            }
        }

        /// <summary>
        /// バインドがデタッチされているかどうかを取得します。
        /// </summary>
        /// <remarks>この値はデバッグに使用します。</remarks>
        public bool IsDetached
        {
            get
            {
                return this._detachedStackFrame != null;
            }
        }
        #endregion

        #region InternalDispose
        /// <summary>
        /// InternalDisposeメソッド
        /// </summary>
        /// <param name="dataServices">データサービス群</param>
        private void InternalDispose(
            IEnumerable<BoundDataServiceFacade> dataServices)
        {
            Assertion.Condition(dataServices != null);

            foreach (var dataService in dataServices)
            {
                var hashCode = dataService.GetHashCode();

                try
                {
                    dataService.FinalDispose();
                }
                catch
                {
                }

                Trace.WriteLine(
                    string.Format("{0}: Disposed, DataService={1}",
                    this.ToString(),
                    hashCode));
            }
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッド
        /// </summary>
        public void Dispose()
        {
            lock (this)
            {
                if (this._dataServices != null)
                {
                    Trace.WriteLine(string.Format("{0}: Dispose with not detached", this.ToString()));

                    this.InternalDispose(this._dataServices);

                    this._dataServices = null;
                    this._pooledDataServices = null;
                }
            }
        }
        #endregion

        #region OnDisposed
        /// <summary>
        /// OnDisposedメソッド（コールバック）
        /// </summary>
        /// <param name="dataService">ファサード</param>
        private void OnDisposed(BoundDataServiceFacade dataService)
        {
            Assertion.Condition(dataService != null);

            lock (this)
            {
                // プールが必要
                if (this._pooledDataServices != null)
                {
                    if (this._pooledDataServices.Contains(dataService) == false)
                    {
                        this._pooledDataServices.AddFirst(dataService);
#if false
                        Debug.WriteLine(
                            string.Format("{0}: Pooled, DataService={1}", this.ToString(), dataService.GetHashCode()));
#endif
                    }
                }
                else
                {
                    // プール不要
                    var hashCode = dataService.GetHashCode();

                    try
                    {
                        // その場で廃棄
                        dataService.FinalDispose();
                    }
                    catch
                    {
                    }

                    if (this._detachedDataServices != null)
                    {
                        this._detachedDataServices.Remove(dataService);
                    }
                    else if (this._dataServices != null)
                    {
                        this._dataServices.Remove(dataService);
                    }

                    Trace.WriteLine(
                        string.Format("{0}: Demand disposed, DataService={1}",
                        this.ToString(),
                        hashCode));
                }
            }
        }
        #endregion

        #region InternalGetDataService
        /// <summary>
        /// InternalGetDataServiceメソッド
        /// </summary>
        /// <param name="dataServices">データサービス群</param>
        /// <param name="useCache">キャッシュを使用するかどうか</param>
        /// <param name="created">生成した場合はtrue</param>
        /// <returns>データサービス</returns>
        /// <remarks>
        /// TODO: DataServiceのuseCacheが廃止された為、useCacheパラメータは無効。別途削除する。
        /// </remarks>
        private BoundDataServiceFacade InternalGetDataService(
            List<BoundDataServiceFacade> dataServices,
            bool useCache, 
            out bool created)
        {
            Assertion.Condition(dataServices != null);

            // 接続プールが有効なら
            if (this._pooledDataServices != null)
            {    
                // 生成済みDSを返す
                if (this._pooledDataServices.First != null)
                {
                    created = false;
                    return this._pooledDataServices.First.Value;
                }

                // プールから取得（リスト先頭から終端へ走査）
                var node = this._pooledDataServices.First;
                while (node != null)
                {
                    //// DataServiceのuseCacheは廃止され、useCasheがfalseの状態は存在しない為、削除する。
                    ////// キャッシュ有無が同一のエントリがあれば
                    ////if (node.Value.UseCache == useCache)
                    ////{

                    ////    //// DataServiceのuseCacheは廃止され、useCasheがfalseの状態は存在しない為、削除する。
                    ////    ////// キャッシュしない場合は、プールから削除
                    ////    ////if (useCache == false)
                    ////    ////{
                    ////    ////    // （キャッシュありの場合は、常にプールにエントリが残るので、同じエントリを使う事になる）
                    ////    ////    this._pooledDataServices.Remove(node);
                    ////    ////}

                    ////    created = false;
                    ////    return node.Value;
                    ////}

                    node = node.Next;
                }

                // プールにデータサービスが見つからない
            }

            // 新規に生成
            var rawDataService = DataServiceFactory.InternalConnectToDataService(
                this._dataServiceID,
                this._dataSourceID,
                this._workGroupID,
                this._subWorkGroupID,
                TransactionMode.NoTransacted,
                useCache);   //// TODO: DataServiceのuseCacheは廃止された為、このパラメータも削除する

            //// UseCacheプロパティ廃止の為、削除。
            //// Assertion.Condition(rawDataService.UseCache == useCache);

            var dataService = new BoundDataServiceFacade(this.OnDisposed, rawDataService);
            dataServices.Add(dataService);

            // キャッシュありなら
            if ((useCache == true) && (this._pooledDataServices != null))
            {
                // プールに登録
                this._pooledDataServices.AddFirst(dataService);
            }

            created = true;
            return dataService;
        }
        #endregion

        #region GetDataService
        /// <summary>
        /// データサービスを取得します。
        /// </summary>
        /// <param name="useCache">キャッシュを使用するかどうか</param>
        /// <returns>データサービスのインスタンス</returns>
        /// <remarks>
        /// キャッシュを使用する場合、並列実行性が失われる可能性があります。
        /// TODO: DataServiceのuseCacheが廃止された為、useCacheパラメータは無効。別途削除する。
        /// </remarks>
        public IPreBoundDataService GetDataService(bool useCache = false) 
        {
            BoundDataServiceFacade dataService;
            bool created;

            lock (this)
            {
                // デタッチされていれば
                if (this._dataServices == null)
                {
                    Assertion.Require(
                        this._detachedDataServices != null,
                        "データサービスファクトリは破棄されています: {0}",
                        this.ToString());

                    // TODO: DataServiceのuseCacheが廃止された為、useCacheパラメータは無効。別途削除する。 
                    dataService = this.InternalGetDataService(
                        this._detachedDataServices,
                        useCache,
                        out created);
                }
                else
                {
                    // デタッチされていない
                    Assertion.Condition(this._detachedDataServices == null);

                    // TODO: DataServiceのuseCacheが廃止された為、useCacheパラメータは無効。別途削除する。 
                    dataService = this.InternalGetDataService(
                        this._dataServices,
                        useCache,
                        out created);
                }
            }

            if (created == true)
            {
                Trace.WriteLine(
                    string.Format("{0}: Connect, DataService={1}", this.ToString(), dataService.GetHashCode()));
            }
#if false
            else
            {
                Debug.WriteLine(
                    string.Format("{0}: Got pooled, DataService={1}", this.ToString(), dataService.GetHashCode()));
            }
#endif

            return dataService;
        }
        #endregion

        #region GetIterator
        /// <summary>
        /// 遅延イテレータを生成します。
        /// </summary>
        /// <typeparam name="U">列挙子の要素型</typeparam>
        /// <param name="results">結果を示す列挙子</param>
        /// <returns>列挙可能なインスタンス</returns>
        private IEnumerable<U> GetIterator<U>(IEnumerable<U> results)
        {
            Assertion.Condition(results != null);
            Assertion.Condition(this._detachedStackFrame != null);
            Assertion.Condition(this._dataServices == null);

            var toString = this.ToString();

            Assertion.Require(
                this._detachedDataServices != null,
                "デタッチされているため、2回以上列挙する事は出来ません: {0}",
                toString);

            Trace.WriteLine(string.Format("{0}: Enumeration start", toString));

            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            try
            {
                foreach (var value in results)
                {
                    yield return value;
                }
            }
            finally
            {
                sw.Stop();

                Trace.WriteLine(string.Format("{0}: Enumeration finished, Elapsed={1}", toString, sw.Elapsed));

                lock (this)
                {
                    this.InternalDispose(this._detachedDataServices);

                    this._detachedDataServices = null;
                    this._pooledDataServices = null;
                }
            }
        }
        #endregion

        #region DetachWithResults
        /// <summary>
        /// 結果にデータサービス群を設定してデタッチします。
        /// </summary>
        /// <typeparam name="U">列挙子の要素型</typeparam>
        /// <param name="results">結果を示す列挙子</param>
        /// <returns>列挙可能なインスタンス</returns>
        /// <remarks>データサービス群の管理は、列挙子の列挙が完了するまで維持されます。
        /// これにより、データサービス群を列挙子の寿命に合わせる事が出来ます。</remarks>
        public IEnumerable<U> DetachWithResults<U>(IEnumerable<U> results)
        {
            Assertion.NullArgument(results, "結果を示す列挙子が必要です");

            IEnumerable<U> iterator;

            lock (this)
            {
                Assertion.Require(
                    this._dataServices != null,
                    "データサービス群は既にデタッチされているか破棄されています: {0}",
                    this.ToString());

                Assertion.Condition(this._detachedDataServices == null);
                Assertion.Condition(this._detachedStackFrame == null);

                this._detachedDataServices = this._dataServices;
                this._dataServices = null;

                this._detachedStackFrame = new StackFrame(1);

                iterator = this.GetIterator(results);
            }

            Trace.WriteLine(string.Format("{0}: Detached", this.ToString()));

            return iterator;
        }
        #endregion

        #region Overrides
        /// <summary>
        /// 文字列表現を取得します。
        /// </summary>
        /// <returns>文字列</returns>
        public override string ToString()
        {
            lock (this)
            {
                var detachedMethod =
                    (this._detachedStackFrame != null) ?
                        string.Format("{0}.{1}()", this._detachedStackFrame.GetMethod().DeclaringType.Name, this._detachedStackFrame.GetMethod().Name) :
                        "(Before detach)";

                return string.Format(
                    "{0}: Guid={1}, {2}, WorkGroupID={3}, SubWorkGroupID={4}, DetachedMethod={5}, DataServiceCount={6}{7}",
                    this.GetType().Name,
                    this._boundID,
                    (this._dataSourceID == this._dataServiceID) ? string.Format("DataSourceID={0}", this._dataSourceID) : string.Format("ApplicationID={0}, DataSourceID={1}", this._dataServiceID, this._dataSourceID),
                    this._workGroupID,
                    this._subWorkGroupID,
                    detachedMethod,
                    this.DataServiceCount,
                    (this._pooledDataServices != null) ? string.Format(", PooledCount={0}", this._pooledDataServices.Count) : string.Empty);
            }
        }
        #endregion

        #region BoundDataService
        /// <summary>
        /// データサービスのファサードクラスです。
        /// </summary>
        private sealed class BoundDataServiceFacade : IPreBoundDataService
        {
            /// <summary>
            /// データサービス
            /// </summary>
            private CREO.DS.DataService _dataService;

            /// <summary>
            /// Disposeコールバック
            /// </summary>
            private Action<BoundDataServiceFacade> _onDisposed;

            /// <summary>
            /// コンストラクタです。
            /// </summary>
            /// <param name="onDisposed">コールバック</param>
            /// <param name="dataService">データサービス</param>
            public BoundDataServiceFacade(Action<BoundDataServiceFacade> onDisposed, CREO.DS.DataService dataService)
            {
                Assertion.Condition(onDisposed != null);
                Assertion.Condition(dataService != null);

                this._onDisposed = onDisposed;
                this._dataService = dataService;
            }

            /////// <summary>
            /////// キャッシュを使用するかどうかを取得します。
            /////// </summary>
            ////public bool UseCache
            ////{
            ////    get
            ////    {
            ////        return this._dataService.UseCache;
            ////    }
            ////}

            /// <summary>
            /// Disposeメソッドです。
            /// </summary>
            public void Dispose()
            {
                if (this._onDisposed != null)
                {
                    this._onDisposed(this);
                }
            }

            /// <summary>
            /// FinalDisposeメソッドです。
            /// </summary>
            public void FinalDispose()
            {
                if (this._dataService != null)
                {
                    this._dataService.Dispose();
                    this._dataService = null;
                    this._onDisposed = null;
                }
            }

            /// <summary>
            /// 条件を指定してGeoItemの配列を取得する
            /// </summary>
            /// <param name="cond">取得条件</param>
            /// <param name="ignoreCache">ローカルキャッシュを無視する</param>
            /// <para>有効範囲：無視：true；ディフォルト：false </para>
            /// <returns>
            /// (List&lt;CREO.DataModel.GeoItem&gt;)GeoItemの配列
            /// </returns>
            /// <remarks>
            /// TODO: DataServiceのuseCacheが廃止された為、QueryItemsのignoreCacheが実質無効になっている。ignoreCacheパラメータは削除する。
            /// </remarks>
            public IList<CREO.DataModel.GeoItem> QueryItems(CREO.DS.QueryItemsCondition cond, bool ignoreCache = false)
            {
                Assertion.Condition(cond != null);

                return this._dataService.QueryItems(cond, ignoreCache);
            }

            /// <summary>
            /// 条件を指定してGeoItemの統計処理を行う
            /// </summary>
            /// <param name="cond">取得条件</param>
            /// <param name="consumers">自行提供なGeoItem操作クラス</param>
            public void ProcessItems(CREO.DS.QueryItemsCondition cond, List<CREO.DS.IDataConsumer> consumers)
            {
                Assertion.Condition(cond != null);
                Assertion.Condition(consumers != null);

                this._dataService.ProcessItems(cond, consumers);
            }

            // 改善追加開始 2014/02/17

            /// <summary>
            /// DataServiceのキャッシュ中のデータをすべて破棄する
            /// </summary>
            public void ClearCache()
            {
                if (this._dataService != null)
                {
                    this._dataService.RefreshCache(DS.Cache.ObjectCacheItem.CacheInfoFlag.Delete);
                }
            }

            // 改善追加終了 2014/02/17

            /// <summary>
            /// ハッシュコードを取得します。
            /// </summary>
            /// <returns>ハッシュコード</returns>
            public override int GetHashCode()
            {
                return this._dataService.GetHashCode();
            }

            /// <summary>
            /// 比較します。
            /// </summary>
            /// <param name="obj">比較先</param>
            /// <returns>一致すればtrue</returns>
            public bool Equals(BoundDataServiceFacade obj)
            {
                return object.ReferenceEquals(this._dataService, obj._dataService);
            }

            /// <summary>
            /// 比較します。
            /// </summary>
            /// <param name="obj">比較先</param>
            /// <returns>一致すればtrue</returns>
            public override bool Equals(object obj)
            {
                return this.Equals(obj as BoundDataServiceFacade);
            }

            /// <summary>
            /// 文字列表現
            /// </summary>
            /// <returns>文字列</returns>
            public override string ToString()
            {
                return string.Format("DataService={0}",
                    (this._dataService != null) ? this._dataService.GetHashCode().ToString() : "(Disposed)");
            }
        }
        #endregion
    }
}

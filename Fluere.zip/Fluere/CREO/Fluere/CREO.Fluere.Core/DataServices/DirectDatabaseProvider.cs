﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.30 TMI K.Matsui

using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.EntityClient;
using System.Data.SqlClient;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データベースへのダイレクトアクセスを実行するデータプロバイダです。
    /// </summary>
    /// <remarks>このプロバイダを使用する場合、正しく構成するために、
    /// App.configのmodulesセクションに"CREO.Fluere.Core.DLL"を追加する必要があります。</remarks>
    public sealed class DirectDatabaseProvider
        : CREO.DS.DataProvider.DataProviderBase, IDirectDatabaseProvider
    {
        #region Fields
        /// <summary>
        /// DbProviderFactory
        /// </summary>
        private DbProviderFactory _factory;

        /// <summary>
        /// IDbConnection
        /// </summary>
        private IDbConnection _connection;

        /// <summary>
        /// DirectDatabaseAccessor
        /// </summary>
        private DirectDatabaseAccessor _accessor;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <remarks>このコンストラクタを使用する場合、自力で初期化を行う必要があります。
        /// 可能であればCreateメソッドを使用して下さい。</remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public DirectDatabaseProvider()
        {
        }
        #endregion

        #region Properties
        /// <summary>
        /// 接続文字列を取得します。
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public string ConnectionString
        {
            get
            {
                Assertion.Require(this._factory != null, "バインドされていません");

                return this._dataSourceInfo.GetDatabase();
            }
        }

        /// <summary>
        /// 接続文字列を取得します。
        /// </summary>
        public string EntitiesConnectionString
        {
            get
            {
                Assertion.Require(this._factory != null, "バインドされていません");

                var entityBuilder = new EntityConnectionStringBuilder();
                entityBuilder.ProviderConnectionString = this.ConnectionString;
                entityBuilder.Metadata = "res://*/";
                entityBuilder.Provider = this._factory.GetType().Namespace;

                return entityBuilder.ConnectionString;
            }
        }

        /// <summary>
        /// ファクトリを取得します。
        /// </summary>
        [EditorBrowsable(EditorBrowsableState.Advanced)]
        public DbProviderFactory Factory
        {
            get
            {
                Assertion.Require(this._factory != null, "バインドされていません");

                return this._factory;
            }
        }

        /// <summary>
        /// 現在のデータベース接続を取得します。
        /// </summary>
        public IDbConnection Connection
        {
            get
            {
                Assertion.Require(this._factory != null, "バインドされていません");
                Assertion.Require(this._connection != null, "接続されていません");

                return this._connection;
            }
        }
        #endregion

        #region Create
        /// <summary>
        /// データサービスIDを指定してプロバイダを生成します。
        /// </summary>
        /// <param name="factory">データサービスファクトリ</param>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDのタイプ</param>
        /// <returns>プロバイダのインスタンス</returns>
        public static IDirectDatabaseProvider Create(
            IDataServiceFactory factory,
            string dataServiceID,
            DataServiceIDTypes idType = DataServiceIDTypes.DatabaseRoleID)
        {
            Assertion.NullArgument(factory, "データサービスファクトリが必要です");
            Assertion.Argument(string.IsNullOrWhiteSpace(dataServiceID) == false, "データサービスIDが必要です");

            var dataProvider = (DirectDatabaseProvider)
                CREO.DS.DataProvider.DataProviderManager.Current.CreateDataProvider(
                "CREO.Fluere.DirectDatabaseProvider");

            dataProvider.DataProviderName = "CREO.Fluere.DirectDatabaseProvider";

            var dataSourceID =
                factory.GetDataSourceIDFromDataServiceID(dataServiceID, idType);

            var rawContext = new CREO.DS.DataSource.ConnectionContext();
            rawContext.DataSourceID = dataSourceID;
            rawContext.WorkGroupID = 0;
            rawContext.SubWorkGroupID = 0;
            rawContext.UserGroup = (string[])new ArrayList(
                CREO.FW.Logon.UserInformation.ADGroup).ToArray(typeof(string));
            rawContext.UserID = CREO.FW.Logon.UserInformation.UserID;
            rawContext.SiteID = "0";

            dataProvider.Bind(rawContext);

            return dataProvider;
        }
        #endregion

        #region Bind
        /// <summary>
        /// データソース情報を取得する。
        /// </summary>
        /// <param name="ctx">データソース情報</param>
        /// <returns>成功/失敗</returns>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public override bool Bind(CREO.DS.DataSource.ConnectionContext ctx)
        {
            bool result = base.Bind(ctx);

            // DBAccessManagerを生成し、接続オブジェクトからデータベースファクトリを特定する
            var dbAccessManager =
                new CREO.FW.DBAccess.DBAccessManager(
                    this._dataSourceInfo.GetDataType(),
                    this._dataSourceInfo.GetDatabase());
            try
            {
                var providerName = dbAccessManager.Connection.GetType().Namespace;
                this._factory = DbProviderFactories.GetFactory(providerName);
            }
            finally
            {
                dbAccessManager.CloseConnection();
            }

            return result;
        }
        #endregion

        #region Open
        /// <summary>
        /// データベースを開きます。
        /// </summary>
        public void Open()
        {
            Assertion.Require(this._factory != null, "バインドされていません");
            Assertion.Require(this._connection == null, "既に接続しています");

            var connection = this._factory.CreateConnection();
            connection.ConnectionString = this.ConnectionString;
            connection.Open();

            this._connection = connection;
            this._accessor = new DirectDatabaseAccessor(this._connection);
        }
        #endregion

        #region Dispose()
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public void Dispose()
        {
            if (this._accessor != null)
            {
                this._accessor.Dispose();
                this._accessor = null;
            }

            if (this._connection != null)
            {
                this._connection.Dispose();
                this._connection = null;
            }
        }
        #endregion

        #region BeginTransaction
        /// <summary>
        /// トランザクションを開始します。
        /// </summary>
        /// <param name="isolationLevel">分離レベル</param>
        /// <returns>トランザクションを示す新しいコンテキスト</returns>
        public IDirectDatabaseTransactionContext BeginTransaction(
            IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            return this._accessor.BeginTransaction(isolationLevel);
        }
        #endregion

        #region Parameter
        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <returns>パラメータオブジェクト</returns>
        public IDbDataParameter Parameter(string name)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            return this._accessor.Parameter(name);
        }

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <param name="value">パラメータ値</param>
        /// <returns>パラメータオブジェクト</returns>
        public IDbDataParameter Parameter(string name, object value)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            return this._accessor.Parameter(name, value);
        }

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <param name="type">パラメータのタイプ</param>
        /// <returns>パラメータオブジェクト</returns>
        public IDbDataParameter Parameter(string name, DbType type)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            return this._accessor.Parameter(name, type);
        }

        /// <summary>
        /// パラメータオブジェクトを生成します。
        /// </summary>
        /// <param name="name">パラメータ名</param>
        /// <param name="type">パラメータのタイプ</param>
        /// <param name="value">パラメータ値</param>
        /// <returns>パラメータオブジェクト</returns>
        public IDbDataParameter Parameter(string name, DbType type, object value)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            return this._accessor.Parameter(name, type, value);
        }
        #endregion

        #region ExecuteNonQuery
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>影響レコード数</returns>
        public int ExecuteNonQuery(
            string queryString,
            IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            return this._accessor.ExecuteNonQuery(queryString, parameters);
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>影響レコード数</returns>
        public int ExecuteNonQuery(
            string queryString,
            params IDbDataParameter[] parameters)
        {
            return this.ExecuteNonQuery(queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteScalar
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果</returns>
        public object ExecuteScalar(
            string queryString,
            IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            return this._accessor.ExecuteScalar(queryString, parameters);
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果</returns>
        public object ExecuteScalar(
            string queryString,
            params IDbDataParameter[] parameters)
        {
            return this.ExecuteScalar(queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteReader
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果レコード群</returns>
        public IDataReader ExecuteReader(
            string queryString,
            IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            return this._accessor.ExecuteReader(queryString, parameters);
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果レコード群</returns>
        public IDataReader ExecuteReader(
            string queryString,
            params IDbDataParameter[] parameters)
        {
            return this.ExecuteReader(queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteToDataTable
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果を格納する新しいデータテーブル</returns>
        public DataTable ExecuteToDataTable(
            string queryString,
            IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            return this._accessor.ExecuteToDataTable(queryString, parameters);
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        /// <returns>結果を格納する新しいデータテーブル</returns>
        public DataTable ExecuteToDataTable(
            string queryString,
            params IDbDataParameter[] parameters)
        {
            return this.ExecuteToDataTable(queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteAndStore
        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataTable">結果を格納するデータテーブル</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        public void ExecuteAndStore(
            DataTable dataTable,
            string queryString,
            IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            this._accessor.ExecuteAndStore(dataTable, queryString, parameters);
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataTable">結果を格納するデータテーブル</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        public void ExecuteAndStore(
            DataTable dataTable,
            string queryString,
            params IDbDataParameter[] parameters)
        {
            this.ExecuteAndStore(dataTable, queryString, (IEnumerable<IDbDataParameter>)parameters);
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataSet">結果を格納するデータセット</param>
        /// <param name="targetTableName">データテーブルを特定するデータセット内のテーブル名</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        public void ExecuteAndStore(
            DataSet dataSet,
            string targetTableName,
            string queryString,
            IEnumerable<IDbDataParameter> parameters)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            this._accessor.ExecuteAndStore(dataSet, targetTableName, queryString, parameters);
        }

        /// <summary>
        /// クエリを実行します。
        /// </summary>
        /// <param name="dataSet">結果を格納するデータセット</param>
        /// <param name="targetTableName">データテーブルを特定するデータセット内のテーブル名</param>
        /// <param name="queryString">クエリ文字列</param>
        /// <param name="parameters">クエリパラメータ群</param>
        public void ExecuteAndStore(
            DataSet dataSet,
            string targetTableName,
            string queryString,
            params IDbDataParameter[] parameters)
        {
            this.ExecuteAndStore(dataSet, targetTableName, queryString, (IEnumerable<IDbDataParameter>)parameters);
        }
        #endregion

        #region ExecuteBulkCopy
        /// <summary>
        /// バルクコピーを実行します。
        /// </summary>
        /// <param name="targetTableName">ストア先のテーブル名</param>
        /// <param name="reader">データを供給するリーダ</param>
        /// <param name="batchSize">バッチレコードサイズ</param>
        /// <param name="options">オプション</param>
        /// <param name="iterationHandler">コピー中に生じる経過イベントのコールバック</param>
        /// <remarks>バルクコピーを実行する場合、プロバイダがSQL Serverに対して構成されていなければなりません。</remarks>
        public void ExecuteBulkCopy(
            string targetTableName,
            IDataReader reader,
            int batchSize = 50000,
            SqlBulkCopyOptions options = SqlBulkCopyOptions.Default,
            SqlRowsCopiedEventHandler iterationHandler = null)
        {
            Assertion.Require(this._accessor != null, "接続されていません");

            this._accessor.ExecuteBulkCopy(targetTableName, reader, batchSize, options, iterationHandler);
        }
        #endregion
    }
}

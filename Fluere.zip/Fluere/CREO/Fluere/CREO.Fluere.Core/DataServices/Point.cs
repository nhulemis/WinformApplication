﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System;
using System.Runtime.Serialization;
using System.Security;

using CREO.Fluere.Common.Diagnostics;

using Microsoft.SqlServer.Types;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするラップクラスです。
    /// </summary>
    [Serializable]
    internal sealed class Point : GeometryBase, IPoint
    {
        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="sqlGeometry">SqlGeometry</param>
        public Point(SqlGeometry sqlGeometry)
            : base(sqlGeometry)
        {
#if DEBUG
            var type = this.GeometryStructureType;
            Assertion.Condition((type == GeometryStructureTypes.Empty) || (type == GeometryStructureTypes.Point));
#endif
        }

        /// <summary>
        /// 逆シリアル化コンストラクタです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecurityCritical]
        private Point(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
        #endregion

        #region X
        /// <summary>
        /// X座標を取得します。
        /// </summary>
        public double X
        {
            get
            {
                Assertion.Require<InvalidOperationException>(this.IsEmpty == false, "インスタンスが空です");

                return this.GEOMETRY.STX.Value;
            }
        }
        #endregion

        #region Y
        /// <summary>
        /// Y座標を取得します。
        /// </summary>
        public double Y
        {
            get
            {
                Assertion.Require<InvalidOperationException>(this.IsEmpty == false, "インスタンスが空です");

                return this.GEOMETRY.STY.Value;
            }
        }
        #endregion

        #region ToCoordinate
        /// <summary>
        /// Coordinateに変換します。
        /// </summary>
        /// <returns>Coordinate</returns>
        public CREO.FW.TMIGeometry.Coordinate ToCoordinate()
        {
            Assertion.Require<InvalidOperationException>(this.IsEmpty == false, "インスタンスが空です");

            return new CREO.FW.TMIGeometry.Coordinate(
                (long)(this.GEOMETRY.STX.Value + 0.5),
                (long)(this.GEOMETRY.STY.Value + 0.5));
        }
        #endregion

        #region ToCoordinateD
        /// <summary>
        /// CoordinateDに変換します。
        /// </summary>
        /// <returns>CoordinateD</returns>
        public CREO.FW.TMIGeometry.CoordinateD ToCoordinateD()
        {
            Assertion.Require<InvalidOperationException>(this.IsEmpty == false, "インスタンスが空です");

            return new CREO.FW.TMIGeometry.CoordinateD(
                this.GEOMETRY.STX.Value,
                this.GEOMETRY.STY.Value);
        }
        #endregion

        #region Transform
        /// <summary>
        /// 指定したアフィン変換演算子を適用します。
        /// </summary>
        /// <param name="matrix">アフィン変換演算子を示す行列</param>
        /// <returns>形状</returns>
        public override IMultiPolygon TransformBy(System.Windows.Media.Matrix matrix)
        {
            Assertion.Require<InvalidOperationException>(this.IsEmpty == false, "インスタンスが空です");

            var result = matrix.Transform(new System.Windows.Point(this.X, this.Y));
            return new MultiPolygon(SqlGeometry.Point(result.X, result.Y, SRID));
        }
        #endregion
    }
}

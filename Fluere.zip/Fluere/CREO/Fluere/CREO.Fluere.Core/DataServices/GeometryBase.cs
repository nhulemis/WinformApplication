﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Runtime.Serialization;
using System.Security;
using System.Windows.Media;
using System.Xml;
using CREO.Fluere.Common.Diagnostics;
using Microsoft.SqlServer.Types;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするラップ基底クラスです。
    /// </summary>
    [Serializable]
    public abstract class GeometryBase : IGeometry, ISerializable
    {
        #region Fields
        /// <summary>
        /// 既定のSRID
        /// </summary>
        /// <remarks>SqlGeographyではなく、SqlGeometryを使用するため、SRIDは常に0となる。</remarks>
        internal static readonly int SRID = 0;

        /// <summary>
        /// 空のインスタンス
        /// </summary>
        private static readonly MultiPolygon EMPTY = new MultiPolygon(SqlGeometry.Null);

        /// <summary>
        /// SqlGeometryのインスタンス
        /// </summary>
        internal readonly SqlGeometry GEOMETRY;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="sqlGeometry">SqlGeometry</param>
        internal GeometryBase(SqlGeometry sqlGeometry)
        {
            Assertion.Condition(sqlGeometry != null);

            this.GEOMETRY = sqlGeometry;
        }

        /// <summary>
        /// 逆シリアル化コンストラクタです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecurityCritical]
        internal GeometryBase(SerializationInfo info, StreamingContext context)
        {
            Assertion.Condition(info != null);

            this.GEOMETRY = new SqlGeometry();
            using (var ms = new MemoryStream((byte[])info.GetValue("SqlGeometry", typeof(byte[]))))
            {
                var reader = new BinaryReader(ms);
                this.GEOMETRY.Read(reader);
            }
        }
        #endregion

        #region GeometryStructureTypes
        /// <summary>
        /// SqlGeometryの構造
        /// </summary>
        internal enum GeometryStructureTypes
        {
            /// <summary>
            /// Empty
            /// </summary>
            Empty,

            /// <summary>
            /// MultiPolygon, MultiLineString, Complex
            /// </summary>
            Multiple,

            /// <summary>
            /// Polygon, LineString
            /// </summary>
            Single,

            /// <summary>
            /// Point
            /// </summary>
            Point
        }
        #endregion

        #region Empty
        /// <summary>
        /// 空のインスタンスを取得します。
        /// </summary>
        public static IMultiPolygon Empty
        {
            get
            {
                return EMPTY;
            }
        }
        #endregion

        #region RawInstance
        /// <summary>
        /// 生のインスタンスを取得します。
        /// </summary>
        /// <remarks>通常、このプロパティを使用する事はありません。</remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        object IGeometry.RawInstance
        {
            get
            {
                return this.GEOMETRY;
            }
        }
        #endregion

        #region GeometryStructureType
        /// <summary>
        /// SqlGeometryの構造を取得します。
        /// </summary>
        internal GeometryStructureTypes GeometryStructureType
        {
            get
            {
                switch (this.GeometryType)
                {
                    case GeometryTypes.Complex:
                    case GeometryTypes.MultiPolygon:
                    case GeometryTypes.MultiLineString:
                        return GeometryStructureTypes.Multiple;
                    case GeometryTypes.Polygon:
                    case GeometryTypes.LineString:
                        return GeometryStructureTypes.Single;
                    case GeometryTypes.Point:
                        return GeometryStructureTypes.Point;
                    case GeometryTypes.Empty:
                        return GeometryStructureTypes.Empty;
                }

                throw new InvalidOperationException();
            }
        }
        #endregion

        #region GeometryType
        /// <summary>
        /// インスタンスのタイプを取得します。
        /// </summary>
        public GeometryTypes GeometryType
        {
            get
            {
                if ((this.GEOMETRY.IsNull == true) || (this.GEOMETRY.STIsEmpty().Value == true))
                {
                    return GeometryTypes.Empty;
                }

                switch (this.GEOMETRY.STGeometryType().Value.ToLowerInvariant())
                {
                    case "geometrycollection":
                        return GeometryTypes.Complex;
                    case "multipolygon":
                        return GeometryTypes.MultiPolygon;
                    case "multilinestring":
                        return GeometryTypes.MultiLineString;
                    case "polygon":
                        return GeometryTypes.Polygon;
                    case "linestring":
                        return GeometryTypes.LineString;
                    case "point":
                        return GeometryTypes.Point;
                }

                throw new InvalidOperationException();
            }
        }
        #endregion

        #region IsEmpty
        /// <summary>
        /// インスタンスが空かどうかを取得します。
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                return (this.GEOMETRY.IsNull == true) || (this.GEOMETRY.STIsEmpty().Value == true);
            }
        }
        #endregion

        #region IsValid
        /// <summary>
        /// インスタンスが正規化されているかどうかを取得します。
        /// </summary>
        public bool IsValid
        {
            get
            {
                return this.GEOMETRY.STIsValid().Value;
            }
        }
        #endregion

        #region IsReadOnly
        /// <summary>
        /// 読み取り専用かどうかを取得します。
        /// </summary>
        /// <remarks>常にtrueを返します。</remarks>
        public bool IsReadOnly
        {
            get
            {
                return true;
            }
        }
        #endregion

        #region IsSynchronized
        /// <summary>
        /// メソッドアクセスが同期化されているかどうかを取得します。
        /// </summary>
        /// <remarks>常にfalseを返しますが、スレッドセーフです。</remarks>
        public bool IsSynchronized
        {
            get
            {
                return false;
            }
        }
        #endregion

        #region SyncRoot
        /// <summary>
        /// 同期化対象のインスタンスを取得します。
        /// </summary>
        public object SyncRoot
        {
            get
            {
                return this.GEOMETRY;
            }
        }
        #endregion

        #region GetGML
        /// <summary>
        /// Geography Markup Languageを取得します。
        /// </summary>
        /// <returns>Geography Markup Language</returns>
        public XmlReader GetGML()
        {
            return this.GEOMETRY.AsGml().CreateReader();
        }
        #endregion

        #region ToMultiPolygon
        /// <summary>
        /// 同じ内容を示すマルチポリゴンインスタンスに変換します。
        /// </summary>
        /// <returns>マルチポリゴン</returns>
        public virtual IMultiPolygon ToMultiPolygon()
        {
            return new MultiPolygon(this.GEOMETRY);
        }
        #endregion

        #region MakeValid
        /// <summary>
        /// 形状を正規化した結果を取得します。
        /// </summary>
        /// <returns>形状</returns>
        /// <remarks>演算結果が不正な形状を示す場合に、形状を変形させて正規化します。
        /// 例えば、同じ線を共有する2つのポリゴンは、線が取り除かれ、単一のポリゴンに修正されます。
        /// このクラスに定義される様々な演算子は、常に結果が不正となる可能性がある事に注意して下さい。</remarks>
        public IMultiPolygon MakeValid()
        {
            return new MultiPolygon(this.GEOMETRY.MakeValid());
        }
        #endregion

        #region Boundary
        /// <summary>
        /// 境界を表す形状を取得します。
        /// </summary>
        /// <returns>形状</returns>
        public IRing Boundary()
        {
            return new Ring(this.GEOMETRY.STBoundary());
        }
        #endregion

        #region Buffer
        /// <summary>
        /// 拡張または縮退した形状を取得する演算子です。
        /// </summary>
        /// <param name="tolerance">拡張または縮退する距離</param>
        /// <returns>形状</returns>
        public IMultiPolygon Buffer(double tolerance)
        {
            return new MultiPolygon(this.GEOMETRY.STBuffer(tolerance));
        }
        #endregion

        #region Centroid
        /// <summary>
        /// 重心座標を取得します。
        /// </summary>
        /// <returns>重心を示す座標</returns>
        public IPoint Centroid()
        {
            return new Point(this.GEOMETRY.STCentroid());
        }
        #endregion

        #region Contains
        /// <summary>
        /// 指定された形状が、現在の形状に完全に含まれているかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>部分的に含まれていればtrue</returns>
        /// <remarks>Withinは逆演算子です。Touchesが成立する形状との演算ではfalseを返します。</remarks>
        public bool Contains(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return this.GEOMETRY.STContains((SqlGeometry)rhs.RawInstance).Value;
        }
        #endregion

        #region ConvexHull
        /// <summary>
        /// 凸包を表す形状を取得する演算子です。
        /// </summary>
        /// <returns>ポリゴン</returns>
        public IMultiPolygon ConvexHull()
        {
            return new MultiPolygon(this.GEOMETRY.STConvexHull());
        }
        #endregion

        #region Crosses
        /// <summary>
        /// 指定された形状が交差するかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>交差していればtrue</returns>
        /// <remarks>CrossesはIntersectsよりも狭範囲です。
        /// 形状同士が、隣り合う次元（線と面など）で交差する場合にtrueとなります。</remarks>
        public bool Crosses(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return this.GEOMETRY.STCrosses((SqlGeometry)rhs.RawInstance).Value;
        }
        #endregion

        #region Difference
        /// <summary>
        /// 指定されたポリゴンとの差集合形状を返す演算子です。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>差集合形状</returns>
        /// <remarks>ポリゴンの除外演算を行います。</remarks>
        public IMultiPolygon Difference(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return new MultiPolygon(this.GEOMETRY.STSymDifference((SqlGeometry)rhs.RawInstance));
        }
        #endregion

        #region Disjoint
        /// <summary>
        /// 指定された形状が連結していないかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>連結していなればtrue</returns>
        /// <remarks>Intersectsは逆演算子です。
        /// Disjointは効率的ではない可能性があります。その場合は、Intersectsを使用して下さい。</remarks>
        public bool Disjoint(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return this.GEOMETRY.STDisjoint((SqlGeometry)rhs.RawInstance).Value;
        }
        #endregion

        #region Distance
        /// <summary>
        /// 指定された形状との最短距離を取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>最短距離</returns>
        public double Distance(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return this.GEOMETRY.STDistance((SqlGeometry)rhs.RawInstance).Value;
        }
        #endregion

        #region Envelope
        /// <summary>
        /// 最小軸に沿って外接する四角形を返す演算子です。
        /// </summary>
        /// <returns>四角形を示すポリゴン</returns>
        public IRing Envelope()
        {
            return new Ring(this.GEOMETRY.STEnvelope());
        }
        #endregion

        #region Intersection
        /// <summary>
        /// 指定された形状との積集合形状を返す演算子です。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>積集合形状</returns>
        public IMultiPolygon Intersection(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return new MultiPolygon(this.GEOMETRY.STIntersection((SqlGeometry)rhs.RawInstance));
        }
        #endregion

        #region Intersects
        /// <summary>
        /// 指定された形状が交差するかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>交差していればtrue</returns>
        /// <remarks>Disjointは逆演算子です。</remarks>
        public bool Intersects(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return this.GEOMETRY.STIntersects((SqlGeometry)rhs.RawInstance).Value;
        }
        #endregion

        #region Overlaps
        /// <summary>
        /// 指定された形状が部分的に重なるかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>部分的に重なっていればtrue</returns>
        /// <remarks>完全に重なっている、又は完全に含まれる場合は、falseを返します。</remarks>
        public bool Overlaps(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return this.GEOMETRY.STOverlaps((SqlGeometry)rhs.RawInstance).Value;
        }
        #endregion

        #region Reduce
        /// <summary>
        /// 指定された形状を簡略化する演算子です。
        /// </summary>
        /// <param name="tolerance">Douglas-Peucker アルゴリズムへの入力の許容範囲</param>
        /// <returns>簡略化形状</returns>
        public IMultiPolygon Reduce(double tolerance)
        {
            return new MultiPolygon(this.GEOMETRY.Reduce(tolerance));
        }
        #endregion

        #region Slide
        /// <summary>
        /// 指定した値で移動した形状を取得する演算子です。
        /// </summary>
        /// <param name="xOffset">x座標方向の移動量</param>
        /// <param name="yOffset">y座標方向の移動量</param>
        /// <returns>移動した形状</returns>
        /// <remarks>大量の計算を行う場合は、TransformByを使用して下さい。</remarks>
        public IMultiPolygon Slide(double xOffset, double yOffset)
        {
            var matrix = new Matrix();
            matrix.Translate(xOffset, yOffset);
            return this.TransformBy(matrix);
        }
        #endregion

        #region Touches
        /// <summary>
        /// 指定された形状のいずれかが接しているかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>接していればtrue</returns>
        /// <remarks>ポリゴンのポイントが一部で共有され、積集合が存在しない場合にtrueとなります。</remarks>
        public bool Touches(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return this.GEOMETRY.STTouches((SqlGeometry)rhs.RawInstance).Value;
        }
        #endregion

        #region TransformBy
        /// <summary>
        /// 指定したアフィン変換演算子を適用する演算子です。
        /// </summary>
        /// <param name="matrix">アフィン変換演算子を示す行列</param>
        /// <returns>形状</returns>
        public abstract IMultiPolygon TransformBy(System.Windows.Media.Matrix matrix);
        #endregion

        #region Union
        /// <summary>
        /// 指定された形状との和集合形状を返す演算子です。
        /// </summary>
        /// <typeparam name="T">引数の型</typeparam>
        /// <param name="rhss">結合する形状</param>
        /// <returns>和集合形状</returns>
        public IMultiPolygon Union<T>(params T[] rhss)
            where T : IGeometry
        {
            return this.Union((IEnumerable<T>)rhss);
        }

        /// <summary>
        /// 指定された形状との和集合形状を返す演算子です。
        /// </summary>
        /// <typeparam name="T">引数の型</typeparam>
        /// <param name="rhss">結合する形状</param>
        /// <returns>和集合形状</returns>
        public IMultiPolygon Union<T>(IEnumerable<T> rhss)
            where T : IGeometry
        {
            SqlGeometry result = this.GEOMETRY;
            foreach (var rhs in rhss)
            {
                result = result.STUnion((SqlGeometry)rhs.RawInstance);
            }

            return new MultiPolygon(result);
        }
        #endregion

        #region Within
        /// <summary>
        /// 現在の形状が、指定された形状に完全に含まれているかどうかを取得します。
        /// </summary>
        /// <param name="rhs">比較する形状</param>
        /// <returns>完全に含まれていればtrue</returns>
        /// <remarks>Containsは逆演算子です。Touchesが成立する形状との演算ではfalseを返します。</remarks>
        public bool Within(IGeometry rhs)
        {
            Assertion.NullArgument(rhs, "比較するインスタンスが必要");

            return this.GEOMETRY.STWithin((SqlGeometry)rhs.RawInstance).Value;
        }
        #endregion

        #region Equals
        /// <summary>
        /// インスタンスが同一かどうかを確認します。
        /// </summary>
        /// <param name="rhs">比較先</param>
        /// <returns>同一の値を示していればtrue</returns>
        /// <remarks>内容は完全に一致（ポリゴン始終点などを含めて）している必要があります。</remarks>
        public bool Equals(IGeometry rhs)
        {
            if (rhs == null)
            {
                return false;
            }

            return this.GEOMETRY.STEquals((SqlGeometry)rhs.RawInstance).Value;
        }
        #endregion

        #region Overrides
        /// <summary>
        /// インスタンスが同一かどうかを確認します。
        /// </summary>
        /// <param name="obj">比較先</param>
        /// <returns>同一の値を示していればtrue</returns>
        /// <remarks>内容は完全に一致（ポリゴン始終点などを含めて）している必要があります。</remarks>
        public override bool Equals(object obj)
        {
            return this.Equals(obj as IGeometry);
        }

        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <returns>ハッシュコード</returns>
        public override int GetHashCode()
        {
            var datas = this.GEOMETRY.STAsBinary();
            var hashCode = 0;

            for (var index = 0; index < datas.Length; index++)
            {
                hashCode ^= datas.Buffer[index];
            }

            return hashCode;
        }

        /// <summary>
        /// インスタンスの文字列表現を取得します。
        /// </summary>
        /// <returns>文字列</returns>
        public override string ToString()
        {
            return this.GEOMETRY.ToString();
        }
        #endregion

        #region GetObjectData
        /// <summary>
        /// シリアル化メソッドです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecuritySafeCritical]
        void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
        {
            Assertion.Condition(info != null);

            using (var ms = new MemoryStream())
            {
                var writer = new BinaryWriter(ms);
                this.GEOMETRY.Write(writer);
                writer.Flush();

                info.AddValue("SqlGeometry", ms.ToArray());
            }
        }
        #endregion

        #region Clear
        /// <summary>
        /// 内容を消去します。
        /// </summary>
        /// <remarks>実装されていません。インスタンスは読み取り専用です。</remarks>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public void Clear()
        {
            throw new NotImplementedException();
        }
        #endregion

        #region CopyTo
        /// <summary>
        /// 内容を配列にコピーします。
        /// </summary>
        /// <param name="array">配列</param>
        /// <param name="index">インデックス</param>
        /// <remarks>実装されていません。</remarks>
        public virtual void CopyTo(Array array, int index)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}

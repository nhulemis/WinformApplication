﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.07 TMI K.Matsui

using System.Collections;
using System.Collections.Generic;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// GeoItemの比較演算子です。
    /// </summary>
    public static class GeoItemComparer
    {
        /// <summary>
        /// デフォルトのインスタンスを取得します。
        /// </summary>
        public static GeoItemComparer<CREO.DataModel.GeoItem> Default
        {
            get
            {
                return GeoItemComparer<CREO.DataModel.GeoItem>.Default;
            }
        }
    }

    /// <summary>
    /// GeoItemの比較演算子です。
    /// </summary>
    /// <typeparam name="T">対象の型</typeparam>
    public class GeoItemComparer<T> : IEqualityComparer<T>, IComparer<T>, IEqualityComparer, IComparer
        where T : CREO.DataModel.GeoItem
    {
        /// <summary>
        /// デフォルトのインスタンスです。
        /// </summary>
        private static readonly GeoItemComparer<T> DEFAULT = new GeoItemComparer<T>();

        /// <summary>
        /// デフォルトのインスタンスを取得します。
        /// </summary>
        public static GeoItemComparer<T> Default
        {
            get
            {
                return DEFAULT;
            }
        }

        /// <summary>
        /// 二つのGeoItem要素を比較します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        public bool Equals(T x, T y)
        {
            return x.OID.Equals(y.OID);
        }

        /// <summary>
        /// 二つのGeoItem要素を比較します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        bool IEqualityComparer.Equals(object x, object y)
        {
            return this.Equals(x as T, y as T);
        }

        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <param name="obj">要素</param>
        /// <returns>ハッシュコード</returns>
        public int GetHashCode(T obj)
        {
            return obj.OID.GetHashCode();
        }

        /// <summary>
        /// ハッシュコードを取得します。
        /// </summary>
        /// <param name="obj">要素</param>
        /// <returns>ハッシュコード</returns>
        int IEqualityComparer.GetHashCode(object obj)
        {
            return this.GetHashCode(obj as T);
        }

        /// <summary>
        /// 二つのGeoItem要素を比較します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        public int Compare(T x, T y)
        {
            return x.OID.CompareTo(y.OID);
        }

        /// <summary>
        /// 二つのGeoItem要素を比較します。
        /// </summary>
        /// <param name="x">比較元</param>
        /// <param name="y">比較先</param>
        /// <returns>結果</returns>
        int IComparer.Compare(object x, object y)
        {
            return this.Compare(x as T, y as T);
        }
    }
}

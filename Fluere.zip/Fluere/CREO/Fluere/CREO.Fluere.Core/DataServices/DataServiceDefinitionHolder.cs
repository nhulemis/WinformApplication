﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.29 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Linq;

using CREO.Fluere.Common.Collections;
using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.Executive;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービス情報を保持するクラスです。
    /// </summary>
    /// <remarks>フレームワークが保持するデータソース群と、アプリケーション構成ファイルに指定する
    /// データベースロール情報を集約し、一元管理出来るようにします。
    /// このクラスは内部で使用します。情報を取得する場合は、IDataServiceFactoryインターフェイスから取得して下さい。</remarks>
    internal sealed class DataServiceDefinitionHolder
    {
        #region Fields
        /// <summary>
        /// 空のリスト
        /// </summary>
        private static readonly KeyValuePair<string, DataServiceDefinition>[] EMPTY =
            new KeyValuePair<string, DataServiceDefinition>[0];

        /// <summary>
        /// データソース定義のリスト
        /// </summary>
        private readonly KeyValuePair<string, DataServiceDefinition>[] _dataSourceDefinitions;

        /// <summary>
        /// データベースロール定義のリスト
        /// </summary>
        private readonly KeyValuePair<string, DataServiceDefinition>[] _dataBaseRoleDefinitions;

        /// <summary>
        /// データベースロール定義の辞書
        /// </summary>
        private readonly Dictionary<string, DataServiceDefinition> _dataBaseRoleDefinitionDictionary;
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public DataServiceDefinitionHolder()
        {
            // データソースマネージャからデータソースの一覧を取得して保持する
            // （フレームワークが解釈出来ないデータソース・データプロバイダの型が指定されている要素は除外される）
            this._dataSourceDefinitions =
                (from dsi in
                     CREO.DS.DataSource.DataSourceManager.Current.EnumDataSources()
                 let dataSourceID = dsi.Id.Trim()
                 let dataServiceInformation = CreateDataServiceInformation(
                    dataSourceID,
                    DataServiceIDTypes.DataSourceID,
                    dsi,
                    null)
                 where dataServiceInformation != null
                 orderby dataSourceID
                 select KeyValuePair.Create(dataSourceID, dataServiceInformation)).ToArray();

            // データソース一覧を辞書化する
            var dataSourcesDictionary =
                this._dataSourceDefinitions.ToDictionary(entry => entry.Key, entry => entry.Value);

            // アプリケーション構成ファイルのdbroleSettingsを取得する
            var dbroleSettings =
                CREO.FW.Utilities.ProfileUtility.GetXElement(
                    CREO.FW.Utilities.ProfileUtility.ProfileTypeEnum.ModuleProfile,
                    "/configuration/dbroleSettings");

            // 存在すれば
            if (dbroleSettings != null)
            {
                // datasource_idを列挙してリストを生成する
                // （フレームワークが解釈出来ないデータソース・データプロバイダの型が指定されている要素は除外される）
                var step1 =
                    from dbrole in
                        dbroleSettings.Elements("dbrole")
                    let dataSourceIDAttribute = dbrole.Attribute("datasource_id")
                    where dataSourceIDAttribute != null
                    let nameAttribute = dbrole.Attribute("name")
                    where nameAttribute != null
                    let name = nameAttribute.Value.Trim()
                    let dataSourceID = dataSourceIDAttribute.Value.Trim()
                    let dsd = AssertDataSourceID(dataSourcesDictionary.GetValue(dataSourceID), name, dataSourceID)
                    where dsd != null
                    let dsi =
                        CreateDataServiceInformation(
                            name,
                            DataServiceIDTypes.DatabaseRoleID,
                            dsd.RawDataSourceInfo,
                            dsd.ProviderType)
                    where dsi != null
                    select new
                    {
                        Name = name,
                        DataSourceInfo = dsi
                    };

                // データベースロールの一覧を保持する
                this._dataBaseRoleDefinitions =
                    (from entry in step1
                     orderby entry.Name
                     select KeyValuePair.Create(entry.Name, entry.DataSourceInfo)).ToArray();
            }
            else
            {
                // 存在しない場合は空
                this._dataBaseRoleDefinitions = EMPTY;
            }

            // データベースロール一覧を辞書化して保持する
            this._dataBaseRoleDefinitionDictionary =
                this._dataBaseRoleDefinitions.ToDictionary(entry => entry.Key, entry => entry.Value);
        }
        #endregion

        #region AssertDataSourceID
        /// <summary>
        /// データソースIDが正しいことを確認します。
        /// </summary>
        /// <param name="dsd">正しいか判定を行うデータソース定義</param>
        /// <param name="name">ロール名</param>
        /// <param name="dataSourceID">データソースID</param>
        /// <returns>正しいと判定されたデータソース定義</returns>
        private static DataServiceDefinition AssertDataSourceID(
            DataServiceDefinition dsd,
            string name,
            string dataSourceID)
        {
            if (dsd == null)
            {
                InternalLogger.Logger.WriteTraceLog(
                    "データソースIDを特定出来ません: RoleName={0}, DataSourceID={1}",
                    name,
                    dataSourceID);
            }

            return dsd;
        }
        #endregion

        #region CreateDataServiceInformation
        /// <summary>
        /// DataServiceInformationのインスタンスを生成します。
        /// </summary>
        /// <param name="dataServiceID">データサービスID</param>
        /// <param name="idType">データサービスIDタイプ</param>
        /// <param name="rawDataSourceInfo">DataSourceInfo</param>
        /// <param name="providerType">プロバイダの型</param>
        /// <returns>成功した場合はインスタンス</returns>
        private static DataServiceDefinition CreateDataServiceInformation(
            string dataServiceID,
            DataServiceIDTypes idType,
            CREO.DS.DataSource.DataSourceInfo rawDataSourceInfo,
            Type providerType)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(dataServiceID) == false);
            Assertion.Condition(rawDataSourceInfo != null);

            try
            {
                return DataServiceDefinition.Create(dataServiceID, idType, rawDataSourceInfo, providerType);
            }
            catch (Exception ex)
            {
                Exception rex = ex; // Releaseビルドでのex不使用警告抑止
#if DEBUG
                InternalLogger.Logger.WriteTraceLog(
                    ex,
                    "データソース情報を特定出来ません: DataServiceID={0}, DataSourceID={1}, ProviderType={2}",
                    dataServiceID,
                    rawDataSourceInfo.Id,
                    (providerType != null) ? providerType.FullName : "(Unknown)");
#else
                InternalLogger.Logger.WriteTraceLog(
                    "データソース情報を特定出来ません: DataServiceID={0}, DataSourceID={1}, ProviderType={2}",
                    dataServiceID,
                    rawDataSourceInfo.Id,
                    (providerType != null) ? providerType.FullName : "(Unknown)");
#endif
                return null;
            }
        }
        #endregion

        #region LookupFromDatabaseRoleID
        /// <summary>
        /// データベースロールIDからデータソース情報を特定します。
        /// </summary>
        /// <param name="databaseRoleID">データベースロールID</param>
        /// <returns>データソース情報</returns>
        public DataServiceDefinition LookupFromDatabaseRoleID(string databaseRoleID)
        {
            Assertion.Condition(string.IsNullOrWhiteSpace(databaseRoleID) == false);

            DataServiceDefinition dataServiceInformation;
            if (this._dataBaseRoleDefinitionDictionary.TryGetValue(databaseRoleID.Trim(), out dataServiceInformation) == false)
            {
                return null;
            }

            return dataServiceInformation;
        }
        #endregion

        #region GetDataServiceDefinitions
        /// <summary>
        /// 設定ファイルに定義されているデータサービスに対応する情報群を取得します。
        /// </summary>
        /// <param name="extractTypes">抽出条件</param>
        /// <returns>データサービス情報の列挙子</returns>
        public IEnumerable<DataServiceDefinition> GetDataServiceDefinitions(
            DataServiceIDExtractTypes extractTypes)
        {
            var databaseRoleIDs =
                ((extractTypes & DataServiceIDExtractTypes.DatabaseRoleID) == DataServiceIDExtractTypes.DatabaseRoleID) ?
                this._dataBaseRoleDefinitions : EMPTY;

            var dataSourceIDs =
                ((extractTypes & DataServiceIDExtractTypes.DataSourceID) == DataServiceIDExtractTypes.DataSourceID) ?
                this._dataSourceDefinitions : EMPTY;

            return
                databaseRoleIDs.Concat(dataSourceIDs).Select(entry => entry.Value);
        }
        #endregion
    }
}

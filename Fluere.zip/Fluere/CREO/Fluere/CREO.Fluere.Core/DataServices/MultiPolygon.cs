﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.SqlTypes;
using System.Linq;
using System.Runtime.Serialization;
using System.Security;
using System.Xml;
using CREO.Fluere.Common.Diagnostics;
using Microsoft.SqlServer.Types;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするラップクラスです。
    /// </summary>
    /// <remarks>SqlGeometryクラスの操作を分離し、マルチポリゴン・ポリゴン・リング・ポイントを
    /// 階層化されたインターフェイスで表現可能にし、不必要な表現変換を不要にします。
    /// また、ICollectionを実装し、LINQクエリを高速化し、シリアル化可能にします。
    /// MultiPolygonクラスのインスタンス生成には、CoordinateExtensionクラスの拡張メソッド（ToMultiPolygon）を使用します。</remarks>
    [Serializable]
    internal sealed class MultiPolygon : GeometryBase, IMultiPolygon, ICollection<IPolygon>, ICollection
    {
        #region Fields
        /// <summary>
        /// 比較演算子
        /// </summary>
        private static readonly CoordinateEqualityComparer COMPARER = new CoordinateEqualityComparer();
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="sqlGeometry">SqlGeometry</param>
        internal MultiPolygon(SqlGeometry sqlGeometry)
            : base(sqlGeometry)
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="wkt">WellKnownText</param>
        /// <remarks>任意のWellKnownTextからインスタンスを生成します。</remarks>
        internal MultiPolygon(string wkt)
            : base(FromWellKnownText(wkt))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="gml">Geography Markup Language</param>
        /// <remarks>任意のGeography Markup Languageからインスタンスを生成します。</remarks>
        internal MultiPolygon(XmlReader gml)
            : base(FromGML(gml))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="point">座標</param>
        /// <remarks>任意の座標からインスタンスを生成します。</remarks>
        internal MultiPolygon(System.Windows.Point point)
            : base(FromPoint(point))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="point">座標</param>
        /// <remarks>任意の座標からインスタンスを生成します。</remarks>
        internal MultiPolygon(CREO.FW.TMIGeometry.Coordinate point)
            : base(FromPoint(point))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="point">座標</param>
        /// <remarks>任意の座標からインスタンスを生成します。</remarks>
        internal MultiPolygon(CREO.FW.TMIGeometry.CoordinateD point)
            : base(FromPoint(point))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="pointCollection">座標のコレクション</param>
        /// <remarks>座標のコレクションからインスタンスを生成します。</remarks>
        internal MultiPolygon(IEnumerable<CREO.FW.TMIGeometry.Coordinate> pointCollection)
            : base(FromPointCollection(pointCollection))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="pointCollection">座標のコレクション</param>
        /// <remarks>座標のコレクションからインスタンスを生成します。</remarks>
        internal MultiPolygon(IEnumerable<CREO.FW.TMIGeometry.CoordinateD> pointCollection)
            : base(FromPointCollection(pointCollection))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="pointsCollection">座標群のコレクション</param>
        /// <remarks>座標群のコレクションからインスタンスを生成します。</remarks>
        internal MultiPolygon(IEnumerable<IEnumerable<CREO.FW.TMIGeometry.Coordinate>> pointsCollection)
            : base(FromPointsCollection(pointsCollection))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="pointsCollection">座標群のコレクション</param>
        /// <remarks>座標群のコレクションからインスタンスを生成します。</remarks>
        internal MultiPolygon(IEnumerable<IEnumerable<CREO.FW.TMIGeometry.CoordinateD>> pointsCollection)
            : base(FromPointsCollection(pointsCollection))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="rect">矩形</param>
        /// <remarks>矩形からインスタンスを生成します。</remarks>
        internal MultiPolygon(CREO.FW.TMIGeometry.CoordinateRect rect)
            : base(FromRect(rect))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="compositePolygon">CompositePolygon</param>
        /// <remarks>CompositePolygonからインスタンスを生成します。</remarks>
        internal MultiPolygon(CREO.FW.TMIGeometry.CompositePolygon compositePolygon)
            : base(FromCompositePolygon(compositePolygon))
        {
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="compositePolygonCollection">CompositePolygonのコレクション</param>
        /// <remarks>CompositePolygonのコレクションからインスタンスを生成します。</remarks>
        internal MultiPolygon(IEnumerable<CREO.FW.TMIGeometry.CompositePolygon> compositePolygonCollection)
            : base(FromCompositePolygonCollection(compositePolygonCollection))
        {
        }

        /// <summary>
        /// 逆シリアル化コンストラクタです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecurityCritical]
        private MultiPolygon(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
        #endregion

        #region Count
        /// <summary>
        /// 内包するポリゴン数を取得します。
        /// </summary>
        public int Count
        {
            get
            {
                var type = this.GeometryStructureType;

                if (type == GeometryStructureTypes.Empty)
                {
                    return 0;
                }

                if (type == GeometryStructureTypes.Multiple)
                {
                    return this.GEOMETRY.STNumGeometries().Value;
                }

                return 1;
            }
        }
        #endregion

        #region Indexer
        /// <summary>
        /// インデックスを指定して、ポリゴンを取得します。
        /// </summary>
        /// <param name="index">インデックス</param>
        /// <returns>ポリゴン</returns>
        public IPolygon this[int index]
        {
            get
            {
                var type = this.GeometryStructureType;

                Assertion.Argument<ArgumentOutOfRangeException>(
                    type != GeometryStructureTypes.Empty,
                    "インスタンスは空です");

                if (type == GeometryStructureTypes.Multiple)
                {
                    Assertion.Argument<ArgumentOutOfRangeException>(
                        index < this.GEOMETRY.STNumGeometries().Value,
                        "インデックスは範囲外です");

                    return new Polygon(this.GEOMETRY.STGeometryN(index + 1));
                }

                Assertion.Argument<ArgumentOutOfRangeException>(
                    index == 0,
                    "インデックスは範囲外です");

                return new Polygon(this.GEOMETRY);
            }
        }
        #endregion

        #region FromWellKnownText
        /// <summary>
        /// WellKnownTextから生成する
        /// </summary>
        /// <param name="wkt">WellKnownText</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromWellKnownText(string wkt)
        {
            return SqlGeometry.STGeomFromText(new SqlChars(wkt), GeometryBase.SRID);
        }
        #endregion

        #region FromGML
        /// <summary>
        /// WellKnownTextから生成する
        /// </summary>
        /// <param name="gml">Geography Markup Language</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromGML(XmlReader gml)
        {
            return SqlGeometry.GeomFromGml(new SqlXml(gml), GeometryBase.SRID);
        }
        #endregion

        #region FromPoint
        /// <summary>
        /// 座標から生成する
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromPoint(System.Windows.Point point)
        {
            return SqlGeometry.Point(point.X, point.Y, GeometryBase.SRID);
        }

        /// <summary>
        /// 座標から生成する
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromPoint(CREO.FW.TMIGeometry.Coordinate point)
        {
            Assertion.NullArgument(point, "座標を示すインスタンスが必要です");

            return SqlGeometry.Point(point.Longitude, point.Latitude, GeometryBase.SRID);
        }

        /// <summary>
        /// 座標から生成する
        /// </summary>
        /// <param name="point">座標</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromPoint(CREO.FW.TMIGeometry.CoordinateD point)
        {
            Assertion.NullArgument(point, "座標を示すインスタンスが必要です");

            return SqlGeometry.Point(point.Longitude, point.Latitude, GeometryBase.SRID);
        }
        #endregion

        #region GetGeometryType
        /// <summary>
        /// 指定された座標リストから、ジオメトリタイプを取得します。
        /// </summary>
        /// <param name="pointList">座標リスト</param>
        /// <returns>ジオメトリタイプ</returns>
        private static OpenGisGeometryType GetGeometryType(List<CREO.FW.TMIGeometry.Coordinate> pointList)
        {
            Assertion.Condition(pointList != null);

            return COMPARER.Equals(pointList.First(), pointList.Last()) ?
                OpenGisGeometryType.Polygon : OpenGisGeometryType.LineString;
        }

        /// <summary>
        /// 指定された座標リストから、ジオメトリタイプを取得します。
        /// </summary>
        /// <param name="pointList">座標リスト</param>
        /// <returns>ジオメトリタイプ</returns>
        private static OpenGisGeometryType GetGeometryType(List<CREO.FW.TMIGeometry.CoordinateD> pointList)
        {
            Assertion.Condition(pointList != null);

            return COMPARER.Equals(pointList.First(), pointList.Last()) ?
                OpenGisGeometryType.Polygon : OpenGisGeometryType.LineString;
        }

        /// <summary>
        /// 指定された座標リストから、ジオメトリタイプを取得します。
        /// </summary>
        /// <param name="pointsList">座標リスト</param>
        /// <returns>ジオメトリタイプ</returns>
        private static OpenGisGeometryType GetGeometryType(List<List<CREO.FW.TMIGeometry.Coordinate>> pointsList)
        {
            Assertion.Condition(pointsList != null);

            // 全ての内包コレクションがPolygonならMultiPolygon、それ以外はGeometryCollection
            var result =
                pointsList.Aggregate(
                -1,
                (accumulate, pointList) =>
                {
                    switch (accumulate)
                    {
                        // 未判定
                        case -1:
                            return (GetGeometryType(pointList) == OpenGisGeometryType.Polygon) ? 1 : 2;

                        // Polygon中
                        case 1:
                            return (GetGeometryType(pointList) == OpenGisGeometryType.Polygon) ? 1 : 0;

                        // LineString中
                        case 2:
                            return (GetGeometryType(pointList) == OpenGisGeometryType.LineString) ? 2 : 0;

                        // 混在（無視）
                        default:
                            return 0;
                    }
                });

            switch (result)
            {
                case 1:
                    return OpenGisGeometryType.MultiPolygon;
                case 2:
                    return OpenGisGeometryType.MultiLineString;
                default:
                    return OpenGisGeometryType.GeometryCollection;
            }
        }

        /// <summary>
        /// 指定された座標リストから、ジオメトリタイプを取得します。
        /// </summary>
        /// <param name="pointsList">座標リスト</param>
        /// <returns>ジオメトリタイプ</returns>
        private static OpenGisGeometryType GetGeometryType(List<List<CREO.FW.TMIGeometry.CoordinateD>> pointsList)
        {
            Assertion.Condition(pointsList != null);

            // 全ての内包コレクションがPolygonならMultiPolygon、それ以外はGeometryCollection
            var result =
                pointsList.Aggregate(
                -1,
                (accumulate, pointList) =>
                {
                    switch (accumulate)
                    {
                        // 未判定
                        case -1:
                            return (GetGeometryType(pointList) == OpenGisGeometryType.Polygon) ? 1 : 2;

                        // Polygon中
                        case 1:
                            return (GetGeometryType(pointList) == OpenGisGeometryType.Polygon) ? 1 : 0;

                        // LineString中
                        case 2:
                            return (GetGeometryType(pointList) == OpenGisGeometryType.LineString) ? 2 : 0;

                        // 混在（無視）
                        default:
                            return 0;
                    }
                });

            switch (result)
            {
                case 1:
                    return OpenGisGeometryType.MultiPolygon;
                case 2:
                    return OpenGisGeometryType.MultiLineString;
                default:
                    return OpenGisGeometryType.GeometryCollection;
            }
        }
        #endregion

        #region FromPointCollection
        /// <summary>
        /// 座標のコレクションから生成する
        /// </summary>
        /// <param name="pointCollection">座標のコレクション</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromPointCollection(IEnumerable<CREO.FW.TMIGeometry.Coordinate> pointCollection)
        {
            Assertion.NullArgument(pointCollection, "座標のコレクションが必要です");

            var gb = new SqlGeometryBuilder();
            gb.SetSrid(GeometryBase.SRID);

            var pointList = pointCollection.ToList();

            bool foundPoint = false;
            foreach (var point in pointList)
            {
                if (foundPoint == false)
                {
                    gb.BeginGeometry(GetGeometryType(pointList));
                    gb.BeginFigure(point.Longitude, point.Latitude, null, null);
                    foundPoint = true;
                }
                else
                {
                    gb.AddLine(point.Longitude, point.Latitude, null, null);
                }
            }

            if (foundPoint == true)
            {
                gb.EndFigure();
                gb.EndGeometry();
            }

            return gb.ConstructedGeometry;
        }

        /// <summary>
        /// 座標のコレクションから生成する
        /// </summary>
        /// <param name="pointCollection">座標のコレクション</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromPointCollection(IEnumerable<CREO.FW.TMIGeometry.CoordinateD> pointCollection)
        {
            Assertion.NullArgument(pointCollection, "座標のコレクションが必要です");

            var gb = new SqlGeometryBuilder();
            gb.SetSrid(GeometryBase.SRID);

            var pointList = pointCollection.ToList();

            bool foundPoint = false;
            foreach (var point in pointList)
            {
                if (foundPoint == false)
                {
                    gb.BeginGeometry(GetGeometryType(pointList));
                    gb.BeginFigure(point.Longitude, point.Latitude, null, null);
                    foundPoint = true;
                }
                else
                {
                    gb.AddLine(point.Longitude, point.Latitude, null, null);
                }
            }

            if (foundPoint == true)
            {
                gb.EndFigure();
                gb.EndGeometry();
            }

            return gb.ConstructedGeometry;
        }
        #endregion

        #region FromPointsCollection
        /// <summary>
        /// 座標群のコレクションから生成する
        /// </summary>
        /// <param name="pointsCollection">座標群のコレクション</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromPointsCollection(
            IEnumerable<IEnumerable<CREO.FW.TMIGeometry.Coordinate>> pointsCollection)
        {
            Assertion.NullArgument(pointsCollection, "座標群のコレクションが必要です");

            var gb = new SqlGeometryBuilder();
            gb.SetSrid(GeometryBase.SRID);

            // 全展開
            var pointsList = pointsCollection.Select(pointCollection => pointCollection.ToList()).ToList();

            bool foundPolygon = false;
            foreach (var polygon in pointsList)
            {
                bool foundPoint = false;
                foreach (var point in polygon)
                {
                    if (foundPolygon == false)
                    {
                        gb.BeginGeometry(GetGeometryType(pointsList));
                        foundPolygon = true;
                    }

                    if (foundPoint == false)
                    {
                        gb.BeginGeometry(GetGeometryType(polygon));
                        gb.BeginFigure(point.Longitude, point.Latitude, null, null);
                        foundPoint = true;
                    }
                    else
                    {
                        gb.AddLine(point.Longitude, point.Latitude, null, null);
                    }
                }

                if (foundPoint == true)
                {
                    gb.EndFigure();
                    gb.EndGeometry();
                }
            }

            if (foundPolygon == true)
            {
                gb.EndGeometry();
            }

            return gb.ConstructedGeometry;
        }

        /// <summary>
        /// 座標群のコレクションから生成する
        /// </summary>
        /// <param name="pointsCollection">座標群のコレクション</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromPointsCollection(
            IEnumerable<IEnumerable<CREO.FW.TMIGeometry.CoordinateD>> pointsCollection)
        {
            Assertion.NullArgument(pointsCollection, "座標群のコレクションが必要です");

            var gb = new SqlGeometryBuilder();
            gb.SetSrid(GeometryBase.SRID);

            // 全展開
            var pointsList = pointsCollection.Select(pointCollection => pointCollection.ToList()).ToList();

            bool foundPolygon = false;
            foreach (var polygon in pointsList)
            {
                bool foundPoint = false;
                foreach (var point in polygon)
                {
                    if (foundPolygon == false)
                    {
                        gb.BeginGeometry(GetGeometryType(pointsList));
                        foundPolygon = true;
                    }

                    if (foundPoint == false)
                    {
                        gb.BeginGeometry(GetGeometryType(polygon));
                        gb.BeginFigure(point.Longitude, point.Latitude, null, null);
                        foundPoint = true;
                    }
                    else
                    {
                        gb.AddLine(point.Longitude, point.Latitude, null, null);
                    }
                }

                if (foundPoint == true)
                {
                    gb.EndFigure();
                    gb.EndGeometry();
                }
            }

            if (foundPolygon == true)
            {
                gb.EndGeometry();
            }

            return gb.ConstructedGeometry;
        }
        #endregion

        #region FromRect
        /// <summary>
        /// CoordinateRectから生成する
        /// </summary>
        /// <param name="rect">CoordinateRect</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromRect(CREO.FW.TMIGeometry.CoordinateRect rect)
        {
            Assertion.NullArgument(rect, "矩形が必要です");

            return FromPointCollection(new[]
                {
                    rect.BottomLeft,
                    new CREO.FW.TMIGeometry.Coordinate(rect.BottomLeft.Longitude, rect.TopRight.Latitude),
                    rect.TopRight,
                    new CREO.FW.TMIGeometry.Coordinate(rect.TopRight.Longitude, rect.BottomLeft.Latitude),
                    rect.BottomLeft
                });
        }
        #endregion

        #region FromCompositePolygon
        /// <summary>
        /// CompositePolygonから生成する
        /// </summary>
        /// <param name="compositePolygon">CompositePolygon</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromCompositePolygon(
            CREO.FW.TMIGeometry.CompositePolygon compositePolygon)
        {
            Assertion.NullArgument(compositePolygon, "CompositePolygonが必要です");

            var gb = new SqlGeometryBuilder();
            gb.SetSrid(GeometryBase.SRID);

            bool foundRing = false;
            bool foundPoint = false;
            foreach (var point in compositePolygon.OuterRing)
            {
                if (foundRing == false)
                {
                    gb.BeginGeometry(GetGeometryType(compositePolygon.OuterRing));
                    foundRing = true;
                }

                if (foundPoint == false)
                {
                    gb.BeginFigure(point.Longitude, point.Latitude, null, null);
                    foundPoint = true;
                }
                else
                {
                    gb.AddLine(point.Longitude, point.Latitude, null, null);
                }
            }

            if (foundPoint == true)
            {
                gb.EndFigure();
            }

            foreach (var ring in compositePolygon.InnerRingAry)
            {
                foundPoint = false;
                foreach (var point in ring)
                {
                    if (foundRing == false)
                    {
                        gb.BeginGeometry(GetGeometryType(compositePolygon.InnerRingAry));
                        gb.BeginGeometry(GetGeometryType(ring));
                        foundRing = true;
                    }

                    if (foundPoint == false)
                    {
                        gb.BeginFigure(point.Longitude, point.Latitude, null, null);
                        foundPoint = true;
                    }
                    else
                    {
                        gb.AddLine(point.Longitude, point.Latitude, null, null);
                    }
                }

                if (foundPoint == true)
                {
                    gb.EndFigure();
                }
            }

            if (foundRing == true)
            {
                gb.EndGeometry();
            }

            return gb.ConstructedGeometry;
        }
        #endregion

        #region FromCompositePolygonCollection
        /// <summary>
        /// CompositePolygonのコレクションから生成する
        /// </summary>
        /// <param name="compositePolygonCollection">CompositePolygonのコレクション</param>
        /// <returns>SqlGeometry</returns>
        private static SqlGeometry FromCompositePolygonCollection(
            IEnumerable<CREO.FW.TMIGeometry.CompositePolygon> compositePolygonCollection)
        {
            Assertion.NullArgument(compositePolygonCollection, "CompositePolygonのコレクションが必要です");

            var gb = new SqlGeometryBuilder();
            gb.SetSrid(GeometryBase.SRID);

            // 展開
            var compositePolygonList = compositePolygonCollection.ToList();

            bool foundPolygon = false;
            foreach (var compositePolygon in compositePolygonList)
            {
                bool foundRing = false;
                bool foundPoint = false;
                foreach (var point in compositePolygon.OuterRing)
                {
                    if (foundPolygon == false)
                    {
                        var type = GetGeometryType(compositePolygon.OuterRing);
                        if (compositePolygonList.Count >= 2)
                        {
                            gb.BeginGeometry((type == OpenGisGeometryType.Polygon) ? OpenGisGeometryType.MultiPolygon : OpenGisGeometryType.MultiLineString);
                        }

                        foundPolygon = true;
                    }

                    if (foundRing == false)
                    {
                        gb.BeginGeometry(GetGeometryType(compositePolygon.OuterRing));
                        foundRing = true;
                    }

                    if (foundPoint == false)
                    {
                        gb.BeginFigure(point.Longitude, point.Latitude, null, null);
                        foundPoint = true;
                    }
                    else
                    {
                        gb.AddLine(point.Longitude, point.Latitude, null, null);
                    }
                }

                if (foundPoint == true)
                {
                    gb.EndFigure();
                }

                foreach (var ring in compositePolygon.InnerRingAry)
                {
                    foundPoint = false;
                    foreach (var point in ring)
                    {
                        if (foundPolygon == false)
                        {
                            gb.BeginGeometry(GetGeometryType(compositePolygon.InnerRingAry));
                            foundPolygon = true;
                        }

                        if (foundRing == false)
                        {
                            gb.BeginGeometry(GetGeometryType(ring));
                            foundRing = true;
                        }

                        if (foundPoint == false)
                        {
                            gb.BeginFigure(point.Longitude, point.Latitude, null, null);
                            foundPoint = true;
                        }
                        else
                        {
                            gb.AddLine(point.Longitude, point.Latitude, null, null);
                        }
                    }

                    if (foundPoint == true)
                    {
                        gb.EndFigure();
                    }
                }

                if (foundRing == true)
                {
                    gb.EndGeometry();
                }
            }

            if (foundPolygon == true)
            {
                if (compositePolygonList.Count >= 2)
                {
                    gb.EndGeometry();
                }
            }

            return gb.ConstructedGeometry;
        }
        #endregion

        #region ToMultiPolygon
        /// <summary>
        /// 同じ内容を示すマルチポリゴンインスタンスに変換します。
        /// </summary>
        /// <returns>マルチポリゴン</returns>
        public override IMultiPolygon ToMultiPolygon()
        {
            return this;
        }
        #endregion

        #region ToCoordinatesCollection
        /// <summary>
        /// マルチポリゴンをCoordinateの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        /// <remarks>返却する列挙子は、リングを表現出来ません。
        /// そのため、内包するポリゴンに複数のリングが含まれている場合、例外がスローされます。</remarks>
        public IEnumerable<IEnumerable<CREO.FW.TMIGeometry.Coordinate>> ToCoordinatesCollection()
        {
            return this.Select(polygon => polygon.ToCoordinateCollection());
        }
        #endregion

        #region ToCoordinateDsCollection
        /// <summary>
        /// マルチポリゴンをCoordinateDの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        /// <remarks>返却する列挙子は、リングを表現出来ません。
        /// そのため、内包するポリゴンに複数のリングが含まれている場合、例外がスローされます。</remarks>
        public IEnumerable<IEnumerable<CREO.FW.TMIGeometry.CoordinateD>> ToCoordinateDsCollection()
        {
            return this.Select(polygon => polygon.ToCoordinateDCollection());
        }
        #endregion

        #region ToCompositePolygonCollection
        /// <summary>
        /// マルチポリゴンをCompositePolygonの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        public IEnumerable<CREO.FW.TMIGeometry.CompositePolygon> ToCompositePolygonCollection()
        {
            return this.Select(polygon => polygon.ToCompositePolygon());
        }
        #endregion

        #region Transform
        /// <summary>
        /// 指定したアフィン変換演算子を適用します。
        /// </summary>
        /// <param name="matrix">アフィン変換演算子を示す行列</param>
        /// <returns>形状</returns>
        public override IMultiPolygon TransformBy(System.Windows.Media.Matrix matrix)
        {
            // TODO: MultiLineString, LineString, MultiPoint
            var gb = new SqlGeometryBuilder();
            gb.SetSrid(GeometryBase.SRID);

            bool foundPolygon = false;
            foreach (var polygon in this)
            {
                bool foundRing = false;
                foreach (var ring in polygon)
                {
                    var points = ring.Select(point => new System.Windows.Point(point.X, point.Y)).ToArray();
                    if (points.Length >= 1)
                    {
                        matrix.Transform(points);

                        bool foundPoint = false;
                        for (var index = 0; index < points.Length; index++)
                        {
                            if (foundPolygon == false)
                            {
                                gb.BeginGeometry(OpenGisGeometryType.MultiPolygon);
                                foundPolygon = true;
                            }

                            if (foundRing == false)
                            {
                                gb.BeginGeometry(OpenGisGeometryType.Polygon);
                                foundRing = true;
                            }

                            if (foundPoint == false)
                            {
                                gb.BeginFigure(points[0].X, points[0].Y, null, null);
                                foundPoint = true;
                            }
                            else
                            {
                                gb.AddLine(points[index].X, points[index].Y, null, null);
                            }
                        }

                        if (foundPoint == true)
                        {
                            gb.EndFigure();
                        }
                    }
                }

                if (foundRing == true)
                {
                    gb.EndGeometry();
                }
            }

            if (foundPolygon == true)
            {
                gb.EndGeometry();
            }

            return new MultiPolygon(gb.ConstructedGeometry);
        }
        #endregion

        #region GetEnumerator
        /// <summary>
        /// マルチポリゴンの列挙子を取得します。
        /// </summary>
        /// <returns>列挙子</returns>
        public IEnumerator<IPolygon> GetEnumerator()
        {
            var type = this.GeometryStructureType;

            if (type == GeometryStructureTypes.Empty)
            {
                yield break;
            }

            if (type == GeometryStructureTypes.Multiple)
            {
                for (int index = 0, count = this.GEOMETRY.STNumGeometries().Value; index < count; index++)
                {
                    yield return new Polygon(this.GEOMETRY.STGeometryN(index + 1));
                }

                yield break;
            }

            yield return new Polygon(this.GEOMETRY);
        }

        /// <summary>
        /// マルチポリゴンの列挙子を取得します。
        /// </summary>
        /// <returns>列挙子</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion

        #region ICollection
        /// <summary>
        /// インスタンスを追加します。
        /// </summary>
        /// <param name="item">対象のインスタンス</param>
        /// <remarks>実装されていません。</remarks>
        void ICollection<IPolygon>.Add(IPolygon item)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// インスタンスが含まれているかどうかを確認します。
        /// </summary>
        /// <param name="item">対象のインスタンス</param>
        /// <returns>なし</returns>
        /// <remarks>実装されていません。</remarks>
        bool ICollection<IPolygon>.Contains(IPolygon item)
        {
            return this.Any(polygon => polygon.Equals(item));
        }

        /// <summary>
        /// 内容を配列にコピーします。
        /// </summary>
        /// <param name="array">配列</param>
        /// <param name="arrayIndex">インデックス</param>
        /// <remarks>実装されていません。</remarks>
        void ICollection<IPolygon>.CopyTo(IPolygon[] array, int arrayIndex)
        {
            var index = arrayIndex;
            foreach (var polygon in this)
            {
                array[index] = polygon;
                index++;
            }
        }

        /// <summary>
        /// 内容を配列にコピーします。
        /// </summary>
        /// <param name="array">配列</param>
        /// <param name="arrayIndex">インデックス</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public override void CopyTo(Array array, int arrayIndex)
        {
            var realArray = (IPolygon[])array;
            var index = arrayIndex;
            foreach (var polygon in this)
            {
                realArray[index] = polygon;
                index++;
            }
        }

        /// <summary>
        /// インスタンスを削除します。
        /// </summary>
        /// <param name="item">対象のインスタンス</param>
        /// <returns>なし</returns>
        /// <remarks>実装されていません。</remarks>
        bool ICollection<IPolygon>.Remove(IPolygon item)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}

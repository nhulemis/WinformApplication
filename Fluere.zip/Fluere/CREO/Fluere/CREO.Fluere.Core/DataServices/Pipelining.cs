﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.04 TMI K.Matsui

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Threading;
using CREO.Fluere.Common.DataServices.Linq;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データサービスのクエリ実行をパイプライン化するクラスです。
    /// </summary>
    /// <remarks>エリア分割を行うためには、検索タイプに空間実体を含み、検索条件を指定しないようにする必要があります。</remarks>
    public static class Pipelining
    {
        #region QueryItemsPipelined
        /// <summary>
        /// 指定されたデータサービスと検索条件でクエリを実行する、パイプライン化可能な列挙子を生成します。
        /// </summary>
        /// <param name="dataService">データサービス</param>
        /// <param name="condition">QueryItemsConditionのインスタンス</param>
        /// <param name="meshType">エリア分割で使用するメッシュタイプ。nullの場合はエリア分割しない</param>
        /// <param name="pipelineQueueCount">キューサイズ</param>
        /// <returns>列挙子</returns>
        /// <remarks>実際のクエリ実行は、結果が列挙されるまで遅延されます。
        /// フェッチはパイプライン化され、キャッシュされません。キャッシュデータも使用しません。
        /// <para>キューサイズを拡大した場合、滞留するデータによってメモリの一時使用量が拡大しますが、
        /// クエリ呼び出し側へのデータ供給の連続性が高まります。
        /// （キューサイズは概算です。一時的に指定したサイズを超える場合があります）</para></remarks>
        public static IEnumerable<CREO.DataModel.GeoItem> QueryItemsPipelined(
            this CREO.DS.DataService dataService,
            CREO.DS.QueryItemsCondition condition,
            int? meshType = 0,
            int pipelineQueueCount = 10000)
        {
            return dataService.QueryItemsPipelined<CREO.DataModel.GeoItem>(condition, meshType, pipelineQueueCount);
        }

        /// <summary>
        /// 指定されたデータサービスファクトリと検索条件でクエリを実行する、パイプライン化可能な列挙子を生成します。
        /// </summary>
        /// <param name="preBoundFactory">事前バインドされたデータサービスファクトリ</param>
        /// <param name="condition">QueryItemsConditionのインスタンス</param>
        /// <param name="meshType">エリア分割で使用するメッシュタイプ。nullの場合はエリア分割しない</param>
        /// <param name="pipelineQueueCount">キューサイズ</param>
        /// <returns>列挙子</returns>
        /// <remarks>実際のクエリ実行は、結果が列挙されるまで遅延されます。
        /// フェッチはパイプライン化され、キャッシュされません。キャッシュデータも使用しません。
        /// また、トランザクションは無効で、取得したデータは読み取り専用です。
        /// <para>キューサイズを拡大した場合、滞留するデータによってメモリの一時使用量が拡大しますが、
        /// クエリ呼び出し側へのデータ供給の連続性が高まります。
        /// （キューサイズは概算です。一時的に指定したサイズを超える場合があります）</para></remarks>
        public static IEnumerable<CREO.DataModel.GeoItem> QueryItemsPipelined(
            this IPreBoundDataServiceFactory preBoundFactory,
            CREO.DS.QueryItemsCondition condition,
            int? meshType = 0,
            int pipelineQueueCount = 10000)
        {
            return preBoundFactory.QueryItemsPipelined<CREO.DataModel.GeoItem>(condition, meshType, pipelineQueueCount);
        }

        /// <summary>
        /// 指定されたデータサービスと検索条件でクエリを実行する、パイプライン化可能な列挙子を生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="dataService">データサービス</param>
        /// <param name="condition">QueryItemsConditionのインスタンス</param>
        /// <param name="meshType">エリア分割で使用するメッシュタイプ。nullの場合はエリア分割しない</param>
        /// <param name="pipelineQueueCount">キューサイズ</param>
        /// <returns>列挙子</returns>
        /// <remarks>実際のクエリ実行は、結果が列挙されるまで遅延されます。
        /// フェッチはパイプライン化され、キャッシュされません。キャッシュデータも使用しません。
        /// <para>キューサイズを拡大した場合、滞留するデータによってメモリの一時使用量が拡大しますが、
        /// クエリ呼び出し側へのデータ供給の連続性が高まります。
        /// （キューサイズは概算です。一時的に指定したサイズを超える場合があります）</para></remarks>
        public static IEnumerable<T> QueryItemsPipelined<T>(
            this CREO.DS.DataService dataService,
            CREO.DS.QueryItemsCondition condition,
            int? meshType = 0,
            int pipelineQueueCount = 10000)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(dataService, "データサービスが必要です");
            Assertion.NullArgument(condition, "条件が必要です");
            Assertion.Argument(pipelineQueueCount >= 1, "キューサイズは1以上である必要があります");

            // パイプライン実行する場合、ProcessItemsメソッドを使用するため、キャッシュは全く参照しない（出来ない）。
            System.Diagnostics.Trace.WriteLine(
                string.Format(
                    "QueryItemsPipelined: Iteration start, ThreadID={0}, DataService={1}, Condition=\"{2}\"",
                    Thread.CurrentThread.ManagedThreadId,
                    dataService.GetHashCode(),
                    condition.ToString().Replace("\r", " ").Replace("\n", " ")));

            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            try
            {
                using (var context = new PipelinedIteratorContext<T>(
                    dataService,
                    condition,
                    meshType,
                    pipelineQueueCount))
                {
                    using (var enumerator = context.Consuming.GetEnumerator())
                    {
                        while (true)
                        {
                            bool available = false;
                            try
                            {
                                available = enumerator.MoveNext();
                            }
                            catch (OperationCanceledException)
                            {
                            }

                            if (available == false)
                            {
                                break;
                            }

                            foreach (var result in enumerator.Current)
                            {
                                yield return result;
                            }
                        }
                    }
                }
            }
            finally
            {
                sw.Stop();

                System.Diagnostics.Trace.WriteLine(
                    string.Format(
                        "QueryItemsPipelined: Iteration finished, ThreadID={0}, DataService={1}, Elapsed={2}",
                        Thread.CurrentThread.ManagedThreadId,
                        dataService.GetHashCode(),
                        sw.Elapsed));
            }
        }

        /// <summary>
        /// 指定されたデータサービスと検索条件でクエリを実行する、パイプライン化可能な列挙子を生成します。
        /// </summary>
        /// <typeparam name="T">結果を示す型</typeparam>
        /// <param name="preBoundFactory">事前バインドされたデータサービスファクトリ</param>
        /// <param name="condition">QueryItemsConditionのインスタンス</param>
        /// <param name="meshType">エリア分割で使用するメッシュタイプ。nullの場合はエリア分割しない</param>
        /// <param name="pipelineQueueCount">キューサイズ</param>
        /// <returns>列挙子</returns>
        /// <remarks>実際のクエリ実行は、結果が列挙されるまで遅延されます。
        /// フェッチはパイプライン化され、キャッシュされません。キャッシュデータも使用しません。
        /// また、トランザクションは無効で、読み取り専用です。
        /// <para>キューサイズを拡大した場合、滞留するデータによってメモリの一時使用量が拡大しますが、
        /// クエリ呼び出し側へのデータ供給の連続性が高まります。
        /// （キューサイズは概算です。一時的に指定したサイズを超える場合があります）</para></remarks>
        public static IEnumerable<T> QueryItemsPipelined<T>(
            this IPreBoundDataServiceFactory preBoundFactory,
            CREO.DS.QueryItemsCondition condition,
            int? meshType = 0,
            int pipelineQueueCount = 10000)
            where T : CREO.DataModel.GeoItem
        {
            Assertion.NullArgument(preBoundFactory, "事前バインドされたデータサービスファクトリが必要です");
            Assertion.NullArgument(condition, "条件が必要です");
            Assertion.Argument(pipelineQueueCount >= 1, "キューサイズは1以上である必要があります");

            // パイプライン実行する場合、ProcessItemsメソッドを使用するため、キャッシュは全く参照しない（出来ない）。
            System.Diagnostics.Trace.WriteLine(
                string.Format(
                    "QueryItemsPipelined: Iteration start, ThreadID={0}, Condition=\"{1}\"",
                    Thread.CurrentThread.ManagedThreadId,
                    condition.ToString().Replace("\r", " ").Replace("\n", " ")));

            var sw = new System.Diagnostics.Stopwatch();
            sw.Start();

            try
            {
                using (var context = new PipelinedIteratorContext<T>(
                    preBoundFactory,
                    condition,
                    meshType,
                    pipelineQueueCount))
                {
                    using (var enumerator = context.Consuming.GetEnumerator())
                    {
                        while (true)
                        {
                            bool available = false;
                            try
                            {
                                available = enumerator.MoveNext();
                            }
                            catch (OperationCanceledException)
                            {
                            }

                            if (available == false)
                            {
                                break;
                            }

                            foreach (var result in enumerator.Current)
                            {
                                yield return result;
                            }
                        }
                    }
                }
            }
            finally
            {
                sw.Stop();

                System.Diagnostics.Trace.WriteLine(
                    string.Format(
                        "QueryItemsPipelined: Iteration finished, ThreadID={0}, Elapsed={1}",
                        Thread.CurrentThread.ManagedThreadId,
                        sw.Elapsed));
            }
        }
        #endregion

        #region PipelinedIteratorContext
        /// <summary>
        /// パイプラインコンテキストクラスです。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        private sealed class PipelinedIteratorContext<T> : IDisposable
            where T : CREO.DataModel.GeoItem
        {
            #region Fields
            /// <summary>
            /// フラグメントサイズ
            /// </summary>
            private static readonly int FRAGMENT_SIZE = 2000;

            /// <summary>
            /// メッシュタイプ
            /// </summary>
            private readonly int? _meshType;

            /// <summary>
            /// マスター検索条件
            /// </summary>
            private readonly CREO.DS.QueryItemsCondition _masterCondition;

            /// <summary>
            /// 取得側スレッドID
            /// </summary>
            private readonly int _consumingThreadID;

            /// <summary>
            /// スレッド
            /// </summary>
            private Thread _thread;

            /// <summary>
            /// キュー
            /// </summary>
            private BlockingCollection<List<T>> _queue;

            /// <summary>
            /// 例外
            /// </summary>
            private Exception _ex;
            #endregion

            #region Constructors
            /// <summary>
            /// コンストラクタです。
            /// </summary>
            /// <param name="dataService">データサービス</param>
            /// <param name="condition">QueryItemsConditionのインスタンス</param>
            /// <param name="meshType">メッシュタイプ</param>
            /// <param name="queueCount">キューサイズ</param>
            public PipelinedIteratorContext(
                CREO.DS.DataService dataService,
                CREO.DS.QueryItemsCondition condition,
                int? meshType,
                int queueCount)
            {
                Assertion.Condition(dataService != null);
                Assertion.Condition(condition != null);
                Assertion.Condition(queueCount >= 1);

                this._masterCondition = condition;
                this._meshType = meshType;

                this._consumingThreadID = Thread.CurrentThread.ManagedThreadId;

                this._queue = new BlockingCollection<List<T>>(
                    (queueCount + FRAGMENT_SIZE) / FRAGMENT_SIZE);

                this._thread = new Thread(this.ThreadEntryByDataService);
                this._thread.Name = string.Format("PipelinedIterator: ConsumingThreadID={0}", this._consumingThreadID);
                this._thread.Start(dataService);
            }

            /// <summary>
            /// コンストラクタです。
            /// </summary>
            /// <param name="preBoundFactory">データサービスファクトリ</param>
            /// <param name="condition">QueryItemsConditionのインスタンス</param>
            /// <param name="meshType">メッシュタイプ</param>
            /// <param name="queueCount">キューサイズ</param>
            public PipelinedIteratorContext(
                IPreBoundDataServiceFactory preBoundFactory,
                CREO.DS.QueryItemsCondition condition,
                int? meshType,
                int queueCount)
            {
                Assertion.Condition(preBoundFactory != null);
                Assertion.Condition(condition != null);
                Assertion.Condition(queueCount >= 1);

                this._masterCondition = condition;
                this._meshType = meshType;

                this._consumingThreadID = Thread.CurrentThread.ManagedThreadId;

                this._queue = new BlockingCollection<List<T>>(
                    ((queueCount + FRAGMENT_SIZE) / FRAGMENT_SIZE) + Environment.ProcessorCount);

                this._thread = new Thread(this.ThreadEntryByPreBoundFactory);
                this._thread.Name = string.Format("PipelinedIterator: ConsumingThreadID={0}", this._consumingThreadID);
                this._thread.Start(preBoundFactory);
            }
            #endregion

            #region Consuming
            /// <summary>
            /// コンシューマー列挙子を取得します。
            /// </summary>
            public IEnumerable<List<T>> Consuming
            {
                get
                {
                    return this._queue.GetConsumingEnumerable();
                }
            }
            #endregion

            #region Dispose
            /// <summary>
            /// Disposeメソッドです。
            /// </summary>
            public void Dispose()
            {
                if (this._queue != null)
                {
                    try
                    {
                        this._queue.CompleteAdding();
                    }
                    catch
                    {
                    }
                }

                if (this._thread != null)
                {
                    this._thread.Join();

                    this._thread = null;
                }

                if (this._queue != null)
                {
                    this._queue.Dispose();
                    this._queue = null;
                }

                if (this._ex != null)
                {
                    var ex = this._ex;
                    this._ex = null;

                    if ((ex is TargetInvocationException) || (ex is AggregateException))
                    {
                        throw ex;
                    }

                    throw new TargetInvocationException(ex);
                }
            }
            #endregion

            #region Execute
            /// <summary>
            /// クエリを実行します。
            /// </summary>
            /// <param name="executeAction">実際にクエリを実行するデリゲート</param>
            private void Execute(Action<bool> executeAction)
            {
                Assertion.Condition(executeAction != null);
                Assertion.Condition(this._masterCondition != null);
                Assertion.Condition(this._queue != null);
                Assertion.Condition(this._ex == null);

                // 検索条件が指定されていない（タイプと詳細検索条件は許容する）
                var splittedAreaIteration = false;

                // IDs:OIDが指定されていない
                // Polygon:範囲が指定されていない
                // MultiPolygon:範囲が指定されていない
                // ConditionExpression:QueryExpressionが指定されていない
                // QueryExpression:QueryExpressionが指定されていない
                // QueryItemsPostProcess:QueryItemsPostProcessが指定されていない
                // RelationExpression:RelationExpressionが指定されていない
                if ((this._meshType.HasValue == true) &&
                    (this._masterCondition.IDs.Count == 0) &&
                    (this._masterCondition.Polygon.Count == 0) &&
                    (this._masterCondition.MultiPolygon.Count == 0) &&
                    (this._masterCondition.ConditionExpression == null) &&
                    (this._masterCondition.QueryExpression == null) &&
                    (this._masterCondition.QueryItemsPostProcess == null) &&
                    (this._masterCondition.RelationExpression == null))
                {
                    // SItemBaseのみを含んでいれば
                    var dataModelManager = CREO.DS.DataModelManager.Current;

                    var sItemBasedCount =
                        (from contentID in this._masterCondition.TypeIDs
                         where
                            typeof(CREO.DataModel.SItemBase).IsAssignableFrom(
                                dataModelManager.CreateDataModel(contentID).GetType()) == true
                         select contentID).Count();

                    // エリア分割する
                    splittedAreaIteration = sItemBasedCount == this._masterCondition.TypeIDs.Count;
                }

                System.Diagnostics.Trace.WriteLine(
                    string.Format(
                        "PipelinedIterator: Iteration start, ThreadID={0}, ConsumingThreadID={1}, Condition=\"{2}\"",
                        Thread.CurrentThread.ManagedThreadId,
                        this._consumingThreadID,
                        this._masterCondition.ToString().Replace("\r", " ").Replace("\n", " ")));

                var sw = new System.Diagnostics.Stopwatch();
                sw.Start();

                try
                {
                    try
                    {
                        executeAction(splittedAreaIteration);
                    }
                    catch (Exception ex)
                    {
                        Assertion.Condition(this._ex == null);
                        this._ex = ex;
                    }
                }
                finally
                {
                    Assertion.Condition(this._queue != null);

                    try
                    {
                        this._queue.CompleteAdding();
                    }
                    catch
                    {
                    }

                    sw.Stop();

                    System.Diagnostics.Trace.WriteLine(
                        string.Format(
                            "PipelinedIterator: Iteration finished, ThreadID={0}, ConsumingThreadID={1}, Elapsed={2}",
                            Thread.CurrentThread.ManagedThreadId,
                            this._consumingThreadID,
                            sw.Elapsed));
                }
            }
            #endregion

            #region CreateLocalAreaCondition
            /// <summary>
            /// 指定されたエリアで検索を実行する検索条件を生成します。
            /// </summary>
            /// <param name="localArea">エリア範囲を示す配列</param>
            /// <returns>検索条件</returns>
            private CREO.DS.QueryItemsCondition CreateLocalAreaCondition(
                FW.TMIGeometry.Coordinate[] localArea)
            {
                Assertion.Condition(localArea != null);
                Assertion.Condition(localArea.Length == 5);

                var localCondition = new CREO.DS.QueryItemsCondition();

                localCondition.ConditionExpression = this._masterCondition.ConditionExpression;
                localCondition.IDs = this._masterCondition.IDs;
                localCondition.QueryExpression = this._masterCondition.QueryExpression;
                localCondition.QueryItemsPostProcess = this._masterCondition.QueryItemsPostProcess;
                localCondition.RelationExpression = this._masterCondition.RelationExpression;
                localCondition.TypeIDs = this._masterCondition.TypeIDs;
                ////localCondition.Workgroups = this._masterCondition.Workgroups;

                localCondition.Polygon = localArea.ToList();

                return localCondition;
            }
            #endregion

            #region ThreadEntryByDataService
            /// <summary>
            /// スレッドのエントリポイントです。
            /// </summary>
            /// <param name="argument">引数（データサービス）</param>
            private void ThreadEntryByDataService(object argument)
            {
                Assertion.Condition(argument is CREO.DS.DataService);

                var dataService = (CREO.DS.DataService)argument;

                this.Execute(
                    splittedAreaIteration =>
                    {
                        if (splittedAreaIteration == true)
                        {
                            var sink = new DataConsumerSink<T>(this._queue, FRAGMENT_SIZE, true);
                            var areas = SplitAreaInformation.GetSplittedAreas(this._meshType.Value);
                            for (var index = 0; index < areas.Length; index++)
                            {
                                var localCondition = this.CreateLocalAreaCondition(areas[index]);
                                var totalCounts = sink.Execute(dataService, localCondition);

                                Trace.WriteLine(
                                    string.Format(
                                        "ThreadEntryByDataService: SplitArea: [{0}/{1}], MeshType={2}, Results={3}, {4}",
                                        index + 1,
                                        areas.Length,
                                        this._meshType.Value,
                                        totalCounts,
                                        areas[index].ToMultiPolygon()));
                            }
                        }
                        else
                        {
                            var sink = new DataConsumerSink<T>(this._queue, FRAGMENT_SIZE, false);
                            sink.Execute(dataService, this._masterCondition);
                        }
                    });
            }
            #endregion

            #region ThreadEntryByPreBoundFactory
            /// <summary>
            /// スレッドのエントリポイントです。
            /// </summary>
            /// <param name="argument">引数（事前バインドされたデータサービスファクトリ）</param>
            private void ThreadEntryByPreBoundFactory(object argument)
            {
                Assertion.Condition(argument is IPreBoundDataServiceFactory);

                var preBoundFactory = (IPreBoundDataServiceFactory)argument;

                this.Execute(
                    splittedAreaIteration =>
                    {
                        if (splittedAreaIteration == true)
                        {
                            var sink = new DataConsumerSink<T>(this._queue, FRAGMENT_SIZE, true);
                            var areas = SplitAreaInformation.GetSplittedAreas(this._meshType.Value);
                            for (var index = 0; index < areas.Length; index++)
                            {
                                //// TODO: DataServiceのuseCacheが廃止された為、GetDataServiceのパラメータも削除する。
                                using (var dataService = preBoundFactory.GetDataService(false))
                                {
                                    var localCondition = this.CreateLocalAreaCondition(areas[index]);
                                    var totalCounts = sink.Execute(dataService, localCondition);

                                    Trace.WriteLine(
                                        string.Format(
                                            "ThreadEntryByPreBoundFactory: SplitArea: [{0}/{1}], MeshType={2}, Results={3}, {4}",
                                            index + 1,
                                            areas.Length,
                                            this._meshType.Value,
                                            totalCounts,
                                            areas[index].ToMultiPolygon()));
                                }
                            }
                        }
                        else
                        {
                            //// TODO: DataServiceのuseCacheが廃止された為、GetDataServiceのパラメータも削除する。
                            using (var dataService = preBoundFactory.GetDataService(true))
                            {
                                var sink = new DataConsumerSink<T>(this._queue, FRAGMENT_SIZE, false);
                                sink.Execute(dataService, this._masterCondition);
                            }
                        }
                    });
            }
            #endregion
        }
        #endregion

        #region DataConsumerSink
        /// <summary>
        /// IDataConsumerインターフェイスを実装するシンククラスです。
        /// </summary>
        /// <typeparam name="T">要素の型</typeparam>
        /// <remarks>データサービスで検索を実行し、結果の収集を行います。</remarks>
        private sealed class DataConsumerSink<T> : CREO.DS.IDataConsumer
            where T : CREO.DataModel.GeoItem
        {
            #region Fields
            /// <summary>
            /// フラグメントサイズ
            /// </summary>
            private readonly int _fragmentSize;

            /// <summary>
            /// キュー
            /// </summary>
            private readonly BlockingCollection<List<T>> _queue;

            /// <summary>
            /// DISTINCT用辞書
            /// </summary>
            private readonly HashSet<ulong> _distinct;

            /// <summary>
            /// 現在のリスト
            /// </summary>
            private List<T> _current;

            /// <summary>
            /// レコード数
            /// </summary>
            private ulong _totalCounts;
            #endregion

            #region Constructors
            /// <summary>
            /// コンストラクタです。
            /// </summary>
            /// <param name="queue">格納先のキュー</param>
            /// <param name="fragmentSize">フラグメントサイズ</param>
            /// <param name="isDistinct">DISTINCTするかどうか</param>
            public DataConsumerSink(BlockingCollection<List<T>> queue, int fragmentSize, bool isDistinct)
            {
                Assertion.Condition(queue != null);
                Assertion.Condition(fragmentSize >= 1);

                this._queue = queue;
                this._fragmentSize = fragmentSize;
                this._distinct = isDistinct ? new HashSet<ulong>() : null;
            }
            #endregion

            #region IDataConsumer.ProcessItem
            /// <summary>
            /// コールバックメソッド
            /// </summary>
            /// <param name="geoItem">収集したGeoItem</param>
            void CREO.DS.IDataConsumer.ProcessItem(CREO.DataModel.GeoItem geoItem)
            {
                Assertion.Condition(geoItem != null);

                Assertion.Condition(this._queue != null);
                Assertion.Condition(this._current != null);

                if (this._distinct != null)
                {
                    if (this._distinct.Contains(geoItem.OID) == true)
                    {
                        return;
                    }

                    this._distinct.Add(geoItem.OID);
                }

                // 追加
                this._current.Add((T)geoItem);
                this._totalCounts++;

                // フラグメントサイズに達したら
                if (this._current.Count >= this._fragmentSize)
                {
                    // キューに転送
                    this._queue.Add(this._current);

                    // 新しいListを用意
                    this._current = new List<T>(this._fragmentSize);
                }
            }
            #endregion

            #region Execute
            /// <summary>
            /// データサービスにクエリを発行し、結果を収集します。
            /// </summary>
            /// <param name="dataService">データサービス</param>
            /// <param name="condition">検索条件</param>
            /// <returns>件数</returns>
            public ulong Execute(
                CREO.DS.DataService dataService,
                CREO.DS.QueryItemsCondition condition)
            {
                Assertion.Condition(dataService != null);
                Assertion.Condition(condition != null);

                Assertion.Condition(this._current == null);
                Assertion.Condition(this._totalCounts == 0);

                ulong totalCounts = 0;

                System.Diagnostics.Trace.WriteLine(
                    string.Format(
                        "DataConsumerSink: Execute start, ThreadID={0}, Condition=\"{1}\"",
                        Thread.CurrentThread.ManagedThreadId,
                        condition.ToString().Replace("\r", " ").Replace("\n", " ")));

                var sw = new System.Diagnostics.Stopwatch();
                sw.Start();

                try
                {
                    this._current = new List<T>(this._fragmentSize);

                    var consumers = new List<CREO.DS.IDataConsumer>();
                    consumers.Add(this);

                    // パイプライン実行する場合、ProcessItemsメソッドを使用するため、キャッシュは全く参照しない（出来ない）。
                    dataService.ProcessItems(condition, consumers);

                    // 最後のリストをキューに送出
                    if (this._current.Count >= 1)
                    {
                        this._queue.Add(this._current);
                    }
                }
                finally
                {
                    sw.Stop();

                    System.Diagnostics.Trace.WriteLine(
                        string.Format(
                            "DataConsumerSink: Execute finished, ThreadID={0}, Elapsed={1}, TotalCounts={2}",
                            Thread.CurrentThread.ManagedThreadId,
                            sw.Elapsed,
                            this._totalCounts));
                    totalCounts = this._totalCounts;

                    this._current = null;
                    this._totalCounts = 0;
                }

                return totalCounts;
            }

            /// <summary>
            /// データサービスにクエリを発行し、結果を収集します。
            /// </summary>
            /// <param name="dataService">データサービス</param>
            /// <param name="condition">検索条件</param>
            /// <returns>件数</returns>
            public ulong Execute(
                IPreBoundDataService dataService,
                CREO.DS.QueryItemsCondition condition)
            {
                Assertion.Condition(dataService != null);
                Assertion.Condition(condition != null);

                Assertion.Condition(this._current == null);
                Assertion.Condition(this._totalCounts == 0);

                ulong totalCounts = 0;

                System.Diagnostics.Trace.WriteLine(
                    string.Format(
                        "DataConsumerSink: Execute start, ThreadID={0}, Condition=\"{1}\"",
                        Thread.CurrentThread.ManagedThreadId,
                        condition.ToString().Replace("\r", " ").Replace("\n", " ")));

                var sw = new System.Diagnostics.Stopwatch();
                sw.Start();

                try
                {
                    this._current = new List<T>(this._fragmentSize);

                    var consumers = new List<CREO.DS.IDataConsumer>();
                    consumers.Add(this);

                    // パイプライン実行する場合、ProcessItemsメソッドを使用するため、キャッシュは全く参照しない（出来ない）。
                    dataService.ProcessItems(condition, consumers);

                    // 最後のリストをキューに送出
                    if (this._current.Count >= 1)
                    {
                        this._queue.Add(this._current);
                    }
                }
                finally
                {
                    sw.Stop();

                    System.Diagnostics.Trace.WriteLine(
                        string.Format(
                            "DataConsumerSink: Execute finished, ThreadID={0}, Elapsed={1}, TotalCounts={2}",
                            Thread.CurrentThread.ManagedThreadId,
                            sw.Elapsed,
                            this._totalCounts));
                    totalCounts = this._totalCounts;

                    this._current = null;
                    this._totalCounts = 0;
                }

                return totalCounts;
            }
            #endregion
        }
        #endregion

        #region SplitAreaInformation
        /// <summary>
        /// 全国探索の場合に、検索範囲を分割するためのポリゴン群を生成して保持するクラスです。
        /// </summary>
        private sealed class SplitAreaInformation
        {
            #region Fields
            /// <summary>
            /// 分割ポリゴンサイズ（経度）
            /// </summary>
            private static readonly long LONGITUDE_DIVIDER = 1L * 60L * 60L * 1024L;    // TODO:1度

            /// <summary>
            /// 分割ポリゴンサイズ（緯度）
            /// </summary>
            private static readonly long LATITUDE_DIVIDER = 1L * 40L * 60L * 1024L;     // TODO:40分

            /// <summary>
            /// 分割ポリゴンのリスト
            /// </summary>
            private static readonly Dictionary<int, SplitAreaInformation> SPLIT_AREA_INFORMATIONS =
                new Dictionary<int, SplitAreaInformation>();

            /// <summary>
            /// 分割ポリゴン群
            /// </summary>
            public readonly CREO.FW.TMIGeometry.Coordinate[][] _splittedAreas;
            #endregion

            #region Constructors
            /// <summary>
            /// コンストラクタです。
            /// </summary>
            /// <param name="meshType">メッシュタイプコード</param>
            /// <param name="longitudeDivider">分割ポリゴンサイズ（経度数）</param>
            /// <param name="latitudeDivider">分割ポリゴンサイズ（緯度数）</param>
            private SplitAreaInformation(int meshType, long longitudeDivider, long latitudeDivider)
            {
#if true
                // 検証する時間がないので、全領域の2次メッシュ分割だけで実行する（件数は多くなる）
                _splittedAreas =
                    (from meshCodeString in
                         CREO.FW.Utilities.MeshCodeUtility.GetMeshCodeSet(meshType, CoordinateExtension.CreateRectangle()).AsParallel()
                     select
                        CREO.FW.Utilities.MeshCodeUtility.GetAreaCoordinateSet(meshType, meshCodeString).ToPolygon().ToArray()).ToArray();
#else
                // ステップ1:
                // 定義済のすべて（全国）のメッシュコードリストから、単一のマルチポリゴンを生成する
                // MeshCodeUtilityは、現在のところ2次メッシュ単位で、1次メッシュのリストから計算で生成している。
                // 一応、2次メッシュ単位ということは仮定せず、返された座標だけで処理を行う。

                //           +--------++--------+
                //           |        ||        |
                //           |        ||        |
                //           +--------++--------+
                // +--------++--------+                   +--------+
                // |        ||        |                   |        |
                // |        ||        |                   |        |
                // +--------++--------+                   +--------+
                // +--------++--------++--------+
                // |        ||        ||        |
                // |        ||        ||        |
                // +--------++--------++--------+
                //
                //                         ↓
                //
                //           +------------------+
                //           |                  |
                //           |                  |
                // +---------+        +---------+         +--------+
                // |                  |                   |        |
                // |                  |                   |        |
                // |                  +---------+         +--------+
                // |                            |
                // |                            |
                // +----------------------------+

                var availableAreas =
                    (from meshCodeString in
                         CREO.FW.Utilities.MeshCodeUtility.GetMeshCodeSet(meshType, CoordinateExtension.CreateRectangle()).
                         AsParallel()
                     select CREO.FW.Utilities.MeshCodeUtility.GetAreaCoordinateSet(meshType, meshCodeString).ToMultiPolygon()).
                     UnionAll().
                     MakeValid();

                // ステップ2:
                // すべてのマルチポリゴンの外周を囲む長方形を取得する

                //           +------------------+
                //           |                  |
                //           |                  |
                // +---------+        +---------+         +--------+
                // |                  |                   |        |
                // |                  |                   |        |
                // |                  +---------+         +--------+
                // |                            |
                // |                            |
                // +----------------------------+
                //
                //                         ↓
                //
                // +-----------------------------------------------+
                // |                                               |
                // |                                               |
                // |                                               |
                // |                                               |
                // |                                               |
                // |                                               |
                // |                                               |
                // |                                               |
                // +-----------------------------------------------+

                var envelopePolygon = availableAreas.Envelope();
                var envelopeRect = envelopePolygon.ToCoordinateRect();

                // ステップ3:
                // ステップ2の長方形をDividerで分割し、それぞれが元のポリゴン（ステップ1）に重なっているかどうかを判定する。
                // 重なっていれば、Divider長方形を分割ポリゴンとして返す。
                // （判定を外れた範囲は、分割ポリゴンに追加されないので、無駄な検索を省く事が出来る。
                // マルチポリゴンとIntersectionした方が正確だが、形状が複雑になって、クエリと範囲内判定が重くなるので、Divider長方形を使う）

                // Longitude Divider     localAreaにavailableAreasが含まれているかどうかを確認。
                // |<------------->|     含まれていればlocalAreaを分割ポリゴンとする。
                //                        /
                // +---------------+-----/---------+---------------+ ---
                // |         |     |////////////|  |               |  ^
                // |         |     |////////////|  |               |  | Latitude Divider
                // |---------+     |//+---------+  |      +--------|  |
                // |               |//|            |      |        |  v
                // +---------------+---------------+---------------+ ---
                // |               |  +---------+  |      +--------|
                // |               |            |  |               |
                // |               |            |  |               |
                // +---------------+---------------+---------------+

                var splittedAreas =
                    // 分割ポリゴンサイズでエリアを列挙する
                    from latitude in
                        LongRange(envelopeRect.BottomLeft.Latitude, envelopeRect.TopRight.Latitude, latitudeDivider).
                        AsParallel()
                    from longitude in
                        LongRange(envelopeRect.BottomLeft.Longitude, envelopeRect.TopRight.Longitude, longitudeDivider)

                    let localArea = CoordinateExtension.CreateRectangle(
                        latitude.Item1, longitude.Item1, latitude.Item2, longitude.Item2).
                        ToMultiPolygon()

                    // 分割ポリゴンが、マルチポリゴンと（全部又は一部）重なっていれば
                    where availableAreas.Intersects(localArea) == true

                    // 分割ポリゴン（四角ポリゴン）を固定化して返す
                    select localArea[0].ToCoordinateCollection().ToArray();

                // 固定化
                _splittedAreas = splittedAreas.ToArray();
#endif
            }
            #endregion

            #region GetSplittedAreas
            /// <summary>
            /// 分割ポリゴンの列挙子を取得します。
            /// </summary>
            /// <param name="meshType">メッシュタイプコード</param>
            /// <returns>分割ポリゴンの列挙子</returns>
            public static CREO.FW.TMIGeometry.Coordinate[][] GetSplittedAreas(int meshType)
            {
                lock (SPLIT_AREA_INFORMATIONS)
                {
                    SplitAreaInformation result;
                    if (SPLIT_AREA_INFORMATIONS.TryGetValue(meshType, out result) == false)
                    {
                        result = new SplitAreaInformation(meshType, LONGITUDE_DIVIDER, LATITUDE_DIVIDER);
                        SPLIT_AREA_INFORMATIONS.Add(meshType, result);

                        Trace.WriteLine(
                            string.Format(
                                "SplitAreaInformation: SplitArea calculated: MeshType={0}, Count={1}",
                                meshType,
                                result._splittedAreas.Length));
                    }

                    return result._splittedAreas;
                }
            }
            #endregion

            #region LongRange
            /// <summary>
            /// 指定された開始・終了値をステップ増分で列挙します。
            /// </summary>
            /// <param name="begin">開始値</param>
            /// <param name="end">終了値</param>
            /// <param name="step">ステップ</param>
            /// <returns>小・大の順で値が格納された列挙子</returns>
            private static IEnumerable<Tuple<long, long>> LongRange(long begin, long end, long step)
            {
                long current = begin;
                if (begin < end)
                {
                    while (current < end)
                    {
                        yield return Tuple.Create(current, current + step - 1);
                        current += step;
                    }
                }
                else
                {
                    while (current > end)
                    {
                        yield return Tuple.Create(current - step + 1, current);
                        current -= step;
                    }
                }
            }
            #endregion
        }
        #endregion
    }
}

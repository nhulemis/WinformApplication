﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.12.26 TMI K.Matsui

using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.Serialization;
using System.Security;
using CREO.Fluere.Common.Diagnostics;
using Microsoft.SqlServer.Types;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// SqlGeometryをラップし、格納されている情報の取り扱いを容易にするラップクラスです。
    /// </summary>
    /// <remarks>ICollectionを実装し、LINQクエリを高速化します。</remarks>
    [Serializable]
    internal sealed class Ring : GeometryBase, IRing, ICollection<IPoint>, ICollection
    {
        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="sqlGeometry">SqlGeometry</param>
        public Ring(SqlGeometry sqlGeometry)
            : base(sqlGeometry)
        {
#if DEBUG
            var type = this.GeometryStructureType;
            Assertion.Condition((type == GeometryStructureTypes.Empty) || (type == GeometryStructureTypes.Single) || (type == GeometryStructureTypes.Point));
#endif
        }

        /// <summary>
        /// 逆シリアル化コンストラクタです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecurityCritical]
        private Ring(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
        }
        #endregion

        #region Count
        /// <summary>
        /// 内包するポイント数を取得します。
        /// </summary>
        public int Count
        {
            get
            {
                var type = this.GeometryStructureType;

                if (type == GeometryStructureTypes.Empty)
                {
                    return 0;
                }

                return this.GEOMETRY.STNumPoints().Value;
            }
        }
        #endregion

        #region RingLength
        /// <summary>
        /// リング長を取得します。
        /// </summary>
        public double RingLength
        {
            get
            {
                return this.GEOMETRY.STLength().Value;
            }
        }
        #endregion

        #region IsClosed
        /// <summary>
        /// このインスタンスが閉形状かどうかを取得します。
        /// </summary>
        /// <remarks>trueの場合は閉形状です。falseの場合はポリライン・マルチポイント・ポイント・空インスタンスの可能性があります。</remarks>
        public bool IsClosed
        {
            get
            {
                return this.GEOMETRY.STIsClosed().Value;
            }
        }
        #endregion

        #region Indexer
        /// <summary>
        /// インデックスを指定して、ポイントを取得します。
        /// </summary>
        /// <param name="index">インデックス</param>
        /// <returns>ポイント</returns>
        public IPoint this[int index]
        {
            get
            {
                var type = this.GeometryStructureType;

                Assertion.Argument<ArgumentOutOfRangeException>(
                    type != GeometryStructureTypes.Empty,
                    "インスタンスは空です");

                if (type == GeometryStructureTypes.Single)
                {
                    Assertion.Argument<ArgumentOutOfRangeException>(
                        index < this.GEOMETRY.STNumPoints().Value,
                        "インデックスは範囲外です");

                    return new Point(this.GEOMETRY.STPointN(index + 1));
                }

                Assertion.Argument<ArgumentOutOfRangeException>(
                    index == 0,
                    "インデックスは範囲外です");

                return new Point(this.GEOMETRY);
            }
        }
        #endregion

        #region StartPoint
        /// <summary>
        /// 先端位置を取得します。
        /// </summary>
        /// <returns>終端位置</returns>
        public IPoint StartPoint()
        {
            return new Point(this.GEOMETRY.STStartPoint());
        }
        #endregion

        #region EndPoint
        /// <summary>
        /// 終端位置を取得します。
        /// </summary>
        /// <returns>終端位置</returns>
        public IPoint EndPoint()
        {
            return new Point(this.GEOMETRY.STEndPoint());
        }
        #endregion

        #region ToCoordinateCollection
        /// <summary>
        /// Coordinateの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        public IEnumerable<CREO.FW.TMIGeometry.Coordinate> ToCoordinateCollection()
        {
            return this.Select(point => point.ToCoordinate());
        }
        #endregion

        #region ToCoordinateDCollection
        /// <summary>
        /// CoordinateDの列挙子に変換します。
        /// </summary>
        /// <returns>列挙子</returns>
        public IEnumerable<CREO.FW.TMIGeometry.CoordinateD> ToCoordinateDCollection()
        {
            return this.Select(point => point.ToCoordinateD());
        }
        #endregion

        #region ToCoordinateRect
        /// <summary>
        /// CoordinateRectに変換します。
        /// </summary>
        /// <returns>CoordinateRect</returns>
        /// <remarks>返却するCoordinateRectは、四角形でないポリゴンを表現出来ません。
        /// そのため、これらのポリゴンが含まれている場合、例外がスローされます。</remarks>
        public CREO.FW.TMIGeometry.CoordinateRect ToCoordinateRect()
        {
            Assertion.Require<InvalidOperationException>(this.IsEmpty == false, "インスタンスが空です");

            var xList =
                (from coordinate in this
                 orderby coordinate.X
                 select coordinate.X).Distinct().ToList();
            Assertion.Argument(xList.Count == 2, "四角ポリゴンのインスタンスが必要です");

            var yList =
                (from coordinate in this
                 orderby coordinate.Y
                 select coordinate.Y).Distinct().ToList();
            Assertion.Argument(yList.Count == 2, "四角ポリゴンのインスタンスが必要です");

            var rect = new CREO.FW.TMIGeometry.CoordinateRect();
            rect.BottomLeft.Longitude = (long)(xList[0] + 0.5);
            rect.BottomLeft.Latitude = (long)(yList[0] + 0.5);
            rect.TopRight.Longitude = (long)(xList[1] + 0.5);
            rect.TopRight.Latitude = (long)(yList[1] + 0.5);

            return rect;
        }
        #endregion

        #region Transform
        /// <summary>
        /// 指定したアフィン変換演算子を適用します。
        /// </summary>
        /// <param name="matrix">アフィン変換演算子を示す行列</param>
        /// <returns>形状</returns>
        public override IMultiPolygon TransformBy(System.Windows.Media.Matrix matrix)
        {
            // TODO: MultiLineString, LineString, MultiPoint
            var gb = new SqlGeometryBuilder();
            gb.SetSrid(GeometryBase.SRID);

            var points = this.Select(point => new System.Windows.Point(point.X, point.Y)).ToArray();
            if (points.Length >= 1)
            {
                matrix.Transform(points);

                bool foundPoint = false;
                for (var index = 0; index < points.Length; index++)
                {
                    if (foundPoint == false)
                    {
                        gb.BeginGeometry(OpenGisGeometryType.MultiPolygon);
                        gb.BeginGeometry(OpenGisGeometryType.Polygon);
                        gb.BeginFigure(points[0].X, points[0].Y, null, null);
                        foundPoint = true;
                    }
                    else
                    {
                        gb.AddLine(points[index].X, points[index].Y, null, null);
                    }
                }

                if (foundPoint == true)
                {
                    gb.EndFigure();
                    gb.EndGeometry();
                    gb.EndGeometry();
                }
            }

            return new MultiPolygon(gb.ConstructedGeometry);
        }
        #endregion

        #region GetEnumerator
        /// <summary>
        /// リングの列挙子を取得します。
        /// </summary>
        /// <returns>列挙子</returns>
        public IEnumerator<IPoint> GetEnumerator()
        {
            var type = this.GeometryStructureType;

            if (type == GeometryStructureTypes.Empty)
            {
                yield break;
            }

            if (type == GeometryStructureTypes.Single)
            {
                for (int index = 0, count = this.GEOMETRY.STNumPoints().Value; index < count; index++)
                {
                    yield return new Point(this.GEOMETRY.STPointN(index + 1));
                }

                yield break;
            }

            yield return new Point(this.GEOMETRY);
        }

        /// <summary>
        /// リングの列挙子を取得します。
        /// </summary>
        /// <returns>列挙子</returns>
        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }
        #endregion

        #region ICollection
        /// <summary>
        /// インスタンスを追加します。
        /// </summary>
        /// <param name="item">対象のインスタンス</param>
        /// <remarks>実装されていません。</remarks>
        void ICollection<IPoint>.Add(IPoint item)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// インスタンスが含まれているかどうかを確認します。
        /// </summary>
        /// <param name="item">対象のインスタンス</param>
        /// <returns>なし</returns>
        bool ICollection<IPoint>.Contains(IPoint item)
        {
            return this.Any(point => point.Equals(item));
        }

        /// <summary>
        /// 内容を配列にコピーします。
        /// </summary>
        /// <param name="array">配列</param>
        /// <param name="arrayIndex">インデックス</param>
        void ICollection<IPoint>.CopyTo(IPoint[] array, int arrayIndex)
        {
            var index = arrayIndex;
            foreach (var point in this)
            {
                array[index] = point;
                index++;
            }
        }

        /// <summary>
        /// 内容を配列にコピーします。
        /// </summary>
        /// <param name="array">配列</param>
        /// <param name="arrayIndex">インデックス</param>
        [EditorBrowsable(EditorBrowsableState.Never)]
        public override void CopyTo(Array array, int arrayIndex)
        {
            var realArray = (IPoint[])array;
            var index = arrayIndex;
            foreach (var point in this)
            {
                realArray[index] = point;
                index++;
            }
        }

        /// <summary>
        /// インスタンスを削除します。
        /// </summary>
        /// <param name="item">対象のインスタンス</param>
        /// <returns>なし</returns>
        /// <remarks>実装されていません。</remarks>
        bool ICollection<IPoint>.Remove(IPoint item)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}

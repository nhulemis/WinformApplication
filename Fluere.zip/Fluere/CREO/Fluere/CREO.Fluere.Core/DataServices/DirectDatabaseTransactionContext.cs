﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.11.01 TMI K.Matsui

using System;
using System.Data;
using CREO.Fluere.Common.Diagnostics;

namespace CREO.Fluere.Common.DataServices
{
    /// <summary>
    /// データベースへのダイレクトアクセスを実行するトランザクションコンテキストクラスです。
    /// </summary>
    internal sealed class DirectDatabaseTransactionContext
        : DirectDatabaseAccessor, IDirectDatabaseTransactionContext
    {
        #region Fields
        /// <summary>
        /// IDbTransaction stack
        /// </summary>
        private IDbTransaction _transaction;

        /// <summary>
        /// TransactionID
        /// </summary>
        private Guid _transactionID = Guid.NewGuid();
        #endregion

        #region Constructors
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="connection">データベース接続</param>
        /// <param name="transaction">データベーストランザクション</param>
        public DirectDatabaseTransactionContext(IDbConnection connection, IDbTransaction transaction)
            : base(connection)
        {
            Assertion.Condition(transaction != null);

            this._transaction = transaction;
        }
        #endregion

        #region Properties
        /// <summary>
        /// 現在のトランザクションオブジェクトを取得します。
        /// </summary>
        /// <remarks>トランザクションを開始していない場合はnullが返されます。</remarks>
        public IDbTransaction Transaction
        {
            get
            {
                return this._transaction;
            }
        }

        /// <summary>
        /// トランザクションに割り当てられたIDを取得します。
        /// </summary>
        public Guid TransactionID
        {
            get
            {
                return this._transactionID;
            }
        }
        #endregion

        #region Dispose()
        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        public override void Dispose()
        {
            if (this._transaction != null)
            {
                this._transaction.Dispose();
                this._transaction = null;
            }

            this._transactionID = Guid.Empty;

            base.Dispose();
        }
        #endregion

        #region Commit
        /// <summary>
        /// トランザクションをコミットします。
        /// </summary>
        public void Commit()
        {
            Assertion.Require(this._transaction != null, "トランザクションは開始していません");

            this._transaction.Commit();
            this._transaction.Dispose();
            this._transaction = null;
            this._transactionID = Guid.Empty;

            base.Dispose();
        }
        #endregion

        #region GetTransaction
        /// <summary>
        /// トランザクションオブジェクトを取得します。
        /// </summary>
        /// <returns>トランザクションオブジェクト</returns>
        protected override IDbTransaction GetTransaction()
        {
            return this._transaction;
        }
        #endregion
    }
}

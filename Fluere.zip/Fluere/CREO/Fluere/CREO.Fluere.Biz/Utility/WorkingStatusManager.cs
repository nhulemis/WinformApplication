﻿using System.Text;
using CREO.DataModel;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 作業ステータスを管理するクラス
    /// </summary>
    public class WorkingStatusManager
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        static WorkingStatusManager()
        {
            ClearWorkingDataKey();
        }

        /// <summary>
        /// コンストラクター
        /// </summary>
        private WorkingStatusManager()
        {
        }

        /// <summary>
        /// 現時点の作業対象のキー情報
        /// </summary>
        private static object WorkingDataKey { get; set; }

        /// <summary>
        /// 現時点の作業対象のキー情報
        /// </summary>
        private static int WorkingDataType { get; set; }

        /// <summary>
        /// 現時点の作業対象をクリアする
        /// </summary>
        public static void ClearWorkingDataKey()
        {
            WorkingDataKey = null;
            WorkingDataType = 0;
        }

        /// <summary>
        /// 現時点の作業対象を設定する
        /// </summary>
        /// <param name="keyOid">対象OID</param>
        public static void SetWorkingDataKeyByOid(ulong keyOid)
        {
            // 簡単に設定する（チェック・変換処理などを禁止）
            WorkingDataType = 1;
            WorkingDataKey = keyOid;
        }

        /// <summary>
        /// 現時点の作業対象を設定する
        /// </summary>
        /// <param name="geoItem">対象データモデル</param>
        public static void SetWorkingDataKeyByGeoItem(GeoItem geoItem)
        {
            // 簡単に設定する（チェック・変換処理などを禁止）
            WorkingDataType = 2;
            WorkingDataKey = geoItem;
        }

        /// <summary>
        /// 処理中データを出力する
        /// </summary>
        public static void ShowWorkingData()
        {
            if (WorkingDataType != 0)
            {
                StringBuilder outSB = new StringBuilder();

                // チェック・変換処理などを実施する
                switch (WorkingDataType)
                {
                    case 1:
                        outSB.AppendFormat("OID: {0}", WorkingDataKey);
                        break;
                    case 2:
                        if (WorkingDataKey != null)
                        {
                            GeoItem geoItem = (GeoItem)WorkingDataKey;
                            outSB.AppendFormat("OID:{0} Type:{1}:{2}",
                                geoItem.OIDString,
                                geoItem.EntityType,
                                geoItem.ContentID);
                        }

                        break;
                    default:
                        break;
                }

                LogUtility.WriteInfo("■処理中対象データ：{0}", outSB.ToString());
            }
        }
    }
}

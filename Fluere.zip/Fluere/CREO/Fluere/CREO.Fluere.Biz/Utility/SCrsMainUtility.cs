﻿using CREO.DataModel;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;
using CREO.FW.TMIGeometry;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 基幹交差点ユーティリティ
    /// </summary>
    public class SCrsMainUtility
    {
        #region 2次メッシュ矩形取得
        /// <summary>
        /// 2次メッシュ矩形取得
        /// </summary> 
        /// <param name="meshType">2次メッシュタイプ</param>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <returns>2次メッシュ矩形</returns>
        private static CoordinateRect GetMeshMatrix(ushort meshType, string meshCode)
        {
            CoordinateRect rect;

            // メッシュ矩形取得結果
            bool result;

            result = GISLib.GetCoordRectByMeshCode(meshType, meshCode, out rect);

            if (!result)
            {
                string message = string.Format("メッシュ矩形が取得できません。メッシュタイプ:{0} メッシュコード:{1}",
                    meshType,
                    meshCode);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            return rect;
        }
        #endregion

        #region 基幹交差点が2次メッシュ境界に接続するか判断
        /// <summary>
        /// 基幹交差点が2次メッシュ境界に接続するか判断
        /// </summary>
        /// <param name="crsMain">基幹交差点</param>
        /// <returns>TRUE：はい、FALSE：いいえ</returns>
        public static bool IsOnMeshBorder(SCrsMain crsMain)
        {
            // Modify By Ning.Cai 2014/03/03 エンハンス開発No.1071 Start
            #region Delete
            ////bool flag = false;
            ////
            ////if (crsMain != null &&
            ////    crsMain.Crs05GuideNoAry != null &&
            ////    crsMain.Crs05GuideNoAry.Count > 0)
            ////{
            ////    foreach (TmiCrsNo crsNo in crsMain.Crs05GuideNoAry)
            ////    {
            ////        if (crsNo.MeshNo.HasValue)
            ////        {
            ////            string meshCode = crsNo.MeshNo.Value.ToString();

            ////            CoordinateRect rect = GetMeshMatrix(8102, meshCode);

            ////            if (crsMain.Geometry.Latitude == rect.BottomLeft.Latitude
            ////                || crsMain.Geometry.Latitude == rect.TopRight.Latitude
            ////                || crsMain.Geometry.Longitude == rect.BottomLeft.Longitude
            ////                || crsMain.Geometry.Longitude == rect.TopRight.Longitude)
            ////            {
            ////                flag = true;
            ////                break;
            ////            }
            ////        }
            ////    }
            ////}

            ////return flag;
            #endregion
            return crsMain != null && crsMain.Crs05GuideNoAry != null && crsMain.Crs05GuideNoAry.Count > 1;

            // Modify By Ning.Cai 2014/03/03 エンハンス開発No.1071 End
        }
        #endregion
    }
}

﻿using System.Collections.Generic;
using System.Xml.Linq;
using CREO.BusiComm.ToDoFile;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 共通部品CommToDoReadWriterクラスのラッパー
    /// </summary>
    public class CommToDoReadWrapper
    {
        /// <summary>
        /// ToDoファイルを読み取る
        /// </summary>
        /// <param name="filePath">ToDoファイル</param>
        /// <returns>CommToDoDataWrapperリスト</returns>
        public static List<CommToDoDataWrapper> ReadToDoFile(string filePath)
        {
            List<CommToDoDataWrapper> retList = new List<CommToDoDataWrapper>();

            using (CommToDoReadWriter target = new CommToDoReadWriter(filePath))
            {
                // データレコードを取得する
                foreach (XElement dataElement in target.GetDatas())
                {
                    CommToDoDataWrapper curData = new CommToDoDataWrapper();
                    foreach (XAttribute dataAttribute in dataElement.Attributes())
                    {
                        curData.SetFieldByName(dataAttribute.Name.LocalName,
                            dataAttribute.Value);
                    }

                    retList.Add(curData);
                }
            }

            return retList;
        }
    }
}

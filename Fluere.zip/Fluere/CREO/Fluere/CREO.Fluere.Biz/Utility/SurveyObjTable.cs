﻿// -----------------------------------------------------------------------
// <copyright file="UpdateSurveyObj.cs" company="Hewlett-Packard Company">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

namespace CREO.Fluere.Biz.Utility
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using CREO.Materia;

    /// <summary>
    /// 調査対象ステータスの更新
    /// </summary>
    public class SurveyObjTable
    {
        /// <summary>
        /// 調査対象データテーブル作成
        /// </summary>
        /// <returns>DataTable</returns>
        public static DataTable CreateSurveyObjTable()
        {
            DataTable dtSurveyObj = new DataTable();

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_ARTICLESOURCEID, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_DRAWINGSOURCEID, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_TRIGGERID, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_SELECTDIVISION, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_DUPLCONFDATA, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_REMARKS, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_DISPLAYITEM1, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_DISPLAYITEM2, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_OLDSURVEYOBJECTID, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_TODOOUTPUTFLAG, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_NEXTSURVEYDATE, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_SURVEYMEMO, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_CREATEDDATE, typeof(DateTime));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_CREATEUSERID, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE, typeof(DateTime));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID, typeof(string));

            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION, typeof(string));

            return dtSurveyObj;
        }
    }
}

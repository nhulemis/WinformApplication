﻿using System;
using System.Collections.Generic;
using System.Linq;
using CREO.DataModel;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.Utility
{
    #region 親子関係情報を格納するクラス
    /// <summary>
    /// 親子関係情報を格納するクラス
    /// </summary>
    public class ParentChildRelation
    {
        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        private ParentChildRelation()
        {
        }

        /// <summary>
        /// ParentChildRelationクラスの新しいインスタンスを生成する。
        /// </summary>
        /// <param name="paraOID">OID</param>
        public ParentChildRelation(ulong paraOID)
        {
            this.OID = paraOID;

            this.Inner = null;
            this.IsLoaded = false;
            this.IsChildLoaded = false;
            this.Childs = new List<ParentChildRelation>();
            this.Parent = null;
        }

        /// <summary>
        /// ParentChildRelationクラスの新しいインスタンスを生成する。
        /// </summary>
        /// <param name="paraTItemBase">TItemBaseデータモデルオブジェクト</param>
        public ParentChildRelation(TItemBase paraTItemBase)
            : this(paraTItemBase.OID)
        {
            this.ResetTItemBase(paraTItemBase);
        }
        #endregion

        /// <summary>
        /// 対象データとなるかどうかを判断する処理のデリゲート
        /// </summary>
        /// <param name="checkData">対象表実体データ</param>
        /// <returns>対象データとなるかどうか</returns>
        public delegate bool MatchDataFuncType(TItemBase checkData);

        #region プロパティ
        /// <summary>
        /// OID
        /// </summary>
        public ulong OID { get; private set; }

        /// <summary>
        /// 取りフラグ
        /// </summary>
        public bool IsLoaded { get; private set; }

        /// <summary>
        /// 表実体
        /// </summary>
        public TItemBase Inner { get; private set; }

        /// <summary>
        /// ネストレベル
        /// </summary>
        public byte NestLevel
        {
            get
            {
                if (Inner == null)
                {
                    throw new Exception(string.Format("対象データが見つかりません。{0}", OID));
                }

                return Inner.NestLevel;
            }
        }

        /// <summary>
        /// 子データ取りフラグ
        /// </summary>
        public bool IsChildLoaded { get; set; }

        /// <summary>
        /// 子関係情報
        /// </summary>
        public List<ParentChildRelation> Childs { get; private set; }

        /// <summary>
        /// 親関係情報
        /// </summary>
        public ParentChildRelation Parent { get; private set; }
        #endregion

        #region パブリック・メソッド
        /// <summary>
        /// 子対象を追加する
        /// </summary>
        /// <param name="child">子対象</param>
        public void AddChild(ParentChildRelation child)
        {
            child.SetParent(this);
            this.Childs.Add(child);
        }

        /// <summary>
        /// 親対象を設定する
        /// </summary>
        /// <param name="parent">親対象</param>
        public void SetParent(ParentChildRelation parent)
        {
            this.Parent = parent;
        }

        /// <summary>
        /// 表実体を再設定する
        /// </summary>
        /// <param name="paraTItemBase">TItemBaseデータモデルオブジェクト</param>
        public void ResetTItemBase(TItemBase paraTItemBase)
        {
            this.Inner = paraTItemBase;
            this.IsLoaded = true;
        }

        /// <summary>
        /// 条件を指定し、子孫データを取得する
        /// </summary>
        /// <param name="dataList">データリスト</param>
        /// <param name="maxNestLevel">最大ネストレベル</param>
        /// <param name="matchDataFunc">対象データとなるかどうかを判断する関数</param>
        public void GetAllChild(ref List<TItemBase> dataList,
            byte maxNestLevel,
            MatchDataFuncType matchDataFunc = null)
        {
            if (maxNestLevel >= this.NestLevel)
            {
                if (matchDataFunc == null || matchDataFunc(this.Inner))
                {
                    dataList.Add(this.Inner);
                }

                if (maxNestLevel > this.NestLevel)
                {
                    foreach (ParentChildRelation child in this.Childs)
                    {
                        child.GetAllChild(ref dataList, maxNestLevel, matchDataFunc);
                    }
                }
            }
        }

        /// <summary>
        /// 条件を指定し、子孫データを取得する
        /// </summary>
        /// <param name="dataList">データリスト</param>
        /// <param name="maxNestLevel">最大ネストレベル</param>
        /// <param name="matchDataFunc">対象データとなるかどうかを判断する関数</param>
        public void GetAllChild(ref List<ParentChildRelation> dataList,
            byte maxNestLevel,
            MatchDataFuncType matchDataFunc = null)
        {
            if (maxNestLevel >= this.NestLevel)
            {
                if (matchDataFunc == null || matchDataFunc(this.Inner))
                {
                    dataList.Add(this);
                }

                if (maxNestLevel > this.NestLevel)
                {
                    foreach (ParentChildRelation child in this.Childs)
                    {
                        child.GetAllChild(ref dataList, maxNestLevel, matchDataFunc);
                    }
                }
            }
        }

        /// <summary>
        /// 条件を指定し、祖先データを取得する
        /// </summary>
        /// <param name="dataList">データリスト</param>
        /// <param name="minNestLevel">最小ネストレベル</param>
        /// <param name="matchDataFunc">対象データとなるかどうかを判断する関数</param>
        public void GetAllParent(ref List<TItemBase> dataList,
            byte minNestLevel,
            MatchDataFuncType matchDataFunc = null)
        {
            if (minNestLevel <= this.NestLevel)
            {
                // 親優先
                if (minNestLevel < this.NestLevel)
                {
                    Parent.GetAllParent(ref dataList, minNestLevel, matchDataFunc);
                }

                if (matchDataFunc == null || matchDataFunc(this.Inner))
                {
                    dataList.Add(this.Inner);
                }
            }
        }

        /// <summary>
        /// 条件を指定し、祖先データを取得する
        /// </summary>
        /// <param name="dataList">データリスト</param>
        /// <param name="minNestLevel">最小ネストレベル</param>
        /// <param name="matchDataFunc">対象データとなるかどうかを判断する関数</param>
        public void GetAllParent(ref List<ParentChildRelation> dataList,
            byte minNestLevel,
            MatchDataFuncType matchDataFunc = null)
        {
            if (minNestLevel <= this.NestLevel)
            {
                // 親優先
                if (minNestLevel < this.NestLevel)
                {
                    Parent.GetAllParent(ref dataList, minNestLevel, matchDataFunc);
                }

                if (matchDataFunc == null || matchDataFunc(this.Inner))
                {
                    dataList.Add(this);
                }
            }
        }
        #endregion
    }
    #endregion

    #region 親子関係のラッパー
    /// <summary>
    /// <para>親子関係のラッパー</para>
    /// </summary>
    public abstract class DataParenthoodWrapper
    {
        /// <summary>
        /// 表実体のキャッシュデータ
        /// </summary>
        protected Dictionary<ulong, ParentChildRelation> _cacheDict = new Dictionary<ulong, ParentChildRelation>();

        /// <summary>
        /// 最上レベルの表実体の一覧
        /// </summary>
        protected List<ParentChildRelation> _topLevelList = new List<ParentChildRelation>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        protected DataParenthoodWrapper()
        {
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="innerDataServiceWrapper">データサービス</param>
        /// <param name="contentType">表実体のタイプ名</param>
        /// <param name="preloadNestLevel">先取りネストレベル</param>
        public DataParenthoodWrapper(DataServiceWrapper innerDataServiceWrapper, string contentType, byte preloadNestLevel)
        {
            this.InnerDataServiceWrapper = innerDataServiceWrapper;

            List<GeoItem> tempGeoItemList = this.InnerDataServiceWrapper.QueryTopLevelWithChildItems(contentType, preloadNestLevel);
            CacheSave(tempGeoItemList, preloadNestLevel);
        }

        /// <summary>
        /// データサービス
        /// </summary>
        public DataServiceWrapper InnerDataServiceWrapper { get; set; }

        /// <summary>
        /// 表実体の子孫を一括取得する
        /// </summary>
        /// <param name="oid">対象OID</param>
        /// <param name="maxNestLevel">最大ネストレベル</param>
        public void LoadChildItems(ulong oid, byte maxNestLevel)
        {
            List<GeoItem> tempGeoItemList = this.InnerDataServiceWrapper.QueryChildItems(oid, maxNestLevel);
            CacheSave(tempGeoItemList, maxNestLevel);
        }

        /// <summary>
        /// 表実体の祖先を一括取得する
        /// </summary>
        /// <param name="oid">対象OID</param>
        /// <param name="minNestLevel">最小ネストレベル</param>
        public void LoadParentItems(ulong oid, byte minNestLevel)
        {
            List<GeoItem> tempGeoItemList = this.InnerDataServiceWrapper.QueryParentItems(oid, minNestLevel);
            CacheSave(tempGeoItemList, 0);
        }

        /// <summary>
        /// 同一の親の表実体を取得する
        /// </summary>
        /// <param name="oid">対象表実体のOID</param>
        /// <returns>同一の親の表実体リスト</returns>
        public List<TItemBase> GetNeighborList(ulong oid)
        {
            List<TItemBase> retList = null;

            if (!this._cacheDict.ContainsKey(oid))
            {
                string message = string.Format("データが取得できません。OID:{0}", oid);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            ParentChildRelation curData = this._cacheDict[oid];

            if (curData.Parent == null)
            {
                retList = this._topLevelList.Select(item => item.Inner).ToList();
            }
            else
            {
                retList = curData.Parent.Childs.Select(item => item.Inner).ToList();
            }

            return retList;
        }

        /// <summary>
        /// 子表実体を取得する
        /// </summary>
        /// <param name="oid">対象表実体のOID</param>
        /// <returns>子表実体リスト</returns>
        public List<TItemBase> GetChildList(ulong oid)
        {
            List<TItemBase> retList = new List<TItemBase>();

            if (!this._cacheDict.ContainsKey(oid))
            {
                string message = string.Format("データが取得できません。OID:{0}", oid);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            ParentChildRelation curData = this._cacheDict[oid];

            if (curData.Childs != null && curData.Childs.Count > 0)
            {
                retList = curData.Childs.Select(item => item.Inner).ToList();
            }

            return retList;
        }

        /// <summary>
        /// 親の表実体を取得する
        /// </summary>
        /// <param name="oid">対象表実体のOID</param>
        /// <returns>親の表実体</returns>
        public TItemBase GetParent(ulong oid)
        {
            if (!this._cacheDict.ContainsKey(oid))
            {
                string message = string.Format("データが取得できません。OID:{0}", oid);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            ParentChildRelation curData = this._cacheDict[oid];

            TItemBase parentData = null;
            if (curData.Parent != null)
            {
                parentData = curData.Parent.Inner;
            }

            return parentData;
        }

        /// <summary>
        /// データをキャシュに保存する
        /// </summary>
        /// <param name="dataList">データリスト</param>
        /// <param name="preloadNestLevel">先取りネストレベル</param>
        protected void CacheSave(List<GeoItem> dataList, byte preloadNestLevel)
        {
            if (dataList != null)
            {
                foreach (GeoItem tempItem in dataList)
                {
                    CacheSave(tempItem, preloadNestLevel);
                }
            }
        }

        /// <summary>
        /// データをキャシュに保存する
        /// </summary>
        /// <param name="dataItem">データ</param>
        /// <param name="preloadNestLevel">先取りネストレベル</param>
        protected void CacheSave(GeoItem dataItem, byte preloadNestLevel)
        {
            if (dataItem != null)
            {
                TItemBase tempTItemBase = (TItemBase)dataItem;

                ParentChildRelation childData = null;
                bool bIsLoaded = false;
                if (this._cacheDict.ContainsKey(tempTItemBase.OID))
                {
                    childData = this._cacheDict[tempTItemBase.OID];
                    bIsLoaded = childData.IsLoaded;

                    childData.ResetTItemBase(tempTItemBase);
                }
                else
                {
                    childData = new ParentChildRelation(tempTItemBase);
                    this._cacheDict.Add(childData.OID, childData);
                }

                if (childData.NestLevel < preloadNestLevel)
                {
                    childData.IsChildLoaded = true;
                }

                if (!bIsLoaded)
                {
                    ParentChildRelation parentData = null;
                    if (tempTItemBase.ParentTableOID != null)
                    {
                        if (this._cacheDict.ContainsKey((ulong)tempTItemBase.ParentTableOID))
                        {
                            parentData = this._cacheDict[(ulong)tempTItemBase.ParentTableOID];
                        }
                        else
                        {
                            parentData = new ParentChildRelation((ulong)tempTItemBase.ParentTableOID);
                            this._cacheDict.Add(parentData.OID, parentData);
                        }
                    }

                    if (parentData == null)
                    {
                        this._topLevelList.Add(childData);
                    }
                    else
                    {
                        parentData.AddChild(childData);
                    }
                }
            }
        }
    }
    #endregion
}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
////using Microsoft.Office.Interop.Excel;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// Excelに関する処理
    /// </summary>
    //// [Obsolete("EXCELプライマリ相互運用の使用は出来ないため、置き換えが必要")]
    public class ExcelUtil
    {
        /*
        /// <summary>
        /// Excelファイルの読込
        /// </summary>
        /// <param name="excelFilePath">ファイルパス</param>
        /// <param name="debugMode">debugMode</param>
        /// <returns>List&lt;List&lt;string&gt;&gt;</returns>
        public static List<List<string>> ReadExcelFileToMatrixFormat(
            string excelFilePath, bool debugMode)
        {
            List<List<string>> excelData = new List<List<string>>();

            ExcelFileClass excelFile = new ExcelFileClass(excelFilePath, debugMode);

            try
            {
                // Get colume count and table header
                List<string> rowList = new List<string>();

                int columeCount = 0;
                for (columeCount = 1; true; columeCount++)
                {
                    Range range = excelFile.WorkSheet.Cells[1, columeCount] as Range;

                    if (string.IsNullOrEmpty(range.Text))
                    {
                        break;
                    }
                    else
                    {
                        rowList.Add(range.Text);
                    }
                }

                // Add table header
                excelData.Add(rowList);

                for (int i = 2; true; i++)
                {
                    bool nullRowFlg = true;

                    rowList = new List<string>();
                    for (int j = 1; j < columeCount; j++)
                    {
                        Range range = excelFile.WorkSheet.Cells[i, j] as Range;
                        if (string.IsNullOrEmpty(range.Text))
                        {
                            rowList.Add(string.Empty);
                        }
                        else
                        {
                            rowList.Add(range.Text);
                            nullRowFlg = false;
                        }
                    }

                    if (nullRowFlg)
                    {
                        break;
                    }
                    else
                    {
                        excelData.Add(rowList);
                    }
                }
            }
            finally
            {
                try
                {
                    if (excelFile != null)
                    {
                        excelFile.Dispose();
                    }
                }
                finally
                {
                    excelFile = null;
                }
            }

            return excelData;
        }
    }

    /// <summary>
    /// ExcelFileClass
    /// </summary>
    ////[Obsolete("EXCELプライマリ相互運用の使用は出来ないため、置き換えが必要")]
    internal class ExcelFileClass : IDisposable
    {
        /// <summary>
        /// DEFAULT_WORKSHEET_INDEX
        /// </summary>
        private const int DEFAULT_WORKSHEET_INDEX = 1;

        /// <summary>
        /// excelApplication.Visible
        /// </summary>
        private bool excelDebugMode = false;

        /// <summary>
        /// excelApplication
        /// </summary>
        private Application excelApplication = null;

        /// <summary>
        /// Workbook
        /// </summary>
        private Workbook myWorkBook = null;

        /// <summary>
        /// myWorkSheet
        /// </summary>
        private Worksheet myWorkSheet = null;

        /// <summary>
        /// Track whether Dispose has been called.
        /// </summary>
        private bool disposed = false;

        #region constructor and destructor
        /// <summary>
        /// ExcelFileClass
        /// </summary>
        /// <param name="excelFilePath">excelFilePath</param>
        /// <param name="debugMode">debugMode</param>
        public ExcelFileClass(string excelFilePath, bool debugMode)
        {
            CultureInfo oldCI = System.Threading.Thread.CurrentThread.CurrentCulture;
            Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");

            this.excelDebugMode = debugMode;

            this.excelApplication = new Application();

            this.excelApplication.Visible = debugMode;

            if (System.IO.File.Exists(excelFilePath))
            {
                Workbook myWorkbook = excelApplication.Workbooks.Open(
                    excelFilePath,
                    Type.Missing,
                    false,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    Type.Missing,
                    false,
                    Type.Missing,
                    Type.Missing);

                this.myWorkBook = myWorkbook;

                this.myWorkSheet = myWorkbook.Sheets[ExcelFileClass.DEFAULT_WORKSHEET_INDEX];
            }
            else
            {
                throw new FileNotFoundException(excelFilePath);
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        ~ExcelFileClass()
        {
            Dispose(false);
        }
        #endregion

        /// <summary>
        /// myWorkSheet
        /// </summary>
        public Worksheet WorkSheet
        {
            get { return myWorkSheet; }
            set { myWorkSheet = value; }
        }

        /// <summary>
        /// WindowsThreadProcessの取得
        /// </summary>
        /// <param name="hWnd">IntPtr</param>
        /// <param name="lpdwProcessId">lpdwProcessId</param>
        /// <returns>int</returns>
        [DllImport("user32.dll", SetLastError = true)]
        private static extern int GetWindowThreadProcessId(IntPtr hWnd, out int lpdwProcessId);

        /// <summary>
        /// エクセルプロセスを中止
        /// </summary>
        /// <param name="excelApplication">エクセルアプリ</param>
        protected static void KillExcelProcess(Application excelApplication)
        {
            try
            {
                if (excelApplication != null)
                {
                    int lpdwProcessId;
                    GetWindowThreadProcessId(new IntPtr(excelApplication.Hwnd), out lpdwProcessId);

                    System.Diagnostics.Process.GetProcessById(lpdwProcessId).Kill();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Delete Excel Process Error:" + ex.Message);
            }
        }

        /// <summary>
        /// IDisposableの実現方法
        /// </summary>
        public void Dispose()
        {
            Dispose(true);

            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// メモリクリア
        /// </summary>
        /// <param name="disposing">disposing</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                // 未使用のインスタンスをクリア
                ExcelFileClass.CloseHandle(this.excelApplication, this.myWorkBook);

                this.excelApplication = null;
                this.myWorkBook = null;

                // disposingがされたことを設定
                disposed = true;
            }
        }

        /// <summary>
        /// Excelアプリをクロス
        /// </summary>
        /// <param name="excelApplication">エクセルアプリ</param>
        /// <param name="myWorkBook">ワークブック</param>
        private static void CloseHandle(Application excelApplication, Workbook myWorkBook)
        {
            myWorkBook.Close(false, Type.Missing, false);
            excelApplication.Quit();

            ExcelFileClass.KillExcelProcess(excelApplication);
        }
        * */
    }
}

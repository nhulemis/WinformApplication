﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// XMLSearchingParam
    /// </summary>
    public class XMLSearchingParam
    {
        /// <summary>
        /// XMLSearchingParam
        /// </summary>
        public XMLSearchingParam()
        {
        }

        /// <summary>
        /// XmlNodeName
        /// </summary>
        public string XmlNodeName { get; set; }

        /// <summary>
        /// Attribute
        /// </summary>
        public string Attribute { get; set; }

        /// <summary>
        /// Value
        /// </summary>
        public string Value { get; set; }
    }
}

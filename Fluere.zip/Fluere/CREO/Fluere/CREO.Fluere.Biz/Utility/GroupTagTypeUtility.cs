﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.Fluere.Biz.Constants;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// グループタグID
    /// </summary>
    public enum GroupTagTypeId : int
    {
        /// <summary>
        /// 作業トリガ（○座標一致）
        /// </summary>
        Type1 = 1,

        /// <summary>
        /// 作業トリガ（×座標一致）
        /// </summary>
        Type2,

        /// <summary>
        /// 同一物件管理（○座標一致）
        /// </summary>
        Type3,

        /// <summary>
        /// 同一物件管理（×座標一致）
        /// </summary>
        Type4,

        /// <summary>
        /// 描画系タイプ自動生成
        /// </summary>
        Type5,

        /// <summary>
        /// SAPA情報専用
        /// </summary>
        Type6,

        /// <summary>
        /// 納品（案内到着位置）
        /// </summary>
        Type7,

        /// <summary>
        /// 納品（駐車場接続交差点）
        /// </summary>
        Type8,

        /// <summary>
        /// 納品（dst_twn）
        /// </summary>
        Type9,

        /// <summary>
        /// 納品（itsspot 目的地コード）
        /// </summary>
        Type10,

        /// <summary>
        /// 納品（駐車場 提携目的地）
        /// </summary>
        Type11,

        /// <summary>
        /// 納品（3Dランドマークオフセット文字 施設物件）
        /// </summary>
        Type12,
    }

    /// <summary>
    /// グループタグ処理
    /// </summary>
    public class GroupTagTypeUtility
    {
        /// <summary>
        /// グループタイプIDにより、グループタイプ名称を取得
        /// </summary>
        /// <param name="typeId">グループタイプID</param>
        /// <returns>グループタイプ名称</returns>
        public static string GetNameByTypeId(int typeId)
        {
            string strName = string.Empty;

            switch (typeId)
            {
                case (int)GroupTagTypeId.Type1:
                    strName = GroupTagTypeName.TYPE1;
                    break;
                case (int)GroupTagTypeId.Type2:
                    strName = GroupTagTypeName.TYPE2;
                    break;
                case (int)GroupTagTypeId.Type3:
                    strName = GroupTagTypeName.TYPE3;
                    break;
                case (int)GroupTagTypeId.Type4:
                    strName = GroupTagTypeName.TYPE4;
                    break;
                case (int)GroupTagTypeId.Type5:
                    strName = GroupTagTypeName.TYPE5;
                    break;
                case (int)GroupTagTypeId.Type6:
                    strName = GroupTagTypeName.TYPE6;
                    break;
                case (int)GroupTagTypeId.Type7:
                    strName = GroupTagTypeName.TYPE7;
                    break;
                case (int)GroupTagTypeId.Type8:
                    strName = GroupTagTypeName.TYPE8;
                    break;
                case (int)GroupTagTypeId.Type9:
                    strName = GroupTagTypeName.TYPE9;
                    break;
                case (int)GroupTagTypeId.Type10:
                    strName = GroupTagTypeName.TYPE10;
                    break;
                case (int)GroupTagTypeId.Type11:
                    strName = GroupTagTypeName.TYPE11;
                    break;
                case (int)GroupTagTypeId.Type12:
                    strName = GroupTagTypeName.TYPE12;
                    break;
                default:
                    strName = string.Empty;
                    break;
            }

            return strName;
        }
    }
}

﻿namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// メモリ管ツール
    /// </summary>
    public class MemoryUtility
    {
        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        private MemoryUtility()
        {
        }
        #endregion

        #region パブリック・メソッド
        /// <summary>
        /// メモリ使用量情報を取得する
        /// </summary>
        /// <returns>MB単位のメモリ量</returns>
        public static ulong GetPrivateMemorySize64()
        {
            long privateMemorySize = 0;

            // 自プロセスを取得
            using (System.Diagnostics.Process currentProcess = System.Diagnostics.Process.GetCurrentProcess())
            {
                // リフレッシュしないとプロセスの各種情報が最新情報に更新されない
                currentProcess.Refresh();

                privateMemorySize = currentProcess.PrivateMemorySize64 / 1024 / 1024;
            }

            return (ulong)privateMemorySize;
        }
        #endregion
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using CREO.DataModel;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.TMIGeometry;
using CREO.FW.Utilities;
using Microsoft.SqlServer.Types;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// ログ出力用ユーティリティ
    /// </summary>
    public class LogUtility
    {
        #region プライベート・変数
        /// <summary>
        /// 機能モジュール番号のデフォルト値
        /// </summary>
        private const string DEFAULT_MODULE_NUMBER = UF_Fluere_MsgId.MODULE_NUMBER;

        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        private static LogManager _curLogMgr = null;

        /// <summary>
        /// 運行モデル
        /// </summary>
        private LogModel _curLogModel;

        /// <summary>
        /// 呼び出し方の関数
        /// </summary>
        private System.Reflection.MethodBase _curMethod = null;

        /// <summary>
        /// ログのタイトル
        /// </summary>
        private string _curLogTitle;

        /// <summary>
        /// 経過時間を正確に計測するために使用できるメソッドとプロパティのセットを提供するオブジェクト
        /// </summary>
        private System.Diagnostics.Stopwatch _curStopwatch = null;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        static LogUtility()
        {
            Init();
        }
        
        /// <summary>
        /// コンストラクタ
        /// </summary>
        private LogUtility()
        {
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="currentMethod">呼び出し方の関数</param>
        /// <param name="logTitle">ログのタイトル</param>
        /// <param name="logModel">運行モデル</param>
        public LogUtility(System.Reflection.MethodBase currentMethod,
            string logTitle,
            LogModel logModel = LogModel.DebugModel)
        {
            this._curMethod = currentMethod;
            this._curLogTitle = logTitle;
            this._curLogModel = logModel;

            InitStopwatch();

            WriteLogBegin();
        }
        #endregion

        #region パブリック・enum定義
        /// <summary>
        /// インスタンスの運行モデル
        /// </summary>
        public enum LogModel
        {
            /// <summary>
            /// デバッグ出力モデル
            /// </summary>
            DebugModel = 0,

            /// <summary>
            /// トレース出力モデル
            /// </summary>
            TraceModel,

            /// <summary>
            /// 情報出力モデル
            /// </summary>
            InfoModel
        }

        /// <summary>
        /// 処理区分
        /// </summary>
        public enum OperationType
        {
            /// <summary>
            /// 取得
            /// </summary>
            Select = 0,

            /// <summary>
            /// 新規作成
            /// </summary>
            New,

            /// <summary>
            /// 更新
            /// </summary>
            Update,

            /// <summary>
            /// 削除
            /// </summary>
            Delete,

            /// <summary>
            /// ファイルのレコード件数
            /// </summary>
            File,

            /// <summary>
            /// 処理区分がなし
            /// </summary>
            EmptyType = 99
        }
        #endregion

        #region パブリック・LogManagerプロパティをラップする
        /// <summary>
        /// Debugログの出力が可能かどうかを取得する。
        /// </summary>
        /// <value>(System.Boolean)Debugログの出力が可能かどうか</value>
        public static bool IsDebugEnabled
        {
            get
            {
                return _curLogMgr.IsDebugEnabled;
            }
        }

        /// <summary>
        /// Funcログの出力が可能かどうかを取得する。
        /// </summary>
        /// <value>(System.Boolean)Funcログの出力が可能かどうか</value>
        public static bool IsFuncEnabled
        {
            get
            {
                return _curLogMgr.IsFuncEnabled;
            }
        }

        /// <summary>
        /// Traceログの出力が可能かどうかを取得する。
        /// </summary>
        /// <value>(System.Boolean)Traceログの出力が可能かどうか</value>
        public static bool IsTraceEnabled
        {
            get
            {
                return _curLogMgr.IsTraceEnabled;
            }
        }

        /// <summary>
        /// Infoログの出力が可能かどうかを取得する。
        /// </summary>
        /// <value>(System.Boolean)Infoログの出力が可能かどうか</value>
        public static bool IsInfoEnabled
        {
            get
            {
                return _curLogMgr.IsInfoEnabled;
            }
        }
        #endregion

        #region パブリック・メソッド
        /// <summary>
        /// ログインスタンスを初期化する
        /// </summary>
        /// <param name="moduleNumber">機能番号を指定する。</param>
        public static void InitLogManager(string moduleNumber)
        {
            _curLogMgr = LogManager.GetLogger(moduleNumber);
        }

        /// <summary>
        /// ログ機能の必要な情報を初期化する。
        /// </summary>
        public static void Init()
        {
            if (_curLogMgr == null)
            {
                InitLogManager(DEFAULT_MODULE_NUMBER);
            }
        }

        /// <summary>
        /// ログインスタンスを取得する。
        /// </summary>
        /// <returns>(CREO.FW.Log.LogManager)ログインスタンスを返す。</returns>
        public static LogManager GetLogger()
        {
            return _curLogMgr;
        }

        /// <summary>
        /// 処理区分の説明情報を取得する
        /// </summary>
        /// <param name="operation">処理区分</param>
        /// <returns>処理区分の説明情報</returns>
        public static string GetOperationTitle(OperationType operation)
        {
            string operationTitle = string.Empty;
            switch (operation)
            {
                case OperationType.Select:
                    operationTitle = "取得";
                    break;
                case OperationType.New:
                    operationTitle = "新規";
                    break;
                case OperationType.Update:
                    operationTitle = "更新";
                    break;
                case OperationType.Delete:
                    operationTitle = "削除";
                    break;
                case OperationType.File:
                    operationTitle = "レコード";
                    break;
                case OperationType.EmptyType:
                    break;
                default:
                    break;
            }

            return operationTitle;
        }

        /// <summary>
        /// データ件数情報を出力する
        /// </summary>
        /// <param name="title">タイトル</param>
        /// <param name="operation">処理区分</param>
        /// <param name="dataCount">データ件数</param>
        /// <param name="logModel">運行モデル</param>
        public static void WriteDataCount(string title,
            OperationType operation,
            int dataCount,
            LogModel logModel = LogModel.InfoModel)
        {
            switch (logModel)
            {
                case LogModel.DebugModel:
                    if (IsDebugEnabled)
                    {
                        WriteDebug("【COUNT】{0}件数：\t{1}\t({2})", GetOperationTitle(operation), dataCount, title);
                    }

                    break;
                case LogModel.TraceModel:
                    if (IsTraceEnabled)
                    {
                        WriteTrace("【COUNT】{0}件数：\t{1}\t({2})", GetOperationTitle(operation), dataCount, title);
                    }

                    break;
                case LogModel.InfoModel:
                    if (IsInfoEnabled)
                    {
                        WriteInfo("【COUNT】{0}件数：\t{1}\t({2})", GetOperationTitle(operation), dataCount, title);
                    }

                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// モデルのOIDを出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="geoItem">データモデル</param>
        /// <param name="logModel">運行モデル</param>
        public static void WriteDataModel(string keyWordDescription, GeoItem geoItem, LogModel logModel)
        {
            switch (logModel)
            {
                case LogModel.DebugModel:
                    WriteDebug("【DATA】{0}: {1} ({2})",
                        keyWordDescription,
                        geoItem.OID,
                        geoItem.GetType().FullName);
                    break;
                case LogModel.TraceModel:
                    WriteTrace("【DATA】{0}: {1} ({2})",
                        keyWordDescription,
                        geoItem.OID,
                        geoItem.GetType().FullName);
                    break;
                case LogModel.InfoModel:
                    WriteInfo("【DATA】{0}: {1} ({2})",
                        keyWordDescription,
                        geoItem.OID,
                        geoItem.GetType().FullName);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// ファイルのユニークキーまたはレコード番号を出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="keyWord">キーワード</param>
        /// <param name="logModel">運行モデル</param>
        public static void WriteDataKeyWord(string keyWordDescription, string keyWord, LogModel logModel)
        {
            switch (logModel)
            {
                case LogModel.DebugModel:
                    WriteDebug("【DATA】{0}: {1}", keyWordDescription, keyWord);
                    break;
                case LogModel.TraceModel:
                    WriteTrace("【DATA】{0}: {1}", keyWordDescription, keyWord);
                    break;
                case LogModel.InfoModel:
                    WriteInfo("【DATA】{0}: {1}", keyWordDescription, keyWord);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// Geometry データのテキスト形式を取得する
        /// </summary>
        /// <param name="geoItem">データモデル</param>
        /// <returns>Geometry データのテキスト形式</returns>
        public static string GetGeometryString(GeoItem geoItem)
        {
            string geometryText = string.Empty;

            if (geoItem is SPoint)
            {
                geometryText = CoordinateLib.ParseCoordinateToPointGeometryString(
                    ((SPoint)geoItem).Geometry);
            }
            else if (geoItem is SPolygon)
            {
                geometryText = CoordinateLib.ParseCoordinateListToPolygonGeometryString(
                    ((SPolygon)geoItem).Geometry);
            }
            else if (geoItem is SPolyline)
            {
                geometryText = CoordinateLib.ParseCoordinateToPolylineGeometryString(
                    ((SPolyline)geoItem).Geometry);
            }
            else if (geoItem is SGuidelinePolyline)
            {
                geometryText = CoordinateLib.ParseCoordinateToPolylineGeometryString(
                    ((SGuidelinePolyline)geoItem).Geometry);
            }

            return geometryText;
        }

        /// <summary>
        /// 空間実体のGeometry データのテキスト形式を出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="geoItem">データモデル</param>
        /// <param name="logModel">運行モデル</param>
        public static void WriteGeometry(string keyWordDescription,
            GeoItem geoItem,
            LogModel logModel = LogModel.DebugModel)
        {
            if (geoItem != null)
            {
                switch (logModel)
                {
                    case LogModel.DebugModel:
                        if (IsDebugEnabled)
                        {
                            WriteDebug("【Geometry】{0}: {1} ({2}) {3}",
                                keyWordDescription,
                                geoItem.OID,
                                geoItem.GetType().FullName,
                                GetGeometryString(geoItem));
                        }

                        break;
                    case LogModel.TraceModel:
                        if (IsTraceEnabled)
                        {
                            WriteTrace("【Geometry】{0}: {1} ({2}) {3}",
                                keyWordDescription,
                                geoItem.OID,
                                geoItem.GetType().FullName,
                                GetGeometryString(geoItem));
                        }

                        break;
                    case LogModel.InfoModel:
                        if (IsInfoEnabled)
                        {
                            WriteInfo("【Geometry】{0}: {1} ({2}) {3}",
                                keyWordDescription,
                                geoItem.OID,
                                geoItem.GetType().FullName,
                                GetGeometryString(geoItem));
                        }

                        break;
                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// 空間実体のGeometry データのテキスト形式を出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="paraObject">データ</param>
        /// <param name="logModel">運行モデル</param>
        public static void WriteToString(string keyWordDescription,
            object paraObject,
            LogModel logModel = LogModel.DebugModel)
        {
            if (paraObject != null)
            {
                switch (logModel)
                {
                    case LogModel.DebugModel:
                        if (IsDebugEnabled)
                        {
                            WriteDebug("【{0}】: {1}",
                                keyWordDescription,
                                paraObject.ToString());
                        }

                        break;
                    case LogModel.TraceModel:
                        if (IsTraceEnabled)
                        {
                            WriteTrace("【{0}】: {1}",
                                keyWordDescription,
                                paraObject.ToString());
                        }

                        break;
                    case LogModel.InfoModel:
                        if (IsInfoEnabled)
                        {
                            WriteInfo("【{0}】: {1}",
                                keyWordDescription,
                                paraObject.ToString());
                        }

                        break;
                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// 空間実体のGeometry データのCoordinateD形式を出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="geometrys">空間実体のGeometry データ</param>
        /// <param name="logModel">運行モデル</param>
        public static void WriteGeometrys(string keyWordDescription,
            IList<Coordinate> geometrys,
            LogModel logModel = LogModel.DebugModel)
        {
            if (geometrys != null)
            {
                switch (logModel)
                {
                    case LogModel.DebugModel:
                        if (IsDebugEnabled)
                        {
                            System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();
                            msgBuffer.AppendFormat("{0}: (", keyWordDescription);
                            bool isFirst = true;
                            foreach (Coordinate coordinate in geometrys)
                            {
                                if (isFirst)
                                {
                                    isFirst = false;
                                }
                                else
                                {
                                    msgBuffer.Append(", ");
                                }

                                msgBuffer.AppendFormat("{0} {1}", coordinate.Longitude, coordinate.Latitude);
                            }

                            msgBuffer.Append(")");

                            WriteDebug(msgBuffer.ToString());
                        }

                        break;
                    case LogModel.TraceModel:
                        if (IsTraceEnabled)
                        {
                            System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();
                            msgBuffer.AppendFormat("{0}: (", keyWordDescription);
                            bool isFirst = true;
                            foreach (Coordinate coordinate in geometrys)
                            {
                                if (isFirst)
                                {
                                    isFirst = false;
                                }
                                else
                                {
                                    msgBuffer.Append(", ");
                                }

                                msgBuffer.AppendFormat("{0} {1}", coordinate.Longitude, coordinate.Latitude);
                            }

                            msgBuffer.Append(")");

                            WriteTrace(msgBuffer.ToString());
                        }

                        break;
                    case LogModel.InfoModel:
                        if (IsInfoEnabled)
                        {
                            System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();
                            msgBuffer.AppendFormat("{0}: (", keyWordDescription);
                            bool isFirst = true;
                            foreach (Coordinate coordinate in geometrys)
                            {
                                if (isFirst)
                                {
                                    isFirst = false;
                                }
                                else
                                {
                                    msgBuffer.Append(", ");
                                }

                                msgBuffer.AppendFormat("{0} {1}", coordinate.Longitude, coordinate.Latitude);
                            }

                            msgBuffer.Append(")");

                            WriteInfo(msgBuffer.ToString());
                        }

                        break;
                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// 空間実体のGeometry データのCoordinateD形式を出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="geometrys">空間実体のGeometry データ</param>
        /// <param name="logModel">運行モデル</param>
        public static void WriteGeometrys(string keyWordDescription,
            DMCollection<CoordinateD> geometrys,
            LogModel logModel = LogModel.DebugModel)
        {
            if (geometrys != null)
            {
                switch (logModel)
                {
                    case LogModel.DebugModel:
                        if (IsDebugEnabled)
                        {
                            System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();
                            msgBuffer.AppendFormat("【DMCollection<CoordinateD>】{0}: (", keyWordDescription);
                            bool isFirst = true;
                            foreach (CoordinateD coordinate in geometrys)
                            {
                                if (isFirst)
                                {
                                    isFirst = false;
                                }
                                else
                                {
                                    msgBuffer.Append(", ");
                                }

                                msgBuffer.AppendFormat("{0} {1}", coordinate.Longitude, coordinate.Latitude);
                            }

                            msgBuffer.Append(")");

                            WriteDebug(msgBuffer.ToString());
                        }

                        break;
                    case LogModel.TraceModel:
                        if (IsTraceEnabled)
                        {
                            System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();
                            msgBuffer.AppendFormat("【DMCollection<CoordinateD>】{0}: (", keyWordDescription);
                            bool isFirst = true;
                            foreach (CoordinateD coordinate in geometrys)
                            {
                                if (isFirst)
                                {
                                    isFirst = false;
                                }
                                else
                                {
                                    msgBuffer.Append(", ");
                                }

                                msgBuffer.AppendFormat("{0} {1}", coordinate.Longitude, coordinate.Latitude);
                            }

                            msgBuffer.Append(")");

                            WriteTrace(msgBuffer.ToString());
                        }

                        break;
                    case LogModel.InfoModel:
                        if (IsInfoEnabled)
                        {
                            System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();
                            msgBuffer.AppendFormat("【DMCollection<CoordinateD>】{0}: (", keyWordDescription);
                            bool isFirst = true;
                            foreach (CoordinateD coordinate in geometrys)
                            {
                                if (isFirst)
                                {
                                    isFirst = false;
                                }
                                else
                                {
                                    msgBuffer.Append(", ");
                                }

                                msgBuffer.AppendFormat("{0} {1}", coordinate.Longitude, coordinate.Latitude);
                            }

                            msgBuffer.Append(")");

                            WriteInfo(msgBuffer.ToString());
                        }

                        break;
                    default:
                        break;
                }
            }
        }

        /// <summary>
        /// Listの内容を出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="paraList">リスト</param>
        /// <param name="logModel">運行モデル</param>
        public static void WriteEnumerable(string keyWordDescription,
            IEnumerable paraList,
            LogModel logModel = LogModel.DebugModel)
        {
            switch (logModel)
            {
                case LogModel.DebugModel:
                    if (IsDebugEnabled)
                    {
                        System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();
                        msgBuffer.AppendFormat("【IEnumerable】{0}", keyWordDescription).AppendLine();
                        foreach (object tempObject in paraList)
                        {
                            msgBuffer.AppendLine(tempObject.ToString());
                        }

                        WriteDebug(msgBuffer.ToString());
                    }

                    break;
                case LogModel.TraceModel:
                    if (IsTraceEnabled)
                    {
                        System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();
                        msgBuffer.AppendFormat("【IEnumerable】{0}", keyWordDescription).AppendLine();
                        foreach (object tempObject in paraList)
                        {
                            msgBuffer.AppendLine(tempObject.ToString());
                        }

                        WriteTrace(msgBuffer.ToString());
                    }

                    break;
                case LogModel.InfoModel:
                    if (IsInfoEnabled)
                    {
                        System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();
                        msgBuffer.AppendFormat("【IEnumerable】{0}", keyWordDescription).AppendLine();
                        foreach (object tempObject in paraList)
                        {
                            msgBuffer.AppendLine(tempObject.ToString());
                        }

                        WriteInfo(msgBuffer.ToString());
                    }

                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 該当データをStringに変換する
        /// </summary>
        /// <param name="dumpObject">該当データ</param>
        /// <returns>変換したデータ</returns>
        public static string SerialObject(object dumpObject)
        {
            string result = string.Empty;
            try
            {
                MethodInfo so = _curLogMgr.GetType().GetMethod("SerialObject",
                        BindingFlags.NonPublic | BindingFlags.InvokeMethod | BindingFlags.Instance);
                result = so.Invoke(_curLogMgr, new object[] { dumpObject }) as string;
            }
            catch (Exception ex)
            {
                WriteTrace(ex);
            }

            return result;
        }

        /// <summary>
        /// プログラムデバッグするために、メモリ中のオブジェクトをXMLシリアライズしてからトレースログファイルに出力する
        /// </summary>
        /// <param name="dumpObject">ダンプ対象とするオブジェクト</param>
        /// <param name="tipInfo">オブジェクトのダンプのときに、出力する提示情報。例えば、"対象GeoItem:"</param>
        /// <remarks>トレースログファイルのTraceレベルのログの出力も許可に指定が必要。</remarks>
        public static void DumpObject(object dumpObject, string tipInfo = "")
        {
            if (IsTraceEnabled)
            {
                lock (_curLogMgr)
                {
                    WriteTrace("{0}{1}：{2}{3}",
                        "【DUMP】",
                        tipInfo,
                        Environment.NewLine,
                        SerialObject(dumpObject));
                }
            }
        }

        /// <summary>
        /// 例外のinnerメッセージをデバッグで出力する
        /// </summary>
        /// <param name="ex">例外</param>
        public static void WriteInnerException(Exception ex)
        {
            if (IsDebugEnabled)
            {
                if (ex != null)
                {
                    Exception innerException = ex.InnerException;
                    while (innerException != null)
                    {
                        _curLogMgr.WriteDebug(innerException, innerException.GetType().FullName);
                        innerException = innerException.InnerException;
                    }
                }
            }
        }

        /// <summary>
        /// 例外のinnerメッセージをINFOで出力する
        /// </summary>
        /// <param name="ex">例外</param>
        public static void WriteInfoInnerException(Exception ex)
        {
            if (IsInfoEnabled)
            {
                if (ex != null)
                {
                    Exception innerException = ex.InnerException;
                    while (innerException != null)
                    {
                        _curLogMgr.WriteInfo(innerException, innerException.GetType().FullName);
                        innerException = innerException.InnerException;
                    }
                }
            }
        }

        #region メモリのログを出力する

        /// <summary>
        /// メモリ情報を取得する
        /// </summary>
        /// <returns>メモリ情報</returns>
        public static string GetMemoryString()
        {
            System.Text.StringBuilder msgBuffer = new System.Text.StringBuilder();

            // 自プロセスを取得
            using (System.Diagnostics.Process currentProcess = System.Diagnostics.Process.GetCurrentProcess())
            {
                // リフレッシュしないとプロセスの各種情報が最新情報に更新されない
                currentProcess.Refresh();

                msgBuffer.AppendFormat("【MEMORY】プロセスID:{0}", currentProcess.Id);
                msgBuffer.Append(Environment.NewLine);
                msgBuffer.AppendFormat("Peak physical memory usage:{0:N0}(K)",
                    currentProcess.PeakWorkingSet64 / 1024);
                msgBuffer.Append(Environment.NewLine);
                msgBuffer.AppendFormat("Peak virtual memory usage:{0:N0}(K)",
                    currentProcess.PeakVirtualMemorySize64 / 1024);
                msgBuffer.Append(Environment.NewLine);
                msgBuffer.AppendFormat("Physical memory usage:{0:N0}(K)",
                    currentProcess.WorkingSet64 / 1024);
                msgBuffer.Append(Environment.NewLine);
                msgBuffer.AppendFormat("Virtual Memory Size:{0:N0}(K)",
                    currentProcess.VirtualMemorySize64 / 1024);
                msgBuffer.Append(Environment.NewLine);
                msgBuffer.AppendFormat("Private Memory Size:{0:N0}(K)",
                    currentProcess.PrivateMemorySize64 / 1024);
                msgBuffer.Append(Environment.NewLine);
                msgBuffer.AppendFormat("Paged Memory Size:{0:N0}(K)",
                    currentProcess.PagedMemorySize64 / 1024);
                msgBuffer.Append(Environment.NewLine);
                msgBuffer.AppendFormat("Paged System Memory Size:{0:N0}(K)",
                    currentProcess.PagedSystemMemorySize64 / 1024);
                msgBuffer.Append(Environment.NewLine);
                msgBuffer.AppendFormat("Non-paged System Memory Size:{0:N0}(K)",
                    currentProcess.NonpagedSystemMemorySize64 / 1024);
                msgBuffer.Append(Environment.NewLine);
            }

            long memAvailable = GC.GetTotalMemory(false);
            msgBuffer.AppendFormat("【MEMORY】マネージメモリ:{0:N0}(K)",
                memAvailable / 1024);
            msgBuffer.Append(Environment.NewLine);

            using (System.Diagnostics.PerformanceCounter memoryCounter =
                new System.Diagnostics.PerformanceCounter("Memory", "Available KBytes", string.Empty))
            {
                msgBuffer.AppendFormat("【MEMORY】利用可能:{0:N0}(K)",
                    memoryCounter.NextValue());
                msgBuffer.Append(Environment.NewLine);
            }

            return msgBuffer.ToString();
        }

        /// <summary>
        /// 一時メモリ情報を出力する
        /// </summary>
        /// <param name="titile">処理の説明</param>
        /// <param name="logModel">運行モデル</param>
        [Conditional("CHECK_FLUERE_MEMORY")]
        public static void WriteCurrentMemory(string titile, LogModel logModel = LogModel.DebugModel)
        {
            switch (logModel)
            {
                case LogModel.DebugModel:
                    if (IsDebugEnabled)
                    {
                        WriteDebug("{0}{1}{2}", titile, Environment.NewLine, GetMemoryString());
                    }

                    break;
                case LogModel.TraceModel:
                    if (IsTraceEnabled)
                    {
                        WriteTrace("{0}{1}{2}", titile, Environment.NewLine, GetMemoryString());
                    }

                    break;
                case LogModel.InfoModel:
                    if (IsInfoEnabled)
                    {
                        WriteInfo("{0}{1}{2}", titile, Environment.NewLine, GetMemoryString());
                    }

                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 一時メモリ情報を出力する
        /// </summary>
        /// <param name="titile">処理の説明</param>
        /// <param name="logModel">運行モデル</param>
        public static void WriteMemoryInfo(string titile, LogModel logModel = LogModel.DebugModel)
        {
            WriteCurrentMemory(titile, logModel);
        }

        #endregion

        #endregion

        #region パブリック・LogManager関数をラップする
        /// <summary>
        /// ログを出力する。
        /// </summary>
        /// <param name="messageID">
        /// 定義済みメッセージを識別するIDを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void Write(string messageID, params object[] paramStrings)
        {
            Write(null, messageID, paramStrings);
        }

        /// <summary>
        /// ログを出力する。
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        /// <param name="messageID">
        /// 定義済みメッセージを識別するIDを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void Write(Exception targetException, string messageID, params object[] paramStrings)
        {
            _curLogMgr.Write(targetException, messageID, paramStrings);

            WriteInnerException(targetException);
        }

        /// <summary>
        /// 指定したメッセージはTraceログに出力する。 
        /// </summary>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。</para>
        /// </param>
        public static void WriteTrace(string message, params object[] paramStrings)
        {
            WriteTrace(null, message, paramStrings);
        }

        /// <summary>
        /// 指定したメッセージはTraceログに出力する。 
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        public static void WriteTrace(Exception targetException)
        {
            WriteTrace(targetException, targetException.Message);
        }

        /// <summary>
        /// 指定したメッセージはTraceログに出力する。 
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteTrace(Exception targetException, string message, params object[] paramStrings)
        {
            _curLogMgr.WriteTrace(targetException, message, paramStrings);

            WriteInnerException(targetException);
        }

        /// <summary>
        /// メソッド入出力情報（呼び出し履歴）出力する
        /// </summary>
        /// <param name="message">メッセージ</param>
        /// <param name="paramList">入出力情報リスト</param>
        public static void WriteFunc(string message, params object[] paramList)
        {
            if (IsFuncEnabled)
            {
                try
                {
                    MethodInfo so = _curLogMgr.GetType().GetMethod("WriteFunc",
                            BindingFlags.NonPublic | BindingFlags.InvokeMethod | BindingFlags.Instance);
                    so.Invoke(_curLogMgr, new object[] { message, paramList });
                }
                catch (Exception ex)
                {
                    WriteTrace(ex);
                }
            }
        }

        /// <summary>
        /// メソッド入力情報をログに記入する（呼び出し履歴）
        /// </summary>
        /// <param name="paramList">入力引数</param>
        //// [Obsolete("LogUtility logUtility = new LogUtility(...)を使用してください")]
        public static void WriteFuncStart(params object[] paramList)
        {
            if (IsFuncEnabled)
            {
                StackTrace st = new StackTrace(true);
                StackFrame sf = st.GetFrame(1);
                MethodBase mb = sf.GetMethod();

                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("【FUN_S】");
                if (mb.DeclaringType != null)
                {
                    sb.Append(mb.DeclaringType.FullName);
                    sb.Append(Environment.NewLine);
                }

                sb.Append(mb.ToString());
                sb.Append(Environment.NewLine);

                WriteFunc(sb.ToString(), paramList);
            }
        }

        /// <summary>
        /// メソッド入出力情報ログファイルに記入する（呼び出し履歴）
        /// </summary>
        /// <param name="paramList">
        /// 出力引数のみを出力。ない場合、引数渡し不要。
        /// </param>
        //// [Obsolete("logUtility.WriteNormalEnd()を使用してください")]
        public static void WriteFuncEnd(params object[] paramList)
        {
            if (IsFuncEnabled)
            {
                StackTrace st = new StackTrace(true);
                StackFrame sf = st.GetFrame(1);
                MethodBase mb = sf.GetMethod();

                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("【FUN_E】");
                if (mb.DeclaringType != null)
                {
                    sb.Append(mb.DeclaringType.FullName);
                    sb.Append(Environment.NewLine);
                }

                sb.Append(mb.ToString());
                sb.Append(Environment.NewLine);

                WriteFunc(sb.ToString(), paramList);
            }
        }

        /// <summary>
        /// 戻り値出力の場合（呼び出し履歴）
        /// </summary>
        /// <param name="rtnValue">戻り値</param>
        /// <param name="paramList">出力引数</param>
        //// [Obsolete("logUtility.WriteNormalEnd()を使用してください")]
        public static void WriteFuncEndWithReturn(object rtnValue, params object[] paramList)
        {
            if (IsFuncEnabled)
            {
                StackTrace st = new StackTrace(true);
                StackFrame sf = st.GetFrame(1);
                MethodBase mb = sf.GetMethod();

                System.Text.StringBuilder sb = new System.Text.StringBuilder();
                sb.Append("【FUN_E】");
                if (mb.DeclaringType != null)
                {
                    sb.Append(mb.DeclaringType.FullName);
                    sb.Append(Environment.NewLine);
                }

                sb.Append(mb.ToString());
                sb.Append(Environment.NewLine);

                if (IsTraceEnabled)
                {
                    sb.Append("【FUN_R】");
                    sb.Append(Environment.NewLine);
                    sb.Append(SerialObject(rtnValue));
                    sb.Append(Environment.NewLine);
                }

                WriteFunc(sb.ToString(), paramList);
            }
        }

        /// <summary>
        /// 指定したメッセージはDebugログに出力する。 
        /// </summary>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteDebug(string message, params object[] paramStrings)
        {
            WriteDebug(null, message, paramStrings);
        }

        /// <summary>
        /// 指定したメッセージはDebugログに出力する。 
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        public static void WriteDebug(Exception targetException)
        {
            WriteDebug(targetException, targetException.Message);
        }

        /// <summary>
        /// 指定したメッセージはDebugログに出力する。 
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteDebug(Exception targetException, string message, params object[] paramStrings)
        {
            _curLogMgr.WriteDebug(targetException, message, paramStrings);

            WriteInnerException(targetException);
        }

        /// <summary>
        /// 指定したメッセージはInfoログに出力する。 
        /// </summary>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteInfo(string message, params object[] paramStrings)
        {
            WriteInfo(null, message, paramStrings);
        }

        /// <summary>
        /// 指定したメッセージはInfoログに出力する。 
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteInfo(Exception targetException, string message, params object[] paramStrings)
        {
            _curLogMgr.WriteInfo(targetException, message, paramStrings);

            WriteInfoInnerException(targetException);
        }

        /// <summary>
        /// 指定したメッセージはWarningログに出力する。 
        /// </summary>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteWarning(string message, params object[] paramStrings)
        {
            WriteWarning(null, message, paramStrings);
        }

        /// <summary>
        /// 指定したメッセージはWarningログに出力する。 
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteWarning(Exception targetException, string message, params object[] paramStrings)
        {
            _curLogMgr.WriteWarning(targetException, message, paramStrings);

            WriteInnerException(targetException);
        }

        /// <summary>
        /// 指定したメッセージはErrorログに出力する。 
        /// </summary>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteError(string message, params object[] paramStrings)
        {
            WriteError(null, message, paramStrings);
        }

        /// <summary>
        /// 指定したメッセージはErrorログに出力する。 
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        public static void WriteError(Exception targetException)
        {
            WriteError(targetException, targetException.Message);
        }

        /// <summary>
        /// 指定したメッセージはErrorログに出力する。 
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteError(Exception targetException, string message, params object[] paramStrings)
        {
            if (targetException != null && targetException is CREOException)
            {
                CREOException tempException = (CREOException)targetException;
                Write(tempException, tempException.MessageId, tempException.MessageParameters);
            }
            else
            {
                _curLogMgr.WriteError(targetException, message, paramStrings);
            }

            WriteInnerException(targetException);
        }

        /// <summary>
        /// 指定したメッセージはFatalログに出力する。 
        /// </summary>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteFatal(string message, params object[] paramStrings)
        {
            WriteFatal(null, message, paramStrings);
        }

        /// <summary>
        /// 指定したメッセージはFatalログに出力する。 
        /// </summary>
        /// <param name="targetException">
        /// ログ出力対象の例外を指定する。
        /// <para>例外出力が不要な場合は、nullを指定する。 </para>
        /// </param>
        /// <param name="message">
        /// メッセージを指定する。
        /// </param>
        /// <param name="paramStrings">
        /// メッセージ置換文字列を配列で指定する。
        /// <para>メッセージ置換が不要な場合は、指定不要。 </para>
        /// </param>
        public static void WriteFatal(Exception targetException, string message, params object[] paramStrings)
        {
            _curLogMgr.WriteFatal(targetException, message, paramStrings);

            WriteInnerException(targetException);
        }
        #endregion

        #region プライベート・メソッド
        #region 処理の説明を出力する
        /// <summary>
        /// 処理開始の説明内容を出力する
        /// </summary>
        private void WriteLogBegin()
        {
            switch (this._curLogModel)
            {
                case LogModel.DebugModel:
                    WriteDebug("【BEGIN】{0} {1}.{2}:{3}",
                        this._curLogTitle,
                        this._curMethod.DeclaringType.Namespace,
                        this._curMethod.DeclaringType.Name,
                        this._curMethod.Name);
                    break;
                case LogModel.TraceModel:
                    WriteTrace("【BEGIN】{0} {1}.{2}:{3}",
                        this._curLogTitle,
                        this._curMethod.DeclaringType.Namespace,
                        this._curMethod.DeclaringType.Name,
                        this._curMethod.Name);
                    break;
                case LogModel.InfoModel:
                    WriteInfo("【BEGIN】{0} {1}.{2}:{3}",
                        this._curLogTitle,
                        this._curMethod.DeclaringType.Namespace,
                        this._curMethod.DeclaringType.Name,
                        this._curMethod.Name);
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        /// 処理終了の説明内容を出力する
        /// </summary>
        /// <param name="bError">エラーフラグ</param>
        private void WriteLogEnd(bool bError = false)
        {
            string elapsedTime = string.Empty;
            this.GetStopTime(ref elapsedTime);

            string endLabel = "【END】";
            if (bError)
            {
                endLabel = "【ERROR】";
            }

            switch (this._curLogModel)
            {
                case LogModel.DebugModel:
                    WriteDebug("{0}{1}{2} {3}.{4}:{5}",
                        endLabel,
                        elapsedTime,
                        this._curLogTitle,
                        this._curMethod.DeclaringType.Namespace,
                        this._curMethod.DeclaringType.Name,
                        this._curMethod.Name);
                    break;
                case LogModel.TraceModel:
                    WriteTrace("{0}{1}{2} {3}.{4}:{5}",
                        endLabel,
                        elapsedTime,
                        this._curLogTitle,
                        this._curMethod.DeclaringType.Namespace,
                        this._curMethod.DeclaringType.Name,
                        this._curMethod.Name);
                    break;
                case LogModel.InfoModel:
                    WriteInfo("{0}{1}{2} {3}.{4}:{5}",
                        endLabel,
                        elapsedTime,
                        this._curLogTitle,
                        this._curMethod.DeclaringType.Namespace,
                        this._curMethod.DeclaringType.Name,
                        this._curMethod.Name);
                    break;
                default:
                    break;
            }
        }
        #endregion

        #region 性能のログを出力する
        /// <summary>
        /// ストップウォッチを初期化する
        /// </summary>
        [Conditional("CHECK_FLUERE_PERFORMANCE")]
        private void InitStopwatch()
        {
            this._curStopwatch = new System.Diagnostics.Stopwatch();
            this.RestartStopwatch();
        }

        /// <summary>
        /// 計測開始
        /// </summary>
        [Conditional("CHECK_FLUERE_PERFORMANCE")]
        private void RestartStopwatch()
        {
            if (this._curStopwatch != null)
            {
                this._curStopwatch.Restart();
            }
        }

        /// <summary>
        /// 計測を中止し、経過時間を取得する
        /// </summary>
        /// <param name="elapsedTime">経過時間</param>
        [Conditional("CHECK_FLUERE_PERFORMANCE")]
        private void GetStopTime(ref string elapsedTime)
        {
            if (_curStopwatch != null)
            {
                this._curStopwatch.Stop();

                this.GetElapsedTime(ref elapsedTime);

                this._curStopwatch = null;
            }
        }

        /// <summary>
        /// 経過時間を取得する
        /// </summary>
        /// <param name="elapsedTime">経過時間</param>
        [Conditional("CHECK_FLUERE_PERFORMANCE")]
        private void GetElapsedTime(ref string elapsedTime)
        {
            elapsedTime = string.Format("{0:0.000} 秒。", (double)this._curStopwatch.ElapsedMilliseconds / 1000.0);
        }
        #endregion
        #endregion

        #region パブリック・メソッド
        #region ログ出力処理を終了する
        /// <summary>
        /// 異常処理終了のログを出力する
        /// </summary>
        public void WriteErrorEnd()
        {
            this.WriteLogEnd(true);
        }

        /// <summary>
        /// 正常処理終了のログを出力する
        /// </summary>
        public void WriteNormalEnd()
        {
            this.WriteLogEnd(false);
        }
        #endregion

        #region データ件数情報を出力
        /// <summary>
        /// データ件数情報を出力する
        /// </summary>
        /// <param name="title">タイトル</param>
        /// <param name="operation">処理区分</param>
        /// <param name="dataCount">データ件数</param>
        public void WriteDefaultDataCount(string title, OperationType operation, int dataCount)
        {
            WriteDataCount(title, operation, dataCount, this._curLogModel);
        }

        /// <summary>
        /// データ件数情報を出力する
        /// </summary>
        /// <param name="title">タイトル</param>
        /// <param name="operation">処理区分</param>
        /// <param name="dataCount">データ件数</param>
        public void WriteDebugDataCount(string title, OperationType operation, int dataCount)
        {
            WriteDataCount(title, operation, dataCount, LogModel.DebugModel);
        }

        /// <summary>
        /// データ件数情報を出力する
        /// </summary>
        /// <param name="title">タイトル</param>
        /// <param name="operation">処理区分</param>
        /// <param name="dataCount">データ件数</param>
        public void WriteTraceDataCount(string title, OperationType operation, int dataCount)
        {
            WriteDataCount(title, operation, dataCount, LogModel.TraceModel);
        }
        #endregion

        #region モデルのOIDを出力する
        /// <summary>
        /// モデルのOIDを出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="geoItem">データモデル</param>
        public void WriteDataModel(string keyWordDescription, GeoItem geoItem)
        {
            WriteDataModel(keyWordDescription, geoItem, this._curLogModel);
        }

        /// <summary>
        /// モデルのOIDを出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="geoItem">データモデル</param>
        public void WriteDebugDataModel(string keyWordDescription, GeoItem geoItem)
        {
            WriteDataModel(keyWordDescription, geoItem, LogModel.DebugModel);
        }

        /// <summary>
        /// モデルのOIDを出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="geoItem">データモデル</param>
        public void WriteTraceDataModel(string keyWordDescription, GeoItem geoItem)
        {
            WriteDataModel(keyWordDescription, geoItem, LogModel.TraceModel);
        }
        #endregion

        #region ファイルのユニークキーまたはレコード番号を出力
        /// <summary>
        /// ファイルのユニークキーまたはレコード番号を出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="keyWord">キーワード</param>
        public void WriteDataKeyWord(string keyWordDescription, string keyWord)
        {
            WriteDataKeyWord(keyWordDescription, keyWord, this._curLogModel);
        }

        /// <summary>
        /// ファイルのユニークキーまたはレコード番号を出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="keyWord">キーワード</param>
        public void WriteDebugDataKeyWord(string keyWordDescription, string keyWord)
        {
            WriteDataKeyWord(keyWordDescription, keyWord, LogModel.DebugModel);
        }

        /// <summary>
        /// ファイルのユニークキーまたはレコード番号を出力する
        /// </summary>
        /// <param name="keyWordDescription">キーワードの説明</param>
        /// <param name="keyWord">キーワード</param>
        public void WriteTraceDataKeyWord(string keyWordDescription, string keyWord)
        {
            WriteDataKeyWord(keyWordDescription, keyWord, LogModel.TraceModel);
        }
        #endregion

        #region 性能のログを出力する
        /// <summary>
        /// 一時処理時間を出力する
        /// </summary>
        /// <param name="titile">処理の説明</param>
        [Conditional("CHECK_FLUERE_PERFORMANCE")]
        public void WriteCurrentElapsedTime(string titile)
        {
            switch (this._curLogModel)
            {
                case LogModel.DebugModel:
                    if (IsDebugEnabled)
                    {
                        string elapsedTime = string.Empty;
                        this.GetElapsedTime(ref elapsedTime);

                        WriteDebug("【TIME】{0}{1} {2}.{3}:{4}",
                            elapsedTime,
                            titile,
                            this._curMethod.DeclaringType.Namespace,
                            this._curMethod.DeclaringType.Name,
                            this._curMethod.Name);
                    }

                    break;
                case LogModel.TraceModel:
                    if (IsTraceEnabled)
                    {
                        string elapsedTime = string.Empty;
                        this.GetElapsedTime(ref elapsedTime);

                        WriteTrace("【TIME】{0}{1} {2}.{3}:{4}",
                            elapsedTime,
                            titile,
                            this._curMethod.DeclaringType.Namespace,
                            this._curMethod.DeclaringType.Name,
                            this._curMethod.Name);
                    }

                    break;
                case LogModel.InfoModel:
                    if (IsInfoEnabled)
                    {
                        string elapsedTime = string.Empty;
                        this.GetElapsedTime(ref elapsedTime);

                        WriteInfo("【TIME】{0}{1} {2}.{3}:{4}",
                            elapsedTime,
                            titile,
                            this._curMethod.DeclaringType.Namespace,
                            this._curMethod.DeclaringType.Name,
                            this._curMethod.Name);
                    }

                    break;
                default:
                    break;
            }
        }
        #endregion

        #endregion
    }
}

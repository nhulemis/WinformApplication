﻿using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// Update summary.
    /// </summary>
    public class FileUtil
    {
        /// <summary>
        /// DEFAULT_ENCODING
        /// </summary>
        private const string DEFAULT_ENCODING = "shift-jis";

        /// <summary>
        /// ducoファイル拡張子
        /// </summary>
        public const string AllDucoExtension = "*.duco";

        /// <summary>
        /// テキストファイルを読込む
        /// </summary>
        /// <param name="filePath">テキストファイルパス</param>
        /// <returns>content</returns>
        public static string ReadFile(string filePath)
        {
            string content = null;

            // ファイルパス存在チェック
            if (!System.IO.File.Exists(filePath))
            {
                throw new FileNotFoundException(filePath);
            }

            // テキストファイルを読込む？？？
            FileInfo fileInfo = new FileInfo(filePath);
            byte[] buffer = new byte[fileInfo.Length];

            FileStream fs = null;
            try
            {
                fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);

                fs.Read(buffer, 0, (int)fileInfo.Length);
                fs.Close();
            }
            finally
            {
                try
                {
                    if (fs != null)
                    {
                        fs.Dispose();
                    }
                }
                finally
                {
                    fs = null;
                }
            }

            content = Encoding.GetEncoding(FileUtil.DEFAULT_ENCODING).GetString(buffer);

            return content;
        }

        #region 指定したフォルダ内のすべてのToDoファイルを取得する
        /// <summary>
        /// 指定したフォルダ内のすべてのToDoファイルを取得する
        /// </summary>
        /// <param name="stRootPath">ToDoファイルのパス</param>
        /// <returns>listファイル</returns>
        public static List<string> GetToDoFiles(string stRootPath)
        {
            // 必要な変数を宣言する
            List<string> list = new List<string>();

            // 拡張子が .duco(stPattern) のファイルを列挙する
            foreach (string stFilePath in Directory.GetFiles(stRootPath, AllDucoExtension))
            {
                list.Add(stFilePath);
            }

            return list;
        }
        #endregion
    }
}

﻿using System.Collections.Generic;
using CREO.DataModel;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 目印取得基準リストラッパー
    /// </summary>
    public class MarkObtainStandardWrapper
    {
        #region フィールド定義
        /// <summary>
        /// ソート済目印取得基準リスト
        /// </summary>
        private List<MarkObtainStandardListData> markObtainStandardList = null;

        /// <summary>
        /// 検索用NTTGroupCodeのDictionary
        /// </summary>
        private Dictionary<string, int> nttGroupCodeDict = new Dictionary<string, int>();
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        private MarkObtainStandardWrapper()
        {
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="markObtainStandardList">ソート済目印取得基準リスト</param>
        public MarkObtainStandardWrapper(List<MarkObtainStandardListData> markObtainStandardList)
        {
            this.markObtainStandardList = markObtainStandardList;
            this.markObtainStandardList.Sort(new GroupDataComparer());

            // NTTGroupCodeを条件として、データをグループする
            string preNTTGroupCode = null;
            for (int i = 0; i < markObtainStandardList.Count; i++)
            {
                MarkObtainStandardListData markObtainStandardListData = markObtainStandardList[i];
                if (markObtainStandardListData.NTTGroupCode == null)
                {
                    if (preNTTGroupCode == null)
                    {
                        preNTTGroupCode = string.Empty;
                        nttGroupCodeDict.Add(preNTTGroupCode, i);
                    }

                    continue;
                }

                if (markObtainStandardListData.NTTGroupCode.Equals(preNTTGroupCode))
                {
                    continue;
                }

                preNTTGroupCode = markObtainStandardListData.NTTGroupCode;
                nttGroupCodeDict.Add(preNTTGroupCode, i);
            }
        }
        #endregion

        #region 目印取得基準リストに合致するデータを取得する
        /// <summary>
        /// 目印取得基準リストに合致するデータを取得する
        /// </summary>
        /// <param name="stwnPOI">タウン物件データモデル</param>
        /// <returns>目印置換用の取得基準</returns>
        public MarkObtainStandardListData GetMatchedData(STwnPOI stwnPOI)
        {
            string matchNTTCode = null;
            string matchKeisaiNameKanji = null;
            string matchKeisaiNameKana = null;

            TGnrTwn tempTGnrTwn = stwnPOI.GnrTwn;
            if (tempTGnrTwn != null)
            {
                matchNTTCode = tempTGnrTwn.NTTCode;
            }

            if (stwnPOI.TwnMultiLang != null)
            {
                if (stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN] != null)
                {
                    matchKeisaiNameKanji = stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name;
                }

                if (stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_KANA] != null)
                {
                    matchKeisaiNameKana = stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_KANA].Name;
                }
            }

            return GetMatchedData(matchNTTCode, matchKeisaiNameKanji, matchKeisaiNameKana);
        }

        /// <summary>
        /// 目印取得基準リストに合致するデータを取得する
        /// </summary>
        /// <param name="matchNTTCode">タウンジャンルのNTT分類コード</param>
        /// <param name="matchKeisaiNameKanji">掲載名（漢字）</param>
        /// <param name="matchKeisaiNameKana">掲載名（片仮名）</param>
        /// <returns>合致する目印取得基準データ</returns>
        public MarkObtainStandardListData GetMatchedData(string matchNTTCode, 
            string matchKeisaiNameKanji,
            string matchKeisaiNameKana)
        {
            MarkObtainStandardListData retValue = null;

            // 基本仕様：データモデル側がNULL場合、不合致となります
            if (!string.IsNullOrEmpty(matchNTTCode))
            {
                if (nttGroupCodeDict.ContainsKey(matchNTTCode))
                {
                    int iBegin = nttGroupCodeDict[matchNTTCode];
                    for (int i = iBegin; i < markObtainStandardList.Count; i++)
                    {
                        MarkObtainStandardListData markObtainStandardListData = markObtainStandardList[i];
                        if (!matchNTTCode.Equals(markObtainStandardListData.NTTGroupCode))
                        {
                            // 判断処理終了
                            break;
                        }

                        // 掲載名（漢字）
                        if (!string.IsNullOrEmpty(matchKeisaiNameKanji))
                        {
                            if (!string.IsNullOrEmpty(markObtainStandardListData.KanjiName))
                            {
                                // 部分一致と判断
                                if (!matchKeisaiNameKanji.Contains(markObtainStandardListData.KanjiName))
                                {
                                    // 部分一致しない場合、不合致
                                    continue;
                                }
                            }

                            // データモデル側がNULL以外、ファイル側がNULL場合、合致
                        }

                        // 掲載名（片仮名）
                        if (!string.IsNullOrEmpty(matchKeisaiNameKana))
                        {
                            if (!string.IsNullOrEmpty(markObtainStandardListData.KanaName))
                            {
                                // 部分一致と判断
                                if (!matchKeisaiNameKana.Contains(markObtainStandardListData.KanaName))
                                {
                                    // 部分一致しない場合、不合致
                                    continue;
                                }
                            }

                            // データモデル側がNULL以外、ファイル側がNULL場合、合致
                        }

                        // 合致の場合、合致する目印取得基準データを生成する
                        retValue = markObtainStandardListData;
                        break;
                    }
                }
            }

            return retValue;
        }
        #endregion

        #region 比較子
        /// <summary>
        /// ソート用比較子
        /// </summary>
        private class GroupDataComparer : IComparer<MarkObtainStandardListData>
        {
            /// <summary>
            /// 2 つの目印取得基準オブジェクトを比較し、一方が他方より小さいか、等しいか、大きいかを示す値を返します。
            /// </summary>
            /// <param name="firstObj">比較する最初のオブジェクトです</param>
            /// <param name="secondObj">比較する 2 番目のオブジェクト</param>
            /// <returns>firstObj と secondObjの相対的な値を示す符号付き整数</returns>
            public int Compare(MarkObtainStandardListData firstObj, MarkObtainStandardListData secondObj)
            {
                int retValue = 0;

                // NTT分類コード
                if (firstObj.NTTGroupCode == null)
                {
                    if (secondObj.NTTGroupCode == null)
                    {
                        retValue = 0;
                    }
                    else
                    {
                        return -1;
                    }
                }
                else
                {
                    retValue = firstObj.NTTGroupCode.CompareTo(secondObj.NTTGroupCode);
                }

                if (retValue != 0)
                {
                    return retValue;
                }

                // NTT分類コードが同じ場合、行番の順に設定する
                retValue = firstObj.LineNum.CompareTo(secondObj.LineNum);
                
                return retValue;
            }
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using CREO.DataModel;
using CREO.DS;
using CREO.DS.DataSource;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;
using CREO.FW.TMIGeometry;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// <para>バッチ専用データサービスのラッパー</para>
    /// </summary>
    public class DataServiceWrapper : IDisposable
    {
        /// <summary>
        /// OID検索件数の最上限
        /// </summary>
        protected const int QUERY_OID_MAX_COUNT = 5000;

        /// <summary>
        /// 2次メッシュタイプ
        /// </summary>
        protected const ushort MESHTYPE = 8102;

        /// <summary>
        /// 全ての実体
        /// </summary>
        protected Dictionary<ulong, GeoItem> _cacheItems = new Dictionary<ulong, GeoItem>();

        /// <summary>
        /// 事前に取得したデータタイプ一覧
        /// </summary>
        protected List<string> _cacheTypeList = new List<string>();

        /// <summary>
        /// 依存関係リスト
        /// </summary>
        protected Dictionary<ulong, List<ulong>> _cacheSItemDependencyDict = new Dictionary<ulong, List<ulong>>();

        /// <summary>
        /// コンストラクタ
        /// </summary>
        protected DataServiceWrapper()
        {
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="innerDataService">データサービス</param>
        public DataServiceWrapper(CREO.DS.DataService innerDataService)
        {
            this.InnerDataService = innerDataService;
        }

        /// <summary>
        /// グローバルなインスタンス
        /// </summary>
        public static DataServiceWrapper GlobalInstance { get; set; }

        /// <summary>
        /// データサービス
        /// </summary>
        public DataService InnerDataService { get; set; }

        /// <summary>
        /// ConnectionContextを使用して、DataServiceに接続する
        /// </summary>
        /// <param name="ctx">ConnectionContext</param>
        /// <returns>バッチ専用データサービスのラッパー</returns>
        public static DataServiceWrapper Connect(ConnectionContext ctx)
        {
            return new DataServiceWrapper(CREO.DS.DataService.Connect(ctx));
        }

        /// <summary>
        /// メッシュ矩形を取得
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <returns>メッシュ矩形</returns>
        public static CoordinateRect GetCoordRectByMeshCode(string meshCode)
        {
            bool bResult = true;
            CoordinateRect meshRect;

            // メッシュ矩形取得
            bResult = GISLib.GetCoordRectByMeshCode(MESHTYPE, meshCode, out meshRect);

            // 二次メッシュの取得に失敗の場合
            if (!bResult)
            {
                string message = string.Format("メッシュ矩形が取得できません。メッシュタイプ:{0} メッシュコード:{1}",
                    MESHTYPE,
                    meshCode);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            return meshRect;
        }

        /// <summary>
        /// メッシュ矩形から、Coordinateリストに変更する
        /// </summary>
        /// <param name="meshRect">メッシュ矩形</param>
        /// <param name="meshPolygon">Coordinateリスト</param>
        public static void ConvertCoordinateRectToList(CoordinateRect meshRect, List<Coordinate> meshPolygon)
        {
            // 左下
            meshPolygon.Add(meshRect.BottomLeft);

            // 左上
            meshPolygon.Add(new Coordinate(meshRect.BottomLeft.Longitude, meshRect.TopRight.Latitude));

            // 右上
            meshPolygon.Add(meshRect.TopRight);

            // 右下
            meshPolygon.Add(new Coordinate(meshRect.TopRight.Longitude, meshRect.BottomLeft.Latitude));

            // 左下
            meshPolygon.Add(meshRect.BottomLeft);
        }

        /// <summary>
        /// データサービスの解放
        /// </summary>
        public void Dispose()
        {
            this.InnerDataService.Dispose();
        }

        /// <summary>
        /// 条件を指定してGeoItemの配列を取得する
        /// </summary>
        /// <param name="cond">取得条件</param>
        /// <returns>GeoItemの配列</returns>
        public List<GeoItem> QueryItems(QueryItemsCondition cond)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "【性能】条件を指定してGeoItemの配列を取得する処理",
                LogUtility.LogModel.TraceModel);

            List<GeoItem> retList = this.InnerDataService.QueryItems(cond);

            logUtility.WriteNormalEnd();

            return retList;
        }

        /// <summary>
        /// 条件を指定してGeoItemの配列を取得する
        /// </summary>
        /// <param name="cond">取得条件</param>
        /// <returns>GeoItemの配列</returns>
        public List<GeoItem> QueryItemsWithCache(QueryItemsCondition cond)
        {
            List<GeoItem> retList = this.QueryItems(cond);
            CacheSave(retList);

            return retList;
        }

        /// <summary>
        /// 空間実体と依存実体を一括取得する
        /// </summary>
        /// <param name="cond">取得条件</param>
        /// <param name="postProcess">後処理条件</param>
        /// <returns>GeoItemの配列</returns>
        public List<GeoItem> QueryItemsWithDependency(QueryItemsCondition cond, QueryItemsPostProcess postProcess = null)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "【性能】空間実体と依存実体を一括取得する処理",
                LogUtility.LogModel.DebugModel);

            if (cond == null)
            {
                throw new ArgumentException();
            }

            if (postProcess != null)
            {
                if (cond.QueryItemsPostProcess != null)
                {
                    throw new ArgumentException();
                }

                cond.QueryItemsPostProcess = postProcess;
            }

            List<GeoItem> tempItems = this.InnerDataService.QueryItems(cond);
            CacheSave(tempItems);

            if (cond.TypeIDs != null)
            {
                foreach (string tempType in cond.TypeIDs)
                {
                    if (!this._cacheTypeList.Contains(tempType))
                    {
                        this._cacheTypeList.Add(tempType);
                    }
                }
            }

            if (cond.QueryItemsPostProcess != null && cond.QueryItemsPostProcess.TypeIDs != null)
            {
                foreach (string tempType in cond.QueryItemsPostProcess.TypeIDs)
                {
                    if (!this._cacheTypeList.Contains(tempType))
                    {
                        this._cacheTypeList.Add(tempType);
                    }
                }
            }

            logUtility.WriteNormalEnd();

            return tempItems;
        }

        /// <summary>
        /// 依存実体の検索条件を指定し、依存実体に関連する空間実体リストを取得する
        /// </summary>
        /// <param name="cond">取得条件</param>
        /// <returns>SItemBaseの配列</returns>
        public List<SItemBase> QueryOwnerOfDependency(QueryItemsCondition cond)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "【性能】依存実体の検索条件を指定し、依存実体に関連する空間実体リストを取得する処理",
                LogUtility.LogModel.DebugModel);

            if (cond == null)
            {
                throw new ArgumentException();
            }

            List<GeoItem> tempItems = this.InnerDataService.QueryItems(cond);

            List<SItemBase> retSItemBase = new List<SItemBase>();
            HashSet<ulong> sItemBaseOidSet = new HashSet<ulong>();
            if (tempItems != null)
            {
                foreach (GeoItem tempItem in tempItems)
                {
                    if (tempItem is DItemBase)
                    {
                        DItemBase tempDItemBase = (DItemBase)tempItem;
                        sItemBaseOidSet.UnionWith(tempDItemBase.GetDependingItemsOid());
                    }

                    CacheSave(tempItem);
                }
            }

            if (cond.TypeIDs != null)
            {
                foreach (string tempType in cond.TypeIDs)
                {
                    if (!this._cacheTypeList.Contains(tempType))
                    {
                        this._cacheTypeList.Add(tempType);
                    }
                }
            }

            if (sItemBaseOidSet.Count > 0)
            {
                QueryItemsCondition sItemcond = new QueryItemsCondition();

                decimal total = sItemBaseOidSet.Count();
                decimal times = Math.Ceiling(total / QUERY_OID_MAX_COUNT);

                for (int i = 0; i < times; i++)
                {
                    sItemcond.IDs = sItemBaseOidSet.Skip(i * QUERY_OID_MAX_COUNT).Take(QUERY_OID_MAX_COUNT).ToList();

                    List<GeoItem> tempItemBases = this.InnerDataService.QueryItems(sItemcond);
                    CacheSave(tempItemBases);

                    if (tempItemBases != null)
                    {
                        retSItemBase.AddRange(tempItemBases.OfType<SItemBase>());
                    }
                }
            }

            logUtility.WriteNormalEnd();

            return retSItemBase;
        }

        /// <summary>
        /// キャッシュからデータモデルを取得する
        /// </summary>
        /// <param name="oid">データモデルのOID</param>
        /// <returns>データモデル</returns>
        public GeoItem QueryGeoItemFromCacheByOid(ulong oid)
        {
            if (this._cacheItems.ContainsKey(oid))
            {
                return this._cacheItems[oid];
            }

            return null;
        }

        /// <summary>
        /// キャッシュからデータモデルを取得する
        /// </summary>
        /// <param name="oid">データモデルのOID</param>
        /// <returns>データモデル</returns>
        public GeoItem QueryGeoItemByOid(ulong oid)
        {
            if (!this._cacheItems.ContainsKey(oid))
            {
                // データ検索対象作成
                QueryItemsCondition qic = new QueryItemsCondition();
                qic.IDs.Add(oid);

                List<GeoItem> preLoadResultItem = QueryItems(qic);

                if (preLoadResultItem == null || preLoadResultItem.Count != 1)
                {
                    string errMsg = string.Format("バッチ専用データサービス: 対象データが取得できません。OID: {0}", oid);
                    throw new Exception(errMsg);
                }

                CacheSave(preLoadResultItem[0]);
                return preLoadResultItem[0];
            }

            return this._cacheItems[oid];
        }

        /// <summary>
        /// 表実体の親子データを一括取得する
        /// </summary>
        /// <param name="contentType">表実体のタイプ名</param>
        /// <param name="preloadNestLevel">先取りネストレベル</param>
        /// <returns>GeoItemの配列</returns>
        public List<GeoItem> QueryTopLevelWithChildItems(string contentType, byte preloadNestLevel)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "【性能】表実体の親子データを一括取得する処理",
                LogUtility.LogModel.DebugModel);

            QueryItemsCondition cond = new QueryItemsCondition();
            cond.TypeIDs.Add(contentType);

            cond.ConditionExpression = new SqlConditionExpression("ParentTableOID",
                QueryItemOperator.Equal,
                null);

            QueryItemsPostProcess qipp = new QueryItemsPostProcess();
            qipp.Flags = QueryItemsPostProcessFlags.GetDescendant;
            qipp.Parameters.Add("GetDescendant.MaxNestLevel", preloadNestLevel.ToString());
            cond.QueryItemsPostProcess = qipp;

            List<GeoItem> retList = this.InnerDataService.QueryItems(cond);

            logUtility.WriteNormalEnd();

            return retList;
        }

        /// <summary>
        /// 表実体の子孫を一括取得する
        /// </summary>
        /// <param name="oid">対象OID</param>
        /// <param name="maxNestLevel">最大ネストレベル</param>
        /// <returns>GeoItemの配列</returns>
        public List<GeoItem> QueryChildItems(ulong oid, byte maxNestLevel)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "【性能】表実体の子孫を一括取得する処理",
                LogUtility.LogModel.DebugModel);

            QueryItemsCondition qic = new QueryItemsCondition();
            qic.IDs.Add(oid);

            QueryItemsPostProcess qipp = new QueryItemsPostProcess();
            qipp.Flags = QueryItemsPostProcessFlags.GetDescendant;
            qipp.Parameters.Add("GetDescendant.MaxNestLevel", maxNestLevel.ToString());
            qic.QueryItemsPostProcess = qipp;

            List<GeoItem> retList = this.InnerDataService.QueryItems(qic);

            logUtility.WriteNormalEnd();

            return retList;
        }

        /// <summary>
        /// 表実体の祖先を一括取得する
        /// </summary>
        /// <param name="oid">対象OID</param>
        /// <param name="minNestLevel">最小ネストレベル</param>
        /// <returns>GeoItemの配列</returns>
        public List<GeoItem> QueryParentItems(ulong oid, byte minNestLevel)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "【性能】表実体の祖先を一括取得する処理",
                LogUtility.LogModel.DebugModel);

            QueryItemsCondition qic = new QueryItemsCondition();
            qic.IDs.Add(oid);

            QueryItemsPostProcess qipp = new QueryItemsPostProcess();
            qipp.Flags = QueryItemsPostProcessFlags.GetAncestors;
            qipp.Parameters.Add("GetAncestors.MinNestLevel", minNestLevel);
            qic.QueryItemsPostProcess = qipp;

            List<GeoItem> retList = this.InnerDataService.QueryItems(qic);

            logUtility.WriteNormalEnd();

            return retList;
        }

        /// <summary>
        /// フィールドの値リストを指定してGeoItemの配列を取得する
        /// </summary>
        /// <param name="cond">取得条件</param>
        /// <param name="qic">検索条件</param>
        /// <param name="fieldName">フィールド名</param>
        /// <param name="valueList">フィールド値リスト</param>
        /// <param name="bWithDependency">依存実体の検索フラグ</param>
        /// <returns>GeoItemの配列</returns>
        public List<GeoItem> QueryItemsWithFieldValues(QueryItemsCondition cond,
            SqlConditionExpression qic,
            string fieldName,
            List<string> valueList,
            bool bWithDependency = false)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "【性能】フィールドの値リストを指定してGeoItemの配列を取得する処理",
                LogUtility.LogModel.TraceModel);

            if (cond.ConditionExpression != null && qic != null)
            {
                throw new ArgumentException();
            }

            if (valueList.Count < 1)
            {
                throw new ArgumentException();
            }

            List<GeoItem> retList = new List<GeoItem>();

            IConditionExpression oldQic = cond.ConditionExpression;
            if (qic != null)
            {
                oldQic = qic;
            }

            decimal total = valueList.Count();
            decimal times = Math.Ceiling(total / QUERY_OID_MAX_COUNT);
            for (int i = 0; i < times; i++)
            {
                string[] filterList = valueList.Skip(i * QUERY_OID_MAX_COUNT).Take(QUERY_OID_MAX_COUNT).ToArray();
                SqlConditionExpression filterCond = new SqlConditionExpression(fieldName, QueryItemOperator.In, filterList);
                if (oldQic == null)
                {
                    cond.ConditionExpression = filterCond;
                }
                else
                {
                    cond.ConditionExpression = oldQic.And(filterCond, oldQic);
                }

                List<GeoItem> partList = null;
                if (bWithDependency)
                {
                    partList = QueryItemsWithDependency(cond);
                }
                else
                {
                    partList = QueryItems(cond);
                }

                if (partList != null)
                {
                    retList.AddRange(partList);
                }
            }

            logUtility.WriteNormalEnd();

            return retList;
        }

        /// <summary>
        /// データをキャシュに保存する
        /// </summary>
        /// <param name="dataList">データリスト</param>
        protected void CacheSave(List<GeoItem> dataList)
        {
            if (dataList != null)
            {
                foreach (GeoItem tempItem in dataList)
                {
                    CacheSave(tempItem);
                }
            }
        }

        /// <summary>
        /// データをキャシュに保存する
        /// </summary>
        /// <param name="dataItem">データ</param>
        protected void CacheSave(GeoItem dataItem)
        {
            if (dataItem != null)
            {
                if (!this._cacheItems.ContainsKey(dataItem.OID))
                {
                    this._cacheItems[dataItem.OID] = dataItem;

                    if (dataItem is DItemBase)
                    {
                        DItemBase tempDItemBase = (DItemBase)dataItem;
                        List<ulong> tempSItemOidList = tempDItemBase.GetDependingItemsOid();
                        foreach (ulong tempSItemOid in tempSItemOidList)
                        {
                            if (!this._cacheSItemDependencyDict.ContainsKey(tempSItemOid))
                            {
                                this._cacheSItemDependencyDict[tempSItemOid] = new List<ulong>();
                            }

                            List<ulong> tempDitemOidSet = this._cacheSItemDependencyDict[tempSItemOid];
                            tempDitemOidSet.Add(tempDItemBase.OID);
                        }
                    }
                }
                else
                {
                    this._cacheItems[dataItem.OID] = dataItem;
                }
            }
        }

        /// <summary>
        /// 依存関係リストの取得
        /// </summary>
        /// <param name="sitem">空間実体</param>
        /// <param name="contentType">コンテンツタイプ(NULL可)</param>
        /// <param name="useOnlyCache">キャッシュを使用するフラグ</param>
        /// <returns>依存実体のリスト</returns>
        public List<GeoItem> GetDependencyItems(SItemBase sitem, string contentType = null, bool useOnlyCache = true)
        {
            List<GeoItem> retList = new List<GeoItem>();

            if (contentType != null && !this._cacheTypeList.Contains(contentType))
            {
                string errMsg = string.Format("バッチ専用データサービス: 事前にデータを取得する必要があります。{0}", contentType);
                throw new Exception(errMsg);
            }

            if (!this._cacheItems.ContainsKey(sitem.OID))
            {
                retList = sitem.GetDependencyItems(contentType);

                CacheSave(sitem);
                CacheSave(retList);
            }
            else
            {
                if (this._cacheSItemDependencyDict.ContainsKey(sitem.OID))
                {
                    List<ulong> tempOidList = this._cacheSItemDependencyDict[sitem.OID];

                    foreach (ulong tempOid in tempOidList)
                    {
                        GeoItem tempGeoItem = this._cacheItems[tempOid];
                        if (contentType == null || tempGeoItem.ContentID == contentType)
                        {
                            retList.Add(tempGeoItem);
                        }
                    }
                }
            }

            return retList;
        }

        /// <summary>
        /// 依存関係リストの取得
        /// </summary>
        /// <param name="ditem">依存実体</param>
        /// <param name="useOnlyCache">キャッシュを使用するフラグ</param>
        /// <returns>空間実体のリスト</returns>
        public List<GeoItem> GetDependingItems(DItemBase ditem, bool useOnlyCache = true)
        {
            List<GeoItem> retList = new List<GeoItem>();
            List<ulong> tempOidList = ditem.GetDependingItemsOid();

            if (tempOidList != null)
            {
                bool bFindAllFlag = true;
                foreach (ulong tempOid in tempOidList)
                {
                    if (this._cacheItems.ContainsKey(tempOid))
                    {
                        retList.Add(this._cacheItems[tempOid]);
                    }
                    else
                    {
                        bFindAllFlag = false;
                        break;
                    }
                }

                if (!bFindAllFlag)
                {
                    retList = ditem.GetDependingItems();

                    CacheSave(ditem);
                    CacheSave(retList);
                }
            }

            return retList;
        }

        /// <summary>
        /// 依存関係リストの取得
        /// </summary>
        /// <param name="sitemOID">空間実体</param>
        /// <param name="contentType">コンテンツタイプ(NULL可)</param>
        /// <returns>依存実体のリスト</returns>
        public List<GeoItem> GetDependencyItemsFromCache(ulong sitemOID, string contentType = null)
        {
            List<GeoItem> retList = new List<GeoItem>();
            if (this._cacheItems.ContainsKey(sitemOID))
            {
                if (this._cacheSItemDependencyDict.ContainsKey(sitemOID))
                {
                    List<ulong> tempOidList = this._cacheSItemDependencyDict[sitemOID];

                    foreach (ulong tempOid in tempOidList)
                    {
                        GeoItem tempGeoItem = this._cacheItems[tempOid];
                        if (contentType == null || tempGeoItem.ContentID == contentType)
                        {
                            retList.Add(tempGeoItem);
                        }
                    }
                }
            }

            return retList;
        }
    }
}

﻿using System.Collections.Generic;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 更新対象管理クラス
    /// </summary>
    /// <typeparam name="TypeKey">更新対象キーの型</typeparam>
    /// <typeparam name="TypeTarget">更新対象の型</typeparam>
    /// <typeparam name="TypeValue">更新値の型</typeparam>
    public class TargetDataCacheDict<TypeKey, TypeTarget, TypeValue>
    {
        /// <summary>
        /// 更新対象のキャッシュ
        /// </summary>
        private Dictionary<TypeKey, TargetData<TypeTarget, TypeValue>> _cacheDict = null;

        /// <summary>
        /// コンストラクター
        /// </summary>
        public TargetDataCacheDict()
        {
            this._cacheDict = new Dictionary<TypeKey, TargetData<TypeTarget, TypeValue>>();
        }

        /// <summary>
        /// 更新用delegateを定義する
        /// </summary>
        /// <param name="targetObject">更新対象</param>
        /// <param name="targetValue">更新値</param>
        public delegate void UpdateTargetDataDelegate(TypeTarget targetObject, TypeValue targetValue);

        /// <summary>
        /// 更新対象を取得・新規する
        /// </summary>
        /// <param name="targetKey">更新対象キー</param>
        /// <param name="targetObject">更新対象</param>
        /// <returns>更新対象拡張</returns>
        public TargetData<TypeTarget, TypeValue> GetCacheData(TypeKey targetKey, TypeTarget targetObject)
        {
            if (!this._cacheDict.ContainsKey(targetKey))
            {
                TargetData<TypeTarget, TypeValue> curTargetDataWrapper = new TargetData<TypeTarget, TypeValue>(targetObject);

                this._cacheDict.Add(targetKey, curTargetDataWrapper);
            }

            return this._cacheDict[targetKey];
        }

        /// <summary>
        /// 更新対象を削除する
        /// </summary>
        /// <param name="targetKey">更新対象キー</param>
        public void RemoveCacheData(TypeKey targetKey)
        {
            if (this._cacheDict.ContainsKey(targetKey))
            {
                this._cacheDict.Remove(targetKey);
            }
        }

        /// <summary>
        /// 更新対象が存在するかどうかをチェックする
        /// </summary>
        /// <param name="targetKey">更新対象キー</param>
        /// <returns>存在するかどうか</returns>
        public bool HasCacheData(TypeKey targetKey)
        {
            if (this._cacheDict.ContainsKey(targetKey))
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// 更新対象を反映する
        /// </summary>
        /// <param name="updateFunc">更新関数</param>
        public void UpdateAllData(UpdateTargetDataDelegate updateFunc)
        {
            foreach (var item in this._cacheDict.Values)
            {
                updateFunc(item.TargetObject, item.TargetValue);
            }
        }
    }

    /// <summary>
    /// 更新対象拡張クラス
    /// </summary>
    /// <typeparam name="TypeTarget">更新対象の型</typeparam>
    /// <typeparam name="TypeValue">更新値の型</typeparam>
    public class TargetData<TypeTarget, TypeValue>
    {
        /// <summary>
        /// コンストラクター
        /// </summary>
        protected TargetData()
        {
        }

        /// <summary>
        /// コンストラクター
        /// </summary>
        /// <param name="targetObject">更新対象</param>
        public TargetData(TypeTarget targetObject)
        {
            this.TargetObject = targetObject;
        }

        /// <summary>
        /// 更新対象
        /// </summary>
        public TypeTarget TargetObject { get; private set; }

        /// <summary>
        /// 更新値
        /// </summary>
        public TypeValue TargetValue { get; set; }
    }
}

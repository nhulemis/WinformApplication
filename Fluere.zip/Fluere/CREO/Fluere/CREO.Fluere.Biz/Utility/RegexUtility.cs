﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// Regex's Utility Class
    /// </summary>
    public class RegexUtility
    {
        /// <summary>
        /// Regex Split List
        /// </summary>
        /// <param name="pattern">Regex Pattern</param>
        /// <param name="input">Split String</param>
        /// <returns>List&lt;string&gt;</returns>
        public static List<string> SplitToList(string pattern, string input)
        {
            List<string> result = new List<string>();

            Regex reg = new Regex(pattern);

            string[] strAry = reg.Split(input);

            foreach (string str in strAry)
            {
                if (!string.IsNullOrWhiteSpace(str))
                {
                    result.Add(str);
                }
            }

            return result;
        }

        /// <summary>
        /// Match Split Array
        /// </summary>
        /// <param name="pattern">Regex Pattern</param>
        /// <param name="input">Split String</param>
        /// <returns>string[]</returns>
        public static string[] MatchSplitArray(string pattern, string input)
        {
            Regex reg = new Regex(pattern);

            MatchCollection marchCollection = reg.Matches(input);

            string[] strAry = new string[marchCollection.Count];

            int i = 0;

            foreach (Match match in marchCollection)
            {
                strAry[i] = match.Value;
                i++;
            }

            return strAry;
        }

        /// <summary>
        /// IsMatch
        /// </summary>
        /// <param name="pattern">Regex Pattern</param>
        /// <param name="input">Input String</param>
        /// <returns>bool</returns>
        public static bool IsMatch(string pattern, string input)
        {
            Regex reg = new Regex(pattern);

            Match march = reg.Match(input);

            return march.Success;
        }
    }
}

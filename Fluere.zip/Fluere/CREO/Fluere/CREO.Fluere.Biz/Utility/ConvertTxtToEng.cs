﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Data;
using CREO.Fluere.Biz.FileOperators.Data;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 英字変換共通
    /// </summary>
    public class ConvertTxtToEng
    {
        /// <summary>
        /// Kakasiパス
        /// </summary>
        public static string KakasiPath = string.Empty;

        /// <summary>
        /// Kakasi起動オプション
        /// </summary>
        public static string KakasiOption = string.Empty;

        /// <summary>
        /// Mecab分割候補数
        /// </summary>
        public static string MecabNBest = string.Empty;

        /// <summary>
        /// Mecabパス
        /// </summary>
        public static string MecabPath = string.Empty;

        /// <summary>
        /// 括弧
        /// </summary>
        private const string Parentheses = "（";

        /// <summary>
        /// 半角括弧
        /// </summary>
        private const string HS_Parentheses = "(";

        /// <summary>
        /// 長音記号
        /// </summary>
        private const string Macron = "^";

        /// <summary>
        /// 母音のリスト
        /// </summary>
        private static readonly string[] VowelAry = new string[4] { "aa", "uu", "oo", "ou" };

        #region 14.1.22. 単語省略処理
        /// <summary>
        /// 14.1.22. 単語省略処理
        /// 入力項目の英字に入力項目の省略単語リストに定義されている省略前単語が有る場合、省略前単語を省略型に変更する。
        /// </summary>
        /// <param name="abbreviationSettingDataList">省略単語リスト</param>
        /// <param name="enString">英字</param>
        /// <returns>変換後英字</returns>
        public static string ConvertAbbreviation(
            List<AbbreviationSettingData> abbreviationSettingDataList,
            string enString)
        {
            string result = enString;

            if (abbreviationSettingDataList != null &&
                abbreviationSettingDataList.Count > 0 &&
                enString != null)
            {
                foreach (AbbreviationSettingData item in abbreviationSettingDataList)
                {
                    if (result.Length < item.AbbreviationWord.Length)
                    {
                        break;
                    }

                    // 省略前単語が含まれていない場合、次の省略単語リストへ
                    int retIdx = result.IndexOf(item.AbbreviationBeforeWord);
                    if (retIdx == -1)
                    {
                        continue;
                    }

                    // 下記に該当する場合は、一致した文字列を省略型に変更
                    //  1.省略前単語と英字（省略前単語が一致する以降の文字列）が完全一致した場合
                    //  2.省略前単語と英字（省略前単語が一致する以降の単語組み合わせ）が完全一致した場合
                    string enPartString = result.Substring(retIdx);
                    char[] delimiterChars = { Convert.ToChar(CommonConstants.HALF_SIZE_BLANK), Convert.ToChar(CommonConstants.FULL_SIZE_BLANK) };
                    string[] befWords = item.AbbreviationBeforeWord.Split(delimiterChars);
                    string[] enWords = enPartString.Split(delimiterChars);
                    
                    // 省略前単語をスペースで分割した数より英字（省略前単語が一致する以降の文字列）をスペースで分割した数の方が小さい場合、
                    // 完全一致しないため、次の省略単語リストへ
                    if (befWords.Count() > enWords.Count())
                    {
                        continue;
                    }

                    // 英字の文字列を結合する
                    string resultBuf = enWords[0];
                    for (int i = 1; i < befWords.Count(); i++)
                    {
                        resultBuf += CommonConstants.HALF_SIZE_BLANK + enWords[i];
                    }

                    // 省略前単語と結合した文字列が完全一致する場合は、一致した文字列を省略型に変更
                    if (resultBuf == item.AbbreviationBeforeWord)
                    {
                        result = result.Remove(retIdx, item.AbbreviationBeforeWord.Length).Insert(retIdx, item.AbbreviationWord);
                    }
                }
            }

            return result;
        }
        #endregion

        #region 14.1.23. 部分一致変換
        /// <summary>
        /// 外部ファイルを参照して物件の日本語名称の語頭・語尾に対象となる単語が存在する場合は英字に変換する。
        /// </summary>
        /// <param name="preConvertResult">部分一致変換対象</param>
        /// <param name="partData">部分変換データ</param>
        /// <param name="code">ジャンル/文字種別コード</param>
        /// <param name="convertData">英字変換情報</param>
        /// <returns>部分一致変換が完了かどうか</returns>
        private static bool DoConvertPart(ref string preConvertResult,
            PartConvertSettingData partData,
            ushort? code,
            EnConvertData convertData)
        {
            // 全文字一致の場合、他の部分一致変換対象をチェック不要となる
            bool bAllEndFlag = false;

            if (LogUtility.IsTraceEnabled)
            {
                LogUtility.WriteTrace("【部分一致変換】変換前 カナ={0}, 漢字={1}, 英字={2}, 省略単語={3}", partData.KanaName, partData.KanjiName, preConvertResult, partData.EnConvertPart.Trim());
            }

            // 2-1)  入力項目のカナ名称のと部分変換データのカナ名称と全文字一致の場合、
            // 全文字一致の変換実施有無が有の場合、全文字を部分変換英字に変換する。
            if (partData.KanaName == convertData.KanaName &&
                partData.IsAllMatchConvert == CommonConstants.YES)
            {
                preConvertResult = preConvertResult.Replace(convertData.KanaName, partData.AllMatchEn);
                convertData.KanaName = string.Empty;
                convertData.KanjiName = string.Empty;

                if (LogUtility.IsTraceEnabled)
                {
                    LogUtility.WriteTrace("【部分一致変換】変換後（完全一致） 英字={0}", preConvertResult);
                }

                bAllEndFlag = true;
                return bAllEndFlag;
            }
            else
            {
                // 2-2)  部分変換英字の事前処理
                if (partData.IsSpace == CommonConstants.YES)
                {
                    if (partData.EnPartMatch == CommonConstants.FRIST_PART)
                    {
                        partData.EnConvertPart = partData.EnConvertPart.TrimEnd();
                        if (partData.KanaName != convertData.KanaName)
                        {
                            partData.EnConvertPart = partData.EnConvertPart + CommonConstants.HALF_SIZE_BLANK;
                        }
                    }
                    else if (partData.EnPartMatch == CommonConstants.END_PART)
                    {
                        partData.EnConvertPart = partData.EnConvertPart.TrimStart();
                        if (partData.KanaName != convertData.KanaName)
                        {
                            partData.EnConvertPart = CommonConstants.HALF_SIZE_BLANK + partData.EnConvertPart;
                        }
                    }
                }

                // 日本語名称の語頭が一致する場合
                if (partData.JapanPartMatch == CommonConstants.FRIST_PART)
                {
                    convertData.KanaName = convertData.KanaName.Remove(0, partData.KanaName.Length);
                    convertData.KanjiName = convertData.KanjiName.Remove(0, partData.KanjiName.Length);

                    // 英字を語頭に付与する場合
                    if (partData.EnPartMatch == CommonConstants.FRIST_PART)
                    {
                        preConvertResult = preConvertResult.Remove(0, partData.KanaName.Length).Insert(0, partData.EnConvertPart);
                    }
                    else if (partData.EnPartMatch == CommonConstants.END_PART)
                    {
                        // 英字を語尾に付与する場合
                        preConvertResult = preConvertResult.Remove(0, partData.KanaName.Length);
                        preConvertResult = preConvertResult + partData.EnConvertPart;
                    }
                }
                else if (partData.JapanPartMatch == CommonConstants.END_PART)
                {
                    // 日本語名称の語尾が一致する場合
                    int index = preConvertResult.Length - partData.KanaName.Length;

                    convertData.KanaName = convertData.KanaName.Remove(convertData.KanaName.Length - partData.KanaName.Length, partData.KanaName.Length);
                    convertData.KanjiName = convertData.KanjiName.Remove(convertData.KanjiName.Length - partData.KanjiName.Length, partData.KanjiName.Length);

                    // 英字を語頭に付与する場合
                    if (partData.EnPartMatch == CommonConstants.FRIST_PART)
                    {
                        preConvertResult = preConvertResult.Remove(index, partData.KanaName.Length);
                        preConvertResult = partData.EnConvertPart + preConvertResult;
                    }
                    else if (partData.EnPartMatch == CommonConstants.END_PART)
                    {
                        // 英字を語尾に付与する場合
                        preConvertResult = preConvertResult.Remove(index, partData.KanaName.Length).Insert(index, partData.EnConvertPart);
                    }
                }

                if (LogUtility.IsTraceEnabled)
                {
                    LogUtility.WriteTrace("【部分一致変換】変換後 カナ={0}, 漢字={1}, 英字={2}", convertData.KanaName, convertData.KanjiName, preConvertResult);
                }
            }

            return bAllEndFlag;
        }

        /// <summary>
        /// 外部ファイルを参照して物件の日本語名称の語頭・語尾に対象となる単語が存在する場合は英字に変換する。
        /// </summary>
        /// <param name="preConvertResult">部分一致変換対象</param>
        /// <param name="partData">部分変換データ</param>
        /// <param name="pGnrCode">親ジャンルコード</param>
        /// <param name="cGnrCode">子ジャンルコード</param>
        /// <param name="convertData">英字変換情報</param>
        /// <returns>部分一致変換が完了かどうか</returns>
        private static bool ConvertPart(ref string preConvertResult,
            PartConvertSettingData partData,
            ushort? pGnrCode,
            ushort? cGnrCode,
            EnConvertData convertData)
        {
            // 全文字一致の場合、他の部分一致変換対象をチェック不要となる
            bool bAllEndFlag = false;

            // 次のチェックを行うかどうか
            bool bContinueFlag = true;

            if (null != pGnrCode && null != cGnrCode &&
                (partData.C_CodeRangeFront != null || partData.C_CodeRangeAfter != null))
            {
                bContinueFlag = false;

                if (CheckRangeGnrCode(partData, pGnrCode.Value, cGnrCode.Value))
                {
                    bContinueFlag = true;
                }
                else
                {
                    // ジャンル/文字種別コードが部分変換データの範囲外となる場合、次の部分変換データの処理を行う
                    return bAllEndFlag;
                }
            }

            if (bContinueFlag)
            {
                bContinueFlag = false;

                if (partData.JapanPartMatch == CommonConstants.FRIST_PART)
                {
                    bContinueFlag = convertData.KanjiName.StartsWith(partData.KanjiName);

                    if (bContinueFlag)
                    {
                        bContinueFlag = preConvertResult.StartsWith(partData.KanaName);
                    }
                }
                else if (partData.JapanPartMatch == CommonConstants.END_PART)
                {
                    bContinueFlag = convertData.KanjiName.EndsWith(partData.KanjiName);

                    if (bContinueFlag)
                    {
                        bContinueFlag = preConvertResult.EndsWith(partData.KanaName);
                    }
                }
            }

            if (LogUtility.IsTraceEnabled)
            {
                string sContinueFlag = bContinueFlag == true ? "有" : "無";
                LogUtility.WriteTrace("【部分変換実施有無】{0}, 変換対象：{1}, {2}, {3}, 部分変換設定：{4}, {5}, {6}, {7}",
                                        sContinueFlag,
                                        convertData.KanjiName,
                                        convertData.KanaName,
                                        preConvertResult,
                                        partData.KanaName,
                                        partData.KanjiName,
                                        partData.JapanPartMatch,
                                        partData.EnConvertPart.Trim());
            }

            if (bContinueFlag)
            {
                bAllEndFlag = DoConvertPart(ref preConvertResult, partData, cGnrCode, convertData);
            }

            return bAllEndFlag;
        }

        /// <summary>
        /// 14.1.23. 部分一致変換
        /// 外部ファイルを参照して物件の日本語名称の語頭・語尾に対象となる単語が存在する場合は英字に変換する。
        /// </summary>
        /// <param name="partConvertSettingDataList">部分変換リスト</param>
        /// <param name="pGnrCode">親ジャンルコード</param>
        /// <param name="cGnrCode">子ジャンルコード</param>
        /// <param name="convertData">英字変換情報</param>
        /// <returns>部分一致変換結果</returns>
        public static string ConvertPart(
            List<PartConvertSettingData> partConvertSettingDataList,
            ushort? pGnrCode,
            ushort? cGnrCode,
            EnConvertData convertData)
        {
            string preConvertResult = convertData.KanaName;

            if (partConvertSettingDataList != null &&
                partConvertSettingDataList.Count > 0 &&
                convertData.KanjiName != null &&
                convertData.KanaName != null)
            {
                foreach (PartConvertSettingData partData in partConvertSettingDataList)
                {
                    if (ConvertPart(ref preConvertResult, partData, pGnrCode, cGnrCode, convertData))
                    {
                        // 全文字一致の場合、他の部分一致変換対象をチェック不要となる
                        break;
                    }
                }

                // 入力項目の括弧後大文字フラグがTRUEの場合、
                // 上記で変換された英字に全角括弧または半角括弧がある場合、括弧の直後の文字を大文字にする。
                if (convertData.UpperFlag)
                {
                    preConvertResult = ParenthesesCaseConversion(preConvertResult);
                }
            }

            convertData.EnName = preConvertResult;

            return preConvertResult;
        }

        /// <summary>
        /// 文字列に半角/全角括弧が存在した場合、直後のアルファベットを大文字に変換する
        /// </summary>
        /// <param name="preConvertResult">英字変換後文字列</param>
        /// <returns>変換後文字列</returns>
        private static string ParenthesesCaseConversion(string preConvertResult)
        {
            int index = 0;

            while (index < preConvertResult.Length)
            {
                index = GetParenthesesIndex(preConvertResult, index);
                if (index < 0)
                {
                    break;
                }

                if (index + 1 >= preConvertResult.Length)
                {
                    break;
                }

                string temp = preConvertResult.Substring(index + 1, 1).ToUpper();

                preConvertResult = preConvertResult.Remove(index + 1, 1).Insert(index + 1, temp);

                index = index + 2;
            }

            return preConvertResult;
        }

        /// <summary>
        /// 変換文字列から括弧の位置を取得
        /// </summary>
        /// <param name="convertResult">変換文字列</param>
        /// <param name="searchIndex">検索インデックス</param>
        /// <returns>括弧の位置のインデックス</returns>
        private static int GetParenthesesIndex(string convertResult, int searchIndex)
        {
            int parenthesesIndex = convertResult.IndexOf(Parentheses, searchIndex);
            int harfParenthesesIndex = convertResult.IndexOf(HS_Parentheses, searchIndex);

            if (parenthesesIndex < 0)
            {
                return harfParenthesesIndex;
            }

            if (harfParenthesesIndex < 0)
            {
                return parenthesesIndex;
            }

            if (parenthesesIndex < harfParenthesesIndex)
            {
                return parenthesesIndex;
            }

            return harfParenthesesIndex;
        }

        /// <summary>
        /// ジャンルコード範囲チェック
        /// </summary>
        /// <param name="partData">部分変換リスト</param>
        /// <param name="pGnrCode">親ジャンルコード</param>
        /// <param name="cGnrCode">子ジャンルコード</param>
        /// <returns>ジャンルコードが範囲内の場合はTRUE</returns>
        private static bool CheckRangeGnrCode(PartConvertSettingData partData, ushort pGnrCode, ushort cGnrCode)
        {
            return partData.P_GenreCode == pGnrCode &&
                (partData.C_CodeRangeFront == null || partData.C_CodeRangeFront <= cGnrCode) &&
                (partData.C_CodeRangeAfter == null || partData.C_CodeRangeAfter >= cGnrCode);
        }

        #endregion

        #region 14.1.25. ローマ字変換
        /// <summary>
        /// 14.1.25. ローマ字変換
        /// </summary>
        /// <param name="convertData">英字変換情報</param>
        /// <returns>変換後文字</returns>
        public static string RomajiConvert(EnConvertData convertData)
        {
            if (convertData == null ||
                convertData.KanaName == null ||
                convertData.KanjiName == null)
            {
                return null;
            }

            string result = string.Empty;

            string[] kanaSplitAry = ParseKanaWord(convertData.KanaName);

            List<MecabUnitData> mecabDataList = ParseRomaToPronounce(convertData.KanjiName, convertData.KanaName);

            if (mecabDataList != null && mecabDataList.Count > 0)
            {
                bool flag = ParseLongPronounce(kanaSplitAry, mecabDataList);
            }

            result = ConvertKanaToRoma(convertData, mecabDataList);

            return result;
        }
        #endregion

        #region カナ名称を発音毎に分解します
        /// <summary>
        /// カナ名称を発音毎に分解します
        /// </summary>
        /// <param name="kanjiName">漢字名称</param>
        /// <param name="kanaName">カナ名称</param>
        /// <returns>カナ名称を発音毎に分解した結果</returns>
        private static List<MecabUnitData> ParseRomaToPronounce(string kanjiName, string kanaName)
        {
            // 1-1)  カナ名称の分割結果
            string[] kanaSplitAry = ParseKanaWord(kanaName);

            // 1-2)  漢字名称をMecabで単語分割結果
            List<List<MecabUnitData>> mecabDataList = GetMecabDataList(kanjiName);

            // 結果記憶
            List<MecabUnitData> wordList = new List<MecabUnitData>();

            // 単語分割結果のレコード件数分の繰り返し
            foreach (List<MecabUnitData> unitList in mecabDataList)
            {
                int x = 0;

                if (unitList.Count < kanaSplitAry.Length)
                {
                    continue;
                }

                // カナ名称分割のカナ単語件数分の繰り返し
                foreach (string kana in kanaSplitAry)
                {
                    MecabUnitData kanaUnit = new MecabUnitData();

                    wordList.Add(kanaUnit);

                    kanaUnit.KanaWord = kana;
                    kanaUnit.Pronounce = string.Empty;
                    kanaUnit.Read = string.Empty;

                    bool read = false;

                    // 1-3)  カナ名称の単語がカタカナ
                    bool isKana = IsKana(kana);

                    if (isKana)
                    {
                        // 読み単語の初期値はNULL
                        string backup = string.Empty;

                        for (int i = x; i < unitList.Count; i++)
                        {
                            x = i + 1;

                            MecabUnitData unit = unitList[i];

                            string combine = unit.Read;

                            if (backup != string.Empty)
                            {
                                // 1-4)  バックアップした読み単語と処理している読み単語の結合処理
                                combine = backup + combine;
                            }

                            kanaUnit.Pronounce = kanaUnit.Pronounce + unit.Pronounce;
                            kanaUnit.Read = kanaUnit.Read + unit.Read;

                            // 1-5)  カナ名称の単語と結合した読み単語が一致
                            if (kana == combine)
                            {
                                // 完全一致で読んだ
                                read = true;
                                break;
                            }
                            else
                            {
                                // 1-8)  読み単語が短い
                                if (combine.Length < kana.Length)
                                {
                                    backup = combine;
                                }
                                else
                                {
                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        // カナ単語がカタカナではない場合、カナ名称の単語の読みと発音をNULLに設定処理を行う。
                        kanaUnit.Pronounce = null;
                        kanaUnit.Read = null;
                        x++;
                        continue;
                    }

                    if (!read)
                    {
                        break;
                    }
                }

                if (kanaSplitAry.Length == wordList.Count)
                {
                    for (int i = 0; i < kanaSplitAry.Length; i++)
                    {
                        if (wordList[i].Read != null &&
                            kanaSplitAry[i] != wordList[i].Read)
                        {
                            wordList.Clear();
                            break;
                        }
                    }

                    if (kanaSplitAry.Length == wordList.Count)
                    {
                        break;
                    }
                }

                wordList.Clear();
            }

            return wordList;
        }
        #endregion

        #region 長音変換
        /// <summary>
        /// 長音変換
        /// </summary>
        /// <param name="kanaSqlitAry">カナ名称のリスト</param>
        /// <param name="unitDataList">カナ名称を発音分解した結果</param>
        /// <returns>長音変換を行ったかのフラグ</returns>
        private static bool ParseLongPronounce(string[] kanaSqlitAry, List<MecabUnitData> unitDataList)
        {
            bool flag = false;

            for (int i = 0; i < kanaSqlitAry.Length; i++)
            {
                string kana = kanaSqlitAry[i];

                MecabUnitData kanaUnit = unitDataList[i];

                if (kanaUnit.Pronounce == null ||
                    kanaUnit.Read == null)
                {
                    continue;
                }

                if (kanaUnit.Pronounce.Length == kanaUnit.Read.Length)
                {
                    for (int j = 0; j < kanaUnit.Pronounce.Length; j++)
                    {
                        char c = kanaUnit.Pronounce[j];

                        // 長音の場合
                        if (c == 'ー')
                        {
                            if (j > 0)
                            {
                                // 発音の長音文字と同じ位置の読み文字とその一つ前の読み文字を取得する。
                                string longStr = kanaUnit.Read.Substring(j - 1, 2);

                                string readRoma = KakasiCovert(longStr);

                                readRoma = readRoma.Substring(1);

                                if (VowelAry.Contains(readRoma))
                                {
                                    string temp = kanaUnit.KanaWord;

                                    // カナ単語の同じ位置の文字を「ー」に置き換え
                                    kanaUnit.KanaWord = kanaUnit.KanaWord.Remove(j, 1).Insert(j, "ー");

                                    flag = true;

                                    // UF50001002
                                    string msg = "ローマ字変換処理に長音変換を行いました	変換前文字列={0},変換後文字列={1}";

                                    // 長音変換を行ったウォーニングメッセージ出力処理を行う
                                    LogUtility.WriteWarning(msg, temp, kanaUnit.KanaWord);
                                }
                                else
                                {
                                    continue;
                                }
                            }
                        }
                    }
                }
                else
                {
                    // UF50001001
                    string msg = "ローマ字変換処理に単語分割した結果に読みと発音の長さが違います	読み単語={0},発音単語={1}";

                    LogUtility.WriteWarning(msg, kanaUnit.Read, kanaUnit.Pronounce);
                    break;
                }
            }

            return flag;
        }
        #endregion

        #region ローマ字変換
        /// <summary>
        /// ローマ字変換
        /// </summary>
        /// <param name="convertData">変換前のデータ</param>
        /// <param name="splitUnitList">カナ名称を発音分解した結果</param>
        /// <returns>ローマ字変換結果</returns>
        private static string ConvertKanaToRoma(EnConvertData convertData, List<MecabUnitData> splitUnitList)
        {
            string result = string.Empty;

            if (splitUnitList != null && splitUnitList.Count > 0)
            {
                // 3-1)  読み文字の結合
                foreach (MecabUnitData unit in splitUnitList)
                {
                    result += unit.KanaWord;
                }
            }
            else
            {
                result = convertData.KanaName;
            }

            // 3-2)  ローマ字変換を行う
            result = KakasiCovert(result).ToLower(System.Globalization.CultureInfo.InvariantCulture);

            result = convertData.EnName.Replace(convertData.KanaName.Trim(), result.Trim()).Trim();

            if (result.Length > 0)
            {
                string c = result.Substring(0, 1);

                if (c != c.ToUpper())
                {
                    result = result.Remove(0, 1).Insert(0, c.ToUpper());
                }
            }

            int index = 0;

            // 3-3)  全角スペース直後を大文字
            while (true)
            {
                index = result.IndexOf(CommonConstants.FULL_SIZE_BLANK, index);
                if (index < 0 || index >= result.Length - 1)
                {
                    break;
                }

                char c = result[index + 1];

                result = result.Remove(index + 1, 1).Insert(index + 1, c.ToString().ToUpper());
                index++;
            }

            // 半角スペース直後を大文字
            index = 0;
            while (true)
            {
                index = result.IndexOf(CommonConstants.HALF_SIZE_BLANK, index);
                if (index < 0 || index >= result.Length - 1)
                {
                    break;
                }

                char c = result[index + 1];

                result = result.Remove(index + 1, 1).Insert(index + 1, c.ToString().ToUpper());
                index++;
            }

            // 3-4)  括弧の直後の文字を大文字
            if (convertData.UpperFlag)
            {
                result = ParenthesesCaseConversion(result);
            }

            // 3-5)  全角スペースと数字と記号を半角に変換
            result = StringUtil.FullToHalf(result);

            // 3-5)  長音をクリア
            return result.Replace(Macron, string.Empty);
        }
        #endregion

        /// <summary>
        /// Kakasiを利用してカナ文字をローマ字に変換
        /// </summary>
        /// <param name="str">カナ文字</param>
        /// <returns>ローマ字</returns>
        private static string KakasiCovert(string str)
        {
            string result = string.Empty;

            string outstr = ProcessUtil.GetCommandReturn(str, KakasiPath, KakasiOption);

            result = outstr.Replace("\r\n", string.Empty);

            return result;
        }

        #region 漢字名称をMecabで単語分割
        /// <summary>
        /// 漢字名称をMecabで単語分割
        /// </summary>
        /// <param name="kanjiName">漢字名称</param>
        /// <returns>漢字名称をMecabで単語分割した結果</returns>
        private static List<List<MecabUnitData>> GetMecabDataList(string kanjiName)
        {
            string exePath = MecabPath;
            string argument = @"-N" + MecabNBest;

            // 1-2)  漢字名称をMecabで単語分割
            string outstr = ProcessUtil.GetCommandReturn(kanjiName, exePath, argument);

            List<string> dataList = RegexUtility.SplitToList("EOS\r\n", outstr);

            List<List<MecabUnitData>> result = new List<List<MecabUnitData>>();

            if (dataList != null && dataList.Count > 0)
            {
                foreach (string strAll in dataList)
                {
                    List<MecabUnitData> unitlist = new List<MecabUnitData>();

                    string[] temp1 = StringUtil.SpiltToLines(strAll);

                    foreach (string str in temp1)
                    {
                        string[] temp2 = str.Split(',');
                        if (temp2.Length != 9)
                        {
                            continue;
                        }

                        MecabUnitData unit = new MecabUnitData();
                        unitlist.Add(unit);

                        unit.KanaWord = temp2[6];
                        unit.Read = temp2[7];
                        unit.Pronounce = temp2[8];
                    }

                    result.Add(unitlist);
                }
            }

            return result;
        }
        #endregion

        #region カナ判断
        /// <summary>
        /// カナ判断
        /// </summary>
        /// <param name="str">文字列</param>
        /// <returns>判断結果</returns>
        public static bool IsKana(string str)
        {
            for (int i = 0; i < str.Length; i++)
            {
                if (GetCharType(str[i]) == 3)
                {
                    return false;
                }
            }

            return true;
        }
        #endregion

        #region カナ名称の分割
        /// <summary>
        /// カナ名称の分割
        /// </summary>
        /// <param name="kanaWord">カナ名称</param>
        /// <returns>string[]</returns>
        private static string[] ParseKanaWord(string kanaWord)
        {
            List<string> list = new List<string>();

            int startIndex = 0;

            int x = 3;

            for (int i = 0; i < kanaWord.Length; i++)
            {
                int type = GetCharType(kanaWord[i]);

                if (type == 3)
                {
                    if (x != 3)
                    {
                        list.Add(kanaWord.Substring(startIndex, i - startIndex));
                    }

                    list.Add(kanaWord.Substring(i, 1));

                    startIndex = i + 1;
                }

                x = type;
            }

            if (x != 3)
            {
                list.Add(kanaWord.Substring(startIndex, kanaWord.Length - startIndex));
            }

            return list.ToArray();
        }
        #endregion

        #region SJIS全角文字の種類を判定します
        /// <summary>
        /// SJIS全角文字の種類を判定します
        /// </summary>
        /// <param name="c">文字</param>
        /// <returns>
        /// 1:全角カタカナ
        /// 2:全角ブランク
        /// 3:以外の文字
        /// </returns>
        public static int GetCharType(char c)
        {
            string hex = StringToHex(c.ToString());

            ushort kana = Convert.ToUInt16(hex, 16);

            // カタカナ
            ushort min = 0x8340;

            // カタカナ
            ushort max = 0x8396;

            // 長音記号
            ushort sLong = 0x815B;

            // 全角ブランク
            ushort fullBlank = 0x8140;

            if ((kana >= min && kana <= max) || kana == sLong)
            {
                return 1;
            }
            else if (kana == fullBlank)
            {
                return 2;
            }

            return 3;
        }

        /// <summary>
        /// 文字列変換16進法
        /// </summary>
        /// <param name="s">文字列</param>
        /// <returns>16進法</returns>
        private static string StringToHex(string s)
        {
            byte[] bytes = Encoding.GetEncoding("shift-jis").GetBytes(s);

            string str = string.Empty;

            for (int i = 0; i < bytes.Length; i++)
            {
                str += string.Format("{0:X}", bytes[i]);
            }

            return str.ToLower();
        }
        #endregion
    }
}

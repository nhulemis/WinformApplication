﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.DataModel;
using CREO.Fluere.Biz.Data;
using CREO.Fluere.Biz.FileOperators.Data;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// メモリのリリース処理
    /// </summary>
    public class VicsDrm07ReleaseManager
    {
        /// <summary>
        /// 最大メモリサイズ数設定(MB)
        /// </summary>
        public static double MaxMemory = 0.0;

        /// <summary>
        /// メモリのリリース
        /// </summary>
        /// <param name="addMemory">加算メモリ</param>
        public static void Release(double addMemory)
        {
            List<VicsDrmCacheData> lastTimeList =
                VicsDrm07CacheManager.GetInstance().GetLastTimeList();

            if (lastTimeList != null && lastTimeList.Count > 0)
            {
                double cacheSize = VicsDrm07CacheManager.GetInstance().GetCountObjectMemery();

                if (MaxMemory < (cacheSize + addMemory))
                {
                    LogUtility.WriteInfo("{0}", "【メモリのリリース処理を行う】");

                    LogUtility.WriteInfo("{0}: {1}MB  {2}: {3}MB",
                        "【現在のメモリ】",
                        cacheSize,
                        "【今回読込対象のサイズ】",
                        addMemory);

                    var order = from data in lastTimeList
                                orderby data.LastTime
                                select data;

                    List<VicsDrmCacheData> tempList = order.ToList();

                    while (MaxMemory < (cacheSize + addMemory) && tempList.Count > 0)
                    {
                        LogUtility.WriteInfo("{0}: {1}（{2}MB）",
                            "【開放対象となる2次メッシュ】",
                            tempList[0].MeshCode,
                            tempList[0].Size);

                        ReleaseAt(tempList[0]);

                        cacheSize = cacheSize - tempList[0].Size;

                        tempList.RemoveAt(0);
                    }
                }
            }
        }

        /// <summary>
        /// メモリのリリース
        /// </summary>
        /// <param name="cacheData">キャッシュデータ</param>
        public static void ReleaseAt(VicsDrmCacheData cacheData)
        {
            int meshCode = cacheData.MeshCode;

            List<VicsDrmCacheData> lastTimeList =
                VicsDrm07CacheManager.GetInstance().GetLastTimeList();

            Dictionary<int, List<VICSLinkFileData>> vicsLinkDataDict =
                VicsDrm07CacheManager.GetInstance().Get07VICSLinkDataDict();

            Dictionary<int, Dictionary<string, List<SDRMRoadBasic>>> drmRoadBasicDict =
                VicsDrm07CacheManager.GetInstance().Get07SDRMRoadBasicDict();

            Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> drmRoadAllDictByAllNode =
               VicsDrm07CacheManager.GetInstance().Get07SDRMRoadAllDictByAllNode();

            Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> drmRoadAllDictByBasicNode =
               VicsDrm07CacheManager.GetInstance().Get07SDRMRoadAllDictByBasicNode();

            if (vicsLinkDataDict.ContainsKey(meshCode))
            {
                if (vicsLinkDataDict[meshCode] != null)
                {
                    vicsLinkDataDict[meshCode].Clear();
                    vicsLinkDataDict[meshCode].Capacity = 0;
                    vicsLinkDataDict[meshCode].TrimExcess();
                }

                vicsLinkDataDict.Remove(meshCode);
            }

            if (drmRoadBasicDict.ContainsKey(meshCode))
            {
                if (drmRoadBasicDict[meshCode] != null)
                {
                    drmRoadBasicDict[meshCode].Clear();
                }

                drmRoadBasicDict[meshCode] = null;
                drmRoadBasicDict.Remove(meshCode);
            }

            if (drmRoadAllDictByAllNode.ContainsKey(meshCode))
            {
                if (drmRoadAllDictByAllNode[meshCode] != null)
                {
                    drmRoadAllDictByAllNode[meshCode].Clear();
                }

                drmRoadAllDictByAllNode[meshCode] = null;
                drmRoadAllDictByAllNode.Remove(meshCode);
            }

            if (drmRoadAllDictByBasicNode.ContainsKey(meshCode))
            {
                if (drmRoadAllDictByBasicNode[meshCode] != null)
                {
                    drmRoadAllDictByBasicNode[meshCode].Clear();
                }

                drmRoadAllDictByBasicNode[meshCode] = null;
                drmRoadAllDictByBasicNode.Remove(meshCode);
            }

            lastTimeList.Remove(cacheData);
        }
    }
}

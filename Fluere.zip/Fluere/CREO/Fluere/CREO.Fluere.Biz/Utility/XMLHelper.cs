﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.FW.Log;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// XMLファイル解析用の共通クラス
    /// </summary>
    public class XMLHelper : IDisposable
    {
        #region 定数定義
        /// <summary>
        /// XMLファイルストリーム
        /// </summary>
        private Stream _xmlFileStream;

        /// <summary>
        /// ファイルパス
        /// </summary>
        private string _xmlFilePath;

        /// <summary>
        /// ルートノード
        /// </summary>
        private XmlNode _rootNode;

        /// <summary>
        /// XmlDocument
        /// </summary>
        private XmlDocument _xmlDocument;

        /// <summary>
        /// Track whether Dispose has been called.
        /// </summary>
        private bool _disposed = false;
        #endregion

        /// <summary>
        /// LogManager
        /// </summary>
        private LogManager _logMgr;

        #region コンストラクタ
        /// <summary>
        /// XMLHelper
        /// </summary>
        public XMLHelper()
        {
            _logMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="xmlFileStream">解析用のXMLファイルストリーム</param>
        public XMLHelper(Stream xmlFileStream)
            : this()
        {
            // XMLファイルストリーム
            _xmlFileStream = xmlFileStream;

            // ファイルパス
            _xmlFilePath = string.Empty;

            // ルートノード
            _rootNode = null;

            _xmlDocument = null;

            GetRootNode();
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="filePath">XMLファイル</param>
        public XMLHelper(string filePath)
            : this()
        {
            _xmlFilePath = filePath;
            GetRootNode();
        }

        /// <summary>
        /// デストラクター
        /// </summary>
        ~XMLHelper()
        {
            // 破棄メソッド
            Dispose(false);
        }
        #endregion

        /// <summary>
        /// GetNodeInnerText
        /// </summary>
        /// <param name="nodePath">nodePath</param>
        /// <param name="paramList">List&lt;XMLSearchingParam&gt;</param>
        /// <returns>string</returns>
        public string GetNodeInnerText(string nodePath, List<XMLSearchingParam> paramList)
        {
            try
            {
                string strNodeFullPath = ResolvePath(nodePath, paramList);
                XmlNode node = _rootNode.SelectSingleNode(strNodeFullPath);
                return node.InnerText.Trim();
            }
            catch (NullReferenceException)
            {
                this._logMgr.WriteDebug(
                    "【XMLファイルに必要な定義が存在しません】指定したタグ間の内容の取得失敗 : "
                    + nodePath);

                return null;
            }
        }

        /// <summary>
        /// ノードリストによりインナーテキストリストを取得する
        /// </summary>
        /// <param name="contentNodeList">ノードリスト</param>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="attributeName">アトリビュート</param>
        /// <returns>インナーテキスト</returns>
        public List<string> GetNodeInnerTextListFrom(
            XmlNodeList contentNodeList, string nodePath, string attributeName)
        {
            List<string> innerTextList = new List<string>();

            try
            {
                foreach (XmlNode contentNode in contentNodeList)
                {
                    if (contentNode.Name.Equals(attributeName))
                    {
                        innerTextList.Add(contentNode.InnerText);
                    }
                }

                return innerTextList;
            }
            catch (NullReferenceException)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】属性値取得失敗 : " +
                    Path.Combine(nodePath, attributeName));

                throw new NullReferenceException(nodePath + "/" + attributeName);
            }
        }

        /// <summary>
        /// 同じ属性名の全てのノードの取得
        /// </summary>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="paramList">統計定義リスト</param>
        /// <param name="attributeName">アトリビュート名</param>
        /// <returns>List</returns>
        public List<string> GetXmlNodeAttributeValueList(
            string nodePath, List<XMLSearchingParam> paramList, string attributeName)
        {
            try
            {
                List<string> attributeList = new List<string>();
                string strNodeFullPath = nodePath;

                if (paramList != null)
                {
                    strNodeFullPath = ResolvePath(nodePath, paramList);
                }

                XmlNodeList childNodeList = _rootNode.SelectNodes(strNodeFullPath);

                foreach (XmlNode childNode in childNodeList)
                {
                    attributeList.Add(childNode.Attributes[attributeName].Value);
                }

                return attributeList;
            }
            catch (Exception)
            {
                _logMgr.WriteDebug(
                    "【XMLフォーマット不正】同じ属性名の全てのノード取得失敗 : " + nodePath);

                return null;
            }
        }

        /// <summary>
        /// ノードパスによりアトリビュートリストを取得する
        /// </summary>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="paramList">統計定義リスト</param>
        /// <returns>XmlNodeList</returns>
        public XmlNodeList GetXmlNodeAttributeValueModel(string nodePath,
                                                                List<XMLSearchingParam> paramList)
        {
            try
            {
                string strNodeFullPath = ResolvePath(nodePath, paramList);
                XmlNodeList attributeList = _rootNode.SelectNodes(strNodeFullPath);
                return attributeList;
            }
            catch (NullReferenceException)
            {
                _logMgr.WriteDebug("【XMLファイルに必要な定義が存在しません】属性値取得失敗 : " + nodePath);

               return null;
            }
        }

        /// <summary>
        /// ノードリストによりアトリビュートを取得する
        /// </summary>
        /// <param name="contentNode">Xmlノード</param>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="attributeName">アトリビュート</param>
        /// <returns>アトリビュート値</returns>
        public string GetXmlAttributeValueFromNode(
            XmlNode contentNode, string nodePath, string attributeName)
        {
            string attributeValue = string.Empty;

            try
            {
                attributeValue = contentNode.Attributes[attributeName].Value;

                return attributeValue;
            }
            catch (NullReferenceException)
            {
                _logMgr.WriteDebug("【XML項目名称不正】属性値取得失敗 : " +
                    Path.Combine(nodePath, attributeName));

                return null;
            }
        }
        
        /// <summary>
        /// ノードリストによりアトリビュートを取得する
        /// </summary>
        /// <param name="contentNodeList">ノードリスト</param>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="attributeName">アトリビュート</param>
        /// <returns>アトリビュート値</returns>
        public string GetXmlAttributeValueFromNodeList(
            XmlNodeList contentNodeList, string nodePath, string attributeName)
        {
            string attributeValue = string.Empty;

            try
            {
                foreach (XmlNode contentNode in contentNodeList)
                {
                    attributeValue = contentNode.Attributes[attributeName].Value;
                }

                return attributeValue;
            }
            catch (NullReferenceException)
            {
                _logMgr.WriteDebug("【XML項目名称不正】属性値取得失敗 : " + 
                    Path.Combine(nodePath, attributeName));

                return null;
            }
        }

        /// <summary>
        /// ノードリストによりアトリビュートリストを取得する
        /// </summary>
        /// <param name="contentNodeList">ノードリスト</param>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="attributeName">アトリビュート</param>
        /// <returns>アトリビュートリスト</returns>
        public List<string> GetXmlAttributeValueListFromNodeList(
            XmlNodeList contentNodeList, string nodePath, string attributeName)
        {
            List<string> attributeValueList = new List<string>();

            try
            {
                foreach (XmlNode contentNode in contentNodeList)
                {
                    if (contentNode.Name.Equals(attributeName))
                    {
                        attributeValueList.Add(contentNode.Value);
                    }
                }

                return attributeValueList;
            }
            catch (NullReferenceException)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】属性値取得失敗 : " +
                    Path.Combine(nodePath, attributeName));

                throw new NullReferenceException(nodePath + "/" + attributeName);
            }
        }

        /// <summary>
        /// ファイルストリームにより、エレメントを取得する
        /// </summary>
        /// <returns>エレメント</returns>
        public XElement GetXElement()
        {
            try
            {
                XElement returnNode = XElement.Load(_xmlFileStream);
                return returnNode;
            }
            catch (Exception ex)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】xmlのアイテム取得失敗");
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// resolvePath
        /// </summary>
        /// <param name="nodeSourcePath">nodeSourcePath</param>
        /// <param name="paramList"> List&lt;XMLSearchingParam&gt;</param>
        /// <returns>string</returns>
        private string ResolvePath(string nodeSourcePath, List<XMLSearchingParam> paramList)
        {
            string strReturn = string.Empty;
            string[] strNodePathArray = nodeSourcePath.Split('/');
            string strTemp = string.Empty;

            try
            {
                if (paramList != null)
                {
                    for (int i = 1; i < strNodePathArray.Length; i++)
                    {
                        string strNodePath = strNodePathArray[i];
                        strTemp = string.Empty;

                        foreach (XMLSearchingParam param in paramList)
                        {
                            if (param.XmlNodeName == strNodePath)
                            {
                                strTemp =
                                   strNodePath + "[@" + param.Attribute + "='" + param.Value + "']";
                            }
                        }

                        if (strTemp == string.Empty)
                        {
                            strReturn = strReturn + "/" + strNodePath;
                        }
                        else
                        {
                            strReturn = strReturn + "/" + strTemp;
                        }
                    }
                }
                else
                {
                    strReturn = nodeSourcePath;
                }

                return strReturn;
            }
            catch (Exception ex)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】xmlのフォーマット不正");
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// ルートノードにより、エレメントを取得する
        /// </summary>
        /// <returns>エレメント</returns>
        public XElement GetXElementFromRootNode()
        {
            try
            {
                XDocument xDoc = new XDocument();
                
                using (XmlWriter xmlWriter = xDoc.CreateWriter())
                {
                    _rootNode.WriteTo(xmlWriter);
                }

                return xDoc.Root;
            }
            catch (Exception ex)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】xmlのルートノード取得失敗");
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// ルートノードを取得する
        /// </summary>
        private void GetRootNode()
        {
            try
            {
                _xmlDocument = new XmlDocument();

                if (_xmlFilePath != string.Empty)
                {
                    _xmlDocument.Load(_xmlFilePath);
                }
                else
                {
                    _xmlDocument.Load(_xmlFileStream);
                }

                _rootNode = _xmlDocument.DocumentElement;
            }
            catch (IOException)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】ノード作成失敗 : " + _xmlFilePath);
                throw;
            }
            catch (Exception ex)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】ノード作成失敗 : " + _xmlFilePath);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// XMLファイル作成
        /// </summary>
        /// <param name="filePath">XMLファイルパス</param>
        /// <param name="rootName">XMLルート名称</param>
        /// <returns>bool</returns>
        public bool CreateXMLFile(string filePath, string rootName)
        {
            try
            {
                _xmlFilePath = filePath;

                XmlTextWriter xml = new XmlTextWriter(_xmlFilePath, System.Text.Encoding.UTF8);
                xml.WriteStartDocument();
                xml.Formatting = Formatting.Indented;
                xml.WriteStartElement(rootName);
                xml.Close();

                GetRootNode();

                return true;
            }
            catch (Exception ex)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】作成失敗 : " + _xmlFilePath);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// XMLノード削除
        /// </summary>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="deletenodeName">ノード名称</param>
        public void DeleteXmlNode(string nodePath, string deletenodeName)
        {
            try
            {
                XmlNode node = _rootNode.SelectSingleNode(nodePath);
                XmlElement xe = (XmlElement)node;

                foreach (XmlNode nodeItem in xe.ChildNodes)
                {
                    if (nodeItem.Name == deletenodeName)
                    {
                        xe.RemoveChild(nodeItem);
                    }
                }
            }
            catch (Exception ex)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】ノード削除失敗 : " + deletenodeName);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// XMLファイルに新ノードとノードの属性新規作成
        /// </summary>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="nodeName">ノード名称</param>
        /// <param name="attributeName">属性名称</param>
        /// <param name="value">属性値</param>
        public void AddXmlNode(string nodePath, string nodeName, string attributeName, string value)
        {
            try
            {
                XmlNode node = _rootNode.SelectSingleNode(nodePath);
                XmlElement xe1 = _xmlDocument.CreateElement(nodeName);
                if (attributeName == string.Empty)
                {
                    xe1.InnerText = value;
                }
                else
                {
                    xe1.SetAttribute(attributeName, value);
                }

                node.AppendChild(xe1);
            }
            catch (Exception ex)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】属性値設定失敗 : " + attributeName);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// XMLファイルに新ノードと複数属性新規作成
        /// </summary>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="nodeName">ノード名称</param>
        /// <param name="attributes">属性名称―値列コード</param>
        public void AddXmlNode(
            string nodePath, string nodeName, Dictionary<string, string> attributes)
        {
            try
            {
                XmlNode node = _rootNode.SelectSingleNode(nodePath);
                XmlElement xe1 = _xmlDocument.CreateElement(nodeName);

                foreach (KeyValuePair<string, string> item in attributes)
                {
                    if (string.IsNullOrEmpty(item.Key))
                    {
                        xe1.InnerText = item.Value;
                    }
                    else
                    {
                        xe1.SetAttribute(item.Key, item.Value);
                    }
                }

                node.AppendChild(xe1);
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// ノード更新
        /// </summary>
        /// <param name="nodePath">ノードパス</param>
        /// <param name="nodeName">ノード名称</param>
        /// <param name="attributeName">属性名称</param>
        /// <param name="value">属性値</param>
        public void UpdateXmlNode(
            string nodePath, string nodeName, string attributeName, string value)
        {
            try
            {
                // 更新ノード取得
                XmlNode node = _rootNode.SelectSingleNode(nodePath);

                // 更新ノード存在しない場合
                if (node == null)
                {
                    return;
                }
                else
                {
                    // 更新ノード存在する場合
                    XmlElement xe = (XmlElement)node;

                    if (attributeName == string.Empty)
                    {
                        xe.InnerText = value;
                    }
                    else
                    {
                        xe.SetAttribute(attributeName, value);
                    }
                }
            }
            catch (Exception ex)
            {
                _logMgr.WriteDebug("【XMLフォーマット不正】ノード追加失敗 : " + nodeName);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// XMLファイル保存
        /// </summary>
        public void SaveXML()
        {
            try
            {
                _xmlDocument.Save(_xmlFilePath);
            }
            catch (Exception ex)
            {
                _logMgr.WriteDebug("【XMLファイル保存】ファイル保存失敗 : " + _xmlFilePath);
                throw new Exception(ex.Message);
            }
        }

        /// <summary>
        /// Dispose
        /// </summary>
        public void Dispose()
        {
            Dispose(true);

            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// 破棄メソッド
        /// </summary>
        /// <param name="disposing">破棄フラグ</param>
        protected virtual void Dispose(bool disposing)
        {
            // オブジェクト破棄出来る判断
            if (!this._disposed)
            {
                // 破棄フラグTrueの場合、すべてオブジェクトを破棄する
                // そして、資源をリリース.
                if (disposing)
                {
                    this._logMgr = null;
                    this._rootNode = null;
                    this._xmlDocument = null;
                    this._xmlFilePath = null;

                    // 資源をリリース.
                    if (this._xmlFileStream != null)
                    {
                        this._xmlFileStream.Dispose();
                    }
                }

                // オブジェクト破棄したフラグ設定.
                _disposed = true;
            }
        }
    }
}

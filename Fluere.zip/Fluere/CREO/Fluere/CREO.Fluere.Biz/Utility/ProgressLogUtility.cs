﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 処理進捗用ログ
    /// </summary>
    public class ProgressLogUtility
    {
        /// <summary>
        /// 処理レコード総数
        /// </summary>
        private int _totalCount = 0;

        /// <summary>
        /// 当前処理のレコードIndex
        /// </summary>
        private int _counter = 0;

        /// <summary>
        /// ログ出力のレート
        /// </summary>
        private double _stepRate = 0.1;

        /// <summary>
        /// 次ログ出力のレコード数
        /// </summary>
        private int _nextStep = 0;

        /// <summary>
        /// 処理名
        /// </summary>
        private string _processName = string.Empty;

        /// <summary>
        /// 処理単位名
        /// </summary>
        private string _processUnitName = string.Empty;

        /// <summary>
        /// 処理進捗用ログ
        /// </summary>
        /// <param name="processName">処理名</param>
        /// <param name="processUnitName">処理単位名</param>
        /// <param name="totalCount">処理レコード総数</param>
        /// <param name="stepRate">ログ出力のレート：ディフォルトは0.1です</param>
        public ProgressLogUtility(string processName, string processUnitName, int totalCount, double stepRate = 0.1)
        {
            _processName = processName;
            _processUnitName = processUnitName;
            _totalCount = totalCount;
            _stepRate = stepRate;
            _nextStep = (int)(_stepRate * _totalCount);
        }

        /// <summary>
        /// 処理開始
        /// 「【処理名】処理開始しました。」をログに出力する。
        /// </summary>
        public void WriteStart()
        {
            LogUtility.WriteInfo("【{0}】処理開始：総計{1}{2}", _processName, _totalCount, _processUnitName);
            _counter = 0;
        }

        /// <summary>
        /// 一つレコードを処理する
        /// ロープの開始位置を呼び出し
        /// </summary>
        /// <param name="count">今回処理数</param>
        public void Process(int count = 1)
        {
            if (_totalCount == 0)
            {
                return;
            }

            _counter = _counter + count;

            if (_counter >= _nextStep)
            {
                double currentRate = _counter * 1.0 / _totalCount;
                _nextStep = (int)((currentRate + _stepRate) * _totalCount);
                LogUtility.WriteInfo("【{0}】処理進捗：{1}/{2} {3}", _processName, _counter, _totalCount, _processUnitName);
            }
        }

        /// <summary>
        /// 処理終了
        /// 「【処理名】処理終了しました。」をログに出力する。
        /// </summary>
        public void WriteEnd()
        {
            _counter = 0;
            LogUtility.WriteInfo("【{0}】処理終了", _processName);
        }
    }
}

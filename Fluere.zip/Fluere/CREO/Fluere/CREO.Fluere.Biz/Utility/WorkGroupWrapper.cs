﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using CREO.DataModel;
using CREO.DS;
using CREO.DS.Cache;
using CREO.Fluere.Biz.BusinessObject;
using CREO.Fluere.Biz.BusinessObject.Data;
using CREO.FW.TMIGeometry;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 変更データ情報を保存する
    /// </summary>
    public class CommWorkGroupData
    {
        #region XMLノード名称(固定分)
        /// <summary>
        /// ノード:datas
        /// </summary>
        public const string FIXED_DATAS = "datas";

        /// <summary>
        /// ノード:data
        /// </summary>
        public const string FIXED_DATA = "data";

        /// <summary>
        /// 属性:oid
        /// </summary>
        public const string FIXED_OID = "oid";

        /// <summary>
        /// 属性:typeid
        /// </summary>
        public const string FIXED_TYPEID = "typeid";

        /// <summary>
        /// 属性:editFlag
        /// </summary>
        public const string FIXED_EDITFLAG = "editflag";

        /// <summary>
        /// 属性:latestflag
        /// </summary>
        public const string FIXED_LATESTFLAG = "latestflag";

        /// <summary>
        /// 属性:swgid
        /// </summary>
        public const string FIXED_SWGID = "swgid";

        /// <summary>
        /// ノード:geometry
        /// </summary>
        public const string FIXED_GEOMETRY = "geometry";

        /// <summary>
        /// ノード:relatelist
        /// </summary>
        public const string FIXED_RELATELIST = "relatelist";

        /// <summary>
        /// ノード:relate
        /// </summary>
        public const string FIXED_RELATE = "relate";

        /// <summary>
        /// 属性:spatialentityid
        /// </summary>
        public const string FIXED_SPATIALENTITYID = "spatialentityid";

        /// <summary>
        /// ノード:xmlproperty
        /// </summary>
        public const string FIXED_XMLPROPERTY = "xmlproperty";
        #endregion

        #region 判定用の定数
        /// <summary>
        /// 新規:0
        /// </summary>
        public const ushort EDIT_NEW = 0;

        /// <summary>
        /// 変更:1
        /// </summary>
        public const ushort EDIT_CHANGE = 1;

        /// <summary>
        /// 削除:2
        /// </summary>
        public const ushort EDIT_DELETE = 2;

        /// <summary>
        /// 新規編集:3
        /// </summary>
        public const ushort EDIT_NEW_CHANGE = 3;

        /// <summary>
        /// 新規削除:4
        /// </summary>
        public const ushort EDIT_NEW_DELETE = 4;

        /// <summary>
        /// 最新フラグ(編集中):0
        /// </summary>
        public const ushort LATEST_EDITING = 0;

        /// <summary>
        /// 最新フラグ(最新):1
        /// </summary>
        public const ushort LATEST_NEWEST = 1;
        #endregion

        #region XML文字列から、関連情報を分析する用
        /// <summary>
        /// POINT⇔COORDINATE変換用Regex
        /// </summary>
        private static Regex pointRegex = new Regex(@"POINT\s*\((.+?)\)", RegexOptions.Singleline | RegexOptions.IgnoreCase);

        /// <summary>
        /// LINESTRING⇔COORDINATE変換用Regex
        /// </summary>
        private static Regex linestringRegex = new Regex(@"LINESTRING\s*\((.+?)\)", RegexOptions.Singleline | RegexOptions.IgnoreCase);

        /// <summary>
        /// MULTIPOINT⇔COORDINATE変換用Regex
        /// </summary>
        private static Regex multipointRegex = new Regex(@"MULTIPOINT\s*\((.+\))", RegexOptions.Singleline | RegexOptions.IgnoreCase);

        /// <summary>
        /// POLYGON⇔COORDINATE変換用Regex
        /// </summary>
        private static Regex polygonRegex = new Regex(@"POLYGON\s*\(\((.+?)\)\)", RegexOptions.Singleline | RegexOptions.IgnoreCase);
        #endregion

        #region インスタンスを生成する用関数
        /// <summary>
        /// 変更データ情報クラスを新規する関数を定義する
        /// </summary>
        public static CreateNewChangedDataDelegate CreateNewChangedDataFunc = CreateDefaultNewChangedData;
        #endregion

        #region 新規削除データの通知関数
        /// <summary>
        /// 変更データ情報クラスを新規する関数を定義する
        /// </summary>
        public static KeepNewDeleteDataDelegate KeepNewDeleteDataFunc = null;
        #endregion

        #region インスタンスを生成する用関数の型を定義する
        /// <summary>
        /// 変更データ情報クラスを新規する用delegateを定義する
        /// </summary>
        /// <param name="dataModelTypeID">データモデルタイプID</param>
        /// <returns>変更データ情報クラス</returns>
        public delegate CommWorkGroupData CreateNewChangedDataDelegate(int dataModelTypeID);
        #endregion

        #region インスタンスを生成する用関数の型を定義する
        /// <summary>
        /// 新規削除データの通知用delegateを定義する
        /// </summary>
        /// <param name="newDeleteData">新規削除データ</param>
        public delegate void KeepNewDeleteDataDelegate(CommWorkGroupData newDeleteData);
        #endregion

        #region 差分データのキー情報
        /// <summary>
        /// OID
        /// </summary>
        public ulong OID { get; private set; }

        /// <summary>
        /// タイプID
        /// </summary>
        public int TypeId { get; private set; }

        /// <summary>
        /// 編集フラグ
        /// </summary>
        protected ushort EditFlag { get; private set; }

        /// <summary>
        /// 更新状態フラグ
        /// </summary>
        public ushort LatestFlag { get; private set; }

        /// <summary>
        /// サブワークグループID
        /// </summary>
        public ulong Swgid { get; private set; }

        /// <summary>
        /// 依存対象リスト
        /// </summary>
        public List<ulong> DependingOidList { get; private set; }

        /// <summary>
        /// 座標リスト
        /// </summary>
        public List<Coordinate> GeometryList { get; private set; }

        /// <summary>
        /// 新規データですか
        /// </summary>
        public bool IsNew { get; private set; }

        /// <summary>
        /// 更新データですか
        /// </summary>
        public bool IsUpdate { get; private set; }

        /// <summary>
        /// 削除データですか
        /// </summary>
        public bool IsDelete { get; private set; }

        /// <summary>
        /// 実の新規削除データですか
        /// </summary>
        public bool IsTrueNewDelete { get; private set; }
        #endregion

        #region 差分データから、属性値を取得
        /// <summary>
        /// 編集データのOIDを取得する
        /// </summary>
        /// <param name="item">編集データ</param>
        /// <returns>OID</returns>
        protected static ulong GetOID(XElement item)
        {
            return ulong.Parse(item.Attribute(CommWorkGroupData.FIXED_OID).Value);
        }

        /// <summary>
        /// 編集データのタイプIDを取得する
        /// </summary>
        /// <param name="item">編集データ</param>
        /// <returns>タイプID</returns>
        protected static int GetTypeID(XElement item)
        {
            return int.Parse(item.Attribute(CommWorkGroupData.FIXED_TYPEID).Value);
        }

        /// <summary>
        /// 編集データの編集フラグを取得する
        /// </summary>
        /// <param name="item">編集データ</param>
        /// <returns>編集フラグ</returns>
        protected static ushort GetEditFlag(XElement item)
        {
            return ushort.Parse(item.Attribute(CommWorkGroupData.FIXED_EDITFLAG).Value);
        }

        /// <summary>
        /// 編集データの更新状態フラグを取得する
        /// </summary>
        /// <param name="item">編集データ</param>
        /// <returns>更新状態フラグ</returns>
        protected static ushort GetLatestFlag(XElement item)
        {
            return ushort.Parse(item.Attribute(CommWorkGroupData.FIXED_LATESTFLAG).Value);
        }

        /// <summary>
        /// 編集データのサブワークグループIDを取得する
        /// </summary>
        /// <param name="item">編集データ</param>
        /// <returns>サブワークグループID</returns>
        protected static ulong GetSwgid(XElement item)
        {
            return ulong.Parse(item.Attribute(CommWorkGroupData.FIXED_SWGID).Value);
        }

        /// <summary>
        /// 編集データの依存対象を取得する
        /// </summary>
        /// <param name="item">編集データ</param>
        /// <returns>依存対象一覧</returns>
        protected static List<ulong> GetDependingItemsOid(XElement item)
        {
            List<ulong> retList = null;

            XElement relatesXml = item.Element(CommWorkGroupData.FIXED_RELATELIST);
            if (relatesXml != null)
            {
                retList = new List<ulong>();

                // データをキャッシュに保存する
                IEnumerable<XElement> allRelates = relatesXml.Elements(CommWorkGroupData.FIXED_RELATE);
                foreach (var relateItem in allRelates)
                {
                    retList.Add(ulong.Parse(relateItem.Attribute(CommWorkGroupData.FIXED_SPATIALENTITYID).Value));
                }
            }

            return retList;
        }

        /// <summary>
        /// 編集データの座標を取得する
        /// </summary>
        /// <param name="item">編集データ</param>
        /// <returns>依存対象一覧</returns>
        protected static List<Coordinate> GetGeometryList(XElement item)
        {
            List<Coordinate> retList = null;

            XElement relatesXml = item.Element(CommWorkGroupData.FIXED_GEOMETRY);
            if (relatesXml != null)
            {
                string coordinateStr = relatesXml.Value;
                if (pointRegex.IsMatch(coordinateStr))
                {
                    retList = new List<Coordinate>();
                    retList.Add(CoordinateLib.ParsePointGeometryToCoordinate(coordinateStr));
                }
                else if (linestringRegex.IsMatch(coordinateStr))
                {
                    retList = CoordinateLib.ParsePolylineGeometryToCoordinate(coordinateStr);
                }
                else if (multipointRegex.IsMatch(coordinateStr))
                {
                    retList = CoordinateLib.ParseMultiPointGeometryToCoordinate(coordinateStr);
                }
                else if (polygonRegex.IsMatch(coordinateStr))
                {
                    retList = CoordinateLib.ParsePolygonGeometryToCoordinate(coordinateStr);
                }
                else
                {
                    string message = string.Format("※想定外座標があるので、無視する。OID:{0} geometry:{1}",
                        GetOID(item),
                        coordinateStr);
                    LogUtility.WriteWarning(message);
                }
            }

            return retList;
        }
        #endregion

        #region 差分データを保存する外部関数
        /// <summary>
        /// 編集データをキャッシュに保存する
        /// </summary>
        /// <param name="changedDataDict">キャッシュ</param>
        /// <param name="changedXmlDatas">編集データ</param>
        /// <param name="subWorkGroupId">子作業グループID</param>
        /// <param name="isSubDiff">子作業グループの差分ですか</param>
        public static void CacheChangedDatas(Dictionary<ulong, CommWorkGroupData> changedDataDict, XElement changedXmlDatas, ulong subWorkGroupId, bool? isSubDiff)
        {
            // データをキャッシュに保存する
            IEnumerable<XElement> allChangedDatas = changedXmlDatas.Element(CommWorkGroupData.FIXED_DATAS).Elements(CommWorkGroupData.FIXED_DATA);
            foreach (var item in allChangedDatas)
            {
                SetChangedData(changedDataDict, item, subWorkGroupId, isSubDiff);
            }
        }
        #endregion

        #region 内部関数
        /// <summary>
        /// データモデルタイプを指定し、変更データ情報クラスを新規する
        /// </summary>
        /// <param name="dataModelTypeID">データモデルタイプID</param>
        /// <returns>変更データ情報クラス</returns>
        protected static CommWorkGroupData CreateDefaultNewChangedData(int dataModelTypeID)
        {
            return new CommWorkGroupData();
        }

        /// <summary>
        /// 編集データをキャッシュに保存する
        /// </summary>
        /// <param name="changedDataDict">キャッシュに保存する用Dictionary</param>
        /// <param name="item">編集データ</param>
        /// <param name="subWorkGroupId">子作業グループID</param>
        /// <param name="isSubDiff">子作業グループの差分ですか</param>
        protected static void SetChangedData(Dictionary<ulong, CommWorkGroupData> changedDataDict, XElement item, ulong subWorkGroupId, bool? isSubDiff)
        {
            // 新規、変更、削除、新規編集、新規削除以外の場合、対象外
            ushort itemEditFlag = GetEditFlag(item);
            if (itemEditFlag > CommWorkGroupData.EDIT_NEW_DELETE)
            {
                return;
            }

            // 編集中、新規編集以外の場合、対象外
            ushort itemLatestFlag = GetLatestFlag(item);
            ulong newSubWorkGroupId = GetSwgid(item);
            if (((isSubDiff == null || isSubDiff == true) && itemLatestFlag == CommWorkGroupData.LATEST_EDITING && newSubWorkGroupId == subWorkGroupId) ||
                ((isSubDiff == null || isSubDiff == false) && itemLatestFlag == CommWorkGroupData.LATEST_NEWEST))
            {
                // 子作業グループでの変化分と親作業グループでの変化済分
                ulong itemOid = GetOID(item);
                int itemTypeID = GetTypeID(item);

                if (changedDataDict.ContainsKey(itemOid))
                {
                    changedDataDict[itemOid].SetByNewXml(item, subWorkGroupId);
                }
                else
                {
                    CommWorkGroupData curCommChangedData = CreateNewChangedDataFunc(itemTypeID);
                    curCommChangedData.SetByXml(item, subWorkGroupId);
                    changedDataDict.Add(itemOid, curCommChangedData);
                }
            }
        }

        /// <summary>
        /// 更新情報を更新する
        /// </summary>
        /// <param name="item">更新情報</param>
        /// <param name="subWorkGroupId">子作業グループID</param>
        protected void SetByNewXml(XElement item, ulong subWorkGroupId)
        {
            ulong newSubWorkGroupId = GetSwgid(item);

            if (newSubWorkGroupId == subWorkGroupId)
            {
                // 子作業グループでの差分が優先
                SetByXml(item, subWorkGroupId);
            }

            string message = string.Format("※変更データが重複であるので、子作業グループでの変化分を使用する。OID:{0} TypeId:{1} SWGID:{2} SWGID:{3}",
                this.OID,
                this.TypeId,
                this.Swgid,
                newSubWorkGroupId);
            LogUtility.WriteDebug(message);
        }

        /// <summary>
        /// 更新情報を設定する
        /// </summary>
        /// <param name="item">更新情報</param>
        /// <param name="subWorkGroupId">子作業グループID</param>
        protected void SetByXml(XElement item, ulong subWorkGroupId)
        {
            this.OID = GetOID(item);
            this.TypeId = GetTypeID(item);
            this.EditFlag = GetEditFlag(item);
            this.LatestFlag = GetLatestFlag(item);
            this.Swgid = GetSwgid(item);
            this.DependingOidList = GetDependingItemsOid(item);
            this.GeometryList = GetGeometryList(item);

            this.IsNew = (this.EditFlag == CommWorkGroupData.EDIT_NEW) || (this.EditFlag == CommWorkGroupData.EDIT_NEW_CHANGE);
            this.IsUpdate = this.EditFlag == CommWorkGroupData.EDIT_CHANGE;
            this.IsDelete = this.EditFlag == CommWorkGroupData.EDIT_DELETE;
            this.IsTrueNewDelete = this.EditFlag == CommWorkGroupData.EDIT_NEW_DELETE;

            // 新規削除分のデータの通知
            if (this.IsTrueNewDelete && KeepNewDeleteDataFunc != null)
            {
                KeepNewDeleteDataFunc(this);
            }
        }
        #endregion

        #region 属性関数
        /// <summary>
        /// 編集フラグを取得する（注意：新規編集データが新規または編集データをなる可能性がある）
        /// </summary>
        /// <returns>編集フラグ</returns>
        public ushort GetEditFlag()
        {
            return this.EditFlag;
        }

        /// <summary>
        /// 補正後の編集フラグを取得する（事前に、ModifyNewChange関数を使用して、）
        /// </summary>
        /// <returns>編集フラグ</returns>
        public ushort GetRevisionEditFlag()
        {
            if (this.IsNew)
            {
                return CommWorkGroupData.EDIT_NEW;
            }

            if (this.IsUpdate)
            {
                return CommWorkGroupData.EDIT_CHANGE;
            }

            if (this.IsDelete)
            {
                return CommWorkGroupData.EDIT_DELETE;
            }
            
            return this.EditFlag;
        }

        /// <summary>
        /// 新規または新規編集データを編集データにする（ディフォルトは新規データとなる）
        /// </summary>
        /// <param name="isUpdate">編集データとなるか</param>
        public void ModifyNew(bool isUpdate)
        {
            // 下記のケースを考慮すて、編集データとなる。外部で補正するが必要
            //  親ワークグループWG01、子ワークグループSWG01でDataModelAを新規して、子ワークグループSWG01をコミットしました。
            //  親ワークグループWG01、子ワークグループSWG02でDataModelAを編集して、WG_OBJECTに保存している。（Editflagが新規または新規編集となる。業務上に編集データと認識したい）
            if (isUpdate)
            {
                this.IsNew = false;
                this.IsUpdate = true;
            }
            else
            {
                this.IsNew = true;
                this.IsUpdate = false;
            }
        }

        /// <summary>
        /// 新規削除データを実の削除データにする
        /// </summary>
        /// <param name="isDelete">実の削除データとなるか</param>
        public void ModifyNewDelete(bool isDelete)
        {
            // 下記のケースを考慮すて、編集データとなる。外部で補正するが必要
            //  親ワークグループWG01、子ワークグループSWG01でDataModelAを新規して、子ワークグループSWG01をコミットしました。
            //  親ワークグループWG01、子ワークグループSWG02でDataModelAを削除して、WG_OBJECTに保存している。（Editflagが新規削除となる。業務上に削除データと認識したい）
            if (isDelete)
            {
                this.IsDelete = true;
                this.IsTrueNewDelete = false;
            }
            else
            {
                this.IsDelete = false;
                this.IsTrueNewDelete = true;
            }
        }
        #endregion

        #region override関数
        /// <summary>
        /// 指定した Object が、現在の Object と等しいかどうかを判断する。
        /// </summary>
        /// <param name="obj">現在のオブジェクトと比較するオブジェクト。</param>
        /// <returns>
        /// 指定した Object が現在の Object と等しい場合は true。それ以外の場合は false。
        /// </returns>
        public override bool Equals(object obj)
        {
            CommWorkGroupData objCommWorkGroupData = obj as CommWorkGroupData;
            if (objCommWorkGroupData != null)
            {
                return this.OID.Equals(objCommWorkGroupData.OID);
            }

            return base.Equals(obj);
        }

        /// <summary>
        /// 特定の型のハッシュ関数として機能である。
        /// </summary>
        /// <returns>Object のハッシュ コード。</returns>
        public override int GetHashCode()
        {
            return OID.GetHashCode();
        }
        #endregion
    }

    /// <summary>
    /// ワークグループデータを検索するクラス
    /// <para>IDisposable インターフェイスを実装する。</para>
    /// </summary>
    public class WorkGroupWrapper : IDisposable
    {
        #region コンストラクター
        /// <summary>
        /// コンストラクター
        /// </summary>
        protected WorkGroupWrapper()
        {
        }

        /// <summary>
        /// コンストラクター
        /// </summary>
        /// <param name="dataSourceID">データサービスID</param>
        /// <param name="workGroupID">グループ</param>
        /// <param name="subWorkGroupID">子グループID</param>
        public WorkGroupWrapper(string dataSourceID, ulong workGroupID, ulong subWorkGroupID)
        {
            this.DataSourceID = dataSourceID;
            this.WorkGroupID = workGroupID;
            this.SubWorkGroupID = subWorkGroupID;
            
            this.AfterDS = null;
            this.BeforeDS = null;

            this.DiffDataDict = null;
            this.NewDeleteDataDict = null;
        }
        #endregion

        #region プロパティ
        /// <summary>
        /// データサービスID
        /// </summary>
        public string DataSourceID { get; private set; }

        /// <summary>
        /// グループ
        /// </summary>
        public ulong WorkGroupID { get; private set; }

        /// <summary>
        /// 子グループID
        /// </summary>
        public ulong SubWorkGroupID { get; private set; }

        /// <summary>
        /// データソース（変更後）
        /// </summary>
        public DataServiceWrapper AfterDS { get; private set; }

        /// <summary>
        /// データソース（変更前）
        /// </summary>
        public DataServiceWrapper BeforeDS { get; private set; }

        /// <summary>
        /// 差分データを保存する
        /// </summary>
        public Dictionary<ulong, CommWorkGroupData> DiffDataDict { get; private set; }

        /// <summary>
        /// 新規削除データを保存する
        /// </summary>
        private Dictionary<ulong, CommWorkGroupData> NewDeleteDataDict { get; set; }

        /// <summary>
        /// 子作業グループの差分のみを対象となるフラグ
        /// </summary>
        public bool IsOnlySubWorkgroup { get; private set; }
        #endregion

        #region 差分の件数を取得する用
        /// <summary>
        /// 編集データの数を取得する
        /// </summary>
        /// <param name="changedXmlDatas">編集データ</param>
        /// <returns>編集データの数</returns>
        public static int GetChangedDataCount(XElement changedXmlDatas)
        {
            int retCount = 0;
            if (changedXmlDatas != null)
            {
                XElement datasXml = changedXmlDatas.Element(CommWorkGroupData.FIXED_DATAS);
                if (datasXml != null)
                {
                    retCount = datasXml.Nodes().Count();
                }
            }

            return retCount;
        }
        #endregion

        #region リソース管理
        /// <summary>
        /// IDisposableの実装をする。
        /// Disposeの時に、ファイルを閉じる処理を自動に行う。
        /// </summary>
        public void Dispose()
        {
            ReleaseAll();
        }

        /// <summary>
        /// リソースを解放する
        /// </summary>
        public void ReleaseAll()
        {
            if (DiffDataDict != null)
            {
                DiffDataDict.Clear();
            }

            ReleaseBeforeDS();
            ReleaseAfterDS();
        }

        /// <summary>
        /// 変更前のデータソースを初期化する
        /// </summary>
        public void InitBeforeDS()
        {
            if (BeforeDS == null)
            {
                DataService curDataService = null;
                if (this.IsOnlySubWorkgroup)
                {
                    // 親作業グループを透過して、変更前データを取得する
                    SystemServiceData data = new SystemServiceData();
                    data.DataSourceID = DataSourceID;
                    data.WorkGroupID = WorkGroupID;
                    data.SubWorkGroupID = 0;
                    curDataService = DataServiceManager.GetDataServcie(data);
                }
                else
                {
                    // 作業グループを透過せず、変更前データを取得する
                    curDataService = DataServiceManager.GetDataServcie(DataSourceID);
                }

                BeforeDS = new DataServiceWrapper(curDataService);
            }
        }

        /// <summary>
        /// 変更後のデータソースを初期化する
        /// </summary>
        public void InitAfterDS()
        {
            if (AfterDS == null)
            {
                SystemServiceData data = new SystemServiceData();
                data.DataSourceID = DataSourceID;
                data.WorkGroupID = WorkGroupID;
                data.SubWorkGroupID = SubWorkGroupID;

                DataService curDataService = DataServiceManager.GetDataServcie(data);
                AfterDS = new DataServiceWrapper(curDataService);
            }
        }

        /// <summary>
        /// 変更前のデータソースを解放する
        /// </summary>
        public void ReleaseBeforeDS()
        {
            if (BeforeDS != null)
            {
                try
                {
                    BeforeDS.Dispose();
                }
                catch (Exception ex)
                {
                    LogUtility.WriteError(ex);
                }
                finally
                {
                    BeforeDS = null;
                }
            }
        }

        /// <summary>
        /// 変更後のデータソースを解放する
        /// </summary>
        public void ReleaseAfterDS()
        {
            if (AfterDS != null)
            {
                try
                {
                    AfterDS.Dispose();
                }
                catch (Exception ex)
                {
                    LogUtility.WriteError(ex);
                }
                finally
                {
                    AfterDS = null;
                }
            }
        }
        #endregion

        #region 差分データを取得
        /// <summary>
        /// 新規削除データを保存する関数
        /// </summary>
        /// <param name="newDeleteData">新規削除データ</param>
        protected void KeepNewDeleteData(CommWorkGroupData newDeleteData)
        {
            if (!this.NewDeleteDataDict.ContainsKey(newDeleteData.OID))
            {
                this.NewDeleteDataDict.Add(newDeleteData.OID, newDeleteData);
            }
        }

        /// <summary>
        /// 差分データのContainerを初期化
        /// </summary>
        protected void InitDiffDataContainer()
        {
            this.DiffDataDict = new Dictionary<ulong, CommWorkGroupData>();
            this.NewDeleteDataDict = new Dictionary<ulong, CommWorkGroupData>();

            if (CommWorkGroupData.KeepNewDeleteDataFunc == null)
            {
                CommWorkGroupData.KeepNewDeleteDataFunc = this.KeepNewDeleteData;
            }
        }

        /// <summary>
        /// タイプIDとメッシュコードを指定し、子、親作業グループの差分のみを取得する
        /// </summary>
        /// <param name="typeIDSet">タイプID</param>
        /// <param name="meshCode">メッシュコード</param>
        /// <returns>差分データ</returns>
        protected XElement GetAllWorkgroupData(HashSet<int> typeIDSet, string meshCode = null)
        {
            InitAfterDS();

            // 編集DBからWGC内の処理対象データの取得
            IWorkGroupManager wgm = this.AfterDS.InnerDataService.GetWorkgroupManager();
            QueryObjectUnitCondition subWGQuery = new QueryObjectUnitCondition();

            // オブジェクトタイプ
            QueryObjectUnitCondtionExpression subWGQueryCond1 = new QueryObjectUnitCondtionExpression(ObjectUnitItems.Type,
                                                    QueryObjectUnitOperator.In,
                                                    typeIDSet.ToArray());

            // 作業グループID(WGID)
            QueryObjectUnitCondtionExpression subWGQueryCond2 = new QueryObjectUnitCondtionExpression(ObjectUnitItems.WGID,
                                                            QueryObjectUnitOperator.Equal,
                                                                this.WorkGroupID);

            if (string.IsNullOrEmpty(meshCode))
            {
                subWGQuery.ConditionExpression = subWGQueryCond2.And(subWGQueryCond1, subWGQueryCond2);
            }
            else
            {
                string area = GeometryUtil.ParseCoordinateRectToPolygonGeometryString(MeshCodeManager.GetUnManagedMeshRect(meshCode));
                QueryObjectUnitCondtionExpression subWGQueryCond4 = new QueryObjectUnitCondtionExpression(ObjectUnitItems.Geometry, QueryObjectUnitOperator.Geometry, area);
                subWGQuery.ConditionExpression = subWGQueryCond2.And(subWGQueryCond1, subWGQueryCond2, subWGQueryCond4);
            }

            XElement changedXmlDatas = wgm.QueryWorkGroupCacheRecords(subWGQuery);

            if (LogUtility.IsDebugEnabled)
            {
                int changedDataCount = GetChangedDataCount(changedXmlDatas);

                LogUtility.WriteDataCount(
                    "編集DBからWGC内の親作業グループと子作業グループのデータ",
                    LogUtility.OperationType.Select,
                    changedDataCount,
                    LogUtility.LogModel.DebugModel);
            }

            return changedXmlDatas;
        }

        /// <summary>
        /// タイプIDとメッシュコードを指定し、子作業グループの差分のみを取得する（子作業グループでの変化分）
        /// </summary>
        /// <param name="typeIDSet">タイプID</param>
        /// <param name="meshCode">メッシュコード</param>
        public void LoadOnlySubWorkgroupData(HashSet<int> typeIDSet, string meshCode = null)
        {
            this.InitDiffDataContainer();
            XElement changedXmlDatas = GetAllWorkgroupData(typeIDSet, meshCode);

            this.IsOnlySubWorkgroup = true;
            int changedDataCount = GetChangedDataCount(changedXmlDatas);

            // 編集データをキャッシュに保存する
            if (changedDataCount > 0)
            {
                CommWorkGroupData.CacheChangedDatas(this.DiffDataDict, changedXmlDatas, this.SubWorkGroupID, this.IsOnlySubWorkgroup);
            }

            LogUtility.WriteDataCount("●WGC内の変化データ(子作業グループ差分を含む)",
                LogUtility.OperationType.Select,
                this.DiffDataDict.Count,
                LogUtility.LogModel.InfoModel);
        }
        
        /// <summary>
        /// タイプIDとメッシュコードを指定し、親作業グループの差分のみを取得する（親作業グループでの変化済分）
        /// </summary>
        /// <param name="typeIDSet">タイプID</param>
        /// <param name="meshCode">メッシュコード</param>
        public void LoadOnlyParentWorkgroupData(HashSet<int> typeIDSet, string meshCode = null)
        {
            this.InitDiffDataContainer();
            XElement changedXmlDatas = GetAllWorkgroupData(typeIDSet, meshCode);

            this.IsOnlySubWorkgroup = false;
            int changedDataCount = GetChangedDataCount(changedXmlDatas);

            // 編集データをキャッシュに保存する
            if (changedDataCount > 0)
            {
                CommWorkGroupData.CacheChangedDatas(this.DiffDataDict, changedXmlDatas, this.SubWorkGroupID, this.IsOnlySubWorkgroup);
            }

            LogUtility.WriteDataCount("●WGC内の変化データ(親作業グループ差分を含む)",
                LogUtility.OperationType.Select,
                this.DiffDataDict.Count,
                LogUtility.LogModel.InfoModel);
        }

        /// <summary>
        /// タイプIDとメッシュコードを指定し、作業グループの差分を取得する（子作業グループでの変化分と親作業グループでの変化済分）
        /// </summary>
        /// <param name="typeIDSet">タイプID</param>
        /// <param name="meshCode">メッシュコード</param>
        public void LoadMergeWorkgroupData(HashSet<int> typeIDSet, string meshCode = null)
        {
            this.InitDiffDataContainer();
            XElement changedXmlDatas = GetAllWorkgroupData(typeIDSet, meshCode);

            this.IsOnlySubWorkgroup = false;
            int changedDataCount = GetChangedDataCount(changedXmlDatas);

            // 編集データをキャッシュに保存する
            if (changedDataCount > 0)
            {
                CommWorkGroupData.CacheChangedDatas(this.DiffDataDict, changedXmlDatas, this.SubWorkGroupID, true);
                CommWorkGroupData.CacheChangedDatas(this.DiffDataDict, changedXmlDatas, this.SubWorkGroupID, false);
            }

            LogUtility.WriteDataCount("●WGC内の変化データ(親、子作業グループ差分を含む)",
                LogUtility.OperationType.Select,
                this.DiffDataDict.Count,
                LogUtility.LogModel.InfoModel);
        }

        /// <summary>
        /// タイプIDとメッシュコードを指定し、作業グループの差分を取得する（子作業グループでの変化分または親作業グループでの変化済分）
        /// </summary>
        /// <param name="typeIDSet">タイプID</param>
        /// <param name="meshCode">メッシュコード</param>
        public void LoadMinWorkgroupDiff(HashSet<int> typeIDSet, string meshCode = null)
        {
            this.InitDiffDataContainer();
            XElement changedXmlDatas = GetAllWorkgroupData(typeIDSet, meshCode);

            this.IsOnlySubWorkgroup = false;
            string infoLabel = "●WGC内の変化データ(親作業グループ差分を含む)";
            int changedDataCount = GetChangedDataCount(changedXmlDatas);

            // 編集データをキャッシュに保存する
            if (changedDataCount > 0)
            {
                this.IsOnlySubWorkgroup = true;
                infoLabel = "●WGC内の変化データ(子作業グループ差分を含む)";
                CommWorkGroupData.CacheChangedDatas(this.DiffDataDict, changedXmlDatas, this.SubWorkGroupID, this.IsOnlySubWorkgroup);

                if (this.DiffDataDict.Count < 1)
                {
                    this.IsOnlySubWorkgroup = false;
                    infoLabel = "●WGC内の変化データ(親作業グループ差分を含む)";
                    CommWorkGroupData.CacheChangedDatas(this.DiffDataDict, changedXmlDatas, this.SubWorkGroupID, this.IsOnlySubWorkgroup);
                }
            }

            LogUtility.WriteDataCount(infoLabel,
                LogUtility.OperationType.Select,
                this.DiffDataDict.Count,
                LogUtility.LogModel.InfoModel);
        }

        /// <summary>
        /// 実の新規削除データを削除する
        /// </summary>
        public void RemoveTrueNewDeleteData()
        {
            foreach (var newDeleteData in this.NewDeleteDataDict.Values)
            {
                if (newDeleteData.IsTrueNewDelete && this.DiffDataDict.ContainsKey(newDeleteData.OID))
                {
                    this.DiffDataDict.Remove(newDeleteData.OID);
                }
            }
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Data;
using CREO.Fluere.Biz.FileOperators.Data;
using Microsoft.VisualBasic;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// StringUtilクラス
    /// </summary>
    public sealed class StringUtil
    {
        #region Convert string to CamelStyle
        /// <summary>
        /// Convert string to CamelStyle
        /// </summary>
        /// <param name="sourceString">入力string</param>
        /// <returns>出力string</returns>
        public static string GetCamelStyleString(string sourceString)
        {
            StringBuilder sb = new StringBuilder(string.Empty);

            bool upperFlag = true;
            foreach (char currentChar in sourceString.ToCharArray())
            {
                if (upperFlag)
                {
                    sb.Append(char.ToUpper(currentChar));
                }
                else
                {
                    sb.Append(char.ToLower(currentChar));
                }

                if (currentChar == '_')
                {
                    upperFlag = true;
                }
                else
                {
                    upperFlag = false;
                }
            }

            return sb.ToString();
        }
        #endregion

        #region Spilt string to string[] by CRLF
        /// <summary>
        /// Spilt string to string[] by CRLF
        /// </summary>
        /// <param name="content">String</param>
        /// <returns>Lines</returns>
        public static string[] SpiltToLines(string content)
        {
            return content.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
        }
        #endregion

        #region Spilt string to string[] by tab
        /// <summary>
        /// Spilt string to string[] by tab
        /// </summary>
        /// <param name="content">String</param>
        /// <returns>Lines</returns>
        public static string[] SpiltDataByTab(string content)
        {
            return content.Split(new string[] { "\t" }, StringSplitOptions.None);
        }
        #endregion

        #region Spilt string to string[] by comma
        /// <summary>
        /// Spilt string to string[] by comma
        /// </summary>
        /// <param name="content">String</param>
        /// <returns>Lines</returns>
        public static string[] SpiltDataBycomma(string content)
        {
            return content.Split(new string[] { "," }, StringSplitOptions.None);
        }
        #endregion

        #region Convert Byte[] to String And delete space
        /// <summary>
        /// Convert Byte[] to String And delete space
        /// </summary>
        /// <param name="strData">string data</param>
        /// <returns>Converted string data</returns>
        public static string DeleteSpace(string strData)
        {
            return strData.Replace("\0", string.Empty);
        }
        #endregion

        #region Convert String toByte[]  And PadRight space
        /// <summary>
        /// Convert String toByte[]  And PadRight space
        /// </summary>
        /// <param name="strData">string data</param>
        /// <param name="intleng">length</param>
        /// <returns>byte data</returns>
        public static string PadRightSpace(string strData, params int[] intleng)
        {
            if (intleng.Length > 0)
            {
                strData = strData + string.Empty.PadRight(intleng[0] - Encoding.GetEncoding("shift_jis").GetByteCount(strData), '\0');
            }

            return strData;
        }
        #endregion

        #region Fill "0"
        /// <summary>
        /// Fill "0"
        /// </summary>
        /// <param name="value">value</param>
        /// <param name="length">length</param>
        /// <returns>string</returns>
        public static string FillLengthAtHeadByZero(string value, int length)
        {
            while (value.Length < length)
            {
                value = "0" + value;
            }

            return value;
        }
        #endregion

        #region Get subString ignore any exception
        /// <summary>
        /// Get subString ignore any exception
        /// </summary>
        /// <param name="source">source</param>
        /// <param name="index">index</param>
        /// <param name="length">length</param>
        /// <returns>GetSubString</returns>
        public static string GetSubString(string source, int index, int length)
        {
            string targetString = null;

            try
            {
                targetString = source.Substring(index, length);
            }
            catch (Exception ex)
            {
                LogUtility.WriteError(string.Empty, ex);
                targetString = string.Empty;
            }

            return targetString;
        }
        #endregion

        #region 都道府県或いは市区町村コード取得
        /// <summary>
        /// 都道府県或いは市区町村コード取得
        /// </summary>
        /// <param name="source">市区町村リストレコード(aabbb)</param>
        /// <param name="index">サブコードIndex</param>
        /// <param name="length">長さ</param>
        /// <returns>都道府県或いは市区町村コード</returns>
        public static string GetAdminCodeSubString(string source, int index, int length)
        {
            // レコード空白の場合、「""」を返す
            if (string.IsNullOrEmpty(source))
            {
                return string.Empty;
            }

            if (index == 0)
            {
                // 都道府県コードを取得
                if (source.Length < length)
                {
                    return FillLengthAtHeadByZero(source, length);
                }
                else
                {
                    return GetSubString(source, index, length);
                }
            }
            else if (index == 2)
            {
                // 市区町村コードを取得
                if (source.Length <= 2)
                {
                    return string.Empty;
                }
                else if (source.Length < (2 + length))
                {
                    return FillLengthAtHeadByZero(GetSubString(source, index, length), length);
                }
                else
                {
                    return GetSubString(source, index, length);
                }
            }

            return string.Empty;
        }
        #endregion

        #region 日付を付いているファイルパスの取得
        /// <summary>
        /// 日付を付いているファイルパスの取得
        /// (EditToDoList.duco⇒EditToDoList_yyyyMMddHHmmss.duco)
        /// </summary>
        /// <param name="outputPath">ファイルパス</param>
        /// <returns>日付を付いているファイルパス</returns>
        public static string GetToDoListOutFileNameWithDate(string outputPath)
        {
            string lastExt = string.Empty;
            if (outputPath.Length > 5)
            {
                lastExt = outputPath.Substring(outputPath.Length - 5);
            }

            if (string.IsNullOrEmpty(lastExt) || lastExt.ToLower() == ".duco")
            {
                string dt = DateTime.Now.ToString("yyyyMMddHHmmss", DateTimeFormatInfo.InvariantInfo);
                outputPath = outputPath.Replace(".duco", "_" + dt + ".duco");
            }

            return outputPath;
        }
        #endregion

        #region 日付付いているパスの転化
        /// <summary>
        /// EditDBApplyList.duco ⇒　EditDBApplyList_yyyyMMddHHmmss.duco
        /// </summary>
        /// <param name="fileName">ファイル名(例EditDBApplyList.duco)</param>
        /// <returns>ファイル名</returns>
        public static string GetFileNameWithDateTime(string fileName)
        {
            string lastExt = string.Empty;
            if (!string.IsNullOrEmpty(fileName))
            {
                lastExt = Path.GetExtension(fileName);
            }

            if (!string.IsNullOrEmpty(lastExt))
            {
                fileName = fileName.Replace(lastExt, "{0}");
                string dt = DateTime.Now.ToString("yyyyMMddHHmmss", DateTimeFormatInfo.InvariantInfo);
                fileName = string.Format(fileName, "_" + dt + lastExt);
            }

            return fileName;
        }
        #endregion

        #region 出力フォルダ+固定部分+日時+拡張子の組み合わせ
        /// <summary>
        /// 出力フォルダ+固定部分+日時+拡張子の組み合わせ
        /// </summary>
        /// <param name="folder">出力フォルダ</param>
        /// <param name="fixedStr">固定部分</param>
        /// <param name="ext">拡張子</param>
        /// <returns>日付を付いているファイルのフルパス</returns>
        public static string GetFileFullPathWithDate(string folder, string fixedStr, string ext)
        {
            // ==============================
            // <added by houyao on 2012/11/22>
            // ==============================

            // 入力必須のチェック
            if (string.IsNullOrEmpty(folder) ||
                string.IsNullOrEmpty(fixedStr) ||
                string.IsNullOrEmpty(ext))
            {
                return string.Empty;
            }

            // 出力フォルダが存在しない場合、当該フォルダを作成する
            if (!Directory.Exists(folder))
            {
                Directory.CreateDirectory(folder);
            }

            // 日時の取得
            string dt = DateTime.Now.ToString("yyyyMMddHHmmss", DateTimeFormatInfo.InvariantInfo);

            // ファイル名の作る
            string fileName = fixedStr + dt + ext;

            // ファイルのフルパスを作る
            string outputPath = Path.Combine(folder, fileName);

            return outputPath;
        }
        #endregion

        #region 半角を全角に変換する
        /// <summary>
        /// 半角を全角に変換する
        /// </summary>
        /// <param name="halfString">半角文字列</param>
        /// <returns>全角文字列</returns>
        public static string ConvertHalfToWide(string halfString)
        {
            string strWide = Strings.StrConv(halfString, VbStrConv.Wide, 0x0411);

            return strWide;
        }
        #endregion

        #region 全角を半角に変換する
        /// <summary>
        /// 全角を半角に変換する
        /// </summary>
        /// <param name="wideString">全角文字列</param>
        /// <returns>半角文字列</returns>
        public static string ConvertWideToHalf(string wideString)
        {
            string strWide = Strings.StrConv(wideString, VbStrConv.Narrow, 0x0411);

            return strWide;
        }
        #endregion

        #region 「-」で区切られた半角データから半角数字を取り出す
        /// <summary>
        /// 「-」で区切られた半角データから半角数字を取り出す
        /// </summary>
        /// <param name="str">対象文字列</param>
        /// <param name="pos">位置</param>
        /// <returns>半角数字</returns>
        public static string HanCut(string str, int pos)
        {
            string returnVal = "0";

            if (string.IsNullOrWhiteSpace(str))
            {
                return returnVal;
            }

            // 「-」で区切
            string[] strAry = str.Split('-');

            if (strAry != null && strAry.Count() >= pos)
            {
                returnVal = strAry[pos - 1];
            }
            else
            {
                return returnVal;
            }

            for (int i = returnVal.Length - 1; i >= 0; i--)
            {
                // 半角数字を判定
                if (CommonConstants.HAN_NUM.Contains(returnVal[i]) == false)
                {
                    returnVal = returnVal.Remove(i, 1);
                }
            }

            if (string.IsNullOrEmpty(returnVal))
            {
                return "0";
            }

            return returnVal;
        }
        #endregion

        #region  全角の数字とハイフンを半角に変換する
        /// <summary>
        /// 全角の数字とハイフンを半角に変換する
        /// </summary>
        /// <param name="str">全角の数字</param>
        /// <returns>ハイフン数字</returns>
        public static string ZenToHan(string str)
        {
            StringBuilder returnVal = new StringBuilder();

            // 数値が既に出てきたか
            bool flgDgtOut = false;
            bool flgHypAppear = false;

            if (string.IsNullOrWhiteSpace(str))
            {
                return string.Empty;
            }

            for (int i = 0; i < str.Length; i++)
            {
                int index = CommonConstants.ZEN_NUM_COMMA.IndexOf(str[i]);

                if (index >= 0)
                {
                    // 全角数字
                    if (index < 10)
                    {
                        returnVal.Append(CommonConstants.HAN_NUM_COMMA[index]);
                        flgDgtOut = true;
                    }
                    else
                    {
                        // コンマを含む
                        flgHypAppear = true;

                        if (flgDgtOut)
                        {
                            returnVal.Append(CommonConstants.HAN_NUM_COMMA[index]);
                        }
                    }
                }
                else
                {
                    if (returnVal.Length > 0 || flgHypAppear)
                    {
                        break;
                    }
                }
            }

            return returnVal.ToString();
        }
        #endregion

        #region 全角スペースと数字と記号と括弧を半角に変換
        /// <summary>
        /// 全角スペースと数字と記号を半角に変換
        /// </summary>
        /// <param name="str">全角の数字</param>
        /// <returns>ハイフン数字</returns>
        public static string FullToHalf(string str)
        {
            StringBuilder returnVal = new StringBuilder();

            if (string.IsNullOrWhiteSpace(str))
            {
                return string.Empty;
            }

            for (int i = 0; i < str.Length; i++)
            {
                int index = CommonConstants.FULL_NUM_COMMA.IndexOf(str[i]);

                if (index >= 0)
                {
                    returnVal.Append(CommonConstants.HALF_NUM_COMMA[index]);
                }
                else
                {
                    returnVal.Append(str[i]);
                }
            }

            return returnVal.ToString();
        }
        #endregion

        #region 「数字＜大文字英字＜小文字英字」に基づく文字列を比較する
        /// <summary>
        /// 「数字＜大文字英字＜小文字英字」に基づく文字列を比較する
        /// </summary>
        /// <param name="text1">文字列1</param>
        /// <param name="text2">文字列2</param>
        /// <returns>0:同じ 正数:text1よりtext2が小さい 負数:text1よりtext2が大きい</returns>
        public static int CompareByLowUpperNumber(string text1, string text2)
        {
            int intCompare = 0;

            char[] charArray1 = text1.ToCharArray();

            char[] charArray2 = text2.ToCharArray();

            for (int i = 0; i < charArray1.Count(); i++)
            {
                intCompare = 0;

                // 数字の場合
                if (char.IsNumber(charArray1[i]))
                {
                    if (char.IsNumber(charArray2[i]))
                    {
                        intCompare = charArray1[i].CompareTo(charArray2[i]);
                    }
                    else if (char.IsUpper(charArray2[i]) || char.IsLower(charArray2[i]))
                    {
                        intCompare = -1;
                    }
                }
                else if (char.IsUpper(charArray1[i]))
                {
                    if (char.IsNumber(charArray2[i]))
                    {
                        intCompare = 1;
                    }
                    else if (char.IsUpper(charArray2[i]))
                    {
                        intCompare = charArray1[i].CompareTo(charArray2[i]);
                    }
                    else if (char.IsLower(charArray2[i]))
                    {
                        intCompare = -1;
                    }
                }
                else if (char.IsLower(charArray1[i]))
                {
                    if (char.IsNumber(charArray2[i]) || char.IsUpper(charArray2[i]))
                    {
                        intCompare = 1;
                    }
                    else if (char.IsLower(charArray2[i]))
                    {
                        intCompare = charArray1[i].CompareTo(charArray2[i]);
                    }
                }
                else
                {
                    break;
                }

                if (i == charArray1.Count() - 1)
                {
                    break;
                }
                else
                {
                    if (intCompare != 0)
                    {
                        break;
                    }
                }
            }

            return intCompare;
        }
        #endregion
    }
}

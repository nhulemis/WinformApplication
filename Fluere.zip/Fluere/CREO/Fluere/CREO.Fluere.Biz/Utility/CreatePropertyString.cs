﻿using System;
using System.Collections;
using System.Reflection;
using System.Text;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// プロパティ取得のクラスのToStringメソッド用の共通クラス
    /// </summary>
    public class CreatePropertyString
    {
        #region プロパティの値を取得する
        /// <summary>
        /// プロパティの値を取得する
        /// </summary>
        /// <param name="obj">処理対象となるオブジェクト</param>
        /// <returns>プロパティの値</returns>
        public static string GetPropertyString(object obj)
        {
            StringBuilder builder = new StringBuilder();
            try
            {
                // 全てのプロパティを取得する
                PropertyInfo[] pi = obj.GetType().GetProperties();

                foreach (PropertyInfo prop in pi)
                {
                    if (!prop.CanRead)
                    {
                        continue;
                    }

                    // プロパティ値の取得
                    object propValue = prop.GetValue(obj, null);
                    if (propValue == null)
                    {
                        SetPropertValue(builder, prop.Name, null);
                        continue;
                    }

                    // リスト
                    IList list = propValue as IList;
                    if (list != null)
                    {
                        SetPropertValue(builder, prop.Name, ConvertPropertyValue(list));
                        continue;
                    }

                    // Dictionary
                    IDictionary dictionary = propValue as IDictionary;
                    if (dictionary != null)
                    {
                        SetPropertValue(builder, prop.Name, ConvertPropertyValue(dictionary));
                        continue;
                    }

                    // Collection
                    ICollection collection = propValue as ICollection;
                    if (collection != null)
                    {
                        SetPropertValue(builder, prop.Name, ConvertPropertyValue(collection));
                        continue;
                    }

                    // TODO（その他のタイプに対応することがある）

                    // 文字、数字、boolなどのValueType                    
                    SetPropertValue(builder, prop.Name, propValue.ToString());
                }
            }
            catch (Exception e)
            {
                builder.Append(obj.GetType() + e.Message);
            }

            return builder.ToString();
        }
        #endregion

        #region IDictionary
        /// <summary>
        /// オブジェクトを文字列に変換します。
        /// </summary>
        /// <param name="obj">変換対象オブジェクト</param>
        /// <returns>オブジェクトの文字列表現</returns>
        private static string ConvertPropertyValue(IDictionary obj)
        {
            StringBuilder dump = new StringBuilder();
         
            for (IDictionaryEnumerator enumerator = obj.GetEnumerator(); enumerator.MoveNext();)
            {
                dump.Append("[");
                dump.Append(enumerator.Value);
                dump.Append("]");
            }

            return dump.ToString();
        }
        #endregion

        #region IList
        /// <summary>
        /// オブジェクトを文字列に変換します。
        /// </summary>
        /// <param name="obj">変換対象オブジェクト</param>
        /// <returns>オブジェクトの文字列表現</returns>
        private static string ConvertPropertyValue(IList obj)
        {
            StringBuilder dump = new StringBuilder();
            for (int index = 0; index < obj.Count; index++)
            {
                if (obj[index] != null)
                {
                    dump.Append("[");
                    dump.Append(obj[index].ToString());
                    dump.Append("]");
                }
            }

            return dump.ToString();
        }
        #endregion

        #region ICollection
        /// <summary>
        /// オブジェクトを文字列に変換します。
        /// </summary>
        /// <param name="obj">変換対象オブジェクト</param>
        /// <returns>オブジェクトの文字列表現</returns>
        private static string ConvertPropertyValue(ICollection obj)
        {
            StringBuilder dump = new StringBuilder();
            for (IEnumerator enumerator = obj.GetEnumerator(); enumerator.MoveNext();)
            {
                dump.Append("[");
                dump.Append(enumerator.Current);
                dump.Append("]");
            }

            return dump.ToString();
        }
        #endregion

        #region IEnumerable
        /// <summary>
        /// オブジェクトを文字列に変換します。
        /// </summary>
        /// <param name="obj">変換対象オブジェクト</param>
        /// <returns>オブジェクトの文字列表現</returns>
        private static string ConvertPropertyValue(IEnumerable obj)
        {
            StringBuilder dump = new StringBuilder();

            for (IEnumerator enumerator = obj.GetEnumerator(); enumerator.MoveNext();)
            {
                dump.Append("[");
                dump.Append(enumerator.Current);
                dump.Append("]");
            }

            return dump.ToString();
        }
        #endregion

        #region プロパティ値を整形
        /// <summary>
        /// 属性値の格納
        /// </summary>
        /// <param name="builder">コンテインナー</param>
        /// <param name="propName">属性名</param>
        /// <param name="propertValue">属性値</param>
        private static void SetPropertValue(StringBuilder builder, string propName, object propertValue)
        {
            if (propertValue == null)
            {
                builder.Append(propName);
                builder.Append("=");
                builder.Append("null");
            }
            else
            {
                builder.Append(propName);
                builder.Append("=");
                builder.Append(propertValue.ToString());
            }

            builder.Append(";\r\n");
        }
        #endregion
    }
}

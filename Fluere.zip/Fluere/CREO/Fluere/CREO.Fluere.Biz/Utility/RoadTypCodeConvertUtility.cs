﻿using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.DataModel;
using CREO.FW.Utilities;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// TMIDB道路種別コードの変換処理クラス
    /// </summary>
    public class RoadTypCodeConvertUtility
    {
        #region 道路種類コード
        /// <summary>
        /// 道路種類コード:1：探索道路
        /// </summary>
        public const int ROAD_TYPE_GUIDE = 1;

        /// <summary>
        /// 道路種類コード:2：表示道路
        /// </summary>
        public const int ROAD_TYPE_MM = 2;
        #endregion

        /// <summary>
        /// TMI道路．基幹道路．探索案内道路コードが「2：非探索」である
        /// </summary>
        public const byte BASIC_GUID_ROD_2 = 2;

        #region 道路レイヤコード
        /// <summary>
        /// 道路レイヤコード4：非探索道路 
        /// </summary>
        public const string ROD_LAYCODE_4 = "4";

        /// <summary>
        /// 道路レイヤコード0：未設定 
        /// </summary>
        public const string ROD_LAYCODE_0 = "0";
        #endregion

        #region 道路番号
        /// <summary>
        /// 道路番号 固定値「0」
        /// </summary>
        public const int ROAD_NO_0 = 0;
        #endregion

        #region 変換後TMIDB道路種別コード
        /// <summary>
        /// 1：高速道路
        /// </summary>
        public const string ROD_CATEGORY_CODE_CONVERT_1 = "1";

        /// <summary>
        /// 2：都市高速道路（指定都市高速道路含む）
        /// </summary>
        public const string ROD_CATEGORY_CODE_CONVERT_2 = "2";

        /// <summary>
        /// 0：未調査、有料道路（※）
        /// </summary>
        public const string ROD_CATEGORY_CODE_CONVERT_0 = "0";

        /// <summary>
        /// 3：一般国道
        /// </summary>
        public const string ROD_CATEGORY_CODE_CONVERT_3 = "3";

        /// <summary>
        /// 4：主要地方道（都道府県道）
        /// </summary>
        public const string ROD_CATEGORY_CODE_CONVERT_4 = "4";

        /// <summary>
        /// 6：一般都道府県道
        /// </summary>
        public const string ROD_CATEGORY_CODE_CONVERT_6 = "6";

        /// <summary>
        /// 7：一般道
        /// </summary>
        public const string ROD_CATEGORY_CODE_CONVERT_NOMAL_7 = "7";

        /// <summary>
        /// 9：非探索道路(探索)、細街路（表示）
        /// </summary>
        public const string ROD_CATEGORY_CODE_CONVERT_SEARCH_9 = "9";
        #endregion

        /// <summary>
        /// 探索道路コード:2
        /// </summary>
        public const byte GUIDE_ROAD_CODE_2 = 2;

        /// <summary>
        /// TMIDB道路種別コードの格付け順の降順
        /// </summary>
        public static List<string> TMIRoadTypCodeDescList = new List<string>()
        {
            ROD_CATEGORY_CODE_CONVERT_1,
            ROD_CATEGORY_CODE_CONVERT_2,
            ROD_CATEGORY_CODE_CONVERT_0,
            ROD_CATEGORY_CODE_CONVERT_3,
            ROD_CATEGORY_CODE_CONVERT_4,
            ROD_CATEGORY_CODE_CONVERT_6,
            ROD_CATEGORY_CODE_CONVERT_NOMAL_7,
            ROD_CATEGORY_CODE_CONVERT_SEARCH_9
        };

        /// <summary>
        /// 14.1.27. TMIDB道路種別コードの変換処理
        /// </summary>
        /// <param name="roadWrappper">RoadWrappper構造体クラス</param>
        /// <returns>主路線・重用路線１の路線リスト</returns>
        public static List<TMIRouteAttribute> RoadTypCodeConvert(RoadWrappper roadWrappper)
        {
            // 主路線・重用路線１の路線リスト
            List<TMIRouteAttribute> routeSortList = new List<TMIRouteAttribute>();

            int roadType = GetRoadType(roadWrappper.RoadMain);
            if (LogUtility.IsTraceEnabled)
            {
                LogUtility.WriteTrace("TMIDB道路種別コード変換対象基幹道路 OID：{0},道路タイプ：{1}",
                                         roadWrappper.RoadMain.OIDString,
                                         roadType.ToString());
            }

            // 1. 道路種類判定
            if (roadType != ROAD_TYPE_MM)
            {
                // 道路レイヤコードと案内道路コードのログ出力
                WriteRoadInfoLog(roadWrappper);

                // 2. 道路レイヤコード変換
                string layerCode = LayerCodeConvert(roadWrappper, ROAD_TYPE_GUIDE);

                // 3. 探索案内道路コード決定
                byte? roadCode = GuideRoadCodeDecide(roadWrappper, ROAD_TYPE_GUIDE);

                if (LogUtility.IsTraceEnabled)
                {
                    LogUtility.WriteTrace("決定された 探索レイヤコード：{0},探索案内道路コード：{1}",
                         layerCode == null ? "NULL" : layerCode.ToString(),
                         roadCode == null ? "NULL" : roadCode.ToString());
                }

                // 路線番号と道路種類コード変換
                List<TMIRouteAttribute> routeList =
                    RouteNoAndRoadTypConvert(roadWrappper, ROAD_TYPE_GUIDE, layerCode, roadCode);
                if (LogUtility.IsTraceEnabled && routeList != null && routeList.Count > 0)
                {
                    LogUtility.WriteTrace("変換後路線番号リスト 路線番号：{0},道路種別コード：{1}",
                        string.Join(",", routeList.Select(o => o.RoadNo == null ? "NULL" : o.RoadNo.ToString())),
                        string.Join(",", routeList.Select(o => o.RoadTypCode)));
                }

                // 「5. 道路種別コードの変換」5-5)  道路種別コードメンテナンス
                routeSortList = MaintainTmiRoutes(routeList, ROAD_TYPE_GUIDE, layerCode);
                if (routeSortList != null && routeSortList.Count > 0)
                {
                    if (LogUtility.IsTraceEnabled)
                    {
                        LogUtility.WriteTrace("決定された主路線の路線番号 路線番号：{0},TMIDB道路種別コード：{1}",
                            routeSortList[0].RoadNo == null ? "NULL" : routeSortList[0].RoadNo.ToString(),
                            routeSortList[0].RoadTypCode);
                    }

                    // ソート後の先頭の要素（主路線）：TMIDB道路種別コードを設定。
                    roadWrappper.RoadTypCode = routeSortList[0].RoadTypCode;
                }
            }

            // ソート後の先頭の要素（主路線）と２番目の要素（重用路線１）の各TMIDB道路種別コード・路線番号を返す。
            return routeSortList;
        }

        #region 道路情報のログ出力
        /// <summary>
        /// 道路情報のログ出力
        /// </summary>
        /// <param name="roadWrappper">RoadWrappper構造体クラス</param>
        private static void WriteRoadInfoLog(RoadWrappper roadWrappper)
        {
            if (LogUtility.IsTraceEnabled)
            {
                LogUtility.WriteTrace("フェリー周辺互換情報 探索レイヤコード：{0},探索案内道路コード：{1}",
                     roadWrappper.FrryCompatibleInfo == null ? "NULL" : roadWrappper.FrryCompatibleInfo.GuideLayerCode == null ? "NULL" : roadWrappper.FrryCompatibleInfo.GuideLayerCode.ToString(),
                     roadWrappper.FrryCompatibleInfo == null ? "NULL" : roadWrappper.FrryCompatibleInfo.GuideRoadCode == null ? "NULL" : roadWrappper.FrryCompatibleInfo.GuideRoadCode.ToString());

                LogUtility.WriteTrace("基幹道路 探索レイヤコード：{0},探索案内道路コード：{1}",
                     roadWrappper.RoadMain.GuideLayerCode == null ? "NULL" : roadWrappper.RoadMain.GuideLayerCode.ToString(),
                     roadWrappper.RoadMain.GuideRoadCode == null ? "NULL" : roadWrappper.RoadMain.GuideRoadCode.ToString());
            }
        }
        #endregion

        #region 1. 道路種類判定
        /// <summary>
        /// 1. 道路種類判定
        /// </summary>
        /// <param name="roadMain">基幹道路</param>
        /// <returns>道路種類</returns>
        private static int GetRoadType(SRoadMain roadMain)
        {
            var road05GuideNoAry = roadMain.Road05GuideNoAry;
            if (road05GuideNoAry != null && road05GuideNoAry.Count > 0)
            {
                return ROAD_TYPE_GUIDE;
            }
            else
            {
                // 基幹道路が表示道路である場合、変換処理対象外として、NULL（空白）を戻す。
                return ROAD_TYPE_MM;
            }
        }
        #endregion

        #region 2. 道路レイヤコード変換処理
        /// <summary>
        /// レイヤコード変換
        /// </summary>
        /// <param name="roadWrappper">TMI道路</param>
        /// <param name="typFlg">道路種類コード</param>
        /// <returns>レイヤコード</returns>
        private static string LayerCodeConvert(RoadWrappper roadWrappper, int typFlg)
        {
            string layerCode = null;

            // レイヤコードが設定されていない場合
            if (roadWrappper.LayerCode == null)
            {
                // 道路レイヤコード変換処理
                new RodLayoutCodeConvert().RoadLayoutCodeConvert(roadWrappper, typFlg);
            }

            // レイヤコードを設定
            layerCode = roadWrappper.LayerCode;

            return layerCode;
        }
        #endregion

        #region 3. 探索案内道路コード決定
        /// <summary>
        /// 探索案内道路コード決定
        /// </summary>
        /// <param name="roadWrappper">TMI道路</param>
        /// <param name="typFlg">道路種類コード</param>
        /// <returns>道路コード</returns>
        private static byte? GuideRoadCodeDecide(RoadWrappper roadWrappper, int typFlg)
        {
            // 基幹道路．フェリー周辺互換情報が設定される 且つ 基幹道路．フェリー周辺互換情報．探索案内道路コードが設定される
            if (roadWrappper.FrryCompatibleInfo != null &&
                    roadWrappper.FrryCompatibleInfo.GuideRoadCode != null)
            {
                // フェリー周辺互換情報．探索案内道路コード
                return roadWrappper.FrryCompatibleInfo.GuideRoadCode;
            }
            else
            {
                // 基幹道路．探索案内道路コード
                return roadWrappper.RoadMain.GuideRoadCode;
            }
        }
        #endregion

        #region 路線番号と道路種類コード変換
        /// <summary>
        /// 路線番号と道路種類コード変換
        /// </summary>
        /// <param name="roadWrappper">TMI道路</param>
        /// <param name="typFlg">道路種別</param>
        /// <param name="layerCode">レイヤコード</param>
        /// <param name="roadCode">道路コード</param>
        /// <returns>TMI路線リスト</returns>
        private static List<TMIRouteAttribute> RouteNoAndRoadTypConvert(
            RoadWrappper roadWrappper,
            int typFlg,
            string layerCode,
            byte? roadCode)
        {
            // 路線番号リスト
            List<TMIRouteAttribute> tmiRoutes = new List<TMIRouteAttribute>();

            // 4-1)  探索案内道路コードより変換
            if (roadCode == RoadTypCodeConvertUtility.GUIDE_ROAD_CODE_2)
            {
                // 探索案内道路コードが「2：非探索道路」である場合
                tmiRoutes.Add(RouteNoAndRoadTypConvertByLayerCD(typFlg, layerCode));
            }
            else
            {
                // 探索案内道路コードが「2：非探索道路」ではない場合
                tmiRoutes = RouteNoAndRoadTypConvertBySRoadMain(roadWrappper, typFlg, layerCode);
            }

            return tmiRoutes;
        }
        #endregion

        #region 路線番号と道路種別コードの変換
        /// <summary>
        /// レイヤコードより路線番号と道路種別コードの変換
        /// </summary>
        /// <param name="typFlg">道路種類コード</param>
        /// <param name="layerCode">レイヤコード</param>
        /// /// <returns>作成した路線番号</returns>
        private static TMIRouteAttribute RouteNoAndRoadTypConvertByLayerCD(int typFlg, string layerCode)
        {
            // 作成した路線番号
            TMIRouteAttribute tmiRoute = new TMIRouteAttribute();

            // 主路線.道路番号を「0」とし、重要路線なしと見なす。
            tmiRoute.RoadNo = RoadTypCodeConvertUtility.ROAD_NO_0;

            // 「2-3)  路線番号決定」a)  探索案内道路コードより変換
            tmiRoute.RoadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_SEARCH_9;

            return tmiRoute;
        }
        #endregion

        #region 基幹道路のそれぞれの情報より変換路線番号と道路種別コードの変換
        /// <summary>
        /// 基幹道路のそれぞれの情報より変換路線番号と道路種別コードの変換
        /// </summary>
        /// <param name="roadWrappper">処理対象の基幹道路</param>
        /// <param name="typFlg">道路種類コード</param>
        /// <param name="layerCode">レイヤコード</param>
        /// <returns>作成したTMI路線リスト</returns>
        private static List<TMIRouteAttribute> RouteNoAndRoadTypConvertBySRoadMain(
            RoadWrappper roadWrappper, int typFlg, string layerCode)
        {
            SRoadMain sroadMain = roadWrappper.RoadMain;

            // 作成したTMI路線リスト
            List<TMIRouteAttribute> tmiAllRoutes = new List<TMIRouteAttribute>();

            // 処理一時用のTMI路線リスト
            List<TMIRouteAttribute> tmiTempRoutes = null;

            // 処理一時用の高速種別路線
            DMCollection<HWRouteInfo> hwRouteInfoAry = sroadMain.HWRouteInfoAry;

            // 高速種別路線より変換
            if (hwRouteInfoAry != null && hwRouteInfoAry.Count > 0)
            {
                // 高速種別路線配列よりTMI路線リスト取得
                tmiTempRoutes = GetTmiRoutesByHWRouteInfoAry(sroadMain.HWRouteInfoAry);

                if (tmiTempRoutes != null && tmiTempRoutes.Count > 0)
                {
                    tmiAllRoutes.AddRange(tmiTempRoutes);
                }
            }
            else
            {
                LogUtility.WriteTrace("変換前の高速路線番号リスト：NULL");
            }

            // 基本路線より変換
            if (sroadMain.BaseRouteInfoAry != null && sroadMain.BaseRouteInfoAry.Count > 0)
            {
                // 基本路線配列よりTMI路線リスト取得
                tmiTempRoutes = GetTmiRoutesByBaseRouteInfoAry(typFlg, layerCode, sroadMain.BaseRouteInfoAry);

                if (tmiTempRoutes != null && tmiTempRoutes.Count > 0)
                {
                    tmiAllRoutes.AddRange(tmiTempRoutes);
                }
            }
            else
            {
                LogUtility.WriteTrace("変換前の基本路線番号リスト：NULL");
            }

            return tmiAllRoutes;
        }
        #endregion

        #region 高速種別路線配列よりTMI路線リスト取得
        /// <summary>
        /// 高速種別路線配列よりTMI路線リスト取得
        /// </summary>
        /// <param name="hwRouteInfoAry">高速種別路線配列</param>
        /// <returns>作成したTMI路線リスト</returns>
        private static List<TMIRouteAttribute> GetTmiRoutesByHWRouteInfoAry(DMCollection<HWRouteInfo> hwRouteInfoAry)
        {
            List<TMIRouteAttribute> tmiRoutesByHWRouteInfo = new List<TMIRouteAttribute>();
            StringBuilder sbLogRouteNo = new StringBuilder();
            StringBuilder sbLogRoadTypCode = new StringBuilder();

            // 高速種別路線配列を繰り返し、変換路線番号と道路種別コード決定
            foreach (HWRouteInfo hwRouteInfo in hwRouteInfoAry)
            {
                // ≪高速路線≫の参照階層レベルが「1：支線」の場合、
                // 対応の≪高速路線≫の参照階層レベル「0：本線」取得
                TRouteHw mainRouteHw = GetMainRouteByBranchRoute(hwRouteInfo.RouteHw);

                // 処理対象の高速種別路線情報であるかを判定
                if (!IsTargetHWRouteInfo(mainRouteHw))
                {
                    continue;
                }

                sbLogRouteNo.Append(hwRouteInfo.RouteHw.RouteNo == null ? string.Empty : 
                                                hwRouteInfo.RouteHw.RouteNo.ToString() + ",");
                sbLogRoadTypCode.Append(mainRouteHw.HwTypCode == null ? string.Empty : 
                                                mainRouteHw.HwTypCode.ToString() + ",");

                // 高速種別路線情報により変換路線番号と道路種別コード決定
                TMIRouteAttribute tmiRoute = GetTmiRouteByHWRouteInfo(mainRouteHw, hwRouteInfo.RouteHw);

                tmiRoutesByHWRouteInfo.Add(tmiRoute);
            }

            if (LogUtility.IsTraceEnabled)
            {
                if (sbLogRouteNo.Length > 0 || sbLogRoadTypCode.Length > 0)
                {
                    LogUtility.WriteTrace("変換前の高速路線番号リスト 路線番号：{0},道路種別コード：{1}",
                        sbLogRouteNo.Length > 0 ? sbLogRouteNo.Remove(sbLogRouteNo.Length - 1, 1).ToString() : "NULL",
                        sbLogRoadTypCode.Length > 0 ? sbLogRoadTypCode.Remove(sbLogRoadTypCode.Length - 1, 1).ToString() : "NULL");
                }
            }

            return tmiRoutesByHWRouteInfo;
        }
        #endregion

        #region 高速路線の参照階層レベル「0：本線」取得
        /// <summary>
        /// 高速路線の参照階層レベル「0：本線」取得
        /// </summary>
        /// <param name="routeHw">高速路線</param>
        /// <returns>取得した本線の高速路線</returns>
        private static TRouteHw GetMainRouteByBranchRoute(TRouteHw routeHw)
        {
            // 取得した本線の高速路線
            TRouteHw mainRouteHw = null;

            // 入力した高速路線が設定されない場合
            if (routeHw == null)
            {
                return null;
            }

            // 入力した高速路線が「0：本線」である場合、そのままで戻す
            if (routeHw.NestLevel == 0)
            {
                return routeHw;
            }

            // 入力した高速路線が「1：支線」である場合、対応する≪高速路線≫の
            // 参照階層レベル「0：本線」を取得
            List<GeoItem> parentTableItems = routeHw.GetParentTableItems();

            if (parentTableItems == null || parentTableItems.Count < 1)
            {
                return null;
            }

            // 高速路線へキャスト
            mainRouteHw = parentTableItems[0] as TRouteHw;

            if (mainRouteHw == null || mainRouteHw.NestLevel != 0)
            {
                return null;
            }

            return mainRouteHw;
        }
        #endregion

        #region 処理対象の高速種別路線情報であるかを判定
        /// <summary>
        /// 処理対象の高速種別路線情報であるかを判定
        /// </summary>
        /// <param name="hwRouteInfo">高速種別路線情報</param>
        /// <returns>判定結果</returns>
        private static bool IsTargetHWRouteInfo(TRouteHw hwRouteInfo)
        {
            if (hwRouteInfo == null || hwRouteInfo.HwTypCode == null)
            {
                return false;
            }

            if (hwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_1 ||
                hwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_2 ||
                hwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_3 ||
                hwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_4)
            {
                return true;
            }

            return false;
        }
        #endregion

        #region 高速種別路線情報よりTMI路線取得
        /// <summary>
        /// 高速種別路線情報よりTMI路線取得
        /// </summary>
        /// <param name="mainHwRouteInfo">高速種別路線情報(本線)</param> 
        /// <param name="branchHwRouteInfo">高速種別路線情報(支線)</param> 
        /// <returns>作成したTMI路線</returns>
        private static TMIRouteAttribute GetTmiRouteByHWRouteInfo(TRouteHw mainHwRouteInfo, TRouteHw branchHwRouteInfo)
        {
            // 作成したTMI路線
            TMIRouteAttribute tmiRoute = new TMIRouteAttribute();

            // 路線番号決定（高速種別路線情報よりTMI路線の路線番号決定）
            tmiRoute.RoadNo = DecideRouteNoByHWRouteInfo(mainHwRouteInfo, branchHwRouteInfo);

            // 道路種別コード決定（高速種別路線情報よりTMI路線の道路種類コード決定）
            tmiRoute.RoadTypCode = DecideRoadTypCodeByHWRouteInfo(mainHwRouteInfo);

            return tmiRoute;
        }
        #endregion

        #region 高速種別路線情報よりTMI路線の路線番号決定
        /// <summary>
        /// 高速種別路線情報よりTMI路線の路線番号決定
        /// </summary>
        /// <param name="mainHwRouteInfo">高速種別路線情報(本線)</param> 
        /// <param name="branchHwRouteInfo">高速種別路線情報(支線)</param> 
        /// <returns>決定した路線番号</returns>
        private static ushort? DecideRouteNoByHWRouteInfo(TRouteHw mainHwRouteInfo, TRouteHw branchHwRouteInfo)
        {
            // 決定した路線番号
            ushort? routeNo = null;

            /*
            // 基幹道路．高速種別路線（ｎ※1）．≪高速路線≫．高速種別コードが下記の何れである場合
　          // 1：高速、2：都市高速、3：有料道路、4：一般道HW
            */
            if (mainHwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_1 ||
                mainHwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_2 ||
                mainHwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_3 ||
                mainHwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_4)
            {
                routeNo = branchHwRouteInfo.RouteNo;
            }

            return routeNo;
        }
        #endregion

        #region 高速種別路線情報よりTMI路線の道路種類コード決定
        /// <summary>
        /// 高速種別路線情報よりTMI路線の道路種類コード決定
        /// </summary>
        /// <param name="hwRouteInfo">高速種別路線情報</param>
        /// <returns>決定した道路種類コード</returns>
        private static string DecideRoadTypCodeByHWRouteInfo(TRouteHw hwRouteInfo)
        {
            // 決定した道路種類コード
            string roadTypCode = null;

            if (hwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_1)
            {
                // 1：高速　の場合、1：高速道路
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_1;
            }
            else if (hwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_2)
            {
                // 2：都市高速　の場合、2：都市高速道路（指定都市高速道路含む）
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_2;
            }
            else if (hwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_3)
            {
                // 3：有料道路　の場合、0：有料道路
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_0;
            }
            else if (hwRouteInfo.HwTypCode == TRouteHw.Code.HwTypCode_4)
            {
                // 4：一般道HW　の場合、0：有料道路
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_0;
            }

            return roadTypCode;
        }
        #endregion

        #region 基本路線配列よりTMI路線リスト取得
        /// <summary>
        /// 基本路線配列よりTMI路線リスト取得
        /// </summary>
        /// <param name="typFlg">道路種類コード</param>
        /// <param name="layerCode">レイヤコード</param>
        /// <param name="baseRouteInfoAry">基本路線配列</param>  
        /// <returns>作成したTMI路線リスト</returns>
        private static List<TMIRouteAttribute> GetTmiRoutesByBaseRouteInfoAry(
            int typFlg, string layerCode, DMCollection<BaseRouteInfo> baseRouteInfoAry)
        {
            // 作成したTMI路線リスト
            List<TMIRouteAttribute> tmiRoutesByBaseRouteInfo = new List<TMIRouteAttribute>();
            StringBuilder sbLogRouteNo = new StringBuilder();
            StringBuilder sbLogRoadTypCode = new StringBuilder();

            // 基本路線情報を繰り返し、変換路線番号と道路種別コード決定
            foreach (BaseRouteInfo baseRouteInfo in baseRouteInfoAry)
            {
                sbLogRouteNo.Append(baseRouteInfo.RouteNo == null ? string.Empty :
                                                baseRouteInfo.RouteNo.ToString() + ",");
                sbLogRoadTypCode.Append(baseRouteInfo.RoadTypCode == null ? string.Empty :
                                                baseRouteInfo.RoadTypCode.ToString() + ",");

                // 基本路線情報よりTMI路線取得
                TMIRouteAttribute tmiTempRoute =
                    GetTmiRouteByBaseRouteInfo(typFlg, layerCode, baseRouteInfo);

                tmiRoutesByBaseRouteInfo.Add(tmiTempRoute);
            }

            if (LogUtility.IsTraceEnabled)
            {
                if (sbLogRouteNo.Length > 0 || sbLogRoadTypCode.Length > 0)
                {
                    LogUtility.WriteTrace("変換前の基本路線番号リスト 路線番号：{0},道路種別コード：{1}",
                        sbLogRouteNo.Length > 0 ? sbLogRouteNo.Remove(sbLogRouteNo.Length - 1, 1).ToString() : "NULL",
                        sbLogRoadTypCode.Length > 0 ? sbLogRoadTypCode.Remove(sbLogRoadTypCode.Length - 1, 1).ToString() : "NULL");
                }
            }

            return tmiRoutesByBaseRouteInfo;
        }
        #endregion

        #region 基本路線情報よりTMI路線取得
        /// <summary>
        /// 基本路線情報よりTMI路線取得
        /// </summary>
        /// <param name="typFlg">道路種類コード</param>
        /// <param name="layerCode">レイヤコード</param>
        /// <param name="baseRouteInfo">基本路線情報</param>  
        /// <returns>作成したTMI路線</returns>
        private static TMIRouteAttribute GetTmiRouteByBaseRouteInfo(
            int typFlg, string layerCode, BaseRouteInfo baseRouteInfo)
        {
            // 作成したTMI路線
            TMIRouteAttribute tmiRoute = new TMIRouteAttribute();

            // 路線番号決定（4-3)  基本路線より変換）
            tmiRoute.RoadNo = DecideRouteNoByBaseRouteInfo(typFlg, baseRouteInfo);

            // 道路種別コード決定（5-3)  基本路線より変換）
            tmiRoute.RoadTypCode = DecideRoadTypCodeByBaseRouteInfo(typFlg, layerCode, baseRouteInfo);

            return tmiRoute;
        }
        #endregion

        #region 基本路線情報よりTMI路線の路線番号決定
        /// <summary>
        /// 基本路線情報よりTMI路線の路線番号決定
        /// </summary>
        /// <param name="typFlg">道路種類コード</param>
        /// <param name="baseRouteInfo">基本路線情報</param>
        /// <returns>決定した路線番号</returns>
        private static ushort? DecideRouteNoByBaseRouteInfo(int typFlg, BaseRouteInfo baseRouteInfo)
        {
            // 決定した路線番号
            ushort? routeNo = 0;

            // 基幹道路.基本路線.道路種別コードが下記の何れである場合
            // 1：一般国道、2：主要地方道、4：一般都道府県道、5：主要一般道、
            // 10：その他細道路（非探索道路）
            if (baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_1 ||
                baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_2 ||
                baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_4 ||
                baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_5 ||
                baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_10)
            {
                routeNo = baseRouteInfo.RouteNo;
            }

            return routeNo;
        }
        #endregion

        #region 基本路線情報よりTMI路線の道路種別コード決定
        /// <summary>
        /// 基本路線情報よりTMI路線の道路種別コード決定
        /// </summary>
        /// <param name="typFlg">道路種類コード</param>
        /// <param name="layerCode">レイヤコード</param>
        /// <param name="baseRouteInfo">基本路線情報</param>
        /// <returns>決定した道路種別コード</returns>
        private static string DecideRoadTypCodeByBaseRouteInfo(
            int typFlg, string layerCode, BaseRouteInfo baseRouteInfo)
        {
            // 決定した道路種別コード
            string roadTypCode = null;

            if (typFlg == RoadTypCodeConvertUtility.ROAD_TYPE_GUIDE)
            {
                roadTypCode = DecideRoadTypCodeByBaseRouteInfo_Guide(layerCode, baseRouteInfo);
            }

            return roadTypCode;
        }
        #endregion

        #region 基本路線情報よりTMI路線の道路種別コード決定(探索道路)
        /// <summary>
        /// 基本路線情報よりTMI路線の道路種別コード決定(探索道路)
        /// </summary>
        /// <param name="layerCode">レイヤコード</param>
        /// <param name="baseRouteInfo">基本路線情報</param>
        /// <returns>決定した道路種別コード</returns>
        private static string DecideRoadTypCodeByBaseRouteInfo_Guide(
             string layerCode, BaseRouteInfo baseRouteInfo)
        {
            // 決定した道路種別コード
            string roadTypCode = null;

            // TMI探索道路の場合
            if (baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_1)
            {
                // 道路種別コードが「1：一般国道」の場合、「3：一般国道」を設定
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_3;
            }
            else if (baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_2)
            {
                // 道路種別コードが「2：主要地方道」の場合、「4：主要地方道（都道府県道）」を設定
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_4;
            }
            else if (baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_3)
            {
                // 道路種別コードが「3：指定市道」の場合、「4：主要地方道（都道府県道）」を設定
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_4;
            }
            else if (baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_4)
            {
                // 道路種別コードが「4：一般都道府県道」の場合、「6：一般都道府県道」を設定
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_6;
            }
            else if (baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_5)
            {
                // 道路種別コードが「5：主要一般道」の場合、「7：一般道」を設定
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_NOMAL_7;
            }
            else if (baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_6)
            {
                // 道路種別コードが「6：地形図一般道」の場合、「7：一般道」を設定
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_NOMAL_7;
            }
            else if (baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_7)
            {
                // 道路種別コードが「7：住宅地図一般道」の場合、「7：一般道」を設定
                roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_NOMAL_7;
            }
            else if (baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_8 ||
                        baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_9 ||
                        baseRouteInfo.RoadTypCode == BaseRouteInfo.Code.RoadTypCode_10)
            {
                // 道路種別コードが「8：地形図細道路」or 道路種別コードが「9：住宅地図細道路」or 道路種別コードが「10：その他細道路（非探索道路）」の場合
                if (layerCode == "0")
                {
                    // 道路レイヤーコードが「0」の場合、「9：非探索道路」を設定
                    roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_SEARCH_9;
                }
                else if (layerCode == "1" || layerCode == "2" || layerCode == "3")
                {
                    // 道路レイヤーコードが「0」以外の場合、「7：一般道」を設定
                    roadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_NOMAL_7;
                }
            }

            return roadTypCode;
        }
        #endregion

        #region TMI路線のメンテナンス
        /// <summary>
        /// TMI路線のメンテナンス
        /// </summary>
        /// <param name="tmiRoutes">TMI路線リスト</param>
        /// <param name="typFlg">道路種類コード</param>
        /// <param name="layerCode">レイヤコード</param>
        /// <returns>メンテナンス後TMI路線リスト</returns>
        private static List<TMIRouteAttribute> MaintainTmiRoutes(
            List<TMIRouteAttribute> tmiRoutes,
            int typFlg,
            string layerCode)
        {
            // 入力したTMI路線リストにデータがない場合
            if (tmiRoutes == null || tmiRoutes.Count < 1)
            {
                return null;
            }

            // 道路種別コードメンテナンス：路線情報の46変換
            List<TMIRouteAttribute> maintainedTmiRoutes =
                MaintainRoadTypCode(tmiRoutes, typFlg, layerCode);

            // 道路種別コードメンテナンス：ソートする
            return SortMaintainedTmiRoutes(maintainedTmiRoutes);
        }
        #endregion

        #region 道路種別コードメンテナンス
        /// <summary>
        /// 道路種別コードメンテナンス
        /// </summary>
        /// <param name="tmiRoutes">TMI路線リスト</param>
        /// <param name="typFlg">道路種類コード</param>
        /// <param name="layerCode">レイヤコード</param> 
        /// <returns>メンテナンス後TMI路線リスト</returns>
        private static List<TMIRouteAttribute> MaintainRoadTypCode(
                                        List<TMIRouteAttribute> tmiRoutes,
                                        int typFlg,
                                        string layerCode)
        {
            // メンテナンスしたTMI路線リスト
            List<TMIRouteAttribute> maintainedTmiRoutes = null;

            if (typFlg == RoadTypCodeConvertUtility.ROAD_TYPE_GUIDE)
            {
                // 1：探索道路の場合、TMI探索道路の道路種別コードメンテナンス
                maintainedTmiRoutes = MaintainRoadTypCodeForTmiGuideRod(tmiRoutes, layerCode);
            }

            return maintainedTmiRoutes;
        }
        #endregion

        #region TMI探索道路の道路種別コードメンテナンス
        /// <summary>
        /// TMI探索道路の道路種別コードメンテナンス
        /// </summary>
        /// <param name="tmiRoutes">TMI路線リスト</param>
        /// <param name="layerCode">レイヤコード</param> 
        /// <returns>メンテナンス後TMI路線リスト</returns>
        private static List<TMIRouteAttribute> MaintainRoadTypCodeForTmiGuideRod(
                                        List<TMIRouteAttribute> tmiRoutes,
                                        string layerCode)
        {
            // メンテナンスしたTMI路線リスト
            List<TMIRouteAttribute> maintainedTmiRoutes = new List<TMIRouteAttribute>();

            // 主路線取得(※TMI路線リスト[0]を主路線とする※)
            TMIRouteAttribute mainTmiRoute = tmiRoutes[0];

            // TMI路線リストを繰り返し、道路種別コードメンテナンスを行う
            foreach (TMIRouteAttribute tmiRoute in tmiRoutes)
            {
                // 主路線の道路種別が｢4｣、重用の道路種別｢6｣の場合、道路種別コードメンテナンスを行う
                MaintainMainRouteNo4AndRepeatRouteNo6(mainTmiRoute, tmiRoute);

                // 主路線の道路種別が｢6｣、重用の道路種別｢4｣の場合、道路種別コードメンテナンスを行う
                MaintainMainRouteNo6AndRepeatRouteNo4(mainTmiRoute, tmiRoute);

                maintainedTmiRoutes.Add(tmiRoute);
            }

            return maintainedTmiRoutes;
        }
        #endregion

        #region 主路線の道路種別が｢4｣、重用の道路種別｢6｣の場合、道路種別コードメンテナンス
        /// <summary>
        /// 主路線の道路種別が｢4｣、重用の道路種別｢6｣の場合、道路種別コードメンテナンス
        /// </summary>
        /// <param name="mainTmiRoute">主路線</param>
        /// <param name="repeatTmiRoute">重用路線</param>
        private static void MaintainMainRouteNo4AndRepeatRouteNo6(
            TMIRouteAttribute mainTmiRoute, TMIRouteAttribute repeatTmiRoute)
        {
            if (mainTmiRoute.RoadTypCode == RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_4)
            {
                if (repeatTmiRoute.RoadTypCode == RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_6)
                {
                    // 主路線の道路種別が｢4｣、重用の道路種別｢6｣の場合、重用の道路種別は｢4｣に変更する
                    repeatTmiRoute.RoadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_4;
                }
            }
        }
        #endregion

        #region 主路線の道路種別が｢6｣、重用の道路種別｢4｣の場合、道路種別コードメンテナンス
        /// <summary>
        /// 主路線の道路種別が｢6｣、重用の道路種別｢4｣の場合、道路種別コードメンテナンス
        /// </summary>
        /// <param name="mainTmiRoute">主路線</param>
        /// <param name="repeatTmiRoute">重用路線</param>
        private static void MaintainMainRouteNo6AndRepeatRouteNo4(
            TMIRouteAttribute mainTmiRoute, TMIRouteAttribute repeatTmiRoute)
        {
            if (mainTmiRoute.RoadTypCode == RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_6)
            {
                if (repeatTmiRoute.RoadTypCode == RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_4)
                {
                    // 主路線の道路種別が｢6｣、重用の道路種別｢4｣の場合、重用の道路種別は｢6｣に変更する
                    repeatTmiRoute.RoadTypCode = RoadTypCodeConvertUtility.ROD_CATEGORY_CODE_CONVERT_6;
                }
            }
        }
        #endregion

        #region メンテナンスしたTMI路線リストのソート
        /// <summary>
        /// メンテナンスしたTMI路線リストのソート
        /// </summary>
        /// <param name="maintainedTmiRoutes">メンテナンスしたTMI路線リスト</param>
        /// <returns>メンテナンス後のTMI路線リスト(主路線・重用路線１)</returns>
        private static List<TMIRouteAttribute> SortMaintainedTmiRoutes(List<TMIRouteAttribute> maintainedTmiRoutes)
        {
            // メンテナンスしたTMI路線リストにデータ1件以下の場合
            if (maintainedTmiRoutes == null)
            {
                return null;
            }
            else if (maintainedTmiRoutes.Count == 1)
            {
                // 1件の場合、ソート必要がない
                return maintainedTmiRoutes;
            }

            // 戻り値：路線リスト
            List<TMIRouteAttribute> routeList = new List<TMIRouteAttribute>();

            // 道路種別が 1, 2, 0(路線番号が1以上), 3, 4, 5, 6, 7, 8, 9, 0(路線番号=0) の順
            // 道路種別が同じ場合は路線番号の昇順 (ただし路線番号「0」は最大値として扱う)
            // 道路種別が1、2の順、且つ路線番号が昇順のTMI路線リスト取得
            List<TMIRouteAttribute> tempTmiRoutesWithRoadTypCode1And2 = maintainedTmiRoutes.Where(
                maintainedRoute => maintainedRoute.RoadTypCode == "1" ||
                                   maintainedRoute.RoadTypCode == "2").OrderBy(
                maintainedRoute => maintainedRoute.RoadTypCode).ThenBy(
                maintainedRoute => maintainedRoute.RoadNo, new RouteNoComparer()).ToList<TMIRouteAttribute>();

            if (tempTmiRoutesWithRoadTypCode1And2 != null && tempTmiRoutesWithRoadTypCode1And2.Count > 0)
            {
                // 最初の要素の道路種別コードを主路線のTMIDB道路種別コードとする
                // ２番目の要素の道路種別コードを重用路線１のTMIDB道路種別コードとする
                if (AddRouteList(tempTmiRoutesWithRoadTypCode1And2, ref routeList) == true)
                {
                    return routeList;
                }
            }

            // 道路種別が0、且つ路線番号(路線番号1以上)が昇順のTMI路線リスト取得
            List<TMIRouteAttribute> tempTmiRoutesWithRoadTypCode0AndNotRouteNo0 = maintainedTmiRoutes.Where(
                maintainedRoute => maintainedRoute.RoadTypCode == "0" &&
                                   maintainedRoute.RoadNo > 0).OrderBy(
                maintainedRoute => maintainedRoute.RoadTypCode).ThenBy(
                maintainedRoute => maintainedRoute.RoadNo).ToList<TMIRouteAttribute>();

            if (tempTmiRoutesWithRoadTypCode0AndNotRouteNo0 != null && tempTmiRoutesWithRoadTypCode0AndNotRouteNo0.Count > 0)
            {
                // 最初の要素の道路種別コードを主路線のTMIDB道路種別コードとする
                // ２番目の要素の道路種別コードを重用路線１のTMIDB道路種別コードとする
                if (AddRouteList(tempTmiRoutesWithRoadTypCode0AndNotRouteNo0, ref routeList) == true)
                {
                    return routeList;
                }
            }

            return SortMaintainedTmiRoutes_2(maintainedTmiRoutes, routeList);
        }
        #endregion

        #region メンテナンスしたTMI路線リストのソート２
        /// <summary>
        /// メンテナンスしたTMI路線リストのソート２
        /// </summary>
        /// <param name="maintainedTmiRoutes">メンテナンスしたTMI路線リスト</param>
        /// <param name="routeList">路線リスト</param>
        /// <returns>メンテナンス後のTMI路線リスト(主路線・重用路線１)</returns>
        private static List<TMIRouteAttribute> SortMaintainedTmiRoutes_2(List<TMIRouteAttribute> maintainedTmiRoutes, List<TMIRouteAttribute> routeList)
        {
            // 道路種別が3～9、且つ路線番号が昇順のTMI路線リスト取得
            List<TMIRouteAttribute> tempTmiRoutesWithRoadTypCode3To9 = maintainedTmiRoutes.Where(
                maintainedRoute => maintainedRoute.RoadTypCode == "3" ||
                                   maintainedRoute.RoadTypCode == "4" ||
                                   maintainedRoute.RoadTypCode == "5" ||
                                   maintainedRoute.RoadTypCode == "6" ||
                                   maintainedRoute.RoadTypCode == "7" ||
                                   maintainedRoute.RoadTypCode == "8" ||
                                   maintainedRoute.RoadTypCode == "9").OrderBy(
                maintainedRoute => maintainedRoute.RoadTypCode).ThenBy(
                maintainedRoute => maintainedRoute.RoadNo).ToList<TMIRouteAttribute>();

            if (tempTmiRoutesWithRoadTypCode3To9 != null && tempTmiRoutesWithRoadTypCode3To9.Count > 0)
            {
                // 最初の要素の道路種別コードを主路線のTMIDB道路種別コードとする
                // ２番目の要素の道路種別コードを重用路線１のTMIDB道路種別コードとする
                if (AddRouteList(tempTmiRoutesWithRoadTypCode3To9, ref routeList) == true)
                {
                    return routeList;
                }
            }

            // 道路種別が0、且つ路線番号(路線番号=0)が昇順のTMI路線リスト取得
            List<TMIRouteAttribute> tempTmiRoutesWithRoadTypCode0AndRouteNo0 = maintainedTmiRoutes.Where(
                maintainedRoute => maintainedRoute.RoadTypCode == "0" &&
                                   (maintainedRoute.RoadNo == 0 ||
                                   maintainedRoute.RoadNo == null)).ToList<TMIRouteAttribute>();

            if (tempTmiRoutesWithRoadTypCode0AndRouteNo0 != null && tempTmiRoutesWithRoadTypCode0AndRouteNo0.Count > 0)
            {
                // 最初の要素の道路種別コードを主路線のTMIDB道路種別コードとする
                // ２番目の要素の道路種別コードを重用路線１のTMIDB道路種別コードとする
                if (AddRouteList(tempTmiRoutesWithRoadTypCode0AndRouteNo0, ref routeList) == true)
                {
                    return routeList;
                }
            }

            return routeList;
        }
        #endregion

        #region ソートしたTMI路線リストから主路線・重用路線１(TMI道路種別コード・路線番号)を取得
        /// <summary>
        /// ソートしたTMI路線リストから主路線・重用路線１(TMI道路種別コード・路線番号)を取得
        /// </summary>
        /// <param name="maintainedTmiRoutes">メンテナンスしたTMI路線リスト</param>
        /// <param name="routeList">路線リスト</param>
        /// <returns>True:路線情報の取得処理を完了する</returns>
        private static bool AddRouteList(List<TMIRouteAttribute> maintainedTmiRoutes, ref List<TMIRouteAttribute> routeList)
        {
            // 路線情報を2件まで取得
            for (int i = 0; i < maintainedTmiRoutes.Count; i++)
            {
                routeList.Add(maintainedTmiRoutes[i]);

                // 重用路線１まで取得できたら完了
                if (routeList.Count >= 2)
                {
                    return true;
                }
            }

            // TMI路線リストのソート処理を続ける
            return false;
        }
        #endregion
    }

    #region TMIDB道路種別コード転換用RoadWrappper構造体クラス
    /// <summary>
    /// RoadWrappper構造体クラス
    /// </summary>
    public class RoadWrappper
    {
        /// <summary>
        /// フェリー周辺互換情報キャッシュが初期されたか
        /// </summary>
        private bool _isExistsCacheDFrryCompatibleInfo = false;

        /// <summary>
        /// フェリー周辺互換情報キャッシュ
        /// </summary>
        private DFrryCompatibleInfo _cacheDFrryCompatibleInfo = null;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="dataServiceWrapper">データサービスのラッパー</param>
        /// <param name="roadMain">基幹道路</param>
        public RoadWrappper(DataServiceWrapper dataServiceWrapper, SRoadMain roadMain)
        {
            this.DBWrapper = dataServiceWrapper; 
            this.RoadMain = roadMain;
        }

        /// <summary>
        /// データサービス
        /// </summary>
        public DataServiceWrapper DBWrapper { get; private set; }

        /// <summary>
        /// 基幹道路
        /// </summary>
        public SRoadMain RoadMain { get; private set; }

        /// <summary>
        /// レイヤコード
        /// </summary>
        public string LayerCode { get; set; }

        /// <summary>
        /// 路線番号
        /// </summary>
        public string RoadNo { get; private set; }

        /// <summary>
        /// TMIDB道路種別コード
        /// </summary>
        public string RoadTypCode { get; set; }

        /// <summary>
        /// フェリー周辺互換情報
        /// </summary>
        public DFrryCompatibleInfo FrryCompatibleInfo
        {
            get
            {
                if (this._isExistsCacheDFrryCompatibleInfo == false)
                {
                    // フェリー周辺互換情報
                    var dFrryCompatibleInfoList = this.DBWrapper.GetDependencyItems(
                                                this.RoadMain, 
                                                DataModelTypeID.CONTENTS_TYPE_DFRRYCOMPATIBLEINFO);
                    if (null == dFrryCompatibleInfoList || dFrryCompatibleInfoList.Count == 0)
                    {
                        this._cacheDFrryCompatibleInfo = null;
                    }
                    else
                    {
                        this._cacheDFrryCompatibleInfo = dFrryCompatibleInfoList[0] as DFrryCompatibleInfo;
                    }

                    this._isExistsCacheDFrryCompatibleInfo = true;
                }

                return this._cacheDFrryCompatibleInfo;
            }
        }
    }
    #endregion

    #region 主路線重用路線構造体クラス
    /// <summary>
    /// 主路線重用路線構造体
    /// </summary>
    public class TMIRouteAttribute
    {
        #region 変数定義
        /// <summary>
        /// 主路線-道路種別コード
        /// </summary>
        private string _roadTypCode;

        /// <summary>
        /// 主路線-路線番号
        /// </summary>
        private ushort? _roadNo;
        #endregion

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TMIRouteAttribute()
        {
        }

        /// <summary>
        /// 主路線道路種別コード
        /// </summary>
        public string RoadTypCode
        {
            get { return _roadTypCode; }
            set { _roadTypCode = value; }
        }

        /// <summary>
        /// 路線番号
        /// </summary>
        public ushort? RoadNo
        {
            get { return _roadNo; }
            set { _roadNo = value; }
        }
    }
    #endregion

    #region 道路レイヤコード変換処理クラス
    /// <summary>
    /// 10.6.8. 道路レイヤコード変換処理
    /// </summary>
    public class RodLayoutCodeConvert
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public RodLayoutCodeConvert()
        {
        }

        /// <summary>
        /// 2. 道路レイヤコード変換処理
        /// </summary>
        /// <param name="roadWrappper">TMI道路</param>
        /// <param name="typFlg">道路種類コード</param>
        public void RoadLayoutCodeConvert(RoadWrappper roadWrappper, int typFlg)
        {
            // 探索と表示以外
            if (typFlg != RoadTypCodeConvertUtility.ROAD_TYPE_GUIDE &&
                typFlg != RoadTypCodeConvertUtility.ROAD_TYPE_MM)
            {
                return;
            }

            // 「 2-1)  変換用パラメータ値の決定」探索レイヤコード取得
            byte? guideLayerCode = GetGuideLayerCode(roadWrappper, typFlg);

            // 「 2-1)  変換用パラメータ値の決定」探索案内道路コード取得
            byte? guideRoadCode = GetGuideRoadCode(roadWrappper, typFlg);

            //// 2-1)  レイヤコード決定
            roadWrappper.LayerCode = RodLayoutConvert(typFlg, guideLayerCode, guideRoadCode);
        }

        /// <summary>
        /// 探索レイヤコード取得
        /// </summary>
        /// <param name="roadWrappper">TMI道路</param>
        /// <param name="typFlg">道路種類コード</param>
        /// <returns>探索レイヤコード</returns>
        private byte? GetGuideLayerCode(RoadWrappper roadWrappper, int typFlg)
        {
            byte? guideLayerCode = null;

            // 探索道路
            if (typFlg == RoadTypCodeConvertUtility.ROAD_TYPE_GUIDE)
            {
                // TMI道路．フェリー周辺互換情報
                if (roadWrappper.FrryCompatibleInfo != null)
                {
                    // フェリー周辺互換情報があり、フェリー周辺互換情報．探索レイヤコード
                    guideLayerCode = roadWrappper.FrryCompatibleInfo.GuideLayerCode;
                }
                else
                {
                    // フェリー周辺互換情報がなし、基幹道路．探索レイヤコード
                    guideLayerCode = roadWrappper.RoadMain.GuideLayerCode;
                }
            }

            return guideLayerCode;
        }

        /// <summary>
        /// 探索案内道路コード取得
        /// </summary>
        /// <param name="roadWrappper">TMI道路</param>
        /// <param name="typFlg">道路種類コード</param>
        /// <returns>探索案内道路コード</returns>
        private byte? GetGuideRoadCode(RoadWrappper roadWrappper, int typFlg)
        {
            byte? guideRoadCode = null;

            // 探索道路
            if (typFlg == RoadTypCodeConvertUtility.ROAD_TYPE_GUIDE)
            {
                // フェリー周辺互換情報があり
                if (roadWrappper.FrryCompatibleInfo != null)
                {
                    guideRoadCode = roadWrappper.FrryCompatibleInfo.GuideRoadCode;
                }
                else
                {
                    guideRoadCode = roadWrappper.RoadMain.GuideRoadCode;
                }
            }

            return guideRoadCode;
        }

        /// <summary>
        /// レイヤコード変換
        /// </summary>
        /// <param name="typFlg">道路種類コード</param>
        /// <param name="guideLayerCode">探索レイヤコード</param>
        /// <param name="guideRoadCode">探索案内道路コード</param>
        /// <returns>レイヤコード</returns>
        private string RodLayoutConvert(int typFlg,
                                        byte? guideLayerCode,
                                        byte? guideRoadCode)
        {
            if (guideLayerCode != null)
            {
                // 探索レイヤコードが設定されている:探索レイヤコード
                return guideLayerCode.ToString();
            }
            else
            {
                //// 探索レイヤコードが設定されていない
                if (guideRoadCode == RoadTypCodeConvertUtility.BASIC_GUID_ROD_2)
                {
                    // 探索案内道路コードが「2：非探索」である
                    return RoadTypCodeConvertUtility.ROD_LAYCODE_4;
                }
                else
                {
                    // 上記以外
                    return RoadTypCodeConvertUtility.ROD_LAYCODE_0;
                }
            }
        }
    }
    #endregion

    #region 路線番号比較クラス（0は最大として扱う）
    /// <summary>
    /// 路線番号比較クラス（0は最大として扱う）
    /// </summary>
    public class RouteNoComparer : IComparer<ushort?>
    {
        /// <summary>
        /// unshort型の値の比較(nullは最小、0は最大として扱う)
        /// </summary>
        /// <param name="x">unshort型の値x</param>
        /// <param name="y">unshort型の値y</param>
        /// <returns>0:同じ、1:xが大きい、-1:yが大きい</returns>
        public int Compare(ushort? x, ushort? y)
        {
            if (x == null)
            {
                if (y == null)
                {
                    // xとyは同じ
                    return 0;
                }
                else
                {
                    // xが小さい
                    return -1;
                }
            }
            else
            {
                if (y == null)
                {
                    // xが大きい
                    return 1;
                }
                else
                {
                    if (x == 0)
                    {
                        if (y == 0)
                        {
                            // xとyは同じ
                            return 0;
                        }
                        else
                        {
                            // xが大きい
                            return 1;
                        }
                    }
                    else
                    {
                        if (y == 0)
                        {
                            // xが小さい
                            return -1;
                        }
                    }

                    if (x == y)
                    {
                        return 0;
                    }
                    else if (x < y)
                    {
                        return -1;
                    }
                    else
                    {
                        return 1;
                    }
                }
            }
        }
    }
    #endregion
}

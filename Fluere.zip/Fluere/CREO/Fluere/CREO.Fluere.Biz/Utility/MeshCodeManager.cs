﻿using System.Collections.Generic;
using System.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;
using CREO.FW.TMIGeometry;
using CREO.FW.Utilities;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 処理対象とするメッシュコードを管理する
    /// </summary>
    public class MeshCodeManager
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        static MeshCodeManager()
        {
            MeshCodeList = new HashSet<string>();
            MeshRectDict = new Dictionary<string, MeshCodeWrapper>();
            MeshPositionDict = new Dictionary<Coordinate, MeshCodeWrapper>();
            MeshPositionKeyList = new List<Coordinate>();
            MeshPositionKeyComparer = new MeshRectKeyComparer();
        }
        
        /// <summary>
        /// コンストラクター
        /// </summary>
        protected MeshCodeManager()
        {
        }

        /// <summary>
        /// メッシュコード一覧
        /// </summary>
        public static HashSet<string> MeshCodeList { get; private set; }

        /// <summary>
        /// メッシュコード一覧
        /// </summary>
        protected static Dictionary<string, MeshCodeWrapper> MeshRectDict { get; private set; }

        /// <summary>
        /// メッシュに属する判断処理用Dictionary
        /// </summary>
        protected static Dictionary<Coordinate, MeshCodeWrapper> MeshPositionDict { get; private set; }

        /// <summary>
        /// メッシュに属する判断処理用リスト
        /// </summary>
        protected static List<Coordinate> MeshPositionKeyList { get; private set; }

        /// <summary>
        /// メッシュに属する判断処理用比較子
        /// </summary>
        protected static MeshRectKeyComparer MeshPositionKeyComparer { get; private set; }

        /// <summary>
        /// 2次メッシュ矩形取得
        /// </summary> 
        /// <param name="meshCode">2次メッシュコード</param>
        /// <returns>2次メッシュ矩形</returns>
        public static CoordinateRect GetUnManagedMeshRect(string meshCode)
        {
            return GetMeshMatrix(8102, meshCode);
        }

        /// <summary>
        /// 2次メッシュ矩形取得
        /// </summary> 
        /// <param name="meshType">2次メッシュタイプ</param>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <returns>2次メッシュ矩形</returns>
        protected static CoordinateRect GetMeshMatrix(ushort meshType, string meshCode)
        {
            CoordinateRect rect;

            // メッシュ矩形取得結果
            bool result;
            result = GISLib.GetCoordRectByMeshCode(meshType, meshCode, out rect);
            if (!result)
            {
                string message = string.Format("メッシュ矩形が取得できません。メッシュタイプ:{0} メッシュコード:{1}",
                    meshType,
                    meshCode);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            return rect;
        }

        /// <summary>
        /// 対象メッシュを追加する
        /// </summary>
        /// <param name="intMeshCode">2次メッシュコード</param>
        public static void AddMesh(int intMeshCode)
        {
            AddMesh(intMeshCode.ToString());
        }

        /// <summary>
        /// 対象メッシュを追加する
        /// </summary>
        /// <param name="meshCode">2次メッシュコード</param>
        public static void AddMesh(string meshCode)
        {
            if (!MeshCodeList.Contains(meshCode))
            {
                MeshCodeList.Add(meshCode);

                MeshCodeWrapper curMeshCodeWrapper = new MeshCodeWrapper(meshCode, GetMeshMatrix(8102, meshCode));
                MeshRectDict.Add(meshCode, curMeshCodeWrapper);
                MeshPositionDict.Add(curMeshCodeWrapper.MeshKey, curMeshCodeWrapper);

                int insertPos = MeshPositionKeyList.BinarySearch(curMeshCodeWrapper.MeshKey, MeshPositionKeyComparer);
                if (insertPos < 0)
                {
                    // 検索座標よりも大きい最初の座標のインデックスが生成されます
                    insertPos = ~insertPos;

                    if (insertPos >= MeshPositionKeyList.Count)
                    {
                        insertPos = MeshPositionKeyList.Count;
                    }
                    else if (insertPos == 0)
                    {
                        insertPos = 0;
                    }

                    MeshPositionKeyList.Insert(insertPos, curMeshCodeWrapper.MeshKey);
                }
            }
        }

        /// <summary>
        /// デバッグ情報を出力する
        /// </summary>
        public static void ShowDebugInfo()
        {
            if (LogUtility.IsDebugEnabled)
            {
                int index = 0;
                foreach (var meshKey in MeshPositionKeyList)
                {
                    LogUtility.WriteDebug("メッシュ:{0} {1} ('{2}', geometry::STGeomFromText('{3}', 0) )",
                        MeshPositionDict[meshKey].MeshCode,
                        string.Format("({0},{1})", meshKey.Longitude, meshKey.Latitude),
                        index++,
                        GeometryUtil.ParseCoordinateRectToPolygonGeometryString(MeshPositionDict[meshKey].MeshRect));
                }
            }
        }

        /// <summary>
        /// メッシュコードを指定し、2次メッシュ矩形取得
        /// </summary>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <returns>2次メッシュ矩形</returns>
        public static CoordinateRect GetMeshRect(string meshCode)
        {
            AddMesh(meshCode);

            return MeshRectDict[meshCode].MeshRect;
        }

        /// <summary>
        /// メッシュコードを指定し、2次メッシュ範囲取得
        /// </summary>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <returns>2次メッシュ範囲</returns>
        public static List<Coordinate> GetMeshCoordinate(string meshCode)
        {
            CoordinateRect tempMeshRect = GetMeshRect(meshCode);
            return new List<Coordinate>()
            {
                tempMeshRect.BottomLeft,
                new Coordinate(tempMeshRect.BottomLeft.Longitude, tempMeshRect.TopRight.Latitude),
                tempMeshRect.TopRight,
                new Coordinate(tempMeshRect.TopRight.Longitude, tempMeshRect.BottomLeft.Latitude),
                tempMeshRect.BottomLeft
            };
        }

        /// <summary>
        /// 座標を指定し、属するメッシュを取得する
        /// </summary>
        /// <param name="targetPoint">点座標</param>
        /// <returns>属するメッシュコード(処理メッシュ範囲外の場合、nullを戻す)</returns>
        public static string GetMeshCode(Coordinate targetPoint)
        {
            string retMesh = null;

            Coordinate searchPoint = new Coordinate(targetPoint);

            // 座標を指定し、メッシュを代表する座標(緯度)を検索する
            int searchPos = MeshPositionKeyList.BinarySearch(searchPoint, MeshPositionKeyComparer);
            if (searchPos < 0)
            {
                // 検索座標よりも大きい最初の座標のインデックスが生成されます
                searchPos = ~searchPos;

                if (searchPos >= MeshPositionKeyList.Count)
                {
                    searchPos = MeshPositionKeyList.Count - 1;
                }
                else if (searchPos == 0)
                {
                    searchPos = 0;
                }
                else
                {
                    // 検索座標よりも小さい最初の座標のインデックスが生成されます
                    searchPos = searchPos - 1;
                }

                // 座標を指定し、メッシュを代表する座標(経度)を検索する
                searchPoint.Latitude = MeshPositionKeyList[searchPos].Latitude;
                searchPos = MeshPositionKeyList.BinarySearch(searchPoint, MeshPositionKeyComparer);
                if (searchPos < 0)
                {
                    // 検索座標よりも大きい最初の座標のインデックスが生成されます
                    searchPos = ~searchPos;

                    if (searchPos >= MeshPositionKeyList.Count)
                    {
                        searchPos = MeshPositionKeyList.Count - 1;
                    }
                    else if (searchPos == 0)
                    {
                        searchPos = 0;
                    }
                    else
                    {
                        // 検索座標よりも小さい最初の座標のインデックスが生成されます
                        searchPos = searchPos - 1;
                    }
                }
            }

            MeshCodeWrapper curMeshCodeWrapper = MeshPositionDict[MeshPositionKeyList[searchPos]];
            if (GeometryUtil.IsCoordinateBelongToMesh(curMeshCodeWrapper.MeshRect, targetPoint))
            {
                retMesh = curMeshCodeWrapper.MeshCode;
            }
            else
            {
                if (LogUtility.IsDebugEnabled)
                {
                    // チェック結果をチェックする
                    string targetMeshCode = MeshCodeUtility.GetMeshCode(8102, targetPoint);
                    if (MeshCodeList.Contains(targetMeshCode))
                    {
                        LogUtility.WriteInfo("※対象メッシュ範囲外であるデータ：メッシュ：{0} (位置：{1}, Point({2} {3})",
                            targetMeshCode,
                            searchPos,
                            targetPoint.Longitude,
                            targetPoint.Latitude);
                    }
                }
            }

            return retMesh;
        }

        /// <summary>
        /// 座標を指定し、属するメッシュを取得する
        /// </summary>
        /// <param name="startPoint">始点座標</param>
        /// <param name="endPoint">終点座標</param>
        /// <returns>属するメッシュコード(処理メッシュ範囲外の場合、nullを戻す)</returns>
        public static string GetRoadMeshCode(Coordinate startPoint, Coordinate endPoint)
        {
            return GetMeshCode(GeometryUtil.GetRoadBasePoint(startPoint, endPoint));            
        }

        /// <summary>
        /// 座標が対象メッシュに所属するかを判断する
        /// </summary>
        /// <param name="meshCode">対象メッシュ</param>
        /// <param name="coordinate">座標</param>
        /// <returns>メッシュに所属するか</returns>
        public static bool IsCoordinateBeyondToMesh(string meshCode, Coordinate coordinate)
        {
            CoordinateRect meshRect = null;

            if (MeshRectDict.ContainsKey(meshCode))
            {
                meshRect = MeshRectDict[meshCode].MeshRect;
            }
            else
            {
                meshRect = GetUnManagedMeshRect(meshCode);
            }

            return GeometryUtil.IsCoordinateBelongToMesh(meshRect, coordinate);
        }

        /// <summary>
        /// メッシュ情報を保存する
        /// </summary>
        protected class MeshCodeWrapper
        {
            /// <summary>
            /// コンストラクター
            /// </summary>
            protected MeshCodeWrapper()
            {
            }

            /// <summary>
            /// コンストラクター
            /// </summary>
            /// <param name="meshCode">2次メッシュコード</param>
            /// <param name="coordinateRect">2次メッシュ矩形</param>
            public MeshCodeWrapper(string meshCode, CoordinateRect coordinateRect)
            {
                this.MeshCode = meshCode;
                this.MeshRect = coordinateRect;
            }

            /// <summary>
            /// メッシュコード一覧
            /// </summary>
            public string MeshCode { get; private set; }

            /// <summary>
            /// メッシュコード一覧
            /// </summary>
            public CoordinateRect MeshRect { get; private set; }

            /// <summary>
            /// メッシュのキー座標
            /// </summary>
            public Coordinate MeshKey 
            {
                get { return MeshRect.BottomLeft; }
            }
        }

        #region 比較子
        /// <summary>
        /// ソート用比較子
        /// </summary>
        protected class MeshRectKeyComparer : IComparer<Coordinate>
        {
            /// <summary>
            /// 2 つのメッシュを比較し、一方が他方より小さいか、等しいか、大きいかを示す値を返します。
            /// </summary>
            /// <param name="firstObj">比較する最初のメッシュ</param>
            /// <param name="secondObj">比較する 2 番目のメッシュ</param>
            /// <returns>firstObj と secondObjの相対的な値を示す符号付き整数</returns>
            public int Compare(Coordinate firstObj, Coordinate secondObj)
            {
                int retValue = 0;

                // 緯度
                retValue = firstObj.Latitude.CompareTo(secondObj.Latitude);

                if (retValue == 0)
                {
                    // 経度
                    retValue = firstObj.Longitude.CompareTo(secondObj.Longitude);
                }

                return retValue;
            }
        }
        #endregion
    }
}

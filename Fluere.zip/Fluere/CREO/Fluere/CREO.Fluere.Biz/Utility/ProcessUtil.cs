﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// TODO: Update summary.
    /// </summary>
    public class ProcessUtil
    {
        /// <summary>
        /// GetCommandReturn
        /// </summary>
        /// <param name="command">コマンド</param>
        /// <param name="exePath">Exeパス</param>
        /// <param name="arg">コマンド引数</param>
        /// <returns>標準出力結果</returns>
        public static string GetCommandReturn(string command, string exePath, string arg)
        {
            ProcessStartInfo psInfo = new ProcessStartInfo();

            psInfo.FileName = exePath;
            psInfo.Arguments = arg;
            psInfo.WorkingDirectory = Path.GetDirectoryName(exePath);
            psInfo.CreateNoWindow = true;
            psInfo.UseShellExecute = false;
            psInfo.RedirectStandardInput = true;
            psInfo.RedirectStandardOutput = true;
            
            Process p = Process.Start(psInfo);
            using (StreamWriter sw = p.StandardInput)
            {
                sw.WriteLine(command);
                sw.Close();
            }

            string sOutput = p.StandardOutput.ReadToEnd();
            p.WaitForExit();
            p.Close();
            p.Dispose();

            return sOutput;
        }
    }
}

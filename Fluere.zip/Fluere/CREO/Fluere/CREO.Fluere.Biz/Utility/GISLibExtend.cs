﻿using System;
using System.Collections.Generic;
using System.Windows;
using CREO.FW.ExceptionHandling;
using CREO.FW.FLLib;
using CREO.FW.TMIGeometry;
using CREO.FW.Utilities;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// GISLib共通関数の拡張クラス
    /// </summary>
    public class GISLibExtend
    {
        #region 計算用定数
        /// <summary>
        /// 日本測地系
        /// </summary>
        private const string SRID_TOKYO = "4301";
        #endregion

        #region CalculateDistance 折れ線の幾何学距離計算
        /// <summary>
        /// Point座標に変換し、折れ線の幾何学距離を求める。
        /// </summary>
        /// <param name="inCoordCollection">経緯度座標リスト</param>
        /// <param name="outDistance">折れ線の幾何学距離</param>
        /// <param name="stopCoord">終了点の経緯度座標</param>
        /// <exception cref="FrameworkException">幾何学共通関数関連処理失敗</exception>
        /// <remarks>
        /// 経緯度座標リストより、Point座標に変換し、折れ線の幾何学距離を算出する。
        /// (1点目から2点目までの距離＋2点目から3点目までの距離…＋終了点の直前の補間点から終了点までの距離)
        /// </remarks>
        /// <methodnamej>折れ線の幾何学距離計算</methodnamej>
        /// <apppublic/>
        public static void CalculateDistance(
            DMCollection<Coordinate> inCoordCollection,
            out double outDistance,
            Coordinate stopCoord = null)
        {
            // 戻り値初期化
            outDistance = 0.0;

            // 対象補間点座標取得
            List<Coordinate> inCoordList = new List<Coordinate>();
            foreach (Coordinate coor in inCoordCollection)
            {
                inCoordList.Add(coor);

                if (stopCoord != null && stopCoord == coor)
                {
                    break;
                }
            }

            // 終了点が開始点の場合
            if (stopCoord != null && inCoordList.Count < 2)
            {
                outDistance = 0.0;
                return;
            }

            // 経緯度座標点列からPoint座標点列に変換
            List<Point> pointList = new List<Point>();
            GISLib.CoordinateToPoint(inCoordList, out pointList);

            // 幾何学距離を取得
            GeometryLib.CalculateDistance(pointList, out outDistance);
        }
        #endregion

        #region CalculateDistance 2点間の幾何学距離計算
        /// <summary>
        /// Point座標に変換し、2点間の幾何学距離を求める。
        /// </summary>
        /// <param name="inCoord1">1点目経緯度</param>
        /// <param name="inCoord2">2点目経緯度</param>
        /// <param name="outDistance">2点間の幾何学距離</param>
        /// <exception cref="FrameworkException">幾何学共通関数関連処理失敗</exception>
        /// <remarks>
        /// Point座標に変換し、2点間の幾何学距離を算出する。
        /// </remarks>
        /// <methodnamej>2点間の幾何学距離計算</methodnamej>
        /// <apppublic/>
        public static void CalculateDistance(
            Coordinate inCoord1,
            Coordinate inCoord2,
            out double outDistance)
        {
            // 戻り値初期化
            outDistance = 0.0;

            // 対象経緯度座標取得
            List<Coordinate> inCoordList = new List<Coordinate>();
            inCoordList.Add(inCoord1);
            inCoordList.Add(inCoord2);

            // 経緯度座標点列からPoint座標点列に変換
            List<Point> pointList = new List<Point>();
            GISLib.CoordinateToPoint(inCoordList, out pointList);

            // 幾何学距離を取得
            GeometryLib.CalculateDistance(pointList, out outDistance);
        }
        #endregion

        #region GetDistance 2点間の日本測地系距離計算
        /// <summary>
        /// 2点間の日本測地系距離を求める。
        /// </summary>
        /// <param name="inCoord1">1点目経緯度</param>
        /// <param name="inCoord2">2点目経緯度</param>
        /// <param name="outDistance">2点間の日本測地系距離（単位：m）</param>
        /// <exception cref="FrameworkException">GIS共通関数処理失敗</exception>
        /// <remarks>
        /// 2点間の日本測地系距離を算出する。
        /// </remarks>
        /// <methodnamej>2点間の日本測地系距離計算</methodnamej>
        /// <apppublic/>
        public static void GetDistance(
            Coordinate inCoord1,
            Coordinate inCoord2,
            out double outDistance)
        {
            GISLib.GetDistance(
                new CoordinateD(inCoord1.Longitude, inCoord1.Latitude),
                new CoordinateD(inCoord2.Longitude, inCoord2.Latitude),
                SRID_TOKYO,
                out outDistance);
        }
        #endregion

        #region 反時計(左)回りに回転した角度計算
        /// <summary>
        /// 始点、通過点、終点より、反時計(左)回りに回転した角度を求める。
        /// </summary>
        /// <param name="startPoint">始点座標</param>
        /// <param name="oPoint">通過点座標</param>
        /// <param name="endPoint">終点座標</param>
        /// <returns>反時計(左)回りに回転した角度</returns>
        public static double GetCCWAngle(Point startPoint, Point oPoint, Point endPoint)
        {
            double outPointAngle;

            // 有効範囲： （-180°～+180°）
            // 通過点を中心に始点より終点の方向が反時計回り（左回り）の場合、角度が正（＋）
            // 通過点を中心に始点より終点の方向が時計回リ（右回り）の場合、角度が負（-）
            GeometryLib.CalculateAngleBy3Points(
                startPoint,
                oPoint,
                endPoint,
                out outPointAngle);

            if (outPointAngle < 0)
            {
                // 交差点を中心に北方向点より道路の方向が時計回リ（右回り）
                outPointAngle = 360 + outPointAngle;
            }

            return outPointAngle;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Xml;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// XmlUtilクラス
    /// </summary>
    public class XmlUtil
    {
        /// <summary>
        /// タイプの取得
        /// </summary>
        /// <param name="classType">クラスタイプ</param>
        /// <returns>属性リスト</returns>
        public static List<string> GetPropertiesList(Type classType)
        {
            List<string> propList = new List<string>();

            PropertyInfo[] propertyInfos = classType.GetProperties();

            if (propertyInfos.Length == 0)
            {
                throw new Exception("Class " + classType.Name + " contains 0 property.");
            }

            foreach (PropertyInfo currentInfo in propertyInfos)
            {
                propList.Add(currentInfo.Name);
            }

            return propList;
        }

        /// <summary>
        /// Read XML file to List&lt;string&gt; property in classInstance
        /// </summary>
        /// <param name="classInstance">classInstance</param>
        /// <param name="reader">XmlTextReader</param>
        /// <param name="attributeName">attributeName</param>
        public static void ReadForList(
            object classInstance, XmlTextReader reader, string attributeName)
        {
            List<string> propList = XmlUtil.GetPropertiesList(classInstance.GetType());

            // ノードの属性の数だけループ
            List<string> attributeList = new List<string>();
            while (reader.MoveToNextAttribute())
            {
                // インデックスを属性に移動する
                if (reader.Name.Equals(attributeName))
                {
                    attributeList.Add(reader.Value);
                }
            }

            // 属性値を設定されていない場合、classInstanceにリストの値はnullで保持する。
            string propName = StringUtil.GetCamelStyleString(attributeName);
            if (propList.Contains(propName) && attributeList.Count > 0)
            {
                PropertyInfo protInfo = classInstance.GetType().GetProperty(propName);
                protInfo.SetValue(classInstance, attributeList, null);
            }
        }

        /// <summary>
        /// Read XML file to string property in classInstance
        /// </summary>
        /// <param name="classInstance">classInstance</param>
        /// <param name="reader">XmlTextReader</param>
        public static void ReadForString(object classInstance, XmlTextReader reader)
        {
            List<string> propList = XmlUtil.GetPropertiesList(classInstance.GetType());

            // ノードの属性の数だけループ
            while (reader.MoveToNextAttribute())
            {
                // インデックスを属性に移動する                                
                string propName = StringUtil.GetCamelStyleString(reader.Name);

                if (propList.Contains(propName))
                {
                    PropertyInfo protInfo = classInstance.GetType().GetProperty(propName);
                    if (string.IsNullOrEmpty(reader.Value))
                    {
                        protInfo.SetValue(classInstance, string.Empty, null);
                    }
                    else
                    {
                        protInfo.SetValue(classInstance, reader.Value, null);
                    }
                }
            }
        }
    }
}

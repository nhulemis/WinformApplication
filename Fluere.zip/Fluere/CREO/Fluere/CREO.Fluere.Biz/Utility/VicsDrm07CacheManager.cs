﻿using System;
using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Data;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Query;
using CREO.FW.ExceptionHandling;
using CREO.FW.TMIGeometry;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// データの格納クラス
    /// </summary>
    public class VicsDrm07CacheManager
    {
        #region インスタンス
        /// <summary>
        /// Singletonインスタンス
        /// </summary>
        private static VicsDrm07CacheManager _instance = null;
        #endregion

        #region 07向けVICSリンクファイルキャッシュ(key/value ：meshCode/ List<VICSLinkFileData>)
        /// <summary>
        /// 07向けVICSリンクファイルキャッシュ
        /// ※key/value ：2次メッシュ/ データ
        /// </summary>
        private Dictionary<int, List<VICSLinkFileData>> _vicsLinkData07Dict =
            new Dictionary<int, List<VICSLinkFileData>>();
        #endregion

        #region 07向けDRM基本道路キャッシュ(key/value ：meshCode/ List<GeoItem>)
        /// <summary>
        /// 07向けDRM基本道路キャッシュ
        /// ※key/value ：2次メッシュ/ データ
        /// </summary>
        private Dictionary<int, Dictionary<string, List<SDRMRoadBasic>>> _drmRoadBasic07Dict =
            new Dictionary<int, Dictionary<string, List<SDRMRoadBasic>>>();
        #endregion

        #region 07向けDRM全道路キャッシュ（キーが全道路ノード）(key/value ：meshCode/ List<GeoItem>)
        /// <summary>
        /// 07向けDRM全道路キャッシュ
        /// ※key/value ：2次メッシュ/ データ（キーが全道路ノード）
        /// </summary>
        private Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> _drmRoadAll07DictByAllNode =
                                    new Dictionary<int, Dictionary<string, List<SDRMRoadAll>>>();
        #endregion

        #region 07向けDRM全道路キャッシュ（キーが基本道路ノード）(key/value ：meshCode/ List<GeoItem>)
        /// <summary>
        /// 07向けDRM全道路キャッシュ
        /// ※key/value ：2次メッシュ/ データ（キーが基本道路ノード）
        /// </summary>
        private Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> _drmRoadAll07DictByBasicNode =
                                    new Dictionary<int, Dictionary<string, List<SDRMRoadAll>>>();
        #endregion

        #region 前回読み出し時間
        /// <summary>
        /// 前回読み出し時間
        /// </summary>
        private List<VicsDrmCacheData> cacheDataList = new List<VicsDrmCacheData>();
        #endregion

        #region コンストラクタ
        /// <summary>
        /// 外部よりインスタンスができないこと
        /// </summary>
        private VicsDrm07CacheManager()
        {
        }
        #endregion

        #region インスタンスの取得
        /// <summary>
        /// Singletonインスタンスの取得
        /// </summary>
        /// <returns>Singletonインスタンス</returns>
        public static VicsDrm07CacheManager GetInstance()
        {
            if (_instance == null)
            {
                _instance = new VicsDrm07CacheManager();
            }

            return _instance;
        }
        #endregion

        #region 07向けVICSリンクファイルデータの取得
        /// <summary>
        /// 07向けVICSリンクファイルデータの取得
        /// </summary>
        /// <param name="folderPath">フォルダパス</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <param name="extensionNum">拡張子番号指定</param>
        /// <returns>VICSリンクファイルデータリスト</returns>
        public List<VICSLinkFileData> Get07VICSLinkDataList(string folderPath, int meshCode, int extensionNum)
        {
            List<VICSLinkFileData> dataList = null;

            if (!this._vicsLinkData07Dict.TryGetValue(meshCode, out dataList))
            {
                double memory = GetObjectMemeryByMeshCode(folderPath, meshCode, extensionNum);

                VicsDrm07ReleaseManager.Release(memory);

                dataList = VicsDrm07FileUtility.LoadVICSLinkFileList(folderPath, meshCode, extensionNum);

                this._vicsLinkData07Dict.Add(meshCode, dataList);

                SetLastTime(meshCode, memory);

                LogUtility.WriteDataCount(
                    string.Format("【07向けVICSリンクデータ】メッシュ：{0}", meshCode),
                    LogUtility.OperationType.File,
                    dataList != null ? dataList.Count : 0);
            }

            return dataList;
        }

        /// <summary>
        /// 07向けVICSリンクファイルキャッシュ
        /// </summary>
        /// <returns>Dictionary</returns>
        public Dictionary<int, List<VICSLinkFileData>> Get07VICSLinkDataDict()
        {
            return this._vicsLinkData07Dict;
        }
        #endregion

        #region 07向けDRM基本道路の取得
        /// <summary>
        /// 07向けDRM基本道路の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadBasicリスト</returns>
        public Dictionary<string, List<SDRMRoadBasic>> Get07SDRMRoadBasic(DataService ds, int meshCode)
        {
            Dictionary<string, List<SDRMRoadBasic>> retDataDict = null;

            if (!this._drmRoadBasic07Dict.TryGetValue(meshCode, out retDataDict))
            {
                List<SDRMRoadBasic> dataList = GetSDRMRoadBasicByMeshCode(ds, meshCode);

                if (dataList != null && dataList.Count != 0)
                {
                    retDataDict = SDRMRoadQuery.MadeSDRMRoadBasicDict(dataList);
                }
                else
                {
                    retDataDict = new Dictionary<string, List<SDRMRoadBasic>>();
                }

                this._drmRoadBasic07Dict.Add(meshCode, retDataDict);

                LogUtility.WriteDataCount(string.Format("【07向けDRM基本道路】メッシュ：{0}", meshCode),
                   LogUtility.OperationType.Select,
                   dataList != null ? dataList.Count : 0);
            }

            SetLastTime(meshCode);

            return retDataDict;
        }

        /// <summary>
        /// 07向けDRM基本道路キャッシュ
        /// </summary>
        /// <returns>Dictionary</returns>
        public Dictionary<int, Dictionary<string, List<SDRMRoadBasic>>> Get07SDRMRoadBasicDict()
        {
            return this._drmRoadBasic07Dict;
        }
        #endregion

        #region 07向けDRM全道路の取得（キーが全道路ノード）
        /// <summary>
        /// 07向けDRM全道路の取得（キーが全道路ノード）
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadAllリスト</returns>
        public Dictionary<string, List<SDRMRoadAll>> Get07SDRMRoadAllByAllNode(DataService ds, int meshCode)
        {
            // 全道路ディクショナリーのリスト（一つ目が全道路ノードキー、二つ目が基本道路ノードキー）
            List<Dictionary<string, List<SDRMRoadAll>>> listDictDRMRoadAll =
                                            new List<Dictionary<string, List<SDRMRoadAll>>>(); 
            Dictionary<string, List<SDRMRoadAll>> retDataDict = null;

            if (!this._drmRoadAll07DictByAllNode.TryGetValue(meshCode, out retDataDict))
            {
                List<SDRMRoadAll> dataList = GetSDRMRoadAllByMeshCode(ds, meshCode);

                if (dataList != null && dataList.Count != 0)
                {
                    listDictDRMRoadAll = SDRMRoadQuery.MadeSDRMRoadAllDict(dataList);
                    if (listDictDRMRoadAll != null && listDictDRMRoadAll.Count > 0)
                    {
                        retDataDict = listDictDRMRoadAll[0];
                    }
                    else
                    {
                        retDataDict = new Dictionary<string, List<SDRMRoadAll>>();
                    }
                }
                else
                {
                    retDataDict = new Dictionary<string, List<SDRMRoadAll>>();
                }

                this._drmRoadAll07DictByAllNode.Add(meshCode, retDataDict);
                if (listDictDRMRoadAll != null && listDictDRMRoadAll.Count > 1)
                {
                    this._drmRoadAll07DictByBasicNode.Add(meshCode, listDictDRMRoadAll[1]);
                }

                LogUtility.WriteDataCount(string.Format("【07向けDRM全道路】メッシュ：{0}", meshCode),
                   LogUtility.OperationType.Select,
                   dataList != null ? dataList.Count : 0);
            }

            SetLastTime(meshCode);

            return retDataDict;
        }

        /// <summary>
        /// 07向けDRM全道路キャッシュ（キーが全道路ノード）
        /// </summary>
        /// <returns>Dictionary</returns>
        public Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> Get07SDRMRoadAllDictByAllNode()
        {
            return this._drmRoadAll07DictByAllNode;
        }
        #endregion

        #region 07向けDRM全道路の取得（キーが基本道路ノード）
        /// <summary>
        /// 07向けDRM全道路の取得（キーが基本道路ノード）
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadAllリスト</returns>
        public Dictionary<string, List<SDRMRoadAll>> Get07SDRMRoadAllByBasicNode(DataService ds, int meshCode)
        {
            // 全道路ディクショナリーのリスト（一つ目が全道路ノードキー、二つ目が基本道路ノードキー）
            List<Dictionary<string, List<SDRMRoadAll>>> listDictDRMRoadAll =
                                            new List<Dictionary<string, List<SDRMRoadAll>>>();
            Dictionary<string, List<SDRMRoadAll>> retDataDict = null;

            if (!this._drmRoadAll07DictByBasicNode.TryGetValue(meshCode, out retDataDict))
            {
                List<SDRMRoadAll> dataList = GetSDRMRoadAllByMeshCode(ds, meshCode);

                if (dataList != null && dataList.Count != 0)
                {
                    listDictDRMRoadAll = SDRMRoadQuery.MadeSDRMRoadAllDict(dataList);
                    if (listDictDRMRoadAll != null && listDictDRMRoadAll.Count > 1)
                    {
                        retDataDict = listDictDRMRoadAll[1];
                    }
                    else
                    {
                        retDataDict = new Dictionary<string, List<SDRMRoadAll>>();
                    }
                }
                else
                {
                    retDataDict = new Dictionary<string, List<SDRMRoadAll>>();
                }

                this._drmRoadAll07DictByBasicNode.Add(meshCode, retDataDict);
                if (listDictDRMRoadAll != null && listDictDRMRoadAll.Count > 0)
                {
                    this._drmRoadAll07DictByAllNode.Add(meshCode, listDictDRMRoadAll[0]);
                }

                LogUtility.WriteDataCount(string.Format("【07向けDRM全道路】メッシュ：{0}", meshCode),
                   LogUtility.OperationType.Select,
                   dataList != null ? dataList.Count : 0);
            }

            SetLastTime(meshCode);

            return retDataDict;
        }

        /// <summary>
        /// 07向けDRM全道路キャッシュ（キーが基本道路ノード）
        /// </summary>
        /// <returns>Dictionary</returns>
        public Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> Get07SDRMRoadAllDictByBasicNode()
        {
            return this._drmRoadAll07DictByBasicNode;
        }
        #endregion

        #region 07向けDRM基本道路の取得(Query)
        /// <summary>
        /// 07向けDRM基本道路の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadBasicリスト</returns>
        private List<SDRMRoadBasic> GetSDRMRoadBasicByMeshCode(DataService ds, int meshCode)
        {
            // 検索条件の作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 2次メッシュを指定する
            qic.ConditionExpression = new SqlConditionExpression("TargetKey",
                QueryItemOperator.Equal,
                meshCode.ToString());

            // コンテンツタイプ = DRM基本道路（SDRMRoadBasic）
            qic.TypeIDs.Add(typeof(SDRMRoadBasic).Name);

            // DRM基本道路の取得
            List<GeoItem> resultTemp = ds.QueryItems(qic);

            return resultTemp.ConvertAll(d => d as SDRMRoadBasic);
        }

        /// <summary>
        /// 07向けDRM全道路の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadAllリスト</returns>
        private List<SDRMRoadAll> GetSDRMRoadAllByMeshCode(DataService ds, int meshCode)
        {
            // 検索条件の作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 2次メッシュを指定する
            qic.ConditionExpression = new SqlConditionExpression("TargetKey",
                QueryItemOperator.Equal,
                meshCode.ToString());

            // コンテンツタイプ = DRM全道路（SDRMRoadAll）
            qic.TypeIDs.Add(typeof(SDRMRoadAll).Name);

            // DRM全道路の取得
            List<GeoItem> resultTemp = ds.QueryItems(qic);

            return resultTemp.ConvertAll(d => d as SDRMRoadAll);
        }
        #endregion

        #region 前回読み出し時間処理
        /// <summary>
        /// 前回読み出し時間の取得
        /// </summary>
        /// <returns>前回読み出し時間</returns>
        public List<VicsDrmCacheData> GetLastTimeList()
        {
            return cacheDataList;
        }

        /// <summary>
        /// 前回読み出し時間の設定
        /// </summary>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <param name="size">メモリの大きさ</param>
        private void SetLastTime(int meshCode, double size = 0)
        {
            long time = DateTime.Now.ToFileTime();

            VicsDrmCacheData cacheData = null;

            bool isExists = cacheDataList.Exists(t => t.MeshCode == meshCode);

            if (isExists)
            {
                cacheData = cacheDataList.Find(t => t.MeshCode == meshCode);

                cacheData.LastTime = time;
            }
            else
            {
                cacheData = new VicsDrmCacheData();

                cacheData.MeshCode = meshCode;

                cacheData.LastTime = time;

                cacheData.Size = size;

                cacheDataList.Add(cacheData);
            }
        }
        #endregion

        #region メモリの取得
        /// <summary>
        /// メモリの取得
        /// </summary>
        /// <param name="folder">フォルダパス</param>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <param name="extensionNum">拡張子番号指定</param>
        /// <returns>メモリ</returns>
        public double GetObjectMemeryByMeshCode(string folder, int meshCode, int extensionNum)
        {
            double memery = 0;

            string vicsFilePath = VicsDrm07FileUtility.Get07VicsLinkFilePath(folder, meshCode, extensionNum);

            string drmFilePath = VicsDrm07FileUtility.Get07DrmFilePath(meshCode);

            memery += VicsDrm07FileUtility.GetFileDataMemery(vicsFilePath, VicsOrDrm.Vics);

            memery += VicsDrm07FileUtility.GetFileDataMemery(drmFilePath, VicsOrDrm.Drm);

            return memery;
        }

        /// <summary>
        /// 合計メモリの取得
        /// </summary>
        /// <returns>合計メモリ</returns>
        public double GetCountObjectMemery()
        {
            double size = 0;

            if (cacheDataList != null && cacheDataList.Count > 0)
            {
                foreach (VicsDrmCacheData data in this.cacheDataList)
                {
                    size += data.Size;
                }
            }

            return size;
        }
        #endregion
    }
}

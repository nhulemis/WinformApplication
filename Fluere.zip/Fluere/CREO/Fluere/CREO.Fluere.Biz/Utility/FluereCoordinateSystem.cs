﻿using System;
using System.Windows;
using CREO.FW.TMIGeometry;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 既存TMIツールと同じ仕様で、座標計算クラス
    /// </summary>
    public class FluereCoordinateSystem
    {
        /// <summary>
        /// Math.PIを補正
        /// </summary>
        public const double PI = 3.1415926535897932384626433832795028841971;

        /// <summary>
        /// 経度の投影変換係数(秒単位に変換用)
        /// 座標系コード,投影変換係数X,投影変換係数Y
        /// 0300,0.0009765625,0.0009765625
        /// 8300,0.0009765625,0.0009765625
        /// </summary>
        public const double LONGITUDE_1024_FACTOR = 0.0009765625;

        /// <summary>
        /// 緯度の投影変換係数(秒単位に変換用)
        /// 座標系コード,投影変換係数X,投影変換係数Y
        /// 0300,0.0009765625,0.0009765625
        /// 8300,0.0009765625,0.0009765625
        /// </summary>
        public const double LATITUDE_1024_FACTOR = 0.0009765625;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        static FluereCoordinateSystem()
        {
            EarchRadius = 6377397.155;
            JapanGeodeticDatum = new CoordinateD(0, 0);
            MeshUnitCode = null;
            MeshUintLength = new CoordinateD(0, 0);
        }

        /// <summary>
        /// 赤道半径（6377397.155 ,299.1528128）
        /// </summary>
        public static double EarchRadius { get; set; }

        /// <summary>
        /// 投影原点の座標(ラジアン単位)
        /// 座標系コード,座標系名称,変換関数,変換クラス,測地系コード,原点緯度,原点経度
        /// 0300,CuscoZCmodelv1.1,,,3,00:00:00,00:00:00
        /// 8300,CuscoZCmodelv1.1W,,,1,00:00:00,00:00:00
        /// </summary>
        public static CoordinateD JapanGeodeticDatum { get; set; }

        /// <summary>
        /// メッシュコード
        /// </summary>
        protected static string MeshUnitCode { get; set; }

        /// <summary>
        /// １ドットあたりの距離
        /// </summary>
        protected static CoordinateD MeshUintLength { get; set; }

        /// <summary>
        /// 点の存在領域を取得する
        /// </summary>
        /// <param name="targetCoordinate">対象点</param>
        /// <param name="bottomLeft">領域の下左点</param>
        /// <param name="topRight">領域の上右点</param>
        public static void CalcPointRect(CoordinateD targetCoordinate, ref CoordinateD bottomLeft, ref CoordinateD topRight)
        {
            if (bottomLeft == null)
            {
                bottomLeft = new CoordinateD(targetCoordinate);
            }

            if (topRight == null)
            {
                topRight = new CoordinateD(targetCoordinate);
            }

            if (targetCoordinate.Longitude < bottomLeft.Longitude)
            {
                bottomLeft.Longitude = targetCoordinate.Longitude;
            }

            if (targetCoordinate.Latitude < bottomLeft.Latitude)
            {
                bottomLeft.Latitude = targetCoordinate.Latitude;
            }

            if (targetCoordinate.Longitude > topRight.Longitude)
            {
                topRight.Longitude = targetCoordinate.Longitude;
            }

            if (targetCoordinate.Latitude > topRight.Latitude)
            {
                topRight.Latitude = targetCoordinate.Latitude;
            }
        }

        /// <summary>
        /// 1/1024秒単位座標から、ラジアンに変換
        /// </summary>
        /// <param name="targetCoordinate">1/1024秒単位座標</param>
        /// <returns>ラジアン</returns>
        public static Point GetRadianFrom1024Coordinate(CoordinateD targetCoordinate)
        {
            Point retPoint = new Point();
            double newLongitude = targetCoordinate.Longitude * LONGITUDE_1024_FACTOR / 60 / 60;
            double newLatitude = targetCoordinate.Latitude * LATITUDE_1024_FACTOR / 60 / 60;
            retPoint.X = newLongitude * PI / 180;
            retPoint.Y = newLatitude * PI / 180;
            return retPoint;
        }

        /// <summary>
        /// 角度値を補正する
        /// </summary>
        /// <param name="angle">角度値</param>
        /// <returns>角度(-180～180)</returns>
        public static double GetZEPrecisionAngle(double angle)
        {
            double retAngle = angle;

            if (retAngle == -180.0)
            {
                // 角度が-180の場合
                retAngle = 180.0;
            }
            else if (retAngle > 180)
            {
                // 角度が180を超える場合
                retAngle = retAngle - 360.0;
            }
            else if (retAngle < -180)
            {
                // 角度が-180を超える場合
                retAngle = retAngle + 360.0;
            }

            return retAngle;
        }

        /// <summary>
        /// 水平線の角度から、北方向角に変換する。
        /// </summary>
        /// <param name="horizontalAngle">水平線の角度</param>
        /// <returns>北方向角</returns>
        public static double GetNorthAngleFromHorizontal(double horizontalAngle)
        {
            return GetZEPrecisionAngle(-(horizontalAngle - 90));
        }

        /// <summary>
        /// 水平線の角の差分を算出する。
        ///     右回りの方向を負(-)、左回りを正(+)とする
        /// </summary>
        /// <param name="startAngle">始点、通過点の線の水平線の角</param>
        /// <param name="endAngle">通過点、終点の線の水平線の角</param>
        /// <returns>角の差分</returns>
        public static double GetHorizontalAngleDiff(double startAngle, double endAngle)
        {
            return GetZEPrecisionAngle(endAngle - startAngle);
        }

        /// <summary>
        /// 北方向の角度の差分を算出する。
        ///     右回りの方向を負(-)、左回りを正(+)とする
        /// </summary>
        /// <param name="startAngle">始点、通過点の線の北方向の角</param>
        /// <param name="endAngle">通過点、終点の線の北方向の角</param>
        /// <returns>角の差分</returns>
        public static double GetNorthAngleDiff(double startAngle, double endAngle)
        {
            return GetZEPrecisionAngle(-(endAngle - startAngle));
        }

        /// <summary>
        /// 既存ツールと同じように、二点の距離を計算する
        /// </summary>
        /// <param name="startCoordinate">始点（1/1024秒単位）</param>
        /// <param name="endCoordinate">終点</param>
        /// <returns>距離</returns>
        public static double GetDistanceByBeforeVision(CoordinateD startCoordinate, CoordinateD endCoordinate)
        {
            // 任意二点の座標が同じの場合、エラーとなる
            if (startCoordinate == null ||
                endCoordinate == null ||
                startCoordinate == endCoordinate)
            {
                throw new ArgumentException("NULL座標または同じ座標が存在している。");
            }

            // 同一点は距離0とする
            if (startCoordinate == endCoordinate)
            {
                return 0.0;
            }

            // 1/1024秒単位座標から、ラジアンに変換する
            Point startRadian = GetRadianFrom1024Coordinate(startCoordinate);
            Point endRadian = GetRadianFrom1024Coordinate(endCoordinate);

            // 始点と終点の緯経度より弧角を算出する
            double radianDistance = Math.Acos((Math.Sin(startRadian.Y) * Math.Sin(endRadian.Y)) +
                (Math.Cos(startRadian.Y) * Math.Cos(endRadian.Y) * Math.Cos(endRadian.X - startRadian.X)));

            double distance = radianDistance * EarchRadius;

            LogUtility.WriteDebug("距離:{0} 始点:{1},{2} 終点:{3},{4}",
                distance,
                startCoordinate.Longitude,
                startCoordinate.Latitude,
                endCoordinate.Longitude,
                endCoordinate.Latitude);

            return distance;
        }

        /// <summary>
        /// 基準点を中心として、経度または緯度方向の地図座標の最小点間の距離を算出します
        /// </summary>
        /// <param name="centerCoordinate">基準点</param>
        /// <param name="isLongitude">経度方向ですか</param>
        /// <returns>最小点間の距離</returns>
        public static double GetDistancePerDotByBeforeVision(CoordinateD centerCoordinate, bool isLongitude)
        {
            // 精度
            long uintPoint = 1000;
            CoordinateD virtualCoordinate = new CoordinateD(centerCoordinate);
            if (isLongitude)
            {
                // 緯度
                virtualCoordinate.Longitude += uintPoint;
            }
            else
            {
                // 経度
                virtualCoordinate.Latitude += uintPoint;
            }

            double dDistance = GetDistanceByBeforeVision(centerCoordinate, virtualCoordinate);
            return dDistance / (double)uintPoint;
        }

        /// <summary>
        /// メッシュ範囲での１ドットあたりの距離を使用する場合
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        public static void SetMeshCode(string meshCode)
        {
            if (meshCode != MeshUnitCode)
            {
                MeshUnitCode = meshCode;

                if (string.IsNullOrEmpty(MeshUnitCode))
                {
                    MeshUintLength.Longitude = 0;
                    MeshUintLength.Latitude = 0;
                }
                else
                {
                    MeshUintLength.Longitude = 0;
                    MeshUintLength.Latitude = 0;

                    // S19が必須？
                    CoordinateRect meshRect = MeshCodeManager.GetUnManagedMeshRect(meshCode);

                    // 左下
                    CoordinateD bottomLeft = new CoordinateD(meshRect.BottomLeft.Longitude, meshRect.BottomLeft.Latitude);

                    // 右下
                    CoordinateD bottomRight = new CoordinateD(meshRect.TopRight.Longitude, meshRect.BottomLeft.Latitude);

                    // 右上
                    CoordinateD topRight = new CoordinateD(meshRect.TopRight.Longitude, meshRect.TopRight.Latitude);

                    // 左上
                    CoordinateD topLeft = new CoordinateD(meshRect.BottomLeft.Longitude, meshRect.TopRight.Latitude);

                    // 左辺
                    double dLeft = GetDistanceByBeforeVision(bottomLeft, topLeft);

                    // 右辺
                    double dRight = GetDistanceByBeforeVision(bottomRight, topRight);

                    // 範囲内のＹ軸方向１ドットあたりのｍ
                    MeshUintLength.Latitude = ((dLeft + dRight) / 2.0) / Math.Abs(topRight.Latitude - bottomLeft.Latitude);

                    // 下辺
                    double dBottom = GetDistanceByBeforeVision(bottomLeft, bottomRight);

                    // 上辺
                    double dTop = GetDistanceByBeforeVision(topRight, topLeft);

                    // 範囲内のＹ軸方向１ドットあたりのｍ
                    MeshUintLength.Longitude = ((dBottom + dTop) / 2.0) / Math.Abs(topRight.Longitude - bottomLeft.Longitude);
                }
            }
        }

        /// <summary>
        /// ２線分の角度を求めます(水平線の角を使用)。
        /// 　　右回りの方向を負(-)、左回りを正(+)とする
        /// </summary>
        /// <param name="startCoordinate1">線分１始点</param>
        /// <param name="endCoordinate1">線分１終点</param>
        /// <param name="startCoordinate2">線分２始点</param>
        /// <param name="endCoordinate2">線分２終点</param>
        /// <returns>角度</returns>
        public static double GetAngleBaseHorizontal(CoordinateD startCoordinate1, CoordinateD endCoordinate1, CoordinateD startCoordinate2, CoordinateD endCoordinate2)
        {
            double startAngle = CalcLineSlope(startCoordinate1, endCoordinate1);
            double endAngle = CalcLineSlope(startCoordinate2, endCoordinate2);
            double retAngle = GetHorizontalAngleDiff(startAngle, endAngle);

            LogUtility.WriteDebug("●２線分の角度 {0} {1}, {2} {3}, {4} {5}, {6} {7}, ({8}, {9}) {10}",
                startCoordinate1.Longitude,
                startCoordinate1.Latitude,
                endCoordinate1.Longitude,
                endCoordinate1.Latitude,
                startCoordinate2.Longitude,
                startCoordinate2.Latitude,
                endCoordinate2.Longitude,
                endCoordinate2.Latitude,
                startAngle,
                endAngle,
                retAngle);

            return retAngle;
        }

        /// <summary>
        /// ２線分の角度を求めます(北方向角を使用)。
        /// 　　右回りの方向を負(-)、左回りを正(+)とする
        /// </summary>
        /// <param name="startCoordinate1">線分１始点</param>
        /// <param name="endCoordinate1">線分１終点</param>
        /// <param name="startCoordinate2">線分２始点</param>
        /// <param name="endCoordinate2">線分２終点</param>
        /// <returns>角度</returns>
        public static double GetAngleBaseNorth(CoordinateD startCoordinate1, CoordinateD endCoordinate1, CoordinateD startCoordinate2, CoordinateD endCoordinate2)
        {
            double startAngle = CalcNorthAngle(startCoordinate1, endCoordinate1);
            double endAngle = CalcNorthAngle(startCoordinate2, endCoordinate2);
            double retAngle = GetNorthAngleDiff(startAngle, endAngle);

            LogUtility.WriteDebug("●２線分の角度 {0} {1}, {2} {3}, {4} {5}, {6} {7}, ({8}, {9}) {10}",
                startCoordinate1.Longitude,
                startCoordinate1.Latitude,
                endCoordinate1.Longitude,
                endCoordinate1.Latitude,
                startCoordinate2.Longitude,
                startCoordinate2.Latitude,
                endCoordinate2.Longitude,
                endCoordinate2.Latitude,
                startAngle,
                endAngle,
                retAngle);

            return retAngle;
        }

        /// <summary>
        /// 北方向角を計算します。
        ///     X軸（北方向）から右回りの方向を正(+)、左回りを負(-)とする。
        /// </summary>
        /// <param name="startCoordinate">始点</param>
        /// <param name="endCoordinate">終点</param>
        /// <returns>北方向角</returns>
        public static double CalcNorthAngle(CoordinateD startCoordinate, CoordinateD endCoordinate)
        {
            return GetNorthAngleFromHorizontal(CalcLineSlope(startCoordinate, endCoordinate));
        }

        /// <summary>
        /// X軸に対する傾きを計算します。
        ///     X軸から右回りの方向を負(-)、左回りを正(+)とする。
        /// </summary>
        /// <param name="startCoordinate">始点</param>
        /// <param name="endCoordinate">終点</param>
        /// <returns>傾き</returns>
        public static double CalcLineSlope(CoordinateD startCoordinate, CoordinateD endCoordinate)
        {
            // X軸からの傾きを求める為 X軸にダミーの始点を置く
            CoordinateD xCoordinate = new CoordinateD(startCoordinate.Longitude + 1024, startCoordinate.Latitude);

            // １ドットあたりの距離取得
            // 横
            double dXPoint;

            // 縦
            double dYPoint;

            // ３点の存在領域取得
            CoordinateD bottomLeft = null;
            CoordinateD topRight = null;
            CalcPointRect(xCoordinate, ref bottomLeft, ref topRight);
            CalcPointRect(startCoordinate, ref bottomLeft, ref topRight);
            CalcPointRect(endCoordinate, ref bottomLeft, ref topRight);

            if (string.IsNullOrEmpty(MeshUnitCode))
            {
                // 予め計算範囲が設定されていないとき
                long lWidth = (long)(topRight.Longitude - bottomLeft.Longitude);
                long lHeight = (long)(topRight.Latitude - bottomLeft.Latitude);
                CoordinateD oCenter = new CoordinateD(bottomLeft.Longitude + (lWidth / 2), bottomLeft.Latitude + (lHeight / 2));

                // 設定領域を基準とした縦横比(１ドットあたりの縦横の距離)を算出 
                dXPoint = GetDistancePerDotByBeforeVision(oCenter, true);
                dYPoint = GetDistancePerDotByBeforeVision(oCenter, false);

                LogUtility.WriteDebug("dx,dy {0},{1} 領域:{2} {3}, {4} {5} 始点:{6} {7} 終点:{8} {9} ダミー点:{10} {11} 基準点:{12} {13}",
                    dXPoint,
                    dYPoint,
                    bottomLeft.Longitude,
                    bottomLeft.Latitude,
                    topRight.Longitude,
                    topRight.Latitude,
                    startCoordinate.Longitude,
                    startCoordinate.Latitude,
                    endCoordinate.Longitude,
                    endCoordinate.Latitude,
                    xCoordinate.Longitude,
                    xCoordinate.Latitude,
                    oCenter.Longitude,
                    oCenter.Latitude);
            }
            else
            {
                dXPoint = MeshUintLength.Longitude;
                dYPoint = MeshUintLength.Latitude;

                LogUtility.WriteDebug("dx,dy {0},{1} 領域:{2} {3}, {4} {5} 始点:{6} {7} 終点:{8} {9} ダミー点:{10} {11} メッシュ:{12}",
                    dXPoint,
                    dYPoint,
                    bottomLeft.Longitude,
                    bottomLeft.Latitude,
                    topRight.Longitude,
                    topRight.Latitude,
                    startCoordinate.Longitude,
                    startCoordinate.Latitude,
                    endCoordinate.Longitude,
                    endCoordinate.Latitude,
                    xCoordinate.Longitude,
                    xCoordinate.Latitude,
                    MeshUnitCode);
            }

            // S19による３点角度計算
            // 2で格納した3点の存在領域の左下座標を基準としたオフセット座標値（開始点、経過点、終点）を、１ドットあたりの距離係数で補正
            Point newXCoordinate = new Point((xCoordinate.Longitude - bottomLeft.Longitude) * dXPoint, (xCoordinate.Latitude - bottomLeft.Latitude) * dYPoint);
            Point newStartCoordinate = new Point((startCoordinate.Longitude - bottomLeft.Longitude) * dXPoint, (startCoordinate.Latitude - bottomLeft.Latitude) * dYPoint);
            Point newEndCoordinate = new Point((endCoordinate.Longitude - bottomLeft.Longitude) * dXPoint, (endCoordinate.Latitude - bottomLeft.Latitude) * dYPoint);

            // 補正後、3点に対する角度計算を実施
            // ラジアンで計測した角度
            return GetAngleBy3P(newXCoordinate, newStartCoordinate, newEndCoordinate);
        }

        /// <summary>
        /// 始点(x,y),通過点(x,y),終点(x,y)で構成される角度を求める
        /// </summary>
        /// <param name="startPoint">始点(x,y)座標</param>
        /// <param name="centerPoint">通過点(x,y)座標</param>
        /// <param name="endPoint">終点(x,y)座標</param>
        /// <returns>角度</returns>
        public static double GetAngleBy3P(Point startPoint, Point centerPoint, Point endPoint)
        {
            // 任意二点の座標が同じの場合、エラーとなる
            if (startPoint == null ||
                centerPoint == null ||
                endPoint == null ||
                startPoint.Equals(centerPoint) ||
                startPoint.Equals(endPoint) ||
                centerPoint.Equals(endPoint))
            {
                throw new ArgumentException("NULL座標または同じ座標が存在している。");
            }

            // 始点と通過点のベクトル
            double startDx = startPoint.X - centerPoint.X;
            double startDy = startPoint.Y - centerPoint.Y;

            // 終点と通過点のベクトル
            double endDx = endPoint.X - centerPoint.X;
            double endDy = endPoint.Y - centerPoint.Y;

            // 2つのベクトルの内積
            double dNai = (startDx * endDx) + (startDy * endDy);

            // 2つのベクトルの大きさ
            double dTVec = Math.Sqrt(Math.Pow(startDx, 2) + Math.Pow(startDy, 2)) * Math.Sqrt(Math.Pow(endDx, 2) + Math.Pow(endDy, 2));

            // 角度算出(ラジアン)
            double x = (double)(dNai / dTVec);

            // doubleの有効小数最下位桁(15桁目)を四捨五入する。(既存ソースから、移行するので、Math.Roundを使用しない)
            double dR = 0.5 / Math.Pow(10, 15);
            if (x < 0.0)
            {
                x = x - dR;
            }
            else if (x > 0.0)
            {
                x = x + dR;
            }

            if (x < -1.0)
            {
                x = -1.0;
            }
            else if (x > 1.0)
            {
                x = 1.0;
            }

            double dRad = (double)Math.Acos(x);

            // ラジアン->度
            double retAngle = GetZEPrecisionAngle(dRad * 180.0 / PI);

            // 2つのベクトルの外積を算出
            double dGai = (startDx * endDy) - (endDx * startDy);
            if (dGai < (double)0.0)
            {
                // 角度(負)
                retAngle *= -1;
            }

            retAngle = GetZEPrecisionAngle(retAngle);

            LogUtility.WriteDebug("角度:{0} 通過点:{1},{2} 終点:{3},{4} 終点:{5},{6}",
                retAngle,
                startPoint.X,
                startPoint.Y,
                centerPoint.X,
                centerPoint.Y,
                endPoint.X,
                endPoint.Y);
            return retAngle;
        }
    }
}

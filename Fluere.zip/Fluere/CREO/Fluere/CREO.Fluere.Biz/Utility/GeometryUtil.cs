﻿using System;
using System.Collections.Generic;
using System.Windows;
using CREO.DataModel;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;
using CREO.FW.TMIGeometry;
using CREO.FW.Utilities;
using Microsoft.SqlServer.Types;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 幾何計算関連クラス
    /// </summary>
    public static class GeometryUtil
    {
        /// <summary>
        /// メッシュを拡張する回数
        /// </summary>
        private const int EXTEND_MESH_COUNT = 1;

        /// <summary>
        /// 円形が直線と実交点の算出
        /// </summary>
        /// <param name="centerPoint">円形の中心点</param>
        /// <param name="radius">半径</param>
        /// <param name="lineStartPoint">直線始点１</param>
        /// <param name="lineEndPoint">直線始点２</param>
        /// <param name="len_x">len_x</param>
        /// <param name="len_y">len_y</param>
        /// <returns>円形が直線との実交点</returns>
        public static Point? GetCrossPoint(Point centerPoint, int radius, Point lineStartPoint, Point lineEndPoint, double len_x, double len_y)
        {
            double retX = 0d;
            double retY = 0d;

            double x0 = centerPoint.X * len_x;
            double y0 = centerPoint.Y * len_y;

            double x1 = lineStartPoint.X * len_x;
            double y1 = lineStartPoint.Y * len_y;

            double x2 = lineEndPoint.X * len_x;
            double y2 = lineEndPoint.Y * len_y;

            Point? retPoint = null;

            double r = radius;
            if (Math.Abs(x2 - x1) > Math.Abs(y2 - y1))
            {
                CalculateCrossPointMain(len_x, len_y, ref retX, ref retY, x0, y0, x1, y1, x2, y2, ref retPoint, r);
            }
            else
            {
                // XとYを交換して、計算する。
                CalculateCrossPointMain(len_y, len_x, ref retY, ref retX, y0, x0, y1, x1, y2, x2, ref retPoint, r);
                if (retPoint != null)
                {
                    retPoint = new Point()
                    {
                        X = (int)(retX / len_x),
                        Y = (int)(retY / len_y),
                    };
                }
            }

            return retPoint;
        }

        /// <summary>
        ///  円形が直線と実交点の算出
        /// </summary>
        /// <param name="len_x">len_x</param>
        /// <param name="len_y">len_y</param>
        /// <param name="retX">retX</param>
        /// <param name="retY">retY</param>
        /// <param name="x0">x0</param>
        /// <param name="y0">y0</param>
        /// <param name="x1">x1</param>
        /// <param name="y1">y1</param>
        /// <param name="x2">x2</param>
        /// <param name="y2">y2</param>
        /// <param name="retPoint">retPoint</param>
        /// <param name="r">r</param>
        private static void CalculateCrossPointMain(double len_x, double len_y, ref double retX, ref double retY, double x0, double y0, double x1, double y1, double x2, double y2, ref Point? retPoint, double r)
        {
            // 座標の交換
            if (x1 > x2)
            {
                double tempX, tempY;
                tempX = x1;
                tempY = y1;

                x1 = x2;
                y1 = y2;

                x2 = tempX;
                y2 = tempY;
            }

            // 1. 直線のX1とX2が同じかどうかの判断
            if (x1 == x2)
            {
                // 2. 直線のX1とX2が同じ場合

                // X1は交点のXの値として、Yの値を算出する。
                retX = x1;

                // Yの値は円形の方程式によって、算出する。
                // Y=√(R² - (X1 – X0)²)
                retY = Math.Sqrt(Math.Pow(r, 2) - Math.Pow((x1 - x0), 2));
                if (retY < y1 || retY > y2)
                {
                    retY = -retY;
                }

                // ステップ6にジャンプする。
                // 6. 算出した（X,Y）がintに変換にて、交点座標として、返却する。
                retPoint = new Point()
                {
                    X = (int)(retX / len_x),
                    Y = (int)(retY / len_y),
                };
            }
            else
            {
                // 3. 直線のX1とX2が違う場合、直線の方程式係数の算出

                // 入力した直線の２つ点の座標によって、係数a と b　を算出する。
                // a =(double) (Y1 – Y2)/(X1 – X2)
                // b = (double) ( X1 * Y2 – X2 * Y1)/(X1 – X2)
                double a = (y1 - y2) / (x1 - x2);
                double b = ((x1 * y2) - (x2 * y1)) / (x1 - x2);

                // 4. 円形の方程式が直線の方程式との２元方程式の係数の算出

                // X² + k* X + m =0
                // k =  (double) (2 * (b – Y0) * a – 2 * X0)/ （a² + 1）
                // m =  (double) (X0² + (b – Y0)² - R²)/（a² + 1）
                double k = ((2 * (b - y0) * a) - (2 * x0)) / (Math.Pow(a, 2) + 1);
                double m = (Math.Pow(x0, 2) + Math.Pow((b - y0), 2) - Math.Pow(r, 2)) / (Math.Pow(a, 2) + 1);

                // (k/2)²-m < 0　場合、交点ないとなるので、
                // nullが返却値として、この処理を終了する。
                if (Math.Pow((k / 2), 2) - m < 0)
                {
                    retPoint = null;
                }
                else
                {
                    double retX1 = 0;
                    double retY1 = 0;

                    // 5. 円形の方程式が直線の方程式の交点座標の算出

                    // X = √((k/2)²-m) – (k/2)
                    // X = - √((k/2)²-m) – (k/2)
                    retX = Math.Sqrt(Math.Pow(k / 2, 2) - m) - (k / 2);

                    // 直線の方程式が下記の通り、一元方程式である。
                    // Y = a* X + b
                    // ② 交点座標の「X」の値が直線方程式に設定して、
                    // 交点座標の「Y」の値を算出する。
                    retY = (a * retX) + b;

                    // 入力したX1 と　X2の間にあるX値を結果とする。
                    if (retX < x1 || retX > x2)
                    {
                        retX1 = -Math.Sqrt(Math.Pow(k / 2, 2) - m) - (k / 2);
                        retY1 = (a * retX1) + b;

                        // 接近円の点判断
                        if (Math.Abs(retX - x1) > Math.Abs(retX1 - x1))
                        {
                            retX = retX1;
                            retY = retY1;
                            LogUtility.WriteTrace("【★★★円形が直線と実交点の算出：二点が円の外に存在する「接近円の点」】");
                        }
                    }

                    // 6. 算出した（X,Y）がintに変換にて、交点座標として、返却する。
                    retPoint = new Point()
                    {
                        X = (int)(retX / len_x),
                        Y = (int)(retY / len_y),
                    };
                }
            }
        }

        /// <summary>
        /// 円形が直線と実交点の算出
        /// </summary>
        /// <param name="centerPoint">円形の中心点</param>
        /// <param name="radius">半径</param>
        /// <param name="lineStartPoint">直線始点１</param>
        /// <param name="lineEndPoint">直線始点２</param>
        /// <param name="len_x">len_x</param>
        /// <param name="len_y">len_y</param>
        /// <returns>円形が直線との実交点</returns>
        public static CoordinateD GetCrossPointD(CoordinateD centerPoint,
            int radius,
            CoordinateD lineStartPoint,
            CoordinateD lineEndPoint,
            double len_x,
            double len_y)
        {
            double retX = 0d;
            double retY = 0d;

            double x0 = centerPoint.Longitude * len_x;
            double y0 = centerPoint.Latitude * len_y;

            double x1 = lineStartPoint.Longitude * len_x;
            double y1 = lineStartPoint.Latitude * len_y;

            double x2 = lineEndPoint.Longitude * len_x;
            double y2 = lineEndPoint.Latitude * len_y;

            CoordinateD retPoint = null;

            double r = radius;
            if (Math.Abs(x2 - x1) > Math.Abs(y2 - y1))
            {
                CalculateCrossPointMainD(len_x, len_y, ref retX, ref retY, x0, y0, x1, y1, x2, y2, ref retPoint, r);
            }
            else
            {
                // XとYを交換して、計算する。
                CalculateCrossPointMainD(len_y, len_x, ref retY, ref retX, y0, x0, y1, x1, y2, x2, ref retPoint, r);
                if (retPoint != null)
                {
                    retPoint = new CoordinateD()
                    {
                        Longitude = retX / len_x,
                        Latitude = retY / len_y,
                    };
                }
            }

            return retPoint;
        }

        /// <summary>
        ///  円形が直線と実交点の算出
        /// </summary>
        /// <param name="len_x">len_x</param>
        /// <param name="len_y">len_y</param>
        /// <param name="retX">retX</param>
        /// <param name="retY">retY</param>
        /// <param name="x0">x0</param>
        /// <param name="y0">y0</param>
        /// <param name="x1">x1</param>
        /// <param name="y1">y1</param>
        /// <param name="x2">x2</param>
        /// <param name="y2">y2</param>
        /// <param name="retPoint">retPoint</param>
        /// <param name="r">r</param>
        private static void CalculateCrossPointMainD(double len_x,
            double len_y,
            ref double retX,
            ref double retY,
            double x0,
            double y0,
            double x1,
            double y1,
            double x2,
            double y2,
            ref CoordinateD retPoint,
            double r)
        {
            // 座標の交換
            if (x1 > x2)
            {
                double tempX, tempY;
                tempX = x1;
                tempY = y1;

                x1 = x2;
                y1 = y2;

                x2 = tempX;
                y2 = tempY;
            }

            // 1. 直線のX1とX2が同じかどうかの判断
            if (x1 == x2)
            {
                // 2. 直線のX1とX2が同じ場合

                // X1は交点のXの値として、Yの値を算出する。
                retX = x1;

                // Yの値は円形の方程式によって、算出する。
                // Y=√(R² - (X1 – X0)²)
                retY = Math.Sqrt(Math.Pow(r, 2) - Math.Pow((x1 - x0), 2));
                if (retY < y1 || retY > y2)
                {
                    retY = -retY;
                }

                // ステップ6にジャンプする。
                // 6. 算出した（X,Y）がintに変換にて、交点座標として、返却する。
                retPoint = new CoordinateD()
                {
                    Longitude = retX / len_x,
                    Latitude = retY / len_y,
                };
            }
            else
            {
                // 3. 直線のX1とX2が違う場合、直線の方程式係数の算出

                // 入力した直線の２つ点の座標によって、係数a と b　を算出する。
                // a =(double) (Y1 – Y2)/(X1 – X2)
                // b = (double) ( X1 * Y2 – X2 * Y1)/(X1 – X2)
                double a = (y1 - y2) / (x1 - x2);
                double b = ((x1 * y2) - (x2 * y1)) / (x1 - x2);

                // 4. 円形の方程式が直線の方程式との２元方程式の係数の算出

                // X² + k* X + m =0
                // k =  (double) (2 * (b – Y0) * a – 2 * X0)/ （a² + 1）
                // m =  (double) (X0² + (b – Y0)² - R²)/（a² + 1）
                double k = ((2 * (b - y0) * a) - (2 * x0)) / (Math.Pow(a, 2) + 1);
                double m = (Math.Pow(x0, 2) + Math.Pow((b - y0), 2) - Math.Pow(r, 2)) / (Math.Pow(a, 2) + 1);

                // (k/2)²-m < 0　場合、交点ないとなるので、
                // nullが返却値として、この処理を終了する。
                if (Math.Pow((k / 2), 2) - m < 0)
                {
                    retPoint = null;
                }
                else
                {
                    // 5. 円形の方程式が直線の方程式の交点座標の算出

                    // X = √((k/2)²-m) – (k/2)
                    // X = - √((k/2)²-m) – (k/2)
                    retX = Math.Sqrt(Math.Pow(k / 2, 2) - m) - (k / 2);

                    // 入力したX1 と　X2の間にあるX値を結果とする。
                    if (retX < x1 || retX > x2)
                    {
                        retX = -Math.Sqrt(Math.Pow(k / 2, 2) - m) - (k / 2);
                    }

                    // 直線の方程式が下記の通り、一元方程式である。
                    // Y = a* X + b
                    // ② 交点座標の「X」の値が直線方程式に設定して、
                    // 交点座標の「Y」の値を算出する。
                    retY = (a * retX) + b;

                    // 6. 算出した（X,Y）がintに変換にて、交点座標として、返却する。
                    retPoint = new CoordinateD()
                    {
                        Longitude = retX / len_x,
                        Latitude = retY / len_y,
                    };
                }
            }
        }

        /// <summary>
        /// 2点間距離計算
        /// </summary>
        /// <param name="lineStartPoint">直線始点１</param>
        /// <param name="lineEndPoint">直線始点２</param>
        /// <param name="len_x">len_x(単位：センチメートル)</param>
        /// <param name="len_y">len_y(単位：センチメートル)</param>
        /// <returns>計算結果(単位：センチメートル)</returns>
        public static double GetDistance(Point lineStartPoint, Point lineEndPoint, double len_x, double len_y)
        {
            // セグメントの長さを算出
            double len_seg = System.Math.Sqrt((((lineEndPoint.Y - lineStartPoint.Y) * len_y) * ((lineEndPoint.Y - lineStartPoint.Y) * len_y))
                + (((lineEndPoint.X - lineStartPoint.X) * len_x) * ((lineEndPoint.X - lineStartPoint.X) * len_x)));

            return len_seg;
        }

        #region 基幹道路が指定2次メッシュに属するか判断
        /// <summary>
        /// 基幹道路が指定2次メッシュに属するか判断
        /// </summary>
        /// <param name="geometry">基幹道路座標</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>判定結果</returns>
        public static bool CheckRoadInCoordRect(DMCollection<Coordinate> geometry, string meshCode)
        {
            bool isInCoordRect = false;

            int listCount = geometry.Count;

            CoordinateD roadStart = new CoordinateD(geometry[0].Longitude, geometry[0].Latitude);

            CoordinateD roadEnd = new CoordinateD(geometry[listCount - 1].Longitude, geometry[listCount - 1].Latitude);

            // 基幹道路が指定2次メッシュに属するか判断
            isInCoordRect = GISLib.CheckRoadInCoordRect(meshCode, roadStart, roadEnd);

            return isInCoordRect;
        }

        /// <summary>
        /// 2次メッシュ境界の幅と高が未満かどうかを判定する
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>2次メッシュ境界の幅と高が未満かどうか</returns>
        private static bool IsMeshUnitBothLess(Coordinate startPoint, Coordinate endPoint, CoordinateRect rect)
        {
            return System.Math.Abs(endPoint.Longitude - startPoint.Longitude) < System.Math.Abs(rect.BottomLeft.Longitude - rect.TopRight.Longitude) &&
                System.Math.Abs(endPoint.Latitude - startPoint.Latitude) < System.Math.Abs(rect.BottomLeft.Latitude - rect.TopRight.Latitude);
        }

        /// <summary>
        /// 2次メッシュ境界の幅と高が未満かどうかを判定する
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>2次メッシュ境界の幅と高が未満かどうか</returns>
        private static bool IsMeshUnitExtendBothLess(Coordinate startPoint, Coordinate endPoint, CoordinateRect rect)
        {
            return System.Math.Abs(endPoint.Longitude - startPoint.Longitude) < (EXTEND_MESH_COUNT + 1) * System.Math.Abs(rect.BottomLeft.Longitude - rect.TopRight.Longitude) &&
                System.Math.Abs(endPoint.Latitude - startPoint.Latitude) < (EXTEND_MESH_COUNT + 1) * System.Math.Abs(rect.BottomLeft.Latitude - rect.TopRight.Latitude);
        }

        /// <summary>
        /// ポイントが矩形の境界内にあるか
        /// </summary>
        /// <param name="startPoint">ポイント</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>境界内にあるか</returns>
        private static bool CheckPointsAssignToRect(Coordinate startPoint, CoordinateRect rect)
        {
            return startPoint.Latitude <= rect.TopRight.Latitude &&
                startPoint.Latitude >= rect.BottomLeft.Latitude &&
                startPoint.Longitude <= rect.TopRight.Longitude &&
                startPoint.Longitude >= rect.BottomLeft.Longitude;
        }

        /// <summary>
        /// ポイントが矩形の境界経線(または延長線)上にあるか
        /// </summary>
        /// <param name="point">対象点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>境界線上にあるか</returns>
        private static bool CheckOnLongitudeBorder(Coordinate point, CoordinateRect rect)
        {
            long bottomLeft = rect.BottomLeft.Longitude;
            long topRight = rect.TopRight.Longitude;
            long diff = rect.TopRight.Longitude - rect.BottomLeft.Longitude;

            int loopCount = 0;
            do
            {
                if (point.Longitude == bottomLeft)
                {
                    return true;
                }

                bottomLeft -= diff;
                loopCount++;
            }
            while (point.Longitude <= bottomLeft && loopCount <= EXTEND_MESH_COUNT);

            loopCount = 0;
            do
            {
                if (point.Longitude == topRight)
                {
                    return true;
                }

                topRight += diff;
                loopCount++;
            }
            while (point.Longitude >= topRight && loopCount <= EXTEND_MESH_COUNT);

            return false;
        }

        /// <summary>
        /// ポイントが矩形の境界緯線(または延長線)上にあるか
        /// </summary>
        /// <param name="point">対象点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>境界線上にあるか</returns>
        private static bool CheckOnLatitudeBorder(Coordinate point, CoordinateRect rect)
        {
            long bottomLeft = rect.BottomLeft.Latitude;
            long topRight = rect.TopRight.Latitude;
            long diff = rect.TopRight.Latitude - rect.BottomLeft.Latitude;

            int loopCount = 0;
            do
            {
                if (point.Latitude == bottomLeft)
                {
                    return true;
                }

                bottomLeft -= diff;
                loopCount++;
            }
            while (point.Latitude <= bottomLeft && loopCount <= EXTEND_MESH_COUNT);

            loopCount = 0;
            do
            {
                if (point.Latitude == topRight)
                {
                    return true;
                }

                topRight += diff;
                loopCount++;
            }
            while (point.Latitude >= topRight && loopCount <= EXTEND_MESH_COUNT);

            return false;
        }

        /// <summary>
        /// ポイントが矩形の境界経線、緯線(または延長線)上にあるか
        /// </summary>
        /// <param name="point">対象点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>境界線上にあるか</returns>
        private static bool CheckOnRectBorder(Coordinate point, CoordinateRect rect)
        {
            return CheckOnLongitudeBorder(point, rect) || CheckOnLatitudeBorder(point, rect);
        }

        /// <summary>
        /// 同一経線または緯線に接続するか
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <param name="meshRect">対象矩形</param>
        /// <returns>同一線に接続するか</returns>
        private static bool CheckOnSameBorder(Coordinate startPoint, Coordinate endPoint, CoordinateRect meshRect)
        {
            return ((startPoint.Longitude == endPoint.Longitude) && CheckOnLongitudeBorder(startPoint, meshRect)) ||
                ((startPoint.Latitude == endPoint.Latitude) && CheckOnLatitudeBorder(startPoint, meshRect));
        }

        /// <summary>
        /// 2次メッシュ境界の幅となるかを判定する
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>2次メッシュ境界の幅となるか</returns>
        private static bool IsMeshUnitLongitudeEquals(Coordinate startPoint, Coordinate endPoint, CoordinateRect rect)
        {
            return System.Math.Abs(endPoint.Longitude - startPoint.Longitude) == System.Math.Abs(rect.BottomLeft.Longitude - rect.TopRight.Longitude);
        }

        /// <summary>
        /// 2次メッシュ境界の高となるかを判定する
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>2次メッシュ境界の高となるか</returns>
        private static bool IsMeshUnitLatitudeEquals(Coordinate startPoint, Coordinate endPoint, CoordinateRect rect)
        {
            return System.Math.Abs(endPoint.Latitude - startPoint.Latitude) == System.Math.Abs(rect.BottomLeft.Latitude - rect.TopRight.Latitude);
        }

        /// <summary>
        /// ポイントが矩形の幅の範囲内にあるか
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>幅の範囲内にあるか</returns>
        private static bool CheckBothInLongitudeRange(Coordinate startPoint, Coordinate endPoint, CoordinateRect rect)
        {
            return startPoint.Longitude <= rect.TopRight.Longitude &&
                startPoint.Longitude >= rect.BottomLeft.Longitude &&
                endPoint.Longitude <= rect.TopRight.Longitude &&
                endPoint.Longitude >= rect.BottomLeft.Longitude;
        }

        /// <summary>
        /// ポイントが矩形の高の範囲内にあるか
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>高の範囲内にあるか</returns>
        private static bool CheckBothInLatitudeRange(Coordinate startPoint, Coordinate endPoint, CoordinateRect rect)
        {
            return startPoint.Latitude <= rect.TopRight.Latitude &&
                startPoint.Latitude >= rect.BottomLeft.Latitude &&
                endPoint.Latitude <= rect.TopRight.Latitude &&
                endPoint.Latitude >= rect.BottomLeft.Latitude;
        }

        /// <summary>
        /// ポイントが矩形の境界経線上にあるか
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>境界線上にあるか</returns>
        private static bool CheckAnyLongitudeBorder(Coordinate startPoint, Coordinate endPoint, CoordinateRect rect)
        {
            return CheckOnLongitudeBorder(startPoint, rect) || CheckOnLongitudeBorder(endPoint, rect);
        }

        /// <summary>
        /// ポイントが矩形の境界緯線上にあるか
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <param name="rect">対象矩形</param>
        /// <returns>境界線上にあるか</returns>
        private static bool CheckAnyLatitudeBorder(Coordinate startPoint, Coordinate endPoint, CoordinateRect rect)
        {
            return CheckOnLatitudeBorder(startPoint, rect) || CheckOnLatitudeBorder(endPoint, rect);
        }

        /// <summary>
        /// 基幹道路が指定2次メッシュに属するか判断
        /// </summary>
        /// <param name="dataOid">基幹道路OID</param>
        /// <param name="geometry">基幹道路座標</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>判定結果</returns>
        private static bool CheckRoadInCoordRectExtend(ulong dataOid, DMCollection<Coordinate> geometry, string meshCode)
        {
            // メッシュ矩形
            ushort meshType = 8102;
            CoordinateRect meshRect;
            bool bFoundMesh = GISLib.GetCoordRectByMeshCode(meshType, meshCode, out meshRect);
            if (!bFoundMesh)
            {
                string message = string.Format("メッシュ矩形が取得できません。メッシュタイプ:{0} メッシュコード:{1}",
                    8102,
                    meshCode);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            return CheckRoadInCoordRectExtend(dataOid, geometry, meshRect);
        }

        /// <summary>
        /// 基幹道路が指定2次メッシュに属するか判断
        /// </summary>
        /// <param name="sRoadMain">基幹道路</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>判定結果</returns>
        public static bool CheckRoadInMesh(SRoadMain sRoadMain, string meshCode)
        {
            return CheckRoadInCoordRectExtend(sRoadMain.OID, sRoadMain.Geometry, meshCode);
        }

        /// <summary>
        /// 道路の内外判定基準点を取得する
        /// </summary>
        /// <param name="startPoint">始点</param>
        /// <param name="endPoint">終点</param>
        /// <returns>判定基準点</returns>
        public static Coordinate GetRoadBasePoint(Coordinate startPoint, Coordinate endPoint)
        {
            // 分割領域の内外判定基準点を決定
            Coordinate baseCoord = null;

            // GISLib.CheckRoadInCoordRectと同じように実装
            if (startPoint.Latitude == endPoint.Latitude)
            {
                // X座標の小さい位置（左）を内外判定基準点とする
                if (startPoint.Longitude < endPoint.Longitude)
                {
                    baseCoord = startPoint;
                }
                else
                {
                    baseCoord = endPoint;
                }
            }
            else
            {
                // Y座標が小さい位置を優先し（下優先）
                if (startPoint.Latitude < endPoint.Latitude)
                {
                    baseCoord = startPoint;
                }
                else
                {
                    baseCoord = endPoint;
                }
            }

            return baseCoord;
        }

        /// <summary>
        /// 基幹道路が指定2次メッシュに属するか判断
        /// </summary>
        /// <param name="dataOid">基幹道路OID</param>
        /// <param name="geometry">基幹道路座標</param>
        /// <param name="meshRect">2次メッシュ</param>
        /// <returns>判定結果</returns>
        private static bool CheckRoadInCoordRectExtend(ulong dataOid,
            DMCollection<Coordinate> geometry,
            CoordinateRect meshRect)
        {
            // 始点
            Coordinate startPoint = geometry[0];

            // 終点
            Coordinate endPoint = geometry[geometry.Count - 1];

            // 分割領域の内外判定基準点を決定
            Coordinate baseCoord = null;

            // 始点と終点が矩形の境界内にあるか
            bool bStartPointAssignToRect = CheckPointsAssignToRect(startPoint, meshRect);
            bool bEndPointAssignToRect = CheckPointsAssignToRect(endPoint, meshRect);
            if (!bStartPointAssignToRect && !bEndPointAssignToRect)
            {
                // 両方がメッシュ外の場合、対象外
                return false;
            }

            // 同一境界線境界線（または延長線）に接続するか
            bool bOnSameBorderLine = CheckOnSameBorder(startPoint, endPoint, meshRect);

            if (!bOnSameBorderLine)
            {
                if (bStartPointAssignToRect && bEndPointAssignToRect)
                {
                    // 始点と終点が矩形の境界内にある、かつ同一境界線に接続しない場合、当該メッシュに属する
                    return true;
                }

                // 始点が2次メッシュ境界線（または延長線）に接続するか
                bool bStartPointOnRectBorder = CheckOnRectBorder(startPoint, meshRect);

                // 終点が2次メッシュ境界線（または延長線）に接続するか
                bool bEndPointOnRectBorder = CheckOnRectBorder(endPoint, meshRect);
                if (bStartPointOnRectBorder && bEndPointOnRectBorder)
                {
                    // 経緯度差は2次メッシュ境界の幅と高が未満かどうか
                    if (IsMeshUnitBothLess(startPoint, endPoint, meshRect))
                    {
                        // 始点と終点が2次メッシュ境界線（または延長線）に接続する場合
                        // 他のメッシュに属することを判明するので、対象外(単一メッシュに属するため)
                        return false;
                    }

                    if (IsMeshUnitLongitudeEquals(startPoint, endPoint, meshRect) &&
                        CheckBothInLatitudeRange(startPoint, endPoint, meshRect) &&
                        CheckAnyLongitudeBorder(startPoint, endPoint, meshRect))
                    {
                        // 他のメッシュに属することを判明するので、対象外(単一メッシュに属するため)
                        return false;
                    }

                    if (IsMeshUnitLatitudeEquals(startPoint, endPoint, meshRect) &&
                        CheckBothInLongitudeRange(startPoint, endPoint, meshRect) &&
                        CheckAnyLatitudeBorder(startPoint, endPoint, meshRect))
                    {
                        // 他のメッシュに属することを判明するので、対象外(単一メッシュに属するため)
                        return false;
                    }
                }
                else if (IsMeshUnitExtendBothLess(startPoint, endPoint, meshRect))
                {
                    if (bStartPointOnRectBorder)
                    {
                        // 道路の一端が2次メッシュ境界線（または延長線）に接続する場合、反対側の端点を使用して、指定2次メッシュに属するかを判断する
                        // 境界線に接続しないはず
                        baseCoord = endPoint;
                    }
                    else if (bEndPointOnRectBorder)
                    {
                        // 道路の一端が2次メッシュ境界線（または延長線）に接続する場合、反対側の端点を使用して、指定2次メッシュに属するかを判断する 
                        // 境界線に接続しないはず
                        baseCoord = startPoint;
                    }
                }
            }

            if (baseCoord == null)
            {
                // GISLib.CheckRoadInCoordRectと同じように実装、下左点
                baseCoord = GetRoadBasePoint(startPoint, endPoint);
            }

            // 内外判定基準点の分割領域内外判定を行う
            return IsCoordinateBelongToMesh(meshRect, baseCoord);
        }

        /// <summary>
        /// 基幹道路が指定2次メッシュに属するか判断
        /// </summary>
        /// <param name="sRoadMain">基幹道路</param>
        /// <param name="meshRect">2次メッシュ</param>
        /// <returns>判定結果</returns>
        public static bool CheckRoadInMeshRect(SRoadMain sRoadMain, CoordinateRect meshRect)
        {
            return CheckRoadInCoordRectExtend(sRoadMain.OID, sRoadMain.Geometry, meshRect);
        }

        /// <summary>
        /// 基幹道路の両端が同一境界線に接続するか判断
        /// </summary>
        /// <param name="sRoadMain">基幹道路</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>判定結果</returns>
        public static bool CheckRoadInSameMeshLine(SRoadMain sRoadMain, string meshCode)
        {
            ushort meshType = 8102;

            // 始点
            Coordinate startPoint = sRoadMain.Geometry[0];

            // 終点
            Coordinate endPoint = sRoadMain.Geometry[sRoadMain.Geometry.Count - 1];

            // メッシュ矩形
            CoordinateRect meshRect;
            bool bFoundMesh = GISLib.GetCoordRectByMeshCode(meshType, meshCode, out meshRect);
            if (!bFoundMesh)
            {
                string message = string.Format("メッシュ矩形が取得できません。メッシュタイプ:{0} メッシュコード:{1}",
                    8102,
                    meshCode);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            if (startPoint.Latitude <= meshRect.TopRight.Latitude &&
                startPoint.Latitude >= meshRect.BottomLeft.Latitude &&
                startPoint.Longitude <= meshRect.TopRight.Longitude &&
                startPoint.Longitude >= meshRect.BottomLeft.Longitude &&
                endPoint.Latitude <= meshRect.TopRight.Latitude &&
                endPoint.Latitude >= meshRect.BottomLeft.Latitude &&
                endPoint.Longitude <= meshRect.TopRight.Longitude &&
                endPoint.Longitude >= meshRect.BottomLeft.Longitude)
            {
                if ((startPoint.Latitude == meshRect.TopRight.Latitude && startPoint.Latitude == endPoint.Latitude) ||
                    (startPoint.Latitude == meshRect.BottomLeft.Latitude && startPoint.Latitude == endPoint.Latitude) ||
                    (startPoint.Longitude == meshRect.TopRight.Longitude && startPoint.Longitude == endPoint.Longitude) ||
                    (startPoint.Longitude == meshRect.BottomLeft.Longitude && startPoint.Longitude == endPoint.Longitude))
                {
                    if (LogUtility.IsDebugEnabled)
                    {
                        LogUtility.WriteDebug("※道路{0}の両端が同一境界線に接続する。",
                            CommToDoDataWrapper.ConvertToOIDString(sRoadMain.OID));
                    }

                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// 座標が対象メッシュに所属するかを判断する
        /// </summary>
        /// <param name="meshRect">対象メッシュ</param>
        /// <param name="coordinate">座標</param>
        /// <returns>メッシュに所属するか</returns>
        public static bool IsCoordinateBelongToMesh(CoordinateRect meshRect, Coordinate coordinate)
        {
            // 内外判定基準点の分割領域内外判定を行う
            return
                (coordinate.Latitude < meshRect.TopRight.Latitude) &&
                (coordinate.Latitude >= meshRect.BottomLeft.Latitude) &&
                (coordinate.Longitude < meshRect.TopRight.Longitude) &&
                (coordinate.Longitude >= meshRect.BottomLeft.Longitude);
        }

        /// <summary>
        /// メッシュRectに、対象Rectによって表された四角形領域全体が含まれているかどうかを判断します
        /// </summary>
        /// <param name="meshRect">メッシュRect</param>
        /// <param name="otherRect">対象Rect</param>
        /// <returns>全体が含まれているかどうか</returns>
        public static bool IsRectContainsRect(CoordinateRect meshRect, CoordinateRect otherRect)
        {
            return
                (otherRect.TopRight.Latitude <= meshRect.TopRight.Latitude) &&
                (otherRect.BottomLeft.Latitude >= meshRect.BottomLeft.Latitude) &&
                (otherRect.TopRight.Longitude <= meshRect.TopRight.Longitude) &&
                (otherRect.BottomLeft.Longitude >= meshRect.BottomLeft.Longitude);
        }
        
        /// <summary>
        /// メッシュRectに、対象四角形領域全体が含まれているかどうかを判断します
        /// </summary>
        /// <param name="meshRect">メッシュRect</param>
        /// <param name="minLongitude">左下の座標(経度)</param>
        /// <param name="minLatitude">左下の座標(緯度)</param>
        /// <param name="maxLongitude">右上の座標(経度)</param>
        /// <param name="maxLatitude">右上の座標(緯度)</param>
        /// <returns>全体が含まれているかどうか</returns>
        public static bool IsRectContainsRect(CoordinateRect meshRect,
            long minLongitude,
            long minLatitude,
            long maxLongitude,
            long maxLatitude)
        {
            return
                (maxLatitude <= meshRect.TopRight.Latitude) &&
                (minLatitude >= meshRect.BottomLeft.Latitude) &&
                (maxLongitude <= meshRect.TopRight.Longitude) &&
                (minLongitude >= meshRect.BottomLeft.Longitude);
        }
        #endregion

        /// <summary>
        /// RECTから、文字列の表現に変更する
        /// </summary>
        /// <param name="rect">CoordinateRect</param>
        /// <returns>PolygonGeometryString</returns>
        public static string ParseCoordinateRectToPolygonGeometryString(CoordinateRect rect)
        {
            List<Coordinate> coorList = new List<Coordinate>();
            coorList.Add(rect.BottomLeft);
            coorList.Add(new Coordinate(rect.BottomLeft.Longitude, rect.TopRight.Latitude));
            coorList.Add(rect.TopRight);
            coorList.Add(new Coordinate(rect.TopRight.Longitude, rect.BottomLeft.Latitude));
            coorList.Add(rect.BottomLeft);

            return CoordinateLib.ParseCoordinateToPolygonGeometryString(coorList);
        }

        /// <summary>
        /// SqlGeometryに外接する四角形から、Coordinateのリストを取得する
        /// </summary>
        /// <param name="sqlGeometry">SqlGeometry型データ</param>
        /// <returns>Coordinateのリスト</returns>
        public static List<Coordinate> ConvertEnvelopeToPolygonList(SqlGeometry sqlGeometry)
        {
            SqlGeometry envelopeRect = sqlGeometry.STEnvelope();

            // 四捨五入
            long left = (long)Math.Round(envelopeRect.STPointN(1).STX.Value, 0, MidpointRounding.AwayFromZero);
            long lower = (long)Math.Round(envelopeRect.STPointN(1).STY.Value, 0, MidpointRounding.AwayFromZero);
            long right = (long)Math.Round(envelopeRect.STPointN(3).STX.Value, 0, MidpointRounding.AwayFromZero);
            long top = (long)Math.Round(envelopeRect.STPointN(3).STY.Value, 0, MidpointRounding.AwayFromZero);

            if (left == right)
            {
                // 切り捨て
                left = (long)Math.Floor(envelopeRect.STPointN(1).STX.Value);

                if (left == right)
                {
                    // 切り上げ
                    right = (long)Math.Ceiling(envelopeRect.STPointN(3).STX.Value);
                }
            }

            if (lower == top)
            {
                // 切り捨て
                lower = (long)Math.Floor(envelopeRect.STPointN(1).STY.Value);

                if (lower == top)
                {
                    // 切り上げ
                    top = (long)Math.Ceiling(envelopeRect.STPointN(3).STY.Value);
                }
            }

            List<Coordinate> coorList = new List<Coordinate>();
            coorList.Add(new Coordinate(left, lower));
            coorList.Add(new Coordinate(left, top));
            coorList.Add(new Coordinate(right, top));
            coorList.Add(new Coordinate(right, lower));
            coorList.Add(new Coordinate(left, lower));
            return coorList;
        }

        #region 19座標系用
        /// <summary>
        /// 円形が直線と実交点の算出(座標系・単位:10cm)
        /// </summary>
        /// <param name="centerPoint">円形の中心点(平面直角座標 (19座標系))</param>
        /// <param name="radius">半径(単位:10cm)</param>
        /// <param name="lineStartPoint">直線始点１(平面直角座標 (19座標系))</param>
        /// <param name="lineEndPoint">直線始点２(平面直角座標 (19座標系))</param>
        /// <returns>円形が直線との実交点(平面直角座標 (19座標系))</returns>
        public static Point? GetCrossPoint(Point centerPoint, int radius, Point lineStartPoint, Point lineEndPoint)
        {
            double retX = 0d;
            double retY = 0d;

            double x0 = centerPoint.X;
            double y0 = centerPoint.Y;

            double x1 = lineStartPoint.X;
            double y1 = lineStartPoint.Y;

            double x2 = lineEndPoint.X;
            double y2 = lineEndPoint.Y;

            Point? retPoint = null;

            double r = radius;
            if (Math.Abs(x2 - x1) > Math.Abs(y2 - y1))
            {
                CalculateCrossPointMain(ref retX, ref retY, x0, y0, x1, y1, x2, y2, ref retPoint, r);
            }
            else
            {
                // XとYを交換して、計算する。
                CalculateCrossPointMain(ref retY, ref retX, y0, x0, y1, x1, y2, x2, ref retPoint, r);
                if (retPoint != null)
                {
                    retPoint = new Point()
                    {
                        X = (long)(retX + 0.5),
                        Y = (long)(retY + 0.5),
                    };
                }
            }

            return retPoint;
        }

        /// <summary>
        ///  円形が直線と実交点の算出
        /// </summary>
        /// <param name="retX">retX</param>
        /// <param name="retY">retY</param>
        /// <param name="x0">x0</param>
        /// <param name="y0">y0</param>
        /// <param name="x1">x1</param>
        /// <param name="y1">y1</param>
        /// <param name="x2">x2</param>
        /// <param name="y2">y2</param>
        /// <param name="retPoint">retPoint</param>
        /// <param name="r">r</param>
        private static void CalculateCrossPointMain(ref double retX, ref double retY, double x0, double y0, double x1, double y1, double x2, double y2, ref Point? retPoint, double r)
        {
            // 座標の交換
            if (x1 > x2)
            {
                double tempX, tempY;
                tempX = x1;
                tempY = y1;

                x1 = x2;
                y1 = y2;

                x2 = tempX;
                y2 = tempY;
            }

            // 1. 直線のX1とX2が同じかどうかの判断
            if (x1 == x2)
            {
                // 2. 直線のX1とX2が同じ場合

                // X1は交点のXの値として、Yの値を算出する。
                retX = x1;

                // Yの値は円形の方程式によって、算出する。
                // Y=√(R² - (X1 – X0)²)
                retY = Math.Sqrt(Math.Pow(r, 2) - Math.Pow((x1 - x0), 2));
                if (retY < y1 || retY > y2)
                {
                    retY = -retY;
                }

                // ステップ6にジャンプする。
                // 6. 算出した（X,Y）がintに変換にて、交点座標として、返却する。
                retPoint = new Point()
                {
                    X = (long)(retX + 0.5),
                    Y = (long)(retY + 0.5),
                };
            }
            else
            {
                // 3. 直線のX1とX2が違う場合、直線の方程式係数の算出

                // 入力した直線の２つ点の座標によって、係数a と b　を算出する。
                // a =(double) (Y1 – Y2)/(X1 – X2)
                // b = (double) ( X1 * Y2 – X2 * Y1)/(X1 – X2)
                double a = (y1 - y2) / (x1 - x2);
                double b = ((x1 * y2) - (x2 * y1)) / (x1 - x2);

                // 4. 円形の方程式が直線の方程式との２元方程式の係数の算出

                // X² + k* X + m =0
                // k =  (double) (2 * (b – Y0) * a – 2 * X0)/ （a² + 1）
                // m =  (double) (X0² + (b – Y0)² - R²)/（a² + 1）
                double k = ((2 * (b - y0) * a) - (2 * x0)) / (Math.Pow(a, 2) + 1);
                double m = (Math.Pow(x0, 2) + Math.Pow((b - y0), 2) - Math.Pow(r, 2)) / (Math.Pow(a, 2) + 1);

                // (k/2)²-m < 0　場合、交点ないとなるので、
                // nullが返却値として、この処理を終了する。
                if (Math.Pow((k / 2), 2) - m < 0)
                {
                    retPoint = null;
                }
                else
                {
                    double retX1 = 0;
                    double retY1 = 0;

                    // 5. 円形の方程式が直線の方程式の交点座標の算出

                    // X = √((k/2)²-m) – (k/2)
                    // X = - √((k/2)²-m) – (k/2)
                    retX = Math.Sqrt(Math.Pow(k / 2, 2) - m) - (k / 2);

                    // 直線の方程式が下記の通り、一元方程式である。
                    // Y = a* X + b
                    // ② 交点座標の「X」の値が直線方程式に設定して、
                    // 交点座標の「Y」の値を算出する。
                    retY = (a * retX) + b;

                    // 入力したX1 と　X2の間にあるX値を結果とする。
                    if (retX < x1 || retX > x2)
                    {
                        retX1 = -Math.Sqrt(Math.Pow(k / 2, 2) - m) - (k / 2);
                        retY1 = (a * retX1) + b;

                        // 接近円の点判断
                        if (Math.Abs(retX - x1) > Math.Abs(retX1 - x1))
                        {
                            retX = retX1;
                            retY = retY1;
                            LogUtility.WriteTrace("【★★★円形が直線と実交点の算出：二点が円の外に存在する「接近円の点」】");
                        }
                    }

                    // 6. 算出した（X,Y）がintに変換にて、交点座標として、返却する。
                    retPoint = new Point()
                    {
                        X = (long)(retX + 0.5),
                        Y = (long)(retY + 0.5),
                    };
                }
            }
        }
        #endregion
    }
}

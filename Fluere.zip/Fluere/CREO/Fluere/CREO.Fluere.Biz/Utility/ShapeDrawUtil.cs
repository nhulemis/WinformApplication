﻿using System;
using System.Windows;
using CREO.FW.TMIGeometry;
using CREO.FW.Utilities;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 共通用のユーティリティクラス
    /// </summary>
    public class ShapeDrawUtil
    {
        #region 円近似の正多角形ポリゴンの取得

        /// <summary>
        /// 円近似の正多角形ポリゴンの取得
        /// </summary>
        /// <param name="coordinate">中心点座標(正多角形ポリゴンの中心点座標)</param>
        /// <param name="radius">半径R(円の半径(単位：m))</param>
        /// <param name="splitCount">正多角形の辺数(円近似の正多角形の辺数(頂点数)※SplitCount>=3)</param>
        /// <returns>座標のコレクション</returns>
        public static DMCollection<Coordinate> GetPlygonCoordinate(Coordinate coordinate, long radius, int splitCount)
        {
            // 出力経緯度座標のコレクション
            DMCollection<Coordinate> plygonCoordinates = new DMCollection<Coordinate>();

            // 原点の経緯度座標（対象交差点の座標、1/1024秒単位→1/128秒単位に変換）
            CoordinateD pointO = new CoordinateD();
            pointO.Longitude = coordinate.Longitude / 8.0;
            pointO.Latitude = coordinate.Latitude / 8.0;

            // 単位コンバート（1m単位⇒10cm単位）
            double radiusValue = radius / 0.10;

            // 円近似の正多角形の角度
            double angle = Math.PI * 2 / splitCount;

            for (int splitIndex = 0; splitIndex < splitCount; splitIndex++)
            {
                // 出力経緯度座標「長整数型」
                Coordinate outCoordinate = new Coordinate();

                // 平面直角座標
                Point inPoint = new Point();

                double sinValue = Math.Sin(angle * splitIndex);
                double cosValue = Math.Cos(angle * splitIndex);

                inPoint.Y = sinValue * radiusValue;
                inPoint.X = cosValue * radiusValue;

                // 出力経緯度座標「倍精度実数型」
                CoordinateD outCoord;

                // 平面直角座標から経緯度座標を求める。
                GISLib.ConvertCartesianToLL("4301", inPoint, pointO, out outCoord);

                // 経緯度座標変換（CoordinateD「倍精度実数型」→Coordinate「長整数型」、1/128秒単位→1/1024秒単位に変換）
                outCoordinate.Latitude = (long)(outCoord.Latitude * 8.0);
                outCoordinate.Longitude = (long)(outCoord.Longitude * 8.0);

                if (LogUtility.IsTraceEnabled)
                {
                    double distance;
                    GISLibExtend.GetDistance(coordinate, outCoordinate, out distance);

                    LogUtility.WriteDebug("【円近似の正多角形】({0}：{1}): {2} {3},",
                        splitIndex,
                        distance,
                        outCoordinate.Longitude,
                        outCoordinate.Latitude);
                }

                // 経緯度座標を追加する。
                plygonCoordinates.Add(outCoordinate);
            }

            return plygonCoordinates;
        }

        #endregion
    }
}

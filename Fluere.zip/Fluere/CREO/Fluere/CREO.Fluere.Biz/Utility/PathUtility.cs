﻿using CREO.FW.Utilities;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// パス取得用ユーティリティ
    /// </summary>
    public class PathUtility
    {
        #region 絶対パスの取得

        /// <summary>
        /// 絶対パスの取得
        /// </summary>
        /// <param name="path">相対パス</param>
        /// <param name="isDirectory">Directory判定フラグ</param>
        /// <returns>絶対パス</returns>
        public static string GetFullPath(string path, bool isDirectory)
        {
            LogUtility.WriteDebug("【絶対パスの取得】入力パス:" + path);

            string strFullPath = ProfileUtility.GetFullPath(path, isDirectory);

            LogUtility.WriteDebug("【絶対パスの取得】出力パス:" + strFullPath);

            return strFullPath;
        }

        #endregion
    }
}

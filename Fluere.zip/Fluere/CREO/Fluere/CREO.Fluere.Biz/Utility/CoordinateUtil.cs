﻿namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 座標関連クラス
    /// </summary>
    public static class CoordinateUtil
    {
        #region decimal
        /// <summary>
        /// 座標変換（1024→128）
        /// </summary>
        /// <param name="value">変換前座標</param>
        /// <returns>変換後座標</returns>
        public static decimal Convert1024To128(decimal value)
        {
            return value / 8m;
        }

        /// <summary>
        /// 座標変換（128→1024）
        /// </summary>
        /// <param name="value">変換前座標</param>
        /// <returns>変換後座標</returns>
        public static decimal Convert128To1024(decimal value)
        {
            return value * 8m;
        }

        /// <summary>
        /// 座標変換（秒→度）
        /// </summary>
        /// <param name="value">変換前座標</param>
        /// <returns>変換後座標</returns>
        public static decimal ConvertSecToDeg(decimal value)
        {
            return value / 3600m;
        }

        /// <summary>
        /// 座標変換（度分秒→秒）
        /// </summary>
        /// <param name="deg">度</param>
        /// <param name="min">分</param>
        /// <param name="sec">秒</param>
        /// <returns>変換後の秒</returns>
        public static decimal ConvertDmsToSec(decimal deg, decimal min, decimal sec)
        {
            return (deg * 3600m) + (min * 60m) + sec;
        }
        #endregion

        #region double
        /// <summary>
        /// 座標変換（1024→128）
        /// </summary>
        /// <param name="value">変換前座標</param>
        /// <returns>変換後座標</returns>
        public static double Convert1024To128(double value)
        {
            return value / 8d;
        }

        /// <summary>
        /// 座標変換（128→1024）
        /// </summary>
        /// <param name="value">変換前座標</param>
        /// <returns>変換後座標</returns>
        public static double Convert128To1024(double value)
        {
            return value * 8d;
        }

        /// <summary>
        /// 座標変換（秒→度）
        /// </summary>
        /// <param name="value">変換前座標</param>
        /// <returns>変換後座標</returns>
        public static double ConvertSecToDeg(double value)
        {
            return value / 3600d;
        }

        /// <summary>
        /// 座標変換（度分秒→秒）
        /// </summary>
        /// <param name="deg">度</param>
        /// <param name="min">分</param>
        /// <param name="sec">秒</param>
        /// <returns>変換後の秒</returns>
        public static double ConvertDmsToSec(double deg, double min, double sec)
        {
            return (deg * 3600d) + (min * 60d) + sec;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Data;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Query;
using CREO.FW.ExceptionHandling;
using CREO.FW.TMIGeometry;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// データの格納クラス
    /// </summary>
    public class VicsDrm05CacheManager
    {
        #region インスタンス
        /// <summary>
        /// Singletonインスタンス
        /// </summary>
        private static VicsDrm05CacheManager _instance = null;
        #endregion

        #region 05向けVICSリンクファイルキャッシュ(key/value ：meshCode/ List<VICSLinkFileData>)
        /// <summary>
        /// 05向けVICSリンクファイルキャッシュ
        /// ※key/value ：2次メッシュ/ データ
        /// </summary>
        private Dictionary<int, List<VICSLinkFileData>> _vicsLinkData05Dict =
            new Dictionary<int, List<VICSLinkFileData>>();
        #endregion

        #region 05向けDRM基本道路キャッシュ(key/value ：meshCode/ List<GeoItem>)
        /// <summary>
        /// 05向けDRM基本道路キャッシュ
        /// ※key/value ：2次メッシュ/ データ
        /// </summary>
        private Dictionary<int, Dictionary<string, List<SDRMRoadBasic>>> _drmRoadBasic05Dict =
            new Dictionary<int, Dictionary<string, List<SDRMRoadBasic>>>();
        #endregion

        #region 05向けDRM全道路キャッシュ(key/value ：meshCode/ List<GeoItem>)
        /// <summary>
        /// 05向けDRM全道路キャッシュ
        /// ※key/value ：2次メッシュ/ データ（キーが全道路ノード）
        /// </summary>
        private Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> _drmRoadAll05DictByAllNode =
            new Dictionary<int, Dictionary<string, List<SDRMRoadAll>>>();
        #endregion

        #region 05向けDRM全道路キャッシュ(key/value ：meshCode/ List<GeoItem>)
        /// <summary>
        /// 05向けDRM全道路キャッシュ
        /// ※key/value ：2次メッシュ/ データ（キーが基本道路ノード）
        /// </summary>
        private Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> _drmRoadAll05DictByBasicNode =
            new Dictionary<int, Dictionary<string, List<SDRMRoadAll>>>();
        #endregion

        // Modify By Ning.Cai 2014/03/03 エンハンス開発No.1071 Start
        #region Delete
        ////#region 同一経路のOIDキャッシュ(key/value ：OID/ int)
        /////// <summary>
        /////// 同一経路のOID
        /////// </summary>
        ////public Dictionary<ulong, int> traceableRoadOIDDict = new Dictionary<ulong, int>();
        ////#endregion
        #endregion
        #region 同一経路のOIDキャッシュ(key ：OIDt)
        /// <summary>
        /// 同一経路のOID
        /// </summary>
        private HashSet<ulong> _traceableRoadOIDDict = new HashSet<ulong>();
        #endregion
        // Modify By Ning.Cai 2014/03/03 エンハンス開発No.1071 End
        #region 前回読み出し時間
        /// <summary>
        /// 前回読み出し時間
        /// </summary>
        private List<VicsDrmCacheData> cacheDataList = new List<VicsDrmCacheData>();
        #endregion

        #region コンストラクタ
        /// <summary>
        /// 外部よりインスタンスができないこと
        /// </summary>
        private VicsDrm05CacheManager()
        {
        }
        #endregion

        #region インスタンスの取得
        /// <summary>
        /// Singletonインスタンスの取得
        /// </summary>
        /// <returns>Singletonインスタンス</returns>
        public static VicsDrm05CacheManager GetInstance()
        {
            if (_instance == null)
            {
                _instance = new VicsDrm05CacheManager();
            }

            return _instance;
        }
        #endregion

        #region 05向けVICSリンクファイルデータの取得
        /// <summary>
        /// 05向けVICSリンクファイルデータの取得
        /// </summary>
        /// <param name="folderPath">パス</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <param name="extensionNum">拡張子番号指定</param>
        /// <returns>VICSリンクファイルデータリスト</returns>
        public List<VICSLinkFileData> Get05VICSLinkDataList(string folderPath, int meshCode, int extensionNum)
        {
            List<VICSLinkFileData> dataList = null;

            if (!this._vicsLinkData05Dict.TryGetValue(meshCode, out dataList))
            {
                double memory = GetObjectMemeryByMeshCode(folderPath, meshCode, extensionNum);

                VicsDrm05ReleaseManager.Release(memory);

                dataList = VicsDrm05FileUtility.LoadVICSLinkFileList(folderPath, meshCode, extensionNum);

                this._vicsLinkData05Dict.Add(meshCode, dataList);

                LogUtility.WriteDataCount(
                    string.Format("【05向けVICSリンクデータ】メッシュ：{0}", meshCode),
                    LogUtility.OperationType.File,
                    dataList == null ? 0 : dataList.Count);

                SetLastTime(meshCode, memory);
            }

            return dataList;
        }

        /// <summary>
        /// 05向けVICSリンクファイルキャッシュ
        /// </summary>
        /// <returns>Dictionary</returns>
        public Dictionary<int, List<VICSLinkFileData>> Get05VICSLinkDataDict()
        {
            return this._vicsLinkData05Dict;
        }
        #endregion

        #region 05向けDRM基本道路の取得
        /// <summary>
        /// 05向けDRM基本道路の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadBasicリスト</returns>
        public Dictionary<string, List<SDRMRoadBasic>> Get05SDRMRoadBasic(DataService ds, int meshCode)
        {
            Dictionary<string, List<SDRMRoadBasic>> retDataDict = null;

            if (!this._drmRoadBasic05Dict.TryGetValue(meshCode, out retDataDict))
            {
                List<SDRMRoadBasic> dataList = GetSDRMRoadBasicByMeshCode(ds, meshCode);
               
                if (dataList != null && dataList.Count != 0)
                {
                    retDataDict = SDRMRoadQuery.MadeSDRMRoadBasicDict(dataList);
                }
                else
                {
                    retDataDict = new Dictionary<string, List<SDRMRoadBasic>>();
                }

                this._drmRoadBasic05Dict.Add(meshCode, retDataDict);

                LogUtility.WriteDataCount(string.Format("【05向けDRM基本道路】メッシュ：{0}", meshCode),
                    LogUtility.OperationType.Select,
                    dataList.Count);
            }

            SetLastTime(meshCode);

            return retDataDict;
        }

        /// <summary>
        /// 05向けDRM基本道路キャッシュ
        /// </summary>
        /// <returns>Dictionary</returns>
        public Dictionary<int, Dictionary<string, List<SDRMRoadBasic>>> Get05SDRMRoadBasicDict()
        {
            return this._drmRoadBasic05Dict;
        }
        #endregion

        #region 05向けDRM全道路の取得（キーが基本道路ノード）
        /// <summary>
        /// 05向けDRM全道路の取得（キーが基本道路ノード）
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadAllリスト</returns>
        public Dictionary<string, List<SDRMRoadAll>> Get05SDRMRoadAllByAllNode(DataService ds, int meshCode)
        {
            // 全道路ディクショナリーのリスト（一つ目が全道路ノードキー、二つ目が基本道路ノードキー）
            List<Dictionary<string, List<SDRMRoadAll>>> listDictDRMRoadAll = 
                                            new List<Dictionary<string, List<SDRMRoadAll>>>();
            Dictionary<string, List<SDRMRoadAll>> retDataDict = null;

            if (!this._drmRoadAll05DictByAllNode.TryGetValue(meshCode, out retDataDict))
            {
                List<SDRMRoadAll> dataList = GetSDRMRoadAllByMeshCode(ds, meshCode);
                
                if (dataList != null && dataList.Count != 0)
                {
                    listDictDRMRoadAll = SDRMRoadQuery.MadeSDRMRoadAllDict(dataList);
                    if (listDictDRMRoadAll != null && listDictDRMRoadAll.Count > 0)
                    {
                        retDataDict = listDictDRMRoadAll[0];
                    }
                    else
                    {
                        retDataDict = new Dictionary<string, List<SDRMRoadAll>>();
                    }
                }
                else
                {
                    retDataDict = new Dictionary<string, List<SDRMRoadAll>>();
                }

                this._drmRoadAll05DictByAllNode.Add(meshCode, retDataDict);
                if (listDictDRMRoadAll != null && listDictDRMRoadAll.Count > 1)
                {
                    this._drmRoadAll05DictByBasicNode.Add(meshCode, listDictDRMRoadAll[1]);
                }

                LogUtility.WriteDataCount(string.Format("【05向けDRM全道路】メッシュ：{0}", meshCode),
                    LogUtility.OperationType.Select,
                    dataList.Count);
            }

            SetLastTime(meshCode);

            return retDataDict;
        }

        /// <summary>
        /// 05向けDRM全道路キャッシュ（キーが基本道路ノード）
        /// </summary>
        /// <returns>Dictionary</returns>
        public Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> Get05SDRMRoadAllDictByAllNode()
        {
            return this._drmRoadAll05DictByAllNode;
        }
        #endregion

        #region 05向けDRM全道路の取得（キーが全道路ノード）
        /// <summary>
        /// 05向けDRM全道路の取得（キーが全道路ノード）
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadAllリスト</returns>
        public Dictionary<string, List<SDRMRoadAll>> Get05SDRMRoadAllByBasicNode(DataService ds, int meshCode)
        {
            List<Dictionary<string, List<SDRMRoadAll>>> listDictDRMRoadAll =
                                            new List<Dictionary<string, List<SDRMRoadAll>>>();
            Dictionary<string, List<SDRMRoadAll>> retDataDict = null;

            if (!this._drmRoadAll05DictByBasicNode.TryGetValue(meshCode, out retDataDict))
            {
                List<SDRMRoadAll> dataList = GetSDRMRoadAllByMeshCode(ds, meshCode);

                if (dataList != null && dataList.Count != 0)
                {
                    listDictDRMRoadAll = SDRMRoadQuery.MadeSDRMRoadAllDict(dataList);
                    if (listDictDRMRoadAll != null && listDictDRMRoadAll.Count > 0)
                    {
                        retDataDict = listDictDRMRoadAll[1];
                    }
                    else
                    {
                        retDataDict = new Dictionary<string, List<SDRMRoadAll>>();
                    }
                }
                else
                {
                    retDataDict = new Dictionary<string, List<SDRMRoadAll>>();
                }

                this._drmRoadAll05DictByBasicNode.Add(meshCode, retDataDict);
                if (listDictDRMRoadAll != null && listDictDRMRoadAll.Count > 0)
                {
                    this._drmRoadAll05DictByAllNode.Add(meshCode, listDictDRMRoadAll[0]);
                }

                LogUtility.WriteDataCount(string.Format("【05向けDRM全道路】メッシュ：{0}", meshCode),
                    LogUtility.OperationType.Select,
                    dataList.Count);
            }

            SetLastTime(meshCode);

            return retDataDict;
        }

        /// <summary>
        /// 05向けDRM全道路キャッシュ（キーが基本道路ノード）
        /// </summary>
        /// <returns>Dictionary</returns>
        public Dictionary<int, Dictionary<string, List<SDRMRoadAll>>> Get05SDRMRoadAllDictByBasicNode()
        {
            return this._drmRoadAll05DictByBasicNode;
        }
        #endregion

        #region 同一経路のOID処理
        /// <summary>
        /// 同一経路のOIDの設定
        /// </summary>
        /// <param name="traceableRoadList">同一経路リスト</param>
        public void SetTraceableRoadOID(List<SRoadMain> traceableRoadList)
        {
            foreach (SRoadMain traceableRoad in traceableRoadList)
            {
                // Modify By Ning.Cai 2014/03/03 エンハンス開発No.1071 Start
                #region Delete
                ////if (!traceableRoadOIDDict.ContainsKey(traceableRoad.OID))
                ////{
                ////    traceableRoadOIDDict.Add(traceableRoad.OID, 1);
                ////}
                #endregion
                if (!_traceableRoadOIDDict.Contains(traceableRoad.OID))
                {
                    _traceableRoadOIDDict.Add(traceableRoad.OID);
                }

                // Modify By Ning.Cai 2014/03/03 エンハンス開発No.1071 End
            }
        }

        /// <summary>
        /// 同一経路のOID存在判断
        /// </summary>
        /// <param name="oid">OID</param>
        /// <returns>True:存在する False:存在しない</returns>
        public bool JudgeTraceableRoadOID(ulong oid)
        {
            // Modify By Ning.Cai 2014/03/03 エンハンス開発No.1071 Start
            // return traceableRoadOIDDict.ContainsKey(oid);
            return _traceableRoadOIDDict.Contains(oid);

            // Modify By Ning.Cai 2014/03/03 エンハンス開発No.1071 Start
        }
        #endregion

        #region 05向けDRM道路の取得(Query)
        /// <summary>
        /// 05向けDRM道路の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadBasicリスト</returns>
        private List<SDRMRoadBasic> GetSDRMRoadBasicByMeshCode(DataService ds, int meshCode)
        {
            // 検索条件の作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 2次メッシュを指定する
            qic.ConditionExpression = new SqlConditionExpression("TargetKey",
                QueryItemOperator.Equal,
                meshCode.ToString());

            // コンテンツタイプ = DRM基本道路（SDRMRoadBasic）
            qic.TypeIDs.Add(typeof(SDRMRoadBasic).Name);

            // DRM基本道路の取得
            List<GeoItem> resultTemp = ds.QueryItems(qic);

            List<SDRMRoadBasic> result = new List<SDRMRoadBasic>();

            if (resultTemp != null && resultTemp.Count > 0)
            {
                result = resultTemp.ConvertAll(d => d as SDRMRoadBasic);
            }

            return result;
        }

        /// <summary>
        /// 05向けDRM道路の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="meshCode">2次メッシュ</param>
        /// <returns>SDRMRoadAllリスト</returns>
        private List<SDRMRoadAll> GetSDRMRoadAllByMeshCode(DataService ds, int meshCode)
        {
            // 検索条件の作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 2次メッシュを指定する
            qic.ConditionExpression = new SqlConditionExpression("TargetKey",
                QueryItemOperator.Equal,
                meshCode.ToString());

            // コンテンツタイプ = DRM全道路（SDRMRoadAll）
            qic.TypeIDs.Add(typeof(SDRMRoadAll).Name);

            // DRM基本道路の取得
            List<GeoItem> resultTemp = ds.QueryItems(qic);

            List<SDRMRoadAll> result = new List<SDRMRoadAll>();

            if (resultTemp != null && resultTemp.Count > 0)
            {
                result = resultTemp.ConvertAll(d => d as SDRMRoadAll);
            }

            return result;
        }
        #endregion

        #region 前回読み出し時間処理
        /// <summary>
        /// 前回読み出し時間の取得
        /// </summary>
        /// <returns>前回読み出し時間</returns>
        public List<VicsDrmCacheData> GetLastTimeList()
        {
            return cacheDataList;
        }

        /// <summary>
        /// 前回読み出し時間の設定
        /// </summary>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <param name="size">サイズ</param>
        private void SetLastTime(int meshCode, double size = 0)
        {
            long time = DateTime.Now.ToFileTime();

            VicsDrmCacheData cacheData = null;

            bool isExists = cacheDataList.Exists(t => t.MeshCode == meshCode);

            if (isExists)
            {
                cacheData = cacheDataList.Find(t => t.MeshCode == meshCode);

                cacheData.LastTime = time;
            }
            else
            {
                cacheData = new VicsDrmCacheData();

                cacheData.MeshCode = meshCode;

                cacheData.LastTime = time;

                cacheData.Size = size;

                cacheDataList.Add(cacheData);
            }
        }
        #endregion

        #region メモリの取得
        /// <summary>
        /// メモリの取得
        /// </summary>
        /// <param name="folder">パス</param>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <param name="extensionNum">拡張子番号指定</param>
        /// <returns>メモリ</returns>
        public double GetObjectMemeryByMeshCode(string folder, int meshCode, int extensionNum)
        {
            double memery = 0;

            string vicsFilePath = VicsDrm05FileUtility.Get05VicsLinkFilePath(folder, meshCode, extensionNum);

            string drmFilePath = VicsDrm05FileUtility.Get05DrmFilePath(meshCode);

            memery += VicsDrm05FileUtility.GetFileDataMemery(vicsFilePath, VicsOrDrm.Vics);

            memery += VicsDrm05FileUtility.GetFileDataMemery(drmFilePath, VicsOrDrm.Drm);

            return memery;
        }

        /// <summary>
        /// 合計メモリの取得
        /// </summary>
        /// <returns>合計メモリ</returns>
        public double GetCountObjectMemery()
        {
            double size = 0;

            if (this.cacheDataList != null && this.cacheDataList.Count > 0)
            {
                foreach (VicsDrmCacheData data in this.cacheDataList)
                {
                    size += data.Size;
                }
            }

            return size;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.BusiComm.Exception;
using CREO.BusiComm.ToDoFile;
using CREO.FW.Utilities;

namespace CREO.Fluere.Biz.Utility
{
    #region パターン名の定義

    /// <summary>
    /// ToDoファイルのパターン名
    /// </summary>
    public enum CommToDoPattern
    {
        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_001")]
        XX001 = 1001,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_002")]
        XX002,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_003")]
        XX003,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_004")]
        XX004,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_005")]
        XX005,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_006")]
        XX006,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_007")]
        XX007,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_008")]
        XX008,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_009")]
        XX009,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_010")]
        XX010,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_011")]
        XX011,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_012")]
        XX012,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_013")]
        XX013,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_014")]
        XX014,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_015")]
        XX015,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_016")]
        XX016,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_017")]
        XX017,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_018")]
        XX018,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_019")]
        XX019,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_020")]
        XX020,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_021")]
        XX021,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_022")]
        XX022,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_023")]
        XX023,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_024")]
        XX024,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_025")]
        XX025,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_026")]
        XX026,

        /// <summary>
        /// ToDoファイルのフォーマットパターン
        /// </summary>
        [PatternName("ToDo_XML_UF_XX_027")]
        XX027
    }

    /// <summary>
    /// パターン名の別名です。
    /// </summary>
    [AttributeUsage(AttributeTargets.Field, Inherited = false, AllowMultiple = false)]
    public sealed class PatternNameAttribute : Attribute
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="patternName">パターン名</param>
        public PatternNameAttribute(string patternName)
        {
            PatternName = patternName;
        }

        /// <summary>
        /// パターン名を格納するフィールドです。
        /// </summary>
        public string PatternName { get; private set; }
    }

    #endregion パターン名の定義

    #region 値オブジェクトの定義

    /// <summary>
    /// ToDoデータののラッパー
    /// </summary>
    public class CommToDoDataWrapper
    {
        /// <summary>
        /// 可変フィールドの名と値のコレクションを表します。
        /// </summary>
        private Dictionary<string, string> _dictVariableFields = new Dictionary<string, string>();

        /// <summary>
        /// 確認
        /// </summary>
        private string _workStatus;

        /// <summary>
        /// 調査対象ID
        /// </summary>
        private string _surveyObjectId;

        /// <summary>
        /// 経度
        /// </summary>
        private string _longitude;

        /// <summary>
        /// 緯度
        /// </summary>
        private string _latitude;

        /// <summary>
        /// 検索対象DB
        /// </summary>
        private string _queryObjectDB;

        #region コンストラクタ

        /// <summary>
        /// コンストラクタ
        /// </summary>
        public CommToDoDataWrapper()
        {
            this.WorkStatus = string.Empty;
            this.SurveyObjectId = string.Empty;
            this.Longitude = string.Empty;
            this.Latitude = string.Empty;
            this.QueryObjectDB = string.Empty;
            this.OID = null;
        }

        #endregion コンストラクタ

        /// <summary>
        /// フィールドタイプ
        /// </summary>
        public enum FieldValueType
        {
            /// <summary>
            /// 普遍的なタイプ
            /// </summary>
            GeneralType = 1,

            /// <summary>
            /// OIDタイプ
            /// </summary>
            OidType = 2,
        }

        #region 固定フィールド

        /// <summary>
        /// OID
        /// </summary>
        public ulong? OID { get; set; }

        /// <summary>
        /// 確認
        /// </summary>
        public string WorkStatus
        {
            get { return this._workStatus; }
            set { this._workStatus = value == null ? string.Empty : value; }
        }

        /// <summary>
        /// 調査対象ID
        /// </summary>
        public string SurveyObjectId
        {
            get { return this._surveyObjectId; }
            set { this._surveyObjectId = value == null ? string.Empty : value; }
        }

        /// <summary>
        /// 経度
        /// </summary>
        public string Longitude
        {
            get { return this._longitude; }
            set { this._longitude = value == null ? string.Empty : value; }
        }

        /// <summary>
        /// 緯度
        /// </summary>
        public string Latitude
        {
            get { return this._latitude; }
            set { this._latitude = value == null ? string.Empty : value; }
        }

        /// <summary>
        /// 検索対象DB
        /// </summary>
        public string QueryObjectDB
        {
            get { return this._queryObjectDB; }
            set { this._queryObjectDB = value == null ? string.Empty : value; }
        }

        #endregion 固定フィールド

        /// <summary>
        /// ulong型のOIDを取得する
        /// </summary>
        /// <param name="oidString">OID文字列</param>
        /// <returns>ulong型のOID</returns>
        public static ulong ConvertToOID(string oidString)
        {
            // 10進数
            return IDConverterUtility.StringToID(oidString);
        }

        /// <summary>
        /// string型のOIDを取得する
        /// </summary>
        /// <param name="oid">OID</param>
        /// <returns>文字列型のOID</returns>
        public static string ConvertToOIDString(ulong oid)
        {
            // 10進数
            return IDConverterUtility.IDToString(oid);
        }

        /// <summary>
        /// 可変フィールド値を設定する
        /// </summary>
        /// <param name="fieldName">フィールド名</param>
        /// <param name="fieldValue">フィールド値</param>
        /// <param name="valueType">フィールドタイプ</param>
        private void SetVariableFieldValue(string fieldName, object fieldValue, FieldValueType valueType)
        {
            string strFileValue = string.Empty;

            if (fieldValue != null)
            {
                switch (valueType)
                {
                    case FieldValueType.OidType:
                        strFileValue = ConvertToOIDString((ulong)fieldValue);
                        break;

                    case FieldValueType.GeneralType:
                        strFileValue = fieldValue.ToString();
                        break;

                    default:
                        strFileValue = fieldValue.ToString();
                        break;
                }
            }

            if (this._dictVariableFields.ContainsKey(fieldName))
            {
                this._dictVariableFields[fieldName] = strFileValue;
            }
            else
            {
                this._dictVariableFields.Add(fieldName, strFileValue);
            }
        }

        /// <summary>
        /// 可変フィールド値を設定する
        /// </summary>
        /// <param name="fieldName">フィールド名</param>
        /// <param name="fieldValue">フィールド値</param>
        /// <param name="valueType">フィールドタイプ</param>
        public void SetFieldByName(string fieldName,
            object fieldValue,
            FieldValueType valueType = FieldValueType.GeneralType)
        {
            switch (fieldName)
            {
                case "WorkStatus":
                    this.WorkStatus = fieldValue == null ? string.Empty : fieldValue.ToString();
                    return;

                case "SurveyObjectId":
                    this.SurveyObjectId = fieldValue == null ? string.Empty : fieldValue.ToString();
                    return;

                case "Longitude":
                    this.Longitude = fieldValue == null ? string.Empty : fieldValue.ToString();
                    return;

                case "Latitude":
                    this.Latitude = fieldValue == null ? string.Empty : fieldValue.ToString();
                    return;

                case "QueryObjectDB":
                    this.QueryObjectDB = fieldValue == null ? string.Empty : fieldValue.ToString();
                    return;

                case "OID":
                    this.OID = null;
                    if (fieldValue != null)
                    {
                        if (fieldValue is string && !string.IsNullOrEmpty((string)fieldValue))
                        {
                            this.OID = ConvertToOID((string)fieldValue);
                        }
                        else if (fieldValue is ulong)
                        {
                            this.OID = (ulong?)fieldValue;
                        }
                    }

                    return;

                default:
                    SetVariableFieldValue(fieldName, fieldValue, valueType);
                    return;
            }
        }

        /// <summary>
        /// 可変フィールド値を設定する
        /// </summary>
        /// <param name="fieldNo">フィールドの番号</param>
        /// <param name="fieldValue">フィールド値</param>
        /// <param name="valueType">フィールドタイプ</param>
        public void SetFieldByDefaultName(int fieldNo,
            object fieldValue,
            FieldValueType valueType = FieldValueType.GeneralType)
        {
            string fieldName = string.Format("Column{0}", fieldNo);
            SetVariableFieldValue(fieldName, fieldValue, valueType);
        }

        /// <summary>
        /// 可変フィールド値を取得する
        /// </summary>
        /// <param name="fieldName">フィールド名</param>
        /// <returns>フィールド値</returns>
        private object GetVariableFieldValue(string fieldName)
        {
            object retValue = null;

            if (this._dictVariableFields.ContainsKey(fieldName))
            {
                retValue = this._dictVariableFields[fieldName];
            }
            else
            {
                retValue = null;
            }

            return retValue;
        }

        /// <summary>
        /// 可変フィールド値を取得する
        /// </summary>
        /// <param name="fieldName">フィールド名</param>
        /// <returns>フィールド値</returns>
        public object GetFieldByName(string fieldName)
        {
            switch (fieldName)
            {
                case "WorkStatus":
                    return this.WorkStatus;
                case "SurveyObjectId":
                    return this.SurveyObjectId;
                case "Longitude":
                    return this.Longitude;
                case "Latitude":
                    return this.Latitude;
                case "QueryObjectDB":
                    return this.QueryObjectDB;
                case "OID":
                    return this.OID;
                default:
                    return GetVariableFieldValue(fieldName);
            }
        }

        /// <summary>
        /// 可変フィールド値を取得する
        /// </summary>
        /// <param name="fieldNo">フィールドの番号</param>
        /// <returns>フィールド値</returns>
        public object GetFieldByDefaultName(int fieldNo)
        {
            string fieldName = string.Format("Column{0}", fieldNo);

            return GetVariableFieldValue(fieldName);
        }

        /// <summary>
        /// XElementに変換する
        /// </summary>
        /// <returns>XElement要素</returns>
        public XElement ToXElement()
        {
            XElement recordData = CommToDoWriter.GetNewRecord();

            // 固定フィールド
            // 確認
            recordData.Add(new XAttribute("WorkStatus", this.WorkStatus));

            // 調査対象ID
            recordData.Add(new XAttribute("SurveyObjectId", this.SurveyObjectId));

            // 経度
            recordData.Add(new XAttribute("Longitude", this.Longitude));

            // 緯度
            recordData.Add(new XAttribute("Latitude", this.Latitude));

            // 検索対象DB
            recordData.Add(new XAttribute("QueryObjectDB", this.QueryObjectDB));

            // OID
            string strOID = this.OID == null ? string.Empty : ConvertToOIDString((ulong)this.OID);
            recordData.Add(new XAttribute("OID", strOID));

            // 可変フィールド
            foreach (KeyValuePair<string, string> fieldRecord in this._dictVariableFields)
            {
                recordData.Add(new XAttribute(fieldRecord.Key, fieldRecord.Value));
            }

            return recordData;
        }

        /// <summary>
        /// 反映タイプ
        /// </summary>
        public class ApplyTypes
        {
            /// <summary>
            /// 新規
            /// </summary>
            public const string New = "1";

            /// <summary>
            /// 更新
            /// </summary>
            public const string Update = "2";

            /// <summary>
            /// 削除
            /// </summary>
            public const string Deleted = "3";
        }
    }

    /// <summary>
    /// 2つのToDoデータが等しいか否かを判別するための比較処理を提供します
    /// </summary>
    public class CommToDoHashSetComparer : EqualityComparer<CommToDoDataWrapper>
    {
        /// <summary>
        /// 2つのToDoデータが等しいか否かを判別する
        /// </summary>
        /// <param name="d1">ToDoデータ１</param>
        /// <param name="d2">ToDoデータ２</param>
        /// <returns>等しいか否か</returns>
        public override bool Equals(CommToDoDataWrapper d1, CommToDoDataWrapper d2)
        {
            // 基幹交差点OID
            return d1.OID == d2.OID;
        }

        /// <summary>
        /// ハッシュ コードを返します
        /// </summary>
        /// <param name="d">ToDoデータ</param>
        /// <returns>ハッシュ コード</returns>
        public override int GetHashCode(CommToDoDataWrapper d)
        {
            return d.OID.GetHashCode();
        }
    }

    #endregion 値オブジェクトの定義

    #region 処理クラス

    /// <summary>
    /// 共通部品CommToDoWriterクラスのラッパー
    /// </summary>
    public class CommToDoWriteWrapper
    {
        #region フィールド

        /// <summary>
        /// グローバルインスタンス
        /// </summary>
        private static CommToDoWriteWrapper globalInstance = null;

        #endregion フィールド

        #region コンストラクタ

        /// <summary>
        /// CommToDoWriteWrapperクラスを初期化する。
        /// </summary>
        protected CommToDoWriteWrapper()
        {
            this.ReSet();
        }

        #endregion コンストラクタ

        #region プロパティ

        /// <summary>
        /// 日付情報
        /// </summary>
        public string DateInfo { get; protected set; }

        /// <summary>
        /// 日付付いているファイル名ですか
        /// </summary>
        public bool IsNeedDateInfo { get; set; }

        /// <summary>
        /// ファイル名の説明
        /// </summary>
        public string FileComment { get; set; }

        /// <summary>
        /// 作業ファイル名
        /// </summary>
        public string FilePath { get; private set; }

        /// <summary>
        /// 処理した作業ファイル名リスト
        /// </summary>
        public List<string> FilesPathList { get; set; }

        #endregion プロパティ

        #region スタティック・メソッド

        /// <summary>
        /// ラッパーのグローバルインスタンスを取得する
        /// </summary>
        /// <returns>グローバルインスタンス</returns>
        public static CommToDoWriteWrapper GetGlobalInstance()
        {
            if (globalInstance == null)
            {
                globalInstance = new CommToDoWriteWrapper();
            }

            return globalInstance;
        }

        /// <summary>
        /// パターン名を取得する
        /// </summary>
        /// <param name="value">パターン定義</param>
        /// <returns>パターン名</returns>
        protected static string GetPatternName(CommToDoPattern value)
        {
            PatternNameAttribute attribute = value.GetType().GetField(value.ToString())
                .GetCustomAttributes(typeof(PatternNameAttribute), false)
                .Cast<PatternNameAttribute>().FirstOrDefault();

            if (attribute == null)
            {
                throw new ArgumentException("PatternName属性が設定されていません。{0}", value.ToString());
            }

            return attribute.PatternName;
        }

        #endregion スタティック・メソッド

        #region パブリック・メソッド

        /// <summary>
        /// 設定情報をリセットする
        /// </summary>
        /// <param name="isNeedDateInfo">日付付いているファイル名ですか</param>
        public virtual void ReSet(bool isNeedDateInfo = true)
        {
            this.DateInfo = DateTime.Now.ToString("yyyyMMddHHmmss", DateTimeFormatInfo.InvariantInfo);
            this.IsNeedDateInfo = isNeedDateInfo;
            this.FileComment = @"ToDoリストファイル";
        }

        /// <summary>
        /// ToDoファイルを出力する
        /// </summary>
        /// <param name="folderPath">フォルダパス</param>
        /// <param name="fileName">ファイル名</param>
        /// <param name="patternNo">パターン名</param>
        /// <param name="todoDataList">ToDoデータリスト</param>
        /// <remarks>
        /// ファイルが存在する場合は、ファイルを切り詰め、新しい内容で上書きする。
        /// エンコーディングはデフォルトでUTF-8に設定されている。
        /// </remarks>
        public void WriteToDoFile(string folderPath,
            string fileName,
            CommToDoPattern patternNo,
            List<CommToDoDataWrapper> todoDataList)
        {
            WriteToDoFile(folderPath, fileName, patternNo, todoDataList, Encoding.UTF8);
        }

        /// <summary>
        /// ToDoファイルを出力する
        /// </summary>
        /// <param name="folderPath">フォルダパス</param>
        /// <param name="fileName">ファイル名</param>
        /// <param name="patternNo">パターン名</param>
        /// <param name="todoDataList">ToDoデータリスト</param>
        /// <param name="fileEncoding">エンコーディング</param>
        /// <remarks>
        /// ファイルが存在する場合は、ファイルを切り詰め、新しい内容で上書きする。
        /// </remarks>
        public void WriteToDoFile(string folderPath,
            string fileName,
            CommToDoPattern patternNo,
            List<CommToDoDataWrapper> todoDataList,
            Encoding fileEncoding)
        {
            this.FilePath = string.Empty;

            if (todoDataList == null)
            {
                todoDataList = new List<CommToDoDataWrapper>();
            }

            LogUtility.WriteDataCount(string.Format("【{0}のレコード数】", this.FileComment),
                LogUtility.OperationType.File,
                todoDataList.Count);

            CommToDoWriter commToDoWriter = null;
            string filePath = null;
            string patternName = null;

            if (IsNeedDateInfo)
            {
                string baseName = Path.GetFileNameWithoutExtension(fileName);
                string extension = Path.GetExtension(fileName);
                string fileNameWithDate = string.Format("{0}_{1}{2}", baseName, this.DateInfo, extension);
                filePath = Path.Combine(folderPath, fileNameWithDate);
            }
            else
            {
                filePath = Path.Combine(folderPath, fileName);
            }

            this.FilePath = filePath;

            patternName = GetPatternName(patternNo);

            try
            {
                // 初期化
                commToDoWriter = new CommToDoWriter(filePath, patternName, fileEncoding);

                // フィールドの名前に基づいて、フィールド値を設定する場合
                // 出力用オブジェクトを取得する
                foreach (CommToDoDataWrapper data in todoDataList)
                {
                    // レコードを出力する
                    commToDoWriter.WriteData(data.ToXElement());
                }

                // 出力を終了する
                commToDoWriter.Close();

                LogUtility.WriteInfo("【{0}を生成しました。】{1}", this.FileComment, filePath);
            }
            catch (Exception ex)
            {
                if (ex is BusinessCommonException)
                {
                    BusinessCommonException bEx = (BusinessCommonException)ex;
                    if (bEx.MessageId != CREO.CommonBusinessLogic.CM_BusiComm_MsgId.MSGID_TODO_FILE_EXIST)
                    {
                        if (File.Exists(filePath))
                        {
                            ////// ファイルが作成失敗の場合、ゴミファイルを削除する
                            ////File.Delete(filePath);
                            LogUtility.WriteWarning("{0}:{1}", "【作成された中間ToDoファイルが残っている】", filePath);
                        }
                    }
                }

                throw ex;
            }
            finally
            {
                // リソースを解放する
                if (null != commToDoWriter)
                {
                    commToDoWriter.Dispose();
                }

                commToDoWriter = null;
            }
        }

        #endregion パブリック・メソッド

        /// <summary>
        /// ToDoファイルを出力する
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="patternNo">パターン名</param>
        /// <param name="todoDataList">ToDoデータリスト</param>
        /// <remarks>
        /// ファイルが存在する場合は、ファイルを切り詰め、新しい内容で上書きする。
        /// エンコーディングはデフォルトでUTF-8に設定されている。
        /// </remarks>
        public void WriteToDoFile(string filePath,
            CommToDoPattern patternNo,
            List<CommToDoDataWrapper> todoDataList)
        {
            string folderPath = Path.GetDirectoryName(filePath);
            string fileName = Path.GetFileName(filePath);

            WriteToDoFile(folderPath, fileName, patternNo, todoDataList, Encoding.UTF8);
        }
    }

    #endregion 処理クラス
}
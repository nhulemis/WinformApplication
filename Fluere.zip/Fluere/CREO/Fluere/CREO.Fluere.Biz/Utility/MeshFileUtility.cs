﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// MeshFileUtilityクラス
    /// </summary>
    public class MeshFileUtility
    {
        #region 2次メッシュコードの重複チェック
        /// <summary>
        /// 2次メッシュコードの重複チェック
        /// </summary>
        /// <param name="meshListFileNames">2次メッシュリストファイルlist</param>
        public static void CheckMeshFile(List<string> meshListFileNames)
        {
            Dictionary<string, List<string>> dicFileMesh = new Dictionary<string, List<string>>();

            List<string> allMesh = new List<string>();

            foreach (var meshListFile in meshListFileNames)
            {
                string fileName = Path.GetFileNameWithoutExtension(meshListFile);

                List<string> resultMesh = new List<string>();

                ////foreach (string line in File.ReadAllLines(meshListFile))
                ////{
                ////    resultMesh.Add(line);
                ////    allMesh.Add(line);
                ////}
                resultMesh = ReadMeshFile(meshListFile);

                dicFileMesh.Add(fileName, resultMesh);
            }

            Dictionary<string, List<string>> cfFile = new Dictionary<string, List<string>>();
            List<string> checkList = new List<string>();

            foreach (var item in dicFileMesh)
            {
                List<string> list = item.Value;

                foreach (string mesh in list)
                {
                    if (!cfFile.ContainsKey(mesh))
                    {
                        List<string> lis = new List<string>();
                        lis.Add(item.Key);
                        cfFile.Add(mesh, lis);
                    }
                    else
                    {
                        cfFile[mesh].Add(item.Key);
                    }
                }
            }

            bool exFlg = false;

            foreach (var item in cfFile)
            {
                List<string> listFile = item.Value;
                if (listFile.Count > 1)
                {
                    // 重複な2次メッシュコードが見つかった場合
                    string msgId = UF_Fluere_MsgId.MSGID_UF10000276;
                    exFlg = true;
                    LogUtility.Write(msgId,
                    item.Key,
                    string.Join(",", listFile));
                }
            }

            if (exFlg)
            {
                // 2次メッシュコードの重複チェック結果が重複ありの場合
                // string msgId = UF_Fluere_MsgId.MSGID_UF10000277;
                // throw new BusinessLogicException(msgId);
            }
        }
        #endregion

        #region 2次メッシュリストファイルの読込
        /// <summary>
        /// 2次メッシュリストファイルの読込
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <returns>2次メッシュリスト</returns>
        public static List<string> ReadMeshFile(string filePath)
        {
            List<string> resultMesh = new List<string>();

            try
            {
                foreach (string line in File.ReadAllLines(filePath))
                {
                    resultMesh.Add(line);
                }
            }
            catch (Exception)
            {
                // UF10000213
                // 2次メッシュリストファイルがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000213;
                throw new BusinessLogicException(msgId, new string[] { filePath });
            }

            return resultMesh;
        }
        #endregion

        #region 処理済みリストフォルダへ移動
        /// <summary>
        /// 処理済みリストフォルダへ移動
        /// </summary>
        /// <param name="folderFilePath">ソースファイル</param>
        /// <param name="destFolderPath">ターゲットのファイル</param>
        public static void MoveFile(string folderFilePath, string destFolderPath)
        {
            string[] name = folderFilePath.Split('\\');
            string sourceName = name[name.Length - 1];
            string destFilePath = destFolderPath + "\\" + sourceName;

            try
            {
                // 処理済みリストフォルダへ移動
                File.Move(folderFilePath, destFilePath);
            }
            catch (Exception)
            {
                // UF40002145
                // 処理済みフォルダに移動できない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40002145;
                throw new BusinessLogicException(msgId, new string[] { sourceName, destFolderPath });
            }
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.FW.Log;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 例外のinnerメッセージの取得
    /// </summary>
    public class ExceptionUtility
    {
        /// <summary>
        /// 例外のinnerメッセージを取得する
        /// </summary>
        /// <param name="ex">例外</param>
        /// <returns>メッセージ</returns>
        public static string GetInnerExceptionMessage(Exception ex)
        {
            StringBuilder builder = new StringBuilder();

            if (!string.IsNullOrEmpty(ex.Message))
            {
                builder.Append(ex.Message);
            }

            while (ex.InnerException != null)
            {
                builder.Append(ex.InnerException.ToString());
                builder.Append("\r\n");

                ex = ex.InnerException;
            }

            // Emptyの場合、スペースを補足
            string msg = builder.ToString();
            if (string.IsNullOrEmpty(msg))
            {
                msg = " ";
            }

            return msg;
        }
    }
}

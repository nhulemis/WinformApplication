﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// 型変換ユーティリティ
    /// </summary>
    public class ConvertUtility
    {
        /// <summary>
        /// stringをushort?に変換する
        /// </summary>
        /// <param name="strValue">string型の値</param>
        /// <returns>ushort?型の値</returns>
        public static ushort? ConvertToUshort(string strValue)
        {
            ushort? retValue = null;

            if (null != strValue)
            {
                strValue = strValue.Trim();
                if (strValue.Length > 0)
                {
                    retValue = ushort.Parse(strValue);
                }
            }

            return retValue;
        }

        /// <summary>
        /// stringをushort?に変換する
        /// </summary>
        /// <param name="strValue">string型の値</param>
        /// <returns>byte?型の値</returns>
        public static byte? ConvertToByte(string strValue)
        {
            byte? retValue = null;

            if (null != strValue)
            {
                strValue = strValue.Trim();
                if (strValue.Length > 0)
                {
                    retValue = byte.Parse(strValue);
                }
            }

            return retValue;
        }

        /// <summary>
        /// stringをulong?に変換する
        /// </summary>
        /// <param name="strValue">string型の値</param>
        /// <returns>ulong?型の値</returns>
        public static ulong? ConvertToUlong(string strValue)
        {
            ulong? retValue = null;

            if (null != strValue)
            {
                strValue = strValue.Trim();
                if (strValue.Length > 0)
                {
                    retValue = ulong.Parse(strValue);
                }
            }

            return retValue;
        }

        /// <summary>
        /// stringをlong?に変換する
        /// </summary>
        /// <param name="strValue">string型の値</param>
        /// <returns>ulong?型の値</returns>
        public static long? ConvertToLong(string strValue)
        {
            long? retValue = null;

            if (null != strValue)
            {
                strValue = strValue.Trim();
                if (strValue.Length > 0)
                {
                    retValue = long.Parse(strValue);
                }
            }

            return retValue;
        }
    }
}

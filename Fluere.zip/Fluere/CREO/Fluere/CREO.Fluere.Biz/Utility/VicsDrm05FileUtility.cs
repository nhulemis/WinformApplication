﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.Utility
{
    /// <summary>
    /// VicsとDrmの値の定義
    /// </summary>
    public enum VicsOrDrm
    {
        /// <summary>
        /// Vics
        /// </summary>
        Vics = 1,

        /// <summary>
        /// Drm
        /// </summary>
        Drm = 2
    }

    /// <summary>
    /// 共通用のユーティリティクラス
    /// </summary>
    public class VicsDrm05FileUtility
    {
        #region クラス定数
        /// <summary>
        /// VICSファイルサイズの倍数（平均計測値）
        /// NET Memory Profilerで計測した値を基に、VICSリンクデータを想定する。
        /// </summary>
        private const double VICS = 3.0;

        /// <summary>
        /// DRMファイルサイズの倍数（平均計測値）
        /// NET Memory Profilerで計測した値を基に、DRMデータを想定する。
        /// </summary>
        private const double DRM = 1.0;

        /// <summary>
        /// DRMデータのフォルダパス
        /// </summary>
        public static string DRMFolderPath = string.Empty;

        /// <summary>
        /// DRMの拡張子
        /// </summary>
        private const string DRM_EXDENT = ".mt";

        /// <summary>
        /// 1024
        /// </summary>
        private const double K = 1024.0;
        #endregion

        #region VICSリンクファイルパスより取得
        /// <summary>
        /// VICSリンクファイルパスより取得
        /// </summary>
        /// <param name="folder">05向けVICSリンクファイルのフォルダパス</param>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <param name="extensionNum">ファイル拡張子番号</param>
        /// <returns>VICSリンクファイルパス(ファイルが存在しない場合はファイル名(拡張子なし))</returns>
        public static string Get05VicsLinkFilePath(string folder, int meshCode, int extensionNum)
        {
            // ファイル名(拡張子なし)
            var fileName = "V" + meshCode.ToString();

            // 指定フォルダ内のVICSリンクファイル情報をすべて取得(サブディレクトリは対象外)
            var dirInfo = new DirectoryInfo(folder);
            var fileInfos = dirInfo.GetFiles(fileName + ".V*", SearchOption.TopDirectoryOnly);

            // V0～Vxxx(xxxは拡張子指定の番号)までの拡張子のものだけを抽出する
            fileInfos = fileInfos.Where(inf =>
                {
                    // ".V"を除く
                    var ex = inf.Extension.Remove(0, 2);
                    int num = 0;
                    if (int.TryParse(ex, out num))
                    {
                        if (0 <= num && num <= extensionNum)
                        {
                            return true;
                        }

                        return false;
                    }

                    return false;
                }).ToArray();

            if (!fileInfos.Any())
            {
                // ファイルが存在しない場合
                // ファイル名(拡張子なし)を返す
                return fileName;
            }
            else if (fileInfos.Count() > 1)
            {
                // 拡張子が複数存在する場合
                // エラーとし、処理終了
                var msgId = UF_Fluere_MsgId.MSGID_UF10000191;
                var parameters = new string[] { folder, string.Join(",", fileInfos.Select(n => n.Name)), extensionNum.ToString() };
                throw new BusinessLogicException(msgId, parameters);
            }

            return fileInfos.First().FullName;
        }
        #endregion

        #region DRMデータのファイルパスより取得
        /// <summary>
        /// DRMデータのファイルパスより取得
        /// </summary>
        /// <param name="meshCode">メッシュコード</param>
        /// <returns>ファイルパス</returns>
        public static string Get05DrmFilePath(int meshCode)
        {
            return Path.Combine(DRMFolderPath, meshCode.ToString() + DRM_EXDENT);
        }
        #endregion

        #region 05向けVICSリンクファイルの読込
        /// <summary>
        /// 05向けVICSリンクファイルを読み込み
        /// </summary>
        /// <param name="folderPath">05向けVICSリンクファイル</param>
        /// <param name="meshCode">メッシュコード</param>
        /// <param name="extensionNum">拡張子番号指定</param>
        /// <returns>VICSLinkFileDataリスト</returns>
        public static List<VICSLinkFileData> LoadVICSLinkFileList(string folderPath, int meshCode, int extensionNum)
        {
            List<VICSLinkFileData> dataList = new List<VICSLinkFileData>();

            string filePath = string.Empty;

            try
            {
                filePath = Get05VicsLinkFilePath(folderPath, meshCode, extensionNum);
                if (File.Exists(filePath))
                {
                    dataList = VICSLinkFileManager.ReadVICSLinkFile(filePath);
                }
                else
                {
                    var msgId = UF_Fluere_MsgId.MSGID_UF10000190;
                    var parameters = new string[] { folderPath, filePath, extensionNum.ToString() };
                    LogUtility.Write(msgId, parameters);
                }

                return dataList;
            }
            catch (Exception ex)
            {
                LogUtility.WriteError(ex, ex.Message);

                // VICSリンクファイルがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000168;
                string[] parameters = new string[] { filePath };

                throw new BusinessLogicException(msgId, parameters, ex);
            }
        }
        #endregion

        #region ファイルメモリ計算
        /// <summary>
        /// ファイルメモリ計算
        /// </summary>
        /// <param name="filePath">DRMファイル</param>
        /// <param name="mode">VicsOrDrm</param>
        /// <returns>メモリサイズ</returns>
        public static double GetFileDataMemery(string filePath, VicsOrDrm mode)
        {
            double memery = 0;

            double x = 0;

            if (VicsOrDrm.Vics == mode)
            {
                x = VICS;
            }
            else if (VicsOrDrm.Drm == mode)
            {
                x = DRM;
            }
            else
            {
                return 0;
            }

            long size = GetFileSize(filePath);

            if (size > 0)
            {
                memery = Convert.ToDouble((size * x) / K / K);
            }

            // 0.00
            return Math.Round(memery, 2);
        }
        #endregion

        #region ファイルのサイズより取得
        /// <summary>
        /// ファイルのサイズより取得
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <returns>ファイルサイズ</returns>
        private static long GetFileSize(string filePath)
        {
            long size = 0;

            if (File.Exists(filePath))
            {
                FileInfo fileInfo = new FileInfo(filePath);
                size = fileInfo.Length;
                fileInfo = null;
            }

            return size;
        }
        #endregion
    }
}

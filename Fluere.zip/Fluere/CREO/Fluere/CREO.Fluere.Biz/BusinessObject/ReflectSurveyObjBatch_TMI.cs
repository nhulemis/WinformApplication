﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using CREO.DS.DataProvider;
using CREO.Materia;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 調査対象ID発行API、バッチ調査対象データ反映API
    /// </summary>
    public class ReflectSurveyObjBatch_TMI
    {
        /// <summary>
        /// パラメータにより、調査対象データの操作
        /// </summary>
        /// <param name="dtSurveyObj">調査対象データ</param>
        /// <param name="dpb0100103">DB接続ハンドル</param>
        /// <returns>処理結果コード</returns>
        public static int UpdateSurveyObjForSTwnPOIUpdate(DataTable dtSurveyObj, DBDataProviderBase dpb0100103)
        {
            try
            {
                dpb0100103.BeginTransaction();

                for (int i = 0; i < dtSurveyObj.Rows.Count; i++)
                {
                    string[] listSurveyObjData = new string[] 
                    {
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE,
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE 
                    };

                    // 処理区分が01、02以外の場合、パラメータエラーとして、返す。
                    if (!dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION].Equals(
                        ReflectSurveyObjConst.PROCESS_DIVISION_INSERT)
                        && !dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION].Equals(
                        ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE))
                    {
                        return ReflectSurveyObjConst.RTN_INT_ONE;
                    }

                    listSurveyObjData[0] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID]);
                    listSurveyObjData[1] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_ARTICLESOURCEID]);
                    listSurveyObjData[2] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_DRAWINGSOURCEID]);
                    listSurveyObjData[3] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_TRIGGERID]);
                    listSurveyObjData[4] = string.Empty;
                    listSurveyObjData[5] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_SELECTDIVISION]);
                    listSurveyObjData[6] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_DUPLCONFDATA]);
                    listSurveyObjData[7] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_REMARKS]);
                    listSurveyObjData[8] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_DISPLAYITEM1]);
                    listSurveyObjData[9] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_DISPLAYITEM2]);
                    listSurveyObjData[10] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_OLDSURVEYOBJECTID]);
                    listSurveyObjData[11] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_TODOOUTPUTFLAG]);
                    listSurveyObjData[12] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS]);
                    listSurveyObjData[13] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_NEXTSURVEYDATE]);
                    listSurveyObjData[14] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS]);
                    listSurveyObjData[15] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_SURVEYMEMO]);
                    listSurveyObjData[16] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_CREATEDDATE]);
                    listSurveyObjData[17] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_CREATEUSERID]);
                    listSurveyObjData[18] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE]);
                    listSurveyObjData[19] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID]);

                    // 「調査対象ID」が空白の場合、パラメータエラーとして、返す。
                    if (string.IsNullOrEmpty(listSurveyObjData[0]))
                    {
                        return ReflectSurveyObjConst.RTN_INT_ONE;
                    }

                    // 処理区分：01登録
                    if (dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION].Equals(
                        ReflectSurveyObjConst.PROCESS_DIVISION_INSERT))
                    {
                        //// 「トリガID」をチェックする
                        if (string.IsNullOrEmpty(listSurveyObjData[3]))
                        {
                            return ReflectSurveyObjConst.RTN_INT_ONE;
                        }

                        ////「選別区分」がNULLの場合、空白で登録する
                        if (string.IsNullOrEmpty(listSurveyObjData[5]))
                        {
                            listSurveyObjData[5] = string.Empty;
                        }

                        // TMI側削除
                        ////「TODO出力フラグ」:0 TODOへ未出力
                        ////listSurveyObjData[11] = ReflectSurveyObjConst.TO_DO_OUTPUT_FLAG_ZERO;

                        ////「調査ステータス」:0 調査未着手
                        ////listSurveyObjData[12] = ReflectSurveyObjConst.SURVEY_STATUS_MITYAKUSYU;
                        // TMI側削除

                        ////「引き継ぎステータス」をチェックする
                        if (string.IsNullOrEmpty(listSurveyObjData[14]))
                        {
                            return ReflectSurveyObjConst.RTN_INT_ONE;
                        }

                        //// トリガ種別から出典カテゴリを取得する
                        DataTable dtSourceCategory = SelSourceCategory(listSurveyObjData[3], dpb0100103);

                        // 出典カテゴリがない場合、エラー
                        if (dtSourceCategory == null || dtSourceCategory.Rows.Count <= 0)
                        {
                            return ReflectSurveyObjConst.RTN_INT_NINE;
                        }

                        listSurveyObjData[4] = Convert.ToString(dtSourceCategory.Rows[0]["SourceCategory"]);

                        //// 調査対象データに登録する
                        int intInsertRtnCode = InsertMsSurveyObj(listSurveyObjData, dpb0100103);

                        if (intInsertRtnCode <= ReflectSurveyObjConst.VALUE_INT_ZERO)
                        {
                            return ReflectSurveyObjConst.RTN_INT_NINE;
                        }
                    }

                    // 処理区分：02更新
                    if (dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION].Equals(
                        ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE))
                    {
                        // 調査対象データを更新する
                        int intUpdateRtnCode = UpdateMsSurveyobj(listSurveyObjData, dpb0100103);

                        if (intUpdateRtnCode <= ReflectSurveyObjConst.VALUE_INT_ZERO)
                        {
                            return ReflectSurveyObjConst.RTN_INT_NINE;
                        }
                    }
                }

                dpb0100103.CommitTransaction();
                return ReflectSurveyObjConst.RTN_INT_ZERO;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// パラメータにより、調査対象データの操作
        /// </summary>
        /// <param name="dtSurveyObj">調査対象データ</param>
        /// <param name="dpb0100103">DB接続ハンドル</param>
        /// <returns>処理結果コード</returns>
        public static int UpdateSurveyObj(DataTable dtSurveyObj, DBDataProviderBase dpb0100103)
        {
            try
            {
                dpb0100103.BeginTransaction();

                for (int i = 0; i < dtSurveyObj.Rows.Count; i++)
                {
                    string[] listSurveyObjData = new string[] 
                    {
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE,
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE, 
                        ReflectSurveyObjConst.BLANK_VALUE 
                    };

                    // 処理区分が01、02以外の場合、パラメータエラーとして、返す。
                    if (!dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION].Equals(
                        ReflectSurveyObjConst.PROCESS_DIVISION_INSERT)
                        && !dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION].Equals(
                        ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE))
                    {
                        return ReflectSurveyObjConst.RTN_INT_ONE;
                    }

                    listSurveyObjData[0] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID]);
                    listSurveyObjData[1] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_ARTICLESOURCEID]);
                    listSurveyObjData[2] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_DRAWINGSOURCEID]);
                    listSurveyObjData[3] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_TRIGGERID]);
                    listSurveyObjData[4] = string.Empty;
                    listSurveyObjData[5] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_SELECTDIVISION]);
                    listSurveyObjData[6] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_DUPLCONFDATA]);
                    listSurveyObjData[7] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_REMARKS]);
                    listSurveyObjData[8] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_DISPLAYITEM1]);
                    listSurveyObjData[9] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_DISPLAYITEM2]);
                    listSurveyObjData[10] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_OLDSURVEYOBJECTID]);
                    listSurveyObjData[11] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_TODOOUTPUTFLAG]);
                    listSurveyObjData[12] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS]);
                    listSurveyObjData[13] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_NEXTSURVEYDATE]);
                    listSurveyObjData[14] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS]);
                    listSurveyObjData[15] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_SURVEYMEMO]);
                    listSurveyObjData[16] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_CREATEDDATE]);
                    listSurveyObjData[17] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_CREATEUSERID]);
                    listSurveyObjData[18] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE]);
                    listSurveyObjData[19] =
                        Convert.ToString(dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID]);

                    // 「調査対象ID」が空白の場合、パラメータエラーとして、返す。
                    if (string.IsNullOrEmpty(listSurveyObjData[0]))
                    {
                        return ReflectSurveyObjConst.RTN_INT_ONE;
                    }

                    // 処理区分：01登録
                    if (dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION].Equals(
                        ReflectSurveyObjConst.PROCESS_DIVISION_INSERT))
                    {
                        //// 「トリガID」をチェックする
                        if (string.IsNullOrEmpty(listSurveyObjData[3]))
                        {
                            return ReflectSurveyObjConst.RTN_INT_ONE;
                        }

                        ////「選別区分」がNULLの場合、空白で登録する
                        if (string.IsNullOrEmpty(listSurveyObjData[5]))
                        {
                            listSurveyObjData[5] = string.Empty;
                        }

                        ////「TODO出力フラグ」:0 TODOへ未出力
                        listSurveyObjData[11] = ReflectSurveyObjConst.TO_DO_OUTPUT_FLAG_ZERO;

                        ////「調査ステータス」:0 調査未着手
                        listSurveyObjData[12] = ReflectSurveyObjConst.SURVEY_STATUS_MITYAKUSYU;

                        ////「引き継ぎステータス」をチェックする
                        if (string.IsNullOrEmpty(listSurveyObjData[14]))
                        {
                            return ReflectSurveyObjConst.RTN_INT_ONE;
                        }

                        //// トリガ種別から出典カテゴリを取得する
                        DataTable dtSourceCategory = SelSourceCategory(listSurveyObjData[3], dpb0100103);

                        // 出典カテゴリがない場合、エラー
                        if (dtSourceCategory == null || dtSourceCategory.Rows.Count <= 0)
                        {
                            return ReflectSurveyObjConst.RTN_INT_NINE;
                        }

                        listSurveyObjData[4] = Convert.ToString(dtSourceCategory.Rows[0]["SourceCategory"]);

                        //// 調査対象データに登録する
                        int intInsertRtnCode = InsertMsSurveyObj(listSurveyObjData, dpb0100103);

                        if (intInsertRtnCode <= ReflectSurveyObjConst.VALUE_INT_ZERO)
                        {
                            return ReflectSurveyObjConst.RTN_INT_NINE;
                        }
                    }

                    // 処理区分：02更新
                    if (dtSurveyObj.Rows[i][ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION].Equals(
                        ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE))
                    {
                        // 調査対象データを更新する
                        int intUpdateRtnCode = UpdateMsSurveyobj(listSurveyObjData, dpb0100103);

                        if (intUpdateRtnCode <= ReflectSurveyObjConst.VALUE_INT_ZERO)
                        {
                            return ReflectSurveyObjConst.RTN_INT_NINE;
                        }
                    }
                }

                dpb0100103.CommitTransaction();
                return ReflectSurveyObjConst.RTN_INT_ZERO;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 調査対象テーブルの登録
        /// </summary>
        /// <param name="listSurveyObjData">登録データリスト</param>
        /// <param name="dpbHandler">DB接続ハンドル</param>
        /// <returns>登録結果コード</returns>
        private static int InsertMsSurveyObj(string[] listSurveyObjData, DBDataProviderBase dpbHandler)
        {
            int intRet = ReflectSurveyObjConst.VALUE_INT_ZERO;
            StringBuilder sqlContent = new StringBuilder();
            sqlContent.Append(" INSERT INTO");
            sqlContent.Append(" MS_SURVEYOBJ (");
            //// 調査対象データ：調査対象ID
            sqlContent.Append("SurveyObjectId");
            //// 調査対象データ：出典O-ID(物件)
            sqlContent.Append(", ArticleSourceId");
            //// 調査対象データ：出典O-ID(描画)
            sqlContent.Append(", DrawingSourceId");
            //// 調査対象データ：トリガID
            sqlContent.Append(", TriggerId");
            //// 調査対象データ：出典カテゴリ
            sqlContent.Append(", SourceCategory");
            //// 調査対象データ：選別区分
            sqlContent.Append(", SelectDivision");
            //// 調査対象データ：重複確認用データ
            sqlContent.Append(", DuplConfData");
            //// 調査対象データ：備考
            sqlContent.Append(", Remarks");
            //// 調査対象データ：表示用項目１
            sqlContent.Append(", DisplayItem1");
            //// 調査対象データ：表示用項目２
            sqlContent.Append(", DisplayItem2");
            //// 調査対象データ：元調査対象ID
            sqlContent.Append(", OldSurveyObjectId");
            //// 調査対象データ：TODO出力フラグ
            sqlContent.Append(", ToDoOutputFlag");
            //// 調査対象データ：調査ステータス
            sqlContent.Append(", SurveyStatus");
            //// 調査対象データ：次回調査可能日
            sqlContent.Append(", NextSurveyDate");
            //// 調査対象データ：引き継ぎステータス
            sqlContent.Append(", HandoverStatus");
            //// 調査対象データ：調査メモ
            sqlContent.Append(", SurveyMemo");
            //// 調査対象データ：生成日時
            sqlContent.Append(", CreatedDate");
            //// 調査対象データ：生成ユーザID
            sqlContent.Append(", CreateUserId");
            //// 調査対象データ：最終更新日時
            sqlContent.Append(", ModifiedDate");
            //// 調査対象データ：最終更新ユーザID
            sqlContent.Append(", ModifyUserId");
            sqlContent.Append(")");
            sqlContent.Append(" VALUES (");

            sqlContent.Append(listSurveyObjData[0] + ",");
            if (string.IsNullOrEmpty(listSurveyObjData[1]))
            {
                sqlContent.Append("null,");
            }
            else
            {
                sqlContent.Append(listSurveyObjData[1] + ",");
            }

            if (string.IsNullOrEmpty(listSurveyObjData[2]))
            {
                sqlContent.Append("null,");
            }
            else
            {
                sqlContent.Append(listSurveyObjData[2] + ",");
            }

            sqlContent.Append("'" + listSurveyObjData[3] + "'" + ",");
            sqlContent.Append("'" + listSurveyObjData[4] + "'" + ",");
            sqlContent.Append("'" + listSurveyObjData[5] + "'" + ",");

            if (string.IsNullOrEmpty(listSurveyObjData[6]))
            {
                sqlContent.Append("null,");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[6] + "'" + ",");
            }

            if (string.IsNullOrEmpty(listSurveyObjData[7]))
            {
                sqlContent.Append("null,");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[7] + "'" + ",");
            }

            if (string.IsNullOrEmpty(listSurveyObjData[8]))
            {
                sqlContent.Append("null,");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[8] + "'" + ",");
            }

            if (string.IsNullOrEmpty(listSurveyObjData[9]))
            {
                sqlContent.Append("null,");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[9] + "'" + ",");
            }

            if (string.IsNullOrEmpty(listSurveyObjData[10]))
            {
                sqlContent.Append("null,");
            }
            else
            {
                sqlContent.Append(listSurveyObjData[10] + ",");
            }

            sqlContent.Append("'" + listSurveyObjData[11] + "'" + ",");
            sqlContent.Append("'" + listSurveyObjData[12] + "'" + ",");

            if (string.IsNullOrEmpty(listSurveyObjData[13]))
            {
                sqlContent.Append("null,");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[13] + "'" + ",");
            }

            sqlContent.Append("'" + listSurveyObjData[14] + "'" + ",");

            if (string.IsNullOrEmpty(listSurveyObjData[15]))
            {
                sqlContent.Append("null,");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[15] + "'" + ",");
            }

            if (string.IsNullOrEmpty(listSurveyObjData[16]))
            {
                sqlContent.Append(" @CreatedDate" + ",");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[16] + "'" + ",");
            }

            if (string.IsNullOrEmpty(listSurveyObjData[17]))
            {
                sqlContent.Append(" @CreateUserId" + ",");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[17] + "'" + ",");
            }

            if (string.IsNullOrEmpty(listSurveyObjData[18]))
            {
                sqlContent.Append("@ModifiedDate" + ",");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[18] + "'" + ",");
            }

            if (string.IsNullOrEmpty(listSurveyObjData[19]))
            {
                sqlContent.Append("@ModifyUserId)");
            }
            else
            {
                sqlContent.Append("'" + listSurveyObjData[19] + "')");
            }

            SqlParameter paraCreatedDate =
                new SqlParameter("@CreatedDate", DateTime.Now);
            SqlParameter paraCreateUserId =
                new SqlParameter("@CreateUserId", System.Environment.UserName);
            SqlParameter paraModifiedDate =
                new SqlParameter("@ModifiedDate", DateTime.Now);
            SqlParameter paraModifyUserId =
                new SqlParameter("@ModifyUserId", System.Environment.UserName);
            intRet = dpbHandler.ExecuteNonQuery(sqlContent.ToString(),
                         new SqlParameter[] { paraCreatedDate, paraCreateUserId, paraModifiedDate, paraModifyUserId });

            return intRet;
        }

        /// <summary>
        /// 調査対象テーブルの更新
        /// </summary>
        /// <param name="listSurveyObjData">更新データリスト</param>
        /// <param name="dpbHandler">DB接続ハンドル</param>
        /// <returns>更新結果コード</returns>
        private static int UpdateMsSurveyobj(string[] listSurveyObjData,
            DBDataProviderBase dpbHandler)
        {
            int intRet = ReflectSurveyObjConst.VALUE_INT_ZERO;
            StringBuilder sqlContent = new StringBuilder();
            sqlContent.Append(" UPDATE MS_SURVEYOBJ");
            sqlContent.Append(" SET");
            //// 調査対象データ：調査対象ID
            sqlContent.Append(" SurveyObjectId=@SurveyObjectId, ");
            //// 調査対象データ：出典O-ID(物件)
            if (!string.IsNullOrEmpty(listSurveyObjData[1]))
            {
                sqlContent.Append(" ArticleSourceId=@ArticleSourceId, ");
            }
            //// 調査対象データ：出典O-ID(描画)
            if (!string.IsNullOrEmpty(listSurveyObjData[2]))
            {
                sqlContent.Append(" DrawingSourceId=@DrawingSourceId, ");
            }
            //// 調査対象データ：トリガID
            if (!string.IsNullOrEmpty(listSurveyObjData[3]))
            {
                sqlContent.Append(" TriggerId=@TriggerId, ");
            }
            //// 調査対象データ：選別区分
            if (!string.IsNullOrEmpty(listSurveyObjData[5]))
            {
                sqlContent.Append(" SelectDivision=@SelectDivision, ");
            }
            //// 調査対象データ：重複確認用データ
            if (!string.IsNullOrEmpty(listSurveyObjData[6]))
            {
                sqlContent.Append(" DuplConfData=@DuplConfData, ");
            }
            //// 調査対象データ：備考
            if (!string.IsNullOrEmpty(listSurveyObjData[7]))
            {
                sqlContent.Append(" Remarks=@Remarks, ");
            }
            //// 調査対象データ：表示用項目１
            if (!string.IsNullOrEmpty(listSurveyObjData[8]))
            {
                sqlContent.Append(" DisplayItem1=@DisplayItem1, ");
            }
            //// 調査対象データ：表示用項目２
            if (!string.IsNullOrEmpty(listSurveyObjData[9]))
            {
                sqlContent.Append(" DisplayItem2=@DisplayItem2, ");
            }
            //// 調査対象データ：元調査対象ID
            if (!string.IsNullOrEmpty(listSurveyObjData[10]))
            {
                sqlContent.Append(" OldSurveyObjectId=@OldSurveyObjectId, ");
            }
            //// 調査対象データ：TODO出力フラグ
            if (!string.IsNullOrEmpty(listSurveyObjData[11]))
            {
                sqlContent.Append(" ToDoOutputFlag=@ToDoOutputFlag, ");
            }
            //// 調査対象データ：調査ステータス
            if (!string.IsNullOrEmpty(listSurveyObjData[12]))
            {
                sqlContent.Append(" SurveyStatus=@SurveyStatus, ");
            }
            //// 調査対象データ：次回調査可能日
            if (!string.IsNullOrEmpty(listSurveyObjData[13]))
            {
                sqlContent.Append(" NextSurveyDate=@NextSurveyDate, ");
            }
            //// 調査対象データ：引き継ぎステータス
            if (!string.IsNullOrEmpty(listSurveyObjData[14]))
            {
                sqlContent.Append(" HandoverStatus=@HandoverStatus, ");
            }
            //// 調査対象データ：調査メモ
            if (!string.IsNullOrEmpty(listSurveyObjData[15]))
            {
                sqlContent.Append(" SurveyMemo=@SurveyMemo, ");
            }
            //// 調査対象データ：最終更新日時
            sqlContent.Append(" ModifiedDate=@ModifiedDate, ");
            //// 調査対象データ：最終更新ユーザID
            sqlContent.Append(" ModifyUserId=@ModifyUserId ");
            sqlContent.Append(" WHERE SurveyObjectId=@SurveyObjectId  ");

            SqlParameter[] arrSqlParameter = new SqlParameter[17];
            string[] strSqlParameterArr = new string[]
                {
                    "@SurveyObjectId",
                    "@ArticleSourceId",
                    "@DrawingSourceId",
                    "@TriggerId",
                    "@SelectDivision",
                    "@DuplConfData",
                    "@Remarks",
                    "@DisplayItem1",
                    "@DisplayItem2",
                    "@OldSurveyObjectId",
                    "@ToDoOutputFlag",
                    "@SurveyStatus",
                    "@NextSurveyDate",
                    "@HandoverStatus",
                    "@SurveyMemo",
                    "@ModifiedDate",
                    "@ModifyUserId"
                };

            for (int i = 0; i < 17; i++)
            {
                if (i == ReflectSurveyObjConst.VALUE_INT_FIFTEEN)
                {
                    // 調査対象データ：最終更新日時
                    if (!string.IsNullOrEmpty(listSurveyObjData[ReflectSurveyObjConst.VALUE_INT_EIGHTEEN]))
                    {
                        arrSqlParameter[i] = new SqlParameter(strSqlParameterArr[i],
                                listSurveyObjData[ReflectSurveyObjConst.VALUE_INT_EIGHTEEN]);
                    }
                    else
                    {
                        arrSqlParameter[i] = new SqlParameter(strSqlParameterArr[i], DateTime.Now);
                    }
                }
                else if (i == ReflectSurveyObjConst.VALUE_INT_SIXTEEN)
                {
                    // 調査対象データ：最終更新ユーザID
                    if (!string.IsNullOrEmpty(listSurveyObjData[ReflectSurveyObjConst.VALUE_INT_NINETEEN]))
                    {
                        arrSqlParameter[i] = new SqlParameter(strSqlParameterArr[i],
                                listSurveyObjData[ReflectSurveyObjConst.VALUE_INT_NINETEEN]);
                    }
                    else
                    {
                        arrSqlParameter[i] = new SqlParameter(strSqlParameterArr[i], System.Environment.UserName);
                    }
                }
                else if (i < ReflectSurveyObjConst.VALUE_INT_FOUR)
                {
                    if (!string.IsNullOrEmpty(listSurveyObjData[i]))
                    {
                        arrSqlParameter[i] = new SqlParameter(strSqlParameterArr[i],
                                listSurveyObjData[i]);
                    }
                    else
                    {
                        arrSqlParameter[i] = new SqlParameter(strSqlParameterArr[i],
                            ReflectSurveyObjConst.BLANK_VALUE);
                    }
                }
                else
                {
                    if (!string.IsNullOrEmpty(listSurveyObjData[i + 1]))
                    {
                        arrSqlParameter[i] = new SqlParameter(strSqlParameterArr[i],
                                listSurveyObjData[i + 1]);
                    }
                    else
                    {
                        arrSqlParameter[i] = new SqlParameter(strSqlParameterArr[i],
                            ReflectSurveyObjConst.BLANK_VALUE);
                    }
                }
            }

            intRet = dpbHandler.ExecuteNonQuery(sqlContent.ToString(), arrSqlParameter);

            return intRet;
        }

        /// <summary>
        /// トリガIDにより、トリガ種別マスタに出典カテゴリの取得
        /// </summary>
        /// <param name="strTriggerId">トリガID</param>
        /// <param name="dpbHandler">DB接続ハンドル</param>
        /// <returns>出典カテゴリ</returns>
        private static DataTable SelSourceCategory(string strTriggerId,
            DBDataProviderBase dpbHandler)
        {
            StringBuilder sqlContent = new StringBuilder();

            sqlContent.Append(" SELECT");
            sqlContent.Append(" TRIGGERTYPE.SourceCategory SourceCategory");
            sqlContent.Append(" From");
            sqlContent.Append(" MT_TRIGGERINFO TRIGGERINFO WITH(NOLOCK)");
            sqlContent.Append(" LEFT OUTER JOIN MM_TRIGGERTYPE TRIGGERTYPE WITH(NOLOCK)");
            sqlContent.Append(" ON TRIGGERINFO.TriggerTypeId = TRIGGERTYPE.TriggerTypeId");
            sqlContent.Append(" WHERE");
            sqlContent.Append(" TRIGGERINFO.TriggerId = @TriggerId");

            SqlParameter paraTriggerId =
                new SqlParameter("@TriggerId", strTriggerId);

            DataTable table = dpbHandler.ExecuteDataTable(sqlContent.ToString(),
            new SqlParameter[] { paraTriggerId });

            return table;
        }
    }
}
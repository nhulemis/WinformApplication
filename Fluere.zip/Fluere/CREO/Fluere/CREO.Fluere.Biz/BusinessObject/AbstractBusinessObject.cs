﻿using System;
using System.Collections.Generic;
using System.Linq;
using CREO.DS;
using CREO.DS.LocalTransaction;
using CREO.Fluere.Biz.BusinessObject.Data;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Message;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 基盤業務クラス
    /// </summary>
    public abstract class AbstractBusinessObject
    {
        #region ログマネージャーのインスタンス、メッセージマネージャーのインスタンス
        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        protected LogManager _logMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);

        /// <summary>
        /// メッセージマネージャーインスタンス
        /// </summary>
        protected MessageManager _msgMgr = MessageManager.GetMessageManager(UF_Fluere_MsgId.MODULE_NUMBER);
        #endregion

        #region データサービス設定
        /// <summary>
        /// データサービス設定
        /// </summary>
        protected DataService _dataService = null;

        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// ディフォルトの値設定について、バルクを利用しなく、キャッシュを利用すること
        /// </summary>
        /// <param name="db">処理用のDB</param>
        public AbstractBusinessObject(string db)
        {
            // ログ初期化
            LogUtility.Init();

            // 指定したDBに対してのデータサービスの取得
            this._dataService = DataServiceManager.GetDataServcie(db);
        }

        /// <summary>
        /// コンストラクタ
        /// ディフォルトの値設定について、バルクを利用しなく、キャッシュを利用すること
        /// </summary>
        /// <param name="data">DB処理用関連情報</param>
        public AbstractBusinessObject(SystemServiceData data)
        {
            // ログ初期化
            LogUtility.Init();

            // 指定したDBに対してのデータサービスの取得
            this._dataService = DataServiceManager.GetDataServcie(data);
        }
        #endregion

        /// <summary>
        /// 更新変更有無のフラグ
        /// </summary>
        public bool IsDataChanged { get; private set; }

        #region トランザクションに該当するロジック処理
        /// <summary>
        /// 実施するかどうかを判断
        /// </summary>
        /// <returns>bool</returns>
        public bool Execute()
        {
            LogUtility logUtility = null;

            // データ変更有りフラグの初期化
            this.IsDataChanged = false;

            try
            {
                // トランザクションの開始
                this._dataService.BeginTransaction();

                // 指定したDBに紐付ける業務ロジック処理
                bool replaceFlag = DoExecute();

                logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                    "【dataService.Commit】",
                    LogUtility.LogModel.DebugModel);

                // トランザクションの終了 
                var changedResults = this.DoCommit();

                logUtility.WriteNormalEnd();
                logUtility = null;

                logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                    "【dataService.Save】",
                    LogUtility.LogModel.DebugModel);

                // ローカルトキャッシュの変更内容をデータソースに保存する 
                replaceFlag = this._dataService.Save();

                logUtility.WriteNormalEnd();
                logUtility = null;

                // 新規、更新、削除件数の集計
                int newCount = 0, modifyCount = 0, deleteCount = 0;

                if (changedResults != null)
                {
                    var changeItemsQuery = from item in changedResults
                                           group item by item.TransactionType
                                               into grouping
                                               select new
                                               {
                                                   grouping.Key,
                                                   ItemCount = grouping.Count()
                                               };

                    foreach (var changeItems in changeItemsQuery)
                    {
                        switch (changeItems.Key)
                        {
                            case DS.LocalTransaction.LocalTransactionType.New:
                                newCount = changeItems.ItemCount;
                                break;
                            case DS.LocalTransaction.LocalTransactionType.Modify:
                                modifyCount = changeItems.ItemCount;
                                break;
                            case DS.LocalTransaction.LocalTransactionType.Delete:
                                deleteCount = changeItems.ItemCount;
                                break;
                            default:
                                break;
                        }
                    }
                }

                if (newCount > 0 || modifyCount > 0 || deleteCount > 0)
                {
                    this.IsDataChanged = true;

                    LogUtility.WriteDataCount("【トランザクション】確認用",
                        LogUtility.OperationType.New,
                        newCount,
                        LogUtility.LogModel.DebugModel);
                    LogUtility.WriteDataCount("【トランザクション】確認用",
                        LogUtility.OperationType.Update,
                        modifyCount,
                        LogUtility.LogModel.DebugModel);
                    LogUtility.WriteDataCount("【トランザクション】確認用",
                        LogUtility.OperationType.Delete,
                        deleteCount,
                        LogUtility.LogModel.DebugModel);
                }

                this.Dispose();

                return replaceFlag;
            }
            catch (BusinessLogicException busExp)
            {
                LogUtility.WriteDebug(busExp, string.Empty);
                if (logUtility != null)
                {
                    logUtility.WriteErrorEnd();
                }

                // トランザクションのロールバック
                this._dataService.Rollback();

                throw busExp;
            }
            catch (FrameworkException fwExp)
            {
                LogUtility.WriteDebug(fwExp, string.Empty);
                if (logUtility != null)
                {
                    logUtility.WriteErrorEnd();
                }

                // トランザクションのロールバック
                this._dataService.Rollback();

                throw fwExp;
            }
            catch (Exception ex)
            {
                LogUtility.WriteDebug(ex, string.Empty);
                if (logUtility != null)
                {
                    logUtility.WriteErrorEnd();
                }

                // トランザクションのロールバック
                this._dataService.Rollback();

                throw ex;
            }
            finally
            {
                try
                {
                    this._dataService.Dispose();
                }
                finally
                {
                    this._dataService = null;
                }
            }
        }

        /// <summary>
        /// 実施するかどうかを判断
        /// </summary>
        /// <returns>bool</returns>
        protected abstract bool DoExecute();

        /// <summary>
        /// コミットを行う
        /// </summary>
        /// <returns>コミット結果</returns>
        protected virtual List<TrackingItem> DoCommit()
        {
            return this._dataService.CommitWithResult();
        }

        #endregion

        #region バルクとキャッシュ設定
        /// <summary>
        /// バルクフラグ設定
        /// </summary>
        /// <param name="flag">true：利用する false：利用しない</param>
        protected void SetUseBulk(bool flag)
        {
        }

        /// <summary>
        /// キャッシュ利用の設定
        /// </summary>
        /// <param name="flag">true：利用する false：利用しない</param>
        protected void SetUseCache(bool flag)
        {
        }
        #endregion

        #region メモリクリア
        /// <summary>
        /// メモリクリア
        /// </summary>
        protected void Dispose()
        {
        }
        #endregion
    }
}

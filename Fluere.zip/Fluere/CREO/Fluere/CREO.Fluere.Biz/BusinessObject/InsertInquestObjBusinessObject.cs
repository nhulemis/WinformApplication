﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Reflection;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;
using CREO.Fluere.Common.Configuration;
using CREO.FW.ExceptionHandling;
using CREO.Materia;
using CREO.Materia.API;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 下記の機能を１つトランザクションに入れると管理
    /// ・調査対象IDの発番
    /// ・調査対象データの新規
    /// ・バッチ設定ファイルに調査対象IDを埋め込み
    /// </summary>
    [Obsolete("このクラスは廃止される予定です。代わりに'AppendInquestObjectDataBusinessObject' を使用してください。", false)]
    public class InsertInquestObjBusinessObject : AbstractInquestObjBusinessObject
    {
        #region クラス属性定義（外部より受入）
        /// <summary>
        /// バッチ設定ファイル管理インスタンス
        /// </summary>
        private IConfigurationManager _configurationManager = null;

        /// <summary>
        /// 調査対象データ
        /// </summary>
        private DataTable _inquestObjectDT = null;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="dt">更新用の調査対象データ</param>
        /// <param name="configurationManager">バッチ設定管理インスタンス</param>
        public InsertInquestObjBusinessObject(
            DataTable dt,
            IConfigurationManager configurationManager)
        {
            _inquestObjectDT = dt;
            _configurationManager = configurationManager;
        }
        #endregion

        #region 主要処理のインタフェイス
        /// <summary>
        /// 主な実行
        /// </summary>
        protected override void DoExecute()
        {
            string inquestObjID = CreateInquestObjectID();

            InsertInquestObject(inquestObjID);

            UpdateBatchDefFile(inquestObjID);
        }
        #endregion

        #region 調査対象発番処理
        /// <summary>
        /// 調査対象発番処理
        /// </summary>
        /// <returns>新規された調査対象ID</returns>
        private string CreateInquestObjectID()
        {
            // 調査対象IDの発番数
            int inquestObjIdCount = 1;

            // 調査対象IDの採番
            List<string> inquestObjIDList = GetSurveyObjId.GetSurveyObjectId(
                GetSurveyObjIdConst.GET_NUM_DIVION_02, inquestObjIdCount, _dBPMateria);

            // inquestObjIDList[0]の値が「0」以外の場合は、エラーとする
            if (inquestObjIDList == null || inquestObjIDList.Count < 1 || inquestObjIDList[0] != "0")
            {
                // 調査対象ID発行APIの戻り値が正常以外の場合
                string msgId = UF_Fluere_MsgId.MSGID_UF20001003;

                throw new BusinessLogicException(msgId, new string[] { });
            }

            // 調査対象発番IDの取得
            return inquestObjIDList[1];
        }
        #endregion

        #region 調査対象データの新規
        /// <summary>
        /// 調査対象データを新規すること
        /// </summary>
        /// <param name="inquestObjID">調査対象ID</param>
        private void InsertInquestObject(string inquestObjID)
        {
            // 新規の場合は、調査対象IDを設定                   
            // 要調査対象データの調査対象IDを順次に採番された調査対象IDに設定する
            DataRow dr = this._inquestObjectDT.Rows[0];
            string currInquestObjID = Convert.ToUInt64(inquestObjID).ToString();
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = currInquestObjID;
                    
            // 調査対象反映APIの呼び出し
            int result = ReflectSurveyObjBatch.UpdateSurveyObj(this._inquestObjectDT, _dBPMateria);

            // 戻り値が0以外の場合、異常をスロー
            if (result != RESULT_SUCCEED)
            {
                string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                throw new BusinessLogicException(msgId, new string[] { currInquestObjID });
            }            
        }
        #endregion

        #region バッチ設定ファイルの更新
        /// <summary>
        /// バッチ設定ファイルに、調査対象IDを埋め込むこと
        /// </summary>
        /// <param name="inquestObjID">調査対象ID</param>
        private void UpdateBatchDefFile(string inquestObjID)
        {
            try
            {
                // バッチ設定情報
                object batchDefObj = _configurationManager.Configuration;

                // 属性の取得
                MemberInfo[] mems = batchDefObj.GetType().FindMembers(
                    MemberTypes.Property, 
                    BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance,
                    null, 
                    null);

                bool inquestObjIdFound = false;

                // 調査対象ID属性の確定
                foreach (MemberInfo mem in mems) 
                {
                    if (mem.Name == "InquestObjectId")
                    {
                        switch (mem.MemberType)
                        {
                            case MemberTypes.Field:
                                ((FieldInfo)mem).SetValue(batchDefObj, inquestObjID);
                                break;
                            case MemberTypes.Property:
                                ((PropertyInfo)mem).SetValue(batchDefObj, inquestObjID, null);
                                break;
                            default:
                                throw new ArgumentException("MemberInfo must be if type FieldInfo or PropertyInfo", "member");
                        }

                        inquestObjIdFound = true;
                        break;                        
                    }
                }

                if (!inquestObjIdFound)
                {
                    string msg = "バッチ設定ファイルに、調査対象IDを「InquestObjectId」に命名してください。";
                    throw new BusinessLogicException(msg);
                }

                // バッチ設定ファイルへ更新
                _configurationManager.Save();
            }
            catch (Exception e)
            {
                string msg = "{0}に調査対象ID{1}を追加出来ません。";
                msg = string.Format(msg, new string[] { _configurationManager.FullName, inquestObjID });
                _logMgr.WriteError(msg);

                throw e;
            }
        }
        #endregion
    }
}

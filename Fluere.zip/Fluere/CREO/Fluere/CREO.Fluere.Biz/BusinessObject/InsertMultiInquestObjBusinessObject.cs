﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using CREO.DataModel;
using CREO.DataModel.Extension.Common;
using CREO.DataModel.Extension.Enum;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators;
using CREO.Fluere.Biz.Query;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;
using CREO.FW.TMIGeometry;
using CREO.Materia;
using CREO.Materia.API;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 調査対象データ処理(複数な調査対象ID)
    /// </summary>
    public class InsertMultiInquestObjBusinessObject : AbstractInquestObjBusinessObject, IDisposable
    {
        /// <summary>
        /// データソースID
        /// </summary>
        private string dataSourceId;

        /// <summary>
        /// 調査対象の新規テーブル
        /// </summary>
        private DataTable surveyObj;

        /// <summary>
        /// 施設物件拡張データ
        /// </summary>
        private List<SPOIFacilityMEx> sPOIFacilityMEx;

        /// <summary>
        /// 描画文字拡張データ
        /// </summary>
        private List<SSignTxtViewMEx> sViewTxtMEx;

        /// <summary>
        /// グルーピングタグメンテToDoリストファイル出力フォルダのパス
        /// </summary>
        private string groupingTagToDoFolderPath;

        /// <summary>
        /// 市区町村による住所名称
        /// </summary>
        private List<LocalAdrName> resultAdrName;

        /// <summary>
        /// グループタイプが同一物件管理（○座標一致）のタウン物件
        /// </summary>
        private List<STwnPOI> resultSTwnPOIOfType3;

        /// <summary>
        /// グループタイプが同一物件管理（○座標一致）以外のタウン物件
        /// </summary>
        private List<STwnPOI> resultSTwnPOIOfOther;

        /// <summary>
        /// 削除したタウン物件
        /// </summary>
        private STwnPOI deletedSTwnPOI;

        /// <summary>
        /// 処理中の市区町村ファイル名称
        /// </summary>
        private string adminFileName;

        /// <summary>
        /// データサービス設定
        /// </summary>
        protected DataService dataService = null;

        #region 初期化
        /// <summary>
        /// 初期化(modify)
        /// </summary>
        /// <param name="strId">データソースID</param>
        /// <param name="dtSurveyObj">調査対象の新規テーブル</param>
        /// <param name="lstSPOIFacilityMEx">施設物件拡張データ</param>
        /// <param name="resultSViewTxtMEx">描画文字拡張データ</param>
        /// <param name="strToDoFolderPath">グルーピングタグメンテToDoリストファイル出力フォルダのパス</param>
        /// <param name="lstAdrName">市区町村による住所名称</param>
        /// <param name="lstSTwnPOIOfType3">グループタイプが同一物件管理（○座標一致）のタウン物件</param>
        /// <param name="lstSTwnPOIOfOther">グループタイプが同一物件管理（○座標一致）以外のタウン物件</param>
        /// <param name="delSTwnPOI">削除したタウン物件</param>
        /// <param name="strAdminFileName">市区町村ファイル名</param>
        public InsertMultiInquestObjBusinessObject(
            string strId,
            DataTable dtSurveyObj,
            List<SPOIFacilityMEx> lstSPOIFacilityMEx,
            List<SSignTxtViewMEx> resultSViewTxtMEx,
            string strToDoFolderPath,
            List<LocalAdrName> lstAdrName,
            List<STwnPOI> lstSTwnPOIOfType3,
            List<STwnPOI> lstSTwnPOIOfOther,
            STwnPOI delSTwnPOI,
            string strAdminFileName)
        {
            // データソースID
            dataSourceId = strId;

            // 調査対象の新規テーブル
            surveyObj = dtSurveyObj;

            // 施設物件拡張データ
            sPOIFacilityMEx = lstSPOIFacilityMEx;

            // 描画文字拡張データ
            sViewTxtMEx = resultSViewTxtMEx;

            // グルーピングタグメンテToDoリストファイル出力フォルダのパス
            groupingTagToDoFolderPath = strToDoFolderPath;

            // 市区町村による住所名称
            resultAdrName = lstAdrName;

            // グループタイプが同一物件管理（○座標一致）のタウン物件
            resultSTwnPOIOfType3 = lstSTwnPOIOfType3;

            // グループタイプが同一物件管理（○座標一致）以外のタウン物件
            resultSTwnPOIOfOther = lstSTwnPOIOfOther;

            // 削除したタウン物件
            deletedSTwnPOI = delSTwnPOI;

            // 市区町村ファイル名称
            adminFileName = strAdminFileName;

            // 指定したDBに対してのデータサービスの取得
            dataService = DataServiceManager.GetDataServcie(strId);
        }
        #endregion

        #region Dispose
        /// <summary>
        /// Disposeメソッド
        /// </summary>
        public void Dispose()
        {
            if (dataService != null)
            {
                dataService.Dispose();
                dataService = null;
            }
        }
        #endregion Dispose

        /// <summary>
        /// 主な実行
        /// </summary>
        protected override void DoExecute()
        {
            // 調査対象発番処理
            List<string> lstInquestObjID = CreateMultiInquestObjectID();

            // ToDoリストファイルの出力
            OutPutTodoFiles(lstInquestObjID, sPOIFacilityMEx, sViewTxtMEx);

            // 調査対象データの追加
            InsertMultiInquestObject(lstInquestObjID);
        }

        #region 調査対象発番処理(modify)
        /// <summary>
        /// 調査対象発番処理
        /// </summary>
        /// <returns>新規された調査対象ID</returns>
        private List<string> CreateMultiInquestObjectID()
        {
            int inquestObjIdCount = 0;

            // グループタイプが同一物件管理（○座標一致）の場合
            if (resultSTwnPOIOfType3.Count > 0)
            {
                // 調査対象IDの発番数
                inquestObjIdCount = sViewTxtMEx.Count();
            }

            if (resultSTwnPOIOfOther.Count > 0)
            {
                // 調査対象IDの発番数
                inquestObjIdCount = resultSTwnPOIOfOther.Count() * sViewTxtMEx.Count();
            }

            inquestObjIdCount = sPOIFacilityMEx.Count() + inquestObjIdCount;

            // 調査対象IDの採番
            List<string> inquestObjIDList = GetSurveyObjId.GetSurveyObjectId(
                GetSurveyObjIdConst.GET_NUM_DIVION_02, inquestObjIdCount, _dBPMateria);

            // inquestObjIDList[0]の値が「0」以外の場合は、エラーとする
            if (inquestObjIDList == null || inquestObjIDList.Count < 1 || inquestObjIDList[0] != "0")
            {
                // 調査対象ID発行APIの戻り値が正常以外の場合
                string msgId = UF_Fluere_MsgId.MSGID_UF20001003;

                throw new BusinessLogicException(msgId);
            }

            // 調査対象発番IDの取得
            return inquestObjIDList;
        }
        #endregion

        #region グルーピングタグToDoファイルの出力
        /// <summary>
        /// グルーピングタグToDoファイルの出力
        /// </summary>
        /// <param name="lstInquestObjID">調査対象IDリスト</param>
        /// <param name="lstSPOIFacilityMEx">施設物件拡張データ</param>
        /// <param name="lstSViewTxtMEx">描画文字拡張データ</param>
        private void OutPutTodoFiles(
            List<string> lstInquestObjID,
            List<SPOIFacilityMEx> lstSPOIFacilityMEx,
            List<SSignTxtViewMEx> lstSViewTxtMEx)
        {
            int i = 0;

            // グルーピングタグメンテToDoリストファイル出力フォルダのパス
            string strOutPutPath = groupingTagToDoFolderPath;

            if (Directory.Exists(strOutPutPath) == false)
            {
                Directory.CreateDirectory(strOutPutPath);
            }                       

            // グルーピングタグメンテ（施設物件拡張）_yyyyMMddHHmmss.duco
            string strFileNameOfSPOIFacilityMEx = "グルーピングタグメンテ（施設物件拡張）" + "_" + adminFileName + ".duco";

            // 施設物件拡張のToDoリストファイルの出力
            if (lstSPOIFacilityMEx.Count > 0)
            {
                OutPutTodoFileOfSPOIFacilityMEx(lstInquestObjID, lstSPOIFacilityMEx, strOutPutPath, strFileNameOfSPOIFacilityMEx, ref i);
            }                     

            // グルーピングタグメンテ（描画文字）_yyyyMMddHHmmss.duco
            string strFileNameOfSview = "グルーピングタグメンテ（描画文字）" + "_" + adminFileName + ".duco";

            // 描画文字拡張データをTodoリストファイルを出力する
            if (lstSViewTxtMEx.Count > 0)
            {
                OutPutTodoFileOfSViewTxtMEx(lstInquestObjID, lstSViewTxtMEx, strOutPutPath, strFileNameOfSview, i);
            }
        }
        #endregion

        #region 施設物件拡張のToDoリストファイルの出力
        /// <summary>
        /// 施設物件拡張のToDoリストファイルの出力
        /// </summary>
        /// <param name="lstInquestObjID">調査対象ID</param>
        /// <param name="lstSPOIFacilityMEx">施設物件拡張データ</param>
        /// <param name="strOutPutPath">ToDoリストファイルの出力パス</param>
        /// <param name="strFileName">ToDoリストファイル名</param>
        /// <param name="i">調査対象リストのインデックス</param>
        private void OutPutTodoFileOfSPOIFacilityMEx(
            List<string> lstInquestObjID,
            List<SPOIFacilityMEx> lstSPOIFacilityMEx,
            string strOutPutPath,
            string strFileName,
            ref int i)
        {
            // ファイル生成のフラグ
            bool blnFlag = false;

            // 処理用のファイル名
            string strFileNew = string.Empty;

            // 初期化
            CommToDoWriteWrapper commToDoWriteWrapper = CommToDoWriteWrapper.GetGlobalInstance();

            try
            {
                // 出力ファイルが存在するかどうかチェック
                blnFlag = TodoListFileManager.CheckTodoFileExist(strOutPutPath, strFileName, ref strFileNew, commToDoWriteWrapper, false);

                if (blnFlag)
                {
                    List<CommToDoDataWrapper> lstTodoListData03 = new List<CommToDoDataWrapper>();

                    // 施設物件拡張データ
                    foreach (var item in lstSPOIFacilityMEx)
                    {
                        CommToDoDataWrapper toDoListPattern03Data = new CommToDoDataWrapper();

                        // 確認
                        toDoListPattern03Data.WorkStatus = "0";

                        // 調査対象ID
                        toDoListPattern03Data.SurveyObjectId = (ulong.Parse(lstInquestObjID[1].ToString()) + (ulong)i).ToString();

                        // 経度
                        toDoListPattern03Data.Latitude = string.Empty;

                        // 緯度
                        toDoListPattern03Data.Longitude = string.Empty;

                        // データソースID
                        toDoListPattern03Data.QueryObjectDB = dataSourceId;

                        // OID
                        toDoListPattern03Data.OID = item.OID;

                        // 住所名称を取得する
                        TAdrName adrName = item.AdrName;

                        string[] nameLevel = new string[] { string.Empty, string.Empty, string.Empty, string.Empty };

                        if (adrName != null)
                        {
                            // 住所名称モデルで各名称を取得する
                            nameLevel = GetNameOfAdrName(adrName);
                        }

                        // 都道府県名
                        toDoListPattern03Data.SetFieldByDefaultName(1, nameLevel[0] ?? string.Empty);

                        // 市区町村名
                        toDoListPattern03Data.SetFieldByDefaultName(2, nameLevel[1] ?? string.Empty);

                        // 大字・通称名
                        toDoListPattern03Data.SetFieldByDefaultName(3, nameLevel[2] ?? string.Empty);

                        // 字・丁目名
                        toDoListPattern03Data.SetFieldByDefaultName(4, nameLevel[3] ?? string.Empty);

                        // 方書
                        if (item.AdrKanjiName == null)
                        {
                            toDoListPattern03Data.SetFieldByDefaultName(5, string.Empty);
                        }
                        else
                        {
                            toDoListPattern03Data.SetFieldByDefaultName(5, item.AdrKanjiName[CommonConstants.MULTLANG_JA_JAPAN].Name);
                        }

                        // 正式名称
                        if (item.FormalNameMultiLang == null)
                        {
                            toDoListPattern03Data.SetFieldByDefaultName(6, string.Empty);
                        }
                        else
                        {
                            toDoListPattern03Data.SetFieldByDefaultName(6, item.FormalNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name);
                        }

                        // 削除タウン物件漢字名称
                        if (deletedSTwnPOI.TwnMultiLang == null)
                        {
                            toDoListPattern03Data.SetFieldByDefaultName(7, string.Empty);
                        }
                        else
                        {
                            toDoListPattern03Data.SetFieldByDefaultName(7, deletedSTwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name);
                        }

                        // 削除タウン物件住所名称（方書含む）
                        toDoListPattern03Data.SetFieldByDefaultName(8, GetSTwnPOIAdrNameStr(deletedSTwnPOI));

                        lstTodoListData03.Add(toDoListPattern03Data);

                        i = i + 1;
                    }

                    // グルーピングタグメンテ（施設物件拡張）ToDoリストファイルを書き込む
                    commToDoWriteWrapper.WriteToDoFile(strOutPutPath, strFileName, CommToDoPattern.XX003, lstTodoListData03);
                }
                else
                {
                    XDocument xdoc = XDocument.Load(strFileNew);

                    XElement detailList = xdoc.Element("Data").Element("DataList");

                    // DetailList属性の追加
                    foreach (var detail in lstSPOIFacilityMEx)
                    {
                        XElement dataDetail = new XElement("DataDetails");

                        // 確認
                        dataDetail.Add(new XAttribute("WorkStatus", "0"));

                        // 調査対象ID
                        dataDetail.Add(new XAttribute("SurveyObjectId", (ulong.Parse(lstInquestObjID[1].ToString()) + (ulong)i).ToString()));

                        // 経度
                        dataDetail.Add(new XAttribute("Longitude", string.Empty));

                        // 緯度
                        dataDetail.Add(new XAttribute("Latitude", string.Empty));

                        // 検索対象DB
                        dataDetail.Add(new XAttribute("QueryObjectDB", dataSourceId));

                        // OID
                        dataDetail.Add(new XAttribute("OID", CommToDoDataWrapper.ConvertToOIDString((ulong)detail.OID)));

                        // 住所名称を取得する
                        TAdrName adrName = detail.AdrName;

                        string[] nameLevel = new string[] { string.Empty, string.Empty, string.Empty, string.Empty };

                        if (adrName != null)
                        {
                            // 住所名称モデルで各名称を取得する
                            nameLevel = GetNameOfAdrName(adrName);
                        }

                        // 都道府県名
                        dataDetail.Add(new XAttribute("Column1", nameLevel[0] ?? string.Empty));

                        // 市区町村名
                        dataDetail.Add(new XAttribute("Column2", nameLevel[1] ?? string.Empty));

                        // 大字・通称名
                        dataDetail.Add(new XAttribute("Column3", nameLevel[2] ?? string.Empty));
 
                        // 字・丁目名
                        dataDetail.Add(new XAttribute("Column4", nameLevel[3] ?? string.Empty));

                        // 方書
                        if (detail.AdrKanjiName == null)
                        {
                            dataDetail.Add(new XAttribute("Column5", string.Empty));
                        }
                        else
                        {
                            dataDetail.Add(new XAttribute("Column5", detail.AdrKanjiName[CommonConstants.MULTLANG_JA_JAPAN].Name));
                        }

                        // 正式名称
                        if (detail.FormalNameMultiLang == null)
                        {
                            dataDetail.Add(new XAttribute("Column6", string.Empty));
                        }
                        else
                        {
                            dataDetail.Add(new XAttribute("Column6", detail.FormalNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name));
                        }

                        // 削除タウン物件漢字名称
                        if (deletedSTwnPOI.TwnMultiLang == null)
                        {
                            dataDetail.Add(new XAttribute("Column7", string.Empty));
                        }
                        else
                        {
                            dataDetail.Add(new XAttribute("Column7", deletedSTwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name));
                        }

                        // 削除タウン物件住所名称（方書含む）
                        dataDetail.Add(new XAttribute("Column8", this.GetSTwnPOIAdrNameStr(deletedSTwnPOI)));
                        
                        detailList.Add(dataDetail);

                        i = i + 1;
                    }

                    xdoc.Save(strFileNew);
                }
            }
            catch (Exception ex)
            {
                // グルーピングタグメンテ（施設物件拡張）ToDoリストファイル出力に失敗した場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40001033;

                throw new BusinessLogicException(msgId, new string[] { strFileNew }, ex);
            }
        }
        #endregion

        #region 描画文字拡張のTodoリストファイルの出力(modify)
        /// <summary>
        /// 描画文字拡張のTodoリストファイルの出力
        /// </summary>
        /// <param name="lstInquestObjID">調査対象ID</param>
        /// <param name="lstSViewTxtMEx">描画文字拡張データ</param>
        /// <param name="strOutPutPath">Todoリストファイルの出力パス</param>
        /// <param name="strFileName">Todoリストファイル名</param>
        /// <param name="i">調査対象リストのインデックス</param>
        private void OutPutTodoFileOfSViewTxtMEx(
            List<string> lstInquestObjID, List<SSignTxtViewMEx> lstSViewTxtMEx, string strOutPutPath, string strFileName, int i)
        {
            // ファイル生成のフラグ
            bool blnFlag = false;

            // 処理用のファイル名
            string strFileNew = string.Empty;

            // 初期化
            CommToDoWriteWrapper commToDoWriteWrapper = CommToDoWriteWrapper.GetGlobalInstance();

            try
            {
                // 出力ファイルが存在するかどうかチェック
                blnFlag = TodoListFileManager.CheckTodoFileExist(strOutPutPath, strFileName, ref strFileNew, commToDoWriteWrapper, false);

                if (blnFlag)
                {
                    List<CommToDoDataWrapper> lstTodoListData04 = new List<CommToDoDataWrapper>();

                    // グループタイプが同一物件管理（○座標一致）の場合
                    if (resultSTwnPOIOfType3.Count > 0)
                    {
                        // 描画文字拡張データ
                        foreach (var item in lstSViewTxtMEx)
                        {
                            // 描画文字拡張データの作成
                            CreateSViewTxtMExData(lstInquestObjID, i, lstTodoListData04, item, resultSTwnPOIOfType3[0], true);

                            i = i + 1;
                        }
                    }

                    if (resultSTwnPOIOfOther.Count > 0)
                    {
                        // グループタイプが同一物件管理（○座標一致）以外の場合

                        // 描画文字拡張データ
                        foreach (var item in lstSViewTxtMEx)
                        {
                            foreach (var itemSTwnPOI in resultSTwnPOIOfOther)
                            {
                                // 描画文字拡張データの作成
                                CreateSViewTxtMExData(lstInquestObjID, i, lstTodoListData04, item, itemSTwnPOI, false);

                                i = i + 1;
                            }
                        }
                    }

                    // グルーピングタグメンテ（描画文字）ToDoリストファイルを書き込む
                    commToDoWriteWrapper.WriteToDoFile(strOutPutPath, strFileName, CommToDoPattern.XX004, lstTodoListData04);
                }
                else
                {
                    XDocument xdoc = XDocument.Load(strFileNew);

                    XElement detailList = xdoc.Element("Data").Element("DataList");

                    // グループタイプが同一物件管理（○座標一致）の場合
                    if (resultSTwnPOIOfType3.Count > 0)
                    {
                        // 描画文字拡張データ
                        foreach (var item in lstSViewTxtMEx)
                        {
                            XElement dataDetail = new XElement("DataDetails");

                            // 描画文字拡張データの作成
                            CreateSViewTxtMExDataByAppend(lstInquestObjID, i, ref dataDetail, item, resultSTwnPOIOfType3[0], true);

                            detailList.Add(dataDetail);

                            i = i + 1;
                        }
                    }

                    if (resultSTwnPOIOfOther.Count > 0)
                    {
                        // グループタイプが同一物件管理（○座標一致）以外の場合

                        // 描画文字拡張データ
                        foreach (var item in lstSViewTxtMEx)
                        {
                            foreach (var itemSTwnPOI in resultSTwnPOIOfOther)
                            {
                                XElement dataDetail = new XElement("DataDetails");

                                // 描画文字拡張データの作成
                                CreateSViewTxtMExDataByAppend(lstInquestObjID, i, ref dataDetail, item, itemSTwnPOI, false);

                                detailList.Add(dataDetail);

                                i = i + 1;
                            }
                        }
                    }

                    xdoc.Save(strFileNew);
                }
            }
            catch (Exception ex)
            {
                // グルーピングタグメンテ（描画文字）ToDoリストファイル出力に失敗した場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40001033;

                throw new BusinessLogicException(msgId, new string[] { strFileNew }, ex);
            }
        }
        #endregion

        #region 描画文字拡張データの作成(modify)
        /// <summary>
        /// 描画文字拡張データの作成
        /// </summary>
        /// <param name="lstInquestObjID">調査対象ID</param>
        /// <param name="i">インデックス</param>
        /// <param name="lstTodoListData04">描画文字拡張のTodoリストデータ</param>
        /// <param name="sViewTxtMEx">処理用の描画文字拡張データ</param>
        /// <param name="sTwnPOI">処理用のタウン物件</param>
        /// <param name="blFlag">true:グループタイプが3の場合 false:以外の場合</param>
        private void CreateSViewTxtMExData(
            List<string> lstInquestObjID, int i, List<CommToDoDataWrapper> lstTodoListData04, SSignTxtViewMEx sViewTxtMEx, STwnPOI sTwnPOI, bool blFlag)
        {
            CommToDoDataWrapper toDoListPattern04Data = new CommToDoDataWrapper();

            // 確認
            toDoListPattern04Data.WorkStatus = "0";

            // 調査対象ID
            toDoListPattern04Data.SurveyObjectId = (ulong.Parse(lstInquestObjID[1].ToString()) + (ulong)i).ToString();

            // 経度
            toDoListPattern04Data.Latitude = string.Empty;

            // 緯度
            toDoListPattern04Data.Longitude = string.Empty;

            // データソースID
            toDoListPattern04Data.QueryObjectDB = dataSourceId;

            // OID
            toDoListPattern04Data.OID = sViewTxtMEx.OID;

            // 表示名称
            if (sViewTxtMEx.DispNameMultiLang == null || sViewTxtMEx.DispNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN] == null)
            {
                toDoListPattern04Data.SetFieldByDefaultName(1, string.Empty);
            }
            else
            {
                toDoListPattern04Data.SetFieldByDefaultName(1, sViewTxtMEx.DispNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name);
            }

            // 文字種別の種別コードと種別名称を"："で連結
            if (sViewTxtMEx.TypTxt == null)
            {
                toDoListPattern04Data.SetFieldByDefaultName(2, string.Empty);
            }
            else
            {
                toDoListPattern04Data.SetFieldByDefaultName(2, sViewTxtMEx.TypTxt.TypCode.ToString() + ":" + sViewTxtMEx.TypTxt.TypName.ToString());
            }

            // メッシュコード
            string strMeshCode = GetMeshCodeBySSignTxtViewGeometry(sViewTxtMEx);

            // ２次メッシュコード
            toDoListPattern04Data.SetFieldByDefaultName(3, strMeshCode);

            // 漢字名称
            if (sTwnPOI.TwnMultiLang == null)
            {
                toDoListPattern04Data.SetFieldByDefaultName(4, string.Empty);
            }
            else
            {
                toDoListPattern04Data.SetFieldByDefaultName(4, sTwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name);
            }

            // 住所名称（方書含む）
            toDoListPattern04Data.SetFieldByDefaultName(5,  GetSTwnPOIAdrNameStr(sTwnPOI));

            // グループタイプが同一物件管理（○座標一致）の場合
            if (blFlag)
            {
                // 主掲載フラグが「1」のものを優先する
                var sortSTwnPOI = from item in resultSTwnPOIOfType3
                                  orderby item.MainEntryFlg descending
                                  select item;

                // 電話文字列
                string strTelList = string.Empty;

                // インデックス
                int j = 0;

                foreach (var item in sortSTwnPOI)
                {
                    string strSTwnPOI = item.Tel ?? string.Empty;

                    // 異なる電話番号を最大5までカンマ区切りで出力する
                    if (j < 5)
                    {
                        if (strTelList.Contains(strSTwnPOI) == false)
                        {
                            j = j + 1;

                            if (j == 1)
                            {
                                strTelList = strTelList + strSTwnPOI;
                            }
                            else
                            {
                                strTelList = strTelList + "," + strSTwnPOI;
                            }
                        }
                    }
                    else
                    {
                        break;
                    }
                }

                // 電話番号
                toDoListPattern04Data.SetFieldByDefaultName(6, strTelList);
            }
            else
            {
                // 電話番号
                toDoListPattern04Data.SetFieldByDefaultName(6, sTwnPOI.Tel ?? string.Empty);
            }

            lstTodoListData04.Add(toDoListPattern04Data);
        }

        #endregion

        /// <summary>
        /// 出力ファイルが存在した場合、描画文字拡張データの追加処理
        /// </summary>
        /// <param name="lstInquestObjID">調査対象IDリスト</param>
        /// <param name="i">インデックス</param>
        /// <param name="dataDetail">XMLファイルの要素</param>
        /// <param name="sViewTxtMEx">描画文字拡張データ</param>
        /// <param name="sTwnPOI">タウン物件データ</param>
        /// <param name="blFlag">true:グループタイプが3の場合 false:以外の場合</param>
        private void CreateSViewTxtMExDataByAppend(
            List<string> lstInquestObjID, int i, ref XElement dataDetail, SSignTxtViewMEx sViewTxtMEx, STwnPOI sTwnPOI, bool blFlag)
        {
            // 確認
            dataDetail.Add(new XAttribute("WorkStatus", "0"));

            // 調査対象ID
            dataDetail.Add(new XAttribute("SurveyObjectId", (ulong.Parse(lstInquestObjID[1].ToString()) + (ulong)i).ToString()));

            // 経度
            dataDetail.Add(new XAttribute("Longitude", string.Empty));

            // 緯度
            dataDetail.Add(new XAttribute("Latitude", string.Empty));

            // データソースID
            dataDetail.Add(new XAttribute("QueryObjectDB", dataSourceId));

            // OID
            dataDetail.Add(new XAttribute("OID", CommToDoDataWrapper.ConvertToOIDString((ulong)sViewTxtMEx.OID)));

            // 表示名称
            if (sViewTxtMEx.DispNameMultiLang == null || sViewTxtMEx.DispNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN] == null)
            {
                dataDetail.Add(new XAttribute("Column1", string.Empty));
            }
            else
            {
                dataDetail.Add(new XAttribute("Column1", sViewTxtMEx.DispNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name));
            }

            // 文字種別の種別コードと種別名称を"："で連結
            if (sViewTxtMEx.TypTxt == null)
            {
                dataDetail.Add(new XAttribute("Column2", string.Empty));
            }
            else
            {
                dataDetail.Add(new XAttribute("Column2", sViewTxtMEx.TypTxt.TypCode.ToString() + ":" + sViewTxtMEx.TypTxt.TypName.ToString()));
            }

            // メッシュコード
            string strMeshCode = GetMeshCodeBySSignTxtViewGeometry(sViewTxtMEx);

            // ２次メッシュコード
            dataDetail.Add(new XAttribute("Column3", strMeshCode));

            // 漢字名称
            if (sTwnPOI.TwnMultiLang == null)
            {
                dataDetail.Add(new XAttribute("Column4", string.Empty));
            }
            else
            {
                dataDetail.Add(new XAttribute("Column4", sTwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name));
            }

            // 住所名称（方書含む）
            dataDetail.Add(new XAttribute("Column5", GetSTwnPOIAdrNameStr(sTwnPOI)));

            // グループタイプが同一物件管理（○座標一致）の場合
            if (blFlag)
            {
                // 主掲載フラグが「1」のものを優先する
                var sortSTwnPOI = from item in resultSTwnPOIOfType3
                                  orderby item.MainEntryFlg descending
                                  select item;

                // 電話文字列
                string strTelList = string.Empty;

                // インデックス
                int j = 0;

                foreach (var item in sortSTwnPOI)
                {
                    string strSTwnPOI = item.Tel ?? string.Empty;

                    // 異なる電話番号を最大5までカンマ区切りで出力する
                    if (j < 5)
                    {
                        if (strTelList.Contains(strSTwnPOI) == false)
                        {
                            j = j + 1;

                            if (j == 1)
                            {
                                strTelList = strTelList + strSTwnPOI;
                            }
                            else
                            {
                                strTelList = strTelList + "," + strSTwnPOI;
                            }
                        }
                    }
                    else
                    {
                        break;
                    }
                }

                // 電話番号
                dataDetail.Add(new XAttribute("Column6", strTelList));
            }
            else
            {
                // 電話番号
                dataDetail.Add(new XAttribute("Column6", sTwnPOI.Tel ?? string.Empty));
            }
        }

        #region 住所名称モデルで各名称を取得する
        /// <summary>
        /// 住所名称モデルで各名称を取得する
        /// </summary>
        /// <param name="adrName">住所名称モデル</param>
        /// <returns>名称文字列</returns>
        private string[] GetNameOfAdrName(TAdrName adrName)
        {
            string[] nameLevel = new string[] { string.Empty, string.Empty, string.Empty, string.Empty };

            Predicate<LocalAdrName> prdLocalAdr = p => p.OID == adrName.OID;

            // LocalAdrNameからデータを抽出する
            LocalAdrName resultLoacal = resultAdrName.FindLast(prdLocalAdr);

            // レベルの取得
            int intLevel = adrName.NestLevel;

            do
            {
                // 都道府県名、市区町村名、大字名、小字名の取得と設定
                nameLevel[intLevel] = resultLoacal.Name;

                intLevel = intLevel - 1;

                resultLoacal = resultLoacal.Parent;
            }
            while (intLevel >= 0);

            return nameLevel;
        }
        #endregion

        #region 調査対象データの新規
        /// <summary>
        /// 調査対象データを新規すること
        /// </summary>
        /// <param name="lstInquestObjID">調査対象ID</param>
        private void InsertMultiInquestObject(List<string> lstInquestObjID)
        {
            // 調査対象ID
            string strInquestObjID = string.Empty;

            ulong lngount = ulong.Parse(lstInquestObjID[2]) - ulong.Parse(lstInquestObjID[1]);

            try
            {
                for (ulong i = 0; i <= lngount; i++)
                {
                    strInquestObjID = (ulong.Parse(lstInquestObjID[1]) + i).ToString();

                    // 新規の場合は、調査対象IDを設定                   
                    DataRow dr = this.surveyObj.Rows[0];

                    // 調査対象データの調査対象IDを順次に採番された調査対象IDに設定する
                    dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = strInquestObjID;

                    // 調査対象反映APIの呼び出し
                    // 暫定対応した方法
                    int result = ReflectSurveyObjBatch_TMI.UpdateSurveyObjForSTwnPOIUpdate(this.surveyObj, _dBPMateria);

                    // 戻り値が0以外の場合、異常をスロー
                    if (result != RESULT_SUCCEED)
                    {
                        string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                        throw new BusinessLogicException(msgId, new string[] { strInquestObjID });
                    }
                }
            }
            catch (Exception ex)
            {
                string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                throw new BusinessLogicException(msgId, new string[] { strInquestObjID }, ex);
            }
        }
        #endregion

        #region 描画記号文字拡張の座標により、2次メッシュコード文字列を取得
        /// <summary>
        /// 描画記号文字拡張の座標により、2次メッシュコード文字列を取得
        /// </summary>
        /// <param name="sViewTxtMEx">描画記号文字拡張</param>
        /// <returns>2次メッシュコード文字列</returns>
        private string GetMeshCodeBySSignTxtViewGeometry(SSignTxtViewMEx sViewTxtMEx)
        {
            string strMeshCode = string.Empty;

            // 取得した座標リスト
            List<Coordinate> lstCoordinate = new List<Coordinate>();

            // 取得した2次メッシュコードリスト
            List<string> lstMeshCode = new List<string>();

            // 描画記号文字拡張の記号座標により、2次メッシュリストを取得
            GetMeshLstBySSignTxtViewGemetryType(sViewTxtMEx, true, ref lstCoordinate, ref lstMeshCode);

            // 描画記号文字拡張の文字座標により、2次メッシュリストを取得
            GetMeshLstBySSignTxtViewGemetryType(sViewTxtMEx, false, ref lstCoordinate, ref lstMeshCode);

            string[] arrMeshCode = lstMeshCode.ToArray();

            for (int i = 0; i < arrMeshCode.Length; i++)
            {
                if (i == 0)
                {
                    strMeshCode = arrMeshCode[0];
                }
                else
                {
                    strMeshCode = strMeshCode + "," + arrMeshCode[i];
                }
            }

            return strMeshCode;
        }

        /// <summary>
        /// 描画記号文字拡張の座標種類により、2次メッシュコードリストを取得
        /// </summary>
        /// <param name="sViewTxtMEx">描画記号文字拡張</param>
        /// <param name="geoType">true:描画記号 false:描画文字</param>
        /// <param name="lstCoordinate">座標リスト</param>
        /// <param name="lstMeshCode">2次メッシュコードリスト</param>
        private void GetMeshLstBySSignTxtViewGemetryType(SSignTxtViewMEx sViewTxtMEx, bool geoType, ref List<Coordinate> lstCoordinate, ref List<string> lstMeshCode)
        {
            string strMeshCode = string.Empty;

            CoordinateD coordinateD = null;

            // 描画文字の記号座標インデックスを取得
            int index = FrameCalculationCommon.GetGeometryIndex(
                    ScaleEnum.ScaleNoDisp,
                    FrameCalculationEnum.TextTypeEnum.Normal,
                    geoType);

            // 描画文字の記号座標
            Coordinate coordinate = sViewTxtMEx.Geometry[index];

            // 無効座標以外
            if (dataService.IsInvalidCoordinate(coordinate) == false)
            {
                // Int64型経緯度座標からDouble型経緯度座標に変換
                coordinateD = GISLib.CoordinateToCoordinateD(coordinate);

                // 座標よりメッシュコードを求める
                GISLib.GetMeshCodeByCoord(8102, coordinateD, out strMeshCode);

                lstCoordinate.Add(coordinate);

                // 2次メッシュコードが存在しない場合
                if (lstMeshCode.Exists(p => p == strMeshCode) == false)
                {
                    lstMeshCode.Add(strMeshCode);
                }
            }
            else
            {
                foreach (ScaleEnum scale in Enum.GetValues(typeof(ScaleEnum)))
                {
                    if (scale == ScaleEnum.Scale10240K || scale == ScaleEnum.Scale20480K || scale == ScaleEnum.ScaleNoDisp)
                    {
                        continue;
                    }

                    // 描画文字の記号座標インデックスを取得
                    index = FrameCalculationCommon.GetGeometryIndex(
                            scale,
                            FrameCalculationEnum.TextTypeEnum.Normal,
                            geoType);

                    // 描画文字の記号座標
                    coordinate = sViewTxtMEx.Geometry[index];

                    // 座標が存在する場合
                    if (lstCoordinate.Exists(p => p.Latitude == coordinate.Latitude && p.Longitude == coordinate.Longitude))
                    {
                        continue;
                    }

                    // 無効座標以外
                    if (dataService.IsInvalidCoordinate(coordinate) == false)
                    {
                        // Int64型経緯度座標からDouble型経緯度座標に変換
                        coordinateD = GISLib.CoordinateToCoordinateD(coordinate);

                        // 座標よりメッシュコードを求める
                        GISLib.GetMeshCodeByCoord(8102, coordinateD, out strMeshCode);

                        lstCoordinate.Add(coordinate);

                        // 2次メッシュコードが存在しない場合
                        if (lstMeshCode.Exists(p => p == strMeshCode) == false)
                        {
                            lstMeshCode.Add(strMeshCode);
                        }
                    }
                }
            }
        }
        #endregion

        #region タウン物件から都道府県+市区町村+大字以下住所（方書含む）文字列を取得
        /// <summary>
        /// タウン物件から都道府県+市区町村+大字以下住所（方書含む）文字列を取得する。
        /// 方書ありの場合は方書の前に「/」を挿入する。
        /// </summary>
        /// <param name="sTwnPOI">タウン物件</param>
        /// <returns>都道府県+市区町村+大字以下住所（方書含む・方書の前に「/」を挿入）</returns>
        private string GetSTwnPOIAdrNameStr(STwnPOI sTwnPOI)
        {
            // 大字以下連結住所：Ja-Jpan
            string strBelowOazaJaJpan = string.Empty;

            if (sTwnPOI.BelowOazaJaJpan != null)
            {
                strBelowOazaJaJpan = sTwnPOI.BelowOazaJaJpan;

                // 方書ありの場合
                if (sTwnPOI.KatagakiMultiLang != null 
                  && sTwnPOI.KatagakiMultiLang[MultiLangName.Code.IETFLangTag_ja_Jpan] != null
                  && sTwnPOI.KatagakiMultiLang[MultiLangName.Code.IETFLangTag_ja_Jpan].Name != null)
                {
                    var strKatagaki = sTwnPOI.KatagakiMultiLang[MultiLangName.Code.IETFLangTag_ja_Jpan].Name;

                    // 方書の前に「/」を挿入
                    strBelowOazaJaJpan = strBelowOazaJaJpan.Insert(strBelowOazaJaJpan.Length - strKatagaki.Length, "/");
                }
            }

            // 住所名称を取得する
            TAdrName adrName = sTwnPOI.AdrName;

            string[] nameLevel = new string[] { string.Empty, string.Empty, string.Empty, string.Empty };

            if (adrName != null)
            {
                // 住所名称モデルで各名称を取得する
                nameLevel = GetNameOfAdrName(adrName);
            }

            // 文字列を連結
            var outStr = (nameLevel[0] ?? string.Empty) + (nameLevel[1] ?? string.Empty) + strBelowOazaJaJpan;

            return outStr;
        }
        #endregion
    }
}

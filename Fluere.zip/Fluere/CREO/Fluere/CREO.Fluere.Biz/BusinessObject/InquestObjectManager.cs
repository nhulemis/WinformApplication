﻿using System;
using System.Collections.Generic;
using System.Data;
using CREO.DataModel;
using CREO.DS.DataProvider;
using CREO.DS.DataSource;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Query;
using CREO.Fluere.Common.Configuration;
using CREO.FW.ExceptionHandling;
using CREO.Materia;
using CREO.Materia.API;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 調査対象データ新規、更新の纏め
    /// ■主要なロジック（BusinessObject）を実行前
    /// ・バッチ設定ファイルに、調査対象IDが未指定の場合、下記の機能を実施
    /// 　調査対象ID発番、調査対象データ新規、調査対象IDをバッチ設定ファイルに埋め込む
    ///  InquestObjectManager.AppendInquestObject();
    /// ・バッチ設定ファイルに、調査対象IDが指定される場合、下記のメソッドを呼び出す
    ///   InquestObjectManager.UpdateInquestObjectBeforeBatchRun();
    /// ■主要なロジック（BusinessObject）を実行後、調査対象ステータスの更新
    /// ・InquestObjectManager.UpdateInquestObjectAfterBatchRun();
    /// </summary>
    public class InquestObjectManager
    {
        #region 指定したパラメータで調査対象データの新規
        /// <summary>
        /// 指定したパラメータで調査対象データの新規
        /// </summary>
        /// <param name="triggerID">システムトリガID</param>
        /// <param name="surveyStatus">調査ステータス</param>
        /// <param name="handoverStatus">引き継ぎステータス</param>
        /// <param name="inquestObjIdCount">採番数</param>
        /// <returns>開始番号と終了番号</returns>
        public static string[] AppendInquestObjectData(
            string triggerID,
            string surveyStatus,
            string handoverStatus,
            int inquestObjIdCount)
        {
            // 1．調査対象データの新規追加
            // 調査対象データの新規作成
            DataTable dtSurveyObj = CreateSurveyObjTable();

            // 開始番号を追加
            dtSurveyObj.Columns.Add(CommonConstants.KAISI, typeof(string));

            // 終了番号を追加
            dtSurveyObj.Columns.Add(CommonConstants.SHUURYOU, typeof(string));

            // 1つ調査対象データの作成
            DataRow dr = dtSurveyObj.Rows.Add();

            // 処理区分 = 01：新規
            dr[ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION] = ReflectSurveyObjConst.PROCESS_DIVISION_INSERT;

            // トリガID
            dr[ReflectSurveyObjBatchConst.FIELDNAME_TRIGGERID] = triggerID;

            // 調査ステータス 
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS] = surveyStatus;

            // 引き継ぎステータス 
            dr[ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS] = handoverStatus;

            // 生成日時
            dr[ReflectSurveyObjBatchConst.FIELDNAME_CREATEDDATE] = DateTime.Now;

            // 生成ユーザID = USERNAME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_CREATEUSERID] = Environment.UserName;

            // 最終更新日時 = SYSTEMTIME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE] = DateTime.Now;

            // 最終更新ユーザID = USERNAME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID] = Environment.UserName;

            // TODO出力フラグ = 0:TODOへ未出力
            dr[ReflectSurveyObjBatchConst.FIELDNAME_TODOOUTPUTFLAG] = ReflectSurveyObjConst.TO_DO_OUTPUT_FLAG_ZERO;

            // 調査対象データ新規
            AppendInquestObjectDataBusinessObject bo = new AppendInquestObjectDataBusinessObject(dtSurveyObj, inquestObjIdCount);
            bo.Execute();

            return new string[] { dr[CommonConstants.KAISI] as string, dr[CommonConstants.SHUURYOU] as string };
        }

        #endregion

        #region 指定したパラメータで調査対象データの更新
        /// <summary>
        /// 指定したパラメータで調査対象ステータスの更新
        /// </summary>
        /// <param name="surveyObjectId">調査対象ID</param>
        /// <param name="surveyStatus">調査ステータス</param>
        /// <param name="handoverStatus">引き継ぎステータス</param>
        /// <param name="surveyMemo">調査メモ(未指定時はNull(更新しない))</param>
        /// <param name="outputToDoFlag">TODOリスト出力フラグ(未指定時はNull(更新しない))</param>
        public static void UpdateInquestObjectData(
            string surveyObjectId,
            string surveyStatus,
            string handoverStatus,
            string surveyMemo = "",
            string outputToDoFlag = "")
        {
            // 調査対象IDにより調査対象テーブルからデータを取得する
            DataTable dtSurveyObj =
                     ReflectSurveyObjCommon.SelectSurveyObject(surveyObjectId, GetConnectMateriaDB());

            if (dtSurveyObj == null || dtSurveyObj.Rows.Count == 0)
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20002001, new string[] { surveyObjectId });
            }

            // 処理区分の列を追加
            dtSurveyObj.Columns.Add(ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION, typeof(string));

            // データ行の特定
            DataRow dr = dtSurveyObj.Rows[0];

            // 調査対象ID
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = surveyObjectId;

            // 処理区分 = 02：更新
            dr[ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION] = ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE;

            // 引き継ぎステータス
            dr[ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS] = handoverStatus;

            // 調査ステータス
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS] = surveyStatus;

            if (string.IsNullOrEmpty(surveyMemo) == false)
            {
                // 調査メモ
                dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYMEMO] = surveyMemo;
            }

            if (string.IsNullOrEmpty(outputToDoFlag) == false)
            {
                // TODO出力フラグ
                dr[ReflectSurveyObjBatchConst.FIELDNAME_TODOOUTPUTFLAG] = outputToDoFlag;
            }

            // 最終更新日時 = SYSTEMTIME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE] = DateTime.Now;

            // 更新ユーザID = バッチ処理者（ログオンユーザID）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID] = Environment.UserName;

            // 調査対象データの更新
            UpdateInquestObjBusinessObject bo = new UpdateInquestObjBusinessObject(dtSurveyObj);
            bo.Execute();
        }
        #endregion

        #region 調査対象データの新規
        /// <summary>
        /// 調査対象データの新規（調査対象ID発番、バッチ設定ファイルの更新）
        /// </summary>
        /// <param name="triggerID">システムトリガID</param>
        /// <param name="configMgr">バッチ設定情報</param>
        [Obsolete("このメソッドは廃止される予定です。代わりに'AppendInquestObjectData()' を使用してください。", false)]
        public static void AppendInquestObject(
            string triggerID,
            ref IConfigurationManager configMgr)
        {
            // 1．調査対象データの新規追加
            // 調査対象データの新規作成
            DataTable dtSurveyObj = CreateSurveyObjTable();

            // 1つ調査対象データの作成
            DataRow dr = dtSurveyObj.Rows.Add();

            // 処理区分 = 01：新規
            dr[ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION] = ReflectSurveyObjConst.PROCESS_DIVISION_INSERT;

            // トリガID
            dr[ReflectSurveyObjBatchConst.FIELDNAME_TRIGGERID] = triggerID;

            // 調査ステータス = 0（調査未着手）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS] = ReflectSurveyObjConst.SURVEY_STATUS_MITYAKUSYU;

            // 引き継ぎステータス = 1（引き継ぎ対象）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS] = ReflectSurveyObjConst.HANDOVER_STATUS_TAISYOU;

            // 生成日時
            dr[ReflectSurveyObjBatchConst.FIELDNAME_CREATEDDATE] = DateTime.Now;

            // 生成ユーザID = USERNAME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_CREATEUSERID] = Environment.UserName;

            // 最終更新日時 = SYSTEMTIME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE] = DateTime.Now;

            // 最終更新ユーザID = USERNAME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID] = Environment.UserName;

            // TODO出力フラグ = 0:TODOへ未出力
            dr[ReflectSurveyObjBatchConst.FIELDNAME_TODOOUTPUTFLAG] = ReflectSurveyObjConst.TO_DO_OUTPUT_FLAG_ZERO;

            // 調査対象データ新規、調査対象IDを埋め込み
            InsertInquestObjBusinessObject bo = new InsertInquestObjBusinessObject(dtSurveyObj, configMgr);
            bo.Execute();
        }
        #endregion

        #region 調査対象データの更新（バッチ処理前）
        /// <summary>
        /// 主要バッチロジック処理を実行する前、調査対象データの更新
        /// </summary>
        /// <param name="surveyObjectId">調査対象ID</param>
        public static void UpdateInquestObjectBeforeBatchRun(string surveyObjectId)
        {
            // 調査対象IDにより調査対象テーブルからデータを取得する
            DataTable dtSurveyObj =
                     ReflectSurveyObjCommon.SelectSurveyObject(surveyObjectId, GetConnectMateriaDB());

            if (dtSurveyObj == null || dtSurveyObj.Rows.Count == 0)
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20002001, new string[] { surveyObjectId });
            }

            // 処理区分の列を追加
            dtSurveyObj.Columns.Add(ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION, typeof(string));

            // データ行の特定
            DataRow dr = dtSurveyObj.Rows[0];

            // 調査対象ID
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = surveyObjectId;

            // 処理区分 = 02：更新
            dr[ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION] = ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE;

            // 最終更新日時 = SYSTEMTIME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE] = DateTime.Now;

            // 更新ユーザID = バッチ処理者（ログオンユーザID）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID] = Environment.UserName;

            // 調査対象データの更新
            UpdateInquestObjBusinessObject bo = new UpdateInquestObjBusinessObject(dtSurveyObj);
            bo.Execute();
        }
        #endregion

        #region 調査対象データの更新（バッチ処理後）
        /// <summary>
        /// バッチ処理実行に成功した後、調査対象ステータスの更新
        /// </summary>
        /// <param name="surveyObjectId">調査対象ID</param>
        public static void UpdateInquestObjectAfterBatchRun(string surveyObjectId)
        {
            // 調査対象IDにより調査対象テーブルからデータを取得する
            DataTable dtSurveyObj =
                     ReflectSurveyObjCommon.SelectSurveyObject(surveyObjectId, GetConnectMateriaDB());

            if (dtSurveyObj == null || dtSurveyObj.Rows.Count == 0)
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20002001, new string[] { surveyObjectId });
            }

            // 処理区分の列を追加
            dtSurveyObj.Columns.Add(ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION, typeof(string));

            // データ行の特定
            DataRow dr = dtSurveyObj.Rows[0];

            // 調査対象ID
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = surveyObjectId;

            // 処理区分 = 02：更新
            dr[ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION] = ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE;

            // 引き継ぎステータスの更新値を決める
            dr[ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS] = ReflectSurveyObjConst.HANDOVER_STATUS_TAISYOU;

            // 調査ステータス = 1（事前調査完了）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS] = ReflectSurveyObjConst.SURVEY_STATUS_JIZENTYOUSA_KANRYOU;

            // 最終更新日時 = SYSTEMTIME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE] = DateTime.Now;

            // 更新ユーザID = バッチ処理者（ログオンユーザID）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID] = Environment.UserName;

            // 調査対象データの更新
            UpdateInquestObjBusinessObject bo = new UpdateInquestObjBusinessObject(dtSurveyObj);
            bo.Execute();
        }
        #endregion

        #region 調査対象データの更新（バッチ処理後）（引継対象外）
        /// <summary>
        /// バッチ処理実行に成功した後、調査対象ステータスの更新
        /// ※引継ステータスを「2（引継対象外）」
        /// </summary>
        /// <param name="surveyObjectId">調査対象ID</param>
        public static void UpdateInquestObjectExceptAfterBatchRun(string surveyObjectId)
        {
            // 調査対象IDにより調査対象テーブルからデータを取得する
            DataTable dtSurveyObj =
                     ReflectSurveyObjCommon.SelectSurveyObject(surveyObjectId, GetConnectMateriaDB());

            if (dtSurveyObj == null || dtSurveyObj.Rows.Count == 0)
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20002001, new string[] { surveyObjectId });
            }

            // 処理区分の列を追加
            dtSurveyObj.Columns.Add(ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION, typeof(string));

            // データ行の特定
            DataRow dr = dtSurveyObj.Rows[0];

            // 調査対象ID
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = surveyObjectId;

            // 処理区分 = 02：更新
            dr[ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION] = ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE;

            // 引き継ぎステータスの更新値を決める → 引継ステータスを「2（引継対象外）」
            dr[ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS] = ReflectSurveyObjConst.HANDOVER_STATUS_TAISYOUGAI;

            // 調査ステータス = 1（事前調査完了）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS] = ReflectSurveyObjConst.SURVEY_STATUS_JIZENTYOUSA_KANRYOU;

            // 最終更新日時 = SYSTEMTIME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE] = DateTime.Now;

            // 更新ユーザID = バッチ処理者（ログオンユーザID）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID] = Environment.UserName;

            // 調査対象データの更新
            UpdateInquestObjBusinessObject bo = new UpdateInquestObjBusinessObject(dtSurveyObj);
            bo.Execute();
        }
        #endregion

        #region 調査対象データの更新（バッチ処理後）【編集DB一括反映 専用】
        /// <summary>
        /// 【編集DB一括反映用】バッチ処理実行に成功した後、引き継ぎステータスの更新
        /// </summary>
        /// <param name="surveyObjectId">調査対象ID</param>
        public static void UpdateInquestObjectAfterBatchRunForDataApply(string surveyObjectId)
        {
            // <Added by houyao on 2012/11/21>

            // 調査対象IDにより調査対象テーブルからデータを取得する
            DataTable dtSurveyObj =
                     ReflectSurveyObjCommon.SelectSurveyObject(surveyObjectId, GetConnectMateriaDB());

            if (dtSurveyObj == null || dtSurveyObj.Rows.Count == 0)
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20002001, new string[] { surveyObjectId });
            }

            // 処理区分の列を追加
            dtSurveyObj.Columns.Add(ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION, typeof(string));

            // データ行の特定
            DataRow dr = dtSurveyObj.Rows[0];

            // 調査対象ID
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = surveyObjectId;

            // 処理区分 = 02：更新
            dr[ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION] = ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE;

            // 引き継ぎステータス=引き継ぎ完了（3） 
            dr[ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS] = ReflectSurveyObjConst.HANDOVER_STATUS_KANRYOU;

            // 最終更新日時 = SYSTEMTIME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE] = DateTime.Now;

            // 更新ユーザID = バッチ処理者（ログオンユーザID）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID] = Environment.UserName;

            // 調査対象データの更新
            UpdateInquestObjBusinessObject bo = new UpdateInquestObjBusinessObject(dtSurveyObj);
            bo.Execute();
        }
        #endregion

        #region 調査対象データの取得
        /// <summary>
        /// 調査対象IDにより調査対象テーブルからデータを取得する
        /// </summary>
        /// <param name="surveyObjectId">調査対象ID</param>
        /// <returns>調査対象データ</returns>
        public static DataRow GetInquestObjectData(string surveyObjectId)
        {
            DataTable dtSurveyObj = ReflectSurveyObjCommon.SelectSurveyObject(surveyObjectId, GetConnectMateriaDB());

            if (dtSurveyObj == null || dtSurveyObj.Rows.Count == 0)
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20002001, new string[] { surveyObjectId });
            }

            return dtSurveyObj.Rows[0];
        }
        #endregion

        #region 調査対象データの更新（ToDoファイルの調査対象IDにより）
        /// <summary>
        /// バッチ処理実行に成功した後、調査対象ステータスの更新  
        /// </summary>
        /// <param name="surveyObjectId">調査対象ID</param>
        /// <param name="surveyStatus">調査ステータス</param>
        /// <param name="handoverStatus">引き継ぎステータス</param>
        public static void UpdateInquestObjectForToDoFile(string surveyObjectId, string surveyStatus, string handoverStatus)
        {
            // 調査対象IDにより調査対象テーブルからデータを取得する
            DataTable dtSurveyObj =
                     ReflectSurveyObjCommon.SelectSurveyObject(surveyObjectId, GetConnectMateriaDB());

            if (dtSurveyObj == null || dtSurveyObj.Rows.Count == 0)
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20002001, new string[] { surveyObjectId });
            }

            // 処理区分の列を追加
            dtSurveyObj.Columns.Add(ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION, typeof(string));

            // データ行の特定
            DataRow dr = dtSurveyObj.Rows[0];

            // 調査対象ID
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = surveyObjectId;

            // 処理区分 = 02：更新
            dr[ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION] = ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE;

            // 引き継ぎステータス
            dr[ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS] = handoverStatus;

            // 調査ステータス
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS] = surveyStatus;

            // 最終更新日時 = SYSTEMTIME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE] = DateTime.Now;

            // 更新ユーザID = バッチ処理者（ログオンユーザID）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID] = Environment.UserName;

            // 調査対象テーブルの更新
            try
            {
                int result = ReflectSurveyObjBatch.UpdateSurveyObj(dtSurveyObj, GetConnectMateriaDB());
            }
            catch
            {
                // 調査対象ID
                string currInquestObjID = dtSurveyObj.Rows[0][ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID].ToString();

                // 調査対象データのレコードを更新出来ません
                string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                throw new BusinessLogicException(msgId, new string[] { currInquestObjID });
            }
        }
        #endregion

        #region 調査対象データの更新と調査対象IDのクリア
        /// <summary>
        /// 調査対象データの更新と調査対象IDのクリア
        /// </summary>
        /// <param name="surveyObjectId">調査対象ID</param>
        /// <param name="surveyStatus">調査ステータス</param>
        /// <param name="handoverStatus">引き継ぎステータス</param>
        /// <param name="configMgr">ファイル対象</param>
        [Obsolete("このメソッドは廃止される予定です。代わりに'UpdateInquestObjectData()' を使用してください。", false)]
        public static void UpdateInquestObjectAndClearInquestId(
            string surveyObjectId, string surveyStatus, string handoverStatus, ref IConfigurationManager configMgr)
        {
            // 調査対象IDにより調査対象テーブルからデータを取得する
            DataTable dtSurveyObj =
                     ReflectSurveyObjCommon.SelectSurveyObject(surveyObjectId, GetConnectMateriaDB());

            if (dtSurveyObj == null || dtSurveyObj.Rows.Count == 0)
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20002001, new string[] { surveyObjectId });
            }

            // 処理区分の列を追加
            dtSurveyObj.Columns.Add(ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION, typeof(string));

            // データ行の特定
            DataRow dr = dtSurveyObj.Rows[0];

            // 調査対象ID
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = surveyObjectId;

            // 処理区分 = 02：更新
            dr[ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION] = ReflectSurveyObjConst.PROCESS_DIVISION_UPDATE;

            // 引き継ぎステータス
            dr[ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS] = handoverStatus;

            // 調査ステータス
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS] = surveyStatus;

            // 最終更新日時 = SYSTEMTIME
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE] = DateTime.Now;

            // 更新ユーザID = バッチ処理者（ログオンユーザID）
            dr[ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID] = Environment.UserName;

            // 調査対象データの更新
            UpdateInquestObjAndClearIdBusinessObject bo = new UpdateInquestObjAndClearIdBusinessObject(dtSurveyObj, configMgr);

            bo.Execute();
        }
        #endregion

        #region 調査対象データテーブルの作成
        /// <summary>
        /// 調査対象データテーブル
        /// </summary>
        /// <returns>DataTable</returns>
        public static DataTable CreateSurveyObjTable()
        {
            DataTable dtSurveyObj = new DataTable();

            // 調査対象ID
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID, typeof(string));

            // 出典O-ID(物件)
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_ARTICLESOURCEID, typeof(string));

            // 出典O-ID(描画)
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_DRAWINGSOURCEID, typeof(string));

            // トリガID
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_TRIGGERID, typeof(string));

            // 選別区分
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_SELECTDIVISION, typeof(string));

            // 重複確認用データ
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_DUPLCONFDATA, typeof(string));

            // 備考
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_REMARKS, typeof(string));

            // 表示用項目１
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_DISPLAYITEM1, typeof(string));

            // 表示用項目2
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_DISPLAYITEM2, typeof(string));

            // 元調査対象ID
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_OLDSURVEYOBJECTID, typeof(string));

            // TODO出力フラグ
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_TODOOUTPUTFLAG, typeof(string));

            // 調査ステータス
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_SURVEYSTATUS, typeof(string));

            // 次回調査可能日
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_NEXTSURVEYDATE, typeof(string));

            // オープン日
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_OPENDATE, typeof(string));

            // 引き継ぎステータス
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_HANDOVERSTATUS, typeof(string));

            // 調査メモ
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_SURVEYMEMO, typeof(string));

            // 生成日時
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_CREATEDDATE, typeof(DateTime));

            // 生成ユーザID
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_CREATEUSERID, typeof(string));

            // 更新日時
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_MODIFIEDDATE, typeof(DateTime));

            // 更新ユーザID
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_MODIFYUSERID, typeof(string));

            // 処理区分（01：登録　02：更新）
            dtSurveyObj.Columns.Add(
                ReflectSurveyObjBatchConst.FIELDNAME_PROCESSDIVISION, typeof(string));

            return dtSurveyObj;
        }
        #endregion

        #region 出典加工システムのデータベースに接続
        /// <summary>
        /// 出典加工システムのデータベースに接続
        /// </summary>
        /// <returns>出典加工システムのDataProvider</returns>
        private static DBDataProviderBase GetConnectMateriaDB()
        {
            try
            {
                // DBDataProviderBaseオブジェクトを作成
                DBDataProviderBase _dBPMateria = new DBDataProviderBase();
                ConnectionContext ctx = new ConnectionContext();
                ctx.DataSourceID = DataServiceManager.DB_Materia;
                _dBPMateria.Bind(ctx);

                return _dBPMateria;
            }
            catch (Exception)
            {
                // 出典加工システムのデータベースに接続出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF20000001;
                string[] parameters = new string[] { DataServiceManager.DB_Materia };

                throw new BusinessLogicException(msgId, parameters);
            }
        }
        #endregion

        #region 調査対象IDの存在するかを判断する
        /// <summary>
        /// 調査対象IDの存在するかを判断する
        /// </summary>
        /// <param name="surveyObjectId">調査対象ID</param>
        /// <returns>true:存在する false:存在しない</returns>
        public static bool IsExitOfsurveyObjectId(string surveyObjectId)
        {
            // 調査対象IDにより調査対象テーブルからデータを取得する
            DataTable dtSurveyObj =
                     ReflectSurveyObjCommon.SelectSurveyObject(surveyObjectId, GetConnectMateriaDB());

            if (dtSurveyObj == null || dtSurveyObj.Rows.Count == 0)
            {
                return false;
            }

            return true;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.FW.Utilities;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// データソースの取得クラス
    /// </summary>
    public sealed class DataSourceCacheManager
    {
        #region Singletonインスタンス定義
        /// <summary>
        /// Singletonインスタンス
        /// </summary>
        private static DataSourceCacheManager _singletonInstance = null;
        #endregion

        #region キャッシュ
        /// <summary>
        /// キャッシュ定義
        /// </summary>
        private Dictionary<string, string> _dataSourceDic = new Dictionary<string, string>();
        #endregion

        #region キャッシュのキー定義
        /// <summary>
        /// 編集DB
        /// </summary>
        public const string DATASOURCE_KEY_EDIT = "Edit";

        /// <summary>
        /// 03凍結DB
        /// </summary>
        public const string DATASOURCE_KEY_FREEZE03 = "Freeze03";

        /// <summary>
        /// 05凍結DB
        /// </summary>
        public const string DATASOURCE_KEY_FREEZE05 = "Freeze05";

        /// <summary>
        /// 07凍結DB
        /// </summary>
        public const string DATASOURCE_KEY_FREEZE07 = "Freeze07";

        /// <summary>
        /// MateriaDB
        /// </summary>
        public const string DATASOURCE_KEY_MATERIA = "Materia";

        /// <summary>
        /// 出典DB
        /// </summary>
        public const string DATASOURCE_KEY_SOURCE = "Source";

        /// <summary>
        /// DrawingDB
        /// </summary>
        public const string DATASOURCE_KEY_DRAWING = "Drawing";

        /// <summary>
        /// マッピングDB
        /// </summary>
        public const string DATASOURCE_KEY_MAPPING = "Mapping";

        /// <summary>
        /// ラスターDB
        /// </summary>
        public const string DATASOURCE_KEY_RASTER = "Raster";

        /// <summary>
        /// VICS形状
        /// </summary>
        public const string DATASOURCE_KEY_VICS = "Vics";

        /// <summary>
        /// 予約VICS形状
        /// </summary>
        public const string DATASOURCE_KEY_VICSRESURVE = "VicsResurve";

        /// <summary>
        /// TMIDB市街図形状
        /// </summary>
        public const string DATASOURCE_KEY_CITYMAPFIG = "CityMapFig";

        /// <summary>
        /// TMIDB市街図道路
        /// </summary>
        public const string DATASOURCE_KEY_CITYMAPROAD = "CityMapRoad";

        /// <summary>
        /// TMIDB市街図施設界
        /// </summary>
        public const string DATASOURCE_KEY_CITYMAPFACILITY = "CityMapFacility";

        /// <summary>
        /// TMIDB市街図文字
        /// </summary>
        public const string DATASOURCE_KEY_CITYMAPTXT = "CityMapTxt";

        /// <summary>
        /// 07市街図
        /// </summary>
        public const string DATASOURCE_KEY_CITYMAP07 = "CityMap07";

        /// <summary>
        /// 05DRM
        /// </summary>
        public const string DATASOURCE_KEY_05DRM = "DRM05";

        /// <summary>
        /// 07DRM
        /// </summary>
        public const string DATASOURCE_KEY_07DRM = "DRM07";

        /// <summary>
        /// 拡張minicusco
        /// </summary>
        public const string DATASOURCE_KEY_MINICUSCOEX = "MinicuscoEx";

        /// <summary>
        /// TR合成DB
        /// </summary>
        public const string DATASOURCE_KEY_TR = "TR";

        /// <summary>
        /// 走行軌跡log
        /// </summary>
        public const string DATASOURCE_KEY_LOCUSLOG = "LocusLog";

        /// <summary>
        /// traceLogDB
        /// </summary>
        public const string DATASOURCE_KEY_TRACELOG = "TraceLog";

        /// <summary>
        /// 走行軌跡syn
        /// </summary>
        public const string DATASOURCE_KEY_LOCUSSYN = "LocusSyn";

        /// <summary>
        /// GuardianDB
        /// </summary>
        public const string DATASOURCE_KEY_GUARDIAN = "Guardian";

        /// <summary>
        /// 住宅地図
        /// </summary>
        public const string DATASOURCE_KEY_HousingMap = "HousingMap";

        /// <summary>
        /// 地形図画像
        /// </summary>
        public const string DATASOURCE_KEY_TopoMap = "TopoMap";

        /// <summary>
        /// TZ
        /// </summary>
        public const string DATASOURCE_KEY_TZ = "TZ";

        /// <summary>
        /// Ref凍結DB
        /// </summary>
        public const string DATASOURCE_KEY_REF = "Ref";

        /// <summary>
        /// 統合NWマッチングDB
        /// </summary>
        public const string DATASOURCE_KEY_TRSMatching = "TRSMatching";
        #endregion

        #region 初期化
        /// <summary>
        /// コンストラクタ 、外部からのアクセスが不可
        /// </summary>
        private DataSourceCacheManager()
        {
        }
        #endregion

        #region 唯一のインスタンス
        /// <summary>
        /// 唯一のインスタンスを取得
        /// </summary>
        /// <returns>DataSourceCacheManager</returns>
        public static DataSourceCacheManager GetInstance()
        {
            if (_singletonInstance == null)
            {
                _singletonInstance = new DataSourceCacheManager();
            }

            return _singletonInstance;
        }
        #endregion

        #region キーによって、データソース名の取得
        /// <summary>
        /// キーによって、データソース名の取得
        /// </summary>
        /// <param name="key">データソースキー</param>
        /// <returns>データソース名</returns>
        public string GetDataSourceName(string key)
        {
            string dsName = string.Empty;
            if (_dataSourceDic.ContainsKey(key))
            {
                dsName = _dataSourceDic[key];
            }

            if (string.IsNullOrEmpty(dsName))
            {
                dsName = GetDataSourceNameSub(key);
                _dataSourceDic[key] = dsName;
            }

            return dsName;
        }

        /// <summary>
        /// 設定ファイルより取得
        /// </summary>
        /// <param name="key">データソースキー</param>
        /// <returns>データソース名</returns>
        private string GetDataSourceNameSub(string key)
        {
            string xPath = "/configuration/dbroleSettings/dbrole[@name='" + key + "']";
            return ProfileUtility.GetAttribute(
            ProfileUtility.ProfileTypeEnum.ModuleProfile,
            xPath,
            "datasource_id");
        }

        /// <summary>
        /// 設定ファイルよりデータソースキー取得
        /// </summary>
        /// <param name="value">データソース名</param>
        /// <returns>データソースキー</returns>
        public string GetDataSouceKeyByValue(string value)
        {
            string xPath = "/configuration/dbroleSettings/dbrole[@datasource_id='" + value + "']";
            return ProfileUtility.GetAttribute(
            ProfileUtility.ProfileTypeEnum.ModuleProfile,
            xPath,
            "name");
        }

        #endregion
    }
}

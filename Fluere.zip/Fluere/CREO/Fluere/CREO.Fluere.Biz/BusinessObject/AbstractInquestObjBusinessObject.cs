﻿using System;
using CREO.DS.DataProvider;
using CREO.DS.DataSource;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Message;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 調査対象データの発番、新規、更新の処理
    /// またバッチ設定ファイルには、調査対象IDの埋め込み処理
    /// </summary>
    public abstract class AbstractInquestObjBusinessObject
    {
        #region Ducoと連携のインタフェース、定数定義
        /// <summary>
        /// 0：正常
        /// </summary>
        protected readonly int RESULT_SUCCEED = 0;
        #endregion

        #region ログマネージャーのインスタンス、メッセージマネージャーのインスタンス
        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        protected LogManager _logMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);

        /// <summary>
        /// メッセージマネージャーインスタンス
        /// </summary>
        protected MessageManager _msgMgr = MessageManager.GetMessageManager(UF_Fluere_MsgId.MODULE_NUMBER);
        #endregion

        #region クラス属性定義
        /// <summary>
        /// データプロバイダ設定
        /// </summary>
        protected DBDataProviderBase _dBPMateria = null;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public AbstractInquestObjBusinessObject()
        {
        }
        #endregion

        #region インタフェイス
        /// <summary>
        /// 調査対象データの主要処理
        /// </summary>
        public void Execute()
        {
            _logMgr.WriteFuncStart();

            try
            {
                this.ConnectMateriaDB();

                this._dBPMateria.BeginTransaction();

                this.DoExecute();

                this._dBPMateria.CommitTransaction();
            }
            catch (BusinessLogicException ex)
            {
                this._dBPMateria.RollBackTransaction();

                throw ex;
            }
            catch (FrameworkException ex)
            {
                this._dBPMateria.RollBackTransaction();

                throw ex;
            }
            catch (Exception ex)
            {
                this._dBPMateria.RollBackTransaction();

                _logMgr.WriteError(ExceptionUtility.GetInnerExceptionMessage(ex));

                throw ex;
            }
            
            _logMgr.WriteFuncEnd();            
        }
        #endregion

        #region 子クラスで実現すること
        /// <summary>
        /// 子クラスで実現
        /// </summary>
        protected abstract void DoExecute();
        #endregion

        #region 出典加工システムのデータベースに接続
        /// <summary>
        /// DBDataProviderBaseオブジェクトを初期化
        /// </summary>
        private void ConnectMateriaDB()
        {
            try
            {
                // DBDataProviderBaseオブジェクトを作成
                _dBPMateria = new DBDataProviderBase();
                ConnectionContext ctx = new ConnectionContext();
                ctx.DataSourceID = DataServiceManager.DB_Materia;
                _dBPMateria.Bind(ctx);
            }
            catch (Exception)
            {
                // 出典加工システムのデータベースに接続出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF20000001;
                string[] parameters = new string[] { DataServiceManager.DB_Materia };

                throw new BusinessLogicException(msgId, parameters);
            }
        }
        #endregion
    }
}

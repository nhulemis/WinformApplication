﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.BusinessObject.Data
{
    /// <summary>
    /// SystemServiceData
    /// </summary>
    public class SystemServiceData
    {
        #region フィールド定義
        /// <summary>
        /// dataSourceID
        /// </summary>
        private string dataSourceID = null;

        /// <summary>
        /// workGroupID
        /// </summary>
        private ulong workGroupID;

        /// <summary>
        /// subWorkGroupID
        /// </summary>
        private ulong subWorkGroupID;
        #endregion

        #region getter and setter
        /// <summary>
        /// DataSourceID
        /// </summary>
        public string DataSourceID
        {
            get { return dataSourceID; }
            set { dataSourceID = value; }
        }

        /// <summary>
        /// WorkGroupID
        /// </summary>
        public ulong WorkGroupID
        {
            get { return workGroupID; }
            set { workGroupID = value; }
        }

        /// <summary>
        /// SubWorkGroupID
        /// </summary>
        public ulong SubWorkGroupID
        {
            get { return subWorkGroupID; }
            set { subWorkGroupID = value; }
        }
        #endregion
    }
}

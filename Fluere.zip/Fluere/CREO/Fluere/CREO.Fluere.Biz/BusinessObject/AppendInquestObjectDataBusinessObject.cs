﻿using System.Collections.Generic;
using System.Data;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;
using CREO.Materia;
using CREO.Materia.API;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 調査対象発番処理
    /// 調査対象データの新規
    /// 発行した調査対象IDをログに出力
    /// </summary>
    public class AppendInquestObjectDataBusinessObject : AbstractInquestObjBusinessObject
    {
        #region クラス属性定義（外部より受入）
        /// <summary>
        /// 調査対象データ
        /// </summary>
        private DataTable _inquestObjectDT = null;

        /// <summary>
        /// 採番数
        /// </summary>
        private int _inquestObjIdCounts = 0;

        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="dt">新規用の調査対象データ</param>
        /// <param name="inquestObjIdCounts">採番数</param>
        public AppendInquestObjectDataBusinessObject(DataTable dt, int inquestObjIdCounts)
        {
            _inquestObjectDT = dt;
            _inquestObjIdCounts = inquestObjIdCounts;
        }
        #endregion

        #region 主要処理のインタフェイス
        /// <summary>
        /// 主な実行
        /// </summary>
        protected override void DoExecute()
        {
            // 調査対象発番処理
            string[] inquestObjIDArray = CreateInquestObjectID(_inquestObjIdCounts);
            string firstNo = inquestObjIDArray[0];
            string lastNo = inquestObjIDArray[1];

            // 調査対象データの新規
            int no = int.Parse(firstNo);
            for (int cnt = 0; cnt < _inquestObjIdCounts; cnt++)
            {
                InsertInquestObject(no.ToString());
                no++;
            }

            // 発行した調査対象IDをログに出力            
            LogUtility.Write(UF_Fluere_MsgId.MSGID_UF20003096, new string[] { firstNo, lastNo });
        }
        #endregion

        #region 調査対象発番処理
        /// <summary>
        /// 調査対象発番処理
        /// </summary>
        /// <param name="inquestObjIdCount">採番数</param>
        /// <returns>開始番号と終了番号</returns>
        private string[] CreateInquestObjectID(int inquestObjIdCount)
        {
            // 調査対象IDの採番
            List<string> inquestObjIDList = GetSurveyObjId.GetSurveyObjectId(
                GetSurveyObjIdConst.GET_NUM_DIVION_02, inquestObjIdCount, _dBPMateria);

            // inquestObjIDList[0]の値が「0」以外の場合は、エラーとする
            if (inquestObjIDList == null || inquestObjIDList.Count < 1 || inquestObjIDList[0] != "0")
            {
                // 調査対象ID発行APIの戻り値が正常以外の場合
                string msgId = UF_Fluere_MsgId.MSGID_UF20001003;

                throw new BusinessLogicException(msgId, new string[] { });
            }

            // 開始番号と終了番号を設定
            DataRow dr = this._inquestObjectDT.Rows[0];
            dr[CommonConstants.KAISI] = inquestObjIDList[1];
            dr[CommonConstants.SHUURYOU] = inquestObjIDList[2];

            return new string[] { dr[CommonConstants.KAISI] as string, dr[CommonConstants.SHUURYOU] as string };
        }
        #endregion

        #region 調査対象データの新規
        /// <summary>
        /// 調査対象データの新規
        /// </summary>
        /// <param name="inquestObjID">調査対象ID</param>
        private void InsertInquestObject(string inquestObjID)
        {
            // 調査対象IDを設定
            DataRow dr = this._inquestObjectDT.Rows[0];
            dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID] = inquestObjID;

            // 調査対象反映APIの呼び出し
            int result = RESULT_SUCCEED;
            try
            {
                result = ReflectSurveyObjBatch.UpdateSurveyObj(this._inquestObjectDT, _dBPMateria);
            }
            catch
            {
                string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                throw new BusinessLogicException(msgId, new string[] { inquestObjID });
            }

            // 戻り値が0以外の場合、異常をスロー
            if (result != RESULT_SUCCEED)
            {
                string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                throw new BusinessLogicException(msgId, new string[] { inquestObjID });
            }
        }
        #endregion
    }
}
﻿using System;
using System.Text;
using CREO.DS;
using CREO.DS.DataSource;
using CREO.Fluere.Biz.BusinessObject.Data;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// DataServiceを管理するクラス
    /// </summary>
    public static class DataServiceManager
    {
        #region DB定数定義
        /// <summary>
        /// 出典マスタ
        /// </summary>
        public static string DB_Master =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_SOURCE);

        /// <summary>
        /// 編集DB
        /// </summary>
        public static string DB_EditDB =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_EDIT);

        /// <summary>
        /// 納品凍結03DB
        /// </summary>
        public static string DB_Donum03 =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_FREEZE03);

        /// <summary>
        /// 納品凍結05DB
        /// </summary>
        public static string DB_Donum05 =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_FREEZE05);

        /// <summary>
        /// 納品凍結07DB
        /// </summary>
        public static string DB_Donum07 =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_FREEZE07);

        /// <summary>
        /// 出典加工DB
        /// </summary>
        public static string DB_Materia =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_MATERIA);

        /// <summary>
        /// TMIDB市街図形状
        /// </summary>
        public static string DB_CityMapFig =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_CITYMAPFIG);

        /// <summary>
        /// TMIDB市街図道路
        /// </summary>
        public static string DB_CityMapRoad =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_CITYMAPROAD);

        /// <summary>
        /// TMIDB市街図施設界
        /// </summary>
        public static string DB_CityMapFacility =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_CITYMAPFACILITY);

        /// <summary>
        /// TMIDB市街図文字
        /// </summary>
        public static string DB_CityMapTxt =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_CITYMAPTXT);

        /// <summary>
        /// 07市街図
        /// </summary>
        public static string DB_CityMap07 =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_CITYMAP07);

        /// <summary>
        /// 05DRM
        /// </summary>
        public static string DB_05DRM =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_05DRM);

        /// <summary>
        /// 07DRM
        /// </summary>
        public static string DB_07DRM =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_07DRM);

        /// <summary>
        /// 拡張minicusco
        /// </summary>
        public static string DB_MinicuscoEx =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_MINICUSCOEX);

        /// <summary>
        /// TR合成DB
        /// </summary>
        public static string DB_TR =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_TR);

        /// <summary>
        /// 走行軌跡log
        /// </summary>
        public static string DB_LocusLog =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_LOCUSLOG);

        /// <summary>
        /// traceLogDB
        /// </summary>
        public static string DB_TraceLog =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_TRACELOG);

        /// <summary>
        /// 走行軌跡syn
        /// </summary>
        public static string DB_LocusSyn =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_LOCUSSYN);

        /// <summary>
        /// GuardianDB
        /// </summary>
        public static string DB_Guardian =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_GUARDIAN);

        /// <summary>
        /// 住宅地図
        /// </summary>
        public static string DB_HousingMap =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_HousingMap);

        /// <summary>
        /// 地形図画像
        /// </summary>
        public static string DB_TopoMap =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_TopoMap);

        /// <summary>
        /// Raster
        /// </summary>
        public static string DB_RASTER =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_RASTER);

        /// <summary>
        /// Ref凍結DB
        /// </summary>
        public static string DB_REF =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_REF);

        /// <summary>
        /// 統合NWマッチングDB
        /// </summary>
        public static string DB_TRSMatching =
            DataSourceCacheManager.GetInstance().GetDataSourceName(DataSourceCacheManager.DATASOURCE_KEY_TRSMatching);
        #endregion

        #region 指定DBに対してデータサービスのインスタンス
        /// <summary>
        /// DataSourceによるデータサービスの取得
        /// </summary>
        /// <param name="dataSourceID">ID</param>
        /// <returns>DataService</returns>
        public static DataService GetDataServcie(string dataSourceID)
        {
            return GetDataServcie(dataSourceID, false, true);
        }

        /// <summary>
        /// ワークグループによるデータサービスのインスタンス
        /// ※WorkGroupの利用の場合：[WG_WGCTRL][WG_SUBWGCTRL][L_PRIOR_LOCK_MNG]
        /// </summary>
        /// <param name="data">設定条件</param>
        /// <returns>データサービスのインスタンス</returns>
        public static DataService GetDataServcie(SystemServiceData data)
        {
            return GetDataServcie(data, false, true);
        }

        /// <summary>
        /// DataSourceによるデータサービスの取得
        /// </summary>
        /// <param name="dataSourceID">ID</param>
        /// <param name="useBulk">Use Bulk</param>
        /// <param name="useCache">Use Cache</param>
        /// <returns>DataService</returns>
        public static DataService GetDataServcie(string dataSourceID, bool useBulk = false, bool useCache = true)
        {
            try
            {
                // 指定DBにデータサービスをインスタンス
                ConnectionContext ctx = new ConnectionContext();
                ctx.DataSourceID = dataSourceID;
                CREO.DS.DataService ds = CREO.DS.DataService.Connect(ctx);

                // ログの記入
                WriteDataBaseInfoLog(ds);

                return ds;
            }
            catch (Exception ex)
            {
                LogUtility.WriteError(ex, string.Empty);

                if (DataServiceManager.DB_Master.Equals(dataSourceID))
                {
                    // 出典マスタデータベースに接続出来ない場合
                    string msgId = UF_Fluere_MsgId.MSGID_UF20000002;
                    string[] parameters = new string[] { DataServiceManager.DB_Master };
                    throw new BusinessLogicException(msgId, parameters);
                }
                else if (DataServiceManager.DB_EditDB.Equals(dataSourceID))
                {
                    // 編集DBに接続出来ない場合
                    string msgId = UF_Fluere_MsgId.MSGID_UF30000001;
                    string[] parameters = new string[] { DataServiceManager.DB_EditDB };
                    throw new BusinessLogicException(msgId, parameters);
                }
                else
                {
                    throw ex;
                }
            }
        }
        #endregion

        #region 指定DBと関連設定に対してデータサービスのインスタンス
        /// <summary>
        /// ワークグループによるデータサービスのインスタンス
        /// ※WorkGroupの利用の場合：[WG_WGCTRL][WG_SUBWGCTRL][L_PRIOR_LOCK_MNG]
        /// </summary>
        /// <param name="data">設定条件</param>
        /// <param name="useBulk">Use Bulk</param>
        /// <param name="useCache">Use Cache</param>
        /// <returns>データサービスのインスタンス</returns>
        public static DataService GetDataServcie(SystemServiceData data, bool useBulk = false, bool useCache = true)
        {
            try
            {
                // 指定DBにデータサービスをインスタンス
                ConnectionContext ctx = new ConnectionContext();
                ctx.DataSourceID = data.DataSourceID;
                ctx.WorkGroupID = data.WorkGroupID;
                ctx.SubWorkGroupID = data.SubWorkGroupID;
                CREO.DS.DataService ds = CREO.DS.DataService.Connect(ctx);

                // ログの記入
                WriteDataBaseInfoLog(ds, true);

                return ds;
            }
            catch (Exception ex)
            {
                LogUtility.WriteError(ex, string.Empty);

                if (DataServiceManager.DB_Master.Equals(data.DataSourceID))
                {
                    // 出典マスタデータベースに接続出来ない場合
                    string msgId = UF_Fluere_MsgId.MSGID_UF20000002;
                    string[] parameters = new string[] { DataServiceManager.DB_Master };
                    throw new BusinessLogicException(msgId, parameters);
                }
                else if (DataServiceManager.DB_EditDB.Equals(data.DataSourceID))
                {
                    // 編集DBに接続出来ない場合
                    string msgId = UF_Fluere_MsgId.MSGID_UF30000001;
                    string[] parameters = new string[] { DataServiceManager.DB_EditDB };
                    throw new BusinessLogicException(msgId, parameters);
                }
                else
                {
                    throw ex;
                }
            }
        }
        #endregion

        #region データベース設定情報の出力
        /// <summary>
        /// データベース設定情報の出力
        /// </summary>
        /// <param name="ds">データソース</param>
        /// <param name="isEditDB">編集ＤＢであるか</param>
        private static void WriteDataBaseInfoLog(DataService ds, bool isEditDB = false)
        {
            ConnectionContext connectionContext = ds.GetConnectionContext();
            DataSourceInfo dataSourceInfo = ds.GetCurrentDataSourceInfo();
            StringBuilder sb = new StringBuilder();
            sb.Append("【データベース情報】：");
            sb.Append("DataSourceID=");
            sb.Append(connectionContext.DataSourceID);
            sb.Append(";");
            sb.Append(dataSourceInfo.GetDatabase());
            sb.Append(";");
            sb.Append(dataSourceInfo.GetFilePath());

            if (isEditDB)
            {
                sb.Append(";");
                sb.Append("WorkGroupID=");
                sb.Append(connectionContext.WorkGroupID);
                sb.Append(";");
                sb.Append("SubWorkGroupID=");
                sb.Append(connectionContext.SubWorkGroupID);
            }

            LogUtility.WriteInfo(sb.ToString());
        }
        #endregion
    }
}

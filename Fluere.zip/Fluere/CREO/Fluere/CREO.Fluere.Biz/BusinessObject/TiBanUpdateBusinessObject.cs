﻿using System.Collections.Generic;
using System.Linq;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Query;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 直接地番リカバリ（共通部品）
    /// </summary>
    public class TiBanUpdateBusinessObject
    {
        #region フィールド
        /// <summary>
        /// 住所代表点のTODOデータ
        /// </summary>
        private HashSet<CommToDoDataWrapper> _todoListSAdrPnt = new HashSet<CommToDoDataWrapper>(new CommToDoHashSetComparer());

        /// <summary>
        /// TODOリスト(既存ソースと合わせるために、保留)
        /// </summary>
        public List<CommToDoDataWrapper> ToDoFileDataList = null;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// 直接地番リカバリ
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adminCode">市区町村コード</param>
        /// <param name="inquestObjectId">調査対象ID</param>
        public TiBanUpdateBusinessObject(
            DataService ds,
            string adminCode,
            string inquestObjectId)
        {
            SetInitInfo(ds, adminCode, inquestObjectId, AddToDoDataForAreaChange);
        }

        /// <summary>
        /// コンストラクタ
        /// 直接地番リカバリ
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adminCode">市区町村コード</param>
        /// <param name="inquestObjectId">調査対象ID</param>
        /// <param name="oIDList">oIDList</param>
        public TiBanUpdateBusinessObject(
            DataService ds,
            string adminCode,
            string inquestObjectId,
            List<CommToDoDataWrapper> oIDList)
        {
            SetInitInfo(ds, adminCode, inquestObjectId, AddToDoDataForAreaCodeChange);

            ToDoFileDataList = oIDList;
        }
        #endregion

        #region delegateとenum
        /// <summary>
        /// ToDoデータ生成用delegateを定義する
        /// </summary>
        /// <param name="sAdrPntBase">住所代表点または廃止住所代表点</param>
        public delegate void AddToDoFileDataDeletegate(SAdrPnt sAdrPntBase);

        /// <summary>
        /// 処理対象タイプ
        /// </summary>
        public enum TargetType
        {
            /// <summary>
            /// 住所代表点
            /// </summary>
            SAdrPnt = 1,
        }
        #endregion

        #region プロパティ
        /// <summary>
        /// データサービス
        /// </summary>
        private DataServiceWrapper DSWrapper { get; set; }

        /// <summary>
        /// 市区町村コード
        /// </summary>
        private string AdminCode { get; set; }

        /// <summary>
        /// 調査対象ID
        /// </summary>
        private ulong? InquestObjectId { get; set; }

        /// <summary>
        /// TODO 出力パターン
        /// </summary>
        private AddToDoFileDataDeletegate AddToDoDataFunc { get; set; }
        #endregion

        #region 初期化
        /// <summary>
        /// 初期化情報を設定する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adminCode">市区町村コード</param>
        /// <param name="inquestObjectId">調査対象ID</param>
        /// <param name="addToDoDataFunc">ToDo生成コールバック関数</param>
        public void SetInitInfo(
            DataService ds,
            string adminCode,
            string inquestObjectId,
            AddToDoFileDataDeletegate addToDoDataFunc)
        {
            this.DSWrapper = new DataServiceWrapper(ds);
            this.AdminCode = adminCode;
            this.InquestObjectId = null;
            if (!string.IsNullOrEmpty(inquestObjectId))
            {
                this.InquestObjectId = ulong.Parse(inquestObjectId);
            }

            this.AddToDoDataFunc = addToDoDataFunc;
            this.ToDoFileDataList = new List<CommToDoDataWrapper>();
        }

        /// <summary>
        /// 調査対象ＩＤを設定する
        /// </summary>
        /// <param name="curInquestObjectId">調査対象ＩＤ</param>
        public void SetInquestObjectId(object curInquestObjectId)
        {
            // 調査対象ＩＤを設定する
            this.DSWrapper.InnerDataService.SetCurrentSessionInfo(DataService.CURRENT_INVESTIGATIONID,
                curInquestObjectId);
        }
        #endregion

        #region 直接地番リカバリ 主要ロジック
        /// <summary>
        /// 直接地番リカバリ 主要ロジック
        /// </summary>
        /// <returns>bool</returns>
        public bool DoExecute()
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "直接地番リカバリ",
                LogUtility.LogModel.TraceModel);

            LogUtility.WriteInfo("{0}:{1}", "【直接地番リカバリ(共通)】市区町村コード", this.AdminCode); 

            if (this.InquestObjectId != null)
            {
                // 調査対象ＩＤを保存する
                SetInquestObjectId(this.InquestObjectId);
            }            

            ulong adminOid = 0;
            HashSet<ulong> adminOoazaList = new HashSet<ulong>();         
            HashSet<ulong> directLotNumberOoazaList = new HashSet<ulong>();
            HashSet<ulong> adminKoazaList = new HashSet<ulong>();

            // 住所名所を取得する(市区町村、市区町村と大字と、直接地番、小字)
            GetAdrNameInfo(ref adminOid, ref adminOoazaList, ref directLotNumberOoazaList, ref adminKoazaList);

            HashSet<ulong> adminDisOoazaList = new HashSet<ulong>();      
            HashSet<ulong> adminDisKoazaList = new HashSet<ulong>();

            // 廃止住所名称を取得する
            GetDisAdrNameInfo(ref adminDisOoazaList, ref adminDisKoazaList);

            if (LogUtility.IsDebugEnabled)
            {
                LogUtility.WriteDebug("○市区町村コード{0}の直接地番：市OID({1})、全件数(市、大字):{2}、直接地番:{3}",
                    AdminCode,
                    adminOid,
                    adminOoazaList.Count,
                    string.Join(",", directLotNumberOoazaList));
            }

            if (adminOoazaList.Count > 0)
            {
                // 住所代表点のリカバリ
                RecoveryAreaCode(adminOid,
                    adminOoazaList,
                    directLotNumberOoazaList,
                    adminDisOoazaList);
            }
            
            if (adminKoazaList.Count > 0 || adminDisKoazaList.Count > 0)
            {
                // 小字住所代表点の局番クリア
                ClearAreaCode(adminKoazaList, adminDisKoazaList);
            }

            ToDoFileDataList.AddRange(this._todoListSAdrPnt);

            LogUtility.WriteDataCount("【直接地番リカバリ・住所代表点更新】",
                LogUtility.OperationType.Update,
                this._todoListSAdrPnt.Count);

            logUtility.WriteNormalEnd();
            return true;
        }
        #endregion

        #region 住所名称を取得
        #region TMI住所名称ファイル(大字まで)(行政区域)データ編集対象であるかを判断()
        /// <summary>
        /// TMI住所名称ファイル(大字まで)(行政区域)データ編集対象であるかを判断
        /// </summary>
        /// <param name="adrName">住所名称</param>
        /// <param name="preAdrName">県レベルの住所名称</param>
        /// <param name="munAdrName">市レベルの住所名称</param>
        /// <param name="oazaAdrName">大字レベルの住所名称</param>
        /// <returns>判断結果</returns>
        private bool IsTMIAddrNameOazaAdminAreaEditObj(
            TAdrNameBase adrName, TAdrNameBase preAdrName, TAdrNameBase munAdrName, TAdrNameBase oazaAdrName)
        {
            // 「NGO10CJ271_外部設計書_Donum（共通-行政区域コードで納品データ取得）.doc」
            //  の「10.5.2.5.2. 住所名称ファイル（大字まで）データ編集」部分を参照する
            //  CREO_Donum/Convert/Common/Administrative/AdrNameRelateData.csのIsTMIAddrNameOazaAdminAreaEditObj関数からコピー

            // 住所名称.ネストレベル =「3：小字」の場合、TMI住所名称ファイル（大字まで）を作成せず、除外する
            if (adrName.NestLevel == 3)
            {
                return false;
            }

            // 郡コードの除外
            // 住所名称.ネストレベル =「1：市区町村」の場合、下記の処理を行う
            if (adrName.NestLevel == 1)
            {
                // 住所名称は市レベルの場合、県と市レベルの住所名称を必ず取得できる
                if (preAdrName == null || munAdrName == null)
                {
                    return false;
                }

                // 郡コードの除外
                // 条件1：
                if (preAdrName.AdrCode.ToString().PadLeft(2, '0').Substring(0, 2) != "01" &&
                    preAdrName.AdrCode.ToString() != "47")
                {
                    if (munAdrName.AdrCode >= 300 &&
                        (munAdrName.AdrCode % 20 == 0))
                    {
                        return false;
                    }
                }

                // 条件2：
                if (preAdrName.AdrCode.ToString() == "47" &&
                    munAdrName.AdrCode >= 300)
                {
                    if (munAdrName.AdrCode != 360 &&
                        (munAdrName.AdrCode % 20 == 0))
                    {
                        return false;
                    }
                }

                // 条件3：
                if (preAdrName.AdrCode.ToString() == "47" &&
                    munAdrName.AdrCode == 370)
                {
                    return false;
                }
            }

            // 住所名称.ネストレベル =「2：大字」の場合、下記の処理を行う
            if (adrName.NestLevel == 2)
            {
                // 住所名称.行政区域コード <> 「0」 且つ 住所名称.住所名称.多言語名称
                // (ja-Japn：日本語(漢字+平仮名+片仮名))が未設定
                if (adrName.AdrCode != 0)
                {
                    if (oazaAdrName == null || oazaAdrName.AdrNameMultiLang == null)
                    {
                        return false;
                    }

                    if (oazaAdrName.AdrNameMultiLang["ja-Jpan"] == null ||
                        oazaAdrName.AdrNameMultiLang["ja-Jpan"].Name == null)
                    {
                        return false;
                    }
                }
            }

            // 都道府県範囲以外の住所名称は処理対象とする
            if (adrName.NestLevel == 0)
            {
                return false;
            }

            return true;
        }
        #endregion

        /// <summary>
        /// 住所名称に関する情報を取得する
        /// </summary>
        /// <param name="adminOid">市</param>
        /// <param name="adminOoazaList">市と大字</param>
        /// <param name="directLotNumberOoazaList">直接地番</param>
        /// <param name="adminKoazaList">小字</param>
        public void GetAdrNameInfo(ref ulong adminOid,
            ref HashSet<ulong> adminOoazaList,
            ref HashSet<ulong> directLotNumberOoazaList,
            ref HashSet<ulong> adminKoazaList)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "住所名称に関する情報を取得",
                LogUtility.LogModel.DebugModel);

            TArdNameCacheQuery adrNameCacheQuery = TArdNameCacheQuery.GetGlobalReadOnlyInstance(DSWrapper);
            adrNameCacheQuery.PreloadNestLevel = TArdNameCacheQuery.COAZA_NESTLEVEL;

            if (adrNameCacheQuery.IsExistOfAdminCode(AdminCode))
            {
                // 市区町村コード分の市区町村、大字ラベルの住所名所の取得
                List<TItemBase> adrNameDataList = adrNameCacheQuery.GetAdminOoazaItems(AdminCode);

                if (adrNameDataList.Count > 0)
                {
                    adminOid = adrNameDataList[0].OID;
                    adminOoazaList.Add(adminOid);

                    TAdrName provinceAdrName = (TAdrName)adrNameCacheQuery.GetParent(adminOid);
                    TAdrName adminAdrName = (TAdrName)adrNameDataList[0];

                    for (int i = 1; i < adrNameDataList.Count; i++)
                    {
                        TAdrName ooazaTAdrName = (TAdrName)adrNameDataList[i];
                        adminOoazaList.Add(ooazaTAdrName.OID);

                        // 小字住所名称を取得
                        var koazaLst = adrNameCacheQuery.GetCOAZAList(ooazaTAdrName.OID);
                        if (koazaLst.Count != 0)
                        {
                            // 小字住所名称のOIDを追加
                            foreach (var koazaOid in koazaLst.Select(s => s.OID))
                            {
                                adminKoazaList.Add(koazaOid);
                            }
                        }

                        // 同一住所コード（県コード－市区町村コード－大字コード）で、ユニークな住所名称レコードを取得できている

                        // TMIDBの住所名称データ（ANF）抽出対象外となる場合
                        if (!IsTMIAddrNameOazaAdminAreaEditObj(ooazaTAdrName,
                            provinceAdrName,
                            adminAdrName,
                            ooazaTAdrName))
                        {
                            // 当該大字の住所名称はTMIDBの住所名称データ（ANF）に含まれいない
                            directLotNumberOoazaList.Add(ooazaTAdrName.OID);
                        }
                        else
                        {
                            // TMIDBの住所名称データ（ANF）の抽出対象となる
                            //  CREO_Donum/Convert/Common/Administrative/AdrNameRelateData.csの
                            //      GetTMIAddrNameOazaAdminArea関数を参照
                        }
                    }
                }
            }
            else
            {
                LogUtility.WriteWarning("※市区町村コードが存在しません。{0}", AdminCode);
            }

            logUtility.WriteNormalEnd();
        }

        /// <summary>
        /// 廃止住所名称に関する情報を取得する
        /// </summary>
        /// <param name="adminDisOoazaList">市と大字</param>
        /// <param name="adminDisKoazaList">小字</param>
        public void GetDisAdrNameInfo(
            ref HashSet<ulong> adminDisOoazaList,
            ref HashSet<ulong> adminDisKoazaList)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "廃止住所名称に関する情報を取得",
                LogUtility.LogModel.DebugModel);

            TDisArdNameCacheQuery disAdrNameCacheQuery = TDisArdNameCacheQuery.GetGlobalReadOnlyInstance(DSWrapper);
            disAdrNameCacheQuery.PreloadNestLevel = TDisArdNameCacheQuery.COAZA_NESTLEVEL;

            if (disAdrNameCacheQuery.IsExistOfAdminCode(AdminCode))
            {
                // 市区町村コード分の市区町村、大字ラベルの住所名所の取得
                List<TItemBase> disAdrNameDataList = disAdrNameCacheQuery.GetAdminOoazaItems(AdminCode);

                if (disAdrNameDataList.Count > 0)
                {
                    ulong adminOid = disAdrNameDataList[0].OID;
                    adminDisOoazaList.Add(adminOid);

                    TDisAdrName provinceAdrName = (TDisAdrName)disAdrNameCacheQuery.GetParent(adminOid);
                    TDisAdrName adminAdrName = (TDisAdrName)disAdrNameDataList[0];

                    for (int i = 1; i < disAdrNameDataList.Count; i++)
                    {
                        TDisAdrName ooazaTAdrName = (TDisAdrName)disAdrNameDataList[i];
                        adminDisOoazaList.Add(ooazaTAdrName.OID);

                        var koazaLst = disAdrNameCacheQuery.GetChildList(ooazaTAdrName.OID);
                        if (koazaLst.Count != 0)
                        {
                            foreach (var koazaOid in koazaLst.Select(s => s.OID))
                            {
                                adminDisKoazaList.Add(koazaOid);
                            }
                        }
                    }
                }
            }

            logUtility.WriteNormalEnd();
        }
        #endregion

        #region 住所代表点の更新
        /// <summary>
        /// 住所代表点を更新する
        /// </summary>
        /// <param name="adminOid">市</param>
        /// <param name="adminOoazaList">市と大字</param>
        /// <param name="directLotNumberOoazaList">直接地番</param>
        /// <param name="adminDisOoazaList">廃止大字</param>
        public void RecoveryAreaCode(ulong adminOid,
            HashSet<ulong> adminOoazaList,
            HashSet<ulong> directLotNumberOoazaList,
            HashSet<ulong> adminDisOoazaList)
        {
            if (directLotNumberOoazaList.Count < 1 && adminDisOoazaList.Count < 1)
            {
                LogUtility.WriteDebug("●直接地番または廃止住所名称に対応する住所代表点がない：市区町村コード:({0})、住所名所件数:({1})",
                    AdminCode,
                    adminOoazaList.Count);
                return;
            }

            string targetType = "SAdrPnt";

            List<SAdrPntBase> adminSAdrPntBaseList = new List<SAdrPntBase>();
            List<SAdrPntBase> directLotNumberOoazaSAdrPntBaseList = new List<SAdrPntBase>();
            List<SAdrPntBase> areaCodeKoazaSAdrPntBaseList = new List<SAdrPntBase>();
            HashSet<ulong> othersAreaCode = new HashSet<ulong>();

            ulong[] arrAdrName = adminOoazaList.ToArray();
            ulong[] arrDisAdrName = adminDisOoazaList.ToArray();            

            // 局番を参照している大字レベルの住所代表点の住所コード（都道府県、市区町村、大字コード）と局番を抽出する
            var tempSAdrPntBaseList = LoadSAdrPntByAdrName(arrAdrName, arrDisAdrName);

            LogUtility.WriteDataCount(string.Format("○検索対象住所代表点"),
                LogUtility.OperationType.Select,
                tempSAdrPntBaseList == null ? 0 : tempSAdrPntBaseList.Count,
                LogUtility.LogModel.DebugModel);

            foreach (SAdrPnt curSAdrPntBase in tempSAdrPntBaseList)
            {
                if (curSAdrPntBase.AdrName != null && curSAdrPntBase.AdrName.OID == adminOid)
                {
                    if (curSAdrPntBase.AdrLvlCode == SAdrPnt.Code.AdrLvlCode_2)
                    {
                        // 市区町村レベルの住所名称を参照する住所代表点の住所代表点レベルコードが2 市区町村の場合、
                        // 該当する住所代表点を更新対象とする
                        adminSAdrPntBaseList.Add(curSAdrPntBase);
                    }

                    // 住所代表点は市区町村の住所名称を参照している
                    continue;
                }

                // TMIDBの住所名称データ（ANF）として出力されない住所コードを持つ組み合わせを、１）のリストから抽出する
                if (curSAdrPntBase.AdrName != null && directLotNumberOoazaList.Contains(curSAdrPntBase.AdrName.OID))
                {
                    // 住所代表点は大字の住所名称を参照している
                    // 当該大字の住所名称はTMIDBの住所名称データ（ANF）に含まれいない
                    // GEN出力フラグ = 1
                    // 座標値 = 有効座標
                    if (curSAdrPntBase.AdrLvlCode == SAdrPnt.Code.AdrLvlCode_3
                        && curSAdrPntBase.GENOutputFlg == 1
                        && IsValidCoordinate(curSAdrPntBase.Geometry) == true)
                    {
                        // 大字レベルの住所名称を参照する住所代表点の住所代表点レベルコードが3 大字の場合、
                        // 該当する住所代表点を抽出対象とする                            
                        if (curSAdrPntBase.AreaCodeAry != null &&
                            curSAdrPntBase.AreaCodeAry.Count > 0)
                        {
                            // 住所代表点は局番を参照している。
                            directLotNumberOoazaSAdrPntBaseList.Add(curSAdrPntBase);
                        }
                    }

                    continue;
                }

                // 廃止住所名称を参照している
                if (curSAdrPntBase.DisAdrName != null)
                {
                    // 住所代表点レベル = 3:大字
                    // GEN出力フラグ = 1
                    // 座標値 = 有効座標
                    if (curSAdrPntBase.AdrLvlCode == SAdrPnt.Code.AdrLvlCode_3
                        && curSAdrPntBase.GENOutputFlg == 1
                        && IsValidCoordinate(curSAdrPntBase.Geometry) == true)
                    {
                        // 大字レベルの住所名称を参照する住所代表点の住所代表点レベルコードが3 大字の場合、
                        // 該当する住所代表点を抽出対象とする                            
                        if (curSAdrPntBase.AreaCodeAry != null &&
                            curSAdrPntBase.AreaCodeAry.Count > 0)
                        {
                            // 住所代表点は局番を参照している。
                            directLotNumberOoazaSAdrPntBaseList.Add(curSAdrPntBase);
                        }                            
                    }                                         

                    continue;
                }

                // 住所代表点は大字の住所名称を参照している。
                // 当該大字の住所名称はTMIDBの住所名称データ（ANF）
                if (curSAdrPntBase.AdrLvlCode == SAdrPnt.Code.AdrLvlCode_3)
                {
                    // 住所代表点の住所代表点レベルコードが3：大字である                           
                    if (curSAdrPntBase.AreaCodeAry != null)
                    {
                        // 住所代表点は局番を参照している
                        othersAreaCode.UnionWith(curSAdrPntBase.AreaCodeAry.Where(o => o != null).Select(o => o.OID));
                    }
                }                
            }

            LogUtility.WriteDataCount(string.Format("○対象市区町村住所代表点{0}", targetType.ToString()),
                LogUtility.OperationType.Select,
                adminSAdrPntBaseList == null ? 0 : adminSAdrPntBaseList.Count,
                LogUtility.LogModel.DebugModel);

            LogUtility.WriteDataCount(string.Format("○対象大字住所代表点{0}", targetType.ToString()),
                LogUtility.OperationType.Select,
                directLotNumberOoazaSAdrPntBaseList == null ? 0 : directLotNumberOoazaSAdrPntBaseList.Count,
                LogUtility.LogModel.DebugModel);

            // NULLとなっている局番が存在するかどうかをチェックした市区町村代表点
            HashSet<ulong> checkedNullAdminList = new HashSet<ulong>();

            // 直接地番に対応する代表点から参照されている局番を処理する
            foreach (SAdrPnt curSAdrPntBase in directLotNumberOoazaSAdrPntBaseList)
            {
                if (curSAdrPntBase.AreaCodeAry != null &&
                       curSAdrPntBase.AreaCodeAry.Count > 0)
                {
                    bool bHaveNullTAreaCode = false;
                    foreach (TAreaCode curTAreaCode in curSAdrPntBase.AreaCodeAry)
                    {
                        if (curTAreaCode == null)
                        {
                            bHaveNullTAreaCode = true;
                            continue;
                        }

                        if (!othersAreaCode.Contains(curTAreaCode.OID))
                        {
                            // 直接地番に対応する代表点からのみ参照されている場合
                            foreach (SAdrPnt adminSAdrPntBase in adminSAdrPntBaseList)
                            {
                                FW.Utilities.DMCollection<TAreaCode> areaCodeList = adminSAdrPntBase.AreaCodeAry;

                                if (areaCodeList != null &&
                                    areaCodeList.Where(o => o != null).Any(o => o.OID == curTAreaCode.OID))
                                {
                                    if (LogUtility.IsDebugEnabled)
                                    {
                                        LogUtility.WriteDebug("○既に、市区町村に対応する{0}が局番を参照している：OID({1})、既存の局番({2})、当該局番({3})",
                                            targetType.ToString(),
                                            adminSAdrPntBase.OID,
                                            string.Join(",", areaCodeList.Where(o => o != null).Select(o => o.OID)),
                                            curTAreaCode.OID);
                                    }

                                    continue;
                                }

                                // 市区町村代表点から参照する
                                if (areaCodeList == null)
                                {
                                    areaCodeList = new FW.Utilities.DMCollection<TAreaCode>();
                                }

                                if (LogUtility.IsTraceEnabled)
                                {
                                    LogUtility.WriteTrace("○市区町村に対応する{0}から参照する：OID({1})、事前の局番({2})、当該局番({3})",
                                        targetType.ToString(),
                                        adminSAdrPntBase.OID,
                                        string.Join(",", areaCodeList.Where(o => o != null).Select(o => o.OID)),
                                        curTAreaCode.OID);
                                }

                                areaCodeList.Add(curTAreaCode);
                                adminSAdrPntBase.AreaCodeAry = areaCodeList;

                                if (!checkedNullAdminList.Contains(adminSAdrPntBase.OID))
                                {
                                    // 更新対象住所代表点（市区町村レベルまたは大字レベルの住所代表点）の局番リスト（AreaCodeAry）
                                    // にNULLとなっている局番が存在する場合、その局番（TAreaCode）を局番リスト（AreaCodeAry）から削除して、
                                    // ワーニングメッセージを出力する。
                                    checkedNullAdminList.Add(adminSAdrPntBase.OID);

                                    if (areaCodeList.Any(o => o == null))
                                    {
                                        LogUtility.Write(UF_Fluere_MsgId.MSGID_UF20003033, new object[] { adminSAdrPntBase.OID });

                                        FW.Utilities.DMCollection<TAreaCode> nullAreaCodeList = areaCodeList;
                                        areaCodeList = new FW.Utilities.DMCollection<TAreaCode>();

                                        foreach (TAreaCode notNullTAreaCode in nullAreaCodeList)
                                        {
                                            if (notNullTAreaCode != null)
                                            {
                                                areaCodeList.Add(notNullTAreaCode);
                                            }
                                        }

                                        adminSAdrPntBase.AreaCodeAry = areaCodeList;
                                    }
                                }

                                if (LogUtility.IsDebugEnabled)
                                {
                                    LogUtility.WriteDebug("○市区町村に対応する{0}から参照する：OID({1})、事後の局番({2})、当該局番({3})",
                                        targetType.ToString(),
                                        adminSAdrPntBase.OID,
                                        string.Join(",", areaCodeList.Where(o => o != null).Select(o => o.OID)),
                                        curTAreaCode.OID);
                                }

                                // ToDOデータを生成
                                if (this.AddToDoDataFunc != null)
                                {
                                    this.AddToDoDataFunc(adminSAdrPntBase);
                                }
                            }
                        }
                        else
                        {
                            // 直接地番に対応する代表点以外から参照されている場合
                            LogUtility.WriteDebug("●直接地番に対応する{0}以外から参照：OID({1})、当該局番({2})",
                                targetType.ToString(),
                                curSAdrPntBase.OID,
                                curTAreaCode.OID);
                        }
                    }

                    if (LogUtility.IsDebugEnabled)
                    {
                        LogUtility.WriteDebug("○直接地番に対応する{0}の局番の参照を削除：OID({1})、当該局番({2})",
                            targetType.ToString(),
                            curSAdrPntBase.OID,
                            string.Join(",", curSAdrPntBase.AreaCodeAry.Where(o => o != null).Select(o => o.OID)));
                    }

                    // 大字代表点からの参照を削除
                    curSAdrPntBase.AreaCodeAry = null;
                    if (bHaveNullTAreaCode)
                    {
                        LogUtility.Write(UF_Fluere_MsgId.MSGID_UF20003033, new object[] { curSAdrPntBase.OID });
                    }

                    // ToDOデータを生成
                    if (this.AddToDoDataFunc != null)
                    {
                        this.AddToDoDataFunc(curSAdrPntBase);
                    }
                }
            }
        }

        #region 小字住所代表点の局番をクリア
        /// <summary>
        /// 小字住所代表点の局番をクリア
        /// </summary>
        /// <param name="adminKoazaList">小字</param>
        /// <param name="adminDisKoazaList">廃止小字</param>
        public void ClearAreaCode(
              HashSet<ulong> adminKoazaList,
              HashSet<ulong> adminDisKoazaList)
        {
            ulong[] arrAdrName = adminKoazaList.ToArray();
            ulong[] arrDisAdrName = adminDisKoazaList.ToArray();       

            // 局番を参照している小字レベルの住所代表点の住所コード（都道府県、市区町村、小字コード）と局番を抽出する
            var tempSAdrPntBaseList = LoadSAdrPntByAdrName(arrAdrName, arrDisAdrName);

            LogUtility.WriteDataCount(string.Format("○検索対象住所代表点"),
                LogUtility.OperationType.Select,
                tempSAdrPntBaseList == null ? 0 : tempSAdrPntBaseList.Count,
                LogUtility.LogModel.DebugModel);

            foreach (var adrPnt in tempSAdrPntBaseList)
            {
                // 住所代表点レベル = 4:小字
                // GEN出力フラグ = null
                // 座標値 = 有効座標
                if (adrPnt.AdrLvlCode == 4
                  && adrPnt.GENOutputFlg == null
                  && IsValidCoordinate(adrPnt.Geometry) == true)
                {
                    // 局番ありならクリア
                    if (adrPnt.AreaCodeAry != null && adrPnt.AreaCodeAry.Count > 0)
                    {
                        adrPnt.AreaCodeAry = null;

                        // ToDOデータを生成
                        if (this.AddToDoDataFunc != null)
                        {
                            this.AddToDoDataFunc(adrPnt);
                        }
                    }
                }
            }
        }
        #endregion

        /// <summary>
        /// 住所名称と廃止住所名称を指定し、住所代表点を取得する
        /// </summary>
        /// <param name="arrAdrName">住所名称一覧</param>
        /// <param name="arrDisAdrName">廃止住所名称一覧</param>
        /// <returns>住所代表点リスト</returns>
        private List<SAdrPnt> LoadSAdrPntByAdrName(ulong[] arrAdrName, ulong[] arrDisAdrName)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                string.Format("{0}情報を取得", "SAdrPnt"),
                LogUtility.LogModel.DebugModel);

            List<SAdrPnt> retList;

            QueryItemsCondition qic = new QueryItemsCondition();
            qic.TypeIDs.Add("SAdrPnt");

            SqlConditionExpression q1 = null;
            
            // 住所名称を指定
            var qAdrName = new SqlConditionExpression("AdrName", QueryItemOperator.In, arrAdrName.Select(n => n.ToString()).ToArray());

            // 廃止住所名称を指定
            var qDisAdrName = new SqlConditionExpression("DisAdrName", QueryItemOperator.In, arrDisAdrName.Select(n => n.ToString()).ToArray());
            
            if (arrAdrName.Count() > 0 && arrDisAdrName.Count() > 0)
            {
                q1 = SqlConditionExpression.Or(qAdrName, qDisAdrName);
            }
            else if (arrAdrName.Count() > 0)
            {
                q1 = qAdrName;
            }
            else if (arrDisAdrName.Count() > 0)
            {
                q1 = qDisAdrName;
            }
                        
            // 住所代表点レベルコード が ２または３または４
            var q2 = new SqlConditionExpression("AdrLvlCode", QueryItemOperator.In, new string[] { "2", "3", "4" });

            qic.ConditionExpression = SqlConditionExpression.And(q1, q2);

            // 局番を抽出
            QueryItemsPostProcess qipp = new QueryItemsPostProcess();
            qipp.Flags = QueryItemsPostProcessFlags.GetReferences;
            qipp.TypeIDs.Add("TAreaCode");
            qic.QueryItemsPostProcess = qipp;

            // 住所代表点を抽出
            List<GeoItem> geoItemList = DSWrapper.QueryItems(qic);
            if (geoItemList == null)
            {
                retList = new List<SAdrPnt>();
            }
            else
            {
                retList = geoItemList.OfType<SAdrPnt>().ToList();
            }            

            logUtility.WriteNormalEnd();
            return retList;
        }
        #endregion

        #region 座標値が有効座標が判定
        /// <summary>
        /// 有効座標かどうか判定する
        /// </summary>
        /// <param name="coord">座標</param>
        /// <returns>True:有効座標</returns>
        private bool IsValidCoordinate(FW.TMIGeometry.Coordinate coord)
        {
            // 無効座標を取得
            var invalid_lng = DSWrapper.InnerDataService.GetInvalidLongitude();
            var invalid_lat = DSWrapper.InnerDataService.GetInvalidLatitude();            
           
            if (coord.Longitude == invalid_lng && coord.Longitude == invalid_lng)
            {
                return false;
            }
            else
            {
                return true;
            }
        }
        #endregion

        #region 編集DB反映用のToDOリスト用データ作成
        /// <summary>
        /// 編集DB反映用のToDOリスト用データ作成(行政変更用)
        /// </summary>
        /// <param name="sAdrPntBase">住所代表点</param>
        public void AddToDoDataForAreaChange(SAdrPnt sAdrPntBase)
        {
            CommToDoDataWrapper toDoData = new CommToDoDataWrapper();

            // 行政変更用
            toDoData.Latitude = sAdrPntBase.Geometry.Latitude.ToString();
            toDoData.Longitude = sAdrPntBase.Geometry.Longitude.ToString();
            toDoData.WorkStatus = CommonConstants.WORK_STATUS_0;

            // TODOファイルの書式を合わせて設定する必要がある
            toDoData.OID = sAdrPntBase.OID;
            toDoData.QueryObjectDB = this.DSWrapper.InnerDataService.GetConnectionContext().DataSourceID;
            toDoData.SurveyObjectId = this.InquestObjectId == null ? string.Empty : this.InquestObjectId.ToString();

            // 差分区分
            toDoData.SetFieldByDefaultName(1, CommToDoDataWrapper.ApplyTypes.Update);

            // タイプ
            toDoData.SetFieldByDefaultName(2, sAdrPntBase.EntityType);

            this._todoListSAdrPnt.Add(toDoData);            
        }

        /// <summary>
        /// 編集DB反映用のToDOリスト用データ作成(局番更新用)
        /// </summary>
        /// <param name="sAdrPntBase">住所代表点</param>
        public void AddToDoDataForAreaCodeChange(SAdrPnt sAdrPntBase)
        {
            CommToDoDataWrapper toDoData = new CommToDoDataWrapper();

            // 局番更新用
            toDoData.Latitude = null;
            toDoData.Longitude = null;
            toDoData.WorkStatus = null;

            // TODOファイルの書式を合わせて設定する必要がある
            toDoData.OID = sAdrPntBase.OID;
            toDoData.QueryObjectDB = this.DSWrapper.InnerDataService.GetConnectionContext().DataSourceID;
            toDoData.SurveyObjectId = this.InquestObjectId == null ? string.Empty : this.InquestObjectId.ToString();

            // 差分区分
            toDoData.SetFieldByDefaultName(1, CommToDoDataWrapper.ApplyTypes.Update);

            // タイプ
            toDoData.SetFieldByDefaultName(2, sAdrPntBase.EntityType);

            this._todoListSAdrPnt.Add(toDoData);
        }
        #endregion
    }
}
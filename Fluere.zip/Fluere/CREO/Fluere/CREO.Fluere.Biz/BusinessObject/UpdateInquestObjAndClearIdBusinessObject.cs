﻿using System;
using System.Data;
using System.Reflection;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Common.Configuration;
using CREO.FW.ExceptionHandling;
using CREO.Materia;
using CREO.Materia.API;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 調査対象データの更新と調査対象IDのクリア
    /// </summary>
    [Obsolete("このクラスは廃止される予定です。代わりに'UpdateInquestObjBusinessObject' を使用してください。", false)]
    public class UpdateInquestObjAndClearIdBusinessObject : AbstractInquestObjBusinessObject
    {
        #region クラス属性定義（外部より受入）
        /// <summary>
        /// 調査対象データ
        /// </summary>
        private DataTable _inquestObjectDT = null;

        /// <summary>
        /// ファイル対象
        /// </summary>
        private IConfigurationManager _configurationManager = null;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="dt">更新用の調査対象データ</param>
        /// <param name="configMgr">ファイル対象</param>
        public UpdateInquestObjAndClearIdBusinessObject(DataTable dt, IConfigurationManager configMgr)
        {
            _inquestObjectDT = dt;

            _configurationManager = configMgr;
        }
        #endregion

        #region 主要処理のインタフェイス
        /// <summary>
        /// 主な実行
        /// </summary>
        protected override void DoExecute()
        {
            // 調査対象反映APIの呼び出し
            int result = RESULT_SUCCEED;

            DataRow dr = this._inquestObjectDT.Rows[0];
            string currInquestObjID = dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID].ToString();

            try
            {
                result = ReflectSurveyObjBatch.UpdateSurveyObj(this._inquestObjectDT, _dBPMateria);
            }
            catch (Exception ex)
            {
                string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                throw new BusinessLogicException(msgId, new string[] { currInquestObjID }, ex);
            }

            // 戻り値が0以外の場合、異常をスロー
            if (result != RESULT_SUCCEED)
            {
                string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                throw new BusinessLogicException(msgId, new string[] { currInquestObjID });
            }

            // 調査対象IDのクリア
            UpdateBatchDefFile(string.Empty);
        }
        #endregion

        #region バッチ設定ファイルの更新
        /// <summary>
        /// バッチ設定ファイルに、調査対象IDを埋め込むこと
        /// </summary>
        /// <param name="inquestObjID">調査対象ID</param>
        private void UpdateBatchDefFile(string inquestObjID)
        {
            try
            {
                // バッチ設定情報
                object batchDefObj = _configurationManager.Configuration;

                // 属性の取得
                MemberInfo[] mems = batchDefObj.GetType().FindMembers(
                    MemberTypes.Property,
                    BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance,
                    null,
                    null);

                bool inquestObjIdFound = false;

                // 調査対象ID属性の確定
                foreach (MemberInfo mem in mems)
                {
                    if (mem.Name == "InquestObjectId")
                    {
                        switch (mem.MemberType)
                        {
                            case MemberTypes.Field:
                                ((FieldInfo)mem).SetValue(batchDefObj, inquestObjID);
                                break;
                            case MemberTypes.Property:
                                ((PropertyInfo)mem).SetValue(batchDefObj, inquestObjID, null);
                                break;
                            default:
                                throw new ArgumentException("MemberInfo must be if type FieldInfo or PropertyInfo", "member");
                        }

                        inquestObjIdFound = true;
                        break;
                    }
                }

                if (!inquestObjIdFound)
                {
                    string msg = "バッチ設定ファイルに、調査対象IDを「InquestObjectId」に命名してください。";
                    throw new BusinessLogicException(msg);
                }

                // バッチ設定ファイルへ更新
                _configurationManager.Save();
            }
            catch (Exception e)
            {
                // 調査対象IDを削除出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000006;

                throw new BusinessLogicException(msgId, new string[] { _configurationManager.FullName }, e);

                throw e;
            }
        }
        #endregion
    }
}

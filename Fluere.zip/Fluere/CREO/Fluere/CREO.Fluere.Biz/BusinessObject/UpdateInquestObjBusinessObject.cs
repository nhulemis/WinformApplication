﻿using System.Data;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;
using CREO.Materia;
using CREO.Materia.API;

namespace CREO.Fluere.Biz.BusinessObject
{
    /// <summary>
    /// 調査対象データの更新
    /// </summary>
    public class UpdateInquestObjBusinessObject : AbstractInquestObjBusinessObject
    {
        #region クラス属性定義（外部より受入）
        /// <summary>
        /// 調査対象データ
        /// </summary>
        private DataTable _inquestObjectDT = null;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="dt">更新用の調査対象データ</param>
        public UpdateInquestObjBusinessObject(
            DataTable dt)
        {
            _inquestObjectDT = dt;
        }
        #endregion

        #region 主要処理のインタフェイス
        /// <summary>
        /// 主な実行
        /// </summary>
        protected override void DoExecute()
        {
            // 調査対象反映APIの呼び出し
            int result = RESULT_SUCCEED;
            
            DataRow dr = this._inquestObjectDT.Rows[0];
            string currInquestObjID = dr[ReflectSurveyObjBatchConst.FIELDNAME_SURVEYOBJECTID].ToString();

            try
            {
                result = ReflectSurveyObjBatch.UpdateSurveyObj(this._inquestObjectDT, _dBPMateria);
            }
            catch
            {
                string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                throw new BusinessLogicException(msgId, new string[] { currInquestObjID });
            }

            // 戻り値が0以外の場合、異常をスロー
            if (result != RESULT_SUCCEED)
            {
                string msgId = UF_Fluere_MsgId.MSGID_UF20003001;
                throw new BusinessLogicException(msgId, new string[] { currInquestObjID });
            }
        }
        #endregion
    }
}

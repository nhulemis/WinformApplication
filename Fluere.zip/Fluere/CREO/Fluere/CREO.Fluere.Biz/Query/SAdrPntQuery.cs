﻿using System.Collections.Generic;
using System.Linq;
using CREO.DataModel;
using CREO.DS;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 住所代表点
    /// </summary>
    public class SAdrPntQuery
    {
        #region 住所代表点データモデル（市区町村）の取得
        /// <summary>
        /// 住所代表点データモデル（市区町村）の取得
        /// 検索条件:GEN出力フラグ = 1、住所名称参照オブジェクトID = adrNameOID、局番 ≠ null
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrNameOID">親表実体OID</param>
        /// <returns>GeoItem（リスト）</returns>
        public static List<GeoItem> LoadSAdrPntByOid(DataService ds, ulong adrNameOID)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(SAdrPnt).Name);

            // 実体OID = 親表実体OID 
            IConditionExpression q1 = new SqlConditionExpression(
                "AdrName", QueryItemOperator.Equal, adrNameOID.ToString());

            // GEN出力フラグ = 1
            IConditionExpression q2 = new SqlConditionExpression(
                "GENOutputFlg", QueryItemOperator.Equal, 1);

            // 局番 ≠ NULL
            IConditionExpression q3 = new SqlConditionExpression(
                "AreaCodeAry[*]", QueryItemOperator.NotEqual, string.Empty);

            // 検索条件組合せ(And)
            qic.ConditionExpression = q1.And(q1, q2, q3);

            // 検索実行
            List<GeoItem> result = ds.QueryItems(qic);

            // 戻り値
            return result;
        }
        #endregion

        #region 住所代表点データモデルの取得
        /// <summary>
        /// 住所代表点データモデルの取得
        /// 条件:住所名称参照オブジェクトID in adrNameOIDList、GEN出力フラグ = 1、局番 ≠ NULL
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrNameOIDList">住所名称のOIDリスト</param>
        /// <returns>GeoItem（リスト）</returns>
        public static List<GeoItem> LoadSAdrPntByOidList(DataService ds, string[] adrNameOIDList)
        {
            // データ検索対象作成
            QueryItemsCondition qic1 = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic1.TypeIDs.Add(typeof(SAdrPnt).Name);

            // 住所名称参照オブジェクトID = 住所名称．オブジェクトID
            IConditionExpression q1 = new SqlConditionExpression(
                "AdrName", QueryItemOperator.In, adrNameOIDList);

            // GEN出力フラグ = 1
            IConditionExpression q2 = new SqlConditionExpression(
                "GENOutputFlg", QueryItemOperator.Equal, 1);

            // 局番 ≠ NULL
            IConditionExpression q3 = new SqlConditionExpression(
                "AreaCodeAry[*]", QueryItemOperator.NotEqual, string.Empty);

            // 検索条件組合せ(And)
            qic1.ConditionExpression = q1.And(q1, q2, q3);

            // 検索実行
            List<GeoItem> result = ds.QueryItems(qic1);

            // 戻り値
            return result;
        }

        /// <summary>
        /// 住所代表点データモデルの取得
        ///  条件:住所名称参照オブジェクトID in adrNameOIDList、GEN出力フラグ = 1
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrNameOIDList">住所名称OIDリスト</param>
        /// <returns>GeoItem（リスト）</returns>
        public static List<GeoItem> LoadSAdrPntByOidListNoAreaCode(DataService ds, string[] adrNameOIDList)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(SAdrPnt).Name);

            // 実体OID = 親表実体OID 
            IConditionExpression q1 = new SqlConditionExpression(
                "AdrName", QueryItemOperator.In, adrNameOIDList);

            // GEN出力フラグ = 1
            IConditionExpression q2 = new SqlConditionExpression(
                "GENOutputFlg", QueryItemOperator.Equal, 1);

            // 検索条件組合せ(And)
            qic.ConditionExpression = q1.And(q1, q2);

            // 検索実行
            List<GeoItem> result = ds.QueryItems(qic);

            // 戻り値
            return result;
        }

        #endregion

        #region 住所名称、GEN出力フラグ、住所代表点レベルによって、住所代表点を検索する
        /// <summary>
        /// 住所名称、GEN出力フラグ、住所代表点レベルによって、住所代表点を検索する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adrNameOIDList">住所名称OIDリスト</param>
        /// <returns>住所代表点データ</returns>
        public static List<SAdrPnt> LoadSAdrPntByTAdrName(DataService ds, string[] adrNameOIDList)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(住所代表点)設定
            qic.TypeIDs.Add(typeof(SAdrPnt).Name);

            // 検索条件：≪住所名称≫
            SqlConditionExpression q1 = new SqlConditionExpression("AdrName", QueryItemOperator.In, adrNameOIDList);

            // 検索条件：≪廃止住所名称≫
            SqlConditionExpression q2 = new SqlConditionExpression("DisAdrName", QueryItemOperator.Equal, null);

            // 検索条件：GEN出力フラグ
            SqlConditionExpression q3 = new SqlConditionExpression("GENOutputFlg", QueryItemOperator.Equal, null);

            // 検索条件：住所代表点レベルコード>=3
            SqlConditionExpression q4 = new SqlConditionExpression("AdrLvlCode", QueryItemOperator.GreatEqual, 3);

            // 検索条件：住所代表点レベルコード<=8
            SqlConditionExpression q5 = new SqlConditionExpression("AdrLvlCode", QueryItemOperator.LessEqual, 8);

            QueryItemsPostProcess qipp = new QueryItemsPostProcess();
            qipp.Flags = QueryItemsPostProcessFlags.GetReferences;
            qipp.TypeIDs.Add("TAdrName");
            qic.QueryItemsPostProcess = qipp;

            // 検索条件組合せ
            qic.ConditionExpression = SqlConditionExpression.And(q1, q2, q3, q4, q5);

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをSAdrPntに変換する
            List<SAdrPnt> resultSAdrPnt = resultItem.OfType<SAdrPnt>().ToList();

            return resultSAdrPnt;
        }
        #endregion

        #region 廃止住所名称、GEN出力フラグ、住所代表点レベルによって、住所代表点を検索する
        /// <summary>
        /// 廃止住所名称、GEN出力フラグ、住所代表点レベルによって、住所代表点を検索する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adrNameOIDList">廃止住所名称OIDリスト</param>
        /// <param name="adrLvlCodeStart">住所代表点レベルコード開始</param>
        /// <param name="adrLvlCodeEnd">住所代表点レベルコード最後</param>
        /// <returns>住所代表点データ</returns>
        public static List<SAdrPnt> LoadSAdrPntBySDisAdrName(
            DataService ds, string[] adrNameOIDList, int adrLvlCodeStart, int adrLvlCodeEnd)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(住所代表点)設定
            qic.TypeIDs.Add(typeof(SAdrPnt).Name);

            // 検索条件：≪住所名称≫
            SqlConditionExpression q1 = new SqlConditionExpression("AdrName", QueryItemOperator.Equal, null);

            // 検索条件：≪廃止住所名称≫
            SqlConditionExpression q2 = new SqlConditionExpression("DisAdrName", QueryItemOperator.In, adrNameOIDList);

            // 検索条件：GEN出力フラグ
            SqlConditionExpression q3 = new SqlConditionExpression("GENOutputFlg", QueryItemOperator.Equal, null);

            // 検索条件：住所代表点レベルコード>=3
            SqlConditionExpression q4 = new SqlConditionExpression("AdrLvlCode", QueryItemOperator.GreatEqual, adrLvlCodeStart);

            // 検索条件：住所代表点レベルコード<=8
            SqlConditionExpression q5 = new SqlConditionExpression("AdrLvlCode", QueryItemOperator.LessEqual, adrLvlCodeEnd);

            QueryItemsPostProcess qipp = new QueryItemsPostProcess();
            qipp.Flags = QueryItemsPostProcessFlags.GetReferences;
            qipp.TypeIDs.Add("TDisAdrName");
            qic.QueryItemsPostProcess = qipp;

            // 検索条件組合せ
            qic.ConditionExpression = SqlConditionExpression.And(q1, q2, q3, q4, q5);

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをSAdrPntに変換する
            List<SAdrPnt> resultSAdrPnt = resultItem.OfType<SAdrPnt>().ToList();

            return resultSAdrPnt;
        }
        #endregion
    }
}

﻿using System.Collections.Generic;
using System.Linq;
using CREO.CommonBusinessLogic.TMIDB;
using CREO.DataModel;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Data;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// DRM道路（基本道路、全道路）Query
    /// </summary>
    public class SDRMRoadQuery
    {
        #region DRM基本道路リストの整備
        /// <summary>
        /// DRM基本道路リストの整備
        /// </summary>
        /// <param name="listSDRMRoadBasic">DRM基本道路リスト</param>
        /// <returns>key/value : DRM基本道路のノード１番号とノード2番号を組み合/DRM基本道路リスト</returns>
        public static Dictionary<string, List<SDRMRoadBasic>> MadeSDRMRoadBasicDict(List<SDRMRoadBasic> listSDRMRoadBasic)
        {
            // DRM基本道路Dic
            Dictionary<string, List<SDRMRoadBasic>> resultSDRMRoadBasic = new Dictionary<string, List<SDRMRoadBasic>>();

            // DRM基本道路
            if (listSDRMRoadBasic != null)
            {
                string nodeNoNew = string.Empty;

                foreach (SDRMRoadBasic item in listSDRMRoadBasic)
                {
                    nodeNoNew = string.Format("0{0}0{1}",
                           (string)item.NodeNo1,
                           (string)item.NodeNo2);

                    if (resultSDRMRoadBasic.ContainsKey(nodeNoNew))
                    {
                        List<SDRMRoadBasic> tempList = resultSDRMRoadBasic[nodeNoNew];
                        tempList.Add(item);
                        resultSDRMRoadBasic[nodeNoNew] = tempList;
                    }
                    else
                    {
                        List<SDRMRoadBasic> tempList = new List<SDRMRoadBasic>();
                        tempList.Add(item);
                        resultSDRMRoadBasic.Add(nodeNoNew, tempList);
                    }

                    if (item.NodeNo2 != item.NodeNo1)
                    {
                        nodeNoNew = string.Format("0{0}0{1}",
                                (string)item.NodeNo2,
                                (string)item.NodeNo1);

                        if (resultSDRMRoadBasic.ContainsKey(nodeNoNew))
                        {
                            List<SDRMRoadBasic> tempList = resultSDRMRoadBasic[nodeNoNew];
                            tempList.Add(item);
                            resultSDRMRoadBasic[nodeNoNew] = tempList;
                        }
                        else
                        {
                            List<SDRMRoadBasic> tempList = new List<SDRMRoadBasic>();
                            tempList.Add(item);
                            resultSDRMRoadBasic.Add(nodeNoNew, tempList);
                        }
                    }
                }
            }

            // DRM基本道路
            return resultSDRMRoadBasic;
        }
        #endregion

        #region DRM全道路リストの整備
        /// <summary>
        /// DRM全道路リストの整備
        /// </summary>
        /// <param name="listSDRMRoadAll">DRM全道路リスト</param>
        /// <returns>key/value :DRM全道路ディクショナリーのリスト（一つ目が全道路ノードキー、二つ目が基本道路ノードキー）</returns>
        public static List<Dictionary<string, List<SDRMRoadAll>>> MadeSDRMRoadAllDict(
                        List<SDRMRoadAll> listSDRMRoadAll)
        {
            List<Dictionary<string, List<SDRMRoadAll>>> retListSDRMRoadAll =
                                        new List<Dictionary<string, List<SDRMRoadAll>>>();

            // DRM全道路のディクショナリー（キーが全道路のノード番号）
            Dictionary<string, List<SDRMRoadAll>> sDRMRoadAllByNodeAll = 
                                        new Dictionary<string, List<SDRMRoadAll>>();

            // DRM全道路のディクショナリー（キーが基本道路のノード番号）
            Dictionary<string, List<SDRMRoadAll>> sDRMRoadAllByNodeBasic = 
                                        new Dictionary<string, List<SDRMRoadAll>>();

            // DRM全道路のリストがnull以外の場合
            if (listSDRMRoadAll != null)
            {
                string nodeAll = string.Empty;
                string nodeBasic = string.Empty;

                foreach (SDRMRoadAll item in listSDRMRoadAll)
                {
                    // DRM全道路の全道路ノード１とノード２の順でキーの作成
                    nodeAll = string.Format("{0}{1}", (string)item.NodeNo1, (string)item.NodeNo2);

                    // ディクショナリーにキーが存在する場合、キーに対するDRM全道路リストに追加
                    if (sDRMRoadAllByNodeAll.ContainsKey(nodeAll))
                    {
                        List<SDRMRoadAll> tempList = sDRMRoadAllByNodeAll[nodeAll];
                        tempList.Add(item);
                        sDRMRoadAllByNodeAll[nodeAll] = tempList;
                    }
                    else
                    {
                        // ディクショナリーにキーが存在しない場合、キーとヴァリューの追加
                        List<SDRMRoadAll> tempList = new List<SDRMRoadAll>();
                        tempList.Add(item);
                        sDRMRoadAllByNodeAll.Add(nodeAll, tempList);
                    }

                    // 全道路のノード２とノード１の順でキーの作成
                    if (item.NodeNo2 != item.NodeNo1)
                    {
                        nodeAll = string.Format("{0}{1}",
                                (string)item.NodeNo2,
                                (string)item.NodeNo1);

                        // ディクショナリーにキーが存在する場合、キーに対するDRM全道路リストに追加
                        if (sDRMRoadAllByNodeAll.ContainsKey(nodeAll))
                        {
                            List<SDRMRoadAll> tempList = sDRMRoadAllByNodeAll[nodeAll];
                            tempList.Add(item);
                            sDRMRoadAllByNodeAll[nodeAll] = tempList;
                        }
                        else
                        {
                            // ディクショナリーにキーが存在しない場合、キーとヴァリューの追加
                            List<SDRMRoadAll> tempList = new List<SDRMRoadAll>();
                            tempList.Add(item);
                            sDRMRoadAllByNodeAll.Add(nodeAll, tempList);
                        }
                    }

                    // DRM全道路の基本道路ノード１とノード２の順でキーの作成
                    nodeBasic = string.Format("0{0}0{1}", 
                                                (string)item.BasicRoadNodeNo1,
                                                (string)item.BasicRoadNodeNo2);

                    // ディクショナリーにキーが存在する場合、キーに対するDRM全道路リストに追加
                    if (sDRMRoadAllByNodeBasic.ContainsKey(nodeBasic))
                    {
                        List<SDRMRoadAll> tempList = sDRMRoadAllByNodeBasic[nodeBasic];
                        tempList.Add(item);
                        sDRMRoadAllByNodeBasic[nodeBasic] = tempList;
                    }
                    else
                    {
                        // ディクショナリーにキーが存在しない場合、キーとヴァリューの追加
                        List<SDRMRoadAll> tempList = new List<SDRMRoadAll>();
                        tempList.Add(item);
                        sDRMRoadAllByNodeBasic.Add(nodeBasic, tempList);
                    }

                    // DRM全道路の基本道路ノード２とノード１の順でキーの作成
                    if (item.BasicRoadNodeNo2 != item.BasicRoadNodeNo1)
                    {
                        nodeBasic = string.Format("0{0}0{1}",
                                (string)item.BasicRoadNodeNo2,
                                (string)item.BasicRoadNodeNo1);

                        // ディクショナリーにキーが存在する場合、キーに対するDRM全道路リストに追加
                        if (sDRMRoadAllByNodeBasic.ContainsKey(nodeBasic))
                        {
                            List<SDRMRoadAll> tempList = sDRMRoadAllByNodeBasic[nodeBasic];
                            tempList.Add(item);
                            sDRMRoadAllByNodeBasic[nodeBasic] = tempList;
                        }
                        else
                        {
                            // ディクショナリーにキーが存在しない場合、キーとヴァリューの追加
                            List<SDRMRoadAll> tempList = new List<SDRMRoadAll>();
                            tempList.Add(item);
                            sDRMRoadAllByNodeBasic.Add(nodeBasic, tempList);
                        }
                    }
                }
            }

            retListSDRMRoadAll.Add(sDRMRoadAllByNodeAll);
            retListSDRMRoadAll.Add(sDRMRoadAllByNodeBasic);

            // DRM全道路のディクショナリー（リストの一つ目は全道路のキー、二つ目は基本道路のキー）
            return retListSDRMRoadAll;
        }
        #endregion

        #region VICSリンクデータに紐付けるDRM道路結果リストの取得
        /// <summary>
        /// VICSリンクデータに紐付けるDRM道路結果リストの取得
        /// </summary>
        /// <param name="calcSpeed">DRM速度算出要否フラグ</param>
        /// <param name="useDRMRoadAll">DRM全道路利用要否フラグ</param>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <param name="listVICSLinkData">VICSリンクデータリスト</param>
        /// <param name="dictSDRMRoadBasic">DRM基本道路ディクショナリー</param>
        /// <param name="dictSDRMRoadAllByAllNode">DRM全道路ディクショナリー（キーが全道路ノード）</param>
        /// <param name="dictSDRMRoadAllByBasicNode">DRM全道路ディクショナリー（キーが基本道路ノード）</param>
        /// <param name="vicsDirect">VICS方向</param>
        /// <param name="dictDRMRoadInfo">DRM道路結果リスト</param>
        /// <returns>bool 問題データが存在するかのフラグ</returns>
        public static bool GetDRMRoadInfoInVICS(
            bool calcSpeed,
            bool useDRMRoadAll,
            int meshCode,
            List<VICSLinkFileData> listVICSLinkData,
            Dictionary<string, List<SDRMRoadBasic>> dictSDRMRoadBasic,
            Dictionary<string, List<SDRMRoadAll>> dictSDRMRoadAllByAllNode,
            Dictionary<string, List<SDRMRoadAll>> dictSDRMRoadAllByBasicNode,
            byte vicsDirect,
            ref Dictionary<string, DRMRoadData> dictDRMRoadInfo)
        {
            // 問題となったデータ存在するかのフラグ、一つのデータでも問題があったらTrueにする
            bool retHadErrorData = false;

            // 毎回に実施した結果に問題となったデータが存在するかフラグ
            bool hadErrorData = false;

            if (listVICSLinkData == null || listVICSLinkData.Count == 0)
            {
                retHadErrorData = true;
                return retHadErrorData;
            }

            if ((dictSDRMRoadBasic == null || dictSDRMRoadBasic.Count == 0) &&
                (dictSDRMRoadAllByAllNode == null || dictSDRMRoadAllByAllNode.Count == 0))
            {
                LogUtility.WriteInfo("2次メッシュ（{0}）に対応するDRM基本道路、DRM全道路がありません", meshCode);

                // VICSに対応するDRMが存在しない場合、メッセージを出力する
                LogUtility.Write(UF_Fluere_MsgId.MSGID_UF30003043,
                    meshCode,
                    string.Empty,
                    string.Empty,
                    string.Empty);

                retHadErrorData = true;
                return retHadErrorData;
            }

            // ログ出力用のDRM結果データ
            List<DRMRoadData> drmRoadDataLogList = new List<DRMRoadData>();

            // 1. VICSリンクデータの整備
            foreach (VICSLinkFileData vicsLinkData in listVICSLinkData)
            {
                List<string> nodeList = new List<string>();

                // VICSリンクデータのチェック　ノート番号の件数が1件以下の場合、呼び出す側に戻す
                retHadErrorData = CheckVICSLinkData(
                        calcSpeed,
                        useDRMRoadAll,
                        meshCode,
                        vicsLinkData,
                        dictSDRMRoadBasic,
                        dictSDRMRoadAllByAllNode,
                        vicsDirect,
                        ref nodeList);
                if (retHadErrorData)
                {
                    // DRM基本道路とDRM全道路を取得できないので、呼び出す側に戻す
                    return retHadErrorData;
                }

                for (int i = 0; i < nodeList.Count - 1; i++)
                {
                    // VICSリンクデータの構成道路ノード列の組み合わせ
                    string keyNode;
 
                    // 予約VICSの依存方向が異なるケースがある場合、
                    // DRM道路結果リストに重複データを追加しないため、ノード番号が小さいノード順で連結
                    if (nodeList[i].CompareTo(nodeList[i + 1]) < 0)
                    {
                        keyNode = nodeList[i] + nodeList[i + 1];
                    }
                    else
                    {
                        keyNode = nodeList[i + 1] + nodeList[i];
                    }

                    // DRM基本道路の抽出
                    if (dictSDRMRoadBasic.ContainsKey(keyNode))
                    {
                        hadErrorData = GetDRMBasicRoadInfo(
                            calcSpeed,
                            useDRMRoadAll,
                            dictSDRMRoadBasic,
                            dictSDRMRoadAllByBasicNode,
                            vicsDirect,
                            ref dictDRMRoadInfo,
                            keyNode,
                            meshCode,
                            ref drmRoadDataLogList);
                        if (hadErrorData)
                        {
                            retHadErrorData = hadErrorData;
                        }
                    }
                    else if (dictSDRMRoadAllByAllNode != null &&
                                            dictSDRMRoadAllByAllNode.ContainsKey(keyNode))
                    {
                        // DRM全道路の抽出
                        hadErrorData = GetDRMAllRoadInfo(
                            calcSpeed,
                            meshCode,
                            vicsLinkData,
                            dictSDRMRoadBasic,
                            dictSDRMRoadAllByAllNode,
                            vicsDirect,
                            ref dictDRMRoadInfo,
                            keyNode,
                            ref drmRoadDataLogList);
                        if (hadErrorData)
                        {
                            retHadErrorData = hadErrorData;
                        }
                    }
                    else
                    {
                        // 抽出キーに対応するDRMが存在しない場合、メッセージを出力する
                        LogUtility.Write(UF_Fluere_MsgId.MSGID_UF30003043,
                            meshCode,
                            vicsLinkData.LinkDiff,
                            vicsLinkData.VICSLinkNo,
                            vicsLinkData.ContinueRecordNo);

                        LogUtility.WriteTrace("○DRMデータ全道路がない(キー：{0})", keyNode);
                        retHadErrorData = true;
                    }
                }
            }

            // DRM結果データをログに出力する
            WriteDRMRoadInfoToTraceLog(drmRoadDataLogList, meshCode);

            return retHadErrorData;
        }
        #endregion

        #region VICSリンクデータのチェック
        /// <summary>
        /// VICSリンクデータのチェック
        /// </summary>
        /// <param name="calcSpeed">DRM速度算出要否フラグ</param>
        /// <param name="useDRMRoadAll">DRM全道路利用要否フラグ</param>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <param name="vicsLinkData">VICSリンクデータ</param>
        /// <param name="dictSDRMRoadBasic">DRM基本道路リスト</param>
        /// <param name="dictSDRMRoadAll">DRM全道路リスト</param>
        /// <param name="vicsDirect">VICS方向</param>
        /// <param name="nodeList">ノード番号リスト</param>
        /// <returns>bool 問題データが存在するかのフラグ</returns>
       private static bool CheckVICSLinkData(
            bool calcSpeed,
            bool useDRMRoadAll,
            int meshCode,
            VICSLinkFileData vicsLinkData,
            Dictionary<string, List<SDRMRoadBasic>> dictSDRMRoadBasic,
            Dictionary<string, List<SDRMRoadAll>> dictSDRMRoadAll,
            byte vicsDirect,
            ref List<string> nodeList)
         {
             // 問題となったデータ存在するかのフラグ
             bool retHadErrorData = false;

            if (LogUtility.IsTraceEnabled)
            {
                List<string> tempLogList = vicsLinkData.BasicRoadNodeSeqList == null ?
                    new List<string>() : vicsLinkData.BasicRoadNodeSeqList;

                LogUtility.WriteTrace("○VICS方向：{0}　構成道路ノード(件数：{1})：{2}",
                    vicsDirect,
                    tempLogList.Count,
                    string.Join(",", tempLogList));
            }

            if (vicsLinkData.BasicRoadNodeSeqList != null &&
                vicsLinkData.BasicRoadNodeSeqList.Count > 0)
            {
                foreach (string item in vicsLinkData.BasicRoadNodeSeqList)
                {
                    if (!string.IsNullOrWhiteSpace(item))
                    {
                        // DRM全道路を利用しない場合
                        if (!useDRMRoadAll)
                        {
                            // 先頭が「0」以外のノード番号（5桁ノード番号）は対象外
                            if (item.Substring(0, 1) == "0")
                            {
                                nodeList.Add(item);
                            }
                        }
                        else
                        {
                            // DRM全道路を利用する場合
                            // 40000番台、50000番台のノード番号は対象外
                            if (item.Substring(0, 1) != "4" && item.Substring(0, 1) != "5")
                            {
                                nodeList.Add(item);
                            }
                        }
                    }
                }
            }

            if (LogUtility.IsTraceEnabled)
            {
                LogUtility.WriteTrace("○有効な構成道路ノード(件数：{0})：{1}",
                    nodeList.Count,
                    string.Join(",", nodeList));
            }

            if (nodeList.Count < 2)
            {
                // 有効な構成基本道路ノードが二つ未満の場合、メッセージを出力する
                LogUtility.Write(UF_Fluere_MsgId.MSGID_UF30003043,
                    meshCode,
                    vicsLinkData.LinkDiff,
                    vicsLinkData.VICSLinkNo,
                    vicsLinkData.ContinueRecordNo);

                retHadErrorData = true;
                return retHadErrorData;
            }

            if (LogUtility.IsTraceEnabled)
            {
                LogUtility.WriteTrace("○DRM基道路ノード(件数：{0})：{1}",
                    dictSDRMRoadBasic.Count,
                    string.Join(",", dictSDRMRoadBasic.Keys));
                if (dictSDRMRoadAll != null)
                {
                    LogUtility.WriteTrace("○DRM全道路ノード(件数：{0})：{1}",
                        dictSDRMRoadAll.Count,
                        string.Join(",", dictSDRMRoadAll.Keys));
                }
            }

            return retHadErrorData;
        }
        #endregion

        #region DRM基本道路の情報の取得
        /// <summary>
        /// DRM基本道路の結果リストの取得
        /// </summary>
        /// <param name="calcSpeed">速度計算要否フラグ</param>
        /// <param name="useDRMRoadAll">DRM全道路利用要否フラグ</param>
        /// <param name="dictSDRMRoadBasic">DRM基本道路リスト</param>
        /// <param name="dictSDRMRoadAllByBasic">DRM全道路リスト（キーが基本道路ノード）</param>
        /// <param name="vicsDirect">VICS方向</param>
        /// <param name="dictDRMRoadInfo">DRM道路結果リスト</param>
        /// <param name="keyNode">DRM道路ノード番号</param>
        /// <param name="vicsMeshCode">予約VICS区間/VICS区間2次メッシュコード</param>
        /// <param name="drmRoadDataLogList">DRM道路結果ログリスト</param>
        /// <returns>bool 問題データが存在するかのフラグ</returns>
        private static bool GetDRMBasicRoadInfo(
            bool calcSpeed,
            bool useDRMRoadAll,
            Dictionary<string, List<SDRMRoadBasic>> dictSDRMRoadBasic,
            Dictionary<string, List<SDRMRoadAll>> dictSDRMRoadAllByBasic,
            byte vicsDirect,
            ref Dictionary<string, DRMRoadData> dictDRMRoadInfo,
            string keyNode,
            int vicsMeshCode,
            ref List<DRMRoadData> drmRoadDataLogList)
        {
            LogUtility.WriteTrace("○DRMデータ基本道路に存在(キー：{0})", keyNode);

            // VICS方向と連結後のノード番号を「-」で連結してから、DRM結果データのキーとする
            string strDictKey = vicsDirect.ToString() + "-" + keyNode;

            // DRM道路の距離リスト
            List<long> distanceList = new List<long>();

            // 問題となったデータ存在するかのフラグ
            bool retHadErrorData = false;

            // DRM道路結果リストに存在しない場合のみ、DRM道路結果リストに追加
            if (!dictDRMRoadInfo.ContainsKey(strDictKey))
            {
                // 距離算出
                CalcDistanceBasic(calcSpeed,
                    useDRMRoadAll,
                    keyNode,
                    dictSDRMRoadBasic,
                    dictSDRMRoadAllByBasic,
                    ref distanceList,
                    ref retHadErrorData);

                // DRM道路データ作成
                DRMRoadData drmRoadData = CreateDRMRoadData(vicsDirect,
                        keyNode,
                        keyNode,
                        dictSDRMRoadBasic[keyNode][0].SpeedLimitCode,
                        dictSDRMRoadBasic[keyNode][0].ExclusiveRoadTypCode,
                        distanceList,
                        vicsMeshCode);

                // DRM道路結果リストに追加
                dictDRMRoadInfo.Add(strDictKey, drmRoadData);

                // DRM道路結果ログリストにも追加
                drmRoadDataLogList.Add(dictDRMRoadInfo[strDictKey]);
            }
            else
            {
                var drmRoadData = dictDRMRoadInfo[strDictKey];

                // 予約VICS区間の2次メッシュが前回計算時の2次メッシュと異なる場合、該当DRM道路結果リストを更新
                if (!drmRoadData.RoadInfoByVicsMeshCode.ContainsKey(vicsMeshCode))
                {
                    LogUtility.WriteTrace("☆★キャッシュの計算結果(基本道路)★☆\tDRM道路のノード番号：{0}\tDRM道路の距離：{1}\tDRMの規制速度：{2}\tmc：{3}\t距離リスト：{4}",
                        drmRoadData.DRMRoadNodeNo,
                        string.Join(", ", drmRoadData.RoadInfoByVicsMeshCode.Values.Select(n => n.RoadLength)),
                        string.Join(", ", drmRoadData.RoadInfoByVicsMeshCode.Values.Select(n => n.SpeedLimitCode)),
                        string.Join(", ", drmRoadData.RoadInfoByVicsMeshCode.Keys),
                        string.Join(", ", drmRoadData.RoadInfoByVicsMeshCode.Values.Select(n => string.Join(",", n.RoadLengthList))));

                    // 距離算出
                    CalcDistanceBasic(calcSpeed,
                        useDRMRoadAll,
                        keyNode,
                        dictSDRMRoadBasic,
                        dictSDRMRoadAllByBasic,
                        ref distanceList,
                        ref retHadErrorData);

                    // 該当DRM道路結果リストを更新
                    var roadInfo = new DRMRoadData.RoadInfo(
                        keyNode,
                        dictSDRMRoadBasic[keyNode][0].SpeedLimitCode,
                        dictSDRMRoadBasic[keyNode][0].ExclusiveRoadTypCode,
                        distanceList);
                    drmRoadData.RoadInfoByVicsMeshCode.Add(vicsMeshCode, roadInfo);

                    // DRM道路結果ログリストにも追加
                    drmRoadDataLogList.Add(drmRoadData);

                    LogUtility.WriteTrace("☆★新たに計算した結果(基本道路)  ★☆\tDRM道路のノード番号：{0}\tDRM道路の距離：{1}\tDRMの規制速度：{2}\tmc：{3}\t距離リスト：{4}",
                        drmRoadData.DRMRoadNodeNo,
                        drmRoadData.RoadInfoByVicsMeshCode[vicsMeshCode].RoadLength,
                        drmRoadData.RoadInfoByVicsMeshCode[vicsMeshCode].SpeedLimitCode,
                        vicsMeshCode,
                        string.Join(",", drmRoadData.RoadInfoByVicsMeshCode[vicsMeshCode].RoadLengthList));
                }
            }

            return retHadErrorData;
        }

        /// <summary>
        /// DRM基本道路の距離計算
        /// </summary>
        /// <param name="calcSpeed">速度計算要否フラグ</param>
        /// <param name="useDRMRoadAll">DRM全道路利用要否フラグ</param>
        /// <param name="keyNode">DRM道路ノード番号</param>
        /// <param name="dictSDRMRoadBasic">DRM基本道路リスト</param>
        /// <param name="dictSDRMRoadAllByBasic">DRM全道路リスト（キーが基本道路ノード）</param>
        /// <param name="distanceList">REF：DRM道路の距離リスト</param>
        /// <param name="retHadErrorData">REF：問題となったデータ存在するかのフラグ</param>
        private static void CalcDistanceBasic(
            bool calcSpeed,
            bool useDRMRoadAll,
            string keyNode,
            Dictionary<string, List<SDRMRoadBasic>> dictSDRMRoadBasic,
            Dictionary<string, List<SDRMRoadAll>> dictSDRMRoadAllByBasic,
            ref List<long> distanceList,
            ref bool retHadErrorData)
        {
            if (calcSpeed && useDRMRoadAll)
            {
                if (dictSDRMRoadAllByBasic != null && dictSDRMRoadAllByBasic.ContainsKey(keyNode))
                {
                    long distance = 0;
                    if (dictSDRMRoadAllByBasic[keyNode] != null && dictSDRMRoadAllByBasic[keyNode].Count > 0)
                    {
                        foreach (SDRMRoadAll drmRoadAll in dictSDRMRoadAllByBasic[keyNode])
                        {
                            // DRM全道路のcm単位の距離を加算する
                            long unitDistance = GetPolylineDistance(drmRoadAll.Geometry.ToList());
                            distance += unitDistance;
                            distanceList.Add(unitDistance);
                        }
                    }
                    else
                    {
                        // DRM基本道路のcm単位の距離を計算する
                        distance = GetPolylineDistance(dictSDRMRoadBasic[keyNode][0].Geometry.ToList());
                        distanceList.Add(distance);
                    }
                }
                else
                {
                    retHadErrorData = true;
                }
            }
        }
        #endregion

        #region DRM全道路の情報の取得
        /// <summary>
        /// DRM全道路の結果リストの取得
        /// </summary>
        /// <param name="calcSpeed">速度計算要否フラグ</param>
        /// <param name="meshCode">2次メッシュコード</param>
        /// <param name="vicsLinkData">VICSリンクデータ</param>
        /// <param name="dictSDRMRoadBasic">DRM基本道路リスト</param>
        /// <param name="dictSDRMRoadAll">DRM全道路リスト</param>
        /// <param name="vicsDirect">VICS方向</param>
        /// <param name="dictDRMRoadInfo">DRM道路結果リスト</param>
        /// <param name="keyNode">DRM道路ノード番号</param>
        /// <param name="drmRoadDataLogList">DRM道路結果ログリスト</param>
        /// <returns>bool 問題データが存在するかのフラグ</returns>
        private static bool GetDRMAllRoadInfo(
            bool calcSpeed,
            int meshCode,
            VICSLinkFileData vicsLinkData,
            Dictionary<string, List<SDRMRoadBasic>> dictSDRMRoadBasic,
            Dictionary<string, List<SDRMRoadAll>> dictSDRMRoadAll,
            byte vicsDirect,
            ref Dictionary<string, DRMRoadData> dictDRMRoadInfo,
            string keyNode,
            ref List<DRMRoadData> drmRoadDataLogList)
        {
            // VICS方向と連結後のノード番号を「-」で連結してから、DRM結果データのキーとする
            string strDictKey;

            // 問題となったデータ存在するかのフラグ
            bool retHadErrorData = false;

            // DRM全道路の抽出
            string keyNodeAll = keyNode;
            List<SDRMRoadAll> resultListSDRMRoadAll = new List<SDRMRoadAll>();

            resultListSDRMRoadAll = dictSDRMRoadAll[keyNodeAll];

            // DRMデータ全道路がない場合の処理
            if (resultListSDRMRoadAll == null || resultListSDRMRoadAll.Count <= 0)
            {
                retHadErrorData = true;
                LogUtility.WriteTrace("○DRMデータ全道路がない(キー：{0})", keyNodeAll);
                return retHadErrorData;
            }

            // DRMデータ全道路が存在する場合の処理
            LogUtility.WriteTrace("○DRMデータ全道路が存在(キー：{0})", keyNodeAll);

            foreach (SDRMRoadAll item in resultListSDRMRoadAll)
            {
                if (CheckValuesIsNullOrWhiteSpace(item.BasicRoadNodeNo1, item.BasicRoadNodeNo2))
                {
                    LogUtility.WriteTrace("○DRMデータ全道路に対応する基本道路のノード番号はNULLまたは空白");
                    continue;
                }

                // DRMデータ全道路に対応する基本道路のノード番号取得
                string keyNodeBasic = string.Format("0{0}0{1}", item.BasicRoadNodeNo1, item.BasicRoadNodeNo2);

                // DRM道路結果リストに存在しない場合のみ、DRM道路結果リストに追加
                strDictKey = vicsDirect.ToString() + "-" + keyNodeAll;
                if (!dictDRMRoadInfo.ContainsKey(strDictKey))
                {
                    // 距離算出
                    List<long> distanceList = new List<long>();
                    CalcDistanceAll(item, calcSpeed, ref distanceList);

                    // 3. DRM基本道路の抽出
                    if (dictSDRMRoadBasic.ContainsKey(keyNodeBasic))
                    {
                        LogUtility.WriteTrace("○DRMデータ全道路に対応する基本道路が存在(キー：{0})", keyNodeBasic);

                        DRMRoadData drmRoadData = CreateDRMRoadData(
                                vicsDirect,
                                keyNodeAll,
                                keyNodeBasic,
                                dictSDRMRoadBasic[keyNodeBasic][0].SpeedLimitCode,
                                dictSDRMRoadBasic[keyNodeBasic][0].ExclusiveRoadTypCode,
                                distanceList,
                                meshCode);

                        // DRM道路結果リスに追加
                        dictDRMRoadInfo.Add(strDictKey, drmRoadData);

                        drmRoadDataLogList.Add(dictDRMRoadInfo[strDictKey]);
                    }
                    else
                    {
                        retHadErrorData = true;
                        LogUtility.WriteTrace("○DRMデータ全道路に対応する基本道路がない(キー：{0})", keyNodeBasic);

                        // 全道路に対する基本道路がない場合、DRM道路結果リスに追加
                        // 距離はDRM全道路の距離、速度はnull：未設定の固定値
                        DRMRoadData drmRoadData = CreateDRMRoadData(
                                vicsDirect,
                                keyNodeAll,
                                keyNodeBasic,
                                null,
                                null,
                                distanceList,
                                meshCode);

                        dictDRMRoadInfo.Add(strDictKey, drmRoadData);

                        drmRoadDataLogList.Add(dictDRMRoadInfo[strDictKey]);
                    }
                }
                else
                {
                    var drmRoadData = dictDRMRoadInfo[strDictKey];

                    // 予約VICS区間の2次メッシュが前回計算時の2次メッシュと異なる場合、該当DRM道路結果リストを更新
                    if (!drmRoadData.RoadInfoByVicsMeshCode.ContainsKey(meshCode))
                    {
                        LogUtility.WriteTrace("☆★キャッシュの計算結果(全道路)  ★☆\tDRM道路のノード番号：{0}\tDRM道路の距離：{1}\tDRMの規制速度：{2}\tmc：{3}\t距離リスト：{4}",
                            drmRoadData.DRMRoadNodeNo,
                            string.Join(", ", drmRoadData.RoadInfoByVicsMeshCode.Values.Select(n => n.RoadLength)),
                            string.Join(", ", drmRoadData.RoadInfoByVicsMeshCode.Values.Select(n => n.SpeedLimitCode)),
                            string.Join(", ", drmRoadData.RoadInfoByVicsMeshCode.Keys),
                            string.Join(", ", drmRoadData.RoadInfoByVicsMeshCode.Values.Select(n => string.Join(",", n.RoadLengthList))));

                        // 距離算出
                        List<long> distanceList = new List<long>();
                        CalcDistanceAll(item, calcSpeed, ref distanceList);

                        // 3. DRM基本道路の抽出
                        if (dictSDRMRoadBasic.ContainsKey(keyNodeBasic))
                        {
                            LogUtility.WriteTrace("○DRMデータ全道路に対応する基本道路が存在(キー：{0})", keyNodeBasic);

                            // 該当DRM道路結果リストを更新
                            var roadInfo = new DRMRoadData.RoadInfo(
                                keyNodeBasic,
                                dictSDRMRoadBasic[keyNodeBasic][0].SpeedLimitCode,
                                dictSDRMRoadBasic[keyNodeBasic][0].ExclusiveRoadTypCode,
                                distanceList);
                            drmRoadData.RoadInfoByVicsMeshCode.Add(meshCode, roadInfo);

                            // DRM道路結果ログリストにも追加
                            drmRoadDataLogList.Add(drmRoadData);
                        }
                        else
                        {
                            retHadErrorData = true;
                            LogUtility.WriteTrace("○DRMデータ全道路に対応する基本道路がない(キー：{0})", keyNodeBasic);

                            // 該当DRM道路結果リストを更新
                            // 距離はDRM全道路の距離、速度はnull：未設定の固定値
                            var roadInfo = new DRMRoadData.RoadInfo(
                                keyNodeBasic,
                                null,
                                null,
                                distanceList);
                            drmRoadData.RoadInfoByVicsMeshCode.Add(meshCode, roadInfo);

                            // DRM道路結果ログリストにも追加
                            drmRoadDataLogList.Add(drmRoadData);
                        }

                        LogUtility.WriteTrace("☆★新たに計算した結果(全道路)    ★☆\tDRM道路のノード番号：{0}\tDRM道路の距離：{1}\tDRMの規制速度：{2}\tmc：{3}\t距離リスト：{4}",
                            drmRoadData.DRMRoadNodeNo,
                            drmRoadData.RoadInfoByVicsMeshCode[meshCode].RoadLength,
                            drmRoadData.RoadInfoByVicsMeshCode[meshCode].SpeedLimitCode,
                            meshCode,
                            string.Join(",", drmRoadData.RoadInfoByVicsMeshCode[meshCode].RoadLengthList));
                    }
                }
            }

            return retHadErrorData;
        }

        /// <summary>
        /// 2つの値の空白値チェック
        /// </summary>
        /// <param name="val1">値1</param>
        /// <param name="val2">値2</param>
        /// <returns>値1,2が共に空白でない場合はFalse。それ以外はTrue。</returns>
        private static bool CheckValuesIsNullOrWhiteSpace(string val1, string val2)
        {
            return string.IsNullOrWhiteSpace(val1) || string.IsNullOrWhiteSpace(val2);
        }

        /// <summary>
        /// DRM全道路の距離計算
        /// </summary>
        /// <param name="drmRoadAll">DRM全道路</param>
        /// <param name="calcSpeed">速度計算要否フラグ</param>
        /// <param name="distanceList">REF：DRM道路の距離リスト</param>
        private static void CalcDistanceAll(SDRMRoadAll drmRoadAll, bool calcSpeed, ref List<long> distanceList)
        {
            if (calcSpeed)
            {
                // cm単位の距離を計算する
                long distance = GetPolylineDistance(drmRoadAll.Geometry.ToList());
                distanceList.Add(distance);
            }
        }
        #endregion

        #region ポリラインのUTM距離の算出
        /// <summary>
        /// ポリラインのUTM距離の算出
        /// </summary>
        /// <param name="geometryLine">ポリライン座標リスト</param>
        /// <returns>long 算出したUTM座標系の距離（四捨五入のCM単位）</returns>
        private static long GetPolylineDistance(List<FW.TMIGeometry.Coordinate> geometryLine)
        {
            long retDistance = 0;

            // m単位の距離をcm単位に四捨五入で変換して、小数点を切り捨てる。
            retDistance = (long)((GIS.GetUTMDistance(
                            geometryLine.Select(cood =>
                                new FW.TMIGeometry.Coordinate(
                                    (long)(System.Math.Floor(cood.Longitude / 8.0) * 8),
                                    (long)(System.Math.Floor(cood.Latitude / 8.0) * 8))).ToList())
                                    * 100) + 0.5);

            return retDistance;
        }
        #endregion

        #region DRM道路結果リスト情報のログ出力
        /// <summary>
        /// DRM道路結果リスト情報のログ出力
        /// </summary>
        /// <param name="drmRoadDataLogList">ログ出力用DRM道路データリスト</param>
        /// <param name="mesh">規制速度/自専道コードの出力対象となる2次メッシュ情報</param>
        private static void WriteDRMRoadInfoToTraceLog(List<DRMRoadData> drmRoadDataLogList, int mesh)
        {
            if (LogUtility.IsTraceEnabled)
            {
                foreach (DRMRoadData item in drmRoadDataLogList)
                {
                    string basicRoadNodeNo = string.Empty;
                    string roadLength = string.Empty;
                    string strSpeedLimitCode = "null";
                    string strExclusiveRoadTypCode = "null";
                    DRMRoadData.RoadInfo roadInfo;
                    if (item.RoadInfoByVicsMeshCode.TryGetValue(mesh, out roadInfo))
                    {
                        basicRoadNodeNo = roadInfo.DRMBasicRoadNodeNo;
                        roadLength = roadInfo.RoadLength.ToString();
                        strSpeedLimitCode = roadInfo.SpeedLimitCode == null ? "null" : roadInfo.SpeedLimitCode.ToString();
                        strExclusiveRoadTypCode = roadInfo.ExclusiveRoadTypCode == null ? "null" : roadInfo.ExclusiveRoadTypCode.ToString();
                    }

                    LogUtility.WriteTrace("○DRM道路結果リストにVICS方向：{0}", item.VicsDirect.ToString());
                    LogUtility.WriteTrace("○DRM道路結果リストにDRM道路のノード番号：{0}", item.DRMRoadNodeNo);
                    LogUtility.WriteTrace("○DRM道路結果リストにDRM基本道路のノード番号：{0}, 予約VICS区間の2次メッシュコード：{1}", basicRoadNodeNo, mesh);
                    LogUtility.WriteTrace("○DRM道路結果リストにDRM道路の距離：{0}, 予約VICS区間の2次メッシュコード：{1}", roadLength, mesh);
                    LogUtility.WriteTrace("○DRM道路結果リストにDRM道路の規制速度コード：{0}, 予約VICS区間の2次メッシュコード：{1}", strSpeedLimitCode, mesh);
                    LogUtility.WriteTrace("○DRM道路結果リストに自動車専用道路コード：{0}, 予約VICS区間の2次メッシュコード：{1}", strExclusiveRoadTypCode, mesh);
                }
            }
        }
        #endregion

        #region DRM道路データの作成
        /// <summary>
        /// DRM道路データの作成
        /// </summary>
        /// <param name="vicsDirect">VICS方向</param>
        /// <param name="keyNode">DRM道路のノード番号</param>
        /// <param name="keyBasicNode">DRM基本道路のノード番号</param>
        /// <param name="speedLimitCode"> DRM道路の規制速度コード</param>
        /// <param name="exclusiveRoadTypCode">自動車専用道路コード</param>
        /// <param name="distanceList">DRM道路毎の距離リスト</param>
        /// <param name="vicsMeshCode">予約VICS区間/VICS区間2次メッシュコード</param>
        /// <returns>DRM道路データ</returns>
        private static DRMRoadData CreateDRMRoadData(byte vicsDirect, 
            string keyNode, 
            string keyBasicNode, 
            byte? speedLimitCode, 
            byte? exclusiveRoadTypCode,
            List<long> distanceList,
            int vicsMeshCode)
        {
            DRMRoadData dRMRoadData = new DRMRoadData();

            // VICS方向
            dRMRoadData.VicsDirect = vicsDirect;

            // DRM道路のノード番号
            dRMRoadData.DRMRoadNodeNo = keyNode;

            // DRM基本道路のノード番号/DRM道路の規制速度コード/自動車専用道路コード, DRM道路データ毎のリスト
            dRMRoadData.RoadInfoByVicsMeshCode.Add(vicsMeshCode,
                new DRMRoadData.RoadInfo(
                    keyBasicNode,
                    speedLimitCode,
                    exclusiveRoadTypCode,
                    distanceList));

            return dRMRoadData;
        }
        #endregion
    }
}

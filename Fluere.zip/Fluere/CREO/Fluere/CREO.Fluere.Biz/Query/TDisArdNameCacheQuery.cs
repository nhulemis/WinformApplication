﻿using System.Collections.Generic;
using CREO.DataModel;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 行政区域コードのフォーマット
    /// </summary>
    public enum FullAdrCodePatternForDis
    {
        /// <summary>
        /// 県コード(0詰め2桁)市区町村コード(0詰め3桁)-大字コード-小字コード　（※半角ハイフンで連結）
        /// </summary>
        Default = 1,

        /// <summary>
        /// 県コード(0詰め2桁)-市区町村コード(0詰め3桁)-大字コード(0詰め4桁)-小字コード(0詰め3桁)　（※半角ハイフンで連結）
        /// </summary>
        Individually = 2
    }

    /// <summary>
    /// 住所名称情報を管理するクラス
    /// </summary>
    public class TDisArdNameCacheQuery : DataParenthoodWrapper
    {
        #region 定数定義 検索関連
        /// <summary>
        /// 住所名称のデータモデルタイプID
        /// </summary>
        private const string DATA_MODEL_TYPEID_TDISADRNAME = "TDisAdrName";

        /// <summary>
        /// 0:都道府県のネストレベル
        /// </summary>
        public const byte PROVINCE_NESTLEVEL = 0;

        /// <summary>
        /// 1:市区町村のネストレベル
        /// </summary>
        public const byte ADMIN_NESTLEVEL = 1;

        /// <summary>
        /// 2:大字のネストレベル
        /// </summary>
        public const byte OOAZA_NESTLEVEL = 2;

        /// <summary>
        /// 3:小字のネストレベル
        /// </summary>
        public const byte COAZA_NESTLEVEL = 3;

        /// <summary>
        /// 市区町村レベルのキャッシュデータ
        /// </summary>
        private Dictionary<string, ParentChildRelation> _adminCacheDict = new Dictionary<string, ParentChildRelation>();

        /// <summary>
        /// グローバルなインスタンス
        /// </summary>
        public static TDisArdNameCacheQuery GlobalReadOnlyInstance = null;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        protected TDisArdNameCacheQuery()
        {
        }

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="innerDataServiceWrapper">データサービス</param>
        public TDisArdNameCacheQuery(DataServiceWrapper innerDataServiceWrapper)
            : base(innerDataServiceWrapper, DATA_MODEL_TYPEID_TDISADRNAME, ADMIN_NESTLEVEL)
        {
            // 事前取得用ネストレベル
            PreloadNestLevel = COAZA_NESTLEVEL;

            // 市区町村コードを取得
            List<ParentChildRelation> adminList = new List<ParentChildRelation>();
            foreach (ParentChildRelation provinceData in this._topLevelList)
            {
                provinceData.GetAllChild(ref adminList, ADMIN_NESTLEVEL, IsAdminLevelData);
            }

            foreach (ParentChildRelation adminData in adminList)
            {
                string adminAdrCode = GetFullAdrCode(adminData);
                if (this._adminCacheDict.ContainsKey(adminAdrCode))
                {
                    LogUtility.WriteWarning("※市区町村コードが重複。{0}:{1}<==>{2}",
                                        adminAdrCode,
                                        adminData.OID,
                                        this._adminCacheDict[adminAdrCode].OID);
                }
                else
                {
                    this._adminCacheDict.Add(adminAdrCode, adminData);
                }
            }
        }
        #endregion

        #region プロパティ
        /// <summary>
        /// プリロードネストレベル
        /// </summary>
        public byte PreloadNestLevel { get; set; }
        #endregion

        #region スタティック・メソッド
        /// <summary>
        /// グローバルなインスタンスを取得する
        /// </summary>
        /// <param name="innerDataServiceWrapper">データサービス</param>
        /// <returns>グローバルなインスタンス</returns>
        public static TDisArdNameCacheQuery GetGlobalReadOnlyInstance(DataServiceWrapper innerDataServiceWrapper)
        {
            if (GlobalReadOnlyInstance == null)
            {
                GlobalReadOnlyInstance = new TDisArdNameCacheQuery(innerDataServiceWrapper);
            }

            GlobalReadOnlyInstance.InnerDataServiceWrapper = innerDataServiceWrapper;

            return GlobalReadOnlyInstance;
        }
        #endregion

        #region プロテクト・メソッド
        /// <summary>
        /// 市区町村レベルのフィルタ関数
        /// </summary>
        /// <param name="checkData">対象データ</param>
        /// <returns>対象データとなるかどうか</returns>
        protected bool IsAdminLevelData(TItemBase checkData)
        {
            if (checkData.NestLevel == ADMIN_NESTLEVEL)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 大字と小字レベルのフィルタ関数
        /// </summary>
        /// <param name="checkData">対象データ</param>
        /// <returns>対象データとなるかどうか</returns>
        protected bool IsOoazaCoazaLevelData(TItemBase checkData)
        {
            if (checkData.NestLevel == OOAZA_NESTLEVEL || checkData.NestLevel == COAZA_NESTLEVEL)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 市区町村、大字と小字レベルのフィルタ関数
        /// </summary>
        /// <param name="checkData">対象データ</param>
        /// <returns>対象データとなるかどうか</returns>
        protected bool IsAdminOoazaCoazaLevelData(TItemBase checkData)
        {
            if (checkData.NestLevel == ADMIN_NESTLEVEL || 
                checkData.NestLevel == OOAZA_NESTLEVEL || 
                checkData.NestLevel == COAZA_NESTLEVEL)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 市区町村と大字レベルのフィルタ関数
        /// </summary>
        /// <param name="checkData">対象データ</param>
        /// <returns>対象データとなるかどうか</returns>
        protected bool IsAdminOoazaLevelData(TItemBase checkData)
        {
            if (checkData.NestLevel == ADMIN_NESTLEVEL ||
                checkData.NestLevel == OOAZA_NESTLEVEL)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した行政区域コード
        /// </summary>
        /// <param name="curData">対象データ</param>
        /// <param name="codePattern">連結フォーマット</param>
        /// <returns>行政区域コード</returns>
        protected string GetFullAdrCode(ParentChildRelation curData,
            FullAdrCodePatternForDis codePattern = FullAdrCodePatternForDis.Default)
        {
            string fullAdrCode;
            ParentChildRelation parentData = curData.Parent;
            TDisAdrName curTDisAdrName = (TDisAdrName)curData.Inner;

            switch (codePattern)
            {
                case FullAdrCodePatternForDis.Individually:
                    switch (curData.NestLevel)
                    {
                        case 0:
                            fullAdrCode = string.Format("{0:D2}", curTDisAdrName.AdrCode);
                            break;
                        case 1:
                            fullAdrCode = string.Format("{0}-{1:D3}", GetFullAdrCode(parentData, codePattern), curTDisAdrName.AdrCode);
                            break;
                        case 2:
                            fullAdrCode = string.Format("{0}-{1:D4}", GetFullAdrCode(parentData, codePattern), curTDisAdrName.AdrCode);
                            break;
                        case 3:
                            fullAdrCode = string.Format("{0}-{1:D3}", GetFullAdrCode(parentData, codePattern), curTDisAdrName.AdrCode);
                            break;
                        default:
                            fullAdrCode = string.Format("{0}-{1}", GetFullAdrCode(parentData, codePattern), curTDisAdrName.AdrCode);
                            break;
                    }

                    break;
                case FullAdrCodePatternForDis.Default:
                default:
                    switch (curData.NestLevel)
                    {
                        case 0:
                            fullAdrCode = string.Format("{0:D2}", curTDisAdrName.AdrCode);
                            break;
                        case 1:
                            fullAdrCode = string.Format("{0}{1:D3}", GetFullAdrCode(parentData, codePattern), curTDisAdrName.AdrCode);
                            break;
                        default:
                            fullAdrCode = string.Format("{0}-{1}", GetFullAdrCode(parentData, codePattern), curTDisAdrName.AdrCode);
                            break;
                    }

                    break;
            }

            return fullAdrCode;
        }
        #endregion

        #region パブリック・メソッド              
        /// <summary>
        /// 市区町村コードを指定し、市区町村、大字と小字の住所名所を取得する
        /// </summary>
        /// <param name="adminCode">市区町村コード</param>
        /// <returns>住所名所リスト</returns>
        public List<TItemBase> GetAdminAzaItems(string adminCode)
        {
            if (!this._adminCacheDict.ContainsKey(adminCode))
            {
                string message = string.Format("市区町村コードが取得できません。市区町村コード:{0}",
                    adminCode);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            List<TItemBase> retList = new List<TItemBase>();

            ParentChildRelation adminData = this._adminCacheDict[adminCode];

            if (!adminData.IsChildLoaded)
            {
                LoadChildItems(adminData.OID, PreloadNestLevel);
            }

            adminData.GetAllChild(ref retList, COAZA_NESTLEVEL, IsAdminOoazaCoazaLevelData);

            return retList;
        }

        /// <summary>
        /// 市区町村コードを指定し、市区町村、大字の住所名所を取得する
        /// </summary>
        /// <param name="adminCode">市区町村コード</param>
        /// <returns>住所名所リスト</returns>
        public List<TItemBase> GetAdminOoazaItems(string adminCode)
        {
            if (!this._adminCacheDict.ContainsKey(adminCode))
            {
                string message = string.Format("市区町村コードが取得できません。市区町村コード:{0}",
                    adminCode);
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF70000010, new object[] { message });
            }

            List<TItemBase> retList = new List<TItemBase>();

            ParentChildRelation adminData = this._adminCacheDict[adminCode];

            if (!adminData.IsChildLoaded)
            {
                LoadChildItems(adminData.OID, PreloadNestLevel);
            }

            adminData.GetAllChild(ref retList, OOAZA_NESTLEVEL, IsAdminOoazaLevelData);

            return retList;
        }

        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した行政区域コード
        /// </summary>
        /// <param name="oid">対象住所名称のOID</param>
        /// <param name="codePattern">連結フォーマット</param>
        /// <returns>行政区域コード</returns>
        public string GetFullAdrCode(ulong oid,
            FullAdrCodePatternForDis codePattern = FullAdrCodePatternForDis.Default)
        {
            if (!this._cacheDict.ContainsKey(oid))
            {
                LoadParentItems(oid, OOAZA_NESTLEVEL);
            }

            return GetFullAdrCode(this._cacheDict[oid], codePattern);
        }

        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した行政区域コード
        /// </summary>
        /// <param name="oid">対象住所名称のOID</param>
        /// <param name="codePattern">連結フォーマット</param>
        /// <returns>行政区域コード</returns>
        public string GetParentFullAdrCode(ulong oid,
            FullAdrCodePatternForDis codePattern = FullAdrCodePatternForDis.Default)
        {
            if (!this._cacheDict.ContainsKey(oid))
            {
                LoadParentItems(oid, OOAZA_NESTLEVEL);
            }

            string retArdCode = string.Empty;
            if (this._cacheDict[oid].Parent != null)
            {
                retArdCode = GetFullAdrCode(this._cacheDict[oid].Parent);
            }

            return retArdCode;
        }

        /// <summary>
        /// 同一の親の大字レベルまたは小字レベルの住所名称を取得する
        /// </summary>
        /// <param name="oid">対象住所名称のOID</param>
        /// <param name="minNestLevel">最小ネストレベル</param>
        /// <param name="maxNestLevel">最大ネストレベル</param>
        /// <returns>住所名称リスト</returns>
        public List<TItemBase> GetNeighborList(ulong oid,
            byte minNestLevel = OOAZA_NESTLEVEL,
            byte maxNestLevel = COAZA_NESTLEVEL)
        {
            if (!this._cacheDict.ContainsKey(oid))
            {
                LoadParentItems(oid, OOAZA_NESTLEVEL);
            }

            ParentChildRelation curData = this._cacheDict[oid];

            if (curData.NestLevel < minNestLevel || curData.NestLevel > maxNestLevel)
            {
                return new List<TItemBase>();
            }

            ParentChildRelation adminData = null;
            if (curData.NestLevel > ADMIN_NESTLEVEL)
            {
                List<ParentChildRelation> parentList = new List<ParentChildRelation>();
                curData.GetAllParent(ref parentList, ADMIN_NESTLEVEL, IsAdminLevelData);

                if (parentList.Count > 0)
                {
                    adminData = parentList[0];
                    if (!adminData.IsChildLoaded)
                    {
                        LoadChildItems(adminData.OID, PreloadNestLevel);
                    }
                }
            }

            return base.GetNeighborList(oid);
        }
        #endregion

        #region OIDにより、親と子モデルを取得する
        /// <summary>
        /// OIDにより、親と子モデルを取得する
        /// </summary>
        /// <param name="oid">OID</param>
        /// <param name="nestLevel">ネストレベル</param>
        /// <returns>親と子モデル</returns>
        public List<TItemBase> GetRelatedItem(ulong oid, byte nestLevel)
        {
            if (!this._cacheDict.ContainsKey(oid))
            {
                LoadParentItems(oid, OOAZA_NESTLEVEL);
            }

            if (OOAZA_NESTLEVEL == nestLevel)
            {
                LoadChildItems(oid, COAZA_NESTLEVEL);
            }

            ParentChildRelation curData = this._cacheDict[oid];
            List<TItemBase> retList = new List<TItemBase>();

            // 都道府県から
            curData.Parent.GetAllParent(ref retList, PROVINCE_NESTLEVEL, null);

            // 小字まで
            curData.GetAllChild(ref retList, COAZA_NESTLEVEL, null);

            return retList;
        }
        #endregion

        #region 市区町村コードが存在するかどうか判断
        /// <summary>
        /// 市区町村コードが存在するかどうか判断
        /// </summary>
        /// <param name="adminCode">市区町村コード</param>
        /// <returns>存在するかどうか</returns>
        public bool IsExistOfAdminCode(string adminCode)
        {
            return this._adminCacheDict.ContainsKey(adminCode);
        }
        #endregion
    }
}

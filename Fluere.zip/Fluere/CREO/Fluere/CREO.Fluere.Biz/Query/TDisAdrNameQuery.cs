﻿using System;
using System.Collections.Generic;
using System.Threading;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;
using CREO.FW.Log;

namespace CREO.Fluere.Biz.Query
{
    #region 廃止住所名称情報を格納するクラス
    /// <summary>
    /// 廃止住所名称情報を格納するクラス
    /// </summary>
    public class LocalDisAdrName
    {
        #region フィールド定義
        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した行政区域コード
        /// </summary>
        private string fullAdrCode = null;

        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した廃止住所名称
        /// </summary>
        private string fullName = null;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        private LocalDisAdrName()
        {
        }

        /// <summary>
        /// LocalDisAdrNameクラスの新しいインスタンスを生成する。
        /// </summary>
        /// <param name="paraOID">OID</param>
        /// <param name="adrNameOID">住所名称OID</param>
        public LocalDisAdrName(ulong paraOID, ulong? adrNameOID)
        {
            this.OID = paraOID;
            this.AdrNameOID = adrNameOID;

            this.Childs = new List<LocalDisAdrName>();
            this.Parent = null;
        }

        /// <summary>
        /// LocalDisAdrNameクラスの新しいインスタンスを生成する。
        /// </summary>
        /// <param name="paraTDisAdrName">TDisAdrNameデータモデルオブジェクト</param>
        public LocalDisAdrName(TDisAdrName paraTDisAdrName)
            : this(paraTDisAdrName.OID, paraTDisAdrName.AdrNameOID) // 「paraTDisAdrName.AdrNameOID」⇒2012/11/02　劉程　添加
        {
            this.ResetTDisAdrName(paraTDisAdrName);
        }
        #endregion

        #region プロパティ
        /// <summary>
        /// OID
        /// </summary>
        public ulong OID { get; set; }

        /// <summary>
        /// 漢字住所名所（ja-Jpan）
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 行政区域コード
        /// </summary>
        public ushort AdrCode { get; set; }

        /// <summary>
        /// ネストレベル
        /// </summary>
        public byte NestLevel { get; set; }

        /// <summary>
        /// 住所名称OID
        /// 2012/11/02　劉程　添加
        /// </summary>
        public ulong? AdrNameOID { get; set; }

        /// <summary>
        /// DummyAdrFlag(仮廃止フラグ)
        /// </summary>
        public bool DummyAdrFlag { get; set; }

        /// <summary>
        /// 出典ID
        /// 2013/04/15 江雪風　追加
        /// </summary>
        public ulong? MaterialID { get; set; }

        /// <summary>
        /// 子廃止住所名称情報
        /// </summary>
        public List<LocalDisAdrName> Childs { get; private set; }

        /// <summary>
        /// 親廃止住所名称情報
        /// </summary>
        public LocalDisAdrName Parent { get; private set; }

        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した行政区域コード
        /// </summary>
        public string FullAdrCode
        {
            get
            {
                if (this.fullAdrCode == null)
                {
                    switch (this.NestLevel)
                    {
                        case 0:
                            this.fullAdrCode = string.Format("{0:D2}", this.AdrCode);
                            break;
                        case 1:
                            this.fullAdrCode = string.Format("{0}{1:D3}", this.Parent.FullAdrCode, this.AdrCode);
                            break;
                        default:
                            this.fullAdrCode = string.Format("{0}-{1}", this.Parent.FullAdrCode, this.AdrCode);
                            break;
                    }
                }

                return fullAdrCode;
            }
        }

        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した廃止住所名称
        /// </summary>
        public string FullName
        {
            get
            {
                if (this.fullName == null)
                {
                    switch (this.NestLevel)
                    {
                        case 0:
                            this.fullName = this.Name;
                            break;
                        default:
                            this.fullName = string.Format("{0}{1}", this.Parent.FullName, this.Name);
                            break;
                    }
                }

                return fullName;
            }
        }
        #endregion

        #region パブリック・メソッド
        /// <summary>
        /// 子住所対象を追加する
        /// </summary>
        /// <param name="child">子住所対象</param>
        public void AddChild(LocalDisAdrName child)
        {
            child.SetParent(this);
            this.Childs.Add(child);
        }

        /// <summary>
        /// 親住所対象を設定する
        /// </summary>
        /// <param name="parent">親住所対象</param>
        public void SetParent(LocalDisAdrName parent)
        {
            this.Parent = parent;
        }

        /// <summary>
        /// 住所対象を再設定する
        /// </summary>
        /// <param name="paraTDisAdrName">TDisAdrNameデータモデルオブジェクト</param>
        public void ResetTDisAdrName(TDisAdrName paraTDisAdrName)
        {
            this.AdrNameOID = paraTDisAdrName.AdrNameOID; // 2012/11/02　劉程　添加

            this.MaterialID = paraTDisAdrName.MaterialID;  // 2013/04/15 江雪風　追加

            this.Name = string.Empty;
            if (paraTDisAdrName.AdrNameMultiLang != null &&
                paraTDisAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN] != null &&
                !string.IsNullOrEmpty(paraTDisAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name))
            {
                this.Name = paraTDisAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name;
            }

            this.AdrCode = (ushort)paraTDisAdrName.AdrCode;
            this.NestLevel = paraTDisAdrName.NestLevel;
            if (paraTDisAdrName.DummyAdrFlag != null && paraTDisAdrName.DummyAdrFlag.Equals(false))
            {
                this.DummyAdrFlag = false;
            }
            else
            {
                this.DummyAdrFlag = true;
            }
        }
        #endregion
    }
    #endregion

    #region 比較子
    /// <summary>
    /// OIDを使用して、2 つの廃止住所名称情報オブジェクトを比較するために型が実装するメソッドを定義します
    /// </summary>
    public class LocalDisAdrNameByOidComparer : IComparer<LocalDisAdrName>
    {
        /// <summary>
        /// 2 つの廃止住所名称情報オブジェクトを比較し、一方が他方より小さいか、等しいか、大きいかを示す値を返します。
        /// </summary>
        /// <param name="firstObj">比較する最初のオブジェクトです</param>
        /// <param name="secondObj">比較する 2 番目のオブジェクト</param>
        /// <returns>x と y の相対的な値を示す符号付き整数</returns>
        public int Compare(LocalDisAdrName firstObj, LocalDisAdrName secondObj)
        {
            if (firstObj == null)
            {
                if (secondObj == null)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                if (secondObj == null)
                {
                    return 1;
                }
                else
                {
                    return firstObj.OID.CompareTo(secondObj.OID);
                }
            }
        }
    }
    #endregion

    #region 廃止住所名称情報を管理するクラス
    /// <summary>
    /// 廃止住所名称情報を管理するクラス
    /// </summary>
    public class TDisAdrNameQuery
    {
        #region 定数定義 検索関連
        /// <summary>
        /// 廃止住所名称のデータモデルタイプID
        /// </summary>
        private const string DATA_MODEL_TYPEID_TDISADRNAME = "TDisAdrName";

        /// <summary>
        /// 親表実体OID
        /// </summary>
        private const string ATTR_NAME_PARENTTABLEOID = "ParentTableOID";
        #endregion

        #region ログマネージャーのインスタンス、メッセージマネージャーのインスタンス
        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        private static LogManager _loggMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);
        #endregion

        #region キャッシュデータ
        /// <summary>
        /// キャッシュデータサービスを使用するフラグ
        /// </summary>
        private static bool useCacheDataService = false;

        /// <summary>
        /// データ検索用データサービス
        /// </summary>
        private static DataService cacheDataService = null;

        /// <summary>
        /// 都道府県レベルのキャッシュデータに対する変更処理の排他制御用イベント
        /// </summary>
        private static ManualResetEvent provinceCacheDictLockEvent = new ManualResetEvent(true);

        /// <summary>
        /// 市区町村レベルのキャッシュデータに対する変更処理の排他制御用ロックオブジェクト
        /// </summary>
        private static object adminCacheDictLockObject = new object();

        /// <summary>
        /// 検索済み県データに対する変更の排他制御用ロックオブジェクト
        /// </summary>
        private static object provinceSearchedOIDDictLockObject = new object();

        /// <summary>
        /// 都道府県レベルのキャッシュデータ
        /// </summary>
        private static Dictionary<string, LocalDisAdrName> provinceCacheDict = new Dictionary<string, LocalDisAdrName>();

        /// <summary>
        /// 市区町村レベルのキャッシュデータ
        /// </summary>
        private static Dictionary<string, LocalDisAdrName> adminCacheDict = new Dictionary<string, LocalDisAdrName>();

        /// <summary>
        /// 検索済み県データ
        /// </summary>
        private static Dictionary<string, ulong> provinceSearchedOIDDict = new Dictionary<string, ulong>();

        /// <summary>
        /// 検索済み市区町村データ
        /// </summary>
        private static Dictionary<string, ulong> adminSearchedOIDDict = new Dictionary<string, ulong>();

        /// <summary>
        /// 検索済み字データ
        /// </summary>
        private static Dictionary<string, ulong> azaSearchedOIDDict = new Dictionary<string, ulong>();
        #endregion

        #region 定数定義 ネストレベル
        /// <summary>
        /// 0:都道府県まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A0_ONLY = 0;

        /// <summary>
        /// 1:市区町村まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A1_ONLY = 1;

        /// <summary>
        /// 2:大字まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A1_A2 = 2;

        /// <summary>
        /// 3:小字まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A1_A2_A3 = 3;
        #endregion

        #region プライベート・メソッド
        /// <summary>
        /// 都道府県の廃止住所名称情報を取得
        /// </summary>
        /// <param name="provinceCode">県レベルの行政区域コード</param>
        /// <returns>都道府県の廃止住所名称情報</returns>
        private static LocalDisAdrName GetKennDisAdrName(string provinceCode)
        {
            if (provinceCacheDict.ContainsKey(provinceCode))
            {
                // 再検索不要場合
                return provinceCacheDict[provinceCode];
            }

            if (provinceCacheDict.Count < 1)
            {
                Monitor.Enter(provinceCacheDictLockEvent);
                try
                {
                    if (provinceCacheDict.Count < 1)
                    {
                        provinceCacheDictLockEvent.Reset();

                        // 初回なので検索する
                        QueryItemsCondition itemsCondition = new QueryItemsCondition();
                        itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TDISADRNAME);
                        itemsCondition.ConditionExpression = new SqlConditionExpression(ATTR_NAME_PARENTTABLEOID,
                            QueryItemOperator.Equal,
                            null);
                        List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

                        if (lstDataModel != null && 0 != lstDataModel.Count)
                        {
                            foreach (GeoItem curGeoItem in lstDataModel)
                            {
                                TDisAdrName tempProvinceGeoItem = (TDisAdrName)curGeoItem;

                                string cacheKey = string.Format("{0:D2}", tempProvinceGeoItem.AdrCode);
                                if (provinceCacheDict.ContainsKey(cacheKey))
                                {
                                    LocalDisAdrName dupProvinceDisAdrName = provinceCacheDict[cacheKey];

                                    _loggMgr.WriteWarning("※都道府県データが重複。{0}:{1},{2}<==>{3},{4}",
                                        cacheKey,
                                        dupProvinceDisAdrName.AdrCode,
                                        dupProvinceDisAdrName.OID,
                                        tempProvinceGeoItem.AdrCode,
                                        tempProvinceGeoItem.OID);
                                }
                                else
                                {
                                    LocalDisAdrName provinceDisAdrName = new LocalDisAdrName(tempProvinceGeoItem);
                                    provinceCacheDict.Add(cacheKey, provinceDisAdrName);
                                }
                            }

                            // データモデルを解放する
                            lstDataModel.Clear();
                            lstDataModel = null;
                        }
                    }
                }
                finally
                {
                    Monitor.Exit(provinceCacheDictLockEvent);
                    provinceCacheDictLockEvent.Set();
                }
            }

            provinceCacheDictLockEvent.WaitOne();
            if (provinceCacheDict.ContainsKey(provinceCode))
            {
                return provinceCacheDict[provinceCode];
            }

            _loggMgr.WriteDebug("※都道府県データが存在しません。{0}", provinceCode);
            return null;
        }

        /// <summary>
        /// 市区町村の廃止住所名称情報を取得
        /// </summary>
        /// <param name="curKennLocalDisAdrName">県の廃止住所名称情報</param>
        private static void GetSiDisAdrName(LocalDisAdrName curKennLocalDisAdrName)
        {
            // 初回なので検索する
            QueryItemsCondition itemsCondition = new QueryItemsCondition();
            itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TDISADRNAME);
            itemsCondition.ConditionExpression = new SqlConditionExpression(ATTR_NAME_PARENTTABLEOID,
                QueryItemOperator.Equal,
                curKennLocalDisAdrName.OID.ToString());
            List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

            if (lstDataModel != null && 0 != lstDataModel.Count)
            {
                foreach (GeoItem curGeoItem in lstDataModel)
                {
                    TDisAdrName tempAdminGeoItem = (TDisAdrName)curGeoItem;

                    string cacheKey = string.Format("{0:D2}{1:D3}",
                        curKennLocalDisAdrName.AdrCode,
                        tempAdminGeoItem.AdrCode);

                    if (!adminCacheDict.ContainsKey(cacheKey))
                    {
                        lock (adminCacheDictLockObject)
                        {
                            if (!adminCacheDict.ContainsKey(cacheKey))
                            {
                                LocalDisAdrName adminDisAdrName = new LocalDisAdrName(tempAdminGeoItem);
                                curKennLocalDisAdrName.AddChild(adminDisAdrName);

                                adminCacheDict.Add(cacheKey, adminDisAdrName);
                            }
                        }
                    }
                }

                // データモデルを解放する
                lstDataModel.Clear();
                lstDataModel = null;
            }

            lock (provinceSearchedOIDDictLockObject)
            {
                // 検索済み配列に追加
                if (!provinceSearchedOIDDict.ContainsKey(curKennLocalDisAdrName.FullAdrCode))
                {
                    provinceSearchedOIDDict.Add(curKennLocalDisAdrName.FullAdrCode, curKennLocalDisAdrName.OID);
                }
            }
        }

        /// <summary>
        /// 市区町村の廃止住所名称情報を取得
        /// </summary>
        /// <param name="disAdrnameCode">県と市区町村レベルの行政区域コード</param>
        /// <returns>市区町村の廃止住所名称情報</returns>
        private static LocalDisAdrName GetSiDisAdrName(string disAdrnameCode)
        {
            if (adminCacheDict.ContainsKey(disAdrnameCode))
            {
                // 再検索不要場合
                return adminCacheDict[disAdrnameCode];
            }

            // 都道府県コード
            string provinceCode = StringUtil.GetAdminCodeSubString(disAdrnameCode, 0, 2);

            // 未検索の場合
            if (!provinceSearchedOIDDict.ContainsKey(provinceCode))
            {
                // 県データを取得する
                LocalDisAdrName curKennLocalDisAdrName = GetKennDisAdrName(provinceCode);
                if (null == curKennLocalDisAdrName)
                {
                    // 県データが存在しない場合
                    return null;
                }

                GetSiDisAdrName(curKennLocalDisAdrName);
            }

            if (adminCacheDict.ContainsKey(disAdrnameCode))
            {
                return adminCacheDict[disAdrnameCode];
            }

            _loggMgr.WriteDebug("※市区町村データが存在しません。{0}", disAdrnameCode);
            return null;
        }

        /// <summary>
        /// 大字の廃止住所名称情報を取得
        /// </summary>
        /// <param name="curSiLocalDisAdrName">市区町村の廃止住所名称情報</param>
        private static void GetOoazaDisAdrName(LocalDisAdrName curSiLocalDisAdrName)
        {
            // 初回なので検索する
            if (!adminSearchedOIDDict.ContainsKey(curSiLocalDisAdrName.FullAdrCode))
            {
                // 初回なので検索する
                QueryItemsCondition itemsCondition = new QueryItemsCondition();
                itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TDISADRNAME);
                itemsCondition.ConditionExpression = new SqlConditionExpression(ATTR_NAME_PARENTTABLEOID,
                    QueryItemOperator.Equal,
                    curSiLocalDisAdrName.OID.ToString());
                List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

                if (lstDataModel != null && 0 != lstDataModel.Count)
                {
                    foreach (GeoItem curGeoItem in lstDataModel)
                    {
                        LocalDisAdrName ooazaDisAdrName = new LocalDisAdrName((TDisAdrName)curGeoItem);
                        curSiLocalDisAdrName.AddChild(ooazaDisAdrName);
                    }

                    // データモデルを解放する
                    lstDataModel.Clear();
                    lstDataModel = null;
                }

                // 検索済み配列に追加
                adminSearchedOIDDict.Add(curSiLocalDisAdrName.FullAdrCode, curSiLocalDisAdrName.OID);
            }
        }

        /// <summary>
        /// 市区町村と大字の廃止住所名称情報を取得
        /// </summary>
        /// <param name="disAdrnameCode">県と市区町村レベルの行政区域コード</param>
        /// <param name="resultList">市区町村と大字の廃止住所名称情報を格納するリスト</param>
        private static void GetOoazaDisAdrName(string disAdrnameCode,
            ref List<LocalDisAdrName> resultList)
        {
            // 市区町村データを取得する
            LocalDisAdrName curSiLocalDisAdrName = GetSiDisAdrName(disAdrnameCode);
            if (null == curSiLocalDisAdrName)
            {
                // 市区町村データが存在しない場合
                return;
            }

            GetOoazaDisAdrName(curSiLocalDisAdrName);

            // 市区町村データを出力
            if (!curSiLocalDisAdrName.DummyAdrFlag)
            {
                resultList.Add(curSiLocalDisAdrName);
            }

            // 大字データを出力
            foreach (LocalDisAdrName tempLocalDisAdrName in curSiLocalDisAdrName.Childs)
            {
                if (!tempLocalDisAdrName.DummyAdrFlag)
                {
                    resultList.Add(tempLocalDisAdrName);
                }
            }
        }

        /// <summary>
        /// 小字廃止住所名称情報を取得
        /// </summary>
        /// <param name="curOoazaLocalDisAdrName">大字廃止住所名称情報</param>
        private static void GetCoazaDisAdrName(LocalDisAdrName curOoazaLocalDisAdrName)
        {
            if (!azaSearchedOIDDict.ContainsKey(curOoazaLocalDisAdrName.FullAdrCode))
            {
                // 初回なので検索する
                QueryItemsCondition itemsCondition = new QueryItemsCondition();
                itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TDISADRNAME);
                itemsCondition.ConditionExpression = new SqlConditionExpression(ATTR_NAME_PARENTTABLEOID,
                    QueryItemOperator.Equal,
                    curOoazaLocalDisAdrName.OID.ToString());
                List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

                if (lstDataModel != null && 0 != lstDataModel.Count)
                {
                    foreach (GeoItem curGeoItem in lstDataModel)
                    {
                        LocalDisAdrName coazaDisAdrName = new LocalDisAdrName((TDisAdrName)curGeoItem);
                        curOoazaLocalDisAdrName.AddChild(coazaDisAdrName);
                    }

                    // データモデルを解放する
                    lstDataModel.Clear();
                    lstDataModel = null;
                }

                // 検索済み配列に追加
                azaSearchedOIDDict.Add(curOoazaLocalDisAdrName.FullAdrCode, curOoazaLocalDisAdrName.OID);
            }
        }

        /// <summary>
        /// 市区町村、大字と小字の廃止住所名称情報を取得
        /// </summary>
        /// <param name="disAdrnameCode">県と市区町村レベルの行政区域コード</param>
        /// <param name="resultList">市区町村、大字と小字の廃止住所名称情報を格納するリスト</param>
        private static void GetCoazaDisAdrName(string disAdrnameCode,
            ref List<LocalDisAdrName> resultList)
        {
            // 市区町村、大字の廃止住所名称情報を取得
            GetOoazaDisAdrName(disAdrnameCode, ref resultList);

            // 市区町村データを取得する
            LocalDisAdrName curSiLocalDisAdrName = null;
            if (adminCacheDict.ContainsKey(disAdrnameCode))
            {
                curSiLocalDisAdrName = adminCacheDict[disAdrnameCode];
            }

            if (null == curSiLocalDisAdrName)
            {
                // 市区町村データが存在しない場合
                return;
            }

            // 初回なので検索する
            if (!azaSearchedOIDDict.ContainsKey(curSiLocalDisAdrName.FullAdrCode))
            {
                // 小字データを出力
                foreach (LocalDisAdrName curOoazaLocalDisAdrName in curSiLocalDisAdrName.Childs)
                {
                    GetCoazaDisAdrName(curOoazaLocalDisAdrName);
                }

                // 検索済み配列に追加
                azaSearchedOIDDict.Add(curSiLocalDisAdrName.FullAdrCode, curSiLocalDisAdrName.OID);
            }

            // 小字データを出力
            foreach (LocalDisAdrName curOoazaLocalDisAdrName in curSiLocalDisAdrName.Childs)
            {
                foreach (LocalDisAdrName tempLocalDisAdrName in curOoazaLocalDisAdrName.Childs)
                {
                    if (!tempLocalDisAdrName.DummyAdrFlag)
                    {
                        resultList.Add(tempLocalDisAdrName);
                    }
                }
            }
        }
        #endregion

        #region パブリック・メソッド
        #region 処理フロー制御用の廃止住所名称を取得する処理
        /// <summary>
        /// 検索用データサービスを設定する
        /// </summary>
        /// <param name="paraDataService">データサービス</param>
        public static void SetDataService(DataService paraDataService)
        {
            if (paraDataService != null)
            {
                useCacheDataService = true;
            }
            else
            {
                useCacheDataService = false;
            }

            cacheDataService = paraDataService;
        }

        /// <summary>
        /// すべて廃止住所名称情報を取得
        /// </summary>
        /// <param name="paraDataService">データサービス</param>
        /// <param name="forceRefresh">全データを再取得するフラグ</param>
        public static void PrepareAllData(DataService paraDataService, bool forceRefresh = false)
        {
            // 検索用データサービスを設定する
            if (!useCacheDataService)
            {
                cacheDataService = paraDataService;
            }

            provinceCacheDictLockEvent.WaitOne();

            if (forceRefresh || provinceCacheDict.Count < 1)
            {
                Monitor.Enter(provinceCacheDictLockEvent);
                try
                {
                    provinceCacheDictLockEvent.Reset();

                    // リフレッシュ場合
                    if (forceRefresh)
                    {
                        provinceCacheDict.Clear();

                        lock (adminCacheDictLockObject)
                        {
                            adminCacheDict.Clear();
                        }

                        lock (provinceSearchedOIDDictLockObject)
                        {
                            provinceSearchedOIDDict.Clear();
                            adminSearchedOIDDict.Clear();
                            azaSearchedOIDDict.Clear();
                        }
                    }

                    if (provinceCacheDict.Count < 1)
                    {
                        // 初回なので検索する
                        QueryItemsCondition itemsCondition = new QueryItemsCondition();
                        itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TDISADRNAME);
                        List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

                        if (lstDataModel != null && 0 != lstDataModel.Count)
                        {
                            Dictionary<ulong, LocalDisAdrName> tempOidCacheDict = new Dictionary<ulong, LocalDisAdrName>();

                            List<LocalDisAdrName> tempProvinceList = new List<LocalDisAdrName>();
                            List<LocalDisAdrName> tempAdminList = new List<LocalDisAdrName>();

                            foreach (GeoItem curGeoItem in lstDataModel)
                            {
                                TDisAdrName curTDisAdrName = (TDisAdrName)curGeoItem;
                                LocalDisAdrName curLocalDisAdrName = null;
                                if (tempOidCacheDict.ContainsKey(curTDisAdrName.OID))
                                {
                                    curLocalDisAdrName = tempOidCacheDict[curTDisAdrName.OID];
                                    curLocalDisAdrName.ResetTDisAdrName(curTDisAdrName);
                                }
                                else
                                {
                                    curLocalDisAdrName = new LocalDisAdrName(curTDisAdrName);
                                    tempOidCacheDict.Add(curLocalDisAdrName.OID, curLocalDisAdrName);
                                }

                                // 都道府県の場合
                                if (curTDisAdrName.NestLevel == 0)
                                {
                                    tempProvinceList.Add(curLocalDisAdrName);
                                }
                                else
                                {
                                    if (curTDisAdrName.NestLevel == 1)
                                    {
                                        // 市区町村の場合
                                        tempAdminList.Add(curLocalDisAdrName);
                                    }

                                    LocalDisAdrName parentLocalDisAdrName = null;
                                    if (tempOidCacheDict.ContainsKey((ulong)curTDisAdrName.ParentTableOID))
                                    {
                                        parentLocalDisAdrName = tempOidCacheDict[(ulong)curTDisAdrName.ParentTableOID];
                                    }
                                    else
                                    {
                                        parentLocalDisAdrName = new LocalDisAdrName((ulong)curTDisAdrName.ParentTableOID, null); // parentLocalDisAdrName = new LocalDisAdrName((ulong)curTDisAdrName.ParentTableOID); ⇒ 2012/11/02　劉程　更新
                                        tempOidCacheDict.Add(parentLocalDisAdrName.OID, parentLocalDisAdrName);
                                    }

                                    parentLocalDisAdrName.AddChild(curLocalDisAdrName);
                                }
                            }

                            // データモデルを解放する
                            lstDataModel.Clear();
                            lstDataModel = null;

                            // ガベージ コレクションを直ちに強制実行します
                            GC.Collect(GC.MaxGeneration);
                            GC.WaitForPendingFinalizers();

                            // キャッシュデータを生成する
                            foreach (LocalDisAdrName provinceLocalDisAdrName in tempProvinceList)
                            {
                                if (provinceCacheDict.ContainsKey(provinceLocalDisAdrName.FullAdrCode))
                                {
                                    LocalDisAdrName dupProvinceDisAdrName =
                                        provinceCacheDict[provinceLocalDisAdrName.FullAdrCode];

                                    _loggMgr.WriteWarning("※都道府県データが重複。{0}:{1},{2}<==>{3},{4}",
                                        provinceLocalDisAdrName.FullAdrCode,
                                        dupProvinceDisAdrName.AdrCode,
                                        dupProvinceDisAdrName.OID,
                                        provinceLocalDisAdrName.AdrCode,
                                        provinceLocalDisAdrName.OID);
                                }
                                else
                                {
                                    provinceCacheDict.Add(provinceLocalDisAdrName.FullAdrCode, provinceLocalDisAdrName);
                                    provinceSearchedOIDDict.Add(provinceLocalDisAdrName.FullAdrCode,
                                        provinceLocalDisAdrName.OID);
                                }
                            }

                            foreach (LocalDisAdrName adminLocalDisAdrName in tempAdminList)
                            {
                                if (adminCacheDict.ContainsKey(adminLocalDisAdrName.FullAdrCode))
                                {
                                    LocalDisAdrName dupAdminLocalDisAdrName =
                                        adminCacheDict[adminLocalDisAdrName.FullAdrCode];

                                    _loggMgr.WriteWarning("※市区町村データが重複。{0}:{1},{2}<==>{3},{4}",
                                        adminLocalDisAdrName.FullAdrCode,
                                        dupAdminLocalDisAdrName.AdrCode,
                                        dupAdminLocalDisAdrName.OID,
                                        adminLocalDisAdrName.AdrCode,
                                        adminLocalDisAdrName.OID);
                                }
                                else
                                {
                                    adminCacheDict.Add(adminLocalDisAdrName.FullAdrCode, adminLocalDisAdrName);
                                    adminSearchedOIDDict.Add(adminLocalDisAdrName.FullAdrCode, adminLocalDisAdrName.OID);
                                    foreach (LocalDisAdrName curOoazaLocalDisAdrName in adminLocalDisAdrName.Childs)
                                    {
                                        azaSearchedOIDDict.Add(curOoazaLocalDisAdrName.FullAdrCode,
                                            curOoazaLocalDisAdrName.OID);
                                    }
                                }
                            }
                        }
                    }
                }
                finally
                {
                    Monitor.Exit(provinceCacheDictLockEvent);
                    provinceCacheDictLockEvent.Set();
                }
            }
        }

        /// <summary>
        /// ①都道府県、②市区町村、③市区町村と大字、④市区町村、大字と小字の廃止住所名称情報を取得
        /// </summary>
        /// <param name="paraDataService">データサービス</param>
        /// <param name="disAdrnameCode">行政区域コード</param>
        /// <param name="nestLevel">ネストレベル</param>
        /// <param name="filterFlag">true:DummyAdrFlag有効;false:DummyAdrFlag無効</param>
        /// <returns>LocalDisAdrName型廃止住所名称情報</returns>
        public static List<LocalDisAdrName> GetLocalDisAdrName(DataService paraDataService, string disAdrnameCode, long nestLevel, bool filterFlag = true)
        {
            // 検索用データサービスを設定する
            if (!useCacheDataService)
            {
                cacheDataService = paraDataService;
            }

            provinceCacheDictLockEvent.WaitOne();

            List<LocalDisAdrName> resultList = new List<LocalDisAdrName>();

            switch (nestLevel)
            {
                case ADMINISTRATIVE_CODE_A0_ONLY:
                    // 都道府県コード
                    string provinceCode = StringUtil.GetAdminCodeSubString(disAdrnameCode, 0, 2);

                    // ①都道府県データの検索
                    LocalDisAdrName provinceLocalDisAdrName = GetKennDisAdrName(provinceCode);

                    if (provinceLocalDisAdrName != null && (!filterFlag || !provinceLocalDisAdrName.DummyAdrFlag))
                    {
                        resultList.Add(provinceLocalDisAdrName);
                    }

                    break;
                case ADMINISTRATIVE_CODE_A1_ONLY:

                    // ②市区町村データの検索
                    LocalDisAdrName adminLocalDisAdrName = GetSiDisAdrName(disAdrnameCode);

                    if (adminLocalDisAdrName != null && (!filterFlag || !adminLocalDisAdrName.DummyAdrFlag))
                    {
                        resultList.Add(adminLocalDisAdrName);
                    }

                    break;
                case ADMINISTRATIVE_CODE_A1_A2:
                    // ③市区町村と大字データの検索
                    GetOoazaDisAdrName(disAdrnameCode, ref resultList);

                    break;
                case ADMINISTRATIVE_CODE_A1_A2_A3:
                    // ④市区町村、大字と小字データの検索
                    GetCoazaDisAdrName(disAdrnameCode, ref resultList);

                    break;
                default:
                    break;
            }

            return resultList;
        }

        /// <summary>
        /// 子廃止住所名称情報を取得
        /// </summary>
        /// <param name="paraDataService">データサービス</param>
        /// <param name="paraLocalDisAdrName">廃止住所名称情報</param>
        public static void InitChildDisAdrName(DataService paraDataService, LocalDisAdrName paraLocalDisAdrName)
        {
            // 検索用データサービスを設定する
            if (!useCacheDataService)
            {
                cacheDataService = paraDataService;
            }

            provinceCacheDictLockEvent.WaitOne();

            switch (paraLocalDisAdrName.NestLevel)
            {
                case 0:
                    GetSiDisAdrName(paraLocalDisAdrName);
                    break;
                case 1:
                    GetOoazaDisAdrName(paraLocalDisAdrName);
                    break;
                case 2:
                    GetCoazaDisAdrName(paraLocalDisAdrName);
                    break;
                default:
                    break;
            }
        }

        #endregion

        #region DummyAdrFlagと関わりがなく、廃止住所名称情報を取得(江雪風追加)

        /// <summary>
        /// DummyAdrFlagと関わりがなく、①都道府県、②市区町村、③市区町村と大字、④市区町村、大字と小字の廃止住所名称情報を取得
        /// </summary>
        /// <param name="paraDataService">データサービス</param>
        /// <param name="disAdrnameCode">行政区域コード</param>
        /// <param name="nestLevel">ネストレベル</param>
        /// <returns>LocalDisAdrName型廃止住所名称情報</returns>
        public static List<LocalDisAdrName> GetLocalDisAdrNameFromLevel3WithoutDummyAdrFlag(DataService paraDataService, string disAdrnameCode, long nestLevel)
        {
            // 検索用データサービスを設定する
            if (!useCacheDataService)
            {
                cacheDataService = paraDataService;
            }

            provinceCacheDictLockEvent.WaitOne();

            List<LocalDisAdrName> resultList = new List<LocalDisAdrName>();

            switch (nestLevel)
            {
                case ADMINISTRATIVE_CODE_A0_ONLY:
                    // 都道府県コード
                    string provinceCode = StringUtil.GetAdminCodeSubString(disAdrnameCode, 0, 2);

                    // ①都道府県データの検索
                    LocalDisAdrName provinceLocalDisAdrName = GetKennDisAdrName(provinceCode);

                    if (provinceLocalDisAdrName != null)
                    {
                        resultList.Add(provinceLocalDisAdrName);
                    }

                    break;
                case ADMINISTRATIVE_CODE_A1_ONLY:

                    // ②市区町村データの検索
                    LocalDisAdrName adminLocalDisAdrName = GetSiDisAdrName(disAdrnameCode);

                    if (adminLocalDisAdrName != null)
                    {
                        resultList.Add(adminLocalDisAdrName);
                    }

                    break;
                case ADMINISTRATIVE_CODE_A1_A2:
                    // ③市区町村と大字データの検索
                    GetOoazaDisAdrNameWithoutDummyAdrFlag(disAdrnameCode, ref resultList);

                    break;
                case ADMINISTRATIVE_CODE_A1_A2_A3:
                    // ④市区町村、大字と小字データの検索
                    GetCoazaDisAdrNameWithoutDummyAdrFlag(disAdrnameCode, ref resultList);

                    break;
                default:
                    break;
            }

            return resultList;
        }

        /// <summary>
        /// 市区町村、大字と小字の廃止住所名称情報を取得
        /// </summary>
        /// <param name="disAdrnameCode">県と市区町村レベルの行政区域コード</param>
        /// <param name="resultList">市区町村、大字と小字の廃止住所名称情報を格納するリスト</param>
        private static void GetCoazaDisAdrNameWithoutDummyAdrFlag(string disAdrnameCode,
            ref List<LocalDisAdrName> resultList)
        {
            // 市区町村、大字の廃止住所名称情報を取得
            GetOoazaDisAdrNameWithoutDummyAdrFlag(disAdrnameCode, ref resultList);

            // 市区町村データを取得する
            LocalDisAdrName curSiLocalDisAdrName = null;
            if (adminCacheDict.ContainsKey(disAdrnameCode))
            {
                curSiLocalDisAdrName = adminCacheDict[disAdrnameCode];
            }

            if (null == curSiLocalDisAdrName)
            {
                // 市区町村データが存在しない場合
                return;
            }

            // 初回なので検索する
            if (!azaSearchedOIDDict.ContainsKey(curSiLocalDisAdrName.FullAdrCode))
            {
                // 小字データを出力
                foreach (LocalDisAdrName curOoazaLocalDisAdrName in curSiLocalDisAdrName.Childs)
                {
                    GetCoazaDisAdrName(curOoazaLocalDisAdrName);
                }

                // 検索済み配列に追加
                azaSearchedOIDDict.Add(curSiLocalDisAdrName.FullAdrCode, curSiLocalDisAdrName.OID);
            }

            // 小字データを出力
            foreach (LocalDisAdrName curOoazaLocalDisAdrName in curSiLocalDisAdrName.Childs)
            {
                foreach (LocalDisAdrName tempLocalDisAdrName in curOoazaLocalDisAdrName.Childs)
                {
                    resultList.Add(tempLocalDisAdrName);
                }
            }
        }

        /// <summary>
        /// 市区町村と大字の廃止住所名称情報を取得
        /// </summary>
        /// <param name="disAdrnameCode">県と市区町村レベルの行政区域コード</param>
        /// <param name="resultList">市区町村と大字の廃止住所名称情報を格納するリスト</param>
        private static void GetOoazaDisAdrNameWithoutDummyAdrFlag(string disAdrnameCode,
            ref List<LocalDisAdrName> resultList)
        {
            // 市区町村データを取得する
            LocalDisAdrName curSiLocalDisAdrName = GetSiDisAdrName(disAdrnameCode);
            if (null == curSiLocalDisAdrName)
            {
                // 市区町村データが存在しない場合
                return;
            }

            GetOoazaDisAdrName(curSiLocalDisAdrName);

            // 市区町村データを出力
            resultList.Add(curSiLocalDisAdrName);

            // 大字データを出力
            foreach (LocalDisAdrName tempLocalDisAdrName in curSiLocalDisAdrName.Childs)
            {
                resultList.Add(tempLocalDisAdrName);
            }
        }
        #endregion

        #region 業務用の廃止住所名称を取得する処理
        #region 実体OIDによって、廃止住所名称を取得
        /// <summary>
        /// 実体OIDによって、廃止住所名称を取得
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="oid">廃止住所名称OID</param>
        /// <returns>廃止住所名称</returns>
        public static TDisAdrName LoadTDisAdrNameByOID(DataService ds, ulong oid)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(DATA_MODEL_TYPEID_TDISADRNAME);

            qic.IDs.Add(oid);

            // 検索実行(※一レコードだけ)
            List<GeoItem> result = ds.QueryItems(qic);

            // 指定廃止住所名称で取得した廃止住所名称データモデルリストの件数が1件で判断
            if (result.Count == 0)
            {
                return null;
            }
            else
            {
                return (TDisAdrName)result[0];
            }
        }
        #endregion

        #region 子廃止住所名称モデルにより、親ネストレベルから子ネストレベルまで連結した住所を取得する
        /// <summary>
        /// 子廃止住所名称モデルにより、親ネストレベルから子ネストレベルまで連結した住所を取得する
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="childTDisAdrName">子廃止住所名称モデル</param>
        /// <param name="nestLevel">親ネストレベル</param>
        /// <returns>住所</returns>
        public static string GetWholeAddressFromChildTDisAdrName(DataService ds, TDisAdrName childTDisAdrName, int nestLevel)
        {
            // 住所
            string address = string.Empty;

            if (int.Parse(childTDisAdrName.NestLevel.ToString()).CompareTo(nestLevel) > 0)
            {
                // 廃止住所名称モデル
                TDisAdrName parentTDisAdrName = null;

                // 子廃止住所名称モデルネストレベルの取得
                int childNestLevel = childTDisAdrName.NestLevel;

                // 子廃止住所名称モデルの廃止住所名称の取得
                address = childTDisAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name;

                for (int i = 0; i < (childNestLevel - nestLevel); i++)
                {
                    // 子廃止住所名称モデルにより、親廃止住所名称モデルを取得する
                    parentTDisAdrName = GetParentTDisAdrNameFromChild(ds, childTDisAdrName);

                    if (parentTDisAdrName == null)
                    {
                        break;
                    }
                    else
                    {
                        if (parentTDisAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN] != null)
                        {
                            // 親廃止住所名称モデルの廃止住所名称の取得と連結
                            address = parentTDisAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name + address;
                        }
                        else
                        {
                            break;
                        }

                        // 前親廃止住所名称モデルを後ろ子廃止住所名称モデルに設定する
                        childTDisAdrName = parentTDisAdrName;
                    }
                }
            }

            return address;
        }
        #endregion

        #region 子廃止住所名称モデルにより、親廃止住所名称モデルを取得する
        /// <summary>
        /// 子廃止住所名称モデルにより、親廃止住所名称モデルを取得する
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="childTDisAdrName">子廃止住所名称モデル</param>
        /// <returns>親廃止住所名称モデル</returns>
        public static TDisAdrName GetParentTDisAdrNameFromChild(DataService ds, TDisAdrName childTDisAdrName)
        {
            // 廃止住所名称モデル
            TDisAdrName parentTDisAdrName = null;

            // 親表実体OIDの取得
            ulong parentOID = (ulong)childTDisAdrName.ParentTableOID;

            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(TDisAdrName).Name);
            qic.IDs.Add((ulong)childTDisAdrName.ParentTableOID);

            // 検索実行(※レコードだけ)
            List<GeoItem> resultTDisAdrName = ds.QueryItems(qic);

            // GeoItemをTDisAdrNameに変換する
            if (resultTDisAdrName != null)
            {
                parentTDisAdrName = (TDisAdrName)resultTDisAdrName[0];
            }

            return parentTDisAdrName;
        }
        #endregion

        #region 住所名称OIDによって、廃止住所名称を取得
        /// <summary>
        /// 住所名称OIDによって、廃止住所名称を取得
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adrNameList">廃止住所名称の住所名称OID</param>
        /// <returns>廃止住所名称</returns>
        public static List<TDisAdrName> LoadTDisAdrNameByAdrNameOIDLst(DataService ds, List<string> adrNameList)
        {
            List<TDisAdrName> resultTDisAdrName = new List<TDisAdrName>();

            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(DATA_MODEL_TYPEID_TDISADRNAME);

            // 検索条件：AdrNameOID
            SqlConditionExpression q1 = new SqlConditionExpression("AdrNameOID", QueryItemOperator.In, adrNameList.ToArray());

            // 検索条件：MatialId
            ////SqlConditionExpression q2 = new SqlConditionExpression("MaterialID", QueryItemOperator.Equal, null);

            // 検索条件組合せ
            ////qic.ConditionExpression = SqlConditionExpression.And(q1,q2);
            qic.ConditionExpression = SqlConditionExpression.And(q1);

            // 検索実行(※一レコードだけ)
            List<GeoItem> result = ds.QueryItems(qic);

            // GeoItemをSTwnPOIに変換する
            result.ConvertAll(s => (TDisAdrName)s).ForEach(p => resultTDisAdrName.Add(p));

            // MaterialIDがnullの条件により、データを抽出する
            List<TDisAdrName> resultTDisAdrName1 = resultTDisAdrName.FindAll(p => p.MaterialID == null);

            return resultTDisAdrName1;
        }
        #endregion
        #endregion
        #endregion
    }
    #endregion
}

﻿using System.Collections.Generic;
using System.Linq;
using CREO.DataModel;
using CREO.DS;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 交差点番号検索クラス
    /// </summary>
    public class SCrsMainQuery
    {
        /// <summary>
        /// 交差点番号と2次メッシュコードに基づく基幹交差点を検索する
        /// </summary>
        /// <param name="ds">データサビース</param>
        /// <param name="crsNo">交差点番号</param>
        /// <param name="meshNo">2次メッシュコード</param>
        /// <returns>基幹交差点データ</returns>
        public static List<SCrsMain> GetSCrsMainByCrsNoAndMeshNo(DataService ds, uint crsNo, int meshNo)
        {
            List<SCrsMain> resultSCrsMain = new List<SCrsMain>();

            // データ検索対象初期化
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(SCrsMain).Name);

            // 検索条件：交差点番号
            SqlConditionExpression q1 = new SqlConditionExpression("Crs05MMNoAry[*].CrsNo", QueryItemOperator.Equal, crsNo);

            // 検索条件：2次メッシュコード
            SqlConditionExpression q2 = new SqlConditionExpression("Crs05MMNoAry[*].MeshNo", QueryItemOperator.Equal, meshNo);

            // 検索条件組合せ
            qic.ConditionExpression = SqlConditionExpression.And(q1, q2);

            // 検索実行(※レコードだけ)
            List<GeoItem> resultGeoItem = ds.QueryItems(qic);

            // GeoItemをSCrsMainに変換する
            resultGeoItem.ConvertAll(s => (SCrsMain)s).ForEach(p => resultSCrsMain.Add(p));

            // 対象の2次メッシュコードかつ交差点番号の交差点を取得する。
            // (クエリではCrs05MMNoAry[0].MeshNoとCrs05MMNoAry[1].CrsNoで条件を満たす様なデータも取得される為)
            resultSCrsMain = resultSCrsMain.Where(n => n.Crs05MMNoAry.Where(m => m.MeshNo == meshNo && m.CrsNo == crsNo).Any()).ToList();

            return resultSCrsMain;
        }
    }
}

﻿using System.Collections.Generic;
using System.Reflection;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// GeoItemQuery
    /// </summary>
    public class GeoItemQuery
    {
        /// <summary>
        /// string[] 
        /// </summary>
        private static string[] _langTagAry = new string[3] 
        {
            MultiLangName.Code.IETFLangTag_ja_Jpan,
            MultiLangName.Code.IETFLangTag_ja_Kana,
            MultiLangName.Code.IETFLangTag_en
        };

        /// <summary>
        /// 新規・更新分の差分データを取得する
        /// </summary>
        /// <param name="curWorkGroupSearch">ワークグループデータを検索するクラス</param>
        /// <param name="meshCode">メッシュコード</param>
        /// <param name="typeIdList">タイプIDリスト</param>
        /// <returns>新規・更新分の差分データOIDリスト</returns>
        private static List<ulong> LoadAddUpdateDiffData(WorkGroupWrapper curWorkGroupSearch, int? meshCode, int[] typeIdList)
        {
            HashSet<int> workGroupTypeIDList = new HashSet<int>();
            workGroupTypeIDList.UnionWith(typeIdList);

            LogUtility.WriteInfo("【取得対象データモデルID】：{0}", string.Join(",", workGroupTypeIDList));

            if (meshCode != null)
            {
                curWorkGroupSearch.LoadOnlySubWorkgroupData(workGroupTypeIDList, meshCode.ToString());
            }
            else
            {
                curWorkGroupSearch.LoadOnlySubWorkgroupData(workGroupTypeIDList);
            }

            List<ulong> deleteExceptList = new List<ulong>();
            foreach (var item in curWorkGroupSearch.DiffDataDict)
            {
                CommWorkGroupData data = item.Value;
                if (data.IsNew || data.IsUpdate)
                {
                    // 新規、新規編集、編集
                    deleteExceptList.Add(item.Key);
                }
            }

            return deleteExceptList;
        }

        /// <summary>
        /// 14.1.24. ワークグループキャッシュに属性変更データの取得
        /// </summary>
        /// <param name="dataSourceID">編集DBのデータサービス</param>
        /// <param name="workGroupID">親ワークグループID</param>
        /// <param name="subWorkGroupID">子ワークグループID</param>
        /// <param name="meshCode">メッシュコード</param>
        /// <param name="typeIdList">タイプIDリスト</param>
        /// <param name="attributeDict">属性リスト</param>
        /// <returns>属性変更データ一覧</returns>
        public static List<ulong> GetAttributeChangedData(
            string dataSourceID,
            ulong workGroupID,
            ulong subWorkGroupID,
            int? meshCode,
            int[] typeIdList,
            Dictionary<string, List<string>> attributeDict)
        {
            List<ulong> result = new List<ulong>();

            // ワークグループデータを検索する
            WorkGroupWrapper curWorkGroupSearch = new WorkGroupWrapper(dataSourceID,
                workGroupID,
                subWorkGroupID);

            try
            {
                // 新規・更新分の差分データを取得する
                List<ulong> deleteExceptList = LoadAddUpdateDiffData(curWorkGroupSearch, meshCode, typeIdList);
                if (deleteExceptList.Count == 0)
                {
                    return result;
                }

                // 編集後データを検索する用データサービスを取得する
                curWorkGroupSearch.InitAfterDS();
                List<GeoItem> afterGeoItemList = GetEditDBData(curWorkGroupSearch.AfterDS, deleteExceptList);

                // 編集前データを検索する用データサービスを取得する
                curWorkGroupSearch.InitBeforeDS();
                GetEditDBData(curWorkGroupSearch.BeforeDS, deleteExceptList);

                foreach (GeoItem afterGeoItem in afterGeoItemList)
                {
                    GeoItem beforeGeoItem = curWorkGroupSearch.BeforeDS.QueryGeoItemFromCacheByOid(afterGeoItem.OID);

                    if (beforeGeoItem == null)
                    {
                        result.Add(afterGeoItem.OID);
                        continue;
                    }

                    bool diffFlag = false;
                    List<string> attributes = attributeDict[afterGeoItem.ContentID];
                    foreach (string attribute in attributes)
                    {
                        PropertyInfo propInfo = afterGeoItem.GetType().GetProperty(attribute);
                        if (propInfo == null)
                        {
                            continue;
                        }

                        object propValueBefore = propInfo.GetValue(beforeGeoItem, null);
                        MultiLangCollection beforeMultLang = null;
                        if (propValueBefore != null && propValueBefore is MultiLangCollection)
                        {
                            beforeMultLang = propValueBefore as MultiLangCollection;
                        }

                        object propValueAfter = propInfo.GetValue(afterGeoItem, null);
                        MultiLangCollection afterMultLang = null;
                        if (propValueAfter != null && propValueAfter is MultiLangCollection)
                        {
                            afterMultLang = propValueAfter as MultiLangCollection;
                        }

                        bool bAfterNull = afterMultLang == null || afterMultLang.MultiLangNameAry.Count == 0;
                        bool bBeforeNull = beforeMultLang == null || beforeMultLang.MultiLangNameAry.Count == 0;
                        if (bAfterNull && bBeforeNull)
                        {
                            // 両方がNULL場合、未変更となる
                            continue;
                        }

                        if (bAfterNull || bBeforeNull)
                        {
                            // 一方がNULL場合、変更となる
                            result.Add(afterGeoItem.OID);
                            break;
                        }

                        foreach (string tag in _langTagAry)
                        {
                            MultiLangName beforeLangName = beforeMultLang[tag];
                            MultiLangName afterLangName = afterMultLang[tag];

                            if (null == afterLangName && null == beforeLangName)
                            {
                                // 両方がNULL場合、未変更となる
                                continue;
                            }

                            if (null == afterLangName || null == beforeLangName || beforeLangName.Name != afterLangName.Name)
                            {
                                // 一方がNULL場合、差分対象となる
                                // 変更がある場合、差分対象となる
                                diffFlag = true;
                                break;
                            }
                        }

                        if (diffFlag)
                        {
                            break;
                        }
                    }

                    if (diffFlag)
                    {
                        result.Add(afterGeoItem.OID);
                    }
                }
            }
            finally
            {
                // 変更前後のデータを解放する
                curWorkGroupSearch.ReleaseAll();
            }

            return result;
        }

        /// <summary>
        /// 編集DBのデータの取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="oidList">対象データOID一覧</param>
        /// <returns>DBのデータモデル</returns>
        private static List<GeoItem> GetEditDBData(
            DataServiceWrapper ds,
            List<ulong> oidList)
        {
            QueryItemsCondition qic = new QueryItemsCondition();
            qic.IDs.AddRange(oidList);

            List<GeoItem> dataList = ds.QueryItemsWithCache(qic);

            return dataList;
        }
    }
}

﻿using System.Collections;
using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.FileOperators.Data;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// タウンジャンルモデルの処理
    /// </summary>
    public class TGnrTwnQuery
    {
        #region 高速化対応 START 4-3.G02-2 改善点③
        /// <summary>
        /// 区切り
        /// </summary>
        public const string DivideChar = ":";

        /// <summary>
        /// タウンジャンルリスト（タウンジャンルのローカルキャッシ）
        /// </summary>
        private static Dictionary<string, TGnrTwn> _cacheGenre { get; set; }
        #endregion

        /// <summary>
        /// AddCacheGenre
        /// </summary>
        /// <param name="tGnrTwn">tGnrTwn</param>
        public static void AddCacheGenre(TGnrTwn tGnrTwn)
        {
            if (_cacheGenre == null)
            {
                _cacheGenre = new Dictionary<string, TGnrTwn>();
            }

            _cacheGenre.Add(tGnrTwn.BasicCode + TGnrTwnQuery.DivideChar + tGnrTwn.NTTCode, tGnrTwn);
        }

        /// <summary>
        /// タウンジャンルモデルの全件データを取得する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <returns>タウンジャンルモデルデータ</returns>
        public static List<TGnrTwn> LoadTGnrTwn(DataService ds)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(タウンジャンル)設定
            qic.TypeIDs.Add(typeof(TGnrTwn).Name);

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをSCrsMainに変換する
            List<TGnrTwn> resultTGnrTwn = resultItem.ConvertAll(s => (TGnrTwn)s);

            return resultTGnrTwn;
        }

        /// <summary>
        /// タウンジャンルモデルの全件データを取得する
        /// タウンジャンルのローカルキャッシ
        /// </summary>
        /// <param name="ds">データサービス</param>
        public static void InitCacheGenre(DataService ds)
        {
            if (_cacheGenre == null)
            {
                _cacheGenre = new Dictionary<string, TGnrTwn>();
            }
            else
            {
                _cacheGenre.Clear();
            }

            List<TGnrTwn> resultTGnrTwn = TGnrTwnQuery.LoadTGnrTwn(ds);
            foreach (TGnrTwn item in resultTGnrTwn)
            {
                // _cacheGenre.Add(item.BasicCode + TGnrTwnQuery.DivideChar + item.NTTCode, item);
                AddCacheGenre(item);
            }
        }

        /// <summary>
        /// タウンジャンルのローカルキャッシをクリアする
        /// </summary>
        public static void ClearCacheGenre()
        {
            if (_cacheGenre != null)
            {
                _cacheGenre.Clear();
            }
        }

        /// <summary>
        /// OIDに応じて、タウンジャンルモデルのデータを取得する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="oid">OID</param>
        /// <returns>タウンジャンルモデルデータ</returns>
        public static List<TGnrTwn> LoadTGnrTwnByOid(DataService ds, ulong oid)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(タウンジャンル)設定
            qic.TypeIDs.Add(typeof(TGnrTwn).Name);

            // 検索条件：OID
            qic.IDs.Add(oid);

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをSCrsMainに変換する
            List<TGnrTwn> resultTGnrTwn = resultItem.ConvertAll(s => (TGnrTwn)s);

            return resultTGnrTwn;
        }

        /// <summary>
        /// タウンジャンルリストから基本分類コードとNTT分類コードでタウンジャンルを抽出する。
        /// </summary>
        /// <param name="ds">データサッビース</param>
        /// <param name="baseCode">基本分類コード</param>
        /// <param name="nttCode">NTT分類コード</param>
        /// <returns>タウンジャンルモデル</returns>
        public static List<TGnrTwn> LoadTGnrTwnBySortCode(DataService ds, string baseCode, string nttCode)
        {
            #region 高速化対応 START 4-3.G02-2 改善点③
            ////// データ検索対象作成
            ////QueryItemsCondition qic = new QueryItemsCondition();

            ////// 検索結果データタイプ(タウンジャンル)設定
            ////qic.TypeIDs.Add(typeof(TGnrTwn).Name);

            ////// 検索条件：基本分類コード
            ////SqlConditionExpression q1 = new SqlConditionExpression("BasicCode", QueryItemOperator.Equal, baseCode);

            ////// NTT分類コード
            ////SqlConditionExpression q2 = new SqlConditionExpression("NTTCode", QueryItemOperator.Equal, nttCode);

            ////// 検索条件組合せ
            ////qic.ConditionExpression = SqlConditionExpression.And(q1, q2);

            ////// データモデルリスト取得
            ////List<GeoItem> resultItem = ds.QueryItems(qic);

            ////// GeoItemをTGnrTwnに変換する
            ////List<TGnrTwn> resultTGnrTwn = resultItem.ConvertAll(s => (TGnrTwn)s);
            List<TGnrTwn> resultTGnrTwn = new List<TGnrTwn>();
            if (_cacheGenre.ContainsKey(baseCode + DivideChar + nttCode))
            {
                // タウンジャンルリストから下記の条件でタウンジャンルを抽出する。
                resultTGnrTwn.Add(_cacheGenre[baseCode + DivideChar + nttCode]);
            }
            #endregion

            return resultTGnrTwn;
        }

        /// <summary>
        /// NTT分類コード条件リストを元にタウンジャンルを検索する
        /// </summary>
        /// <param name="ds">データサッビース</param>
        /// <param name="conExpressData">NTT分類コード条件リスト</param>
        /// <returns>タウンジャンルモデル</returns>
        public static List<TGnrTwn> LoadTGnrTwnByNTTCodeList(DataService ds, List<ConditionExpressData> conExpressData)
        {
            Hashtable hashExpress = new Hashtable();

            // 抽出対象外
            hashExpress.Add("<>", QueryItemOperator.NotEqual);

            // 抽出対象
            hashExpress.Add("=", QueryItemOperator.Equal);

            // 設定値以下
            hashExpress.Add("<=", QueryItemOperator.LessEqual);

            // 設定値以上
            hashExpress.Add(">=", QueryItemOperator.GreatEqual);

            // 設定値未満
            hashExpress.Add("<", QueryItemOperator.Less);

            // 設定値より大
            hashExpress.Add(">", QueryItemOperator.Great);

            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(タウンジャンル)設定
            qic.TypeIDs.Add(typeof(TGnrTwn).Name);

            // インデックス
            int i = 0;

            // 一件目検索条件を保存
            SqlConditionExpression condExpressTotal =
                new SqlConditionExpression("NTTCode", (QueryItemOperator)hashExpress[conExpressData[0].Expression], conExpressData[0].Value);

            foreach (var item in conExpressData)
            {
                if (i != 0)
                {
                    // NTT分類コード
                    SqlConditionExpression currentCondtion = new SqlConditionExpression("NTTCode", (QueryItemOperator)hashExpress[item.Expression], item.Value);

                    if (item.AndOr == "AND")
                    {
                        // 検索条件組合せ
                        condExpressTotal = SqlConditionExpression.And(condExpressTotal, currentCondtion);
                    }

                    if (item.AndOr == "OR")
                    {
                        // 検索条件組合せ
                        condExpressTotal = SqlConditionExpression.Or(condExpressTotal, currentCondtion);
                    }
                }

                i = i + 1;
            }

            qic.ConditionExpression = condExpressTotal;

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをTGnrTwnに変換する
            List<TGnrTwn> resultTGnrTwn = resultItem.ConvertAll(s => (TGnrTwn)s);

            return resultTGnrTwn;
        }
    }
}

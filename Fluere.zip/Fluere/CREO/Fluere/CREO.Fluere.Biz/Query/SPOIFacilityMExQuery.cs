﻿using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 施設物件拡張モデル
    /// </summary>
    public class SPOIFacilityMExQuery
    {
        /// <summary>
        /// 市区町村コードによる施設物件拡張モデルの検索
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="resultAdrName">市区町村コードによる住所名称モデル</param>
        /// <returns>施設物件拡張モデル</returns>
        public static List<SPOIFacilityMEx> GetSPOIFacilityMExListByAdrnameCode(
            DataService ds, List<LocalAdrName> resultAdrName)
        {
            List<SPOIFacilityMEx> resultSPOIFacilityMEx = new List<SPOIFacilityMEx>();

            foreach (var item in resultAdrName)
            {
                // 施設物件拡張データモデルの検索
                // データ検索対象初期化
                QueryItemsCondition qic = new QueryItemsCondition();

                // 検索結果データタイプ設定
                qic.TypeIDs.Add(typeof(SPOIFacilityMEx).Name);

                // 検索条件：実体OID イコール  物件ジャンルモデルから取得した実体OID
                IConditionExpression q1 = new SqlConditionExpression("AdrName", QueryItemOperator.Equal, item.OID.ToString());

                // 検索条件組合せ
                qic.ConditionExpression = q1;

                // 検索実行(※レコードだけ)
                List<GeoItem> resultGeoItem = ds.QueryItems(qic);

                // GeoItemをSPOIFacilityMExに変換する
                resultGeoItem.ConvertAll(s => (SPOIFacilityMEx)s).ForEach(p => resultSPOIFacilityMEx.Add(p));
            }

            return resultSPOIFacilityMEx;
        }

        /// <summary>
        /// スクールゾーンOIDによる施設物件拡張モデルの検索
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="schOID">スクールゾーンデータのOID</param>
        /// <returns>施設物件拡張モデル</returns>
        public static SPOIFacilityMEx GetSPOIFacilityMExBySchOID(
            DataService ds, ulong schOID)
        {
            // データ検索対象作成
            QueryItemsCondition qic1 = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic1.TypeIDs.Add(typeof(SPOIFacilityMEx).Name);

            qic1.IDs.Add(schOID);

            // 検索実行(※一レコードだけ)
            List<GeoItem> result = ds.QueryItems(qic1);

            // 指定スクールゾーンOIDで取得した施設物件拡張データモデルの件数が1件で判断
            if (result.Count == 1)
            {
                return result[0] as SPOIFacilityMEx;
            }
            else
            {
                // 指定スクールゾーンOIDで取得した施設物件拡張データモデルの件数が1件以外の場合、異常処理
                string msgId = UF_Fluere_MsgId.MSGID_UF00000018;
                throw new BusinessLogicException(msgId, new string[] { "施設物件拡張", "OID", schOID.ToString() });
            }
        }
    }
}

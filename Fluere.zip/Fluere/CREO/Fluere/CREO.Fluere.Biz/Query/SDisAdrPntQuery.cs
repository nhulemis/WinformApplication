﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.DataModel;
using CREO.DS;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 廃止住所代表点
    /// </summary>
    public class SDisAdrPntQuery
    {
        #region 廃止住所代表点データモデルの取得
        /// <summary>
        /// 廃止住所代表点データモデルの取得
        /// 検索条件:住所名称参照オブジェクトID = adrNameOID、局番 ≠ null
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrNameOID">住所名称OID</param>
        /// <returns>GeoItem（リスト）</returns>
        public static List<GeoItem> LoadSDisAdrPntByOid(DataService ds, ulong adrNameOID)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(SDisAdrPnt).Name);

            // 実体OID = 親表実体OID 
            IConditionExpression q1 = new SqlConditionExpression(
                "AdrName", QueryItemOperator.Equal, adrNameOID.ToString());

            // 局番 ≠ NULL
            IConditionExpression q2 = new SqlConditionExpression(
                "AreaCodeAry[*]", QueryItemOperator.NotEqual, string.Empty);

            // 検索条件組合せ(And)
            qic.ConditionExpression = q1.And(q1, q2);

            // 検索実行
            List<GeoItem> result = ds.QueryItems(qic);

            // 戻り値
            return result;
        }

        /// <summary>
        /// 廃止住所代表点データモデルの取得
        /// 条件:住所名称参照オブジェクトID in adrNameOIDList、GEN出力フラグ = 1、局番 ≠ NULL
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrNameOIDList">住所名称のOIDリスト</param>
        /// <returns>廃止住所代表点データ</returns>
        public static List<GeoItem> LoadSDisAdrPntByOidList(DataService ds, string[] adrNameOIDList)
        {
            // データ検索対象作成
            QueryItemsCondition qic1 = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic1.TypeIDs.Add(typeof(SDisAdrPnt).Name);

            // 廃止住所名称参照オブジェクトID = 住所名称．オブジェクトID
            IConditionExpression q1 = new SqlConditionExpression(
                "AdrName", QueryItemOperator.In, adrNameOIDList);

            // 局番 ≠ NULL
            IConditionExpression q2 = new SqlConditionExpression(
                "AreaCodeAry[*]", QueryItemOperator.NotEqual, string.Empty);

            // 検索条件組合せ(And)
            qic1.ConditionExpression = q1.And(q1, q2);

            // 検索実行
            List<GeoItem> result = ds.QueryItems(qic1);

            // 戻り値
            return result;
        }

        /// <summary>
        /// 廃止住所代表点データモデル（市区町村）の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrNameOIDList">住所名称のOIDリスト</param>
        /// <returns>GeoItem（リスト）</returns>
        public static List<GeoItem> LoadSDisAdrPntByOidListNoAreaCode(DataService ds, string[] adrNameOIDList)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(SDisAdrPnt).Name);

            // 実体OID = 親表実体OID 
            IConditionExpression q1 = new SqlConditionExpression(
                "AdrName", QueryItemOperator.In, adrNameOIDList);

            // 検索条件組合せ(And)
            qic.ConditionExpression = q1;

            // 検索実行
            List<GeoItem> result = ds.QueryItems(qic);

            // 戻り値
            return result;
        }
        #endregion

        #region 直接地番と同じ市区町村にある廃止住所代表点の取得
        /// <summary>
        /// 廃止住所代表点の取得
        /// 検索条件:住所名称参照オブジェクトID = adrNameOID かつGEN出力フラグ = 1
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrNameOID">住所名称OID</param>
        /// <returns>GeoItem（リスト）</returns>
        public static List<GeoItem> LoadSDisAdrPntByAdrNameOID(DataService ds, ulong adrNameOID)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(SDisAdrPnt).Name);

            // 住所名称（TAdrName）参照オブジェクトID = 住所名称．オブジェクトID
            IConditionExpression q1 = new SqlConditionExpression(
                "AdrName", QueryItemOperator.Equal, adrNameOID.ToString());

            // 検索条件組合せ(And)
            qic.ConditionExpression = q1;

            // 検索実行
            List<GeoItem> result = ds.QueryItems(qic);

            // 戻り値
            return result;
        }
        #endregion

        #region 住所名称、住所代表点レベルによって、廃止住所代表点を検索する
        /// <summary>
        /// 住所名称、住所代表点レベルによって、廃止住所代表点を検索する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adrNameOIDList">住所名称OIDリスト</param>
        /// <returns>廃止住所代表点データ</returns>
        public static List<SDisAdrPnt> LoadSDisAdrPntByTAdrName(DataService ds, string[] adrNameOIDList)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(廃止住所代表点)設定
            qic.TypeIDs.Add(typeof(SDisAdrPnt).Name);

            // 検索条件：≪住所名称≫
            SqlConditionExpression q1 = new SqlConditionExpression("AdrName", QueryItemOperator.In, adrNameOIDList);

            // 検索条件：≪廃止住所名称≫
            SqlConditionExpression q2 = new SqlConditionExpression("DisAdrName", QueryItemOperator.Equal, null);

            // 検索条件：住所代表点レベルコード>=3
            SqlConditionExpression q3 = new SqlConditionExpression("AdrLvlCode", QueryItemOperator.GreatEqual, 3);

            // 検索条件：住所代表点レベルコード<=8
            SqlConditionExpression q4 = new SqlConditionExpression("AdrLvlCode", QueryItemOperator.LessEqual, 8);

            QueryItemsPostProcess qipp = new QueryItemsPostProcess();
            qipp.Flags = QueryItemsPostProcessFlags.GetReferences;
            qipp.TypeIDs.Add("TAdrName");
            qic.QueryItemsPostProcess = qipp;

            // 検索条件組合せ
            qic.ConditionExpression = SqlConditionExpression.And(q1, q2, q3, q4);

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをSDisAdrPntに変換する
            List<SDisAdrPnt> resultSDisAdrPnt = resultItem.OfType<SDisAdrPnt>().ToList();

            return resultSDisAdrPnt;
        }
        #endregion

        #region 廃止住所名称、住所代表点レベルによって、廃止住所代表点を検索する
        /// <summary>
        /// 廃止住所名称、住所代表点レベルによって、廃止住所代表点を検索する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adrNameOIDList">廃止住所名称OIDリスト</param>
        /// <param name="adrLvlCodeStart">住所代表点レベルコード開始</param>
        /// <param name="adrLvlCodeEnd">住所代表点レベルコード最後</param>
        /// <returns>廃止住所代表点データ</returns>
        public static List<SDisAdrPnt> LoadSDisAdrPntBySDisAdrName(
            DataService ds, string[] adrNameOIDList, int adrLvlCodeStart, int adrLvlCodeEnd)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(廃止住所代表点)設定
            qic.TypeIDs.Add(typeof(SDisAdrPnt).Name);

            // 検索条件：≪住所名称≫
            SqlConditionExpression q1 = new SqlConditionExpression("AdrName", QueryItemOperator.Equal, null);

            // 検索条件：≪廃止住所名称≫
            SqlConditionExpression q2 = new SqlConditionExpression("DisAdrName", QueryItemOperator.In, adrNameOIDList);

            // 検索条件：住所代表点レベルコード>=3
            SqlConditionExpression q3 = new SqlConditionExpression("AdrLvlCode", QueryItemOperator.GreatEqual, adrLvlCodeStart);

            // 検索条件：住所代表点レベルコード<=8
            SqlConditionExpression q4 = new SqlConditionExpression("AdrLvlCode", QueryItemOperator.LessEqual, adrLvlCodeEnd);
                        
            QueryItemsPostProcess qipp = new QueryItemsPostProcess();
            qipp.Flags = QueryItemsPostProcessFlags.GetReferences;
            qipp.TypeIDs.Add("TDisAdrName");
            qic.QueryItemsPostProcess = qipp;

            // 検索条件組合せ
            qic.ConditionExpression = SqlConditionExpression.And(q1, q2, q3, q4);

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをSDisAdrPntに変換する
            List<SDisAdrPnt> resultSDisAdrPnt = resultItem.OfType<SDisAdrPnt>().ToList();

            return resultSDisAdrPnt;
        }
        #endregion
    }
}

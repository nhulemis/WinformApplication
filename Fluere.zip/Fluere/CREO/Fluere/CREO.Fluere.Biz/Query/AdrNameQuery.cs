﻿using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 市区町村名を管理するクラス
    /// </summary>
    public class AdrNameQuery
    {
        #region ログマネージャーのインスタンス、メッセージマネージャーのインスタンス
        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        private static LogManager _loggMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);
        #endregion

        #region 定数定義 ネストレベル
        /// <summary>
        /// 0:都道府県まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A0_ONLY = 0;

        /// <summary>
        /// 1:市区町村まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A1_ONLY = 1;

        /// <summary>
        /// 2:大字まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A1_A2 = 2;

        /// <summary>
        /// 3:小字まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A1_A2_A3 = 3;
        #endregion

        #region 処理フロー制御用の住所名称を取得する処理
        #region 市区町村コードで都道府県或いは市区町村の住所名称の取得処理
        /// <summary>
        /// 市区町村コードで都道府県或いは市区町村の住所名称の取得処理
        /// ネストレベル =  0:都道府県の住所名称。1:市区町村の住所名称。
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrnameCode">都道府県と市区町村コード(5桁)</param>
        /// <param name="nestLevel">ネストレベル</param>
        /// <returns>住所名称</returns>
        public static string GetTAdNameString(DataService ds, string adrnameCode, long nestLevel)
        {
            List<LocalAdrName> curLocalAdrNameList = TAdrNameQuery.GetLocalAdrName(ds, adrnameCode, nestLevel);
            if (curLocalAdrNameList.Count > 0)
            {
                return curLocalAdrNameList[0].Name;
            }

            return string.Empty;
        }
        #endregion

        #region 市区町村コードで住所名称の取得処理
        /// <summary>
        /// 市区町村コードで住所名称の取得処理
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrnameCode">都道府県と市区町村コード(5桁)</param>
        /// <param name="nestLevel">ネストレベル</param>
        /// <returns>検索結果データモデルリスト</returns>
        public static List<LocalAdrName> GetTAdrNameList(DataService ds, string adrnameCode, long nestLevel)
        {
            List<LocalAdrName> curLocalAdrNameList = TAdrNameQuery.GetLocalAdrName(ds, adrnameCode, nestLevel);
            if (curLocalAdrNameList.Count < 1)
            {
                #region 性能測定ログを出力
                _loggMgr.WriteDebug("※GetTAdrNameList No Data: {0},{1}", adrnameCode, nestLevel);
                #endregion
            }

            return curLocalAdrNameList;
        }
        #endregion

        #region 市区町村コードで廃止住所名称の取得処理
        /// <summary>
        /// 市区町村コードで廃止住所名称の取得処理
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="adrnameCode">都道府県と市区町村コード(5桁)</param>
        /// <param name="nestLevel">ネストレベル</param>
        /// <returns>廃止住所名称データモデル</returns>
        public static List<LocalDisAdrName> GetTDisAdrNameList(DataService ds, string adrnameCode, long nestLevel)
        {
            List<LocalDisAdrName> curLocalAdrNameList = TDisAdrNameQuery.GetLocalDisAdrName(ds, adrnameCode, nestLevel);
            if (curLocalAdrNameList.Count < 1)
            {
                #region 性能測定ログを出力
                _loggMgr.WriteDebug("※GetTDisAdrNameList No Data: {0},{1}", adrnameCode, nestLevel);
                #endregion
            }

            return curLocalAdrNameList;
        }
        #endregion
        #endregion

        #region 業務処理で、変更・削除用の住所名称を取得する処理
        #region 住所コード（aabbb-cccc-dd）によって、住所名称データモデルを取得
        /// <summary>
        /// 住所コードによって、住所名称データモデルリストの取得
        /// 住所コードの例：aabbb, aabbb-cccc, aabbb-cccc-ddd
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adrCode">住所コード</param>
        /// <returns>住所名称データモデル</returns>
        public static TAdrName LoadAdrNameByAdrCode(DataService ds, string adrCode)
        {
            // '-'で住所コードの切り分け
            string[] adrCodeArr = adrCode.Split('-');

            if (adrCodeArr.Length > 3)
            {
                string err = "住所コードのフォーマットは「aabbb-cccc-dd」と設けられるのですが、実は{0}になってしまいました。";
                err = string.Format(err, adrCode);
                throw new BusinessLogicException(adrCode);
            }

            // 都道府県コードに対する住所名称の取得
            if (adrCodeArr.Length == 1 && adrCodeArr[0].Length <= 2)
            {
                List<LocalAdrName> provinceLocalAdrNameList =
                    TAdrNameQuery.GetLocalAdrName(ds, adrCodeArr[0], ADMINISTRATIVE_CODE_A0_ONLY);

                if (provinceLocalAdrNameList.Count > 0)
                {
                    return TAdrNameQuery.LoadTAdrNameByOID(ds, provinceLocalAdrNameList[0].OID);
                }

                return null;
            }

            // 都道府県コード＋市区町村コードに対する住所名称の取得
            LocalAdrName curSiLocalAdrName = null;
            List<LocalAdrName> adminLocalAdrNameList =
                TAdrNameQuery.GetLocalAdrName(ds, adrCodeArr[0], ADMINISTRATIVE_CODE_A1_ONLY);
            if (adminLocalAdrNameList.Count > 0)
            {
                curSiLocalAdrName = adminLocalAdrNameList[0];
            }

            // 市レベルデータがなし
            if (curSiLocalAdrName == null)
            {
                return null;
            }

            // 市区町村コード場合
            if (adrCodeArr.Length == 1)
            {
                return TAdrNameQuery.LoadTAdrNameByOID(ds, curSiLocalAdrName.OID);
            }

            ushort ooazNum;
            if (!ushort.TryParse(adrCodeArr[1], out ooazNum))
            {
                string err = "大字コード{0}が数字に変更出来ません";
                err = string.Format(err, adrCodeArr[1]);
                throw new BusinessLogicException(err);
            }

            // 大字データを取得
            TAdrNameQuery.InitChildAdrName(ds, curSiLocalAdrName);

            LocalAdrName curOoazaLocalAdrName = null;
            foreach (LocalAdrName tempLocalAdrName in curSiLocalAdrName.Childs)
            {
                if (tempLocalAdrName.AdrCode.Equals(ooazNum))
                {
                    curOoazaLocalAdrName = tempLocalAdrName;
                    break;
                }
            }

            // 大字レベルデータがなし
            if (curOoazaLocalAdrName == null)
            {
                return null;
            }

            if (adrCodeArr.Length == 2)
            {
                return TAdrNameQuery.LoadTAdrNameByOID(ds, curOoazaLocalAdrName.OID);
            }

            ushort koazNum;
            if (!ushort.TryParse(adrCodeArr[2], out koazNum))
            {
                string err = "小字コード{0}が数字に変更出来ません";
                err = string.Format(err, adrCodeArr[2]);
                throw new BusinessLogicException(err);
            }

            TAdrNameQuery.InitChildAdrName(ds, curOoazaLocalAdrName);

            LocalAdrName curCoazaLocalAdrName = null;
            foreach (LocalAdrName tempLocalAdrName in curOoazaLocalAdrName.Childs)
            {
                if (tempLocalAdrName.AdrCode.Equals(koazNum))
                {
                    curCoazaLocalAdrName = tempLocalAdrName;
                    break;
                }
            }

            if (curCoazaLocalAdrName == null)
            {
                return null;
            }

            return TAdrNameQuery.LoadTAdrNameByOID(ds, curCoazaLocalAdrName.OID);
        }
        #endregion

        #region 住所コード（aabbb-cccc-dd）によって、廃止住所名称データモデルを取得
        /// <summary>
        /// 住所コードによって、廃止住所名称データモデルリストの取得
        /// 住所コードの例：aabbb, aabbb-cccc, aabbb-cccc-ddd
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adrCode">住所コード</param>
        /// <returns>廃止住所名称データモデル</returns>
        public static TDisAdrName LoadDisAdrNameByAdrCode(DataService ds, string adrCode)
        {
            // '-'で住所コードの切り分け
            string[] adrCodeArr = adrCode.Split('-');

            if (adrCodeArr.Length > 3)
            {
                string err = "住所コードのフォーマットは「aabbb-cccc-dd」と設けられるのですが、実は{0}になってしまいました。";
                err = string.Format(err, adrCode);
                throw new BusinessLogicException(adrCode);
            }

            // 都道府県コードに対する住所名称の取得
            if (adrCodeArr.Length == 1 && adrCodeArr[0].Length <= 2)
            {
                List<LocalDisAdrName> provinceLocalDisAdrNameList =
                    TDisAdrNameQuery.GetLocalDisAdrName(ds, adrCodeArr[0], ADMINISTRATIVE_CODE_A0_ONLY, false);

                if (provinceLocalDisAdrNameList.Count > 0)
                {
                    // 2012-11-05 HP-liucheng update
                    ////if (true || !provinceLocalDisAdrNameList[0].DummyAdrFlag)
                    ////{
                    return TDisAdrNameQuery.LoadTDisAdrNameByOID(ds, provinceLocalDisAdrNameList[0].OID);
                    ////}
                    ////else
                    ////{
                    ////    return null;
                    ////}
                }

                return null;
            }

            // 都道府県コード＋市区町村コードに対する住所名称の取得
            LocalDisAdrName curSiLocalDisAdrName = null;
            List<LocalDisAdrName> adminLocalAdrNameList =
                TDisAdrNameQuery.GetLocalDisAdrName(ds, adrCodeArr[0], ADMINISTRATIVE_CODE_A1_ONLY, false);
            if (adminLocalAdrNameList.Count > 0)
            {
                curSiLocalDisAdrName = adminLocalAdrNameList[0];
            }

            // 市レベルデータがなし
            if (curSiLocalDisAdrName == null)
            {
                return null;
            }

            // 市区町村コード場合
            if (adrCodeArr.Length == 1)
            {
                // 2012-11-05 HP-liucheng update
                ////if (true || !curSiLocalDisAdrName.DummyAdrFlag)
                ////{
                return TDisAdrNameQuery.LoadTDisAdrNameByOID(ds, curSiLocalDisAdrName.OID);
                ////}
                ////else
                ////{
                ////    return null;
                ////}
            }

            ushort ooazNum;
            if (!ushort.TryParse(adrCodeArr[1], out ooazNum))
            {
                string err = "大字コード{0}が数字に変更出来ません";
                err = string.Format(err, adrCodeArr[1]);
                throw new BusinessLogicException(err);
            }

            // 大字データを取得
            TDisAdrNameQuery.InitChildDisAdrName(ds, curSiLocalDisAdrName);

            LocalDisAdrName curOoazaLocalDisAdrName = null;
            foreach (LocalDisAdrName tempLocalAdrName in curSiLocalDisAdrName.Childs)
            {
                if (tempLocalAdrName.AdrCode.Equals(ooazNum))
                {
                    curOoazaLocalDisAdrName = tempLocalAdrName;
                    break;
                }
            }

            // 大字レベルデータがなし
            if (curOoazaLocalDisAdrName == null)
            {
                return null;
            }

            if (adrCodeArr.Length == 2)
            {
                if (!curOoazaLocalDisAdrName.DummyAdrFlag)
                {
                    return TDisAdrNameQuery.LoadTDisAdrNameByOID(ds, curOoazaLocalDisAdrName.OID);
                }
                else
                {
                    return null;
                }
            }

            ushort koazNum;
            if (!ushort.TryParse(adrCodeArr[2], out koazNum))
            {
                string err = "小字コード{0}が数字に変更出来ません";
                err = string.Format(err, adrCodeArr[2]);
                throw new BusinessLogicException(err);
            }

            TDisAdrNameQuery.InitChildDisAdrName(ds, curOoazaLocalDisAdrName);

            LocalDisAdrName curCoazaLocalDisAdrName = null;
            foreach (LocalDisAdrName tempLocalAdrName in curOoazaLocalDisAdrName.Childs)
            {
                if (tempLocalAdrName.AdrCode.Equals(koazNum))
                {
                    curCoazaLocalDisAdrName = tempLocalAdrName;
                    break;
                }
            }

            if (curCoazaLocalDisAdrName == null || curCoazaLocalDisAdrName.DummyAdrFlag)
            {
                return null;
            }

            return TDisAdrNameQuery.LoadTDisAdrNameByOID(ds, curCoazaLocalDisAdrName.OID);
        }
        #endregion
        #endregion
        // Refactory Area
        #region 市区町村（例10202）によって、住所名称データの取得
        /// <summary>
        /// 都道府県コード＋市区町村コード（例10202）によって、住所名称データの取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="municipalityCode">都道府県コード＋市区町村コード（例10202）</param>
        /// <returns>住所名称(TAdrName)</returns>
        public static TAdrName LoadTAdrNameByMunicipalityCode(
            DataService ds,
            string municipalityCode)
        {
            // 市区町村コードのチェック
            if (string.IsNullOrWhiteSpace(municipalityCode) ||
                municipalityCode.Length != 5)
            {
                string err = "入力市区町村の桁数が5桁になると設けられるのですが、入力値が{0}になってしまいました。";
                err = string.Format(err, municipalityCode);
                throw new BusinessLogicException(err);
            }

            return LoadAdrNameByAdrCode(ds, municipalityCode);
        }
        #endregion
    }
}

﻿using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 駐車場物件データモデルの取得するクラス
    /// </summary>
    public class SPOIParkingQuery
    {
        #region コンテンツタイプかつ駐車場ＩＤによって、駐車場物件データモデルの取得
        /// <summary>
        /// コンテンツタイプかつ駐車場ＩＤによって、駐車場物件データモデルの取得、エラーチェックが無し
        /// 呼び出し側でエラーチェックを実施すると想定
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="parkingID">駐車場ＩＤ</param>
        /// <returns>駐車場物件データモデルデータ</returns>
        public static SPOIParking LoadSPOIParking(DataService ds, string parkingID)
        {
            // データ検索対象作成
            QueryItemsCondition qic1 = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic1.TypeIDs.Add(DataModelTypeID.CONTENTS_TYPE_SPOIPARKING);

            // 駐車場ＩＤ=上記取得した駐車場ＩＤ 
            IConditionExpression q1 = new SqlConditionExpression(
                "ParkingID", QueryItemOperator.Equal, parkingID);

            // 検索条件組合せ(And)
            qic1.ConditionExpression = q1;

            // 検索実行(※一レコードだけ)
            List<GeoItem> result = ds.QueryItems(qic1);

            // 指定駐車場ＩＤで取得した駐車場物件データモデルの件数が1件で判断
            if (result.Count == 1)
            {
                return result[0] as SPOIParking;
            }
            else
            {
                // 指定駐車場ＩＤで取得した駐車場物件データモデルの件数が1件以外の場合、異常処理
                string msgId = UF_Fluere_MsgId.MSGID_UF20003014;
                throw new BusinessLogicException(msgId, new string[] { parkingID });
            }
        }
        #endregion
    }
}

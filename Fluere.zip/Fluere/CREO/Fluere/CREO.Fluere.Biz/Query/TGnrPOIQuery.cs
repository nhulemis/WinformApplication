﻿using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 物件ジャンルデータモデルの取得するクラス
    /// </summary>
    public class TGnrPOIQuery
    {
        #region 施設物件ジャンルコードによって、施設物件データモデルの取得
        /// <summary>
        /// コンテンツタイプかつ施設物件ジャンルコードによって、物件ジャンルデータモデルの取得、エラーチェックが無し
        /// 呼び出し側でエラーチェックを実施すると想定
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="parentGnrPOICode">親施設物件ジャンルコード</param>
        /// <param name="childGnrPOICode">子施設物件ジャンルコード</param>
        /// <returns>物件ジャンルモデルデータ</returns>
        public static TGnrPOI LoadTGnrPOI(DataService ds, string parentGnrPOICode, string childGnrPOICode)
        {
            // データ検索対象作成
            QueryItemsCondition qic1 = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic1.TypeIDs.Add(typeof(TGnrPOI).Name);

            // 親施設物件ジャンルコード
            IConditionExpression q1 = new SqlConditionExpression(
                "GnrCode", QueryItemOperator.Equal, ushort.Parse(parentGnrPOICode));

            // ネストレベル０
            IConditionExpression q2 = new SqlConditionExpression("NestLevel", QueryItemOperator.Equal, 0);

            // 検索条件組合せ(And)
            qic1.ConditionExpression = q1.And(q1, q2);

            // 検索実行(※一レコードだけ)
            List<GeoItem> result = ds.QueryItems(qic1);

            // 指定施設物件ジャンルコードで取得した親施設物件ジャンルデータモデルあり(1件のみ)
            if (result.Count == 1)
            {
                TGnrPOI parentTGnrPOI = result[0] as TGnrPOI;

                // データ検索対象作成
                qic1 = new QueryItemsCondition();

                // 検索結果データタイプ設定
                qic1.TypeIDs.Add(typeof(TGnrPOI).Name);

                // 子施設物件ジャンルコード
                q1 = new SqlConditionExpression(
                    "GnrCode", QueryItemOperator.Equal, ushort.Parse(childGnrPOICode));

                // ネストレベル１
                q2 = new SqlConditionExpression("NestLevel", QueryItemOperator.Equal, 1);

                // 親OID
                IConditionExpression q3 = new SqlConditionExpression("ParentTableOID", QueryItemOperator.Equal, parentTGnrPOI.OIDString);

                // 検索条件組合せ(And)
                qic1.ConditionExpression = q1.And(q1, q2, q3);

                // 検索実行(※一レコードだけ)
                result = ds.QueryItems(qic1);
                if (result.Count == 1)
                {
                    return result[0] as TGnrPOI;
                }
                else
                {
                    string msgId = UF_Fluere_MsgId.MSGID_UF20002046;
                    string[] parameters = new string[] { "1", childGnrPOICode };
                    throw new BusinessLogicException(msgId, parameters);
                }
            }
            else
            {
                string msgId = UF_Fluere_MsgId.MSGID_UF20002046;
                string[] parameters = new string[] { "0", parentGnrPOICode };
                throw new BusinessLogicException(msgId, parameters);
            }
        }
        #endregion
    }
}

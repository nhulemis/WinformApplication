﻿using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// タウン物件
    /// </summary>
    public class STwnPOIQuery
    {
        /// <summary>
        /// タウン物件
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="oid">OID</param>
        /// <returns>タウン物件モデル</returns>
        public static List<STwnPOI> GetSTwnPOIByOid(DataService ds, ulong oid)
        {
            List<STwnPOI> resultSTwnPOI = new List<STwnPOI>();

            // データ検索対象初期化
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(STwnPOI).Name);

            // 検索条件：実体OID
            qic.IDs.Add(oid);

            // 検索実行(※レコードだけ)
            List<GeoItem> resultGeoItem = ds.QueryItems(qic);

            // GeoItemをSTwnPOIに変換する
            resultGeoItem.ConvertAll(s => (STwnPOI)s).ForEach(p => resultSTwnPOI.Add(p));

            return resultSTwnPOI;
        }

        /// <summary>
        /// タウンジャンルのOIDにより、タウン物件を検索する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="oid">OID</param>
        /// <returns>タウン物件モデル</returns>
        public static List<STwnPOI> GetSTwnPOIByTGnrTwnOid(DataService ds, ulong oid)
        {
            List<STwnPOI> resultSTwnPOI = new List<STwnPOI>();

            // データ検索対象初期化
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(STwnPOI).Name);

            // 検索条件：実体OID イコール  タウンジャンルモデルから取得した実体OID
            IConditionExpression q1 = new SqlConditionExpression("GnrTwn", QueryItemOperator.Equal, oid.ToString());

            // 検索条件組合せ
            qic.ConditionExpression = q1;

            // 検索実行(※レコードだけ)
            List<GeoItem> resultGeoItem = ds.QueryItems(qic);

            // GeoItemをSTwnPOIに変換する
            resultGeoItem.ConvertAll(s => (STwnPOI)s).ForEach(p => resultSTwnPOI.Add(p));

            return resultSTwnPOI;
        }

        /// <summary>
        /// タウンジャンルのOIDにより、タウン物件を検索する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="oid">OID</param>
        /// <returns>タウン物件モデルの件</returns>
        public static int GetSTwnPOICountByTGnrTwnOid(DataService ds, ulong oid)
        {
            List<STwnPOI> resultSTwnPOI = new List<STwnPOI>();

            // データ検索対象初期化
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(STwnPOI).Name);

            // 検索条件：実体OID イコール  タウンジャンルモデルから取得した実体OID
            IConditionExpression q1 = new SqlConditionExpression("GnrTwn", QueryItemOperator.Equal, oid.ToString());

            // 検索条件組合せ
            qic.ConditionExpression = q1;

            // 検索実行(※レコードだけ)
            return ds.QueryItemsCount(qic);
        }

        /// <summary>
        /// 掲載名（漢字）と住所名称（都道府県レベル、市区町村レベル）＋大字以下連結住所により、タウン物件を検索する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="sTwnPOI">タウン物件</param>
        /// <param name="tAdrName">住所名称</param>
        /// <returns>タウン物件モデル</returns>
        public static List<STwnPOI> GetSTwnPOIBySameAdrNameInfo(DataService ds, STwnPOI sTwnPOI, TAdrName tAdrName)
        {
            List<STwnPOI> resultSTwnPOI = new List<STwnPOI>();

            // データ検索対象初期化
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(STwnPOI).Name);

            // 検索条件：掲載名
            SqlConditionExpression q1 = new SqlConditionExpression(
                "TwnMultiLang.MultiLangNameAry[*].IETFLangTag", QueryItemOperator.Equal, "ja-Jpan");
            SqlConditionExpression q2 = new SqlConditionExpression(
                "TwnMultiLang.MultiLangNameAry[*].Name", QueryItemOperator.Equal, sTwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name);

            // 検索条件：実体OID イコール  住所名称モデルから取得した実体OID
            IConditionExpression q3;

            if (tAdrName == null)
            {
                q3 = new SqlConditionExpression("AdrName", QueryItemOperator.Equal, null);
            }
            else
            {
                q3 = new SqlConditionExpression("AdrName", QueryItemOperator.Equal, tAdrName.OID.ToString());
            }

            // 検索条件：方書
            SqlConditionExpression q11 = new SqlConditionExpression(
                "BelowOazaJaJpan", QueryItemOperator.Equal, sTwnPOI.BelowOazaJaJpan);

            // 検索条件組合せ
            qic.ConditionExpression = q1.And(q2, q3, q11);

            // 検索実行(※レコードだけ)
            List<GeoItem> resultGeoItem = ds.QueryItems(qic);

            // GeoItemをSTwnPOIに変換する
            resultGeoItem.ConvertAll(s => (STwnPOI)s).ForEach(p => resultSTwnPOI.Add(p));

            return resultSTwnPOI;
        }

        /// <summary>
        /// 市区町村コードとTMI作成タウン物件コードにより、タウン物件を検索する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="adminCode">市区町村コード</param>
        /// <param name="tmiTwnPOICode">TMI作成タウン物件コード</param>
        /// <param name="adrName">タウン物件の住所名称</param>
        /// <returns>タウン物件モデル</returns>
        public static List<STwnPOI> GetSTwnPOIByAdminCodeAndTMITwnPOICode(DataService ds, string adminCode, string tmiTwnPOICode, ref LocalAdrName adrName)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                                                   "出典マスタのタウン物件の取得",
                                                   LogUtility.LogModel.DebugModel);

            List<STwnPOI> resultSTwnPOI = new List<STwnPOI>();

            // 指定市区町村に対して市区町村リストを所得する
            List<LocalAdrName> adrNameList = AdrNameQuery.GetTAdrNameList(ds,
                                                                          adminCode,
                                                                          AdrNameQuery.ADMINISTRATIVE_CODE_A1_ONLY);
            if (adrNameList.Count < 1)
            {
                return resultSTwnPOI;
            }

            // 指定市区町村でのタウン物件データモデルの取得                   
            adrName = adrNameList[0];

            // データ検索対象初期化
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(STwnPOI).Name);

            // 検索条件：住所名称 = 上記取得した住所名称データモデル
            SqlConditionExpression q1 = new SqlConditionExpression("AdrName",
                                                                 QueryItemOperator.Equal,
                                                                 adrName.OID.ToString());

            // タウン座標更新設定ファイルの処理対象フラグが1の場合
            if (tmiTwnPOICode == "1")
            {
                SqlConditionExpression q2 = new SqlConditionExpression("TMITwnPOICode", QueryItemOperator.Equal, null);

                // 検索条件組合せ(And)
                qic.ConditionExpression = SqlConditionExpression.And(q1, q2);
            }
            else
            {
                // 検索条件組合せ
                qic.ConditionExpression = q1;
            }

            // 検索実行(※レコードだけ)
            List<GeoItem> resultGeoItem = ds.QueryItems(qic);

            // GeoItemをSTwnPOIに変換する
            resultGeoItem.ConvertAll(s => (STwnPOI)s).ForEach(p => resultSTwnPOI.Add(p));

            logUtility.WriteNormalEnd();

            return resultSTwnPOI;
        }
    }
}

﻿using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 基幹勾配形状検索クラス
    /// </summary>
    public class SSlopeFigMainQuery
    {
        /// <summary>
        /// ファイル名に基づく基幹勾配形状を検索する
        /// </summary>
        /// <param name="ds">データサビース</param>
        /// <param name="fileName">ファイル名</param>
        /// <returns>基幹勾配形状</returns>
        public static List<SSlopeFigMain> GetSSlopeFigMainByFileName(DataService ds, string fileName)
        {
            List<SSlopeFigMain> resultSSlopeFigMain = new List<SSlopeFigMain>();

            // データ検索対象初期化
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(SSlopeFigMain).Name);

            // 検索条件：ファイル名
            SqlConditionExpression q1 = new SqlConditionExpression("FileName", QueryItemOperator.Equal, fileName);

            // 検索条件組合せ
            qic.ConditionExpression = q1;

            // 検索実行(※レコードだけ)
            List<GeoItem> resultGeoItem = ds.QueryItems(qic);

            // GeoItemをSSlopeFigMainに変換する
            resultGeoItem.ConvertAll(s => (SSlopeFigMain)s).ForEach(p => resultSSlopeFigMain.Add(p));

            return resultSSlopeFigMain;
        }

        /// <summary>
        /// ファイル名(更新番号以外)に基づく基幹勾配形状を検索する
        /// </summary>
        /// <param name="ds">データサビース</param>
        /// <param name="fileName">ファイル名(更新番号以外)</param>
        /// <returns>基幹勾配形状</returns>
        public static List<SSlopeFigMain> GetSSlopeFigMainByLikeFileName(DataService ds, string fileName)
        {
            List<SSlopeFigMain> resultSSlopeFigMain = new List<SSlopeFigMain>();

            // データ検索対象初期化
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(SSlopeFigMain).Name);

            // 検索条件：ファイル名
            SqlConditionExpression q1 = new SqlConditionExpression("FileName", QueryItemOperator.Like, fileName + "%");

            // 検索条件組合せ
            qic.ConditionExpression = q1;

            // 検索実行(※レコードだけ)
            List<GeoItem> resultGeoItem = ds.QueryItems(qic);

            // GeoItemをSSlopeFigMainに変換する
            resultGeoItem.ConvertAll(s => (SSlopeFigMain)s).ForEach(p => resultSSlopeFigMain.Add(p));

            return resultSSlopeFigMain;
        }
    }
}

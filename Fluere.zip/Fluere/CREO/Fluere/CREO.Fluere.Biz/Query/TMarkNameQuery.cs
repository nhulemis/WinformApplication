﻿using System.Collections;
using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.FileOperators.Data;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 目印名称モデル
    /// </summary>
    public class TMarkNameQuery
    {
        /// <summary>
        /// 目印コードによって目印名称モデルの検索
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="markCode">目印コード</param>
        /// <returns>目印名称モデルデータ</returns>
        public static List<TMarkName> LoadTMarkNameByMarkCode(DataService ds, uint markCode)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(タウンジャンル)設定
            qic.TypeIDs.Add(typeof(TMarkName).Name);

            // 検索条件：目印コード
            IConditionExpression q1 = new SqlConditionExpression("MarkCode", QueryItemOperator.Equal, markCode);

            // 検索条件組合せ
            qic.ConditionExpression = q1;

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをTMarkNameに変換する
            List<TMarkName> resultTMarkName = resultItem.ConvertAll(s => (TMarkName)s);

            return resultTMarkName;
        }

        /// <summary>
        /// 目印コード条件リストによって、目印名称モデルの検索
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="conExpressData">目印コード条件リスト</param>
        /// <returns>目印名称モデルデータ</returns>
        public static List<TMarkName> LoadTMarkNameByMarkCodeList(DataService ds, List<ConditionExpressData> conExpressData)
        {
            Hashtable hashExpress = new Hashtable();

            // 抽出対象外
            hashExpress.Add("<>", QueryItemOperator.NotEqual);

            // 抽出対象
            hashExpress.Add("=", QueryItemOperator.Equal);

            // 設定値以下
            hashExpress.Add("<=", QueryItemOperator.LessEqual);

            // 設定値以上
            hashExpress.Add(">=", QueryItemOperator.GreatEqual);

            // 設定値未満
            hashExpress.Add("<", QueryItemOperator.Less);

            // 設定値より大
            hashExpress.Add(">", QueryItemOperator.Great);

            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(タウンジャンル)設定
            qic.TypeIDs.Add(typeof(TMarkName).Name);

            // インデックス
            int i = 0;

            // 一件目検索条件を保存
            SqlConditionExpression condExpressTotal =
                new SqlConditionExpression("MarkCode", (QueryItemOperator)hashExpress[conExpressData[0].Expression], conExpressData[0].Value);

            foreach (var item in conExpressData)
            {
                if (i != 0)
                {
                    // 目印コード
                    SqlConditionExpression currentCondtion = new SqlConditionExpression("MarkCode", (QueryItemOperator)hashExpress[item.Expression], item.Value);

                    if (item.AndOr == "AND")
                    {
                        // 検索条件組合せ
                        condExpressTotal = SqlConditionExpression.And(condExpressTotal, currentCondtion);
                    }

                    if (item.AndOr == "OR")
                    {
                        // 検索条件組合せ
                        condExpressTotal = SqlConditionExpression.Or(condExpressTotal, currentCondtion);
                    }
                }

                i = i + 1;
            }

            qic.ConditionExpression = condExpressTotal;

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをTMarkNameに変換する
            List<TMarkName> resultTMarkName = resultItem.ConvertAll(s => (TMarkName)s);

            return resultTMarkName;
        }
    }
}

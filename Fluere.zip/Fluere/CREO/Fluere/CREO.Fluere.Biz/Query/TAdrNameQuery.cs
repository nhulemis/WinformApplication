﻿using System;
using System.Collections.Generic;
using System.Threading;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Message;

namespace CREO.Fluere.Biz.Query
{
    #region 住所名称情報を格納するクラス
    /// <summary>
    /// 住所名称情報を格納するクラス
    /// </summary>
    public class LocalAdrName
    {
        #region フィールド定義
        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した行政区域コード
        /// </summary>
        private string fullAdrCode = null;

        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した住所名称
        /// </summary>
        private string fullName = null;
        #endregion

        #region コンストラクタ
        /// <summary>
        /// コンストラクタ
        /// </summary>
        private LocalAdrName()
        {
        }

        /// <summary>
        /// LocalAdrNameクラスの新しいインスタンスを生成する。
        /// </summary>
        /// <param name="paraOID">OID</param>
        public LocalAdrName(ulong paraOID)
        {
            this.OID = paraOID;

            this.Childs = new List<LocalAdrName>();
            this.Parent = null;
        }

        /// <summary>
        /// LocalAdrNameクラスの新しいインスタンスを生成する。
        /// </summary>
        /// <param name="paraTAdrName">TAdrNameデータモデルオブジェクト</param>
        public LocalAdrName(TAdrName paraTAdrName)
            : this(paraTAdrName.OID)
        {
            this.ResetTAdrName(paraTAdrName);
        }
        #endregion

        #region プロパティ
        /// <summary>
        /// OID
        /// </summary>
        public ulong OID { get; set; }

        /// <summary>
        /// 漢字住所名所（ja-Jpan）
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 行政区域コード
        /// </summary>
        public ushort AdrCode { get; set; }

        /// <summary>
        /// ネストレベル
        /// </summary>
        public byte NestLevel { get; set; }

        /// <summary>
        /// 出典ID
        /// </summary>
        public ulong? MaterialID { get; set; }

        /// <summary>
        /// 子住所名称情報
        /// </summary>
        public List<LocalAdrName> Childs { get; private set; }

        /// <summary>
        /// 親住所名称情報
        /// </summary>
        public LocalAdrName Parent { get; private set; }

        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した行政区域コード
        /// </summary>
        public string FullAdrCode
        {
            get
            {
                if (this.fullAdrCode == null)
                {
                    switch (this.NestLevel)
                    {
                        case 0:
                            this.fullAdrCode = string.Format("{0:D2}", this.AdrCode);
                            break;
                        case 1:
                            this.fullAdrCode = string.Format("{0}{1:D3}", this.Parent.FullAdrCode, this.AdrCode);
                            break;
                        default:
                            this.fullAdrCode = string.Format("{0}-{1}", this.Parent.FullAdrCode, this.AdrCode);
                            break;
                    }
                }

                return fullAdrCode;
            }
        }

        /// <summary>
        /// 親ネストレベルから子ネストレベルまで連結した住所名称
        /// </summary>
        public string FullName
        {
            get
            {
                if (this.fullName == null)
                {
                    switch (this.NestLevel)
                    {
                        case 0:
                            this.fullName = this.Name;
                            break;
                        default:
                            this.fullName = string.Format("{0}{1}", this.Parent.FullName, this.Name);
                            break;
                    }
                }

                return fullName;
            }
        }
        #endregion

        #region パブリック・メソッド
        /// <summary>
        /// 子住所対象を追加する
        /// </summary>
        /// <param name="child">子住所対象</param>
        public void AddChild(LocalAdrName child)
        {
            child.SetParent(this);
            this.Childs.Add(child);
        }

        /// <summary>
        /// 親住所対象を設定する
        /// </summary>
        /// <param name="parent">親住所対象</param>
        public void SetParent(LocalAdrName parent)
        {
            this.Parent = parent;
        }

        /// <summary>
        /// 住所対象を再設定する
        /// </summary>
        /// <param name="paraTAdrName">TAdrNameデータモデルオブジェクト</param>
        public void ResetTAdrName(TAdrName paraTAdrName)
        {
            this.MaterialID = paraTAdrName.MaterialID;  // 2013/04/15 江雪風　追加

            this.Name = string.Empty;
            if (paraTAdrName.AdrNameMultiLang != null &&
                paraTAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN] != null &&
                !string.IsNullOrEmpty(paraTAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name))
            {
                this.Name = paraTAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name;
            }

            if (paraTAdrName.AdrCode != null)
            {
                this.AdrCode = (ushort)paraTAdrName.AdrCode;
            }

            this.NestLevel = paraTAdrName.NestLevel;
        }
        #endregion
    }
    #endregion

    #region 比較子
    /// <summary>
    /// OIDを使用して、2 つの住所名称情報オブジェクトを比較するために型が実装するメソッドを定義します
    /// </summary>
    public class LocalAdrNameByOidComparer : IComparer<LocalAdrName>
    {
        /// <summary>
        /// 2 つの住所名称情報オブジェクトを比較し、一方が他方より小さいか、等しいか、大きいかを示す値を返します。
        /// </summary>
        /// <param name="firstObj">比較する最初のオブジェクトです</param>
        /// <param name="secondObj">比較する 2 番目のオブジェクト</param>
        /// <returns>x と y の相対的な値を示す符号付き整数</returns>
        public int Compare(LocalAdrName firstObj, LocalAdrName secondObj)
        {
            if (firstObj == null)
            {
                if (secondObj == null)
                {
                    return 0;
                }
                else
                {
                    return -1;
                }
            }
            else
            {
                if (secondObj == null)
                {
                    return 1;
                }
                else
                {
                    return firstObj.OID.CompareTo(secondObj.OID);
                }
            }
        }
    }
    #endregion

    #region 住所名称情報を管理するクラス
    /// <summary>
    /// 住所名称情報を管理するクラス
    /// </summary>
    public class TAdrNameQuery
    {
        #region 定数定義 検索関連
        /// <summary>
        /// 住所名称のデータモデルタイプID
        /// </summary>
        private const string DATA_MODEL_TYPEID_TADRNAME = "TAdrName";

        /// <summary>
        /// 親表実体OID
        /// </summary>
        private const string ATTR_NAME_PARENTTABLEOID = "ParentTableOID";
        #endregion

        #region ログマネージャーのインスタンス、メッセージマネージャーのインスタンス
        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        private static LogManager _loggMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);
        #endregion

        #region キャッシュデータ
        /// <summary>
        /// キャッシュデータサービスを使用するフラグ
        /// </summary>
        private static bool useCacheDataService = false;

        /// <summary>
        /// データ検索用データサービス
        /// </summary>
        private static DataService cacheDataService = null;

        /// <summary>
        /// 都道府県レベルのキャッシュデータに対する変更処理の排他制御用イベント
        /// </summary>
        private static ManualResetEvent provinceCacheDictLockEvent = new ManualResetEvent(true);

        /// <summary>
        /// 市区町村レベルのキャッシュデータに対する変更処理の排他制御用ロックオブジェクト
        /// </summary>
        private static object adminCacheDictLockObject = new object();

        /// <summary>
        /// 検索済み県データに対する変更の排他制御用ロックオブジェクト
        /// </summary>
        private static object provinceSearchedOIDDictLockObject = new object();

        /// <summary>
        /// 都道府県レベルのキャッシュデータ
        /// </summary>
        private static Dictionary<string, LocalAdrName> provinceCacheDict = new Dictionary<string, LocalAdrName>();

        /// <summary>
        /// 市区町村レベルのキャッシュデータ
        /// </summary>
        private static Dictionary<string, LocalAdrName> adminCacheDict = new Dictionary<string, LocalAdrName>();

        /// <summary>
        /// 検索済み県データ
        /// </summary>
        private static Dictionary<string, ulong> provinceSearchedOIDDict = new Dictionary<string, ulong>();

        /// <summary>
        /// 検索済み市区町村データ
        /// </summary>
        private static Dictionary<string, ulong> adminSearchedOIDDict = new Dictionary<string, ulong>();

        /// <summary>
        /// 検索済み字データ
        /// </summary>
        private static Dictionary<string, ulong> azaSearchedOIDDict = new Dictionary<string, ulong>();
        #endregion

        #region 定数定義 ネストレベル
        /// <summary>
        /// 0:都道府県まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A0_ONLY = 0;

        /// <summary>
        /// 1:市区町村まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A1_ONLY = 1;

        /// <summary>
        /// 2:大字まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A1_A2 = 2;

        /// <summary>
        /// 3:小字まで
        /// </summary>
        public const long ADMINISTRATIVE_CODE_A1_A2_A3 = 3;
        #endregion

        #region プライベート・メソッド
        /// <summary>
        /// 都道府県の住所名称情報を取得
        /// </summary>
        /// <param name="provinceCode">県レベルの行政区域コード</param>
        /// <returns>都道府県の住所名称情報</returns>
        private static LocalAdrName GetKennAdrName(string provinceCode)
        {
            if (provinceCacheDict.ContainsKey(provinceCode))
            {
                // 再検索不要場合
                return provinceCacheDict[provinceCode];
            }

            if (provinceCacheDict.Count < 1)
            {
                Monitor.Enter(provinceCacheDictLockEvent);
                try
                {
                    if (provinceCacheDict.Count < 1)
                    {
                        provinceCacheDictLockEvent.Reset();

                        // 初回なので検索する
                        QueryItemsCondition itemsCondition = new QueryItemsCondition();
                        itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TADRNAME);
                        itemsCondition.ConditionExpression = new SqlConditionExpression(ATTR_NAME_PARENTTABLEOID,
                            QueryItemOperator.Equal,
                            null);
                        List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

                        if (lstDataModel != null && 0 != lstDataModel.Count)
                        {
                            foreach (GeoItem curGeoItem in lstDataModel)
                            {
                                TAdrName tempProvinceGeoItem = (TAdrName)curGeoItem;

                                string cacheKey = string.Format("{0:D2}", tempProvinceGeoItem.AdrCode);
                                if (provinceCacheDict.ContainsKey(cacheKey))
                                {
                                    LocalAdrName dupProvinceAdrName = provinceCacheDict[cacheKey];

                                    _loggMgr.WriteWarning("※都道府県データが重複。{0}:{1},{2}<==>{3},{4}",
                                        cacheKey,
                                        dupProvinceAdrName.AdrCode,
                                        dupProvinceAdrName.OID,
                                        tempProvinceGeoItem.AdrCode,
                                        tempProvinceGeoItem.OID);
                                }
                                else
                                {
                                    LocalAdrName provinceAdrName = new LocalAdrName(tempProvinceGeoItem);
                                    provinceCacheDict.Add(cacheKey, provinceAdrName);
                                }
                            }

                            // データモデルを解放する
                            lstDataModel.Clear();
                            lstDataModel = null;
                        }
                    }
                }
                finally
                {
                    Monitor.Exit(provinceCacheDictLockEvent);
                    provinceCacheDictLockEvent.Set();
                }
            }

            provinceCacheDictLockEvent.WaitOne();
            if (provinceCacheDict.ContainsKey(provinceCode))
            {
                return provinceCacheDict[provinceCode];
            }

            _loggMgr.WriteDebug("※都道府県データが存在しません。{0}", provinceCode);
            return null;
        }

        /// <summary>
        /// 市区町村の住所名称情報を取得
        /// </summary>
        /// <param name="curKennLocalAdrName">県の住所名称情報</param>
        private static void GetSiAdrName(LocalAdrName curKennLocalAdrName)
        {
            // 初回なので検索する
            QueryItemsCondition itemsCondition = new QueryItemsCondition();
            itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TADRNAME);
            itemsCondition.ConditionExpression = new SqlConditionExpression(ATTR_NAME_PARENTTABLEOID,
                QueryItemOperator.Equal,
                curKennLocalAdrName.OID.ToString());
            List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

            if (lstDataModel != null && 0 != lstDataModel.Count)
            {
                foreach (GeoItem curGeoItem in lstDataModel)
                {
                    TAdrName tempAdminGeoItem = (TAdrName)curGeoItem;

                    string cacheKey = string.Format("{0:D2}{1:D3}",
                        curKennLocalAdrName.AdrCode,
                        tempAdminGeoItem.AdrCode);

                    if (!adminCacheDict.ContainsKey(cacheKey))
                    {
                        lock (adminCacheDictLockObject)
                        {
                            if (!adminCacheDict.ContainsKey(cacheKey))
                            {
                                LocalAdrName adminAdrName = new LocalAdrName(tempAdminGeoItem);
                                curKennLocalAdrName.AddChild(adminAdrName);

                                adminCacheDict.Add(cacheKey, adminAdrName);
                            }
                        }
                    }
                }

                // データモデルを解放する
                lstDataModel.Clear();
                lstDataModel = null;
            }

            lock (provinceSearchedOIDDictLockObject)
            {
                // 検索済み配列に追加
                if (!provinceSearchedOIDDict.ContainsKey(curKennLocalAdrName.FullAdrCode))
                {
                    provinceSearchedOIDDict.Add(curKennLocalAdrName.FullAdrCode, curKennLocalAdrName.OID);
                }
            }
        }

        /// <summary>
        /// 市区町村の住所名称情報を取得
        /// </summary>
        /// <param name="adrnameCode">県と市区町村レベルの行政区域コード</param>
        /// <returns>市区町村の住所名称情報</returns>
        private static LocalAdrName GetSiAdrName(string adrnameCode)
        {
            if (adminCacheDict.ContainsKey(adrnameCode))
            {
                // 再検索不要場合
                return adminCacheDict[adrnameCode];
            }

            // 都道府県コード
            string provinceCode = StringUtil.GetAdminCodeSubString(adrnameCode, 0, 2);

            // 未検索の場合
            if (!provinceSearchedOIDDict.ContainsKey(provinceCode))
            {
                // 県データを取得する
                LocalAdrName curKennLocalAdrName = GetKennAdrName(provinceCode);
                if (null == curKennLocalAdrName)
                {
                    // 県データが存在しない場合
                    return null;
                }

                GetSiAdrName(curKennLocalAdrName);
            }

            if (adminCacheDict.ContainsKey(adrnameCode))
            {
                return adminCacheDict[adrnameCode];
            }

            _loggMgr.WriteDebug("※市区町村データが存在しません。{0}", adrnameCode);
            return null;
        }

        /// <summary>
        /// 大字の住所名称情報を取得
        /// </summary>
        /// <param name="curSiLocalAdrName">市区町村の住所名称情報</param>
        private static void GetOoazaAdrName(LocalAdrName curSiLocalAdrName)
        {
            // 初回なので検索する
            if (!adminSearchedOIDDict.ContainsKey(curSiLocalAdrName.FullAdrCode))
            {
                // 初回なので検索する
                QueryItemsCondition itemsCondition = new QueryItemsCondition();
                itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TADRNAME);
                itemsCondition.ConditionExpression = new SqlConditionExpression(ATTR_NAME_PARENTTABLEOID,
                    QueryItemOperator.Equal,
                    curSiLocalAdrName.OID.ToString());
                List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

                if (lstDataModel != null && 0 != lstDataModel.Count)
                {
                    foreach (GeoItem curGeoItem in lstDataModel)
                    {
                        LocalAdrName ooazaAdrName = new LocalAdrName((TAdrName)curGeoItem);
                        curSiLocalAdrName.AddChild(ooazaAdrName);
                    }

                    // データモデルを解放する
                    lstDataModel.Clear();
                    lstDataModel = null;
                }

                // 検索済み配列に追加
                adminSearchedOIDDict.Add(curSiLocalAdrName.FullAdrCode, curSiLocalAdrName.OID);
            }
        }

        /// <summary>
        /// 市区町村と大字の住所名称情報を取得
        /// </summary>
        /// <param name="adrnameCode">県と市区町村レベルの行政区域コード</param>
        /// <param name="resultList">市区町村と大字の住所名称情報を格納するリスト</param>
        private static void GetOoazaAdrName(string adrnameCode,
            ref List<LocalAdrName> resultList)
        {
            // 市区町村データを取得する
            LocalAdrName curSiLocalAdrName = GetSiAdrName(adrnameCode);
            if (null == curSiLocalAdrName)
            {
                // 市区町村データが存在しない場合
                return;
            }

            GetOoazaAdrName(curSiLocalAdrName);

            // 市区町村データを出力
            resultList.Add(curSiLocalAdrName);

            // 大字データを出力
            resultList.AddRange(curSiLocalAdrName.Childs);
        }

        /// <summary>
        /// 小字住所名称情報を取得
        /// </summary>
        /// <param name="curOoazaLocalAdrName">大字住所名称情報</param>
        private static void GetCoazaAdrName(LocalAdrName curOoazaLocalAdrName)
        {
            if (!azaSearchedOIDDict.ContainsKey(curOoazaLocalAdrName.FullAdrCode))
            {
                // 初回なので検索する
                QueryItemsCondition itemsCondition = new QueryItemsCondition();
                itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TADRNAME);
                itemsCondition.ConditionExpression = new SqlConditionExpression(ATTR_NAME_PARENTTABLEOID,
                    QueryItemOperator.Equal,
                    curOoazaLocalAdrName.OID.ToString());
                List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

                if (lstDataModel != null && 0 != lstDataModel.Count)
                {
                    foreach (GeoItem curGeoItem in lstDataModel)
                    {
                        LocalAdrName coazaAdrName = new LocalAdrName((TAdrName)curGeoItem);
                        curOoazaLocalAdrName.AddChild(coazaAdrName);
                    }

                    // データモデルを解放する
                    lstDataModel.Clear();
                    lstDataModel = null;
                }

                // 検索済み配列に追加
                azaSearchedOIDDict.Add(curOoazaLocalAdrName.FullAdrCode, curOoazaLocalAdrName.OID);
            }
        }

        /// <summary>
        /// 市区町村、大字と小字の住所名称情報を取得
        /// </summary>
        /// <param name="adrnameCode">県と市区町村レベルの行政区域コード</param>
        /// <param name="resultList">市区町村、大字と小字の住所名称情報を格納するリスト</param>
        private static void GetCoazaAdrName(string adrnameCode,
            ref List<LocalAdrName> resultList)
        {
            // 市区町村、大字の住所名称情報を取得
            GetOoazaAdrName(adrnameCode, ref resultList);

            // 市区町村データを取得する
            LocalAdrName curSiLocalAdrName = null;
            if (adminCacheDict.ContainsKey(adrnameCode))
            {
                curSiLocalAdrName = adminCacheDict[adrnameCode];
            }

            if (null == curSiLocalAdrName)
            {
                // 市区町村データが存在しない場合
                return;
            }

            // 初回なので検索する
            if (!azaSearchedOIDDict.ContainsKey(curSiLocalAdrName.FullAdrCode))
            {
                // 小字データを出力
                foreach (LocalAdrName curOoazaLocalAdrName in curSiLocalAdrName.Childs)
                {
                    GetCoazaAdrName(curOoazaLocalAdrName);
                }

                // 検索済み配列に追加
                azaSearchedOIDDict.Add(curSiLocalAdrName.FullAdrCode, curSiLocalAdrName.OID);
            }

            // 小字データを出力
            foreach (LocalAdrName curOoazaLocalAdrName in curSiLocalAdrName.Childs)
            {
                resultList.AddRange(curOoazaLocalAdrName.Childs);
            }
        }
        #endregion

        #region パブリック・メソッド
        #region 処理フロー制御用の住所名称を取得する処理
        /// <summary>
        /// 検索用データサービスを設定する
        /// </summary>
        /// <param name="paraDataService">データサービス</param>
        public static void SetDataService(DataService paraDataService)
        {
            if (paraDataService != null)
            {
                useCacheDataService = true;
            }
            else
            {
                useCacheDataService = false;
            }

            cacheDataService = paraDataService;
        }

        /// <summary>
        /// すべて住所名称情報を取得
        /// </summary>
        /// <param name="paraDataService">データサービス</param>
        /// <param name="forceRefresh">全データを再取得するフラグ</param>
        public static void PrepareAllData(DataService paraDataService, bool forceRefresh = false)
        {
            // 検索用データサービスを設定する
            if (!useCacheDataService)
            {
                cacheDataService = paraDataService;
            }

            provinceCacheDictLockEvent.WaitOne();

            if (forceRefresh || provinceCacheDict.Count < 1)
            {
                Monitor.Enter(provinceCacheDictLockEvent);
                try
                {
                    provinceCacheDictLockEvent.Reset();

                    // リフレッシュ場合
                    if (forceRefresh)
                    {
                        provinceCacheDict.Clear();

                        lock (adminCacheDictLockObject)
                        {
                            adminCacheDict.Clear();
                        }

                        lock (provinceSearchedOIDDictLockObject)
                        {
                            provinceSearchedOIDDict.Clear();
                            adminSearchedOIDDict.Clear();
                            azaSearchedOIDDict.Clear();
                        }
                    }

                    if (provinceCacheDict.Count < 1)
                    {
                        // 初回なので検索する
                        QueryItemsCondition itemsCondition = new QueryItemsCondition();
                        itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TADRNAME);
                        List<GeoItem> lstDataModel = cacheDataService.QueryItems(itemsCondition);

                        if (lstDataModel != null && 0 != lstDataModel.Count)
                        {
                            Dictionary<ulong, LocalAdrName> tempOidCacheDict = new Dictionary<ulong, LocalAdrName>();

                            List<LocalAdrName> tempProvinceList = new List<LocalAdrName>();
                            List<LocalAdrName> tempAdminList = new List<LocalAdrName>();

                            foreach (GeoItem curGeoItem in lstDataModel)
                            {
                                TAdrName curTAdrName = (TAdrName)curGeoItem;
                                LocalAdrName curLocalAdrName = null;
                                if (tempOidCacheDict.ContainsKey(curTAdrName.OID))
                                {
                                    curLocalAdrName = tempOidCacheDict[curTAdrName.OID];
                                    curLocalAdrName.ResetTAdrName(curTAdrName);
                                }
                                else
                                {
                                    curLocalAdrName = new LocalAdrName(curTAdrName);
                                    tempOidCacheDict.Add(curLocalAdrName.OID, curLocalAdrName);
                                }

                                // 都道府県の場合
                                if (curTAdrName.NestLevel == 0)
                                {
                                    tempProvinceList.Add(curLocalAdrName);
                                }
                                else
                                {
                                    if (curTAdrName.NestLevel == 1)
                                    {
                                        // 市区町村の場合
                                        tempAdminList.Add(curLocalAdrName);
                                    }

                                    LocalAdrName parentLocalAdrName = null;
                                    if (tempOidCacheDict.ContainsKey((ulong)curTAdrName.ParentTableOID))
                                    {
                                        parentLocalAdrName = tempOidCacheDict[(ulong)curTAdrName.ParentTableOID];
                                    }
                                    else
                                    {
                                        parentLocalAdrName = new LocalAdrName((ulong)curTAdrName.ParentTableOID);
                                        tempOidCacheDict.Add(parentLocalAdrName.OID, parentLocalAdrName);
                                    }

                                    parentLocalAdrName.AddChild(curLocalAdrName);
                                }
                            }

                            // データモデルを解放する
                            lstDataModel.Clear();
                            lstDataModel = null;

                            // ガベージ コレクションを直ちに強制実行します
                            GC.Collect(GC.MaxGeneration);
                            GC.WaitForPendingFinalizers();

                            // キャッシュデータを生成する
                            foreach (LocalAdrName provinceLocalAdrName in tempProvinceList)
                            {
                                if (provinceCacheDict.ContainsKey(provinceLocalAdrName.FullAdrCode))
                                {
                                    LocalAdrName dupProvinceAdrName =
                                        provinceCacheDict[provinceLocalAdrName.FullAdrCode];

                                    _loggMgr.WriteWarning("※都道府県データが重複。{0}:{1},{2}<==>{3},{4}",
                                        provinceLocalAdrName.FullAdrCode,
                                        dupProvinceAdrName.AdrCode,
                                        dupProvinceAdrName.OID,
                                        provinceLocalAdrName.AdrCode,
                                        provinceLocalAdrName.OID);
                                }
                                else
                                {
                                    provinceCacheDict.Add(provinceLocalAdrName.FullAdrCode, provinceLocalAdrName);
                                    provinceSearchedOIDDict.Add(provinceLocalAdrName.FullAdrCode,
                                        provinceLocalAdrName.OID);
                                }
                            }

                            foreach (LocalAdrName adminLocalAdrName in tempAdminList)
                            {
                                if (adminCacheDict.ContainsKey(adminLocalAdrName.FullAdrCode))
                                {
                                    LocalAdrName dupAdminLocalAdrName =
                                        adminCacheDict[adminLocalAdrName.FullAdrCode];

                                    _loggMgr.WriteWarning("※市区町村データが重複。{0}:{1},{2}<==>{3},{4}",
                                        adminLocalAdrName.FullAdrCode,
                                        dupAdminLocalAdrName.AdrCode,
                                        dupAdminLocalAdrName.OID,
                                        adminLocalAdrName.AdrCode,
                                        adminLocalAdrName.OID);
                                }
                                else
                                {
                                    adminCacheDict.Add(adminLocalAdrName.FullAdrCode, adminLocalAdrName);
                                    adminSearchedOIDDict.Add(adminLocalAdrName.FullAdrCode, adminLocalAdrName.OID);
                                    foreach (LocalAdrName curOoazaLocalAdrName in adminLocalAdrName.Childs)
                                    {
                                        azaSearchedOIDDict.Add(curOoazaLocalAdrName.FullAdrCode,
                                            curOoazaLocalAdrName.OID);
                                    }
                                }
                            }
                        }
                    }
                }
                finally
                {
                    Monitor.Exit(provinceCacheDictLockEvent);
                    provinceCacheDictLockEvent.Set();
                }
            }
        }

        /// <summary>
        /// ①都道府県、②市区町村、③市区町村と大字、④市区町村、大字と小字の住所名称情報を取得
        /// </summary>
        /// <param name="paraDataService">データサービス</param>
        /// <param name="adrnameCode">行政区域コード</param>
        /// <param name="nestLevel">ネストレベル</param>
        /// <returns>LocalAdrName型住所名称情報</returns>
        public static List<LocalAdrName> GetLocalAdrName(DataService paraDataService, string adrnameCode, long nestLevel)
        {
            // 検索用データサービスを設定する
            if (!useCacheDataService)
            {
                cacheDataService = paraDataService;
            }

            provinceCacheDictLockEvent.WaitOne();

            List<LocalAdrName> resultList = new List<LocalAdrName>();

            switch (nestLevel)
            {
                case ADMINISTRATIVE_CODE_A0_ONLY:
                    // 都道府県コード
                    string provinceCode = StringUtil.GetAdminCodeSubString(adrnameCode, 0, 2);

                    // ①都道府県データの検索
                    LocalAdrName provinceLocalAdrName = GetKennAdrName(provinceCode);

                    if (provinceLocalAdrName != null)
                    {
                        resultList.Add(provinceLocalAdrName);
                    }

                    break;
                case ADMINISTRATIVE_CODE_A1_ONLY:

                    // ②市区町村データの検索
                    LocalAdrName adminLocalAdrName = GetSiAdrName(adrnameCode);

                    if (adminLocalAdrName != null)
                    {
                        resultList.Add(adminLocalAdrName);
                    }

                    break;
                case ADMINISTRATIVE_CODE_A1_A2:
                    // ③市区町村と大字データの検索
                    GetOoazaAdrName(adrnameCode, ref resultList);

                    break;
                case ADMINISTRATIVE_CODE_A1_A2_A3:
                    // ④市区町村、大字と小字データの検索
                    GetCoazaAdrName(adrnameCode, ref resultList);

                    break;
                default:
                    break;
            }

            return resultList;
        }

        /// <summary>
        /// 子住所名称情報を取得
        /// </summary>
        /// <param name="paraDataService">データサービス</param>
        /// <param name="paraLocalAdrName">住所名称情報</param>
        public static void InitChildAdrName(DataService paraDataService, LocalAdrName paraLocalAdrName)
        {
            // 検索用データサービスを設定する
            if (!useCacheDataService)
            {
                cacheDataService = paraDataService;
            }

            provinceCacheDictLockEvent.WaitOne();

            switch (paraLocalAdrName.NestLevel)
            {
                case 0:
                    GetSiAdrName(paraLocalAdrName);
                    break;
                case 1:
                    GetOoazaAdrName(paraLocalAdrName);
                    break;
                case 2:
                    GetCoazaAdrName(paraLocalAdrName);
                    break;
                default:
                    break;
            }
        }

        #endregion

        #region 業務用の住所名称を取得する処理
        #region 実体OIDによって、住所名称を取得
        /// <summary>
        /// 実体OIDによって、住所名称を取得
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="oid">住所名称OID</param>
        /// <returns>住所名称</returns>
        public static TAdrName LoadTAdrNameByOID(DataService ds, ulong oid)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(DATA_MODEL_TYPEID_TADRNAME);

            qic.IDs.Add(oid);

            // 検索実行(※一レコードだけ)
            List<GeoItem> result = ds.QueryItems(qic);

            // 指定住所名称で取得した住所名称データモデルリストの件数が1件で判断
            if (result.Count == 0)
            {
                return null;
            }
            else
            {
                return (TAdrName)result[0];
            }
        }
        #endregion

        #region 子住所名称モデルにより、親ネストレベルから子ネストレベルまで連結した住所を取得する
        /// <summary>
        /// 子住所名称モデルにより、親ネストレベルから子ネストレベルまで連結した住所を取得する
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="childTAdrName">子住所名称モデル</param>
        /// <param name="nestLevel">親ネストレベル</param>
        /// <returns>住所</returns>
        public static string GetWholeAddressFromChildTAdrName(DataService ds, TAdrName childTAdrName, int nestLevel)
        {
            // 住所
            string address = string.Empty;

            if (int.Parse(childTAdrName.NestLevel.ToString()).CompareTo(nestLevel) > 0)
            {
                // 住所名称モデル
                TAdrName parentTAdrName = null;

                // 子住所名称モデルネストレベルの取得
                int childNestLevel = childTAdrName.NestLevel;

                // 子住所名称モデルの住所名称の取得
                address = childTAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name;

                for (int i = 0; i < (childNestLevel - nestLevel); i++)
                {
                    // 子住所名称モデルにより、親住所名称モデルを取得する
                    parentTAdrName = GetParentTAdrNameFromChild(ds, childTAdrName);

                    if (parentTAdrName == null)
                    {
                        break;
                    }
                    else
                    {
                        if (parentTAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN] != null)
                        {
                            // 親住所名称モデルの住所名称の取得と連結
                            address = parentTAdrName.AdrNameMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name + address;
                        }
                        else
                        {
                            break;
                        }

                        // 前親住所名称モデルを後ろ子住所名称モデルに設定する
                        childTAdrName = parentTAdrName;
                    }
                }
            }

            return address;
        }
        #endregion

        #region 子住所名称モデルにより、親住所名称モデルを取得する
        /// <summary>
        /// 子住所名称モデルにより、親住所名称モデルを取得する
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="childTAdrName">子住所名称モデル</param>
        /// <returns>親住所名称モデル</returns>
        public static TAdrName GetParentTAdrNameFromChild(DataService ds, TAdrName childTAdrName)
        {
            // 住所名称モデル
            TAdrName parentTAdrName = null;

            // 親表実体OIDの取得
            ulong parentOID = (ulong)childTAdrName.ParentTableOID;

            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(typeof(TAdrName).Name);
            qic.IDs.Add((ulong)childTAdrName.ParentTableOID);

            // 検索実行(※レコードだけ)
            List<GeoItem> resultTAdrName = ds.QueryItems(qic);

            // GeoItemをTAdrNameに変換する
            if (resultTAdrName != null && resultTAdrName.Count > 0)
            {
                parentTAdrName = (TAdrName)resultTAdrName[0];
            }

            return parentTAdrName;
        }
        #endregion

        #region 子住所名称モデルにより、親ネストレベルから子ネストレベルまで連結した住所コードを取得する
        /// <summary>
        /// 子住所名称モデルにより、親ネストレベルから子ネストレベルまで連結した住所コードを取得する
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="childTAdrName">子住所名称モデル</param>
        /// <param name="nestLevel">親ネストレベル</param>
        /// <returns>住所コード</returns>
        public static string GetWholeAddressCodeFromChildTAdrName(DataService ds, TAdrName childTAdrName, int nestLevel)
        {
            // 住所
            string addressCode = string.Empty;

            if (int.Parse(childTAdrName.NestLevel.ToString()).CompareTo(nestLevel) > 0)
            {
                // 住所名称モデル
                TAdrName parentTAdrName = null;

                // 子住所名称モデルネストレベルの取得
                int childNestLevel = childTAdrName.NestLevel;

                // 子住所名称モデルの住所名称コードの取得
                if (childTAdrName.NestLevel == 0)
                {
                    addressCode = childTAdrName.AdrCode == null ? string.Empty : childTAdrName.AdrCode.ToString().PadLeft(2, '0');
                }
                else if (childTAdrName.NestLevel == 1)
                {
                    addressCode = childTAdrName.AdrCode == null ? string.Empty : childTAdrName.AdrCode.ToString().PadLeft(3, '0');
                }
                else
                {
                    addressCode = childTAdrName.AdrCode == null ? string.Empty : "-" + childTAdrName.AdrCode.ToString();
                }

                for (int i = 0; i < (childNestLevel - nestLevel); i++)
                {
                    // 子住所名称モデルにより、親住所名称モデルを取得する
                    parentTAdrName = GetParentTAdrNameFromChild(ds, childTAdrName);

                    if (parentTAdrName == null)
                    {
                        break;
                    }
                    else
                    {
                        if (parentTAdrName.NestLevel == 0)
                        {
                            // 親住所名称モデルの住所名称コードの取得と連結
                            addressCode = parentTAdrName.AdrCode.ToString().PadLeft(2, '0') + addressCode;
                        }
                        else if (parentTAdrName.NestLevel == 1)
                        {
                            // 親住所名称モデルの住所名称コードの取得と連結
                            addressCode = parentTAdrName.AdrCode.ToString().PadLeft(3, '0') + addressCode;
                        }
                        else
                        {
                            // 親住所名称モデルの住所名称コードの取得と連結
                            addressCode = parentTAdrName.AdrCode.ToString() + addressCode;
                        }

                        // 前親住所名称モデルを後ろ子住所名称モデルに設定する
                        childTAdrName = parentTAdrName;
                    }
                }
            }

            return addressCode;
        }
        #endregion

        #region ネストレベルによって、住所名称情報を取得
        /// <summary>
        /// ネストレベルによって、住所名称情報を取得
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="level">ネストレベル</param>
        /// <returns>住所名称</returns>
        public static List<TAdrName> GetTAdrNameByNetLevel(DataService ds, int level)
        {
            // 検索する
            QueryItemsCondition itemsCondition = new QueryItemsCondition();

            // 検索結果データタイプ(住所名称)設定
            itemsCondition.TypeIDs.Add(DATA_MODEL_TYPEID_TADRNAME);

            // 検索条件：ネストレベル
            itemsCondition.ConditionExpression = new SqlConditionExpression("NestLevel", QueryItemOperator.Equal, level);

            List<GeoItem> lstDataModel = ds.QueryItems(itemsCondition);

            // GeoItemをTAdrNameに変換する
            List<TAdrName> resultTAdrName = lstDataModel.ConvertAll(s => (TAdrName)s);

            return resultTAdrName;
        }
        #endregion

        #region 実体MaterialIDによって、住所名称を取得
        /// <summary>
        /// 実体MaterialIDによって、住所名称を取得
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="oid">住所名称のMaterialID</param>
        /// <returns>住所名称</returns>
        public static TAdrName LoadTAdrNameByMaterialID(DataService ds, ulong oid)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic.TypeIDs.Add(DATA_MODEL_TYPEID_TADRNAME);

            // 検索条件：MaterialID
            SqlConditionExpression q1 = new SqlConditionExpression("MaterialID", QueryItemOperator.Equal, oid);

            // 検索条件組合せ
            qic.ConditionExpression = SqlConditionExpression.And(q1);

            // 検索実行(※一レコードだけ)
            List<GeoItem> result = ds.QueryItems(qic);

            // 指定住所名称で取得した住所名称データモデルリストの件数が1件で判断
            if (result.Count == 0)
            {
                return null;
            }
            else
            {
                return (TAdrName)result[0];
            }
        }
        #endregion
        #endregion
        #endregion
    }
    #endregion
}

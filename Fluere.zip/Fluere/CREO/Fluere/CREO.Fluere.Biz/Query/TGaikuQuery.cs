﻿using System;
using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Message;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 特殊街区テーブルの検索
    /// </summary>
    public class TGaikuQuery
    {
        #region 全て特殊街区テーブルデータの取得
        /// <summary>
        /// 特殊街区テーブルデータを取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <returns>特殊街区テーブル</returns>
        public static List<TGaiku> GetAllGaiku(DataService ds)
        {
            // 検索結果リスト
            List<TGaiku> result = new List<TGaiku>();

            // データ検索対象作成
            QueryItemsCondition qic1 = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic1.TypeIDs.Add(typeof(TGaiku).Name);

            // 検索実行(※一レコードだけ)
            List<GeoItem> queryResult = ds.QueryItems(qic1);

            foreach (GeoItem item in queryResult)
            {
                result.Add(item as TGaiku);
            }

            return result;
        }    
        #endregion
    }        
}
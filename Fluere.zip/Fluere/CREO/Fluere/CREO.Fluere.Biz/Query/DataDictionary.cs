﻿using System;
using System.Collections.Generic;
using System.Linq;
using CREO.DataModel;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 空間実体と依存実体関係管理辞書クラス
    /// </summary>
    public class DependentDictionary
    {
        /// <summary>
        /// 空間実体
        /// </summary>
        private Dictionary<ulong, HashSet<ulong>> _sidMaps =
            new Dictionary<ulong, HashSet<ulong>>();

        /// <summary>
        /// 依存実体
        /// </summary>
        private Dictionary<ulong, HashSet<ulong>> _didMaps =
            new Dictionary<ulong, HashSet<ulong>>();

        /// <summary>
        /// 全ての実体
        /// </summary>
        private Dictionary<ulong, GeoItem> _items =
            new Dictionary<ulong, GeoItem>();

        /// <summary>
        /// 空間実体と依存実体関係管理クラス
        /// </summary>
        /// <param name="items">空間実体と依存実体リスト</param>
        public DependentDictionary(IEnumerable<GeoItem> items)
        {
            if (items == null || items.Count() == 0)
            {
                return;
            }

            foreach (var item in items)
            {
                _items[item.OID] = item;
                var dItem = item as DItemBase;
                if (dItem != null)
                {
                    var sItems = dItem.GetDependingItemsOid();
                    if (sItems != null)
                    {
                        sItems.ForEach(oid => Add(oid, dItem.OID));
                    }
                }
            }
        }

        /// <summary>
        /// 空間実体と依存実体の関係取得
        /// </summary>
        /// <param name="item">空間実体又は依存実体</param>
        /// <returns>結果セット、空間と依存実体の関係存在しないの場合、nullを戻る</returns>
        public IEnumerable<GeoItem> GetDependingItems(GeoItem item)
        {
            if (item is SItemBase && _sidMaps.ContainsKey(item.OID))
            {
                var oids = _sidMaps[item.OID];
                return oids.Select(oid => _items[oid]);
            }

            if (item is DItemBase && _didMaps.ContainsKey(item.OID))
            {
                var oids = _didMaps[item.OID];
                return oids.Select(oid => _items[oid]);
            }

            return new List<GeoItem>();
        }

        /// <summary>
        /// 空間実体と依存実体の関係取得
        /// </summary>
        /// <param name="item">空間実体又は依存実体</param>
        /// <param name="typeName">実体のタイプ名前</param>
        /// <returns>結果セット、空間と依存実体の関係存在しないの場合、nullを戻る</returns>
        public IEnumerable<GeoItem> GetDependingItems(GeoItem item, string typeName)
        {
            var tmp = GetDependingItems(item);
            return tmp.Where(i => i.ContentID == typeName);
        }

        /// <summary>
        /// 依存実体OIDの取得
        /// </summary>
        /// <returns>OIDリスト</returns>
        public List<ulong> GetDependingItemsOID()
        {
            List<ulong> lstDependingItemsOID = new List<ulong>();

            foreach (var de in _didMaps)
            {
                lstDependingItemsOID.Add(Convert.ToUInt64(de.Key));
            }

            return lstDependingItemsOID;
        }

        /// <summary>
        /// 空間実体と依存実体関係テーブルに追加データ
        /// </summary>
        /// <param name="sid">空間実体id</param>
        /// <param name="did">依存実体id</param>
        private void Add(ulong sid, ulong did)
        {
            if (!_sidMaps.ContainsKey(sid))
            {
                _sidMaps.Add(sid, new HashSet<ulong>());
            }

            _sidMaps[sid].Add(did);

            if (!_didMaps.ContainsKey(did))
            {
                _didMaps.Add(did, new HashSet<ulong>());
            }

            _didMaps[did].Add(sid);
        }
    }

    /// <summary>
    /// グルーピング関係があるのデータモデル取得
    /// </summary>
    public class GroupingDictionary
    {
        /// <summary>
        /// グルーピング
        /// </summary>
        private Dictionary<ulong, HashSet<ulong>> _groups =
            new Dictionary<ulong, HashSet<ulong>>();

        /// <summary>
        /// 全ての実体
        /// </summary>
        private Dictionary<ulong, GeoItem> _items =
            new Dictionary<ulong, GeoItem>();

        /// <summary>
        /// グルーピング関係管理クラス
        /// </summary>
        /// <param name="items">実体リスト</param>
        public GroupingDictionary(IEnumerable<GeoItem> items)
        {
            if (items == null || items.Count() == 0)
            {
                return;
            }

            foreach (var item in items)
            {
                _items[item.OID] = item;
                var groupIds = item.GroupingTag;
                if (groupIds != null)
                {
                    groupIds.ForEach(gid => Add(item.OID, gid));
                }
            }
        }

        /// <summary>
        /// グルーピング関係あるの実体取得
        /// </summary>
        /// <param name="oid">実体OID</param>
        /// <returns>同じグルーピングの実体戻る</returns>
        public IEnumerable<GeoItem> GetGroupingItems(ulong oid)
        {
            if (_items.ContainsKey(oid))
            {
                return GetGroupingItems(_items[oid]);
            }

            return new List<GeoItem>();
        }

        /// <summary>
        /// グルーピング関係あるの実体取得
        /// </summary>
        /// <param name="item">実体</param>
        /// <returns>同じグルーピングの実体戻る</returns>
        public IEnumerable<GeoItem> GetGroupingItems(GeoItem item)
        {
            var groupIds = item.GroupingTag;
            if (groupIds == null)
            {
                return new List<GeoItem>();
            }

            HashSet<ulong> oids = new HashSet<ulong>();
            groupIds.ForEach(gid => oids.UnionWith(_groups[gid]));
            return oids.Select(oid => _items[oid]);
        }

        /// <summary>
        /// グルーピング関係あるの実体取得
        /// </summary>
        /// <param name="items">実体リスト</param>
        /// <returns>同じグルーピングの実体戻る</returns>
        public IEnumerable<GeoItem> GetGroupingItems(List<GeoItem> items)
        {
            HashSet<ulong> oids = new HashSet<ulong>();
            foreach (var item in items)
            {
                var groupIds = item.GroupingTag;
                if (groupIds != null)
                {
                    groupIds.ForEach(gid => oids.UnionWith(_groups[gid]));
                }
            }

            return oids.Select(oid => _items[oid]);
        }

        /// <summary>
        /// グルーピング関係テーブルに追加データ
        /// </summary>
        /// <param name="oid">実体id</param>
        /// <param name="gid">グルーピングid</param>
        private void Add(ulong oid, ulong gid)
        {
            if (!_groups.ContainsKey(gid))
            {
                _groups.Add(gid, new HashSet<ulong>());
            }

            _groups[gid].Add(oid);
        }
    }
}

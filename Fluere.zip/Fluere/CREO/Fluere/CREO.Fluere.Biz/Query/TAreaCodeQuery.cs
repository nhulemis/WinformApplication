﻿using System.Collections.Generic;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 局番データモデルの取得するクラス
    /// </summary>
    public class TAreaCodeQuery
    {
        #region コンテンツタイプかつ市外局番と市内局番によって、局番データモデルの取得
        /// <summary>
        /// コンテンツタイプかつ市外局番と市内局番によって、局番モデルの取得、エラーチェックが無し
        /// 呼び出し側でエラーチェックを実施すると想定
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="outAreaCode">駐車場差分リストファイルデータの市外局番</param>
        /// <param name="inAreaCode">駐車場差分リストファイルデータの市内局番</param>
        /// <returns>局番データモデルデータ</returns>
        public static TAreaCode LoadSPOIParking(DataService ds, string outAreaCode, string inAreaCode)
        {
            // データ検索対象作成
            QueryItemsCondition qic1 = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic1.TypeIDs.Add(typeof(TAreaCode).Name);

            // 市外局番=上記取得した市外局番
            IConditionExpression q1 = new SqlConditionExpression(
                "AreaNo", QueryItemOperator.Equal, outAreaCode);

            // 市内局番 =上記取得した市内局番
            IConditionExpression q2 = new SqlConditionExpression(
                "LocalNo", QueryItemOperator.Equal, inAreaCode);

            // 検索条件組合せ(And)
            qic1.ConditionExpression = q1.And(q1, q2);

            // 検索実行(※一レコードだけ)
            List<GeoItem> result = ds.QueryItems(qic1);

            // 指定市外局番と市内局番で取得した局番データモデルの件数が1件で判断
            if (result.Count == 1)
            {
                return result[0] as TAreaCode;
            }
            else
            {
                // 指定市外局番と市内局番で取得した局番データモデルの件数が1件以外の場合
                string msgId = UF_Fluere_MsgId.MSGID_UF20002014;
                throw new BusinessLogicException(msgId, new string[] { outAreaCode, inAreaCode });
            }
        }
        #endregion

        #region コンテンツタイプかつ市外局番によって、局番データモデルの取得
        /// <summary>
        /// コンテンツタイプかつ市外局番によって、局番モデルの取得、エラーチェックが無し
        /// 呼び出し側でエラーチェックを実施すると想定
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="outAreaCode">駐車場差分リストファイルデータの市外局番</param>
        /// <returns>局番データモデルデータ</returns>
        public static TAreaCode LoadSPOIParking(DataService ds, string outAreaCode)
        {
            // データ検索対象作成
            QueryItemsCondition qic1 = new QueryItemsCondition();

            // 検索結果データタイプ設定
            qic1.TypeIDs.Add(typeof(TAreaCode).Name);

            // 市外局番=上記取得した市外局番
            IConditionExpression q1 = new SqlConditionExpression(
                "AreaNo", QueryItemOperator.Equal, outAreaCode);

            // 検索条件組合せ(And)
            qic1.ConditionExpression = q1.And(q1);

            // 検索実行(※一レコードだけ)
            List<GeoItem> result = ds.QueryItems(qic1);

            // 指定市外局番と市内局番で取得した局番データモデルの件数が1件で判断
            if (result.Count == 1)
            {
                return result[0] as TAreaCode;
            }
            else
            {
                // 指定市外局番で取得した局番データモデルの件数が1件以外の場合
                string msgId = UF_Fluere_MsgId.MSGID_UF20002020;
                throw new BusinessLogicException(msgId, new string[] { outAreaCode });
            }
        }
        #endregion
    }
}

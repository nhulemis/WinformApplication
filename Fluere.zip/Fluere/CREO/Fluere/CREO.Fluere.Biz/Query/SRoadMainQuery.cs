﻿using System.Collections.Generic;
using System.Linq;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 基幹道路Query
    /// </summary>
    public class SRoadMainQuery
    {
        #region 同一経路の05向け基幹道路の取得
        /// <summary>
        /// 同一経路の05向け基幹道路の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="sRoadMain">基幹道路</param>
        /// <returns>同一経路の基幹道路</returns>
        public static List<SRoadMain> GetTraceableRoad(DataService ds, SRoadMain sRoadMain)
        {
            List<ulong> crsMainOIDs = new List<ulong>();
            List<SRoadMain> retList = GetTraceableRoad(ds, sRoadMain, crsMainOIDs);

            if (LogUtility.IsDebugEnabled)
            {
                LogUtility.WriteDebug("○同一経路の05向け基幹道路, 対象基幹道路：{0} 同一経路の基幹道路：{1}",
                    sRoadMain.OID,
                    string.Join(", ", retList.Select(o => o.OID)));
            }

            return retList;
        }

        /// <summary>
        /// 同一経路の05向け基幹道路の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="sRoadMain">基幹道路</param>
        /// <param name="crsMainOIDs">基幹交差点OIDのリスト</param>
        /// <returns>OID / MeshCode:Key / Value</returns>
        private static List<SRoadMain> GetTraceableRoad(DataService ds, SRoadMain sRoadMain, List<ulong> crsMainOIDs)
        {
            List<SRoadMain> dataList = new List<SRoadMain>();

            dataList.Add(sRoadMain);

            if (ds != null && sRoadMain != null)
            {
                // 1. 基幹交差点の取得
                List<SCrsMain> listSCrsMain = GetSCrsMainListBySRoadMain(ds, sRoadMain);

                // 上記取得した基幹交差点リストが2件になるので、繰り返す処理が必要。
                if (listSCrsMain.Count > 2)
                {
                    return null;
                }

                List<SCrsMain> needSCrsMain = new List<SCrsMain>();

                foreach (SCrsMain sCrsMain in listSCrsMain)
                {
                    if (!crsMainOIDs.Contains(sCrsMain.OID))
                    {
                        crsMainOIDs.Add(sCrsMain.OID);

                        // 基幹交差点が2次メッシュ境界に接続する場合
                        if (SCrsMainUtility.IsOnMeshBorder(sCrsMain))
                        {
                            // 「1：2次メッシュ境界に接続する交差点」と判断でき
                            // 【基幹交差点の判定が格納】
                            needSCrsMain.Add(sCrsMain);
                        }
                        else
                        {
                            // 基幹交差点が2次メッシュ境界に接続しない場合
                            if (sCrsMain.Crs05GuideNoAry == null || sCrsMain.Crs05GuideNoAry.Count == 0)
                            {
                                // 2次メッシュ境界に接続しない表示交差点」と判断でき
                                // 【基幹交差点の判定が格納】
                                needSCrsMain.Add(sCrsMain);
                            }
                            else
                            {
                                // 「2次メッシュ境界に接続しない探索交差点」と判断でき
                                // 次の基幹交差点へ移す
                                continue;
                            }
                        }
                    }
                }

                foreach (SCrsMain sCrsMain in needSCrsMain)
                {
                    // 基幹交差点を持つ05向け基幹道路の取得
                    List<SRoadMain> listSRoadMain = GetSRoadMainListBySRoadMain(ds, sCrsMain);

                    foreach (SRoadMain item in listSRoadMain)
                    {
                        if (item.OID != sRoadMain.OID)
                        {
                            // 再帰処理
                            List<SRoadMain> temp = GetTraceableRoad(ds, item, crsMainOIDs);

                            if (temp != null && temp.Count > 0)
                            {
                                dataList.AddRange(temp);
                            }
                        }
                    }
                }
            }

            return dataList;
        }

        /// <summary>
        /// 基幹道路を持つ基幹交差点の取得
        /// </summary>
        /// <param name="ds">DataService</param>
        /// <param name="sRoadMain">基幹道路</param>
        /// <returns>基幹交差点リスト</returns>
        public static List<SCrsMain> GetSCrsMainListBySRoadMain(DataService ds, SRoadMain sRoadMain)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索条件
            // コンテンツタイプ = 基幹交差点（SCrsMain）
            qic.TypeIDs.Add(typeof(SCrsMain).Name);

            // RelationMode = RelationMode.Position 
            RelationExpression re = new RelationExpression();
            re.RelationMode = RelationMode.Position;

            // オブジェクトID = 基幹道路．オブジェクトID
            re.OID = sRoadMain.OID;

            // 検索条件組合せ(And)
            qic.RelationExpression = re;

            // 検索実行
            List<GeoItem> resultTemp = ds.QueryItems(qic);

            List<SCrsMain> listSCrsMain = new List<SCrsMain>();

            if (resultTemp != null && resultTemp.Count > 0)
            {
                listSCrsMain = resultTemp.ConvertAll(s => (s as SCrsMain));
            }

            return listSCrsMain;
        }

        /// <summary>
        /// 基幹交差点を持つ05向け基幹道路の取得
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="sCrsMain">基幹交差点</param>
        /// <returns>基幹道路リスト</returns>
        private static List<SRoadMain> GetSRoadMainListBySRoadMain(DataService ds, SCrsMain sCrsMain)
        {
            List<SRoadMain> listSCrsMain = new List<SRoadMain>();

            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索条件
            // コンテンツタイプ = 基幹道路（SRoadMain）
            qic.TypeIDs.Add(typeof(SRoadMain).Name);

            // オブジェクトID = 基幹交差点.オブジェクトID
            // RelationMode = RelationMode.Position
            RelationExpression re = new RelationExpression();
            re.RelationMode = RelationMode.Position;
            re.OID = sCrsMain.OID;

            // 検索条件
            qic.RelationExpression = re;

            // 検索実行(※一レコードだけ)
            List<GeoItem> resultTemp = ds.QueryItems(qic);

            foreach (GeoItem item in resultTemp)
            {
                SRoadMain roadMain = item as SRoadMain;

                // 05探索道路情報 != null
                if (roadMain.Road05GuideNoAry != null && roadMain.Road05GuideNoAry.Count > 0)
                {
                    listSCrsMain.Add(roadMain);
                }
            }

            return listSCrsMain;
        }
        #endregion
    }
}

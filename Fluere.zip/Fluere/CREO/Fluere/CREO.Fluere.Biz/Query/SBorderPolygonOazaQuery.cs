﻿using System;
using System.Collections.Generic;
using System.Linq;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Utility;
using CREO.FW.TMIGeometry;
using Microsoft.SqlServer.Types;

namespace CREO.Fluere.Biz.Query
{
    /// <summary>
    /// 大字ポリゴンモデルの処理
    /// </summary>
    public class SBorderPolygonOazaQuery
    {
        /// <summary>
        /// 大字ポリゴンモデルの全件データを取得する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <returns>大字ポリゴンモデルデータ</returns>
        public static List<SBorderPolygonOaza> LoadSBorderPolygonOaza(DataService ds)
        {
            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(タウンジャンル)設定
            qic.TypeIDs.Add(typeof(SBorderPolygonOaza).Name);

            QueryItemsPostProcess qipp = new QueryItemsPostProcess();
            qipp.Flags = QueryItemsPostProcessFlags.GetReferences;
            qipp.TypeIDs.Add("TAdrName");
            qic.QueryItemsPostProcess = qipp;

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをSBorderPolygonOazaに変換する
            List<SBorderPolygonOaza> resultSBorderPolygonOaza = resultItem.OfType<SBorderPolygonOaza>().ToList();

            return resultSBorderPolygonOaza;
        }

        /// <summary>
        /// 大字ポリゴンに基づく、付近の大字ポリゴンを取得する
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="coordinates">空間ポリゴン</param>
        /// <returns>大字ポリゴンモデルデータ</returns>
        public static List<SBorderPolygonOaza> GetNearSBorderPolygonOazaByPolygon(DataService ds, IEnumerable<Coordinate> coordinates)
        {
            LogUtility logUtility = new LogUtility(System.Reflection.MethodBase.GetCurrentMethod(),
                "付近の大字ポリゴンを取得する",
                LogUtility.LogModel.DebugModel);

            SqlGeometry sqlGeometryPolygon = CoordinateLib.ParseCoordinateToPolygonGeometry(coordinates);

            // 最小軸に沿って外接する、インスタンスの四角形を返します
            SqlGeometry box = sqlGeometryPolygon.STEnvelope();

            SqlGeometry lower_left = box.STPointN(1);
            SqlGeometry upper_right = box.STPointN(3);
            double x1 = lower_left.STX.Value;
            double y1 = lower_left.STY.Value;
            double x2 = upper_right.STX.Value;
            double y2 = upper_right.STY.Value;

            double maxX = Math.Max(x1, x2);
            double maxY = Math.Max(y1, y2);
            double minX = Math.Min(x1, x2);
            double minY = Math.Min(y1, y2);

            // 緯度経度を±1した矩形
            minX = minX - 1;
            minY = minY - 1;
            maxX = maxX + 1;
            maxY = maxY + 1;

            List<Coordinate> polygon = new List<Coordinate>
            {
                GISLib.CoordinateDToCoordinate(new CoordinateD(minX, minY)),
                GISLib.CoordinateDToCoordinate(new CoordinateD(minX, maxY)),
                GISLib.CoordinateDToCoordinate(new CoordinateD(maxX, maxY)),
                GISLib.CoordinateDToCoordinate(new CoordinateD(maxX, minY)),
                GISLib.CoordinateDToCoordinate(new CoordinateD(minX, minY))
            };

            // データ検索対象作成
            QueryItemsCondition qic = new QueryItemsCondition();

            // 検索結果データタイプ(タウンジャンル)設定
            qic.TypeIDs.Add(typeof(SBorderPolygonOaza).Name);

            qic.Polygon = polygon;

            // データモデルリスト取得
            List<GeoItem> resultItem = ds.QueryItems(qic);

            // GeoItemをSBorderPolygonOazaに変換する
            List<SBorderPolygonOaza> resultSBorderPolygonOaza = resultItem.ConvertAll(s => (SBorderPolygonOaza)s);

            logUtility.WriteNormalEnd();

            return resultSBorderPolygonOaza;
        }
    }
}

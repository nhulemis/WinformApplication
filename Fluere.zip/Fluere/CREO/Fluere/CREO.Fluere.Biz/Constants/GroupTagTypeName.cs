﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Constants
{
    /// <summary>
    /// グループタグタイプの日本語名称
    /// </summary>
    public class GroupTagTypeName
    {
        /// <summary>
        /// 作業トリガ（○座標一致）
        /// </summary>
        public const string TYPE1 = "作業トリガ（○座標一致）";

        /// <summary>
        /// 作業トリガ（×座標一致）
        /// </summary>
        public const string TYPE2 = "作業トリガ（×座標一致）";

        /// <summary>
        /// 同一物件管理（○座標一致）
        /// </summary>
        public const string TYPE3 = "同一物件管理（○座標一致）";

        /// <summary>
        /// 同一物件管理（×座標一致）
        /// </summary>
        public const string TYPE4 = "同一物件管理（×座標一致）";

        /// <summary>
        /// 描画系タイプ自動生成
        /// </summary>
        public const string TYPE5 = "描画系タイプ自動生成";

        /// <summary>
        /// SAPA情報専用
        /// </summary>
        public const string TYPE6 = "SAPA情報専用";

        /// <summary>
        /// 納品（案内到着位置）
        /// </summary>
        public const string TYPE7 = "納品（案内到着位置）";

        /// <summary>
        /// 納品（駐車場接続交差点）
        /// </summary>
        public const string TYPE8 = "納品（駐車場接続交差点）";

        /// <summary>
        /// 納品（dst_twn）
        /// </summary>
        public const string TYPE9 = "納品（dst_twn）";

        /// <summary>
        /// 納品（itsspot 目的地コード）
        /// </summary>
        public const string TYPE10 = "納品（itsspot 目的地コード）";

        /// <summary>
        /// 納品（駐車場 提携目的地）
        /// </summary>
        public const string TYPE11 = "納品（駐車場 提携目的地）";

        /// <summary>
        /// 納品（3Dランドマークオフセット文字 施設物件）
        /// </summary>
        public const string TYPE12 = "納品（3Dランドマークオフセット文字 施設物件）";
    }
}

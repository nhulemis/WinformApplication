﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Constants
{
    /// <summary>
    /// 空間実体名称
    /// </summary>
    public class DataModelTypes
    {
        #region "空間実体名称"
        /// <summary>
        /// 基幹交差点
        /// </summary>
        public const string SCRSMAIN = "SCrsMain";

        /// <summary> 
        /// 高速道路模式図交差点
        /// </summary>
        public const string SCRSHWSCHEMA = "SCrsHwSchema";

        /// <summary> 
        /// 特別駐車場交差点
        /// </summary>
        public const string SPARKINGCRS = "SParkingCrs";

        /// <summary> 
        /// 07フェリー交差点
        /// </summary>
        public const string SFRRYCRS07 = "SFrryCrs07";

        /// <summary> 
        /// 05フェリー交差点
        /// </summary>
        public const string SFRRYCRS05 = "SFrryCrs05";

        /// <summary> 
        /// 施設物件
        /// </summary>
        public const string SPOIFACILITY = "SPOIFacility";

        /// <summary> 
        /// 駐車場物件
        /// </summary>
        public const string SPOIPARKING = "SPOIParking";

        /// <summary> 
        /// 郵便番号物件
        /// </summary>
        public const string SPOIPOSTCODE = "SPOIPostCode";

        /// <summary> 
        /// パーキングメータ
        /// </summary>
        public const string SPOIPARKINGMETER = "SPOIParkingMeter";

        /// <summary> 
        /// タウン物件
        /// </summary>
        public const string STWNPOI = "STwnPOI";

        /// <summary> 
        /// 住所代表点
        /// </summary>
        public const string SADRPNT = "SAdrPnt";

        /// <summary> 
        /// 廃止住所代表点
        /// </summary>
        public const string SDISADRPNT = "SDisAdrPnt";

        /// <summary> 
        /// 特別駐車場文字
        /// </summary>
        public const string SPARKINGTXT = "SParkingTxt";

        /// <summary> 
        /// 基幹道路
        /// </summary>
        public const string SROADMAIN = "SRoadMain";

        /// <summary> 
        /// 高速道路模式図道路
        /// </summary>
        public const string SROADHWSCHEMA = "SRoadHwSchema";

        /// <summary> 
        /// 特別駐車場道路
        /// </summary>
        public const string SPARKINGROAD = "SParkingRoad";

        /// <summary> 
        /// 07フェリー道路
        /// </summary>
        public const string SFRRYROAD07 = "SFrryRoad07";

        /// <summary> 
        /// 05フェリー道路
        /// </summary>
        public const string SFRRYROAD05 = "SFrryRoad05";

        /// <summary> 
        /// 基幹勾配形状/// 
        /// </summary>
        public const string SSLOPEFIGMAIN = "SSlopeFigMain";

        /// <summary> 
        /// 特別駐車場勾配形状
        /// </summary>
        public const string SSLOPEFIGPARKING = "SSlopeFigParking";

        /// <summary> 
        /// 描画背景（線）
        /// </summary>
        public const string SFIGPOLYLINEVIEW = "SFigPolylineView";

        /// <summary> 
        /// 特別駐車場背景（線）
        /// </summary>
        public const string SFIGPOLYLINEPARKING = "SFigPolylineParking";

        /// <summary> 
        /// 高速道路模式図背景（線）
        /// </summary>
        public const string SFIGPOLYLINEHWSCHEMA = "SFigPolylineHwSchema";

        /// <summary> 
        /// 大字ポリゴン
        /// </summary>
        public const string SBORDERPOLYGONOAZA = "SBorderPolygonOaza";

        /// <summary> 
        /// 描画背景（面）
        /// </summary>
        public const string SFIGPOLYGONVIEW = "SFigPolygonView";

        /// <summary> 
        /// 特別駐車場背景（面）
        /// </summary>
        public const string SFIGPOLYGONPARKING = "SFigPolygonParking";

        /// <summary> 
        /// 高速道路模式図背景（面）
        /// </summary>
        public const string SFIGPOLYGONHWSCHEMA = "SFigPolygonHwSchema";

        /// <summary>    
        /// 側道案内経路
        /// </summary>
        public const string DDESIGNGUIDEFRNTGROAD = "DDesignGuideFrntgRoad";

        /// <summary>    
        /// 座標なし物件
        /// </summary>
        public const string TPOINOPNT = "TPOINoPnt";

        /// <summary>    
        /// 目印名称
        /// </summary>
        public const string TMARKNAME = "TMarkName";

        /// <summary>    
        /// 高速分岐案内意匠
        /// </summary>
        public const string TDESIGNHWBRANCH = "TDesignHwBranch";

        /// <summary>    
        /// 連続分岐案内意匠
        /// </summary>
        public const string TDESIGNCONSECUTIVEBRANCH = "TDesignConsecutiveBranch";

        /// <summary>    
        /// 高速分岐案内経路
        /// </summary>
        public const string DDESIGNGUIDEHWBRANCH = "DDesignGuideHwBranch";

        /// <summary>    
        /// 連続分岐案内経路
        /// </summary>
        public const string DDESIGNGUIDECONTINUEDBRANCH = "DDesignGuideContinuedBranch";

        /// <summary>    
        /// 道路付加情報
        /// </summary>
        public const string DROADINFO = "DRoadInfo";

        /// <summary>    
        /// 高速施設
        /// </summary>
        public const string TFACILITYHW = "TFacilityHw";

        /// <summary>    
        /// 鉄道駅
        /// </summary>
        public const string TFACILITYSTATION = "TFacilityStation";

        /// <summary>    
        /// フェリー港
        /// </summary>
        public const string TFACILITYFRRY = "TFacilityFrry";

        /// <summary>    
        /// 付加価値詳細情報IDテーブル
        /// </summary>
        public const string TADDVALUEDETAILINFOIDTABLE = "TAddValueDetailInfoIDTable";

        /// <summary>    
        /// 住所名称 
        /// </summary>
        public const string TADRNAME = "TAdrName";

        /// <summary>    
        /// 特殊街区
        /// </summary>
        public const string TGAIKU = "TGaiku";

        /// <summary>    
        /// 高速路線
        /// </summary>
        public const string TROUTEHW = "TRouteHw";

        /// <summary>    
        /// 案内到着位置
        /// </summary>
        public const string DARRIVALPNT = "DArrivalPnt";

        /// <summary>    
        /// 廃止住所名称
        /// </summary>
        public const string TDISADRNAME = "TDisAdrName";

        /// <summary>    
        /// 交差点目印
        /// </summary>
        public const string DCRSMARK = "DCrsMark";

        /// <summary>    
        /// 交差点名称
        /// </summary>
        public const string DCRSNAME = "DCrsName";

        /// <summary>    
        /// 基幹統合交差点
        /// </summary>
        public const string DGROUPCRSBASIC = "DGroupCrsBasic";

        /// <summary>    
        /// 料金所機能
        /// </summary>
        public const string DTOLLGATEFUNC = "DTollgateFunc";

        /// <summary>    
        /// 高速方面標識
        /// </summary>
        public const string DHWGUIDESIGN = "DHwGuideSign";

        /// <summary>    
        /// 05フェリー乗り場
        /// </summary>
        public const string DFRRYPORT05 = "DFrryPort05";

        /// <summary>    
        /// 事故多発地点
        /// </summary>
        public const string DACCDNTPNT = "DAccdntPnt";

        /// <summary>    
        /// 予約VICS区間
        /// </summary>
        public const string DVICSSECTIONRSRVD = "DVicsSectionRsrvd";

        /// <summary>    
        /// 事故多発区間
        /// </summary>
        public const string DACCDNTSECTION = "DAccdntSection";

        /// <summary>    
        /// 街道名称リスト
        /// </summary>
        public const string TSTREETNAMELIST = "TStreetNameList";

        /// <summary>    
        /// 音声
        /// </summary>
        public const string TVOICE = "TVoice";

        /// <summary>    
        /// 都市高イラスト案内
        /// </summary>
        public const string DDESIGNGUIDETHWLLUST = "DDesignGuideTHwIllust";

        /// <summary>    
        /// 物件ジャンル
        /// </summary>
        public const string TGNRPOI = "TGnrPOI";

        /// <summary>    
        /// 鉄道路線
        /// </summary>
        public const string TROUTERAILROAD = "TRouteRailroad";

        /// <summary>    
        /// 高速会社
        /// </summary>
        public const string TCMPNYHW = "TCmpnyHw";

        /// <summary>    
        /// 鉄道会社矢印信号
        /// </summary>
        public const string TCMPNYRAILROAD = "TCmpnyRailroad";

        /// <summary>
        /// 交差点付近レーン
        /// </summary>
        public const string DCRSNEARLANE = "DCrsNearLane";

        /// <summary>
        /// 一般道レーン接続
        /// </summary>
        public const string DLANECONNECTLOCALROAD = "DLaneConnectLocalRoad";

        /// <summary>
        /// レーン統合交差点
        /// </summary>
        public const string DGROUPCRSLANE = "DGroupCrsLane";

        /// <summary>
        /// 矢印信号
        /// </summary>
        public const string DARRWSIGNAL = "DArrwSignal";

        /// <summary>
        /// 3D交差点案内経路
        /// </summary>
        public const string DDESIGNGUIDE3DCRS = "DDesignGuide3DCrs";

        /// <summary>
        /// 外国語省略対応テーブル
        /// </summary>
        public const string TFOREIGNLANGOMITTABLE = "TForeignLangOmitTable";

        /// <summary>
        /// 局番
        /// </summary>
        public const string TAREACODE = "TAreaCode";

        /// <summary>
        /// 郵便番号
        /// </summary>
        public const string TPOSTCODE = "TPostCode";

        /// <summary>
        /// タウンジャンル
        /// </summary>
        public const string TGNRTWN = "TGnrTwn";

        /// <summary>
        /// 特別駐車場フロア名称
        /// </summary>
        public const string TPARKINGFLOORNAME = "TParkingFloorName";

        /// <summary>
        /// 特別駐車場フロア管理
        /// </summary>
        public const string TPARKINGFLOORMNG = "TParkingFloorMng";

        /// <summary>
        /// フェリー会社
        /// </summary>
        public const string TCMPNYFRRY = "TCmpnyFrry";

        /// <summary>
        /// フェリー航路
        /// </summary>
        public const string TROUTEFRRY = "TRouteFrry";

        /// <summary>
        /// 文字種別
        /// </summary>
        public const string TTYPTXT = "TTypTxt";

        /// <summary>
        /// 鉄道駅拡張
        /// </summary>
        public const string TFACILITYSTATIONMEX = "TFacilityStationMEx";

        /// <summary>
        /// フェリー港拡張
        /// </summary>
        public const string TFACILITYFRRYMEX = "TFacilityFrryMEx";

        /// <summary>
        /// 施設物件拡張
        /// </summary>
        public const string SPOIFACILITYMEX = "SPOIFacilityMEx";

        /// <summary>
        /// 郵便番号物件拡張
        /// </summary>
        public const string SPOIPOSTCODEMEX = "SPOIPostCodeMEx";

        /// <summary>
        /// 削除用テーブル
        /// </summary>
        public const string TDELETED_DATA_TYPE = "TDeletedData";

        /// <summary>
        /// 描画記号文字
        /// </summary>
        public const string SSIGNTXTVIEW = "SSignTxtView";

        /// <summary>
        /// ハイウェイマップ２道路文字
        /// </summary>
        public const string SSIGNTXTHWROAD = "SSignTxtHwRoad";

        /// <summary>
        /// ハイウェイマップ２記号文字
        /// </summary>
        public const string SSIGNTXTHWFACILITY = "SSignTxtHwFacility";

        /// <summary>
        /// 描画記号文字拡張
        /// </summary>
        public const string SSIGNTXTVIEWMEX = "SSignTxtViewMEx";

        /// <summary>
        /// ハイウェイマップ２道路文字拡張
        /// </summary>
        public const string SSIGNTXTHWROADMEX = "SSignTxtHwRoadMEx";

        /// <summary>
        /// ハイウェイマップ２記号文字拡張
        /// </summary>
        public const string SSIGNTXTHWFACILITYMEX = "SSignTxtHwFacilityMEx";

        /// <summary> 
        /// 料金表示文字拡張
        /// </summary>
        public const string SSIGNTXTTOLLDISPMEX = "SSignTxtTollDispMEx";

        /// <summary> 
        /// 統合描画記号文字
        /// </summary>
        public const string DGROUPSIGNTXT = "DGroupSignTxt";

        /// <summary> 
        /// 3Dランドマーク施設文字
        /// </summary>
        public const string DLANDMARK3DFACILITYTXT = "DLandMark3DFacilityTxt";

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Constants
{
    /// <summary>
    /// バッチ定数クラス
    /// </summary>
    public class CommonConstants
    {
        #region ファイルパーサー用のフォーマットファイルのキー定義（app.configで指定）
        /// <summary>
        /// ファイルパーサー用のフォーマットファイルのキー定義
        /// </summary>
        public const string FILE_FORMAT_PATH = "CREO.Fluere.FileParser.Format.Path";
        #endregion

        #region バッチ実行結果
        /// <summary>
        /// バッチ実行結果:成功
        /// </summary>
        public const int BATCH_RESULT_SUCCEED = 0;

        /// <summary>
        /// バッチ実行結果:失敗
        /// </summary>
        public const int BATCH_RESULT_FAILED = 1;
        #endregion

        #region 多言語
        /// <summary>
        /// 漢字
        /// </summary>
        public const string MULTLANG_JA_JAPAN = "ja-Jpan";

        /// <summary>
        /// カナ
        /// </summary>
        public const string MULTLANG_JA_KANA = "ja-Kana";
        #endregion

        #region 行政区域レベル
        /// <summary>
        /// 行政区域レベルー都道府県
        /// </summary>
        public const ushort NEST_LEVEL_TODOFUKENN = 0;

        /// <summary>
        /// 行政区域レベルー市区町村
        /// </summary>
        public const ushort NEST_LEVEL_SIKUTYOUSON = 1;

        /// <summary>
        /// 行政区域レベルー大字
        /// </summary>
        public const ushort NEST_LEVEL_OOAZ = 2;

        /// <summary>
        /// 行政区域レベルー小字
        /// </summary>
        public const ushort NEST_LEVEL_KOAZ = 3;
        #endregion

        #region 編集DB反映用ToDoリストファイルに対応
        /// <summary>
        /// 差分区分：新規
        /// </summary>
        public const string DIFF_FLAG_INSERT = "1";

        /// <summary>
        /// 差分区分：変更
        /// </summary>
        public const string DIFF_FLAG_UPDATE = "2";

        /// <summary>
        /// 差分区分：削除
        /// </summary>
        public const string DIFF_FLAG_DELETE = "3";

        /// <summary>
        /// 確認:0
        /// </summary>
        public const string WORK_STATUS_0 = "0";
        #endregion

        #region 新旧対応データに新・旧住所コードのマッピング
        /// <summary>
        /// 新旧対応データに新・旧住所コードのマッピングが「（1対1）」
        /// </summary>
        public const string CORRESPOND_ONE_TO_ONE = "1";

        /// <summary>
        /// 新旧対応データに新・旧住所コードのマッピングが「（複数対1）」
        /// </summary>
        public const string CORRESPOND_N_TO_ONE = "2";

        /// <summary>
        /// 新旧対応データに新・旧住所コードのマッピングが「（1対複数）」
        /// </summary>
        public const string CORRESPOND_ONE_TO_N = "3";

        /// <summary>
        /// 新旧対応データに新・旧住所コードのマッピングが「（1対1）まだ（複数対1）」
        /// </summary>
        public const string CORRESPOND_ONE_TO_ONE_OR_N_TO_ONE = "4";
        #endregion

        #region 地番分離文字
        /// <summary>
        /// コンマ
        /// </summary>
        public const string OOAZ_AREA_NUMBER_PART_SIGN = ",";

        /// <summary>
        /// 波浪線
        /// </summary>
        public const string OOAZ_AREA_NUMBER_PART_BILLOW_LANG = "～";
        #endregion

        /// <summary>
        /// 全角スペース
        /// </summary>
        public const string FULL_SIZE_BLANK = "　";

        /// <summary>
        /// 半角スペース
        /// </summary>
        public const string HALF_SIZE_BLANK = " ";

        #region 数字
        /// <summary>
        /// 半角数字
        /// </summary>
        public const string HAN_NUM = "0123456789";

        /// <summary>
        /// 全角数字(コンマを含む)
        /// </summary>
        public const string ZEN_NUM_COMMA = "０１２３４５６７８９‐―－ー─";

        /// <summary>
        /// 半角数字(コンマを含む)
        /// </summary>
        public const string HAN_NUM_COMMA = "0123456789-----";

        /// <summary>
        /// 全角スペースと数字と記号
        /// </summary>
        public const string FULL_NUM_COMMA = "０１２３４５６７８９‐―－ー─（）　";

        /// <summary>
        /// 半角スペースと数字と記号
        /// </summary>
        public const string HALF_NUM_COMMA = "0123456789-----() ";
        #endregion

        #region 語頭、語尾の二つの値を設定する
        /// <summary>
        /// 語頭
        /// </summary>
        public const string FRIST_PART = "語頭";

        /// <summary>
        /// 語尾
        /// </summary>
        public const string END_PART = "語尾";
        #endregion

        #region 有無
        /// <summary>
        /// 有
        /// </summary>
        public const string YES = "有";

        /// <summary>
        /// 無
        /// </summary>
        public const string NO = "無";
        #endregion

        #region TODOファイルヘッド部用
        /// <summary>
        /// フィルタ名
        /// </summary>
        public const string FIELDNAME = "FieldName";

        /// <summary>
        /// フィルタタイプ
        /// </summary>
        public const string TITLENAME = "TitleName";

        /// <summary>
        /// フィルタ編集可/編集不可
        /// </summary>
        public const string READONLY = "ReadOnly";

        /// <summary>
        /// フィルタ表示/非表示
        /// </summary>
        public const string VISIBILITY = "Visibility";

        /// <summary>
        /// フィルタ固定/非固定
        /// </summary>
        public const string FIXCOLUMNFLAG = "FixedColumnFlag";

        /// <summary>
        /// 固定項目値
        /// </summary>
        public const string TRUE = "true";
        #endregion

        #region 出力ファイル名の固定部分の定数定義
        /// <summary>
        /// G01-目印取得候補抽出: 編集DB反映用ToDoリストファイル名
        /// </summary>
        public const string G01_MARK_OBTAIN_001_TODO_FILE_NAME = "EditDBToDoList.duco";

        /// <summary>
        /// G02-町字更新: 編集DB反映用ToDoリストファイル名
        /// </summary>
        public const string G02_ADDRESS_DIFF_001_TODO_FILE_NAME = "EditDBToDoList.duco";

        /// <summary>
        /// G02-局番更新：編集DB反映用ToDoリストファイル名
        /// </summary>
        public const string G02_TAREACODE_CHG_001_TODO_FILE_NAME = "EditDBToDoList.duco";

        /// <summary>
        /// G02-行政変更：大字分割目視確認対象ファイル名
        /// </summary>
        public const string G02_AREA_CHANGE_001_TODO_FILE_NAME = "OoazConfirmList.duco";

        /// <summary>
        /// G02-行政変更：編集DB反映用ToDoリストファイル名
        /// </summary>
        public const string G02_AREA_CHANGE_002_TODO_FILE_NAME = "EditDBToDoList.duco";

        /// <summary>
        /// G02-タウン目印自動設定：編集DB反映用ToDoリストファイル名
        /// </summary>
        public const string G02_AUTO_UPDATE_001_TODO_FILE_NAME = "EditDBToDoList.duco";

        /// <summary>
        /// G03-出典マスタDB一括反映-スクールゾーン：編集DB反映用ToDoリストファイル名
        /// </summary>
        public const string G03_APPLY_SCHOOLZONE_001_TODO_FILE_NAME = "EditDBToDoList.duco";

        /// <summary>
        /// G09-バイファケーションメンテナンス：追加候補箇所ToDoリストファイル名
        /// </summary>
        public const string G09_DBIFURCATION_MAINTENANCE_001_TODO_FILE_NAME = "追加候補箇所ToDoリスト.duco";

        /// <summary>
        /// G09-バイファケーションメンテナンス：削除候補箇所ToDoリストファイル名
        /// </summary>
        public const string G09_DBIFURCATION_MAINTENANCE_002_TODO_FILE_NAME = "削除候補箇所ToDoリスト.duco";

        /// <summary>
        /// G10-迂回路メンテナンス：有料区間接続箇所ToDoリストファイル名
        /// </summary>
        public const string G10_DETOUR_ADOPT_001_TODO_FILE_NAME = "有料区間接続箇所.duco";

        /// <summary>
        /// G10-踏切メンテナンス：踏切メンテナンスToDoリストファイル
        /// </summary>
        public const string G10_DRAILROAD_CRS_001_TODO_FILE_NAME = "踏切メンテナンスToDoリスト.duco";

        /// <summary>
        /// G10-踏切メンテナンス：特殊ペアToDoリストファイル
        /// </summary>
        public const string G10_DRAILROAD_CRS_024_TODO_FILE_NAME = "特殊ペアToDoリストファイル.duco";

        /// <summary>
        /// G10-3D交差点パターン設定：3D拡大追加候補ToDoリストファイル名
        /// </summary>
        public const string G10_DDG3DSCRS_MAINTENANCE_001_TODO_FILE_NAME = "3D拡大追加候補.duco";

        /// <summary>
        /// G10-3D交差点パターン設定：3D拡大変更候補ToDoリストファイル名
        /// </summary>
        public const string G10_DDG3DSCRS_MAINTENANCE_002_TODO_FILE_NAME = "3D拡大変更候補.duco";

        /// <summary>
        /// G10-3D交差点パターン設定：3D追加箇所ToDoリストファイル名
        /// </summary>
        public const string G10_DDG3DSCRS_MAINTENANCE_003_TODO_FILE_NAME = "3D追加箇所.duco";

        /// <summary>
        /// G10-3D交差点パターン設定：3D変更箇所ToDoリストファイル名
        /// </summary>
        public const string G10_DDG3DSCRS_MAINTENANCE_004_TODO_FILE_NAME = "3D変更箇所.duco";

        /// <summary>
        /// G10-3D交差点パターン設定：3D手動箇所変更候補ToDoリストファイル名
        /// </summary>
        public const string G10_DDG3DSCRS_MAINTENANCE_005_TODO_FILE_NAME = "3D手動箇所変更候補.duco";

        /// <summary>
        /// G10-3D交差点パターン設定：3D削除箇所ToDoリストファイル名
        /// </summary>
        public const string G10_DDG3DSCRS_MAINTENANCE_006_TODO_FILE_NAME = "3D削除箇所.duco";

        /// <summary>
        /// G10-3D交差点パターン設定：3D手動箇所削除候補ToDoリストファイル名
        /// </summary>
        public const string G10_DDG3DSCRS_MAINTENANCE_007_TODO_FILE_NAME = "3D手動箇所削除候補.duco";

        /// <summary>
        /// G10-英字変換-検索系：目視対象ToDoリストファイル名
        /// </summary>
        public const string G10_VISUAL_CHECK_008_TODO_FILE_NAME = "英字変換目視対象.duco";

        /// <summary>
        /// G10-英字変換-検索系：同一物件英字不一致ToDoリストファイル名
        /// </summary>
        public const string G10_SAME_POI_DIFF_EN_009_TODO_FILE_NAME = "同一物件英字変換確認.duco";

        /// <summary>
        /// G10-英字変換-描画系：英字調査対象ToDoリストファイル名
        /// </summary>
        public const string G10_EN_SURVEY_OBJECT_013_TODO_FILE_NAME = "英字調査対象.duco";

        /// <summary>
        /// G10-英字変換-描画系：英字調査対象_機関裁判所トヨタ関連ToDoリストファイル名
        /// </summary>
        public const string G10_EN_SURVEY_OBJECT_RELATED_013_TODO_FILE_NAME = "英字調査対象_機関裁判所トヨタ関連.duco";

        /// <summary>
        /// G10-Z属性コピー：Z属性コピー実行結果詳細ファイル名
        /// </summary>
        public const string G10_ZPROPERTY_COPY_001_TODO_FILE_NAME = "ZPropCopyResult.duco";

        /// <summary>
        /// G07-編集DB一括反映ファイル統合：編集DB一括反映ファイル統合設定ファイル名
        /// </summary>
        public const string G07_DATAAPPLY_FILEMERGE_001_TODO_FILE_NAME = "MergeFile.duco";

        /// <summary>
        /// G01-作業対象抽出-TZ住所検索データ：特別対応確認ToDoリストファイル
        /// </summary>
        public const string G01_TZ_RELATED_001_TODO_FILE_NAME = "特別対応確認ToDoリストファイル.duco";

        /// <summary>
        /// G01-作業対象抽出-TZ住所検索データ：問連対応確認ToDoリストファイル
        /// </summary>
        public const string G01_TZ_SPECIAL_002_TODO_FILE_NAME = "問連対応確認ToDoリストファイル.duco";

        /// <summary>
        /// G01-作業対象抽出-TZ住所検索データ：レクサ対応確認ToDoリストファイ
        /// </summary>
        public const string G01_TZ_RECUSASU_003_TODO_FILE_NAME = "レクサ対応確認ToDoリストファイ.duco";

        /// <summary>
        /// レベルダウン文字のToDoリストファイル
        /// </summary>
        public const string G02_TXTLEVEL_001_TODO_FILE_NAME = "DisplayLevelMaintenance_LDN.duco";

        /// <summary>
        /// レベルダウン文字のToDoリストファイル
        /// </summary>
        public const string G02_TOLLDISP_001_TODO_FILE_NAME = "DisplayLevelMaintenance_TollDisp_LDN.duco";

        /// <summary>
        /// レベルアップ線状注記文字のToDoリストファイル
        /// </summary>
        public const string G02_TXTLEVEL_002_TODO_FILE_NAME = "DisplayLevelMaintenance_LUP_SJC.duco";

        /// <summary>
        /// レベルアップ線状注記文字以外のToDoリストファイル
        /// </summary>
        public const string G02_TXTLEVEL_003_TODO_FILE_NAME = "DisplayLevelMaintenance_LUP.duco";

        /// <summary>
        /// 料金表示文字レベルアップの更新ToDoリスト
        /// </summary>
        public const string G02_TOLLDISP_003_TODO_FILE_NAME = "DisplayLevelMaintenance_TollDisp_LUP.duco";

        /// <summary>
        /// オフセット設定できない線状注記文字のToDoリストファイル
        /// 更新有無フラグが有り
        /// </summary>
        public const string G02_TXTLEVEL_004_TODO_FILE_NAME = "DisplayLevelMaintenance_OFTNG_Upd.duco";

        /// <summary>
        /// オフセット設定できない線状注記文字のToDoリストファイル
        /// 更新有無フラグがなし
        /// </summary>
        public const string G02_TXTLEVEL_005_TODO_FILE_NAME = "DisplayLevelMaintenance_OFTNG_NoUpd.duco";

        /// <summary>
        /// G10-交差点名称自動生成：手動リカバリ用ToDoリストファイル名
        /// </summary>
        public const string G10_CRSNAME_CREATE_001_TODO_FILE_NAME = "手動リカバリ用ToDoリストファイル.duco";
        #endregion

        #region 最初に発行した調査対象IDと最後に発行した調査対象ID
        /// <summary>
        /// 最初に発行した調査対象ID       
        /// </summary>
        public const string KAISI = "開始番号";

        /// <summary>
        /// 最後に発行した調査対象ID       
        /// </summary>
        public const string SHUURYOU = "終了番号";
        #endregion

        #region TODOリスト出力フラグ
        /// <summary>
        /// TODOリスト出力フラグ_出力済み
        /// </summary>
        public const string TO_DO_OUTPUT_FLAG_ONE = "1";
        #endregion
    }
}
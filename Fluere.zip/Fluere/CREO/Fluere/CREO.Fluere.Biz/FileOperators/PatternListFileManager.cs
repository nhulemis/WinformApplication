﻿using System.IO;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 組合せリストファイルの読み込み
    /// </summary>
    public class PatternListFileManager
    {
        /// <summary>
        /// 組合せリストファイルの読み込み
        /// </summary>
        /// <param name="strPath">組合せリストファイルのパス</param>
        /// <returns>組合せリスト</returns>
        public static PatternListData ReadPatternList(string strPath)
        {
            try
            {
                // ファイルが存在するか確認
                if (!System.IO.File.Exists(strPath))
                {
                    throw new FileNotFoundException();
                }

                PatternListData patternList = new PatternListData();

                // 組合せリストファイルの読み込み
                string content = FileUtil.ReadFile(strPath);

                // 行分割
                string[] stringLines = StringUtil.SpiltToLines(content);

                // 組合せリスト作成
                foreach (string currentLine in stringLines)
                {
                    string status = currentLine.Replace("\t", string.Empty);

                    if (!string.IsNullOrEmpty(status))
                    {
                        patternList.StatusNoList.Add(status);
                    }
                }

                return patternList;
            }
            catch (FileNotFoundException)
            {
                // 組合せリストファイルがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40000010;
                throw new BusinessLogicException(msgId, new string[] { strPath });
            }
            catch (FileLoadException)
            {
                // 組合せリストファイルの読み込みに失敗しました場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40000011;
                throw new BusinessLogicException(msgId, new string[] { strPath });
            }
        }
    }
}

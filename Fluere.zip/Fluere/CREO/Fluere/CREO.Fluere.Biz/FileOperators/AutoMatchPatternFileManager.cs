﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.BusinessObject;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 自動継承条件ファイルの読込、書込み
    /// </summary>
    public class AutoMatchPatternFileManager
    {
        /// <summary>
        /// 自動継承条件ファイルの読込
        /// </summary>
        /// <param name="file">自動継承条件ファイル名</param>
        /// <returns>自動継承条件ファイル</returns>
        public static List<AutoMatchPatternData> ReadAutoMatchPatternFile(string file)
        {
            List<AutoMatchPatternData> dataList = new List<AutoMatchPatternData>();

            string formatFilePath = ConfigFileInfo.AutoMatchPatternFormat;

            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(file, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    AutoMatchPatternData autoMatchPattern = new AutoMatchPatternData();

                    // 条件種別
                    autoMatchPattern.CondCatalog = fp["CondCatalog"].ToString();

                    // 適用フィールド
                    autoMatchPattern.Field = int.Parse(fp["Field"].ToString());

                    // 特殊条件
                    autoMatchPattern.SpecialCond = int.Parse(fp["SpecialCond"].ToString());

                    // 文字列1のリスト（全角文字列）
                    autoMatchPattern.BaseList = fp["BaseList"].ToString().Split(',').ToList();

                    // 文字列2のリスト（文字列１と一致と判定する全角文字列）
                    autoMatchPattern.SameList = fp["SameList"].ToString().Split(',').ToList();

                    dataList.Add(autoMatchPattern);
                }
            }
            catch (Exception)
            {
                // 自動継承条件ファイルがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000052;
                string[] parameters = new string[] { file };

                throw new BusinessLogicException(msgId, parameters);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

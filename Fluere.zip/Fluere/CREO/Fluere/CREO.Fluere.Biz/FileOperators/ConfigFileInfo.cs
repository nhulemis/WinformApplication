﻿using System.IO;
using CREO.Fluere.Biz.Constants;
using CREO.FW.Utilities;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// ConfigFileInfo
    /// </summary>
    public class ConfigFileInfo
    {
        // ファイルパーサーに関連するセクション↓
        #region ファイルパーサー用のフォーマット定義名
        /// <summary>
        /// 目印置換設定ファイル
        /// </summary>
        private const string MARK_REPLACE_LIST_FORMAT = "MarkReplaceListFormat.xml";

        /// <summary>
        /// 目印調査対象原稿ファイル
        /// </summary>
        private const string MARK_SUVERY_LIST_FORMAT = "MarkSurveyListFormat.xml";

        /// <summary>
        /// G03_差分抽出‐タウンページデータのみに対応
        /// </summary>
        private const string G03_TWN_DIFF_EXTRACT_FORMAT = "TownFileFormat.xml";

        /// <summary>
        /// 新規･廃止差分タウンファイル
        /// </summary>
        private const string NEW_DIS_TWN_DIFF_FORMAT = "NewDisTwnDiffFileFormat.xml";

        /// <summary>
        /// タウンファイル
        /// </summary>
        private const string TMI_TOWNPAGE_DATA_FORMAT = "TMITownpageDataFileFormat.xml";

        /// <summary>
        /// インディクスファイル
        /// </summary>
        private const string INDEX_FORMAT = "IndexFileFormat.xml";

        /// <summary>
        /// TZ住所検索データファイル
        /// </summary>
        private const string TZ_HOUSE_SEARCH_FORMAT = "TZHouseSearchFromat.xml";

        /// <summary>
        /// 目印リカバリログファイルの定義ファイル
        /// </summary>
        private const string MARK_RECOVER_FORMAT = "MarkRecoverFormat.xml";

        /// <summary>
        /// 自動継承条件リストファイルの定義ファイル
        /// </summary>
        private const string AUTO_MATCH_PATTERN_FORMAT = "AutoMatchPatternFormat.xml";

        /// <summary>
        /// 自動継承ログファイルの定義ファイル
        /// </summary>
        private const string AUTO_MATCHING_LOG_FORMAT = "AutoMatchingLogFormat.xml";

        /// <summary>
        /// 目視対象ログファイルの定義ファイル
        /// </summary>
        private const string EYE_CONFRIM_LOG_FORMAT = "EyeConfirmLogFormat.xml";

        /// <summary>
        /// 役所定義ファイルの定義ファイル
        /// </summary>
        private const string GOV_OFFICE_DEF_FORMAT = "GovOfficeDefFormat.xml";

        /// <summary>
        /// 建造物定義ファイルの定義ファイル
        /// </summary>
        private const string BUILDING_DEF_FORMAT = "BuildingDefFormat.xml";

        /// <summary>
        /// 京都市通り名称置換文字列定義ファイルの定義ファイル
        /// </summary>
        private const string KYOUTO_STREET_NAME_REPLACE_DEF_FORMAT = "KyoutoStreetNameReplaceDefFormat.xml";

        /// <summary>
        /// 方書・漢字複合条件ファイルの定義ファイル
        /// </summary>
        private const string MATRIX_CO_KANJI_FORMAT = "MatrixCoKanjiFileFormat.xml";

        /// <summary>
        /// 東西通り名称ファイルの定義ファイル
        /// </summary>
        private const string EASTWET_STREET_NAME_FORMAT = "EastWetStreetNameFormat.xml";

        /// <summary>
        /// 南北通り名称ファイルの定義ファイル
        /// </summary>
        private const string SOUTHNORTH_STREET_NAME_FORMAT = "SouthNorthStreetNameFormat.xml";

        /// <summary>
        /// 大字表記対リストファイルの定義ファイル
        /// </summary>
        private const string OOAZ_MAPPING_FORMAT = "OoazMappingFormat.xml";

        /// <summary>
        /// ZMAP中間ファイルファイルの定義ファイル
        /// </summary>
        private const string ZMAP_TEMP_FORMAT = "ZmapTempFormat.xml";

        /// <summary>
        /// ZCY京都交差点ファイルの定義ファイル
        /// </summary>
        private const string ZCY_KYOUTO_CRS_FORMAT = "ZcyKyoutoCrsFormat.xml";

        /// <summary>
        ///  NGファイルの定義ファイル
        /// </summary>
        private const string NG_DATA_FORMAT = "NgFormat.xml";

        /// <summary>
        /// 隣接大字ファイルの定義ファイル
        /// </summary>
        private const string ADJOIN_OOAZDATA_FORMAT = "AdjoinOoazFormat.xml";

        /// <summary>
        /// 面積設定した大字代表点ファイルの定義ファイル
        /// </summary>
        private const string AREA_SQUAR_GEN_FORMAT = "AreaSquarGenFormat.xml";

        /// <summary>
        /// 累積住所代表点ファイルの定義ファイル
        /// </summary>
        private const string ACCUMULATION_AEN_FORMAT = "AccumulationAenFormat.xml";

        /// <summary>
        /// 町字差分ファイルの定義ファイル
        /// </summary>
        private const string ADDRESS_DIFF_FORMAT = "AddressDiffFormat.xml";

        /// <summary>
        /// GRXファイルの定義ファイル
        /// </summary>
        private const string GRX_Data_FORMAT = "GrxCellFormat.xml";

        /// <summary>
        /// エリア名称ファイルの定義ファイル
        /// </summary>
        private const string AREANAME_DATA_FORMAT = "AreaNameFormat.xml";

        /// <summary>
        /// 地形図管理データファイルの定義ファイル
        /// </summary>
        private const string TopoMapManager_Data_FORMAT = "TopoMapManagerFormat.xml";

        /// <summary>
        /// 地形図補足データファイルの定義ファイル
        /// </summary>
        private const string TopoMapFill_Data_FORMAT = "TopoMapFillFormat.xml";

        /// <summary>
        /// 新旧対応表データファイルの定義ファイル
        /// </summary>
        private const string NewOldMapping_Data_FORMAT = "NewOldMappingFillFormat.xml";

        /// <summary>
        /// 駐車場差分リストファイルの定義ファイル
        /// </summary>
        private const string ParkingDiffListFill_Data_FORMAT = "ParkingDiffListFormat.xml";

        /// <summary>
        /// 出典差分･今回出典･前回出典･外国人･外国人以外スクールゾーンファイルの定義ファイル
        /// </summary>
        private const string SCHOOL_ZONE_FILE_DATA_FORMAT = "SchoolZoneFileDataFormat.xml";

        /// <summary>
        /// 出典差分･今回出典･前回出典･外国人･外国人以外スクールゾーンファイルの定義ファイル
        /// </summary>
        private const string SCHOOL_ZONE_FILE_DATA_WRITE_FORMAT = "SchoolZoneFileDataWriteFormat.xml";

        /// <summary>
        /// 局番・電話番号変更設定ファイルの定義ファイル
        /// </summary>
        private const string TEL_FILE_DATA_FORMAT = "TelFileDataFormat.xml";

        /// <summary>
        /// 出典差分-スクールゾーンファイル-外国人の定義ファイル
        /// </summary>
        private const string Materia_Diff_Schoolzone_Foreign_FORMAT = "MateriaDiffSchoolzoneFormat.xml";

        /// <summary>
        /// 出典差分-スクールゾーンファイル-外国人以外の定義ファイル
        /// </summary>
        private const string Materia_Diff_Schoolzone_FORMAT = "MateriaDiffSchoolzoneFormat.xml";

        /// <summary>
        /// 分類コードと施設物件ジャンルコードの対応の定義ファイル
        /// </summary>
        private const string TGnrL_POI_Code_FORMAT = "TGnrPOICodeMappingFormat.xml";

        /// <summary>
        /// ToDoリスト作成用の情報（外国人）の定義ファイル
        /// </summary>
        private const string MakeToDoInfo_Foreign_FORMAT = "MakeToDoInfoFormat.xml";

        /// <summary>
        /// ToDoリスト作成用の情報（外国人以外）の定義ファイル
        /// </summary>
        private const string MakeToDoInfo_FORMAT = "MakeToDoInfoFormat.xml";

        /// <summary>
        /// VICSリンクの定義ファイル
        /// </summary>
        private const string VICS_LINK_FORMAT = "VICSLinkFileFormat.xml";

        /// <summary>
        /// 文字種別ファイルの定義ファイル
        /// </summary>
        private const string TYPE_CODE_SETTING_FORMAT = "TypeCodeSettingFormat.xml";

        /// <summary>
        /// 文字種別の共通フォーマットの定義ファイル
        /// </summary>
        private const string TYP_TXT_COMMON_FORMAT = "TypTxtCommonFormat.xml";

        /// <summary>
        /// 規制情報変換テーブルファイルの定義ファイル
        /// </summary>
        private const string REG_INFO_CONVERT_FORMAT = "RegInfoConvertFormat.xml";

        /// <summary>
        /// 予約VICS⇒VICS更新設定ファイルの定義ファイル
        /// </summary>
        private const string VICS_SECTION_FORMAT = "VicsSectionFormat.xml";

        /// <summary>
        /// 省略単語設定ファイルの定義ファイル
        /// </summary>
        private const string ABBREVIATION_SETTING_FORMAT = "AbbreviationSettingFormat.xml";

        /// <summary>
        /// 部分変換設定ファイルの定義ファイル
        /// </summary>
        private const string PART_CONVERT_SETTING_FORMAT = "PartConvertSettingFormat.xml";

        /// <summary>
        /// 目視対象ジャンルファイルの定義ファイル
        /// </summary>
        private const string VISUAL_CHECK_GENRE_FORMAT = "VisualCheckGenreFormat.xml";

        /// <summary>
        /// 英字変換対象外ジャンルファイルの定義ファイル
        /// </summary>
        private const string EN_CONVERT_EXCEPT_GENRE_FORMAT = "EnConvertExceptGenreFormat.xml";

        /// <summary>
        /// 除外ジャンルコードリストファイルの定義ファイル
        /// </summary>
        private const string EXCLUSION_GENRE_CODE_LIST_FORMAT = "ExclusionGenreCodeListFormat.xml";

        /// <summary>
        /// 対象ジャンルリストファイルの定義ファイル
        /// </summary>
        private const string TARGET_GENRE_LIST_FORMAT = "TargetGenreListFormat.xml";

        /// <summary>
        /// コンテンツリカバリ処理対象リストファイルの定義ファイル
        /// </summary>
        private const string REVOCERY_PROCESS_OBJECT_DATA = "ReadRevoceryProcessObjectFormat.xml";

        /// <summary>
        /// 描画系部分変換設定ファイルの定義ファイル
        /// </summary>
        private const string MJC_PART_FORMAT = "MjcPartFileFormat.xml";

        /// <summary>
        /// 語頭語尾変換設定ファイルの定義ファイル
        /// </summary>
        private const string MJC_GOTOU_GOBI_FORMAT = "MjcGotouGobiFileFormat.xml";

        /// <summary>
        /// 種別毎変換設定ファイルの定義ファイル
        /// </summary>
        private const string MJC_ALL_FORMAT = "MjcAllFileFormat.xml";

        /// <summary>
        /// 複数名称一括変換設定ファイルの定義ファイル
        /// </summary>
        private const string ONE_VS_N_FORMAT = "1vsNFileFormat.xml";

        /// <summary>
        /// 使用禁止文字設定ファイルの定義ファイル
        /// </summary>
        private const string BLOCK_WORD_FORMAT = "BlockWordFileFormat.xml";

        /// <summary>
        /// カーメーカー関連リストファイルの定義ファイル
        /// </summary>
        private const string CAR_MAKER_FORMAT = "CarMakerFileFormat.xml";

        /// <summary>
        /// 英字変換分類一覧設定ファイルの定義ファイル
        /// </summary>
        private const string EN_CONVERT_TYPE_FORMAT = "EnConvertTypeFileFormat.xml";

        /// <summary>
        /// スペース対象抽出定義ファイルの定義ファイル
        /// </summary>
        private const string SPACE_OBJECT_DEF_FORMAT = "SpaceObjectDefFileFormat.xml";

        /// <summary>
        /// マッチング対応交差点目印ファイル
        /// </summary>
        private const string SPACE_TARGETSNO_FORMAT = "TargetSnoFormat.xml";

        /// <summary>
        /// 対象外交差点設定ファイル
        /// </summary>
        private const string SPACE_OVERCRSNO_FORMAT = "OverCrsnoFormat.xml";

        /// <summary>
        /// 交差点目印丸設定ファイル
        /// </summary>
        private const string SPACE_CMKTWNSNO_FORMAT = "CmkTwnSnoFormat.xml";

        /// <summary>
        /// マッチング結果ファイル
        /// </summary>
        private const string SPACE_MATCHINGRESULTS_FORMAT = "MatchingResultsFormat.xml";

        /// <summary>
        /// アンマッチ結果ファイル
        /// </summary>
        private const string SPACE_UNMATCHRESULTS_FORMAT = "UnmatchResultsFormat.xml";

        /// <summary>
        /// 調査原稿テキストファイル
        /// </summary>
        private const string SPACE_SEARCHINFO_FORMAT = "SearchInfoFormat.xml";

        /// <summary>
        /// 調査原稿テキストファイル（Pingo連携用）
        /// </summary>
        private const string SPACE_SEARCHINFOPINGO_FORMAT = "SearchInfoPingoFormat.xml";

        /// <summary>
        /// マッチングリストファイル
        /// </summary>
        private const string SPACE_MATCHINGLIST_FORMAT = "MatchingListFormat.xml";

        /// <summary>
        /// 特殊街区の大字小字変換ログファイル
        /// </summary>
        private const string SPACE_GAIKUCONVERT_FORMAT = "GaikuConvertFormat.xml";

        /// <summary>
        /// 音声発注リストファイルの定義ファイル
        /// </summary>
        private const string VOICE_ORDER_FORMAT = "VoiceOrderFormat.xml";

        /// <summary>
        /// 差分住所データファイル
        /// </summary>
        private const string DIFF_ADR_FORMAT = "DiffAdrFormat.xml";

        /// <summary>
        /// 接頭語接尾語変換設定ファイル
        /// </summary>
        private const string HEAD_TAIL_CONVERT_FORMAT = "HeadTailConvertFormat.xml";

        /// <summary>
        /// 高速路線ファイル
        /// </summary>
        private const string T_ROUTE_HW_FORMAT = "TRouteHwFormat.xml";

        /// <summary>
        /// 施設物件リストの定義ファイル
        /// </summary>
        private const string FACILITY_LIST_FORMAT = "FacilityListFormat.xml";

        #endregion

        #region ファイルパーサー用のフォーマットファイルのパス（ユーザ指定）
        /// <summary>
        /// ユーザが指定されたパス
        /// </summary>
        private static string _baseicFileParserSettingsPath =
            System.Configuration.ConfigurationManager.AppSettings[CommonConstants.FILE_FORMAT_PATH];
        #endregion

        #region ファイルパーサー用のパブリックインターフェイス
        /// <summary>
        /// 目印置換設定ファイル
        /// ※G01-目印取得候補抽出
        /// </summary>
        public static string MarkReplaceListFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, MARK_REPLACE_LIST_FORMAT);
            }
        }

        /// <summary>
        /// 目印調査対象原稿ファイル
        /// ※G01-目印取得候補抽出
        /// ※G02-タウン目印自動設定
        /// </summary>
        public static string MarkSuveryListFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, MARK_SUVERY_LIST_FORMAT);
            }
        }

        /// <summary>
        /// G03_差分抽出‐タウンページデータのみに対応
        /// ※G03-差分抽出-タウンページデータ
        /// </summary>
        public static string G03TwnDiffExtractFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, G03_TWN_DIFF_EXTRACT_FORMAT);
            }
        }

        /// <summary>
        /// タウンファイル
        /// ※G02-行政変更：町字（行政変更）処理
        /// </summary>
        public static string TMITownpageDataFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, TMI_TOWNPAGE_DATA_FORMAT);
            }
        }

        /// <summary>
        /// 新規･廃止差分タウンファイル
        /// ※G02-行政変更
        /// ※G02-タウン受入処理
        /// </summary>
        public static string NewDisDiffTwnFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, NEW_DIS_TWN_DIFF_FORMAT);
            }
        }

        /// <summary>
        /// インディクスファイル
        /// ※G02-行政変更
        /// ※G02-局番更新
        /// </summary>
        public static string IndexFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, INDEX_FORMAT);
            }
        }

        /// <summary>
        /// TZ住所検索データファイル
        /// ※G02-行政変更
        /// </summary>
        public static string TZHouseSearchFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, TZ_HOUSE_SEARCH_FORMAT);
            }
        }

        /// <summary>
        /// 目印リカバリログファイルの定義ファイル
        /// ※G02-タウン目印自動設定
        /// </summary>
        public static string MarkRecoverFormat
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, MARK_RECOVER_FORMAT);
            }
        }

        /// <summary>
        /// 自動継承条件リストファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string AutoMatchPatternFormat
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, AUTO_MATCH_PATTERN_FORMAT);
            }
        }

        /// <summary>
        /// 自動継承ログファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string AutoMatchingLogFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, AUTO_MATCHING_LOG_FORMAT);
            }
        }

        /// <summary>
        /// 役所定義ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string GovOfficeDefFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, GOV_OFFICE_DEF_FORMAT);
            }
        }

        /// <summary>
        /// 建造物定義ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string BuildingDefFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, BUILDING_DEF_FORMAT);
            }
        }

        /// <summary>
        /// 東西通り名称ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string EastWetStreetNameFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, EASTWET_STREET_NAME_FORMAT);
            }
        }

        /// <summary>
        /// 南北通り名称ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string SouthNorthStreetNameFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SOUTHNORTH_STREET_NAME_FORMAT);
            }
        }

        /// <summary>
        /// 目視対象ログファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string EyeConfirmLogFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, EYE_CONFRIM_LOG_FORMAT);
            }
        }

        /// <summary>
        /// 京都市通り名称置換文字列定義ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string KyoutoStreetNameReplaceDefFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, KYOUTO_STREET_NAME_REPLACE_DEF_FORMAT);
            }
        }

        /// <summary>
        /// 方書・漢字複合条件ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string MatrixCoKanjiFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, MATRIX_CO_KANJI_FORMAT);
            }
        }

        /// <summary>
        /// 大字表記対応リストファイルの定義ファイル
        /// ※G02-行政変更
        /// ※G02-局番更新
        /// ※G02-タウン受入処理
        /// </summary>
        public static string OoazMappingFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, OOAZ_MAPPING_FORMAT);
            }
        }

        /// <summary>
        /// ZMAP中間ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string ZmapTempFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, ZMAP_TEMP_FORMAT);
            }
        }

        /// <summary>
        /// ZCY京都交差点ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string ZcyKyoutoCrsFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, ZCY_KYOUTO_CRS_FORMAT);
            }
        }

        /// <summary>
        /// NGファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string NgDataFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, NG_DATA_FORMAT);
            }
        }

        /// <summary>
        /// エリア名称ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string AreaNameDataFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, AREANAME_DATA_FORMAT);
            }
        }

        /// <summary>
        /// 隣接大字ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string AdjoinOoazDataFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, ADJOIN_OOAZDATA_FORMAT);
            }
        }

        /// <summary>
        /// 面積設定した大字代表点ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string AreaSquarGenFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, AREA_SQUAR_GEN_FORMAT);
            }
        }

        /// <summary>
        /// 累積住所代表点ファイルの定義ファイル
        /// ※G02-タウン受入処理
        /// </summary>
        public static string AccumulationAenFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, ACCUMULATION_AEN_FORMAT);
            }
        }

        /// <summary>
        /// 町字差分ファイルの定義ファイル
        /// ※G02-町字更新
        /// </summary>
        public static string AddressDiffFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, ADDRESS_DIFF_FORMAT);
            }
        }

        /// <summary>
        /// GRXファイルの定義ファイル
        /// ※G02-行政変更
        /// ※G02-背景座標値流し込み
        /// </summary>
        public static string GRXDataFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, GRX_Data_FORMAT);
            }
        }

        /// <summary>
        /// 地形図管理データファイルの定義ファイル
        /// ※G02-背景座標値流し込み
        /// </summary>
        public static string TopoMapManagerDataFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, TopoMapManager_Data_FORMAT);
            }
        }

        /// <summary>
        /// 新旧対応表データファイルの定義ファイル
        /// ※G02-行政変更
        /// </summary>
        public static string NewOldAreaMappingDataFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, NewOldMapping_Data_FORMAT);
            }
        }

        /// <summary>
        /// 地形図補足データファイルの定義ファイル
        /// ※G02-背景座標値流し込み
        /// </summary>
        public static string TopoMapFillDataFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, TopoMapFill_Data_FORMAT);
            }
        }

        /// <summary>
        /// 地形図補足データファイルの定義ファイル
        /// ※G03-出典マスタDB一括反映-駐車場物件
        /// </summary>
        public static string ParkingDiffListDataFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, ParkingDiffListFill_Data_FORMAT);
            }
        }

        /// <summary>
        /// 出典差分･今回出典･前回出典･外国人･外国人以外スクールゾーンファイルの定義ファイル
        /// ※G03-出典マスタDB一括反映-スクールゾーン
        /// </summary>
        public static string SchoolZoneDataFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SCHOOL_ZONE_FILE_DATA_FORMAT);
            }
        }

        /// <summary>
        /// 出典差分･今回出典･前回出典･外国人･外国人以外スクールゾーンファイルの定義ファイル
        /// ※G03-出典マスタDB一括反映-スクールゾーン
        /// </summary>
        public static string SchoolZoneDataWriteFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SCHOOL_ZONE_FILE_DATA_WRITE_FORMAT);
            }
        }

        /// <summary>
        /// 局番・電話番号変更設定ファイル
        /// ※G02-局番更新
        /// </summary>
        public static string TelFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, TEL_FILE_DATA_FORMAT);
            }
        }

        /// <summary>
        /// 出典差分-スクールゾーンファイル-外国人の対応ファイル
        /// G03-差分抽出-スクールゾーン
        /// </summary>
        public static string MateriaDiffSchoolzoneForeignFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, Materia_Diff_Schoolzone_Foreign_FORMAT);
            }
        }

        /// <summary>
        /// 出典差分-スクールゾーンファイル-外国人以外の対応ファイル
        /// G03-差分抽出-スクールゾーン
        /// </summary>
        public static string MateriaDiffSchoolzoneFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, Materia_Diff_Schoolzone_FORMAT);
            }
        }

        /// <summary>
        /// 分類コードと施設物件ジャンルコードの対応ファイル
        /// ※G03-出典マスタDB一括反映-スクールゾーン
        /// </summary>
        public static string TGnrPOICodeMappingFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, TGnrL_POI_Code_FORMAT);
            }
        }

        /// <summary>
        /// 今回出典ToDoリスト作成用の情報（外国人）ファイル
        /// ※G03-出典マスタDB一括反映-スクールゾーン
        /// </summary>
        public static string MakeToDoInfoForeignFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, MakeToDoInfo_Foreign_FORMAT);
            }
        }

        /// <summary>
        /// ToDoリスト作成用の情報（外国人以外）ファイル
        /// ※G03-出典マスタDB一括反映-スクールゾーン
        /// </summary>
        public static string MakeToDoInfoFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, MakeToDoInfo_FORMAT);
            }
        }

        /// <summary>
        /// VICSリンクファイル
        /// ※G10-自動車専用道路メンテナンス
        /// ※G10-規制速度メンテナンス
        /// </summary>
        public static string VICSLinkFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, VICS_LINK_FORMAT);
            }
        }

        /// <summary>
        /// 文字種別の設定ファイル
        /// ※G02-表示レベル設定
        /// </summary>
        public static string TypeCodeSettingFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, TYPE_CODE_SETTING_FORMAT);
            }
        }

        /// <summary>
        /// 文字種別の共通ファイル
        /// </summary>
        public static string TypTxtCommonFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, TYP_TXT_COMMON_FORMAT);
            }
        }

        /// <summary>
        /// 規制情報変換の共通ファイル
        /// ※G10-規制情報一括変換
        /// </summary>
        public static string RegInfoConvertFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, REG_INFO_CONVERT_FORMAT);
            }
        }

        /// <summary>
        /// 予約VICS⇒VICS更新設定ファイル
        /// ※G10-予約VICS⇒VICS更新
        /// </summary>
        public static string VicsSectionFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, VICS_SECTION_FORMAT);
            }
        }

        /// <summary>
        /// 省略単語設定ファイル
        /// ※G10-英字変換-検索系
        /// </summary>
        public static string AbbreviationSettingFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, ABBREVIATION_SETTING_FORMAT);
            }
        }

        /// <summary>
        /// 部分変換設定ファイル
        /// ※G10-英字変換-検索系
        /// </summary>
        public static string PartConvertSettingFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, PART_CONVERT_SETTING_FORMAT);
            }
        }

        /// <summary>
        /// 目視対象ジャンルファイル
        /// ※G10-英字変換-検索系
        /// </summary>
        public static string VisualCheckGenreFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, VISUAL_CHECK_GENRE_FORMAT);
            }
        }

        /// <summary>
        /// 英字変換対象外ジャンルファイル
        /// ※G10-英字変換-検索系
        /// </summary>
        public static string EnConvertExceptGenreFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, EN_CONVERT_EXCEPT_GENRE_FORMAT);
            }
        }

        /// <summary>
        /// 除外ジャンルコードリストファイル
        /// </summary>
        public static string ExclusionGenreCodeListFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, EXCLUSION_GENRE_CODE_LIST_FORMAT);
            }
        }

        /// <summary>
        /// 対象ジャンルリストファイル
        /// </summary>
        public static string TargetGenreListFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, TARGET_GENRE_LIST_FORMAT);
            }
        }

        /// <summary>
        /// コンテンツリカバリ処理対象リストファイルの定義ファイル
        /// ※G09-コンテンツリカバリ対象抽出
        /// </summary>
        public static string RevoceryProcessObjectDataFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, REVOCERY_PROCESS_OBJECT_DATA);
            }
        }

        /// <summary>
        /// 描画系部分変換設定ファイルの定義ファイル
        /// </summary>
        public static string MjcPartFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, MJC_PART_FORMAT);
            }
        }

        /// <summary>
        /// 語頭語尾変換設定ファイルの定義ファイル
        /// </summary>
        public static string MjcGotouGobiFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, MJC_GOTOU_GOBI_FORMAT);
            }
        }

        /// <summary>
        /// 種別毎変換設定ファイルの定義ファイル
        /// </summary>
        public static string MjcAllFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, MJC_ALL_FORMAT);
            }
        }

        /// <summary>
        /// 複数名称一括変換設定ファイルの定義ファイル
        /// </summary>
        public static string OneVsNFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, ONE_VS_N_FORMAT);
            }
        }

        /// <summary>
        /// 使用禁止文字設定ファイルの定義ファイル
        /// </summary>
        public static string BlockWordFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, BLOCK_WORD_FORMAT);
            }
        }

        /// <summary>
        /// カーメーカー関連リストファイルの定義ファイル
        /// </summary>
        public static string CarMakerFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, CAR_MAKER_FORMAT);
            }
        }

        /// <summary>
        /// 英字変換分類一覧設定ファイルの定義ファイル
        /// </summary>
        public static string EnConvertTypeFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, EN_CONVERT_TYPE_FORMAT);
            }
        }

        /// <summary>
        /// スペース対象抽出定義ファイルの定義ファイル
        /// </summary>
        public static string SpaceObjectDefFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_OBJECT_DEF_FORMAT);
            }
        }

        /// <summary>
        /// マッチング対応交差点目印ファイル
        /// </summary>
        public static string SpaceTargetSnoFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_TARGETSNO_FORMAT);
            }
        }

        /// <summary>
        /// 対象外交差点設定ファイル
        /// </summary>
        public static string SpaceOverCrsnoFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_OVERCRSNO_FORMAT);
            }
        }

        /// <summary>
        /// 交差点目印丸設定ファイル
        /// </summary>
        public static string SpaceCmkTwnSnoFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_CMKTWNSNO_FORMAT);
            }
        }

        /// <summary>
        /// マッチング結果ファイル
        /// </summary>
        public static string MatchingResultsFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_MATCHINGRESULTS_FORMAT);
            }
        }

        /// <summary>
        /// アンマッチ結果ファイル
        /// </summary>
        public static string UnmatchResultsFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_UNMATCHRESULTS_FORMAT);
            }
        }

        /// <summary>
        /// 調査原稿テキストファイル
        /// </summary>
        public static string SearchInfoFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_SEARCHINFO_FORMAT);
            }
        }

        /// <summary>
        /// 調査原稿テキストファイル（Pingo連携用）
        /// </summary>
        public static string SearchInfoPingoFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_SEARCHINFOPINGO_FORMAT);
            }
        }

        /// <summary>
        /// マッチングリストファイル
        /// </summary>
        public static string MatchingListFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_MATCHINGLIST_FORMAT);
            }
        }

        /// <summary>
        /// 特殊街区の大字小字変換ログファイル
        /// </summary>
        public static string GaikuConvertFormat
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, SPACE_GAIKUCONVERT_FORMAT);
            }
        }

        /// <summary>
        /// 音声発注リストファイルの定義ファイル
        /// </summary>
        public static string VoiceOrderFileFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, VOICE_ORDER_FORMAT);
            }
        }

        /// <summary>
        /// 差分住所データファイル
        /// </summary>
        public static string DiffAdrFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, DIFF_ADR_FORMAT);
            }
        }

        /// <summary>
        /// 接頭語接尾語変換設定ファイル
        /// </summary>
        public static string HeadTailConvertFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, HEAD_TAIL_CONVERT_FORMAT);
            }
        }

        /// <summary>
        /// 高速路線ファイル
        /// </summary>
        public static string TRouteHwFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, T_ROUTE_HW_FORMAT);
            }
        }

        /// <summary>
        /// 施設物件リスト
        /// </summary>
        public static string FacilityListFormatFile
        {
            get
            {
                return Path.Combine(
                    ProfileUtility.BaseDir, _baseicFileParserSettingsPath, FACILITY_LIST_FORMAT);
            }
        }

        #endregion

        // ToDoリスト作成に関連するセクション↓
        #region ToDoリスト用のフォーマットパターン定義
        /// <summary>
        /// ToDoリストファイルのフォーマットパターン01のフォーマットファイル
        /// </summary>
        public const string TODOFILE_PATTERN_NO_001 = "ToDo_XML_UF_XX_001";

        /// <summary>
        /// ToDoリストファイルのフォーマットパターン03のフォーマットファイル
        /// </summary>
        public const string TODOFILE_PATTERN_NO_003 = "ToDo_XML_UF_XX_003";

        /// <summary>
        /// ToDoリストファイルのフォーマットパターン04のフォーマットファイル
        /// </summary>
        public const string TODOFILE_PATTERN_NO_004 = "ToDo_XML_UF_XX_004";
        #endregion
    }
}

﻿using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 目視対象ログファイルの書き込み、読込
    /// </summary>
    public class EyeConfirmLogFileManager
    {
        /// <summary>
        /// 目視対象ログファイルの読み込み
        /// </summary>
        /// <param name="strPath">目視対象ログファイルのパス</param>
        /// <returns>目視対象ログファイルリスト</returns>
        public static List<EyeConfrimLogData> ReadEyeConfirmLogFile(string strPath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(strPath))
            {
                throw new FileNotFoundException();
            }

            // 目視対象ログファイルデータ初期化
            List<EyeConfrimLogData> lsteyeConfrimLogData = new List<EyeConfrimLogData>();

            // テキストファイル読込む
            string content = FileUtil.ReadFile(strPath);

            // 行データの分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // コードリスト作成
            foreach (string currentLine in stringLines)
            {
                string[] strData = StringUtil.SpiltDataByTab(currentLine);

                if (strData.Length > 0)
                {
                    EyeConfrimLogData eyeConfrimLogData = new EyeConfrimLogData();

                    // 新旧区分
                    eyeConfrimLogData.NewOrOld = strData[0];

                    // 方書一致判定結果
                    eyeConfrimLogData.SameKatagakiFlag = int.Parse(strData[1]);

                    // 漢字掲載名一致判定結果
                    eyeConfrimLogData.SameTwnKanjiFlag = int.Parse(strData[2]);

                    // OID
                    eyeConfrimLogData.OID = ulong.Parse(strData[3]);

                    // 電話番号
                    eyeConfrimLogData.TelNumber = strData[4];

                    // 漢字掲載名
                    eyeConfrimLogData.TwnKanji = strData[5];

                    // 都道府県コード
                    eyeConfrimLogData.ProvinceCode = int.Parse(strData[6]);

                    // 市区町村コード
                    eyeConfrimLogData.CityCode = int.Parse(strData[7]);

                    // 大字コード
                    eyeConfrimLogData.OazaCode = strData[8];

                    // 字・丁目コード
                    eyeConfrimLogData.SectionCode = strData[9];

                    // 都道府県名
                    eyeConfrimLogData.ProvinceName = strData[10];

                    // 市区郡町村名
                    eyeConfrimLogData.CityName = strData[11];

                    // 大字・通称名
                    eyeConfrimLogData.OazaName = strData[12];

                    // 字・丁目名
                    eyeConfrimLogData.SectionName = strData[13];

                    // 街区番号・部屋番号
                    eyeConfrimLogData.GaikuRoom = strData[14];

                    // 方書
                    eyeConfrimLogData.Katagaki = strData[15];

                    // NTT分類コード
                    eyeConfrimLogData.NTTGroupCode = strData[16];

                    // NTT分類名
                    eyeConfrimLogData.NTTGroupName = strData[17];

                    // 経度
                    eyeConfrimLogData.Longitude = long.Parse(strData[18]);

                    // 緯度
                    eyeConfrimLogData.Latitude = long.Parse(strData[19]);

                    // マッチングレベル
                    eyeConfrimLogData.MatchingLv = int.Parse(strData[20]);

                    lsteyeConfrimLogData.Add(eyeConfrimLogData);
                }
            }

            return lsteyeConfrimLogData;
        }

        /// <summary>
        /// 書込みメソッドを対象
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="eyeConfrimLogList">ファイルのデータリスト</param>
        public static void WriteEyeConfirmLogFile(
            string filePath, List<EyeConfrimLogData> eyeConfrimLogList)
        {
            // TsvファイルFormat
            string addressFormatFile = ConfigFileInfo.EyeConfirmLogFormatFile;

            if (!System.IO.File.Exists(addressFormatFile))
            {
                throw new FileNotFoundException(addressFormatFile);
            }

            XElement xmlDef = XElement.Load(addressFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                fp = new FileParser(fstream, xmlDef);

                foreach (EyeConfrimLogData eyeConfrimLogData in eyeConfrimLogList)
                {
                    fp.AddRecord();

                    SetCurData(fp, eyeConfrimLogData);
                }

                fp.Close();
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }

        /// <summary>
        /// 変更メソッドを対象
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="eyeConfrimLogList">ファイルのデータリスト</param>
        public static void ModifyEyeConfirmLogFile(
            string filePath, List<EyeConfrimLogData> eyeConfrimLogList)
        {
            // TsvファイルFormat
            string addressFormatFile = ConfigFileInfo.EyeConfirmLogFormatFile;

            if (!System.IO.File.Exists(addressFormatFile))
            {
                throw new FileNotFoundException(addressFormatFile);
            }

            XElement xmlDef = XElement.Load(addressFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Truncate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (EyeConfrimLogData eyeConfrimLogData in eyeConfrimLogList)
                {
                    fp.AppendRecord();

                    SetCurData(fp, eyeConfrimLogData);
                }

                fp.Close();
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }

        /// <summary>
        /// 一つデータを設定する
        /// </summary>
        /// <param name="fp">ファイルパーサ</param>
        /// <param name="eyeConfrimLogData">ファイルのデータ</param>
        private static void SetCurData(FileParser fp, EyeConfrimLogData eyeConfrimLogData)
        {
            // 新旧区分
            if (string.IsNullOrEmpty(eyeConfrimLogData.NewOrOld) ||
                string.IsNullOrWhiteSpace(eyeConfrimLogData.NewOrOld))
            {
                fp["NewOrOld"] = string.Empty;
            }
            else
            {
                fp["NewOrOld"] = eyeConfrimLogData.NewOrOld;
            }

            // SameKatagakiFlag
            fp["SameKatagakiFlag"] = eyeConfrimLogData.SameKatagakiFlag.ToString();

            // SameTwnKanjiFlag
            fp["SameTwnKanjiFlag"] = eyeConfrimLogData.SameTwnKanjiFlag.ToString();

            // OID
            fp["OID"] = eyeConfrimLogData.OID.ToString();

            // 電話番号
            if (string.IsNullOrWhiteSpace(eyeConfrimLogData.TelNumber))
            {
                fp["TelNumber"] = string.Empty;
            }
            else
            {
                fp["TelNumber"] = eyeConfrimLogData.TelNumber;
            }

            // 漢字掲載名
            if (string.IsNullOrEmpty(eyeConfrimLogData.TwnKanji) ||
                string.IsNullOrWhiteSpace(eyeConfrimLogData.TwnKanji))
            {
                fp["TwnKanji"] = string.Empty;
            }
            else
            {
                fp["TwnKanji"] = eyeConfrimLogData.TwnKanji;
            }

            // 都道府県コード
            fp["ProvinceCode"] = eyeConfrimLogData.ProvinceCode.ToString();

            // 市区町村コード
            fp["CityCode"] = eyeConfrimLogData.CityCode.ToString();

            // 大字コード
            if (string.IsNullOrWhiteSpace(eyeConfrimLogData.OazaCode))
            {
                fp["OazaCode"] = string.Empty;
            }
            else
            {
                fp["OazaCode"] = eyeConfrimLogData.OazaCode;
            }

            // 字・丁目コード
            if (string.IsNullOrWhiteSpace(eyeConfrimLogData.SectionCode))
            {
                fp["SectionCode"] = string.Empty;
            }
            else
            {
                fp["SectionCode"] = eyeConfrimLogData.SectionCode;
            }

            // 都道府県名
            if (string.IsNullOrEmpty(eyeConfrimLogData.ProvinceName) ||
                string.IsNullOrWhiteSpace(eyeConfrimLogData.ProvinceName))
            {
                fp["ProvinceName"] = string.Empty;
            }
            else
            {
                fp["ProvinceName"] = eyeConfrimLogData.ProvinceName;
            }

            // 市区郡町村名
            if (string.IsNullOrEmpty(eyeConfrimLogData.CityName) ||
                string.IsNullOrWhiteSpace(eyeConfrimLogData.CityName))
            {
                fp["CityName"] = string.Empty;
            }
            else
            {
                fp["CityName"] = eyeConfrimLogData.CityName;
            }

            // 大字・通称名
            if (string.IsNullOrEmpty(eyeConfrimLogData.OazaName) ||
                string.IsNullOrWhiteSpace(eyeConfrimLogData.OazaName))
            {
                fp["OazaName"] = string.Empty;
            }
            else
            {
                fp["OazaName"] = eyeConfrimLogData.OazaName;
            }

            // 字・丁目名
            if (string.IsNullOrEmpty(eyeConfrimLogData.SectionName) ||
                string.IsNullOrWhiteSpace(eyeConfrimLogData.SectionName))
            {
                fp["SectionName"] = string.Empty;
            }
            else
            {
                fp["SectionName"] = eyeConfrimLogData.SectionName;
            }

            // 街区番号・部屋番号
            if (string.IsNullOrEmpty(eyeConfrimLogData.GaikuRoom) ||
                string.IsNullOrWhiteSpace(eyeConfrimLogData.GaikuRoom))
            {
                fp["GaikuRoom"] = string.Empty;
            }
            else
            {
                fp["GaikuRoom"] = eyeConfrimLogData.GaikuRoom;
            }

            // 方書
            if (string.IsNullOrEmpty(eyeConfrimLogData.Katagaki) ||
                string.IsNullOrWhiteSpace(eyeConfrimLogData.Katagaki))
            {
                fp["Katagaki"] = string.Empty;
            }
            else
            {
                fp["Katagaki"] = eyeConfrimLogData.Katagaki;
            }

            // NTT分類コード
            if (string.IsNullOrWhiteSpace(eyeConfrimLogData.NTTGroupCode))
            {
                fp["NTTGroupCode"] = string.Empty;
            }
            else
            {
                fp["NTTGroupCode"] = eyeConfrimLogData.NTTGroupCode;
            }

            // NTT分類名
            if (string.IsNullOrEmpty(eyeConfrimLogData.NTTGroupName) ||
                string.IsNullOrWhiteSpace(eyeConfrimLogData.NTTGroupName))
            {
                fp["NTTGroupName"] = string.Empty;
            }
            else
            {
                fp["NTTGroupName"] = eyeConfrimLogData.NTTGroupName;
            }

            // 経度
            fp["Longitude"] = eyeConfrimLogData.Longitude.ToString();

            // 緯度
            fp["Latitude"] = eyeConfrimLogData.Latitude.ToString();

            // マッチングレベル
            fp["MatchingLv"] = eyeConfrimLogData.MatchingLv.ToString();

            // ファイルパーサーにアップデート
            fp.Update();
        }
    }
}

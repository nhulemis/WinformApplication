﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// カーメーカー関連リストファイル管理
    /// </summary>
    public class CarMakerFileManager
    {
        /// <summary>
        /// カーメーカー関連リストファイルを読み込み
        /// </summary>
        /// <param name="filePath">カーメーカー関連リストファイルパス</param>
        /// <returns>カーメーカー関連リストファイルデータのリスト</returns>
        public static List<string> ReadCarMakerFile(string filePath)
        {
            List<string> dataList = new List<string>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.CarMakerFileFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    if ((string)fp["c1"] != string.Empty)
                    {
                        dataList.Add(fp["c1"] as string);
                    }
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

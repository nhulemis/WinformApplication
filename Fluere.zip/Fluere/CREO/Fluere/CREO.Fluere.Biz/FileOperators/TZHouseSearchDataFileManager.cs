﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// TZ住所検索データファイルの読込、書込み
    /// </summary>
    public class TZHouseSearchDataFileManager
    {
        #region TZ住所検索データファイルを読込
        /// <summary>
        /// TZ住所検索データファイルを読込
        /// </summary>
        /// <param name="filepath">TZ住所検索データファイルパース</param>
        /// <returns>TZ住所検索データファイルデータリスト</returns>
        public static List<TZHouseSearchData> ReadTZHouseSearchFile(string filepath)
        {
            XElement xmlDef = null;
            FileStream stream = null;
            FileParser fp = null;
            List<TZHouseSearchData> record = null;
            try
            {
                record = new List<TZHouseSearchData>();

                // フォーマットファイル存在チェック
                if (!File.Exists(ConfigFileInfo.TZHouseSearchFormatFile))
                {
                    // フォーマットファイルがオープン出来ない場合
                    string msgId = UF_Fluere_MsgId.MSGID_UF10000079;
                    throw new BusinessLogicException(msgId, new string[] { ConfigFileInfo.TZHouseSearchFormatFile });
                }

                // バイナリファイルFormat
                xmlDef = XElement.Load(ConfigFileInfo.TZHouseSearchFormatFile);

                // ファイル読込
                stream = new FileStream(filepath, FileMode.Open, FileAccess.Read);

                // バイナリファイル作成
                fp = new FileParser(stream, xmlDef);

                // バイナリファイル読む
                while (fp.NextRecord())
                {
                    TZHouseSearchData tzHouseFileData = new TZHouseSearchData();

                    // レコード種別
                    tzHouseFileData.ReCodeType = (string)fp["ReCodeType"];

                    // ゼンリン独自住所フラグ
                    tzHouseFileData.ZenRinAloneTAdrFlag = (string)fp["ZenRinAloneTAdrFlag"];

                    // 都道府県コード
                    tzHouseFileData.ProvinceCode = (string)fp["ProvinceCode"];

                    // 市区町村コード
                    tzHouseFileData.CityCode = (string)fp["CityCode"];

                    // 大字・町コード
                    tzHouseFileData.OazaCode = (string)fp["OazaCode"];

                    // 字・丁目コード
                    tzHouseFileData.SectionCode = (string)fp["SectionCode"];

                    // 街区コード
                    tzHouseFileData.GaikuCode = (string)fp["GaikuCode"];

                    // 地番・戸番
                    tzHouseFileData.LotOrHouseNo = (string)fp["LotOrHouseNo"];

                    // 建物連番
                    tzHouseFileData.BuildingNo = (string)fp["BuildingNo"];

                    // 都道府県名称
                    tzHouseFileData.ProvinceName = (string)fp["ProvinceName"];

                    // 市区町村名称
                    tzHouseFileData.CityName = (string)fp["CityName"];

                    // 大字・町名称
                    tzHouseFileData.OazaName = (string)fp["OazaName"];

                    // 字・丁目名称
                    tzHouseFileData.SectionName = (string)fp["SectionName"];

                    // 街区番号
                    tzHouseFileData.GaikuNo = (string)fp["GaikuNo"];

                    // 市区町村名称カナ
                    tzHouseFileData.CityNameKana = (string)fp["CityNameKana"];

                    // 大字・町名称カナ
                    tzHouseFileData.OazaNameKana = (string)fp["OazaNameKana"];

                    // 字・丁目名称カナ
                    tzHouseFileData.SectionNameKana = (string)fp["SectionNameKana"];

                    // 住所座標　経度
                    tzHouseFileData.AdrTpoiLongitude = (string)fp["AdrTpoiLongitude"];

                    // 住所座標　緯度
                    tzHouseFileData.AdrTpoiLatitude = (string)fp["AdrTpoiLatitude"];

                    // 建物到着地点座標　経度
                    tzHouseFileData.BuildingLongitude = (string)fp["BuildingLongitude"];

                    // 建物到着地点座標　緯度
                    tzHouseFileData.BuildingLatitude = (string)fp["BuildingLatitude"];

                    record.Add(tzHouseFileData);
                }

                fp.Close();
                stream.Close();
            }
            catch (FrameworkException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // 手動でメモリを解放する
                if (fp != null)
                {
                    fp.Dispose();
                }

                if (stream != null)
                {
                    stream.Dispose();
                }
            }

            return record;
        }
        #endregion

        #region TZ住所検索データファイルを書込み
        /// <summary>
        /// TZ住所検索データファイルを書込み
        /// </summary>
        /// <param name="path">TZ住所検索データファイルパース</param>
        /// <param name="updateTZHouseDataList">TZ住所検索データファイルデータリスト</param>
        public static void WriteTZHouseSearchFile(string path, List<TZHouseSearchData> updateTZHouseDataList)
        {
            // レコードフォーマットファイル読込
            XElement xmlDef = XElement.Load(ConfigFileInfo.TZHouseSearchFormatFile);

            // ファイルパーサー用情報設定
            FileParser fileParser = null;

            fileParser = new FileParser(new FileStream(path,
                                                        FileMode.OpenOrCreate,
                                                        FileAccess.ReadWrite),
                                        xmlDef);

            try
            {
                foreach (TZHouseSearchData data in updateTZHouseDataList)
                {
                    fileParser.AddRecord();

                    // レコード種別
                    fileParser["ReCodeType"] = data.ReCodeType;

                    // ゼンリン独自住所フラグ
                    fileParser["ZenRinAloneTAdrFlag"] = data.ZenRinAloneTAdrFlag;

                    // 都道府県コード
                    fileParser["ProvinceCode"] = data.ProvinceCode;

                    // 市区町村コード
                    fileParser["CityCode"] = data.CityCode;

                    // 大字・町コード
                    fileParser["OazaCode"] = data.OazaCode;

                    // 字・丁目コード
                    fileParser["SectionCode"] = data.SectionCode;

                    // 街区コード
                    fileParser["GaikuCode"] = data.GaikuCode;

                    // 地番・戸番
                    fileParser["LotOrHouseNo"] = data.LotOrHouseNo;

                    // 建物連番
                    fileParser["BuildingNo"] = data.BuildingNo;

                    // 都道府県名称
                    fileParser["ProvinceName"] = data.ProvinceName;

                    // 市区町村名称
                    fileParser["CityName"] = data.CityName;

                    // 大字・町名称
                    fileParser["OazaName"] = data.OazaName;

                    // 字・丁目名称
                    fileParser["SectionName"] = data.SectionName;

                    // 街区番号
                    fileParser["GaikuNo"] = data.GaikuNo;

                    // 市区町村名称カナ
                    fileParser["CityNameKana"] = data.CityNameKana;

                    // 大字・町名称カナ
                    fileParser["OazaNameKana"] = data.OazaNameKana;

                    // 字・丁目名称カナ
                    fileParser["SectionNameKana"] = data.SectionNameKana;

                    // 住所座標　経度
                    fileParser["AdrTpoiLongitude"] = data.AdrTpoiLongitude;

                    // 住所座標　緯度
                    fileParser["AdrTpoiLatitude"] = data.AdrTpoiLatitude;

                    // 建物到着地点座標　経度
                    fileParser["BuildingLongitude"] = data.BuildingLongitude;

                    // 建物到着地点座標　緯度
                    fileParser["BuildingLatitude"] = data.BuildingLatitude;

                    // ファイルパーサーにアップデート
                    fileParser.Update();
                }
            }
            catch (FrameworkException fwEx)
            {
                throw fwEx;
            }
            catch (Exception exp)
            {
                throw exp;
            }
            finally
            {
                fileParser.Close();
                fileParser.Dispose();
            }
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CREO.Fluere.Common.DataSources.OpenXml;
using CREO.Fluere.Biz.FileOperators.Data;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 問連対応リストファイルの読み込み
    /// </summary>
    public class RelatedListInputFileManager
    {
        #region クラス属性定義
        /// <summary>
        /// シートページの名前
        /// </summary>
        private static string excelSheetName = "問連対応リスト";

        #endregion

        #region 問連対応リストファイルの読み込み
        /// <summary>
        /// 問連対応リストファイルの読み込み
        /// </summary>
        /// <param name="filePath">問連対応リストファイルパス</param>
        /// <returns>問連対応リストファイル</returns>
        public static List<RelatedListInputListData> RelatedListInputList(string filePath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(filePath))
            {
                throw new FileNotFoundException(filePath);
            }

            // 戻りリスト
            List<RelatedListInputListData> relatedListInputListDataList =
                new List<RelatedListInputListData>();

            // 読込結果の整形
            using (SpreadSheetDataRepository repository = new SpreadSheetDataRepository(
                filePath, CultureInfo.InvariantCulture, true, false))
            {
                repository.Open();

                // ファイルの読込
                IEnumerable<object[]> context = repository.Target(excelSheetName);

                foreach (object[] record in context)
                {
                    if (record.Length == 0)
                    {
                        continue;
                    }

                    // データインスタンス
                    RelatedListInputListData relatedListInputListData = new RelatedListInputListData();

                    // Ｎｏ
                    if (record.Length > 0 && !string.IsNullOrEmpty(record[0].ToString()))
                    {
                        relatedListInputListData.SpecialListNo = Convert.ToInt32(record[0]);
                    }
                    else
                    {
                        relatedListInputListData.SpecialListNo = 0;
                    }

                    // 都道府県コード
                    if (record.Length > 1 && !string.IsNullOrEmpty(record[1].ToString()))
                    {
                        relatedListInputListData.ProvinceCode = record[1].ToString();
                    }
                    else
                    {
                        relatedListInputListData.ProvinceCode = "0";
                    }

                    // 市区町村コード
                    if (record.Length > 2 && !string.IsNullOrEmpty(record[2].ToString()))
                    {
                        relatedListInputListData.CityCode = record[2].ToString();
                    }
                    else
                    {
                        relatedListInputListData.CityCode = "0";
                    }

                    // 大字コード
                    if (record.Length > 3 && !string.IsNullOrEmpty(record[3].ToString()))
                    {
                        relatedListInputListData.OazaCode = record[3].ToString();
                    }
                    else
                    {
                        relatedListInputListData.OazaCode = "0";
                    }

                    // 小字コード
                    if (record.Length > 4 && !string.IsNullOrEmpty(record[4].ToString()))
                    {
                        relatedListInputListData.SectionCode = record[4].ToString();
                    }
                    else
                    {
                        relatedListInputListData.SectionCode = "0";
                    }

                    // 街区符号
                    if (record.Length > 5 && !string.IsNullOrEmpty(record[5].ToString()))
                    {
                        relatedListInputListData.GaikuCode = record[5].ToString();
                    }
                    else
                    {
                        relatedListInputListData.GaikuCode = "0";
                    }

                    // 住居番号
                    if (record.Length > 6 && !string.IsNullOrEmpty(record[6].ToString()))
                    {
                        relatedListInputListData.HouseNo = record[6].ToString();
                    }
                    else
                    {
                        relatedListInputListData.HouseNo = "0";
                    }

                    // 地番
                    if (record.Length > 7 && !string.IsNullOrEmpty(record[7].ToString()))
                    {
                        relatedListInputListData.LotNo = record[7].ToString();
                    }
                    else
                    {
                        relatedListInputListData.LotNo = "0";
                    }

                    // 枝番
                    if (record.Length > 8 && !string.IsNullOrEmpty(record[8].ToString()))
                    {
                        relatedListInputListData.SuffixNo = record[8].ToString();
                    }
                    else
                    {
                        relatedListInputListData.SuffixNo = "0";
                    }

                    // 住所名称
                    if (record.Length > 9 && !string.IsNullOrEmpty(record[9].ToString()))
                    {
                        relatedListInputListData.AdrName = record[9].ToString();
                    }
                    else
                    {
                        relatedListInputListData.AdrName = "0";
                    }

                    // ２MC
                    if (record.Length > 10 && !string.IsNullOrEmpty(record[10].ToString()))
                    {
                        relatedListInputListData.MC = Convert.ToInt32(record[10]);
                    }
                    else
                    {
                        relatedListInputListData.MC = 0;
                    }

                    // X座標
                    if (record.Length > 11 && !string.IsNullOrEmpty(record[11].ToString()))
                    {
                        relatedListInputListData.Longitude = Convert.ToInt64(record[11]);
                    }
                    else
                    {
                        relatedListInputListData.Longitude = 0;
                    }

                    // Y座標
                    if (record.Length > 12 && !string.IsNullOrEmpty(record[12].ToString()))
                    {
                        relatedListInputListData.Latitude = Convert.ToInt64(record[12]);
                    }
                    else
                    {
                        relatedListInputListData.Latitude = 0;
                    }

                    // 確認項目
                    if (record.Length > 13 && !string.IsNullOrEmpty(record[13].ToString()))
                    {
                        relatedListInputListData.ConfirmType = record[13].ToString();
                    }
                    else
                    {
                        relatedListInputListData.ConfirmType = "0";
                    }

                    // 確認内容
                    if (record.Length > 14 && !string.IsNullOrEmpty(record[14].ToString()))
                    {
                        relatedListInputListData.ConfirmContent = record[14].ToString();
                    }
                    else
                    {
                        relatedListInputListData.ConfirmContent = "0";
                    }

                    // 問連管理No
                    if (record.Length > 15 && !string.IsNullOrEmpty(record[15].ToString()))
                    {
                        relatedListInputListData.RelatedMngNo = record[15].ToString();
                    }
                    else
                    {
                        relatedListInputListData.RelatedMngNo = "0";
                    }

                    // 管理表登録日
                    if (record.Length > 16 && !string.IsNullOrEmpty(record[16].ToString()))
                    {
                        relatedListInputListData.EntryDate = record[16].ToString();
                    }
                    else
                    {
                        relatedListInputListData.EntryDate = "0";
                    }

                    relatedListInputListDataList.Add(relatedListInputListData);
                }
            }

            return relatedListInputListDataList;
        }
        #endregion
    }
}

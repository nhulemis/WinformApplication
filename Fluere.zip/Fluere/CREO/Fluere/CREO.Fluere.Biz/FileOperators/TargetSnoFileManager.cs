﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// マッチング対応交差点目印ファイル
    /// </summary>
    public class TargetSnoFileManager
    {
        /// <summary>
        /// Readメソッド
        /// </summary>
        /// <param name="filePath">filePath</param>
        /// <returns>マッチング対応交差点目印</returns>
        public static List<TargetSnoData> Read(string filePath)
        {
            List<TargetSnoData> dataList = new List<TargetSnoData>();

            string formatFilePath = ConfigFileInfo.SpaceTargetSnoFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // lst ファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    TargetSnoData targetSnoData = new TargetSnoData();

                    // 交差点目印の【目印名称】[目印コード]
                    targetSnoData.MarkCode = (string)fp["MarkCode"];

                    // 交差点目印漢字名称
                    targetSnoData.MarkName = (string)fp["MarkName"];

                    // 交差点目印カナ名称
                    targetSnoData.MarkKanaName = (string)fp["MarkKanaName"];

                    // 半角数字（Null、1、2）
                    targetSnoData.MarkNumber = (string)fp["MarkNumber"];

                    dataList.Add(targetSnoData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

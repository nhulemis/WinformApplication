﻿using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 出典差分-スクールゾーンファイル-外国人以外定義ファイル
    /// </summary>
    public class MateriaDiffSchoolzoneFileManager
    {
        /// <summary>
        /// 出典差分-スクールゾーンファイル-外国人以外定義ファイルの読込
        /// </summary>
        /// <param name="file">出典差分-スクールゾーンファイル-外国人以外定義ファイル名</param>
        /// <returns>出典差分-スクールゾーンファイル-外国人以外ファイル</returns>
        public static List<MateriaDiffSchoolzoneData> ReadMateriaDiffSchoolzoneFile(string file)
        {
            List<MateriaDiffSchoolzoneData> dataList = new List<MateriaDiffSchoolzoneData>();
            string formatFilePath = ConfigFileInfo.MateriaDiffSchoolzoneFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            fstream = new FileStream(file, FileMode.Open, FileAccess.Read);
            fp = new FileParser(fstream, xmlDef);

            while (fp.NextRecord())
            {
                MateriaDiffSchoolzoneData materiaDiffSchoolzoneData = new MateriaDiffSchoolzoneData();

                // 差分区分
                string value = fp["DiffFlag"].ToString();
                CheckDiffFlg(value);
                materiaDiffSchoolzoneData.DiffFlag = fp["DiffFlag"].ToString();

                // 差分明細
                materiaDiffSchoolzoneData.DiffDetail = fp["DiffDetail"].ToString();

                // 施設物件拡張のOID
                materiaDiffSchoolzoneData.OID = fp["OID"].ToString();

                // 出典ID
                materiaDiffSchoolzoneData.MaterialID = fp["MaterialID"].ToString();

                // 物件住所（漢字）
                materiaDiffSchoolzoneData.AdrNameKanji = fp["AdrNameKanji"].ToString();

                // 電話番号
                materiaDiffSchoolzoneData.Telno = fp["Telno"].ToString();

                // 正式漢字名称
                materiaDiffSchoolzoneData.FormalNameKanji = fp["FormalNameKanji"].ToString();

                // 正式カナ名称
                materiaDiffSchoolzoneData.FormalNameKana = fp["FormalNameKana"].ToString();

                // 表示漢字名称
                materiaDiffSchoolzoneData.DispNameKanji = fp["DispNameKanji"].ToString();

                // 2次メッシュコード
                materiaDiffSchoolzoneData.Meshcode = fp["Meshcode"].ToString();

                // 東経座標
                materiaDiffSchoolzoneData.Longitude = fp["Longitude"].ToString();

                // 北緯座標
                materiaDiffSchoolzoneData.Latitude = fp["Latitude"].ToString();

                // 読込むファイル区分
                materiaDiffSchoolzoneData.FileType = "L";

                dataList.Add(materiaDiffSchoolzoneData);
            }

            if (fp != null)
            {
                fp.Dispose();
            }

            fp = null;

            if (fstream != null)
            {
                fstream.Dispose();
            }

            fstream = null;

            return dataList;
        }

        /// <summary>
        /// 差分区分チェック
        /// </summary>
        /// <param name="value">差分区分値</param>
        private static void CheckDiffFlg(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                if (("N" != value) && ("C" != value) && ("D" != value))
                {
                    throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF10000125, new string[] { "出典差分-スクールゾーンファイル-外国人以外ファイル", "差分区分-DiffFlg" });
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 目視対象ジャンルファイル
    /// </summary>
    public class VisualCheckGenreFileManager
    {
        /// <summary>
        /// 目視対象ジャンルファイルの読込
        /// </summary>
        /// <param name="filePath">目視対象ジャンルファイルパス</param>
        /// <returns>目視対象ジャンルデータのリスト</returns>
        public static List<VisualCheckGenreData> ReadVisualCheckGenreFile(string filePath)
        {
            List<VisualCheckGenreData> dataList = new List<VisualCheckGenreData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.VisualCheckGenreFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                int i = 0;

                while (fp.NextRecord())
                {
                    if (i == 0)
                    {
                        i++;
                        continue;
                    }

                    VisualCheckGenreData visualCheckGenreData = new VisualCheckGenreData();

                    string temp = null;
                    ushort value;

                    // 親ジャンルコード
                    temp = fp["P_GenreCode"] as string;

                    if (!ushort.TryParse(temp, out value))
                    {
                        throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF21003432, temp);
                    }

                    visualCheckGenreData.P_GenreRange = value;

                    // 子ジャンル範囲(前)
                    temp = fp["C_GenreRangeFront"] as string;

                    if (string.IsNullOrWhiteSpace(temp))
                    {
                        continue;
                    }

                    // 子ジャンル範囲（前）
                    visualCheckGenreData.C_GenreRangeFront = Convert.ToUInt16(temp);

                    temp = fp["C_GenreRangeAfter"] as string;

                    if (string.IsNullOrWhiteSpace(temp))
                    {
                        continue;
                    }

                    // 子ジャンル範囲（後）
                    visualCheckGenreData.C_GenreRangeAfter = Convert.ToUInt16(temp);

                    // 対象条件文字列（カナ）
                    visualCheckGenreData.Condition = fp["Condition"] as string;

                    dataList.Add(visualCheckGenreData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

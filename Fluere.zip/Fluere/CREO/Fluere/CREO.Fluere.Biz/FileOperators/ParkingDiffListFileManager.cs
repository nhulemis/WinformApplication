﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Message;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 駐車場差分リストファイル
    /// </summary>
    public class ParkingDiffListFileManager
    {
        #region ログマネージャーのインスタンス、メッセージマネージャーのインスタンス
        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        private static LogManager _logMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);

        /// <summary>
        /// メッセージマネージャーインスタンス
        /// </summary>
        private static MessageManager _msgMgr = MessageManager.GetMessageManager(UF_Fluere_MsgId.MODULE_NUMBER);
        #endregion

        #region 駐車場差分リストファイルの読込
        /// <summary>
        /// 駐車場差分リストファイルの読込
        /// </summary>
        /// <param name="parkingDiffListFile">駐車場差分リストファイルパース</param>
        /// <param name="mappingDefFile">駐車場差分リストファイル</param>
        /// <param name="foreignKeyDictionary">外部定義名リスト</param>
        /// <returns>駐車場差分リストファイルデータ</returns>
        public static List<ParkingDiffListData> ReadParkingDiffListFile(string parkingDiffListFile,
                                                                        string mappingDefFile,
                                                                        Dictionary<string, string> foreignKeyDictionary)
        {
            List<ParkingDiffListData> dataList = new List<ParkingDiffListData>();

            string formatFilePath = ConfigFileInfo.ParkingDiffListDataFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;

            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fs = new FileStream(parkingDiffListFile, FileMode.Open, FileAccess.Read);

                // BOMあり、一時対応
                fs.Position = 3;

                fp = new FileParser(fs, xmlDef);

                ulong lineNo = 0;
                while (fp.NextRecord())
                {
                    lineNo++;
                    ParkingDiffListData data = new ParkingDiffListData();

                    // 行番号
                    data.LineNo = lineNo;

                    // CSVのデータ「差分情報」「順番1」
                    string value = (string)fp["DiffType"];
                    CheckNullOrEmpty(value, ParkingDiffListDataConstant.DiffType, parkingDiffListFile, lineNo);
                    data.DiffType = ushort.Parse(value);
                    bool isNew = false;
                    bool isUpdate = false;
                    switch (data.DiffType)
                    {
                        case ParkingDiffListDataConstant.DIFF_NEW:
                            isNew = true;
                            break;
                        case ParkingDiffListDataConstant.DIFF_CHANGE:
                            isUpdate = true;
                            break;
                        default:
                            break;
                    }

                    // CSVのデータ「駐車場ＩＤ」「順番2」
                    value = (string)fp["ParkingID"];
                    CheckNullOrEmpty(value, ParkingDiffListDataConstant.ParkingID, parkingDiffListFile, lineNo);
                    data.ParkingID = value;

                    // CSVのデータ「変更内容」の項目名リスト「順番124」
                    value = (string)fp["UpdateContent"];
                    data.ChangeColumnList = value;
                    List<string> updateFieldList = new List<string>();
                    if (isUpdate)
                    {
                        CheckNullOrEmpty(value, ParkingDiffListDataConstant.UpdateContent, parkingDiffListFile, lineNo);
                        updateFieldList = data.ChangeColumnList.Split(',').ToList();
                    }

                    #region CSVのデータ「順番3-順番123」

                    Dictionary<string, string> allColumnValueDict = new Dictionary<string, string>();
                    allColumnValueDict.Add(ParkingDiffListDataConstant.OutAreaCode, (string)fp["OutAreaCode"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.InAreaCode, (string)fp["InAreaCode"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.MemberCode, (string)fp["MemberCode"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.KanjiName, (string)fp["KanjiName"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.KanaName, (string)fp["KanaName"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.ProvinceName, (string)fp["ProvinceName"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.AdminName, (string)fp["AdminName"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Oaza, (string)fp["Oaza"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.SectionName, (string)fp["SectionName"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Number, (string)fp["Number"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TPostCode, (string)fp["TPostCode"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.AdminCode, (string)fp["AdminCode"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Longitude, (string)fp["Longitude"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Latitude, (string)fp["Latitude"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LongitudeIn, (string)fp["LongitudeIn"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LatitudeIn, (string)fp["LatitudeIn"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayInfoNum, (string)fp["RegularHolidayInfoNum"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayTyp1, (string)fp["RegularHolidayTyp1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayTyp2, (string)fp["RegularHolidayTyp2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayTyp3, (string)fp["RegularHolidayTyp3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayTyp4, (string)fp["RegularHolidayTyp4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayTyp5, (string)fp["RegularHolidayTyp5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayInfo1, (string)fp["RegularHolidayInfo1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayInfo2, (string)fp["RegularHolidayInfo2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayInfo3, (string)fp["RegularHolidayInfo3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayInfo4, (string)fp["RegularHolidayInfo4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayInfo5, (string)fp["RegularHolidayInfo5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHolidayMemo, (string)fp["RegularHolidayMemo"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeNum, (string)fp["BizTimeNum"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTyp1, (string)fp["BizTimeTyp1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTypAnother1, (string)fp["BizTimeTypAnother1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StartHour1, (string)fp["StartHour1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.EndHour1, (string)fp["EndHour1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.UnitTime1, (string)fp["UnitTime1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Rate1, (string)fp["Rate1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTyp2, (string)fp["BizTimeTyp2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTypAnother2, (string)fp["BizTimeTypAnother2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StartHour2, (string)fp["StartHour2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.EndHour2, (string)fp["EndHour2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.UnitTime2, (string)fp["UnitTime2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Rate2, (string)fp["Rate2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTyp3, (string)fp["BizTimeTyp3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTypAnother3, (string)fp["BizTimeTypAnother3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StartHour3, (string)fp["StartHour3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.EndHour3, (string)fp["EndHour3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.UnitTime3, (string)fp["UnitTime3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Rate3, (string)fp["Rate3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTyp4, (string)fp["BizTimeTyp4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTypAnother4, (string)fp["BizTimeTypAnother4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StartHour4, (string)fp["StartHour4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.EndHour4, (string)fp["EndHour4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.UnitTime4, (string)fp["UnitTime4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Rate4, (string)fp["Rate4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTyp5, (string)fp["BizTimeTyp5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeTypAnother5, (string)fp["BizTimeTypAnother5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StartHour5, (string)fp["StartHour5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.EndHour5, (string)fp["EndHour5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.UnitTime5, (string)fp["UnitTime5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Rate5, (string)fp["Rate5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RegularHoliday, (string)fp["RegularHoliday"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTime1, (string)fp["BizTime1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTime2, (string)fp["BizTime2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RateInfo1, (string)fp["RateInfo1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RateInfo2, (string)fp["RateInfo2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RateInfo3, (string)fp["RateInfo3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.RateInfo4, (string)fp["RateInfo4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.CouponTicket, (string)fp["CouponTicket"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.PrepaidCard, (string)fp["PrepaidCard"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.CreditCard, (string)fp["CreditCard"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.CreditCardTyp, (string)fp["CreditCardTyp"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Cash, (string)fp["Cash"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Use1000Yen, (string)fp["Use1000Yen"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Use5000Yen, (string)fp["Use5000Yen"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Use10000Yen, (string)fp["Use10000Yen"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Receipt, (string)fp["Receipt"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Genre, (string)fp["Genre"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoNum, (string)fp["TypKindInfoNum"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypA1, (string)fp["TypKindInfoTypA1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypB1, (string)fp["TypKindInfoTypB1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypA2, (string)fp["TypKindInfoTypA2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypB2, (string)fp["TypKindInfoTypB2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypA3, (string)fp["TypKindInfoTypA3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypB3, (string)fp["TypKindInfoTypB3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypA4, (string)fp["TypKindInfoTypA4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypB4, (string)fp["TypKindInfoTypB4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypA5, (string)fp["TypKindInfoTypA5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TypKindInfoTypB5, (string)fp["TypKindInfoTypB5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.TakeInUnit, (string)fp["TakeInUnit"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.Human, (string)fp["Human"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.HandicappedOnlySpaceCnt, (string)fp["HandicappedOnlySpaceCnt"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.WomanOnlySpaceCnt, (string)fp["WomanOnlySpaceCnt"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LimitInfoHeight, (string)fp["LimitInfoHeight"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LimitInfoWidth, (string)fp["LimitInfoWidth"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LimitInfoLength, (string)fp["LimitInfoLength"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LimitInfoWeight, (string)fp["LimitInfoWeight"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LimitInfo3No, (string)fp["LimitInfo3No"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LimitInfoRV, (string)fp["LimitInfoRV"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LimitInfo1BOX, (string)fp["LimitInfo1BOX"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LimitInfoImported, (string)fp["LimitInfoImported"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.LimitInfoAnother, (string)fp["LimitInfoAnother"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.CooperationStoreCnt, (string)fp["CooperationStoreCnt"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.CooperationStore1, (string)fp["CooperationStore1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StoreTel1, (string)fp["StoreTel1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.DiscountCondition1, (string)fp["DiscountCondition1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.CooperationStore2, (string)fp["CooperationStore2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StoreTel2, (string)fp["StoreTel2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.DiscountCondition2, (string)fp["DiscountCondition2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.CooperationStore3, (string)fp["CooperationStore3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StoreTel3, (string)fp["StoreTel3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.DiscountCondition3, (string)fp["DiscountCondition3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.CooperationStore4, (string)fp["CooperationStore4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StoreTel4, (string)fp["StoreTel4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.DiscountCondition4, (string)fp["DiscountCondition4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.CooperationStore5, (string)fp["CooperationStore5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.StoreTel5, (string)fp["StoreTel5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.DiscountCondition5, (string)fp["DiscountCondition5"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeAry1, (string)fp["BizTimeAry1"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeAry2, (string)fp["BizTimeAry2"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeAry3, (string)fp["BizTimeAry3"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeAry4, (string)fp["BizTimeAry4"]);
                    allColumnValueDict.Add(ParkingDiffListDataConstant.BizTimeAry5, (string)fp["BizTimeAry5"]);
                    #endregion

                    data.AllColumnValueDict = allColumnValueDict;
                    data.DiffColumnList = allColumnValueDict;

                    // 2次メッシュ単位で駐車場物件データモデルを処理するので、座標が必須である
                    CheckNullOrEmpty(data.DiffColumnList[ParkingDiffListDataConstant.Longitude],
                        ParkingDiffListDataConstant.Longitude,
                        parkingDiffListFile,
                        lineNo);
                    CheckNullOrEmpty(data.DiffColumnList[ParkingDiffListDataConstant.Latitude],
                        ParkingDiffListDataConstant.Latitude,
                        parkingDiffListFile,
                        lineNo);

                    // 駐車場差分項目リスト
                    if (isNew)
                    {
                        // 差分情報：「1:新規」

                        // 入力必須チェック
                        // 漢字名称
                        CheckNullOrEmpty(data.DiffColumnList[ParkingDiffListDataConstant.KanjiName],
                            ParkingDiffListDataConstant.KanjiName,
                            parkingDiffListFile,
                            lineNo);
                        // カナ名称
                        CheckNullOrEmpty(data.DiffColumnList[ParkingDiffListDataConstant.KanaName],
                            ParkingDiffListDataConstant.KanaName,
                            parkingDiffListFile,
                            lineNo);
                        // 都道府県
                        CheckNullOrEmpty(data.DiffColumnList[ParkingDiffListDataConstant.ProvinceName],
                            ParkingDiffListDataConstant.ProvinceName,
                            parkingDiffListFile,
                            lineNo);
                        // 市区群町村
                        CheckNullOrEmpty(data.DiffColumnList[ParkingDiffListDataConstant.AdminName],
                            ParkingDiffListDataConstant.AdminName,
                            parkingDiffListFile,
                            lineNo);
                        // 東経（入口）
                        CheckNullOrEmpty(data.DiffColumnList[ParkingDiffListDataConstant.LongitudeIn],
                            ParkingDiffListDataConstant.LongitudeIn,
                            parkingDiffListFile,
                            lineNo);
                        // 北緯（入口）
                        CheckNullOrEmpty(data.DiffColumnList[ParkingDiffListDataConstant.LatitudeIn],
                            ParkingDiffListDataConstant.LatitudeIn,
                            parkingDiffListFile,
                            lineNo);
                    }
                    else if (isUpdate)
                    {
                        // 差分情報：「2:変更」

                        // 変更内容定義名と外部定義名に整合性チェックを行う
                        IsEqualValueCheck(foreignKeyDictionary, updateFieldList, parkingDiffListFile, mappingDefFile, lineNo);

                        Dictionary<string, string> updateColumnList = new Dictionary<string, string>();
                        foreach (string tempValue in updateFieldList)
                        {
                            string updateColumnName = null;
                            if (tempValue != null)
                            {
                                updateColumnName = tempValue.Trim();
                            }

                            if (string.IsNullOrEmpty(updateColumnName))
                            {
                                continue;
                            }

                            if (data.AllColumnValueDict.ContainsKey(updateColumnName))
                            {
                                string updateColumnValue = data.AllColumnValueDict[updateColumnName];
                                updateColumnList.Add(updateColumnName, updateColumnValue);

                                if (updateColumnName == ParkingDiffListDataConstant.KanjiName ||
                                    updateColumnName == ParkingDiffListDataConstant.KanaName ||
                                    updateColumnName == ParkingDiffListDataConstant.ProvinceName ||
                                    updateColumnName == ParkingDiffListDataConstant.AdminName)
                                {
                                    // 入力必須チェック
                                    // 漢字名称,カナ名称,都道府県,市区郡町村
                                    CheckNullOrEmpty(updateColumnValue, updateColumnName, parkingDiffListFile, lineNo);
                                }
                            }
                        }

                        data.DiffColumnList = updateColumnList;
                    }

                    dataList.Add(data);
                }
            }
            finally
            {
                if (fp != null)
                {
                    fp.Dispose();
                }

                fp = null;

                if (fs != null)
                {
                    fs.Dispose();
                }

                fs = null;
            }

            return dataList;
        }
        #endregion

        #region 必須チェックを行う
        /// <summary>
        /// 必須チェックを行う
        /// </summary>
        /// <param name="fieldValue">フィールド値</param>
        /// <param name="fieldName">フィールド名</param>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="lineNo">行目</param>
        public static void CheckNullOrEmpty(string fieldValue, string fieldName, string filePath, ulong lineNo)
        {
            if (string.IsNullOrEmpty(fieldValue))
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20003032,
                    new object[] { fieldName, filePath, lineNo });
            }
        }
        #endregion

        #region 駐車場差分リストファイルの「更新内容」に整合性チェックを行う
        /// <summary>
        /// 駐車場差分リストファイルの「更新内容」に整合性チェックを行う
        /// </summary>
        /// <param name="foreignKeyDictionary">外部定義名リスト</param>
        /// <param name="updateFieldList">変更内容項目名リスト</param>
        /// <param name="filePath">駐車場差分リストファイルパス</param>
        /// <param name="mappingDefFile">変更項目のマッピング定義ファイルパス</param>
        /// <param name="lineNo">行目</param>
        public static void IsEqualValueCheck(Dictionary<string, string> foreignKeyDictionary,
                                             List<string> updateFieldList,
                                             string filePath,
                                             string mappingDefFile,
                                             ulong lineNo)
        {
            System.Text.StringBuilder keyBuf = new System.Text.StringBuilder();

            foreach (string changeDataName in updateFieldList)
            {
                if (!foreignKeyDictionary.ContainsValue(changeDataName))
                {
                    keyBuf.Append(changeDataName);
                    keyBuf.Append("、");
                }
            }

            if (keyBuf.Length > 0)
            {
                keyBuf.Replace("、", " ", keyBuf.Length - 1, 1);

                // 駐車場差分リストファイルの「更新内容」
                // 項目に定義された項目が変更項目のマッピング定義ファイルに定義されていません
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF20003043,
                    new object[] { filePath, keyBuf, lineNo, mappingDefFile });
            }
        }
        #endregion
    }
}

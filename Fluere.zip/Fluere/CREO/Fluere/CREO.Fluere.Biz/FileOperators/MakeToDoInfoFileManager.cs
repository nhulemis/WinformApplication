﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.BusinessObject;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// ToDoリスト作成用の情報（外国人以外）管理クラス
    /// </summary>
    public class MakeToDoInfoFileManager
    {
        #region ToDoリスト作成用の情報（外国人以外）作成
        /// <summary>
        /// ToDoリスト作成用の情報（外国人以外）ファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="makeToDoInfoList">ToDoリスト作成用の情報（外国人以外）リスト</param>
        public static void WriteMakeToDoInfo(
            string filePath,
            string formatFilePath,
            List<MakeToDoInfoData> makeToDoInfoList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (MakeToDoInfoData makeToDoInfo in makeToDoInfoList)
                {
                    fp.AddRecord();

                    SetCurData(fp, makeToDoInfo);
                }
            }
            catch (Exception ex)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40001031;
                throw new BusinessLogicException(msgId, new string[] { filePath }, ex);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion

        #region ToDoリスト作成用の情報（外国人以外）作成
        /// <summary>
        /// ToDoリスト作成用の情報（外国人以外）ファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="makeToDoInfoList">ToDoリスト作成用の情報（外国人以外）リスト</param>
        public static void ModifyMakeToDoInfo(
            string filePath,
            string formatFilePath,
            List<MakeToDoInfoData> makeToDoInfoList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                fp = new FileParser(fstream, xmlDef);

                foreach (MakeToDoInfoData makeToDoInfo in makeToDoInfoList)
                {
                    fp.AppendRecord();

                    SetCurData(fp, makeToDoInfo);
                }
            }
            catch (Exception ex)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40001031;
                throw new BusinessLogicException(msgId, new string[] { filePath }, ex);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion

        #region  一つデータを設定する
        /// <summary>
        /// 一つデータを設定する
        /// </summary>
        /// <param name="fp">ファイルパーサ</param>
        /// <param name="makeToDoInfo">出典-スクールゾーンデータ</param>
        private static void SetCurData(FileParser fp, MakeToDoInfoData makeToDoInfo)
        {
            // 施設物件拡張のOID
            if (string.IsNullOrEmpty(makeToDoInfo.OID))
            {
                fp["OID"] = string.Empty;
            }
            else
            {
                fp["OID"] = makeToDoInfo.OID;
            }

            // グループID
            if (string.IsNullOrEmpty(makeToDoInfo.GroupID))
            {
                fp["GroupID"] = string.Empty;
            }
            else
            {
                fp["GroupID"] = makeToDoInfo.GroupID;
            }

            // 物件住所（漢字）
            if (string.IsNullOrEmpty(makeToDoInfo.AdrNameKanji))
            {
                fp["AdrNameKanji"] = string.Empty;
            }
            else
            {
                fp["AdrNameKanji"] = makeToDoInfo.AdrNameKanji;
            }

            // 電話番号
            if (string.IsNullOrEmpty(makeToDoInfo.Telno))
            {
                fp["Telno"] = string.Empty;
            }
            else
            {
                fp["Telno"] = makeToDoInfo.Telno;
            }

            // 正式漢字名称
            if (string.IsNullOrEmpty(makeToDoInfo.FormalNameKanji))
            {
                fp["FormalNameKanji"] = string.Empty;
            }
            else
            {
                fp["FormalNameKanji"] = makeToDoInfo.FormalNameKanji;
            }

            // 正式カナ名称
            if (string.IsNullOrEmpty(makeToDoInfo.FormalNameKana))
            {
                fp["FormalNameKana"] = string.Empty;
            }
            else
            {
                fp["FormalNameKana"] = makeToDoInfo.FormalNameKana;
            }

            // 表示漢字名称
            if (string.IsNullOrEmpty(makeToDoInfo.DispNameKanji))
            {
                fp["DispNameKanji"] = string.Empty;
            }
            else
            {
                fp["DispNameKanji"] = makeToDoInfo.DispNameKanji;
            }

            // 分類コード
            if (string.IsNullOrEmpty(makeToDoInfo.TypeCode))
            {
                fp["TypeCode"] = string.Empty;
            }
            else
            {
                fp["TypeCode"] = makeToDoInfo.TypeCode;
            }

            // 絶対座標：東経
            if (string.IsNullOrEmpty(makeToDoInfo.Longitude))
            {
                fp["Longitude"] = string.Empty;
            }
            else
            {
                fp["Longitude"] = makeToDoInfo.Longitude;
            }

            // 絶対座標：北緯
            if (string.IsNullOrEmpty(makeToDoInfo.Latitude))
            {
                fp["Latitude"] = string.Empty;
            }
            else
            {
                fp["Latitude"] = makeToDoInfo.Latitude;
            }

            // ファイルパーサーにアップデート
            fp.Update();
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 大字表記対応リスト
    /// </summary>
    public class OoazMappingFileManager
    {
        /// <summary>
        /// 大字表記対応リストを読み込み
        /// </summary>
        /// <param name="filePath">filePath</param>
        /// <returns>大字表記対応リスト</returns>
        public static List<OoazMappingData> ReadOoazMappingData(string filePath)
        {
            List<OoazMappingData> dataList = new List<OoazMappingData>();

            string formatFilePath = ConfigFileInfo.OoazMappingFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    OoazMappingData ooazMappingData = new OoazMappingData();

                    // アルファベット表記 ＃１
                    ooazMappingData.OazaCodeStr = fp["OazaCodeStr"].ToString();

                    // 10 進表記 ＃２
                    ooazMappingData.OazaCodeNum = fp["OazaCodeNum"].ToString();

                    dataList.Add(ooazMappingData);
                }
            }
            catch (FrameworkException fwEx)
            {
                throw fwEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

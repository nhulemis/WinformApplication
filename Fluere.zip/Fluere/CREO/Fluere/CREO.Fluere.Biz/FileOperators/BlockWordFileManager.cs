﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 使用禁止文字設定ファイル管理
    /// </summary>
    public class BlockWordFileManager
    {
        /// <summary>
        /// 使用禁止文字設定ファイルを読み込み
        /// </summary>
        /// <param name="filePath">使用禁止文字設定ファイルパス</param>
        /// <returns>使用禁止文字設定ファイルデータのリスト</returns>
        public static List<string> ReadBlockWordFile(string filePath)
        {
            List<string> dataList = new List<string>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.BlockWordFileFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    if (fp.RowIndex == 1)
                    {
                        continue;
                    }

                    if ((string)fp["c1"] != string.Empty)
                    {
                        dataList.Add(fp["c1"] as string);
                    }
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

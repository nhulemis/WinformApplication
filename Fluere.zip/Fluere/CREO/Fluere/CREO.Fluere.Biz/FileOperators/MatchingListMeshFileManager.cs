﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// マッチングリストファイル
    /// </summary>
    public class MatchingListMeshFileManager
    {
        #region マッチングリストファイル作成
        /// <summary>
        /// マッチングリストファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="matchingListMeshDataList">マッチングリスト</param>
        public static void WriteMatchingListMeshToDoFile(
            string filePath,
            string formatFilePath,
            List<MatchingListMeshData> matchingListMeshDataList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (
                    MatchingListMeshData matchingListMesh in matchingListMeshDataList)
                {
                    fp.AddRecord();

                    // 交差点目印のOID
                    if (string.IsNullOrEmpty(matchingListMesh.CrsMarkOID))
                    {
                        fp["CrsMarkOID"] = string.Empty;
                    }
                    else
                    {
                        fp["CrsMarkOID"] = matchingListMesh.CrsMarkOID;
                    }

                    // マッチングステータス
                    if (string.IsNullOrEmpty(matchingListMesh.MatchingStatus))
                    {
                        fp["MatchingStatus"] = string.Empty;
                    }
                    else
                    {
                        fp["MatchingStatus"] = matchingListMesh.MatchingStatus;
                    }

                    // 交差点目印整備対象フラグ
                    if (string.IsNullOrEmpty(matchingListMesh.CrsMarkCodeFlg))
                    {
                        fp["CrsMarkCodeFlg"] = string.Empty;
                    }
                    else
                    {
                        fp["CrsMarkCodeFlg"] = matchingListMesh.CrsMarkCodeFlg;
                    }

                    // 目印コード整備対象フラグ
                    if (string.IsNullOrEmpty(matchingListMesh.MarkCodeFlg))
                    {
                        fp["MarkCodeFlg"] = string.Empty;
                    }
                    else
                    {
                        fp["MarkCodeFlg"] = matchingListMesh.MarkCodeFlg;
                    }

                    // メンテナンス日
                    if (string.IsNullOrEmpty(matchingListMesh.MaintenanceDay))
                    {
                        fp["MaintenanceDay"] = string.Empty;
                    }
                    else
                    {
                        fp["MaintenanceDay"] = matchingListMesh.MaintenanceDay;
                    }

                    // 手動マッチングOID
                    if (string.IsNullOrEmpty(matchingListMesh.ManualOID))
                    {
                        fp["ManualOID"] = string.Empty;
                    }
                    else
                    {
                        fp["ManualOID"] = matchingListMesh.ManualOID;
                    }

                    // ファイルパーサーにアップデート
                    fp.Update();
                }
            }
            catch (Exception)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000208;
                throw new BusinessLogicException(msgId, new string[] { filePath });
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion

        #region マッチングリストファイルを読み込み
        /// <summary>
        /// Readメソッド
        /// </summary>
        /// <param name="filePath">filePath</param>
        /// <returns>マッチングリスト</returns>
        public static List<MatchingListMeshData> Read(string filePath)
        {
            List<MatchingListMeshData> dataList = new List<MatchingListMeshData>();

            string formatFilePath = ConfigFileInfo.MatchingListFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // tsv ファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    MatchingListMeshData matchingListMeshData = new MatchingListMeshData();

                    // 交差点目印のOID
                    matchingListMeshData.CrsMarkOID = (string)fp["CrsMarkOID"];

                    // マッチングステータス
                    matchingListMeshData.MatchingStatus = (string)fp["MatchingStatus"];

                    // 交差点目印整備対象フラグ
                    matchingListMeshData.CrsMarkCodeFlg = (string)fp["CrsMarkCodeFlg"];

                    // 目印コード整備対象フラグ
                    matchingListMeshData.MarkCodeFlg = (string)fp["MarkCodeFlg"];

                    // メンテナンス日
                    matchingListMeshData.MaintenanceDay = (string)fp["MaintenanceDay"];

                    // 手動マッチングOID
                    matchingListMeshData.ManualOID = (string)fp["ManualOID"];

                    dataList.Add(matchingListMeshData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }

        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 省略単語設定ファイル
    /// </summary>
    public class AbbreviationSettingFileManager
    {
        /// <summary>
        /// 省略単語設定ファイルの読込
        /// </summary>
        /// <param name="filePath">省略単語設定ファイルパス</param>
        /// <returns>省略単語設定データのリスト</returns>
        public static List<AbbreviationSettingData> ReadAbbreviationSettingFile(string filePath)
        {
            List<AbbreviationSettingData> dataList = new List<AbbreviationSettingData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.AbbreviationSettingFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                int i = 0;

                while (fp.NextRecord())
                {
                    if (i == 0)
                    {
                        i++;
                        continue;
                    }

                    AbbreviationSettingData abbreviationSettingData = new AbbreviationSettingData();

                    // 省略前単語
                    abbreviationSettingData.AbbreviationBeforeWord = fp["AbbreviationBeforeWord"] as string;

                    // 省略語単語
                    abbreviationSettingData.AbbreviationWord = fp["AbbreviationWord"] as string;

                    dataList.Add(abbreviationSettingData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

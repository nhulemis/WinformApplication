﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// ファイル管理共通クラス
    /// </summary>
    public class CommonFileManager
    {
        /// <summary>
        /// レコード配列から、インデックスを指定、フィールド値を取得する
        /// </summary>
        /// <param name="record">レコード配列</param>
        /// <param name="fieldIndex">インデックス</param>
        /// <param name="bEffective">有効値かどうか</param>
        /// <returns>フィールド値</returns>
        protected static string GetFieldStringValue(object[] record, int fieldIndex, ref bool bEffective)
        {
            string fieldValue = default(string);

            if (record.Length > fieldIndex && null != record[fieldIndex])
            {
                fieldValue = record[fieldIndex].ToString();
                bEffective = true;
            }

            return fieldValue;
        }

        /// <summary>
        /// レコード配列から、インデックスを指定、フィールド値を取得する
        /// </summary>
        /// <param name="record">レコード配列</param>
        /// <param name="fieldIndex">インデックス</param>
        /// <param name="bEffective">有効値かどうか</param>
        /// <returns>フィールド値</returns>
        protected static long GetFieldLongValue(object[] record, int fieldIndex, ref bool bEffective)
        {
            long fieldValue = default(long);

            if (record.Length > fieldIndex && null != record[fieldIndex])
            {
                string strValue = record[fieldIndex].ToString().Trim();
                if (strValue.Length > 0)
                {
                    fieldValue = long.Parse(strValue);
                    bEffective = true;
                }
            }

            return fieldValue;
        }

        /// <summary>
        /// レコード配列から、インデックスを指定、フィールド値を取得する
        /// </summary>
        /// <param name="record">レコード配列</param>
        /// <param name="fieldIndex">インデックス</param>
        /// <param name="bEffective">有効値かどうか</param>
        /// <returns>フィールド値</returns>
        protected static ulong GetFieldULongValue(object[] record, int fieldIndex, ref bool bEffective)
        {
            ulong fieldValue = default(ulong);

            if (record.Length > fieldIndex && null != record[fieldIndex])
            {
                string strValue = record[fieldIndex].ToString().Trim();
                if (strValue.Length > 0)
                {
                    fieldValue = ulong.Parse(strValue);
                    bEffective = true;
                }
            }

            return fieldValue;
        }

        /// <summary>
        /// レコード配列から、インデックスを指定、フィールド値を取得する
        /// </summary>
        /// <param name="record">レコード配列</param>
        /// <param name="fieldIndex">インデックス</param>
        /// <param name="bEffective">有効値かどうか</param>
        /// <returns>フィールド値</returns>
        protected static int GetFieldIntValue(object[] record, int fieldIndex, ref bool bEffective)
        {
            int fieldValue = default(int);

            if (record.Length > fieldIndex && null != record[fieldIndex])
            {
                string strValue = record[fieldIndex].ToString().Trim();
                if (strValue.Length > 0)
                {
                    fieldValue = int.Parse(strValue);
                    bEffective = true;
                }
            }

            return fieldValue;
        }

        /// <summary>
        /// レコード配列から、インデックスを指定、フィールド値を取得する
        /// </summary>
        /// <param name="record">レコード配列</param>
        /// <param name="fieldIndex">インデックス</param>
        /// <param name="bEffective">有効値かどうか</param>
        /// <returns>フィールド値</returns>
        protected static uint GetFieldUIntValue(object[] record, int fieldIndex, ref bool bEffective)
        {
            uint fieldValue = default(uint);

            if (record.Length > fieldIndex && null != record[fieldIndex])
            {
                string strValue = record[fieldIndex].ToString().Trim();
                if (strValue.Length > 0)
                {
                    fieldValue = uint.Parse(strValue);
                    bEffective = true;
                }
            }

            return fieldValue;
        }

        /// <summary>
        /// レコード配列から、インデックスを指定、フィールド値を取得する
        /// </summary>
        /// <param name="record">レコード配列</param>
        /// <param name="fieldIndex">インデックス</param>
        /// <param name="bEffective">有効値かどうか</param>
        /// <returns>フィールド値</returns>
        protected static short GetFieldShortValue(object[] record, int fieldIndex, ref bool bEffective)
        {
            short fieldValue = default(short);

            if (record.Length > fieldIndex && null != record[fieldIndex])
            {
                string strValue = record[fieldIndex].ToString().Trim();
                if (strValue.Length > 0)
                {
                    fieldValue = short.Parse(strValue);
                    bEffective = true;
                }
            }

            return fieldValue;
        }

        /// <summary>
        /// レコード配列から、インデックスを指定、フィールド値を取得する
        /// </summary>
        /// <param name="record">レコード配列</param>
        /// <param name="fieldIndex">インデックス</param>
        /// <param name="bEffective">有効値かどうか</param>
        /// <returns>フィールド値</returns>
        protected static ushort GetFieldUShortValue(object[] record, int fieldIndex, ref bool bEffective)
        {
            ushort fieldValue = default(ushort);

            if (record.Length > fieldIndex && null != record[fieldIndex])
            {
                string strValue = record[fieldIndex].ToString().Trim();
                if (strValue.Length > 0)
                {
                    fieldValue = ushort.Parse(strValue);
                    bEffective = true;
                }
            }

            return fieldValue;
        }

        /// <summary>
        /// レコード配列から、インデックスを指定、フィールド値を取得する
        /// </summary>
        /// <param name="record">レコード配列</param>
        /// <param name="fieldIndex">インデックス</param>
        /// <param name="bEffective">有効値かどうか</param>
        /// <returns>フィールド値</returns>
        protected static byte GetFieldByteValue(object[] record, int fieldIndex, ref bool bEffective)
        {
            byte fieldValue = default(byte);

            if (record.Length > fieldIndex && null != record[fieldIndex])
            {
                string strValue = record[fieldIndex].ToString().Trim();
                if (strValue.Length > 0)
                {
                    fieldValue = byte.Parse(strValue);
                    bEffective = true;
                }
            }

            return fieldValue;
        }
    }
}

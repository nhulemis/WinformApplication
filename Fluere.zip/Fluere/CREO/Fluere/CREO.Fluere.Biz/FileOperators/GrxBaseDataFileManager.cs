﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// GRXデータファイルを読み込み
    /// </summary>
    public class GrxBaseDataFileManager
    {
        /// <summary>
        /// GRX基本データファイルを読み込み
        /// </summary>
        /// <param name="filePath">GRX基本データファイルパス</param>
        /// <returns>GRXデータファイルリスト</returns>
        public static List<GrxBaseData> ReadGrxBaseDataFile(string filePath)
        {
            List<GrxBaseData> dataList = new List<GrxBaseData>();

            string formatFilePath = ConfigFileInfo.GRXDataFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);
                int groupNum = 0;
                int rowIndex = 0;
                GrxBaseData grxBaseData = new GrxBaseData();

                while (fp.NextRecord())
                {
                    if (rowIndex == 1)
                    {
                        // GRX基本データファイル･発行年月日
                        string value = fp["Col3"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxBaseData.PublicationDate = 0;
                        }
                        else
                        {
                            grxBaseData.PublicationDate = ulong.Parse(value);
                        }

                        // GRX基本データファイル･市区町村コード
                        value = fp["Col4"].ToString();
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxBaseData.MunicipalityCode = string.Empty;
                        }
                        else
                        {
                            grxBaseData.MunicipalityCode = value;
                        }

                        // GRX基本データファイル･分冊コード
                        grxBaseData.PartCode = fp["Col5"] as string;
                    }
                    else if (rowIndex == 2)
                    {
                        // GRX基本データファイル･住宅地図名称
                        grxBaseData.HousingMapName = fp["Col1"] as string;
                    }
                    else if (rowIndex == 3)
                    {
                        // GRX基本データファイル･住宅地図の幅
                        string value = fp["Col2"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxBaseData.HousingMapWidth = 0;
                        }
                        else
                        {
                            grxBaseData.HousingMapWidth = double.Parse(value);
                        }

                        // GRX基本データファイル･住宅地図の高さ
                        value = fp["Col3"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxBaseData.HousingMapHight = 0;
                        }
                        else
                        {
                            grxBaseData.HousingMapHight = double.Parse(value);
                        }
                    }
                    else if (rowIndex == 4)
                    {
                        // グループ数
                        string value = fp["Col1"] as string;

                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxBaseData.GroupNum = 0;
                        }
                        else
                        {
                            grxBaseData.GroupNum = int.Parse(value);
                        }

                        groupNum = grxBaseData.GroupNum;
                    }

                    if (grxBaseData.GroupNum != 0)
                    {
                        List<GrxGroupData> grxGroupDataList = new List<GrxGroupData>();
                        grxGroupDataList = ReadGrxGroupDataFile(filePath, groupNum);

                        grxBaseData.GrxGroupDataList = grxGroupDataList;
                        break;
                    }

                    rowIndex++;
                }

                dataList.Add(grxBaseData);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }

        /// <summary>
        /// GRXセルデータファイルを読み込み
        /// </summary>
        /// <param name="filePath">GRXセルファイルパス</param>
        /// <param name="groupNum">GRXセルファイルのセルデータの件数</param>
        /// <returns>GRXセルデータファイル</returns>
        public static List<GrxGroupData> ReadGrxGroupDataFile(string filePath, int groupNum)
        {
            List<GrxGroupData> dataList = new List<GrxGroupData>();
            string formatFilePath = ConfigFileInfo.GRXDataFile;

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                uint groupStartIndex = 6;

                while (fp.NextRecord())
                {
                    GrxGroupData grxGroupData = new GrxGroupData();

                    grxGroupData.InputGrxFolderName = Path.GetDirectoryName(filePath);

                    if (fp.RowIndex == groupStartIndex + 7)
                    {
                        string value = fp["Col1"] as string;

                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxGroupData.CellNum = 0;
                        }
                        else
                        {
                            grxGroupData.CellNum = int.Parse(value);
                        }

                        if (0 != grxGroupData.CellNum)
                        {
                            uint cellIndex = groupStartIndex + 8;

                            grxGroupData.GrxCellDataList = ReadGrxCellDataList(fp, grxGroupData.CellNum, cellIndex);

                            groupStartIndex = fp.RowIndex + 1;
                        }
                        else
                        {
                            groupStartIndex = fp.RowIndex + 8 + 1;
                        }

                        dataList.Add(grxGroupData);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }

        /// <summary>
        /// GRXセルデータファイルを読み込み
        /// </summary>
        /// <param name="fp">GRXセルファイルパス</param>
        /// <param name="cellCount">GRXセルファイルのセルデータの件数</param>
        /// <param name="cellStartIndex">セルデータ開始番号</param>
        /// <returns>GRXセルデータファイル</returns>
        public static List<GrxCellData> ReadGrxCellDataList(FileParser fp, int cellCount, uint cellStartIndex)
        {
            List<GrxCellData> grxCellDataList = new List<GrxCellData>();

            uint cellIndex = cellStartIndex;

            for (int i = 0; i < cellCount; i++)
            {
                GrxCellData grxCellData = new GrxCellData();

                while (fp.NextRecord())
                {
                    if (fp.RowIndex == cellIndex + 2)
                    {
                        // 住宅図データファイルID
                        grxCellData.HousingMapFileID = fp["Col1"] as string;
                    }

                    if (fp.RowIndex == cellIndex + 3)
                    {
                        // セル位置情報 左
                        string value = fp["Col1"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.GeometryBaseLeft = 0;
                        }
                        else
                        {
                            grxCellData.GeometryBaseLeft = int.Parse(value);
                        }

                        // セル位置情報 下
                        value = fp["Col2"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.GeometryBaseDown = 0;
                        }
                        else
                        {
                            grxCellData.GeometryBaseDown = int.Parse(value);
                        }

                        // セル位置情報 右
                        value = fp["Col3"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.GeometryBaseRight = 0;
                        }
                        else
                        {
                            grxCellData.GeometryBaseRight = int.Parse(value);
                        }

                        // セル位置情報 上
                        value = fp["Col4"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.GeometryBaseUp = 0;
                        }
                        else
                        {
                            grxCellData.GeometryBaseUp = int.Parse(value);
                        }
                    }

                    if (fp.RowIndex == cellIndex + 6)
                    {
                        // ビットマップの４隅の基準点左下のX
                        string value = fp["Col2"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.BitMapLeftDownX = 0;
                        }
                        else
                        {
                            grxCellData.BitMapLeftDownX = double.Parse(value);
                        }

                        // ビットマップの４隅の基準点左下のY
                        value = fp["Col3"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.BitMapLeftDownY = 0;
                        }
                        else
                        {
                            grxCellData.BitMapLeftDownY = double.Parse(value);
                        }
                    }

                    if (fp.RowIndex == cellIndex + 7)
                    {
                        // ビットマップの４隅の基準点左上のX
                        string value = fp["Col2"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.BitMapLeftUpX = 0;
                        }
                        else
                        {
                            grxCellData.BitMapLeftUpX = double.Parse(value);
                        }

                        // ビットマップの４隅の基準点左上のY
                        value = fp["Col3"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.BitMapLeftUpY = 0;
                        }
                        else
                        {
                            grxCellData.BitMapLeftUpY = double.Parse(value);
                        }
                    }

                    if (fp.RowIndex == cellIndex + 8)
                    {
                        // ビットマップの４隅の基準点右上のX
                        string value = fp["Col2"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.BitMapRightUpX = 0;
                        }
                        else
                        {
                            grxCellData.BitMapRightUpX = double.Parse(value);
                        }

                        // ビットマップの４隅の基準点右上のY
                        value = fp["Col3"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.BitMapRightUpY = 0;
                        }
                        else
                        {
                            grxCellData.BitMapRightUpY = double.Parse(value);
                        }
                    }

                    if (fp.RowIndex == cellIndex + 9)
                    {
                        // ビットマップの４隅の基準点右下のX
                        string value = fp["Col2"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.BitMapRightDownX = 0;
                        }
                        else
                        {
                            grxCellData.BitMapRightDownX = double.Parse(value);
                        }

                        // ビットマップの４隅の基準点右下のY
                        value = fp["Col3"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.BitMapRightDownY = 0;
                        }
                        else
                        {
                            grxCellData.BitMapRightDownY = double.Parse(value);
                        }
                    }

                    if (fp.RowIndex == cellIndex + 10)
                    {
                        // 区分図基準点数
                        string value = fp["Col1"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxCellData.TypeMapNum = 0;
                        }
                        else
                        {
                            grxCellData.TypeMapNum = int.Parse(value);
                        }

                        break;
                    }
                }

                if (0 < grxCellData.TypeMapNum)
                {
                    uint typeStartIndex = cellIndex + 11;

                    List<GrxTypeMapData> grxTypeMapDataList =
                        ReadGrxTypeMapDataList(fp, typeStartIndex, grxCellData.TypeMapNum, grxCellData);

                    grxCellData.GrxTypeDataList = grxTypeMapDataList;
                }

                grxCellDataList.Add(grxCellData);

                cellIndex = cellIndex + 10 + (uint)(4 * grxCellData.TypeMapNum) + 1;
            }

            return grxCellDataList;
        }

        /// <summary>
        /// GRXセルデータファイルを読み込み
        /// </summary>
        /// <param name="fp">ファイルパーサー</param>
        /// <param name="typeStartIndex">開始番号</param>
        /// <param name="typeCount">タイプカウント</param>
        /// <param name="grxCellData">GRXセルデータ</param>
        /// <returns>GrxTypeMapDataリスト</returns>
        public static List<GrxTypeMapData> ReadGrxTypeMapDataList(FileParser fp, uint typeStartIndex, int typeCount, GrxCellData grxCellData)
        {
            List<GrxTypeMapData> grxTypeMapDataList = new List<GrxTypeMapData>();

            uint typeIndex = typeStartIndex;

            for (int i = 0; i < typeCount; i++)
            {
                GrxTypeMapData grxTypeMapData = new GrxTypeMapData();

                while (fp.NextRecord())
                {
                    if (fp.RowIndex == typeIndex + 2)
                    {
                        // ノーマライズ座標：X
                        string value = fp["Col1"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxTypeMapData.LongitudeCoordinates = 0;
                        }
                        else
                        {
                            grxTypeMapData.LongitudeCoordinates = ulong.Parse(value);
                        }

                        // ノーマライズ座標：Y
                        value = fp["Col2"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxTypeMapData.NorthLatitude = 0;
                        }
                        else
                        {
                            grxTypeMapData.NorthLatitude = ulong.Parse(value);
                        }
                    }

                    if (fp.RowIndex == typeIndex + 3)
                    {
                        // ノーマライズ座標：X
                        string value = fp["Col2"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxTypeMapData.NormalMatrixX = 0;
                        }
                        else
                        {
                            grxTypeMapData.NormalMatrixX = double.Parse(value);
                        }

                        // ノーマライズ座標：Y
                        value = fp["Col3"] as string;
                        if (string.IsNullOrWhiteSpace(value))
                        {
                            grxTypeMapData.NormalMatrixY = 0;
                        }
                        else
                        {
                            grxTypeMapData.NormalMatrixY = double.Parse(value);
                        }

                        // セル
                        grxTypeMapData.OwnerCell = grxCellData;
                        break;
                    }
                }

                typeIndex = typeIndex + 4;

                grxTypeMapDataList.Add(grxTypeMapData);
            }

            return grxTypeMapDataList;
        }
    }
}

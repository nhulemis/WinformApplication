﻿using System.Collections.Generic;
using System.IO;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// アンマッチ追跡市区町村リストファイルの読み込み
    /// </summary>
    public class UnmatchAdministrativeCodeFileManager
    {
        /// <summary>
        /// アンマッチ追跡市区町村リストファイルの読み込み
        /// </summary>
        /// <param name="strPath">アンマッチ追跡市区町村リストファイルのパス</param>
        /// <returns>アンマッチ追跡市区町村リストファイルリスト</returns>
        public static List<UnmatchAdministrativeCodeData> ReadUnmatchAdministrativeCodeFile(string strPath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(strPath))
            {
                throw new FileNotFoundException();
            }

            // アンマッチ追跡市区町村リストファイルデータ初期化
            List<UnmatchAdministrativeCodeData> lstUnmatchAdministrativeCodeData = new List<UnmatchAdministrativeCodeData>();

            // テキストファイル読込む
            string content = FileUtil.ReadFile(strPath);

            // 行データの分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // コードリスト作成
            foreach (string currentLine in stringLines)
            {
                string[] strData = StringUtil.SpiltDataByTab(currentLine);

                if (strData.Length > 0)
                {
                    UnmatchAdministrativeCodeData unmatchAdministrativeCodeData = new UnmatchAdministrativeCodeData();

                    // 市区町村コード
                    unmatchAdministrativeCodeData.AdministrativeCode = strData[0];

                    // 備考
                    unmatchAdministrativeCodeData.Comment = strData[1];

                    lstUnmatchAdministrativeCodeData.Add(unmatchAdministrativeCodeData);
                }
            }

            return lstUnmatchAdministrativeCodeData;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 文字種別の共通ファイルを読み込み
    /// </summary>
    public class TypTxtCommonFileManager
    {
        /// <summary>
        /// 文字種別の共通ファイルを読み込み
        /// </summary>
        /// <param name="filePath">文字種別の共通ファイルパス</param>
        /// <returns>文字種別リスト</returns>
        public static List<int> ReadTypTxtDataFile(string filePath)
        {
            List<int> dataList = new List<int>();

            string formatFilePath = ConfigFileInfo.TypTxtCommonFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    // 文字種別
                    dataList.Add((int)fp["TypTxt"]);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 差分住所データファイルの読込
    /// </summary>
    public class DiffAdrDataListInputFileManager
    {
        /// <summary>
        /// Readメソッド
        /// </summary>
        /// <param name="filePath">filePath</param>
        /// <returns>差分住所データ</returns>
        public static List<DiffAdrDataListInputListData> Read(string filePath)
        {
            List<DiffAdrDataListInputListData> dataList = new List<DiffAdrDataListInputListData>();

            string formatFilePath = ConfigFileInfo.DiffAdrFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // lst ファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    DiffAdrDataListInputListData diffAdrDataListInputListData = new DiffAdrDataListInputListData();

                    // 差分情報（削除、追加、更新）
                    diffAdrDataListInputListData.DiffType = StringToInt(fp["DiffType"]);

                    // 都道府県コード
                    diffAdrDataListInputListData.ProvinceCode = StringToInt(fp["ProvinceCode"]);

                    // 市区町村コード
                    diffAdrDataListInputListData.CityCode = StringToInt(fp["CityCode"]);

                    // 大字コード(4桁の数値)
                    diffAdrDataListInputListData.OazaCode = StringToInt(fp["OazaCode"]);

                    // 小字コード
                    diffAdrDataListInputListData.SectionCode = StringToInt(fp["SectionCode"]);

                    // 街区コード
                    diffAdrDataListInputListData.GaikuCode = StringToInt(fp["GaikuCode"]);

                    // 都道府県名称
                    diffAdrDataListInputListData.ProvinceName = (string)fp["ProvinceName"];

                    // 市区町村名称
                    diffAdrDataListInputListData.CityName = (string)fp["CityName"];

                    // 大字・町名称
                    diffAdrDataListInputListData.OazaName = (string)fp["OazaName"];

                    // 字・丁目名称
                    diffAdrDataListInputListData.SectionName = (string)fp["SectionName"];

                    // 市区町村名称読み
                    diffAdrDataListInputListData.CityNameKana = (string)fp["CityNameKana"];

                    // 大字・町名称読み
                    diffAdrDataListInputListData.OazaNameKana = (string)fp["OazaNameKana"];

                    // 字・丁目名称読み
                    diffAdrDataListInputListData.SectionNameKana = (string)fp["SectionNameKana"];

                    // 地番・住居番号
                    diffAdrDataListInputListData.LotOrHouseNo = StringToInt(fp["LotOrHouseNo"]);

                    // 枝番
                    diffAdrDataListInputListData.SuffixNo = StringToInt(fp["SuffixNo"]);

                    // 住所座標　経度
                    diffAdrDataListInputListData.Longitude = StringToLong(fp["Longitude"]);

                    // 住所座標　緯度
                    diffAdrDataListInputListData.Latitude = StringToLong(fp["Latitude"]);

                    dataList.Add(diffAdrDataListInputListData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }

        /// <summary>
        /// string型をint型に変換
        /// </summary>
        /// <param name="value">変換前のオブジェクト</param>
        /// <returns>int型の値</returns>
        private static int StringToInt(object value)
        {
            if (value == null || value.ToString() == string.Empty)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt32(value);
            }
        }

        /// <summary>
        /// string型をlong型に変換
        /// </summary>
        /// <param name="value">変換前のオブジェクト</param>
        /// <returns>long型の値</returns>
        private static long StringToLong(object value)
        {
            if (value == null || value.ToString() == string.Empty)
            {
                return 0;
            }
            else
            {
                return Convert.ToInt64(value);
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 複数名称一括変換設定ファイル管理
    /// </summary>
    public class File1vsNManager
    {
        /// <summary>
        /// 複数名称一括変換設定ファイルの読込
        /// </summary>
        /// <param name="filePath">複数名称一括変換設定ファイルパス</param>
        /// <returns>複数名称一括変換設定ファイルデータのリスト</returns>
        public static List<File1vsNData> Read1vsNFile(string filePath)
        {
            List<File1vsNData> dataList = new List<File1vsNData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.OneVsNFileFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    if (fp.RowIndex == 1)
                    {
                        continue;
                    }

                    File1vsNData data = new File1vsNData();

                    // 英字名称
                    data.EnName = fp["EnName"] as string;

                    if ((string)fp["TxtType"] != string.Empty)
                    {
                        // 文字種別コード
                        data.TxtType = Convert.ToUInt16(fp["TxtType"]);
                    }

                    // 漢字名称
                    data.KanjiName = fp["KanjiName"] as string;

                    // カナ名称
                    data.KanaName = fp["KanaName"] as string;

                    dataList.Add(data);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

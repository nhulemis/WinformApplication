﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 英字変換分類一覧設定ファイル管理
    /// </summary>
    public class EnConvertTypeFileManager
    {
        /// <summary>
        /// 英字変換分類一覧設定ファイルの読込
        /// </summary>
        /// <param name="filePath">英字変換分類一覧設定ファイルパス</param>
        /// <returns>英字変換分類一覧設定ファイルデータのリスト</returns>
        public static List<EnConvertTypeData> ReadEnConvertTypeFile(string filePath)
        {
            List<EnConvertTypeData> dataList = new List<EnConvertTypeData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.EnConvertTypeFileFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    if (fp.RowIndex <= 2)
                    {
                        continue;
                    }

                    EnConvertTypeData data = new EnConvertTypeData();

                    // 番号
                    data.No = fp["No"] as string;

                    // 納品対象
                    data.DeliverObject = fp["DeliverObject"] as string;

                    if ((string)fp["TxtType"] != string.Empty)
                    {
                        // 文字種別コード
                        data.TxtType = Convert.ToUInt16(fp["TxtType"]);
                    }

                    // 文字種別名称
                    data.TypName = fp["TypName"] as string;

                    if ((string)fp["ConvertPattern_1"] != string.Empty)
                    {
                        // 変換パターン1
                        data.ConvertPattern_1 = fp["ConvertPattern_1"] as string;
                    }

                    if ((string)fp["ConvertPattern_2"] != string.Empty)
                    {
                        // 変換パターン2 
                        data.ConvertPattern_2 = fp["ConvertPattern_2"] as string;
                    }

                    if ((string)fp["ConvertPattern_3"] != string.Empty)
                    {
                        // 変換パターン3
                        data.ConvertPattern_3 = fp["ConvertPattern_3"] as string;
                    }

                    if ((string)fp["ConvertPattern_4"] != string.Empty)
                    {
                        // 変換パターン4
                        data.ConvertPattern_4 = fp["ConvertPattern_4"] as string;
                    }

                    if ((string)fp["ConvertPattern_5"] != string.Empty)
                    {
                        // 変換パターン5
                        data.ConvertPattern_5 = fp["ConvertPattern_5"] as string;
                    }

                    if ((string)fp["ConvertPattern_6"] != string.Empty)
                    {
                        // 変換パターン6
                        data.ConvertPattern_6 = fp["ConvertPattern_6"] as string;
                    }

                    if ((string)fp["ConvertPattern_7"] != string.Empty)
                    {
                        // 変換パターン7
                        data.ConvertPattern_7 = fp["ConvertPattern_7"] as string;
                    }

                    if ((string)fp["ConvertPattern_8"] != string.Empty)
                    {
                        // 変換パターン8
                        data.ConvertPattern_8 = fp["ConvertPattern_8"] as string;
                    }

                    if ((string)fp["ForceConvertPattern"] != string.Empty)
                    {
                        // 変換パターン強制
                        data.ForceConvertPattern = fp["ForceConvertPattern"] as string;
                    }

                    if ((string)fp["ConvertParameter_1"] != string.Empty)
                    {
                        // 変換パラメータ①
                        data.ConvertParameter_1 = fp["ConvertParameter_1"] as string;
                    }

                    if ((string)fp["ConvertParameter_2"] != string.Empty)
                    {
                        // 変換パラメータ②
                        data.ConvertParameter_2 = fp["ConvertParameter_2"] as string;
                    }

                    if ((string)fp["ConvertParameter_3"] != string.Empty)
                    {
                        // 変換パラメータ③
                        data.ConvertParameter_3 = fp["ConvertParameter_3"] as string;
                    }

                    if ((string)fp["ConvertParameter_4"] != string.Empty)
                    {
                        // 変換パラメータ④
                        data.ConvertParameter_4 = fp["ConvertParameter_4"] as string;
                    }

                    if ((string)fp["ConvertParameter_5"] != string.Empty)
                    {
                        // 変換パラメータ⑤
                        data.ConvertParameter_5 = fp["ConvertParameter_5"] as string;
                    }

                    if ((string)fp["ConvertParameter_6"] != string.Empty)
                    {
                        // 変換パラメータ⑥
                        data.ConvertParameter_6 = fp["ConvertParameter_6"] as string;
                    }

                    dataList.Add(data);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

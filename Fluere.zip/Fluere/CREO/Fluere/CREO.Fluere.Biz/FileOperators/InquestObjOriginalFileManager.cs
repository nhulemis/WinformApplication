﻿// -----------------------------------------------------------------------
// <copyright file="InquestObjOriginalFileManager.cs" company="Hewlett-Packard Company">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.BusinessObject;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 目印調査対象原稿ファイル管理クラス
    /// </summary>
    public class InquestObjOriginalFileManager
    {
        #region 目印調査対象原稿ファイル作成
        /// <summary>
        /// 目印調査対象原稿ファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="inquestObjectOriginalList">目印調査対象原稿リスト</param>
        public static void WriteMarkInqueryObjToDoFile(
            string filePath,
            string formatFilePath,
            List<InquestObjectOriginalData> inquestObjectOriginalList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (
                    InquestObjectOriginalData inquestObjectOriginal in inquestObjectOriginalList)
                {
                    fp.AddRecord();

                    // タウン物件OID
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Oid))
                    {
                        fp["oid"] = string.Empty;
                    }
                    else
                    {
                        fp["oid"] = inquestObjectOriginal.Oid;
                    }

                    // 行政JISコード
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Adrc))
                    {
                        fp["adrc"] = string.Empty;
                    }
                    else
                    {
                        fp["adrc"] = inquestObjectOriginal.Adrc;
                    }

                    // 電話番号
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Tn))
                    {
                        fp["tn"] = string.Empty;
                    }
                    else
                    {
                        fp["tn"] = inquestObjectOriginal.Tn;
                    }

                    // NTT分類コード
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Nc))
                    {
                        fp["nc"] = string.Empty;
                    }
                    else
                    {
                        fp["nc"] = inquestObjectOriginal.Nc;
                    }

                    // NTT分類名
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Ncn))
                    {
                        fp["ncn"] = string.Empty;
                    }
                    else
                    {
                        fp["ncn"] = inquestObjectOriginal.Ncn;
                    }

                    // 目印コード
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Mnf))
                    {
                        fp["mnf"] = string.Empty;
                    }
                    else
                    {
                        fp["mnf"] = inquestObjectOriginal.Mnf;
                    }

                    // 目印名称
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Ckj))
                    {
                        fp["ckj"] = string.Empty;
                    }
                    else
                    {
                        fp["ckj"] = inquestObjectOriginal.Ckj;
                    }

                    // 漢字掲載名
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Kj))
                    {
                        fp["kj"] = string.Empty;
                    }
                    else
                    {
                        fp["kj"] = inquestObjectOriginal.Kj;
                    }

                    // カナ掲載名
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Kn))
                    {
                        fp["kn"] = string.Empty;
                    }
                    else
                    {
                        fp["kn"] = inquestObjectOriginal.Kn;
                    }

                    // 住所名称
                    if (string.IsNullOrEmpty(inquestObjectOriginal.An))
                    {
                        fp["an"] = string.Empty;
                    }
                    else
                    {
                        fp["an"] = inquestObjectOriginal.An;
                    }

                    // 設定可否コード
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Cd))
                    {
                        fp["cd"] = string.Empty;
                    }
                    else
                    {
                        fp["cd"] = inquestObjectOriginal.Cd;
                    }

                    // 備考
                    if (string.IsNullOrEmpty(inquestObjectOriginal.Bk))
                    {
                        fp["cd"] = string.Empty;
                    }
                    else
                    {
                        fp["bk"] = inquestObjectOriginal.Bk;
                    }

                    // ファイルパーサーにアップデート
                    fp.Update();
                }
            }
            catch (Exception)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40001002;
                throw new BusinessLogicException(msgId, new string[] { filePath });
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion

        #region 目印調査対象原稿ファイルを読み込み
        /// <summary>
        /// 目印調査対象原稿ファイルを読み込み
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <returns>目印調査対象原稿ファイル</returns>
        public static List<InquestObjectOriginalData> ReadInquestObjectOriginalData(
            string filePath, string formatFilePath)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            List<InquestObjectOriginalData> inquestObjectOriginalList = new List<InquestObjectOriginalData>();

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    InquestObjectOriginalData inquestObjectOriginal = new InquestObjectOriginalData();

                    // タウン物件OID
                    inquestObjectOriginal.Oid = fp["oid"].ToString();

                    // 行政JISコード
                    inquestObjectOriginal.Adrc = fp["adrc"].ToString();

                    // 電話番号
                    inquestObjectOriginal.Tn = fp["tn"].ToString();

                    // NTT分類コード
                    inquestObjectOriginal.Nc = fp["nc"].ToString();

                    // NTT分類名
                    inquestObjectOriginal.Ncn = fp["ncn"].ToString();

                    // 目印コード
                    inquestObjectOriginal.Mnf = fp["mnf"].ToString();

                    // 目印名称
                    inquestObjectOriginal.Ckj = fp["ckj"].ToString();

                    // 漢字掲載名
                    inquestObjectOriginal.Kj = fp["kj"].ToString();

                    // カナ掲載名
                    inquestObjectOriginal.Kn = fp["kn"].ToString();

                    // 住所名称
                    inquestObjectOriginal.An = fp["an"].ToString();

                    // 設定可否コード
                    inquestObjectOriginal.Cd = fp["cd"].ToString();

                    // 備考
                    inquestObjectOriginal.Bk = fp["bk"].ToString();

                    inquestObjectOriginalList.Add(inquestObjectOriginal);
                }
            }
            catch (Exception)
            {
                // 目印調査対象原稿ファイルがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000095;
                string[] parameters = new string[] { filePath };

                throw new BusinessLogicException(msgId, parameters);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return inquestObjectOriginalList;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// アンマッチ追跡対象抽出条件設定ファイル読み込み
    /// </summary>
    public class UnmatchExtractConditionFileManager
    {
        /// <summary>
        /// データ識別番号
        /// </summary>
        private enum DataCol
        {
            /// <summary>
            /// マッチングレベル
            /// </summary>
            mlv,

            /// <summary>
            /// 電話調査フラグ
            /// </summary>
            eflg,

            /// <summary>
            /// 漢字掲載名文字数
            /// </summary>
            kj_len,

            /// <summary>
            /// 漢字掲載名
            /// </summary>
            kj,

            /// <summary>
            /// カナ掲載名
            /// </summary>
            kn,

            /// <summary>
            /// NTT分類コード
            /// </summary>
            nc,

            /// <summary>
            /// 目印コード
            /// </summary>
            mnf,

            /// <summary>
            /// 住所コード(都道府県)
            /// </summary>
            a0,

            /// <summary>
            /// 住所コード(市区町村)
            /// </summary>
            a1,

            /// <summary>
            /// 住所コード(大字)
            /// </summary>
            a2,

            /// <summary>
            /// 住所コード(小字)
            /// </summary>
            a3,

            /// <summary>
            /// 街区番号、部屋番号
            /// </summary>
            an4,

            /// <summary>
            /// 方書
            /// </summary>
            co,

            /// <summary>
            /// 東経
            /// </summary>
            e,

            /// <summary>
            /// 北緯
            /// </summary>
            n
        }

        /// <summary>
        /// AND/OR設定
        /// </summary>
        private enum AndOr
        {
            /// <summary>
            /// AND
            /// </summary>
            AND,

            /// <summary>
            /// OR
            /// </summary>
            OR
        }

        #region アンマッチ追跡対象抽出条件設定ファイル読み込み
        /// <summary>
        /// アンマッチ追跡対象抽出条件設定ファイル読み込み
        /// </summary>
        /// <param name="conditionFilePath">アンマッチ追跡対象抽出条件設定ファイルパス</param>
        /// <returns>アンマッチ追跡対象抽出条件設定ファイルデータ</returns>
        public static UnmatchExtractConditionListData ReadUnmatchConditionFile(string conditionFilePath)
        {
            // セクションフラグ
            string strSectionFlag = string.Empty;

            // AND/OR設定で「-」分の判断用
            bool blStart = true;

            // メッセージID
            string msgId = UF_Fluere_MsgId.MSGID_UF40002075;

            // ファイルが存在するか確認
            if (!System.IO.File.Exists(conditionFilePath))
            {
                throw new FileNotFoundException();
            }

            // アンマッチ追跡対象抽出条件設定ファイルデータ初期化
            UnmatchExtractConditionListData conditionListData = new UnmatchExtractConditionListData();

            // テキストファイル読込む
            string content = FileUtil.ReadFile(conditionFilePath);

            // 条件設定分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // 行番号
            int intIndex = 0;

            // コードリスト作成
            foreach (string currentLine in stringLines)
            {
                // 行番号
                intIndex = intIndex + 1;

                string item = currentLine.Trim();

                if (!string.IsNullOrWhiteSpace(item) && item.StartsWith("#") == false)
                {
                    // マッチングレベル
                    if (item == "[MatchingLevel]")
                    {
                        if (strSectionFlag == "M")
                        {
                            // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                            throw new BusinessLogicException(msgId,
                                new string[] { conditionFilePath, intIndex.ToString(), "マッチングレベル" });
                        }
                        else
                        {
                            strSectionFlag = "M";
                        }
                    }
                    else if (item == "[GroupCondition]")
                    {
                        // 絞込み条件
                        if (strSectionFlag == "G")
                        {
                            // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                            throw new BusinessLogicException(msgId,
                                new string[] { conditionFilePath, intIndex.ToString(), "絞込み条件" });
                        }
                        else
                        {
                            strSectionFlag = "G";
                        }
                    }
                    else if (item == "[Condition]")
                    {
                        // 個別条件
                        strSectionFlag = "C";
                    }
                    else
                    {
                        switch (strSectionFlag)
                        {
                            case "M":
                                // マッチングレベルの設定
                                conditionListData.MatchingLevel = int.Parse(item);

                                // マッチングレベルが0～3の場合
                                if (!(conditionListData.MatchingLevel >= 0 && conditionListData.MatchingLevel <= 3))
                                {
                                    // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                    throw new BusinessLogicException(msgId,
                                        new string[] { conditionFilePath, intIndex.ToString(), "マッチングレベル" });
                                }

                                break;
                            case "G":
                                // 絞込み条件
                                conditionListData.GroupCondition = int.Parse(item);

                                // 絞込み条件が0～3の場合
                                if (!(conditionListData.MatchingLevel >= 0 && conditionListData.MatchingLevel <= 3))
                                {
                                    // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                    throw new BusinessLogicException(msgId,
                                        new string[] { conditionFilePath, intIndex.ToString(), "絞込み条件" });
                                }

                                break;
                            case "C":
                                // 個別条件の設定項目
                                string[] strExpress = StringUtil.SpiltDataByTab(item);

                                if (strExpress.Length != 5)
                                {
                                    // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                    throw new BusinessLogicException(msgId,
                                        new string[] { conditionFilePath, intIndex.ToString(), "個別条件" });
                                }

                                // 条件設定対象がマッチングレベル 且つ マッチングレベルが有効(個別指定)の場合
                                if (strExpress[2] == DataCol.mlv.ToString() && conditionListData.MatchingLevel.CompareTo(3) != 0)
                                {
                                    // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                    throw new BusinessLogicException(msgId,
                                        new string[] { conditionFilePath, intIndex.ToString(), "データ識別番号" });
                                }

                                // 漢字掲載名文字数が数値か判断
                                if (strExpress[2] == DataCol.kj_len.ToString() && IsNumber(strExpress[4]) == false)
                                {
                                    // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                    throw new BusinessLogicException(msgId,
                                        new string[] { conditionFilePath, intIndex.ToString(), "データ識別番号" });
                                }

                                // 北緯が数値か判断
                                if (strExpress[2] == DataCol.n.ToString() && IsNumber(strExpress[4]) == false)
                                {
                                    // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                    throw new BusinessLogicException(msgId,
                                        new string[] { conditionFilePath, intIndex.ToString(), "データ識別番号" });
                                }
                                
                                // 東経が数値か判断
                                if (strExpress[2] == DataCol.e.ToString() && IsNumber(strExpress[4]) == false)
                                {
                                    // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                    throw new BusinessLogicException(msgId,
                                        new string[] { conditionFilePath, intIndex.ToString(), "データ識別番号" });
                                }

                                // AND/OR判定が「AND」或いは「OR」以外の場合
                                if (!(strExpress[1] == "AND" || strExpress[1] == "OR" || strExpress[1] == "-"))
                                {
                                    // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                    throw new BusinessLogicException(msgId,
                                        new string[] { conditionFilePath, intIndex.ToString(), "AND/OR設定" });
                                }

                                // AND/OR設定で、「-」の分の判断
                                if (strExpress[1] == "-" && strExpress[0] == "0" && blStart)
                                {
                                    blStart = false;
                                }
                                else if (strExpress[1] == "-" && strExpress[0] == "0" && blStart == false)
                                {
                                    // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                    throw new BusinessLogicException(msgId,
                                        new string[] { conditionFilePath, intIndex.ToString(), "AND/OR設定" });
                                }

                                // 抽出条件が複数指定する場合
                                if (strExpress[4].Contains(","))
                                {
                                    string[] data = StringUtil.SpiltDataBycomma(strExpress[4]);

                                    for (int i = 0; i < data.Length; i++)
                                    {
                                        // 個別条件
                                        ConditionExpressData conditionData = new ConditionExpressData();

                                        if (i == 0)
                                        {
                                            // AND/OR
                                            conditionData.AndOr = strExpress[1];
                                        }
                                        else
                                        {
                                            // AND/OR
                                            conditionData.AndOr = AndOr.AND.ToString();
                                        }

                                        // 条件のグループ番号
                                        conditionData.GroupId = strExpress[0];

                                        // データ識別番号
                                        conditionData.Column = strExpress[2];

                                        // 判定基準
                                        conditionData.Expression = strExpress[3];

                                        // 抽出条件
                                        conditionData.Value = data[i];

                                        // 個別条件リスト
                                        conditionListData.ConditionExpressList.Add(conditionData);
                                    }
                                }
                                else
                                {
                                    // 個別条件
                                    ConditionExpressData conditionData = new ConditionExpressData();

                                    // 条件のグループ番号
                                    conditionData.GroupId = strExpress[0];

                                    // AND/OR設定
                                    conditionData.AndOr = strExpress[1];

                                    // データ識別番号
                                    conditionData.Column = strExpress[2];

                                    // 判定基準
                                    conditionData.Expression = strExpress[3];

                                    // 抽出条件
                                    conditionData.Value = strExpress[4];

                                    // 個別条件リスト
                                    conditionListData.ConditionExpressList.Add(conditionData);
                                }

                                break;
                            default:
                                // アンマッチ追跡条件設定ファイルの設定値が不正な場合
                                throw new BusinessLogicException(msgId,
                                    new string[] { conditionFilePath, intIndex.ToString(), "[Condition]" });
                        }
                    }
                }
            }

            return conditionListData;
        }
        #endregion

        #region 数値の判断
        /// <summary>
        /// 数値の判断
        /// </summary>
        /// <param name="data">文字列</param>
        /// <returns>true:数値 false:数値でない</returns>
        private static bool IsNumber(string data)
        {
            int result;

            return int.TryParse(data, out result);
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.BusinessObject;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// ToDoリスト作成用の情報（外国人）管理クラス
    /// </summary>
    public class MakeToDoInfoForeignFileManager
    {
        #region ToDoリスト作成用の情報（外国人）作成
        /// <summary>
        /// ToDoリスト作成用の情報（外国人）ファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="makeToDoInfoForeignList">ToDoリスト作成用の情報（外国人）リスト</param>
        public static void WriteMakeToDoInfoForeign(
            string filePath,
            string formatFilePath,
            List<MakeToDoInfoData> makeToDoInfoForeignList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (MakeToDoInfoData makeToDoInfoForeign in makeToDoInfoForeignList)
                {
                    fp.AddRecord();

                    SetCurData(fp, makeToDoInfoForeign);
                }
            }
            catch (Exception ex)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40001029;
                throw new BusinessLogicException(msgId, new string[] { filePath }, ex);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion

        #region ToDoリスト作成用の情報（外国人）作成
        /// <summary>
        /// ToDoリスト作成用の情報（外国人）ファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="makeToDoInfoForeignList">ToDoリスト作成用の情報（外国人）リスト</param>
        public static void ModifyMakeToDoInfoForeign(
            string filePath,
            string formatFilePath,
            List<MakeToDoInfoData> makeToDoInfoForeignList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                fp = new FileParser(fstream, xmlDef);

                foreach (MakeToDoInfoData makeToDoInfoForeign in makeToDoInfoForeignList)
                {
                    fp.AppendRecord();

                    SetCurData(fp, makeToDoInfoForeign);
                }
            }
            catch (Exception ex)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40001029;
                throw new BusinessLogicException(msgId, new string[] { filePath }, ex);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion

        #region  一つデータを設定する
        /// <summary>
        /// 一つデータを設定する
        /// </summary>
        /// <param name="fp">ファイルパーサ</param>
        /// <param name="makeToDoInfoForeign">出典-スクールゾーンデータ</param>
        private static void SetCurData(FileParser fp, MakeToDoInfoData makeToDoInfoForeign)
        {
            // 施設物件拡張のOID
            if (string.IsNullOrEmpty(makeToDoInfoForeign.OID))
            {
                fp["OID"] = string.Empty;
            }
            else
            {
                fp["OID"] = makeToDoInfoForeign.OID;
            }

            // グループID
            if (string.IsNullOrEmpty(makeToDoInfoForeign.GroupID))
            {
                fp["GroupID"] = string.Empty;
            }
            else
            {
                fp["GroupID"] = makeToDoInfoForeign.GroupID;
            }

            // 物件住所（漢字）
            if (string.IsNullOrEmpty(makeToDoInfoForeign.AdrNameKanji))
            {
                fp["AdrNameKanji"] = string.Empty;
            }
            else
            {
                fp["AdrNameKanji"] = makeToDoInfoForeign.AdrNameKanji;
            }

            // 電話番号
            if (string.IsNullOrEmpty(makeToDoInfoForeign.Telno))
            {
                fp["Telno"] = string.Empty;
            }
            else
            {
                fp["Telno"] = makeToDoInfoForeign.Telno;
            }

            // 正式漢字名称
            if (string.IsNullOrEmpty(makeToDoInfoForeign.FormalNameKanji))
            {
                fp["FormalNameKanji"] = string.Empty;
            }
            else
            {
                fp["FormalNameKanji"] = makeToDoInfoForeign.FormalNameKanji;
            }

            // 正式カナ名称
            if (string.IsNullOrEmpty(makeToDoInfoForeign.FormalNameKana))
            {
                fp["FormalNameKana"] = string.Empty;
            }
            else
            {
                fp["FormalNameKana"] = makeToDoInfoForeign.FormalNameKana;
            }

            // 表示漢字名称
            if (string.IsNullOrEmpty(makeToDoInfoForeign.DispNameKanji))
            {
                fp["DispNameKanji"] = string.Empty;
            }
            else
            {
                fp["DispNameKanji"] = makeToDoInfoForeign.DispNameKanji;
            }

            // 分類コード
            if (string.IsNullOrEmpty(makeToDoInfoForeign.TypeCode))
            {
                fp["TypeCode"] = string.Empty;
            }
            else
            {
                fp["TypeCode"] = makeToDoInfoForeign.TypeCode;
            }

            // 絶対座標：東経
            if (string.IsNullOrEmpty(makeToDoInfoForeign.Longitude))
            {
                fp["Longitude"] = string.Empty;
            }
            else
            {
                fp["Longitude"] = makeToDoInfoForeign.Longitude;
            }

            // 絶対座標：北緯
            if (string.IsNullOrEmpty(makeToDoInfoForeign.Latitude))
            {
                fp["Latitude"] = string.Empty;
            }
            else
            {
                fp["Latitude"] = makeToDoInfoForeign.Latitude;
            }

            // ファイルパーサーにアップデート
            fp.Update();
        }
        #endregion
    }
}

﻿using System.Collections.Generic;
using System.IO;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// フリーダイヤル・IP電話設定ファイル
    /// </summary>
    public class FreeAndIpPhoneFileManager
    {
        /// <summary>
        /// フリーダイヤル・IP電話設定ファイルの読み込み
        /// </summary>
        /// <param name="strPath">フリーダイヤル・IP電話設定ファイルのパス</param>
        /// <returns>フリーダイヤル・IP電話設定ファイルリスト</returns>
        public static List<FreeAndIpPhoneFileData> ReadFreeAndIpPhoneFile(string strPath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(strPath))
            {
                throw new FileNotFoundException();
            }

            // フリーダイヤル・IP電話設定ファイルデータ初期化
            List<FreeAndIpPhoneFileData> lstFreeAndIpPhoneFileData = new List<FreeAndIpPhoneFileData>();

            // テキストファイル読込む
            string content = FileUtil.ReadFile(strPath);

            // 行データの分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // コードリスト作成
            foreach (string currentLine in stringLines)
            {
                string[] strData = StringUtil.SpiltDataByTab(currentLine);

                if (strData.Length > 0)
                {
                    FreeAndIpPhoneFileData freeAndIpPhoneFileDataData = new FreeAndIpPhoneFileData();

                    // 電話番号
                    freeAndIpPhoneFileDataData.TelNo = strData[0];

                    // 電話分類
                    freeAndIpPhoneFileDataData.TelType = strData[1];

                    lstFreeAndIpPhoneFileData.Add(freeAndIpPhoneFileDataData);
                }
            }

            return lstFreeAndIpPhoneFileData;
        }
    }
}

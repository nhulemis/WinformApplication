﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 語頭語尾変換設定ファイル管理
    /// </summary>
    public class MjcGotouGobiFileManager
    {
        /// <summary>
        /// 語頭語尾変換設定ファイルの読込
        /// </summary>
        /// <param name="filePath">語頭語尾変換設定ファイルパス</param>
        /// <returns>語頭語尾変換設定ファイルデータのリスト</returns>
        public static List<MjcGotouGobiData> ReadMjcGotouGobiFile(string filePath)
        {
            List<MjcGotouGobiData> dataList = new List<MjcGotouGobiData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.MjcGotouGobiFileFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    MjcGotouGobiData data = new MjcGotouGobiData();

                    if ((string)fp["TxtType"] != string.Empty)
                    {
                        // 文字種別コード
                        data.TxtType = Convert.ToUInt16(fp["TxtType"]);
                    }

                    // 語頭語尾フラグ
                    data.Flag = fp["Flag"] as string;

                    // 変換英字
                    data.ConvertEn = fp["ConvertEn"] as string;

                    dataList.Add(data);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

﻿using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 出典差分-スクールゾーンファイル-外国人定義ファイル
    /// </summary>
    public class MateriaDiffSchoolzoneForeignFileManager
    {
        /// <summary>
        /// 出典差分-スクールゾーンファイル-外国人定義ファイルの読込
        /// </summary>
        /// <param name="file">出典差分-スクールゾーンファイル-外国人定義ファイル名</param>
        /// <returns>出典差分-スクールゾーンファイル-外国人ファイル</returns>
        public static List<MateriaDiffSchoolzoneData> ReadMateriaDiffSchoolzoneForeignFile(string file)
        {
            List<MateriaDiffSchoolzoneData> dataList = new List<MateriaDiffSchoolzoneData>();
            string formatFilePath = ConfigFileInfo.MateriaDiffSchoolzoneForeignFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            fstream = new FileStream(file, FileMode.Open, FileAccess.Read);
            fp = new FileParser(fstream, xmlDef);

            while (fp.NextRecord())
            {
                MateriaDiffSchoolzoneData materiaDiffSchoolzoneForeignData = new MateriaDiffSchoolzoneData();

                // 差分区分
                string value = fp["DiffFlag"].ToString();
                CheckDiffFlg(value);
                materiaDiffSchoolzoneForeignData.DiffFlag = value;

                // 差分明細
                materiaDiffSchoolzoneForeignData.DiffDetail = fp["DiffDetail"].ToString();

                // 施設物件拡張のOID
                materiaDiffSchoolzoneForeignData.OID = fp["OID"].ToString();

                // 出典ID
                materiaDiffSchoolzoneForeignData.MaterialID = fp["MaterialID"].ToString();

                // 物件住所（漢字）
                materiaDiffSchoolzoneForeignData.AdrNameKanji = fp["AdrNameKanji"].ToString();

                // 電話番号
                materiaDiffSchoolzoneForeignData.Telno = fp["Telno"].ToString();

                // 正式漢字名称
                materiaDiffSchoolzoneForeignData.FormalNameKanji = fp["FormalNameKanji"].ToString();

                // 正式カナ名称
                materiaDiffSchoolzoneForeignData.FormalNameKana = fp["FormalNameKana"].ToString();

                // 表示漢字名称
                materiaDiffSchoolzoneForeignData.DispNameKanji = fp["DispNameKanji"].ToString();

                // 2次メッシュコード
                materiaDiffSchoolzoneForeignData.Meshcode = fp["Meshcode"].ToString();

                // 東経座標
                materiaDiffSchoolzoneForeignData.Longitude = fp["Longitude"].ToString();

                // 北緯座標
                materiaDiffSchoolzoneForeignData.Latitude = fp["Latitude"].ToString();

                // 読込むファイル区分
                materiaDiffSchoolzoneForeignData.FileType = "F";

                dataList.Add(materiaDiffSchoolzoneForeignData);
            }

            if (fp != null)
            {
                fp.Dispose();
            }

            fp = null;

            if (fstream != null)
            {
                fstream.Dispose();
            }

            fstream = null;

            return dataList;
        }

        /// <summary>
        /// 差分区分チェック
        /// </summary>
        /// <param name="value">差分区分値</param>
        private static void CheckDiffFlg(string value)
        {
            if (!string.IsNullOrEmpty(value))
            {
                if (("N" != value) && ("C" != value) && ("D" != value))
                {
                    throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF10000123, new string[] { "出典差分-スクールゾーンファイル-外国人ファイル", "差分区分-DiffFlg" });
                }
            }
        }
    }
}

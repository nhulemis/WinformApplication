﻿using System.IO;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// deltelリストファイル読み込み
    /// </summary>
    public class DeltelListFileManager
    {
        #region deltelリストファイル読み込み
        /// <summary>
        /// deltelリストファイル読み込み
        /// </summary>
        /// <param name="deltelFilePath">deltelリストファイル</param>
        /// <returns>deltelリストファイルデータ</returns>
        public static DeltelListData ReadDeltelFile(string deltelFilePath)
        {
            try
            {
                // ファイルが存在するか確認
                if (!System.IO.File.Exists(deltelFilePath))
                {
                    throw new FileNotFoundException();
                }

                // deltelファイルデータ初期化
                DeltelListData deltelListData = new DeltelListData();

                // テキストファイル読込む
                string content = FileUtil.ReadFile(deltelFilePath);

                // 電話番号分割
                string[] stringLines = StringUtil.SpiltToLines(content);

                // コードリスト作成
                foreach (string currentLine in stringLines)
                {
                    string deltel = currentLine.Trim();
                    if (!string.IsNullOrWhiteSpace(deltel))
                    {
                        deltelListData.TelNoList.Add(deltel);
                    }
                }

                return deltelListData;
            }
            catch (FileNotFoundException)
            {
                // delteリストファイルがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40000002;
                throw new BusinessLogicException(msgId, new string[] { deltelFilePath });
            }
            catch (FileLoadException)
            {
                // delteリストファイルの読み込みに失敗した場合
                string msgId = UF_Fluere_MsgId.MSGID_UF40000009;
                throw new BusinessLogicException(msgId, new string[] { deltelFilePath });
            }
        }
        #endregion
    }
}

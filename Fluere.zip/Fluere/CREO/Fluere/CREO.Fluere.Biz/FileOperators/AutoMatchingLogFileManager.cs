﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 自動継承ログファイルの書き込み、読込
    /// </summary>
    public class AutoMatchingLogFileManager
    {
        #region 自動継承ログファイルの書き込み
        /// <summary>
        /// 自動継承ログファイルの書き込み
        /// </summary>
        /// <param name="filePath">自動継承ログファイル名</param>
        /// <param name="autoMatchingLogList">自動継承ログリスト</param>
        public static void WriteAutoMatchingLogFile(
            string filePath, List<AutoMatchingLogData> autoMatchingLogList)
        {
            // TsvファイルFormat
            string addressFormatFile = ConfigFileInfo.AutoMatchingLogFormatFile;

            if (!System.IO.File.Exists(addressFormatFile))
            {
                throw new FileNotFoundException(addressFormatFile);
            }

            XElement xmlDef = XElement.Load(addressFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                fp = new FileParser(fstream, xmlDef);

                foreach (AutoMatchingLogData autoMatchingLogData in autoMatchingLogList)
                {
                    fp.AddRecord();

                    // 新旧区分
                    if (string.IsNullOrEmpty(autoMatchingLogData.NewOrOld) ||
                        string.IsNullOrWhiteSpace(autoMatchingLogData.NewOrOld))
                    {
                        fp["NewOrOld"] = string.Empty;
                    }
                    else
                    {
                        fp["NewOrOld"] = autoMatchingLogData.NewOrOld;
                    }

                    // OID
                    fp["OID"] = autoMatchingLogData.OID.ToString();

                    // 電話番号
                    if (string.IsNullOrWhiteSpace(autoMatchingLogData.TelNumber))
                    {
                        fp["TelNumber"] = string.Empty;
                    }
                    else
                    {
                        fp["TelNumber"] = autoMatchingLogData.TelNumber;
                    }

                    // 漢字掲載名
                    if (string.IsNullOrEmpty(autoMatchingLogData.TwnKanji) ||
                        string.IsNullOrWhiteSpace(autoMatchingLogData.TwnKanji))
                    {
                        fp["TwnKanji"] = string.Empty;
                    }
                    else
                    {
                        fp["TwnKanji"] = autoMatchingLogData.TwnKanji;
                    }

                    // 都道府県コード
                    fp["ProvinceCode"] = autoMatchingLogData.ProvinceCode.ToString();

                    // 市区町村コード
                    fp["CityCode"] = autoMatchingLogData.CityCode.ToString();

                    // 大字コード
                    if (string.IsNullOrWhiteSpace(autoMatchingLogData.OazaCode))
                    {
                        fp["OazaCode"] = string.Empty;
                    }
                    else
                    {
                        fp["OazaCode"] = autoMatchingLogData.OazaCode;
                    }

                    // 字・丁目コード
                    if (string.IsNullOrWhiteSpace(autoMatchingLogData.SectionCode))
                    {
                        fp["SectionCode"] = string.Empty;
                    }
                    else
                    {
                        fp["SectionCode"] = autoMatchingLogData.SectionCode;
                    }

                    // 都道府県名
                    if (string.IsNullOrEmpty(autoMatchingLogData.ProvinceName) ||
                        string.IsNullOrWhiteSpace(autoMatchingLogData.ProvinceName))
                    {
                        fp["ProvinceName"] = string.Empty;
                    }
                    else
                    {
                        fp["ProvinceName"] = autoMatchingLogData.ProvinceName;
                    }

                    // 市区郡町村名
                    if (string.IsNullOrEmpty(autoMatchingLogData.CityName) ||
                        string.IsNullOrWhiteSpace(autoMatchingLogData.CityName))
                    {
                        fp["CityName"] = string.Empty;
                    }
                    else
                    {
                        fp["CityName"] = autoMatchingLogData.CityName;
                    }

                    // 大字・通称名
                    if (string.IsNullOrEmpty(autoMatchingLogData.OazaName) ||
                        string.IsNullOrWhiteSpace(autoMatchingLogData.OazaName))
                    {
                        fp["OazaName"] = string.Empty;
                    }
                    else
                    {
                        fp["OazaName"] = autoMatchingLogData.OazaName;
                    }

                    // 字・丁目名
                    if (string.IsNullOrEmpty(autoMatchingLogData.SectionName) ||
                        string.IsNullOrWhiteSpace(autoMatchingLogData.SectionName))
                    {
                        fp["SectionName"] = string.Empty;
                    }
                    else
                    {
                        fp["SectionName"] = autoMatchingLogData.SectionName;
                    }

                    // 街区番号・部屋番号
                    if (string.IsNullOrEmpty(autoMatchingLogData.GaikuRoom) ||
                        string.IsNullOrWhiteSpace(autoMatchingLogData.GaikuRoom))
                    {
                        fp["GaikuRoom"] = string.Empty;
                    }
                    else
                    {
                        fp["GaikuRoom"] = autoMatchingLogData.GaikuRoom;
                    }

                    // 方書
                    if (string.IsNullOrEmpty(autoMatchingLogData.Katagaki) ||
                        string.IsNullOrWhiteSpace(autoMatchingLogData.Katagaki))
                    {
                        fp["Katagaki"] = string.Empty;
                    }
                    else
                    {
                        fp["Katagaki"] = autoMatchingLogData.Katagaki;
                    }

                    // NTT分類コード
                    if (string.IsNullOrWhiteSpace(autoMatchingLogData.NTTGroupCode))
                    {
                        fp["NTTGroupCode"] = string.Empty;
                    }
                    else
                    {
                        fp["NTTGroupCode"] = autoMatchingLogData.NTTGroupCode;
                    }

                    // NTT分類名
                    if (string.IsNullOrEmpty(autoMatchingLogData.NTTGroupName) ||
                        string.IsNullOrWhiteSpace(autoMatchingLogData.NTTGroupName))
                    {
                        fp["NTTGroupName"] = string.Empty;
                    }
                    else
                    {
                        fp["NTTGroupName"] = autoMatchingLogData.NTTGroupName;
                    }

                    // 経度
                    fp["Longitude"] = autoMatchingLogData.Longitude.ToString();

                    // 緯度
                    fp["Latitude"] = autoMatchingLogData.Latitude.ToString();

                    // マッチングレベル
                    fp["MatchingLv"] = autoMatchingLogData.MatchingLv.ToString();

                    // ファイルパーサーにアップデート
                    fp.Update();
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion
    }
}

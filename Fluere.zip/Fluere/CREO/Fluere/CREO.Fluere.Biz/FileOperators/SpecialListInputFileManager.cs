﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CREO.Fluere.Common.DataSources.OpenXml;
using CREO.Fluere.Biz.FileOperators.Data;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 特別対応リストファイルの読み込み
    /// </summary>
    public class SpecialListInputFileManager
    {
        #region クラス属性定義
        /// <summary>
        /// シートページの名前
        /// </summary>
        private static string excelSheetName = "特別対応リスト";

        #endregion

        #region 特別対応リストファイルの読み込み
        /// <summary>
        /// 特別対応リストファイルの読み込み
        /// </summary>
        /// <param name="filePath">特別対応リストファイルパス</param>
        /// <returns>特別対応リストファイル</returns>
        public static List<SpecialListInputListData> ReadSpecialListInputList(string filePath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(filePath))
            {
                throw new FileNotFoundException(filePath);
            }

            // 戻りリスト
            List<SpecialListInputListData> specialListInputListDataList =
                new List<SpecialListInputListData>();

            // 読込結果の整形
            using (SpreadSheetDataRepository repository = new SpreadSheetDataRepository(
                filePath, CultureInfo.InvariantCulture, true, false))
            {
                repository.Open();

                // ファイルの読込
                IEnumerable<object[]> context = repository.Target(excelSheetName);

                foreach (object[] record in context)
                {
                    if (record.Length == 0)
                    {
                        continue;
                    }

                    // データインスタンス
                    SpecialListInputListData specialListInputListData = new SpecialListInputListData();

                    // Ｎｏ
                    if (record.Length > 0 && !string.IsNullOrEmpty(record[0].ToString()))
                    {
                        specialListInputListData.SpecialListNo = Convert.ToInt32(record[0]);
                    }
                    else
                    {
                        specialListInputListData.SpecialListNo = 0;
                    }

                    // 都道府県コード
                    if (record.Length > 1 && !string.IsNullOrEmpty(record[1].ToString()))
                    {
                        specialListInputListData.ProvinceCode = record[1].ToString();
                    }
                    else
                    {
                        specialListInputListData.ProvinceCode = "0";
                    }

                    // 市区町村コード
                    if (record.Length > 2 && !string.IsNullOrEmpty(record[2].ToString()))
                    {
                        specialListInputListData.CityCode = record[2].ToString();
                    }
                    else
                    {
                        specialListInputListData.CityCode = "0";
                    }

                    // 大字コード
                    if (record.Length > 3 && !string.IsNullOrEmpty(record[3].ToString()))
                    {
                        specialListInputListData.OazaCode = record[3].ToString();
                    }
                    else
                    {
                        specialListInputListData.OazaCode = "0";
                    }

                    // 小字コード
                    if (record.Length > 4 && !string.IsNullOrEmpty(record[4].ToString()))
                    {
                        specialListInputListData.SectionCode = record[4].ToString();
                    }
                    else
                    {
                        specialListInputListData.SectionCode = "0";
                    }

                    // 街区符号
                    if (record.Length > 5 && !string.IsNullOrEmpty(record[5].ToString()))
                    {
                        specialListInputListData.GaikuCode = record[5].ToString();
                    }
                    else
                    {
                        specialListInputListData.GaikuCode = "0";
                    }

                    // 住居番号
                    if (record.Length > 6 && !string.IsNullOrEmpty(record[6].ToString()))
                    {
                        specialListInputListData.HouseNo = record[6].ToString();
                    }
                    else
                    {
                        specialListInputListData.HouseNo = "0";
                    }

                    // 地番
                    if (record.Length > 7 && !string.IsNullOrEmpty(record[7].ToString()))
                    {
                        specialListInputListData.LotNo = record[7].ToString();
                    }
                    else
                    {
                        specialListInputListData.LotNo = "0";
                    }

                    // 枝番
                    if (record.Length > 8 && !string.IsNullOrEmpty(record[8].ToString()))
                    {
                        specialListInputListData.SuffixNo = record[8].ToString();
                    }
                    else
                    {
                        specialListInputListData.SuffixNo = "0";
                    }

                    // 住所名称
                    if (record.Length > 9 && !string.IsNullOrEmpty(record[9].ToString()))
                    {
                        specialListInputListData.AdrName = record[9].ToString();
                    }
                    else
                    {
                        specialListInputListData.AdrName = "0";
                    }

                    // ２MC
                    if (record.Length > 10 && !string.IsNullOrEmpty(record[10].ToString()))
                    {
                        specialListInputListData.MC = Convert.ToInt32(record[10]);
                    }
                    else
                    {
                        specialListInputListData.MC = 0;
                    }

                    // X座標
                    if (record.Length > 11 && !string.IsNullOrEmpty(record[11].ToString()))
                    {
                        specialListInputListData.Longitude = Convert.ToInt64(record[11]);
                    }
                    else
                    {
                        specialListInputListData.Longitude = 0;
                    }

                    // Y座標
                    if (record.Length > 12 && !string.IsNullOrEmpty(record[12].ToString()))
                    {
                        specialListInputListData.Latitude = Convert.ToInt64(record[12]);
                    }
                    else
                    {
                        specialListInputListData.Latitude = 0;
                    }

                    // 確認項目
                    if (record.Length > 13 && !string.IsNullOrEmpty(record[13].ToString()))
                    {
                        specialListInputListData.ConfirmType = record[13].ToString();
                    }
                    else
                    {
                        specialListInputListData.ConfirmType = "0";
                    }

                    // 確認内容
                    if (record.Length > 14 && !string.IsNullOrEmpty(record[14].ToString()))
                    {
                        specialListInputListData.ConfirmContent = record[14].ToString();
                    }
                    else
                    {
                        specialListInputListData.ConfirmContent = "0";
                    }

                    // 問連管理No
                    if (record.Length > 15 && !string.IsNullOrEmpty(record[15].ToString()))
                    {
                        specialListInputListData.RelatedMngNo = record[15].ToString();
                    }
                    else
                    {
                        specialListInputListData.RelatedMngNo = "0";
                    }

                    // 管理表登録日
                    if (record.Length > 16 && !string.IsNullOrEmpty(record[16].ToString()))
                    {
                        specialListInputListData.EntryDate = record[16].ToString();
                    }
                    else
                    {
                        specialListInputListData.EntryDate = "0";
                    }

                    specialListInputListDataList.Add(specialListInputListData);
                }
            }

            return specialListInputListDataList;
        }
        #endregion
    }
}

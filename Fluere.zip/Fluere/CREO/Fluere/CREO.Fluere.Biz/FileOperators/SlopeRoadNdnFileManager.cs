﻿using System.Collections.Generic;
using System.IO;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 対応付けデータファイル処理
    /// </summary>
    public static class SlopeRoadNdnFileManager
    {
        /// <summary>
        /// 対応付けデータファイルの読み込み
        /// </summary>
        /// <param name="strPath">ファイルのパス</param>
        /// <returns>対応付けデータのリスト</returns>
        public static List<SlopeRoadNdnData> ReadSlopeRoadNdnFile(string strPath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(strPath))
            {
                throw new FileNotFoundException();
            }

            // 対応付けデータファイルデータ初期化
            List<SlopeRoadNdnData> lstSlopeRoadNdnData = new List<SlopeRoadNdnData>();

            // テキストファイル読込む
            string content = FileUtil.ReadFile(strPath);

            // 行データの分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // コードリスト作成
            foreach (string currentLine in stringLines)
            {
                string[] strData = StringUtil.SpiltDataBycomma(currentLine);

                if (strData.Length > 0)
                {
                    SlopeRoadNdnData slopeRoadNdnData = new SlopeRoadNdnData();

                    slopeRoadNdnData.MeshNo = int.Parse(strData[0]);
                    slopeRoadNdnData.CrsNo = uint.Parse(strData[1]);

                    lstSlopeRoadNdnData.Add(slopeRoadNdnData);
                }
            }

            return lstSlopeRoadNdnData;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// スペース対象抽出定義ファイル管理
    /// </summary>
    public class SpaceObjectDefFileManager
    {
        /// <summary>
        /// スペース対象抽出定義ファイルを読み込み
        /// </summary>
        /// <param name="filePath">スペース対象抽出定義ファイルパス</param>
        /// <returns>スペース対象抽出定義ファイルリスト</returns>
        public static List<SpaceObjectDefData> ReadSpaceObjectDefFile(string filePath)
        {
            List<SpaceObjectDefData> dataList = new List<SpaceObjectDefData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.SpaceObjectDefFileFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    SpaceObjectDefData data = new SpaceObjectDefData();

                    // 文字種別コード
                    data.TxtType = (string)fp["TxtType"];

                    // 抽出キー
                    data.ExtractKey = (string)fp["ExtractKey"];

                    dataList.Add(data);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Message;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 町字差分ファイル
    /// </summary>
    public class AddressDiffManager
    {
        #region ログマネージャーのインスタンス、メッセージマネージャーのインスタンス
        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        private static LogManager _logMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);

        /// <summary>
        /// メッセージマネージャーインスタンス
        /// </summary>
        private static MessageManager _msgMgr = MessageManager.GetMessageManager(UF_Fluere_MsgId.MODULE_NUMBER);
        #endregion

        /// <summary>
        /// 町字差分ファイルの読込
        /// </summary>
        /// <param name="file">町字差分ファイル</param>
        /// <returns>町字差分ファイルデータ</returns>
        public static List<AddressDiffData> ReadAddressDiffFile(string file)
        {
            List<AddressDiffData> dataList = new List<AddressDiffData>();

            string formatFilePath = ConfigFileInfo.AddressDiffFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;

            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fs, xmlDef);

                while (fp.NextRecord())
                {
                    AddressDiffData data = new AddressDiffData();
                    dataList.Add(data);

                    // 差分区分
                    string value = (string)fp["DiffKbn"];
                    CheckIsNull(value, "差分区分（DiffKbn）");
                    data.DiffFlag = ushort.Parse(value);

                    // 特殊処理有無
                    value = (string)fp["SpecialProcess"];
                    CheckIsNull(value, "特殊処理有無（SpecialProcess）");
                    data.SpecialProcess = ushort.Parse(value);

                    // 処理住所コード
                    value = (string)fp["A0123"];
                    CheckIsNull(value, "処理住所コード（A0123）");
                    data.AdrCode = value;

                    // 行政区域コード
                    data.ActionAdrCode = (string)fp["AdrCode"];

                    // 住所名称（漢字）
                    data.AdrNameKanji = (string)fp["AdrNameKanji"];

                    // 住所名称（全角カナ）
                    data.AdrNameKana = (string)fp["AdrNameKana"];

                    // 出典住所名称（漢字）
                    data.MateriaAdrNameKanji = (string)fp["SrcAdrNameKanji"];

                    // 出典住所名称（全角カナ）
                    data.MateriaAdrNameKana = (string)fp["SrcAdrNameKana"];

                    // DTVコード
                    data.DtvCode = ConvertStringToUshort((string)fp["DtvCode"]);

                    // 出力コード
                    data.IndexDivision = ConvertStringToUshort((string)fp["IndexDivision"]);
                    
                    // 捏造コード
                    data.InventCode = ConvertStringToByte((string)fp["InventCode"]);

                    // 郵便：町字コード
                    data.MachiazaCode = ConvertStringToUshort((string)fp["MachiazaCode"]);

                    // 郵便：市区町村コード
                    data.MunicipalityCode = ConvertStringToUshort((string)fp["MunicipalityCode"]);

                    // 同一住所名称の識別名称
                    data.OazaDistinctNameMultiLang = (string)fp["OazaDistinctName"];

                    // 人口
                    data.Population = ConvertStringToUlong((string)fp["Population"]);

                    // 通称/公称コード
                    data.PublicCode = ConvertStringToUshort((string)fp["PublicCode"]);

                    // 観光地コード
                    data.ResortCodeAry = (string)fp["ResortCode"];

                    // 観光地名称（漢字）
                    data.ResortNameMultiLangAryKanji = (string)fp["ResortName"];

                    // 観光地名称（ひらがな）
                    data.ResortNameMultiLangAryKana = (string)fp["ResortNameAryKana"];

                    // 観光地名称（音声認識）
                    data.ResortNameMultiLangAryAware = (string)fp["ResortNameAryAware"];

                    // 観光地名称（音声合成）
                    data.ResortNameMultiLangAryComp = (string)fp["ResortNameAryComp"];
                    
                    // 旧郵便：町字コード
                    data.MachiazaOldCode = ConvertStringToUshort((string)fp["MachiazaOldCode"]);

                    // 旧郵便：市区町村コード
                    data.MunicipalityOldCode = ConvertStringToUshort((string)fp["MunicipalityOldCode"]);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (fp != null)
                {
                    fp.Dispose();
                }

                fp = null;

                if (fs != null)
                {
                    fs.Dispose();
                }

                fs = null;
            }

            return dataList;
        }

        /// <summary>
        /// nullチェック
        /// </summary>
        /// <param name="value">値</param>
        /// <param name="item">項目</param>
        private static void CheckIsNull(string value, string item)
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF00000002, new string[] { item });
            }
        }

        /// <summary>
        /// stringをushort?に変換する
        /// </summary>
        /// <param name="strValue">string型の値</param>
        /// <returns>ushort?型の値</returns>
        private static ushort? ConvertStringToUshort(string strValue)
        {
            ushort? retValue = null;

            if (!string.IsNullOrEmpty(strValue))
            {
                retValue = ushort.Parse(strValue);
            }

            return retValue;
        }

        /// <summary>
        /// stringをushort?に変換する
        /// </summary>
        /// <param name="strValue">string型の値</param>
        /// <returns>byte?型の値</returns>
        private static byte? ConvertStringToByte(string strValue)
        {
            byte? retValue = null;

            if (!string.IsNullOrEmpty(strValue))
            {
                retValue = byte.Parse(strValue);
            }

            return retValue;
        }

        /// <summary>
        /// stringをulong?に変換する
        /// </summary>
        /// <param name="strValue">string型の値</param>
        /// <returns>ulong?型の値</returns>
        private static ulong? ConvertStringToUlong(string strValue)
        {
            ulong? retValue = null;

            if (!string.IsNullOrEmpty(strValue))
            {
                retValue = ulong.Parse(strValue);
            }

            return retValue;
        }
    }
}

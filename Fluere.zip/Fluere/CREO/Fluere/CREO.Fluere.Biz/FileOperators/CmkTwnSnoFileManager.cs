﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 交差点目印丸め込みリストファイル
    /// </summary>
    public class CmkTwnSnoFileManager
    {
        /// <summary>
        /// Readメソッド
        /// </summary>
        /// <param name="filePath">filePath</param>
        /// <returns>交差点目印丸め込みリスト</returns>
        public static List<CmkTwnSnoData> Read(string filePath)
        {
            List<CmkTwnSnoData> dataList = new List<CmkTwnSnoData>();

            string formatFilePath = ConfigFileInfo.SpaceCmkTwnSnoFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // lstファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    CmkTwnSnoData overCrsnoData = new CmkTwnSnoData();

                    // 目印コード1
                    // 交差点目印の【目印名称】[目印コード]
                    overCrsnoData.MarkCode_1 = (string)fp["MarkCode_1"];

                    // 目印コード2
                    // 交差点目印に対応するタウン物件か施設物件の【目印名称】[目印コード]
                    overCrsnoData.MarkCode_2 = (string)fp["MarkCode_2"];

                    dataList.Add(overCrsnoData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// アンマッチ結果ファイル
    /// </summary>
    public class UnmatchResultsFileManager
    {
        #region アンマッチ結果ファイル作成
        /// <summary>
        /// アンマッチ結果ファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="unmatchResultsList">アンマッチ結果リスト</param>
        public static void WriteUnmatchResultsToDoFile(
            string filePath,
            string formatFilePath,
            List<UnmatchResultsData> unmatchResultsList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (UnmatchResultsData unmatchResult in unmatchResultsList)
                {
                    fp.AddRecord();

                    // 2次メッシュコード
                    if (string.IsNullOrEmpty(unmatchResult.MeshCode))
                    {
                        fp["MeshCode"] = string.Empty;
                    }
                    else
                    {
                        fp["MeshCode"] = unmatchResult.MeshCode;
                    }

                    // 交差点データ番号
                    if (string.IsNullOrEmpty(unmatchResult.CrsDateNumber))
                    {
                        fp["CrsDateNumber"] = string.Empty;
                    }
                    else
                    {
                        fp["CrsDateNumber"] = unmatchResult.CrsDateNumber;
                    }

                    // 目印連番
                    if (string.IsNullOrEmpty(unmatchResult.MarkSpate))
                    {
                        fp["MarkSpate"] = string.Empty;
                    }
                    else
                    {
                        fp["MarkSpate"] = unmatchResult.MarkSpate;
                    }

                    // 目印コード
                    if (string.IsNullOrEmpty(unmatchResult.MarkCode))
                    {
                        fp["MarkCode"] = string.Empty;
                    }
                    else
                    {
                        fp["MarkCode"] = unmatchResult.MarkCode;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(unmatchResult.KANAName))
                    {
                        fp["KANAName"] = string.Empty;
                    }
                    else
                    {
                        fp["KANAName"] = unmatchResult.KANAName;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(unmatchResult.KanJiNames))
                    {
                        fp["KanJiNames"] = string.Empty;
                    }
                    else
                    {
                        fp["KanJiNames"] = unmatchResult.KanJiNames;
                    }

                    // 経度
                    if (string.IsNullOrEmpty(unmatchResult.Longitude))
                    {
                        fp["Longitude"] = string.Empty;
                    }
                    else
                    {
                        fp["Longitude"] = unmatchResult.Longitude;
                    }

                    // 緯度
                    if (string.IsNullOrEmpty(unmatchResult.Latitude))
                    {
                        fp["Latitude"] = string.Empty;
                    }
                    else
                    {
                        fp["Latitude"] = unmatchResult.Latitude;
                    }

                    // 交差点目印のOID
                    if (string.IsNullOrEmpty(unmatchResult.CrsMarkOID))
                    {
                        fp["CrsMarkOID"] = string.Empty;
                    }
                    else
                    {
                        fp["CrsMarkOID"] = unmatchResult.CrsMarkOID;
                    }

                    // ファイルパーサーにアップデート
                    fp.Update();
                }
            }
            catch (Exception)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000212;
                throw new BusinessLogicException(msgId, new string[] { filePath });
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion
    }
}

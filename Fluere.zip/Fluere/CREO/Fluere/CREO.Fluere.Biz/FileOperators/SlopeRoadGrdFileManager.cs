﻿using System.Collections.Generic;
using System.IO;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 道路勾配データファイル処理
    /// </summary>
    public class SlopeRoadGrdFileManager
    {
        /// <summary>
        /// 道路勾配データファイルの読み込み
        /// </summary>
        /// <param name="strPath">ファイルのパス</param>
        /// <returns>道路勾配データのリスト</returns>
        public static List<SlopeRoadGrdData> ReadSlopeRoadGrdFile(string strPath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(strPath))
            {
                throw new FileNotFoundException();
            }

            // 道路勾配データファイルデータ初期化
            List<SlopeRoadGrdData> lstSlopeRoadGrdData = new List<SlopeRoadGrdData>();

            // テキストファイル読込む
            string content = FileUtil.ReadFile(strPath);

            // 行データの分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // コードリスト作成
            foreach (string currentLine in stringLines)
            {
                string[] strData = StringUtil.SpiltDataBycomma(currentLine);

                if (strData.Length > 0)
                {
                    SlopeRoadGrdData slopeRoadGrdData = new SlopeRoadGrdData();

                    slopeRoadGrdData.Latitude = double.Parse(strData[0]);
                    slopeRoadGrdData.Longitude = double.Parse(strData[1]);
                    slopeRoadGrdData.Height = double.Parse(strData[2]);
                    slopeRoadGrdData.RelativeSlope = double.Parse(strData[3]);

                    lstSlopeRoadGrdData.Add(slopeRoadGrdData);
                }
            }

            return lstSlopeRoadGrdData;
        }
    }
}

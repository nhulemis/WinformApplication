﻿using CREO.CommonBusinessLogic.FileOperators.Data;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// タウン受入ファイルフォーマットクラス
    /// </summary>
    public class TownAcceptFileFormatManager
    {
        #region ファイルのフォーマットデータを取得する
        /// <summary>
        /// ファイルのフォーマットデータを取得する
        /// </summary>
        /// <returns>ファイルのフォーマットデータ</returns>
        public static TownAcceptFileFormatData GetTownAcceptFileFormatData()
        {
            TownAcceptFileFormatData townAcceptFileFormatData = new TownAcceptFileFormatData();

            // 面積限定した大字代表点ファイルフォーマット
            townAcceptFileFormatData.GenFileFormat = ConfigFileInfo.AreaSquarGenFormatFile;

            // 累積住所代表点ファイルフォーマット
            townAcceptFileFormatData.AenAcmFormat = ConfigFileInfo.AccumulationAenFile;

            // ZMAP住所代表点ファイルフォーマット
            townAcceptFileFormatData.AenZxdFormat = ConfigFileInfo.AccumulationAenFile;

            // ZCYファイルフォーマット
            townAcceptFileFormatData.ZcyFormat = ConfigFileInfo.ZmapTempFormatFile;

            // ZCY京都交差点データファイルフォーマット
            townAcceptFileFormatData.ZcyCrsKyoutoFormat = ConfigFileInfo.ZcyKyoutoCrsFormatFile;

            // 隣接大字データファイルフォーマット
            townAcceptFileFormatData.RozFormat = ConfigFileInfo.AdjoinOoazDataFormatFile;

            // 大字表記対応リストファイルフォーマット
            townAcceptFileFormatData.OoaztblFormat = ConfigFileInfo.OoazMappingFormatFile;

            // NGファイルフォーマット
            townAcceptFileFormatData.NGFormat = ConfigFileInfo.NgDataFormatFile;

            // 役所定義ファイルフォーマット
            townAcceptFileFormatData.YakushoFileFormat = ConfigFileInfo.GovOfficeDefFormatFile;

            // 建造物定義ファイルフォーマット
            townAcceptFileFormatData.BuildingFileFormat = ConfigFileInfo.BuildingDefFormatFile;

            // 東西通り名称ファイルフォーマット
            townAcceptFileFormatData.EwStreetFileFormat = ConfigFileInfo.EastWetStreetNameFormatFile;

            // 南北通り名称ファイルフォーマット
            townAcceptFileFormatData.SnStreetFileFormat = ConfigFileInfo.SouthNorthStreetNameFormatFile;

            // 京都市通り名称置換文字列定義ファイルフォーマット
            townAcceptFileFormatData.ExchangesFileFormat = ConfigFileInfo.KyoutoStreetNameReplaceDefFormatFile;

            // エリア名称ファイルフォーマット
            townAcceptFileFormatData.AreaNameFileFormat = ConfigFileInfo.AreaNameDataFormatFile;

            return townAcceptFileFormatData;
        }
        #endregion
    }
}

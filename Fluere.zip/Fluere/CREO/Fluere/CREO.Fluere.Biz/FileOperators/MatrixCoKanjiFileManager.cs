﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 方書･漢字複合条件ファイルの読込、書込み
    /// </summary>
    public class MatrixCoKanjiFileManager
    {
        /// <summary>
        /// 方書･漢字複合条件ファイルの読込
        /// </summary>
        /// <param name="file">方書･漢字複合条件ファイル名</param>
        /// <returns>方書･漢字複合条件ファイル</returns>
        public static List<MatrixCoKanjiData> ReadMatrixCoKanjiFile(string file)
        {
            List<MatrixCoKanjiData> dataList = new List<MatrixCoKanjiData>();

            string formatFilePath = ConfigFileInfo.MatrixCoKanjiFileFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            fstream = new FileStream(file, FileMode.Open, FileAccess.Read);
            fp = new FileParser(fstream, xmlDef);

            string matrixCoKanji = null;
            while (fp.NextRecord())
            {
                MatrixCoKanjiData matrixCoKanjiData = new MatrixCoKanjiData();
                matrixCoKanjiData.MultipleCondFlagList = new List<int>();

                matrixCoKanji = fp["MatrixCoKanji"].ToString();
                List<string> strList = matrixCoKanji.Split('\t').ToList();

                // 条件種別
                matrixCoKanjiData.CondCatalog = strList[0];

                // 複合可/否リスト
                strList.RemoveAt(0);
                foreach (string item in strList)
                {
                    if (string.IsNullOrEmpty(item) || string.IsNullOrWhiteSpace(item))
                    {
                        matrixCoKanjiData.MultipleCondFlagList.Add(0);
                    }
                    else
                    {
                        matrixCoKanjiData.MultipleCondFlagList.Add(int.Parse(item));
                    }
                }

                dataList.Add(matrixCoKanjiData);
            }

            if (fp != null)
            {
                fp.Dispose();
            }

            fp = null;

            if (fstream != null)
            {
                fstream.Dispose();
            }

            fstream = null;

            return dataList;
        }
    }
}

﻿using System.Collections.Generic;
using System.IO;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// タウンデータ区分対応リストファイル
    /// </summary>
    public class TwnDataDivConvertFileManager
    {
        /// <summary>
        /// タウンデータ区分対応リストファイルの読み込み
        /// </summary>
        /// <param name="strPath">タウンデータ区分対応リストファイルのパス</param>
        /// <returns>タウンデータ区分対応リスト</returns>
        public static List<TwnDataDivConvertData> ReadTwnDataDivConvertFile(string strPath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(strPath))
            {
                throw new FileNotFoundException();
            }

            // タウンデータ区分対応リストファイルデータ初期化
            List<TwnDataDivConvertData> lstTwnDataDivConvertData = new List<TwnDataDivConvertData>();

            // テキストファイル読込む
            string content = FileUtil.ReadFile(strPath);

            // 行データの分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // コードリスト作成
            foreach (string currentLine in stringLines)
            {
                string[] strData = StringUtil.SpiltDataByTab(currentLine);

                if (strData.Length > 0)
                {
                    TwnDataDivConvertData twnDataDivConvertData = new TwnDataDivConvertData();

                    twnDataDivConvertData.DataCode = strData[0];

                    if (strData.Length < 2)
                    {
                        twnDataDivConvertData.InputCode = string.Empty;
                    }
                    else
                    {
                        twnDataDivConvertData.InputCode = strData[1];
                    }

                    if (strData.Length < 3)
                    {
                        twnDataDivConvertData.TwnCode = string.Empty;
                    }
                    else
                    {
                        twnDataDivConvertData.TwnCode = strData[2];
                    }

                    lstTwnDataDivConvertData.Add(twnDataDivConvertData);
                }
            }

            return lstTwnDataDivConvertData;
        }
    }
}

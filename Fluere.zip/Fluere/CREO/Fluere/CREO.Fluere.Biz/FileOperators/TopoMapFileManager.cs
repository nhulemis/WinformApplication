﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Message;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 地形図データファイル
    /// </summary>
    public class TopoMapFileManager
    {
        #region ログマネージャーのインスタンス、メッセージマネージャーのインスタンス
        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        private static LogManager _logMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);

        /// <summary>
        /// メッセージマネージャーインスタンス
        /// </summary>
        private static MessageManager _msgMgr = MessageManager.GetMessageManager(UF_Fluere_MsgId.MODULE_NUMBER);
        #endregion

        /// <summary>
        /// 地形図管理データファイルの読込
        /// </summary>
        /// <param name="file">地形図管理データファイル</param>
        /// <returns>地形図管理データファイルデータ</returns>
        public static List<TopoMapManagerData> ReadTopoMapManagerDataFile(string file)
        {
            List<TopoMapManagerData> dataList = new List<TopoMapManagerData>();

            string formatFilePath = ConfigFileInfo.TopoMapManagerDataFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;

            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fs, xmlDef);

                while (fp.NextRecord())
                {
                    if (fp.RowIndex == 1)
                    {
                        continue;
                    }

                    TopoMapManagerData data = new TopoMapManagerData();

                    // 2次メッシュ
                    data.MeshNo = fp["MeshNo"].ToString();

                    // 地形図名称（漢字）
                    data.MapNameKanji = fp["MapNameKanji"].ToString();

                    // 発行年月日
                    data.PublishDate = fp["PublishDate"].ToString();
                    
                    // 左上経度（度）
                    string value = fp["leftUpLongitude"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftUpLongitude = Convert.ToInt64(value);
                    }

                    // 左上経度（分）
                    value = fp["leftUpLongitudeMinute"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftUpLongitudeMinute = Convert.ToInt64(value);
                    }

                    // 左上経度（秒）
                    value = fp["leftUpLongitudeSecond"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftUpLongitudeSecond = Convert.ToInt64(value);
                    }

                    // 左上緯度（度）
                    value = fp["leftUpLatitude"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftUpLatitude = Convert.ToInt64(value);
                    }

                    // 左上緯度（分）
                    value = fp["leftUpLatitudeMinute"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftUpLatitudeMinute = Convert.ToInt64(value);
                    }

                    // 左上緯度（秒）
                    value = fp["leftUpLatitudeSecond"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftUpLatitudeSecond = Convert.ToInt64(value);
                    }

                    // 左下経度（度）
                    value = fp["leftDownLongitude"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftDownLongitude = Convert.ToInt64(value);
                    }

                    // 左下経度（分）
                    value = fp["leftDownLongitudeMinute"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftDownLongitudeMinute = Convert.ToInt64(value);
                    }

                    // 左下経度（秒）
                    value = fp["leftDownLongitudeSecond"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftDownLongitudeSecond = Convert.ToInt64(value);
                    }

                    // 左下緯度（度）
                    value = fp["leftDownLatitude"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftDownLatitude = Convert.ToInt64(value);
                    }

                    // 左下緯度（分）
                    value = fp["leftDownLatitudeMinute"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftDownLatitudeMinute = Convert.ToInt64(value);
                    }

                    // 左下緯度（秒）
                    value = fp["leftDownLatitudeSecond"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.leftDownLatitudeSecond = Convert.ToInt64(value);
                    }

                    // 右下経度（度）
                    value = fp["rightDownLongitude"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightDownLongitude = Convert.ToInt64(value);
                    }

                    // 右下経度（分）
                    value = fp["rightDownLongitudeMinute"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightDownLongitudeMinute = Convert.ToInt64(value);
                    }

                    // 右下経度（秒）
                    value = fp["rightDownLongitudeSecond"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightDownLongitudeSecond = Convert.ToInt64(value);
                    }

                    // 右下緯度（度）
                    value = fp["rightDownLatitude"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightDownLatitude = Convert.ToInt64(value);
                    }

                    // 右下緯度（分）
                    value = fp["rightDownLatitudeMinute"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightDownLatitudeMinute = Convert.ToInt64(value);
                    }

                    // 右下緯度（秒）
                    value = fp["rightDownLatitudeSecond"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightDownLatitudeSecond = Convert.ToInt64(value);
                    }

                    // 右上経度（度）
                    value = fp["rightUpLongitude"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightUpLongitude = Convert.ToInt64(value);
                    }

                    // 右上経度（分）
                    value = fp["rightUpLongitudeMinute"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightUpLongitudeMinute = Convert.ToInt64(value);
                    }

                    // 右上経度（秒）
                    value = fp["rightUpLongitudeSecond"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightUpLongitudeSecond = Convert.ToInt64(value);
                    }

                    // 右上緯度（度）
                    value = fp["rightUpLatitude"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightUpLatitude = Convert.ToInt64(value);
                    }

                    // 右上緯度（分）
                    value = fp["rightUpLatitudeMinute"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightUpLatitudeMinute = Convert.ToInt64(value);
                    }

                    // 右上緯度（秒）
                    value = fp["rightUpLatitudeSecond"].ToString();
                    if (!string.IsNullOrWhiteSpace(value))
                    {
                        data.rightUpLatitudeSecond = Convert.ToInt64(value);
                    }

                    dataList.Add(data);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (fp != null)
                {
                    fp.Dispose();
                }

                fp = null;

                if (fs != null)
                {
                    fs.Dispose();
                }

                fs = null;
            }

            return dataList;
        }

        /// <summary>
        /// 地形図補足データファイルの読込
        /// </summary>
        /// <param name="file">地形図補足データファイル</param>
        /// <returns>地形図補足データファイルデータ</returns>
        public static List<TopoMapFillData> ReadTopoMapFillDataFile(string file)
        {
            List<TopoMapFillData> dataList = new List<TopoMapFillData>();

            string formatFilePath = ConfigFileInfo.TopoMapFillDataFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;
            
            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fs, xmlDef);

                while (fp.NextRecord())
                {
                    TopoMapFillData data = new TopoMapFillData();

                    // 地形図名称（漢字）
                    data.MapNameKanji = fp["MapNameKanji"].ToString();

                    // 改測年月日
                    data.ResurveyDate = fp["ResurveyDate"].ToString();

                    // 2万5千分の1地形図番号
                    string value = fp["TopoMap25kNo"].ToString();
                    if (string.IsNullOrEmpty(value))
                    {
                        data.TopoMap25kNo = null;
                    }
                    else
                    {
                        data.TopoMap25kNo = ushort.Parse(value);
                    }

                    // 5万分の1地形図番号
                    value = fp["TopoMap50kNo"].ToString();
                    if (string.IsNullOrEmpty(value))
                    {
                        data.TopoMap50kNo = null;
                    }
                    else
                    {
                        data.TopoMap50kNo = ushort.Parse(value);
                    }

                    // 地勢図名称
                    data.GeographicMapName = fp["GeographicMapName"].ToString();

                    dataList.Add(data);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (fp != null)
                {
                    fp.Dispose();
                }

                fp = null;

                if (fs != null)
                {
                    fs.Dispose();
                }

                fs = null;
            }

            return dataList;
        }

        /// <summary>
        /// nullチェック
        /// </summary>
        /// <param name="value">ファイルパス</param>
        /// <param name="item">項目</param>
        private static void CheckIsNull(string value, string item)
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF00000002, new string[] { item });
            }
        }
    }
}

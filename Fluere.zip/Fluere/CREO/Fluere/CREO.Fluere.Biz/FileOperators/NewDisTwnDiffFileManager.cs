﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 新規・廃止差分タウンファイルの読込、書込み
    /// </summary>
    public class NewDisTwnDiffFileManager
    {
        /// <summary>
        /// 指定した市区町村の新規・廃止差分タウンファイルの読込
        /// </summary>
        /// <param name="file">読込用のファイル</param>
        /// <returns>市区町村の新規・廃止差分タウンファイル</returns>
        public static List<NewDisTwnDiffFileData> ReadNewDisTwnDiffFile(string file)
        {
            // レコードフォーマットファイル読込
            XElement xmlDef = XElement.Load(ConfigFileInfo.NewDisDiffTwnFormatFile);

            // ファイルパーサー用情報設定
            FileParser fileParser = null;

            fileParser = new FileParser(new FileStream(file,
                                                        FileMode.Open,
                                                        FileAccess.Read),
                                        xmlDef);

            // 読込む先が定義
            List<NewDisTwnDiffFileData> dataList = new List<NewDisTwnDiffFileData>();

            try
            {
                while (fileParser.NextRecord())
                {
                    // 新規･廃止差分タウンデータをインスタンス
                    NewDisTwnDiffFileData data = new NewDisTwnDiffFileData();

                    // タウン物件OID
                    data.OidString = (long)fileParser["oidstring"];

                    // データ区分
                    data.Ddiv = (short)fileParser["ddiv"];

                    // 差分フラグ
                    data.Dflg = (string)fileParser["dflg"];

                    // 情報種別
                    data.Ity = (string)fileParser["ity"];

                    // ファイル区分
                    data.Fcl = (string)fileParser["fcl"];

                    // 市外局番
                    data.T0 = (string)fileParser["t0"];

                    // 電話番号
                    data.Tn = (string)fileParser["tn"];

                    // カナ掲載名
                    data.Kn = (string)fileParser["kn"];

                    // 漢字掲載名
                    data.Kj = (string)fileParser["kj"];

                    // 都道府県コード
                    data.A0 = (long?)fileParser["a0"];

                    // 市区町村コード
                    data.A1 = (long)fileParser["a1"];

                    // 大字コード
                    data.A2 = (string)fileParser["a2"];

                    // 字・丁目コード
                    data.A3 = (string)fileParser["a3"];

                    // 都道府県名
                    data.An0 = (string)fileParser["an0"];

                    // 市区郡町村名
                    data.An1 = (string)fileParser["an1"];

                    // 大字・通称名
                    data.An2 = (string)fileParser["an2"];

                    // 字・丁目名
                    data.An3 = (string)fileParser["an3"];

                    // 街区番号・部屋番号
                    data.An4 = (string)fileParser["an4"];

                    // 方書
                    data.Co = (string)fileParser["co"];

                    // 基本分類コード
                    data.Bc = (string)fileParser["bc"];

                    // 基本分類名
                    data.Bcn = (string)fileParser["bcn"];

                    // 付記
                    data.Ps = (string)fileParser["ps"];

                    // 電番略符号
                    data.Tac = (string)fileParser["tac"];

                    // ＮＴＴ分類コード
                    data.Nc = (string)fileParser["nc"];

                    // ＮＴＴ分類名
                    data.Ncn = (string)fileParser["ncn"];

                    // 法人種類コード
                    data.Apt = (string)fileParser["apt"];

                    // 郵便番号１
                    data.M0 = (string)fileParser["m0"];

                    // 郵便番号２
                    data.M1 = (string)fileParser["m1"];

                    // 外字識別表示
                    data.Xkj = (string)fileParser["xkj"];

                    // 通称識別表示
                    data.Xan = (string)fileParser["xan"];

                    // 主掲載フラグ
                    data.Mfg = (string)fileParser["mfg"];

                    // 予備
                    data.Rsv = (long)fileParser["rsv"];

                    // 目印コード
                    data.Sno = (string)fileParser["sno"];

                    if (!string.IsNullOrEmpty(data.Sno))
                    {
                        data.Sno = data.Sno.Trim();

                        if (string.IsNullOrEmpty(data.Sno))
                        {
                            data.Sno = null;
                        }
                    }
                    else
                    {
                        data.Sno = null;
                    }

                    // 経度
                    data.E = (long)fileParser["e"];

                    // 緯度
                    data.N = (long)fileParser["n"];

                    // マッチングレベル
                    data.Mlv = (ushort)(int)fileParser["mlv"];

                    // 住所マッチングフラグ
                    data.Amflg = (int)fileParser["amflg"];

                    dataList.Add(data);
                }
            }
            catch (FrameworkException fwEx)
            {
                throw fwEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                fileParser.Close();
            }

            return dataList;
        }

        /// <summary>
        /// 新規・廃止差分タウンファイルの書き込み
        /// </summary>
        /// <param name="file">出力ファイル</param>
        /// <param name="dataList">ファイルデータリスト</param>
        public static void WriteNewDisTwnDiff(string file, List<NewDisTwnDiffFileData> dataList)
        {
            // レコードフォーマットファイル読込
            XElement xmlDef = XElement.Load(ConfigFileInfo.NewDisDiffTwnFormatFile);

            // ファイルパーサー用情報設定
            FileParser fileParser = null;

            fileParser = new FileParser(new FileStream(file,
                                                        FileMode.OpenOrCreate,
                                                        FileAccess.ReadWrite),
                                        xmlDef);

            try
            {
                foreach (NewDisTwnDiffFileData data in dataList)
                {
                    fileParser.AddRecord();

                    // タウン物件OID
                    fileParser["oidstring"] = data.OidString;

                    // データ区分
                    fileParser["ddiv"] = (short)data.Ddiv;

                    // 差分フラグ
                    fileParser["dflg"] = data.Dflg;

                    // 情報種別
                    fileParser["ity"] = data.Ity;

                    // ファイル区分
                    fileParser["fcl"] = data.Fcl;

                    // 市外局番
                    fileParser["t0"] = data.T0;

                    // 電話番号
                    fileParser["tn"] = data.Tn;

                    // カナ掲載名
                    fileParser["kn"] = data.Kn;

                    // 漢字掲載名
                    fileParser["kj"] = data.Kj;

                    // 都道府県コード
                    fileParser["a0"] = data.A0;

                    // 市区町村コード
                    fileParser["a1"] = data.A1;

                    // 大字コード
                    fileParser["a2"] = data.A2;

                    // 字・丁目コード
                    fileParser["a3"] = data.A3;

                    // 都道府県名
                    fileParser["an0"] = data.An0;

                    // 市区郡町村名
                    fileParser["an1"] = data.An1;

                    // 大字・通称名
                    fileParser["an2"] = data.An2;

                    // 字・丁目名
                    fileParser["an3"] = data.An3;

                    // 街区番号・部屋番号
                    fileParser["an4"] = data.An4;

                    // 方書
                    fileParser["co"] = data.Co;

                    // 基本分類コード
                    fileParser["bc"] = data.Bc;

                    // 基本分類名
                    fileParser["bcn"] = data.Bcn;

                    // 付記
                    fileParser["ps"] = data.Ps;

                    // 電番略符号
                    fileParser["tac"] = data.Tac;

                    // ＮＴＴ分類コード
                    fileParser["nc"] = data.Nc;

                    // ＮＴＴ分類名
                    fileParser["ncn"] = data.Ncn;

                    // 法人種類コード
                    fileParser["apt"] = data.Apt;

                    // 郵便番号１
                    fileParser["m0"] = data.M0;

                    // 郵便番号２
                    fileParser["m1"] = data.M1;

                    // 外字識別表示
                    fileParser["xkj"] = data.Xkj;

                    // 通称識別表示
                    fileParser["xan"] = data.Xan;

                    // 主掲載フラグ
                    fileParser["mfg"] = data.Mfg;

                    // 予備
                    fileParser["rsv"] = data.Rsv;

                    // 目印コード
                    if (string.IsNullOrEmpty(data.Sno))
                    {
                        fileParser["sno"] = string.Empty;
                    }
                    else
                    {
                        fileParser["sno"] = data.Sno;
                    }

                    // 経度
                    fileParser["e"] = data.E;

                    // 緯度
                    fileParser["n"] = data.N;

                    // マッチングレベル
                    fileParser["mlv"] = (int)data.Mlv;

                    // 住所マッチングフラグ
                    fileParser["amflg"] = data.Amflg;

                    // ファイルパーサーにアップデート
                    fileParser.Update();
                }
            }
            catch (FrameworkException fwEx)
            {
                throw fwEx;
            }
            catch (Exception exp)
            {
                throw exp;
            }
            finally
            {
                fileParser.Close();
            }
        }
    }
}

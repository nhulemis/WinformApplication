﻿using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 音声発注リストファイル
    /// </summary>
    public class VoiceOrderFileManager
    {
        /// <summary>
        /// 音声発注リストファイルの書き込み
        /// </summary>
        /// <param name="filePath">音声発注リストファイルパス</param>
        /// <param name="dataList">音声発注リストファイルデータのリスト</param>
        public static void WriteVoiceOrderListFile(string filePath, List<VoiceOrderFileData> dataList)
        {
            XElement xmlDef = XElement.Load(ConfigFileInfo.VoiceOrderFileFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                fp = new FileParser(fstream, xmlDef);

                foreach (VoiceOrderFileData data in dataList)
                {
                    fp.AddRecord();

                    fp["V_FILE_VoiceTypCode"] = data.V_FILE_VoiceTypCode;

                    // よみがなキー
                    fp["YomiKey"] = data.YomiKey;

                    // よみ名称
                    fp["YomiName"] = data.YomiName;

                    // 音声種別コード
                    fp["VoiceTypCode"] = data.VoiceTypCode;

                    // 音声ID
                    fp["VoiceID"] = data.VoiceID;

                    // ファイル名
                    fp["VoiceFileName"] = data.VoiceFileName;

                    // 漢字名称
                    if (data.VoiceKanjiName == null)
                    {
                        fp["VoiceKanjiName"] = string.Empty;
                    }
                    else
                    {
                        fp["VoiceKanjiName"] = data.VoiceKanjiName;
                    }

                    // 整備状況コード
                    fp["MaintStateCode"] = data.MaintStateCode;

                    // ファイルパーサーにアップデート
                    fp.Update();
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
    }
}

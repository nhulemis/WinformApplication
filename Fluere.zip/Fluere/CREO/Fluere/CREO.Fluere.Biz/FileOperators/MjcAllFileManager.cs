﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 種別毎変換設定ファイル管理
    /// </summary>
    public class MjcAllFileManager
    {
        /// <summary>
        /// 種別毎変換設定ファイルの読込
        /// </summary>
        /// <param name="filePath">種別毎変換設定ファイルパス</param>
        /// <returns>種別毎変換設定ファイルデータのリスト</returns>
        public static List<MjcAllData> ReadMjcAllFile(string filePath)
        {
            List<MjcAllData> dataList = new List<MjcAllData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.MjcAllFileFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    if (fp.RowIndex == 1)
                    {
                        continue;
                    }

                    MjcAllData data = new MjcAllData();

                    if ((string)fp["TxtType"] != string.Empty)
                    {
                        // 文字種別コード
                        data.TxtType = Convert.ToUInt16(fp["TxtType"]);
                    }

                    if ((string)fp["OneWordSetting"] != string.Empty)
                    {
                        // 一律一定ワード設定文字
                        data.OneWordSetting = fp["OneWordSetting"] as string;
                    }

                    // 変換パターン
                    data.ConvertPattern = fp["ConvertPattern"] as string;

                    if ((string)fp["ForceConvertRomaji"] != string.Empty)
                    {
                        // 強制ローマ字変換
                        data.ForceConvertRomaji = fp["ForceConvertRomaji"] as string;
                    }

                    dataList.Add(data);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

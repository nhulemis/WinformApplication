﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 予約VICS区間削除対象リストファイルの読み込み
    /// </summary>
    public class VicsSectionFileManager
    {
        #region 予約VICS区間削除対象リストファイルの読み込み
        /// <summary>
        /// 予約VICS区間削除対象リストファイルの読み込み
        /// </summary>
        /// <param name="file">予約VICS区間削除対象リストファイル</param>
        /// <returns>規制情報変換データ</returns>
        public static Dictionary<string, List<VicsSectionFileData>> ReadNewOldAreaFile(string file)
        {
            Dictionary<string, List<VicsSectionFileData>> retDic = new Dictionary<string, List<VicsSectionFileData>>();

            string formatFilePath = ConfigFileInfo.VicsSectionFormatFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;

            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                if (!File.Exists(file))
                {
                    // フォーマットファイルがオープン出来ない場合
                    string msgId = UF_Fluere_MsgId.MSGID_UF10000186;
                    throw new BusinessLogicException(msgId, new string[] { file });
                }

                // FileParserで直接に項目で取得する 
                fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fs, xmlDef);

                int dataCount = 0;
                while (fp.NextRecord())
                {
                    VicsSectionFileData data = new VicsSectionFileData();

                    // 2次メッシュコード
                    data.MeshCode = fp["MeshCode"].ToString();

                    if (string.IsNullOrEmpty(data.MeshCode))
                    {
                        string sCount = Convert.ToString(dataCount + 1);
                        string filename = Path.GetFileName(file);
                        string[] parameter = new string[] { filename, "MeshCode", sCount };
                        string msgId = UF_Fluere_MsgId.MSGID_UF10000187;
                        throw new BusinessLogicException(msgId, parameter);
                    }

                    // VICSリンク区分コード
                    data.VICSDivisionCode = fp["VICSDivisionCode"].ToString();

                    if (string.IsNullOrEmpty(data.VICSDivisionCode))
                    {
                        string sCount = Convert.ToString(dataCount + 1);
                        string filename = Path.GetFileName(file);
                        string[] parameter = new string[] { filename, "VICSDivisionCode", sCount };
                        string msgId = UF_Fluere_MsgId.MSGID_UF10000187;
                        throw new BusinessLogicException(msgId, parameter);
                    }

                    // VICSリンク番号
                    data.VICSNumber = fp["VICSNumber"].ToString();

                    if (string.IsNullOrEmpty(data.VICSNumber))
                    {
                        string sCount = Convert.ToString(dataCount + 1);
                        string filename = Path.GetFileName(file);
                        string[] parameter = new string[] { filename, "VICSNumber", sCount };
                        string msgId = UF_Fluere_MsgId.MSGID_UF10000187;
                        throw new BusinessLogicException(msgId, parameter);
                    }

                    // 9.13.6.3.3. 削除対象リストのグループ
                    List<VicsSectionFileData> dataList = null;
                    if (retDic.ContainsKey(data.MeshCode))
                    {
                        dataList = retDic[data.MeshCode];
                    }
                    else
                    {
                        dataList = new List<VicsSectionFileData>();
                        retDic.Add(data.MeshCode, dataList);
                    }

                    dataList.Add(data);
                    dataCount++;
                }

                LogUtility.WriteDataCount("【予約VICS区間削除対象リストファイル】",
                    LogUtility.OperationType.File,
                    dataCount);
            }
            catch (BusinessLogicException buEx)
            {
                throw buEx;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (fp != null)
                {
                    fp.Dispose();
                }

                fp = null;

                if (fs != null)
                {
                    fs.Dispose();
                }

                fs = null;
            }

            return retDic;
        }
        #endregion
    }
}

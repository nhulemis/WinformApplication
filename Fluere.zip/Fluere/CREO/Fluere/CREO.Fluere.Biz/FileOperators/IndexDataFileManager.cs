﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// インディクスファイルの読込、書込み
    /// </summary>
    public class IndexDataFileManager
    {
        #region インディクスファイルの読込
        /// <summary>
        /// インディクスファイルの読込
        /// </summary>
        /// <param name="file">読込用のファイル</param>
        /// <returns>インディクスファイルリスト</returns>
        public static List<IndexFileData> ReadIndexFile(string file)
        {
            // レコードフォーマットファイル読込
            XElement xmlDef = XElement.Load(ConfigFileInfo.IndexFormatFile);

            // ファイルパーサー用情報設定
            FileParser fileParser = null;

            fileParser = new FileParser(new FileStream(file,
                                                        FileMode.Open,
                                                        FileAccess.Read),
                                        xmlDef);

            // 読込む先が定義
            List<IndexFileData> dataList = new List<IndexFileData>();

            try
            {
                while (fileParser.NextRecord())
                {
                    // インディクスファイル
                    IndexFileData data = new IndexFileData();
                    dataList.Add(data);

                    // 市外局番
                    data.AreaNo = Encoding.Default.GetString((byte[])fileParser["AreaNo"]).Trim();

                    // 市内局番
                    data.LocalNo = Encoding.Default.GetString((byte[])fileParser["LocalNo"]).Trim();

                    // 住所コード1
                    data.AdrCode1 = Encoding.Default.GetString((byte[])fileParser["AdrCode1"]);

                    // 住所コード2
                    data.AdrCode2 = Encoding.Default.GetString((byte[])fileParser["AdrCode2"]);

                    // 住所コード3
                    data.AdrCode3 = Encoding.Default.GetString((byte[])fileParser["AdrCode3"]);

                    // 住所コード4
                    data.AdrCode4 = Encoding.Default.GetString((byte[])fileParser["AdrCode4"]);

                    // 住所コード5
                    data.AdrCode5 = Encoding.Default.GetString((byte[])fileParser["AdrCode5"]);

                    // 住所コード6
                    data.AdrCode6 = Encoding.Default.GetString((byte[])fileParser["AdrCode6"]);

                    // 住所コード7
                    data.AdrCode7 = Encoding.Default.GetString((byte[])fileParser["AdrCode7"]);

                    // 住所コード8
                    data.AdrCode8 = Encoding.Default.GetString((byte[])fileParser["AdrCode8"]);

                    // 住所コード9
                    data.AdrCode9 = Encoding.Default.GetString((byte[])fileParser["AdrCode9"]);

                    // 住所コード10
                    data.AdrCode10 = Encoding.Default.GetString((byte[])fileParser["AdrCode10"]);

                    // 住所コード11
                    data.AdrCode11 = Encoding.Default.GetString((byte[])fileParser["AdrCode11"]);

                    // 住所コード12
                    data.AdrCode12 = Encoding.Default.GetString((byte[])fileParser["AdrCode12"]);

                    // 住所コード13
                    data.AdrCode13 = Encoding.Default.GetString((byte[])fileParser["AdrCode13"]);

                    // 住所コード14
                    data.AdrCode14 = Encoding.Default.GetString((byte[])fileParser["AdrCode14"]);

                    // 住所コード15
                    data.AdrCode15 = Encoding.Default.GetString((byte[])fileParser["AdrCode15"]);

                    // 住所コード16
                    data.AdrCode16 = Encoding.Default.GetString((byte[])fileParser["AdrCode16"]);

                    // 住所コード17
                    data.AdrCode17 = Encoding.Default.GetString((byte[])fileParser["AdrCode17"]);

                    // 住所コード18
                    data.AdrCode18 = Encoding.Default.GetString((byte[])fileParser["AdrCode18"]);

                    // 住所コード19
                    data.AdrCode19 = Encoding.Default.GetString((byte[])fileParser["AdrCode19"]);

                    // 住所コード20
                    data.AdrCode20 = Encoding.Default.GetString((byte[])fileParser["AdrCode20"]);

                    // 住所コード21
                    data.AdrCode21 = Encoding.Default.GetString((byte[])fileParser["AdrCode21"]);

                    // 住所コード22
                    data.AdrCode22 = Encoding.Default.GetString((byte[])fileParser["AdrCode22"]);

                    // 住所コード23
                    data.AdrCode23 = Encoding.Default.GetString((byte[])fileParser["AdrCode23"]);

                    // 住所コード24
                    data.AdrCode24 = Encoding.Default.GetString((byte[])fileParser["AdrCode24"]);

                    // 住所コード25
                    data.AdrCode25 = Encoding.Default.GetString((byte[])fileParser["AdrCode25"]);

                    // 住所コード26
                    data.AdrCode26 = Encoding.Default.GetString((byte[])fileParser["AdrCode26"]);

                    // 住所コード27
                    data.AdrCode27 = Encoding.Default.GetString((byte[])fileParser["AdrCode27"]);

                    // 住所コード28
                    data.AdrCode28 = Encoding.Default.GetString((byte[])fileParser["AdrCode28"]);

                    // 住所コード29
                    data.AdrCode29 = Encoding.Default.GetString((byte[])fileParser["AdrCode29"]);

                    // 住所コード30
                    data.AdrCode30 = Encoding.Default.GetString((byte[])fileParser["AdrCode30"]);

                    // 廃止フラグ
                    data.DisAdrFlag = Encoding.Default.GetString((byte[])fileParser["DisAdrFlag"]);

                    // 予備
                    data.Prep = Encoding.Default.GetString((byte[])fileParser["Prep"]);

                    data.AdrCodeList = new List<string>();

                    string fileParserName = string.Empty;
                    string value = string.Empty;
                    for (int i = 1; i < 31; i++)
                    {
                        fileParserName = "AdrCode" + i.ToString();

                        value = Encoding.Default.GetString((byte[])fileParser[fileParserName]);

                        if (value.Trim().Length > 0)
                        {
                            data.AdrCodeList.Add(value);
                        }
                    }
                }
            }
            finally
            {
                fileParser.Close();
            }

            return dataList;
        }
        #endregion

        #region インディクスファイルの書き込み
        /// <summary>
        /// インディクスファイルの書き込み
        /// </summary>
        /// <param name="file">出力ファイル</param>
        /// <param name="dataList">ファイルデータリスト</param>
        public static void WriteIndexFile(string file, List<IndexFileData> dataList)
        {
            // レコードフォーマットファイル読込
            XElement xmlDef = XElement.Load(ConfigFileInfo.IndexFormatFile);

            // ファイルパーサー用情報設定
            FileParser fileParser = null;

            fileParser = new FileParser(new FileStream(file,
                                                        FileMode.OpenOrCreate,
                                                        FileAccess.ReadWrite),
                                        xmlDef);

            try
            {
                foreach (IndexFileData data in dataList)
                {
                    fileParser.AddRecord();

                    if (data.AreaNo.Length < 6)
                    {
                        data.AreaNo = data.AreaNo.PadRight(6, ' ');
                    }

                    // 市外局番
                    fileParser["AreaNo"] = Encoding.Default.GetBytes(data.AreaNo);

                    if (data.LocalNo.Length < 4)
                    {
                        data.LocalNo = data.LocalNo.PadRight(4, ' ');
                    }

                    // 市内局番
                    fileParser["LocalNo"] = Encoding.Default.GetBytes(data.LocalNo);

                    // 住所コード1
                    fileParser["AdrCode1"] = Encoding.Default.GetBytes(data.AdrCode1);

                    // 住所コード2
                    fileParser["AdrCode2"] = Encoding.Default.GetBytes(data.AdrCode2);

                    // 住所コード3
                    fileParser["AdrCode3"] = Encoding.Default.GetBytes(data.AdrCode3);

                    // 住所コード4
                    fileParser["AdrCode4"] = Encoding.Default.GetBytes(data.AdrCode4);

                    // 住所コード5
                    fileParser["AdrCode5"] = Encoding.Default.GetBytes(data.AdrCode5);

                    // 住所コード6
                    fileParser["AdrCode6"] = Encoding.Default.GetBytes(data.AdrCode6);

                    // 住所コード7
                    fileParser["AdrCode7"] = Encoding.Default.GetBytes(data.AdrCode7);

                    // 住所コード8
                    fileParser["AdrCode8"] = Encoding.Default.GetBytes(data.AdrCode8);

                    // 住所コード9
                    fileParser["AdrCode9"] = Encoding.Default.GetBytes(data.AdrCode9);

                    // 住所コード10
                    fileParser["AdrCode10"] = Encoding.Default.GetBytes(data.AdrCode10);

                    // 住所コード11
                    fileParser["AdrCode11"] = Encoding.Default.GetBytes(data.AdrCode11);

                    // 住所コード12
                    fileParser["AdrCode12"] = Encoding.Default.GetBytes(data.AdrCode12);

                    // 住所コード13
                    fileParser["AdrCode13"] = Encoding.Default.GetBytes(data.AdrCode13);

                    // 住所コード14
                    fileParser["AdrCode14"] = Encoding.Default.GetBytes(data.AdrCode14);

                    // 住所コード15
                    fileParser["AdrCode15"] = Encoding.Default.GetBytes(data.AdrCode15);

                    // 住所コード16
                    fileParser["AdrCode16"] = Encoding.Default.GetBytes(data.AdrCode16);

                    // 住所コード17
                    fileParser["AdrCode17"] = Encoding.Default.GetBytes(data.AdrCode17);

                    // 住所コード18
                    fileParser["AdrCode18"] = Encoding.Default.GetBytes(data.AdrCode18);

                    // 住所コード19
                    fileParser["AdrCode19"] = Encoding.Default.GetBytes(data.AdrCode19);

                    // 住所コード20
                    fileParser["AdrCode20"] = Encoding.Default.GetBytes(data.AdrCode20);

                    // 住所コード21
                    fileParser["AdrCode21"] = Encoding.Default.GetBytes(data.AdrCode21);

                    // 住所コード22
                    fileParser["AdrCode22"] = Encoding.Default.GetBytes(data.AdrCode22);

                    // 住所コード23
                    fileParser["AdrCode23"] = Encoding.Default.GetBytes(data.AdrCode23);

                    // 住所コード24
                    fileParser["AdrCode24"] = Encoding.Default.GetBytes(data.AdrCode24);

                    // 住所コード25
                    fileParser["AdrCode25"] = Encoding.Default.GetBytes(data.AdrCode25);

                    // 住所コード26
                    fileParser["AdrCode26"] = Encoding.Default.GetBytes(data.AdrCode26);

                    // 住所コード27
                    fileParser["AdrCode27"] = Encoding.Default.GetBytes(data.AdrCode27);

                    // 住所コード28
                    fileParser["AdrCode28"] = Encoding.Default.GetBytes(data.AdrCode28);

                    // 住所コード29
                    fileParser["AdrCode29"] = Encoding.Default.GetBytes(data.AdrCode29);

                    // 住所コード30
                    fileParser["AdrCode30"] = Encoding.Default.GetBytes(data.AdrCode30);

                    // 廃止フラグ
                    fileParser["DisAdrFlag"] = Encoding.Default.GetBytes(data.DisAdrFlag);

                    // 予備
                    fileParser["Prep"] = Encoding.Default.GetBytes(data.Prep);

                    // ファイルパーサーにアップデート
                    fileParser.Update();
                }
            }
            catch (FrameworkException fwEx)
            {
                throw fwEx;
            }
            catch (Exception exp)
            {
                throw exp;
            }
            finally
            {
                fileParser.Close();
            }
        }
        #endregion
    }
}

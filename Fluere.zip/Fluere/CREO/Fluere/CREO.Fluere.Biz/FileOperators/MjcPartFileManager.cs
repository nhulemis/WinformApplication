﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 描画系部分変換設定ファイル管理
    /// </summary>
    public class MjcPartFileManager
    {
        /// <summary>
        /// 描画系部分変換設定ファイルの読込
        /// </summary>
        /// <param name="filePath">描画系部分変換設定ファイルパス</param>
        /// <returns>描画系部分変換設定ファイルデータのリスト</returns>
        public static List<MjcPartConvertData> ReadMjcPartFile(string filePath)
        {
            List<MjcPartConvertData> dataList = new List<MjcPartConvertData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.MjcPartFileFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    if (fp.RowIndex == 1)
                    {
                        continue;
                    }

                    MjcPartConvertData data = new MjcPartConvertData();

                    if ((string)fp["TxtType"] != string.Empty)
                    {
                        // 文字種別コード
                        data.TxtType = Convert.ToUInt16(fp["TxtType"]);
                    }

                    // 漢字名称
                    data.KanjiName = fp["KanjiName"] as string;

                    // カナ名称
                    data.KanaName = fp["KanaName"] as string;

                    // チェック位置
                    data.CheckPosition = fp["CheckPosition"] as string;

                    // 部分変換語句
                    data.ConvetWord = fp["ConvetWord"] as string;

                    // 変換仕様
                    data.ConvertSpecification = fp["ConvertSpecification"] as string;

                    // 完全一致の対応
                    data.AllMatchSupport = fp["AllMatchSupport"] as string;

                    if ((string)fp["AllMatchEn"] != string.Empty)
                    {
                        // 完全一致英字
                        data.AllMatchEn = fp["AllMatchEn"] as string;
                    }

                    // 優先度
                    data.Priority = fp["Priority"] as string;

                    dataList.Add(data);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

﻿using System;
using System.IO;
using CREO.Fluere.Common.Configuration;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Common.Diagnostics;
using CREO.Fluere.Common.Serialization;
using CREO.Fluere.Common.SystemDefinition;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// システム定義ファイル管理クラス
    /// </summary>
    public class SystemDefinitionManager
    {
        /// <summary>
        /// システム定義ファイル初期化
        /// </summary>
        /// <param name="systemDefinitionManager">システム定義ファイルパス</param>
        /// <returns>システム定義を示すインターフェイスです</returns>
        public static ISystemDefinition LoadSystemDefData(
            IConfigurationManager systemDefinitionManager)
        {
            Assertion.Condition(systemDefinitionManager != null);

            try
            {
                LogUtility.WriteInfo("{0}:{1}", "【システム定義ファイル】", systemDefinitionManager.FullName);

                systemDefinitionManager.Load();
                ISystemDefinition systemDef = systemDefinitionManager.Configuration as ISystemDefinition;
                return systemDef;
            }
            catch (IOException ex)
            {
                // システム定義ファイルがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000001;
                string[] parameters = new string[] { systemDefinitionManager.FullName };

                throw new BusinessLogicException(msgId, parameters, ex);
            }
            catch (MissingNodeException ex)
            {
                string nodeName = ex.NodeName;

                // システム定義ファイルに、必要な定義が存在しない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000002;
                string[] messageParameters = new string[] { systemDefinitionManager.FullName, nodeName };

                throw new BusinessLogicException(msgId, messageParameters, ex);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.BusiComm.Exception;
using CREO.BusiComm.ToDoFile;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// Todoリストファイルの処理
    /// </summary>
    public class TodoListFileManager
    {
        #region ToDoファイルの読み込み処理
        /// <summary>
        /// ToDoファイルの読み込み処理
        /// </summary>
        /// <param name="strToDoFPath">読み込みTodoファイルのパス</param>
        /// <param name="lstForFieldFormat">Todoファイルのヘッダリスト</param>
        /// <param name="lstToDoListData">Todoファイルのデータリスト</param>
        public static void ReadTodoListData(
            string strToDoFPath, ref List<FormatFieldItem> lstForFieldFormat, ref List<List<string>> lstToDoListData)
        {
            // Todoファイル読書用
            CommToDoReadWriter commToDoReadWriter = null;

            // 一時ToDoファイルヘッド部データリスト
            List<FormatFieldItem> lstForFieldFormat_temp = new List<FormatFieldItem>();

            // 一時ToDoファイルデータ部データリスト
            List<List<string>> lstToDoListData_temp = new List<List<string>>();

            // ToDoフォーマット(HeaderList)形式チェック
            bool isHeadlistformatOK = false;

            // HeaderList項目数
            int headlistNum = 0;

            // ToDoフォーマット(DataList)形式チェック
            bool isDatalistformatOK = false;

            // DataList項目数
            int datalistNum = 0;

            // 初期化
            lstForFieldFormat.Clear();
            lstToDoListData.Clear();

            // リソースを解放する
            if (commToDoReadWriter != null)
            {
                commToDoReadWriter.Dispose();
            }

            // 初期化
            commToDoReadWriter = new CommToDoReadWriter(strToDoFPath, false, true);

            string strfieldname = string.Empty;
            string strTitleName = string.Empty;
            string strReadOnly = string.Empty;
            string strVisibility = string.Empty;
            string strFixColumnFlag = string.Empty;

            // ヘッダーレコードを取得する
            foreach (XElement headerElement in commToDoReadWriter.GetHeaders())
            {
                isHeadlistformatOK = true;
                foreach (XAttribute headerAttribute in headerElement.Attributes())
                {
                    if (headerAttribute.Name.LocalName.Equals(CommonConstants.FIELDNAME))
                    {
                        strfieldname = headerAttribute.Value;
                    }

                    if (headerAttribute.Name.LocalName.Equals(CommonConstants.TITLENAME))
                    {
                        strTitleName = headerAttribute.Value;
                    }

                    if (headerAttribute.Name.LocalName.Equals(CommonConstants.READONLY))
                    {
                        strReadOnly = headerAttribute.Value;
                    }

                    if (headerAttribute.Name.LocalName.Equals(CommonConstants.VISIBILITY))
                    {
                        strVisibility = headerAttribute.Value;
                    }

                    if (headerAttribute.Name.LocalName.Equals(CommonConstants.FIXCOLUMNFLAG))
                    {
                        strFixColumnFlag = headerAttribute.Value;
                    }
                }

                lstForFieldFormat_temp.Add(new FormatFieldItem()
                {
                    StrFieldName = strfieldname,
                    StrTitleName = strTitleName,
                    StrReadOnly = strReadOnly,
                    StrVisibility = strVisibility,
                    StrFixColumnFlag = strFixColumnFlag
                });

                // HeaderList項目数
                headlistNum++;
            }

            // データレコードを取得する
            foreach (XElement dataElement in commToDoReadWriter.GetDatas())
            {
                isDatalistformatOK = true;
                List<string> listempToDoListData = new List<string>();
                foreach (XAttribute dataAttribute in dataElement.Attributes())
                {
                    listempToDoListData.Add(dataAttribute.Value);

                    // dataList項目数
                    datalistNum++;
                }

                // HeaderList、DataListの件数が異なる場合
                if (isDatalistformatOK && headlistNum != datalistNum)
                {
                    throw new BusinessCommonException(UF_Fluere_MsgId.MSGID_UF40002084);
                }

                datalistNum = 0;

                lstToDoListData_temp.Add(listempToDoListData);
            }

            // 定義されたToDoフォーマット(HeaderList、DataList)形式ではない場合
            if (!isHeadlistformatOK || !isDatalistformatOK)
            {
                throw new BusinessCommonException(UF_Fluere_MsgId.MSGID_UF40002085);
            }

            lstForFieldFormat = lstForFieldFormat_temp;
            lstToDoListData = lstToDoListData_temp;
        }
        #endregion ToDoファイルの読み込み処理

        #region Todoファイルが存在するかどうか判断
        /// <summary>
        /// Todoファイルが存在するかどうか判断
        /// </summary>
        /// <param name="strOutPutPath">出力パース</param>
        /// <param name="strFileName">出力ファイル名</param>
        /// <param name="strFileNew">生成用のファイル名</param>
        /// <param name="commToDoWriteWrapper">Todoファイル出力対象</param>
        /// <param name="multiFlag">true:ファイルタイプが複数</param>
        /// <returns>ファイルの存在フラグ</returns>
        public static bool CheckTodoFileExist(string strOutPutPath, 
            string strFileName, 
            ref string strFileNew,
            CommToDoWriteWrapper commToDoWriteWrapper, 
            bool multiFlag)
        {
            bool blnFlag = false;

            if (commToDoWriteWrapper.FilePath == null || commToDoWriteWrapper.FilePath == string.Empty)
            {
                blnFlag = true;
            }
            else
            {
                string strFile = string.Empty;

                if (multiFlag)
                {
                    Predicate<string> prdFileExit = p => p.Contains(Path.GetFileNameWithoutExtension(strFileName));

                    strFile = commToDoWriteWrapper.FilesPathList.Find(prdFileExit);
                }
                else
                {
                    // ファイル名
                    strFile = commToDoWriteWrapper.FilePath;
                }

                if (strFile != null && strFile.CompareTo(string.Empty) != 0)
                {
                    int intIndex = strFile.LastIndexOf("_");

                    // 処理用のファイル名
                    strFileNew = Path.Combine(strOutPutPath, Path.GetFileNameWithoutExtension(strFileName));

                    strFileNew = strFileNew + strFile.Substring(intIndex, strFile.Length - intIndex);

                    if (File.Exists(strFileNew))
                    {
                        blnFlag = false;

                        LogUtility.WriteInfo("{0}:{1}", "【Todoリストファイル】", strFileNew);
                    }
                    else
                    {
                        blnFlag = true;
                    }
                }
                else
                {
                    blnFlag = true;
                }
            }

            return blnFlag;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Log;
using CREO.FW.Message;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 分類コードと施設物件ジャンルコードの対応ファイル
    /// </summary>
    public class TGnrPOICodeMappingFileManager
    {
        #region ログマネージャーのインスタンス、メッセージマネージャーのインスタンス
        /// <summary>
        /// ログ出力用オブジェクト
        /// </summary>
        private static LogManager _logMgr = LogManager.GetLogger(UF_Fluere_MsgId.MODULE_NUMBER);

        /// <summary>
        /// メッセージマネージャーインスタンス
        /// </summary>
        private static MessageManager _msgMgr = MessageManager.GetMessageManager(UF_Fluere_MsgId.MODULE_NUMBER);
        #endregion

        /// <summary>
        /// 分類コードと施設物件ジャンルコードの対応ファイルの読込
        /// </summary>
        /// <param name="file">分類コードと施設物件ジャンルコードの対応ファイル</param>
        /// <returns>分類コードと施設物件ジャンルコードの対応ファイルデータ</returns>
        public static List<TGnrPOICodeData> ReadTGnrPOICodeMappingFile(string file)
        {
            List<TGnrPOICodeData> dataList = new List<TGnrPOICodeData>();

            string formatFilePath = ConfigFileInfo.TGnrPOICodeMappingFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;

            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fs, xmlDef);

                while (fp.NextRecord())
                {
                    TGnrPOICodeData data = new TGnrPOICodeData();
                    dataList.Add(data);

                    // 分類コード
                    data.POICode = fp["POICode"].ToString();

                    // 親施設物件ジャンルコード
                    data.TParentGnrCode = fp["TParentGnrCode"].ToString();

                    // 子施設物件ジャンルコード
                    data.TGnrCode = fp["TGnrCode"].ToString();
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (fp != null)
                {
                    fp.Dispose();
                }

                fp = null;

                if (fs != null)
                {
                    fs.Dispose();
                }

                fs = null;
            }

            return dataList;
        }
    }
}

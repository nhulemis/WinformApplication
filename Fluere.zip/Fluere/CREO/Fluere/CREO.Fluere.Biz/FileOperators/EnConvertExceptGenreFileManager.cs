﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 英字変換対象外ジャンルファイル
    /// </summary>
    public class EnConvertExceptGenreFileManager
    {
        /// <summary>
        /// 英字変換対象外ジャンルファイルの読込
        /// </summary>
        /// <param name="filePath">英字変換対象外ジャンルファイルパス</param>
        /// <returns>英字変換対象外ジャンルデータのリスト</returns>
        public static List<EnConvertExceptGenreData> ReadEnConvertExceptGenreFile(string filePath)
        {
            List<EnConvertExceptGenreData> dataList = new List<EnConvertExceptGenreData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.EnConvertExceptGenreFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                int i = 0;

                while (fp.NextRecord())
                {
                    if (i == 0)
                    {
                        i++;
                        continue;
                    }

                    EnConvertExceptGenreData enConvertExceptGenreData = new EnConvertExceptGenreData();

                    // 親ジャンルコード
                    ushort value;
                    string p_temp = fp["P_GenreCode"] as string;

                    // 子ジャンルコード
                    string c_temp = fp["C_GenreCode"] as string;

                    // 親ジャンルコードが設定されていなければエラーとする
                    if (!ushort.TryParse(p_temp, out value))
                    {
                        throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF21003434, p_temp);
                    }

                    enConvertExceptGenreData.P_GenreCode = value;

                    // 子ジャンルコードがnullまたは空白ではないか確認する
                    if (!string.IsNullOrEmpty(c_temp))
                    {
                        enConvertExceptGenreData.C_GenreCode = Convert.ToUInt16(c_temp);
                    }

                    dataList.Add(enConvertExceptGenreData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

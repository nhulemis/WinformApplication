﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Xml.Linq;
using CREO.DataModel;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;
using CREO.Fluere.Common.Diagnostics;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;
using CREO.FW.Utilities;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 除外ジャンルコードリストファイル管理
    /// </summary>
    public class ExclusionGenreCodeListFileManager
    {
        /// <summary>
        /// ファイルの読込
        /// </summary>
        /// <param name="path">ファイルパス</param>
        /// <returns>ファイル内容</returns>
        public static List<ExclusionGenreCode> Load(string path)
        {
            var result = new List<ExclusionGenreCode>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.ExclusionGenreCodeListFile);
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(path, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    ushort pGnrCode;
                    ushort cGnrCode;
                    string p_temp = fp["P_GenreCode"] as string;
                    string c_temp = fp["C_GenreCode"] as string;

                    if (!ushort.TryParse(p_temp, out pGnrCode))
                    {
                        var param = new string[] { Path.GetFullPath(path), "親ジャンルコード", p_temp };
                        throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000005, param);
                    }

                    if (!ushort.TryParse(c_temp, out cGnrCode))
                    {
                        if (c_temp != "*")
                        {
                            var param = new string[] { Path.GetFullPath(path), "子ジャンルコード", c_temp };
                            throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000005, param);
                        }

                        result.Add(new ExclusionGenreCode(pGnrCode, null));
                        continue;
                    }

                    result.Add(new ExclusionGenreCode(pGnrCode, cGnrCode));
                }
            }
            catch (FileNotFoundException ex)
            {
                // 除外ジャンルコードリストがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF11000004;
                throw new BusinessLogicException(msgId, new string[] { Path.GetFullPath(path) }, ex);
            }
            catch (FileLoadException ex)
            {
                // 除外ジャンルコードリストがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF11000004;
                throw new BusinessLogicException(msgId, new string[] { Path.GetFullPath(path) }, ex);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return result;
        }

        /// <summary>
        /// 空間実体の物件ジャンルを参照して除外ジャンルかどうかを判定する
        /// </summary>
        /// <param name="sItem">空間実体</param>
        /// <param name="codes">除外ジャンルコードリスト</param>
        /// <returns>除外物件ジャンルの場合True</returns>
        public static bool IsExcludeGenreSItem(SItemBase sItem, List<ExclusionGenreCode> codes)
        {
            var gnrPOIAry = GetGnrPOIAry(sItem);

            if (gnrPOIAry == null || !gnrPOIAry.Any())
            {
                return false;
            }

            return gnrPOIAry.All(gnrPOI =>
            {
                return IsExclude(gnrPOI, codes);
            });
        }

        /// <summary>
        /// 依存実体の依存先の空間実体の物件ジャンルを参照して除外ジャンルかどうかを判定する
        /// </summary>
        /// <typeparam name="T">空間実体の型指定</typeparam>
        /// <param name="dItem">依存実体</param>
        /// <param name="codes">除外ジャンルコードリスト</param>
        /// <returns>除外物件ジャンルの場合True</returns>
        /// <remarks>依存先の中で指定した型の先頭の空間実体を対象に判定する</remarks>
        public static bool IsExcludeGenreDItem<T>(DItemBase dItem, List<ExclusionGenreCode> codes)
        {
            Assertion.Condition(dItem.GetDependingItems() != null);
            Assertion.Condition(dItem.GetDependingItems().OfType<T>().FirstOrDefault() != null);

            var sItem = dItem.GetDependingItems().OfType<T>().First() as SItemBase;
            return IsExcludeGenreSItem(sItem, codes);
        }

        /// <summary>
        /// 包含(除外対象外)の子物件ジャンルを取得する
        /// </summary>
        /// <param name="sItem">空間実体</param>
        /// <param name="codes">除外ジャンルコードリスト</param>
        /// <returns>包含ジャンル</returns>
        public static IEnumerable<TGnrPOI> GetIncludeChildGenre(SItemBase sItem, List<ExclusionGenreCode> codes)
        {
            var gnrPOIAry = GetGnrPOIAry(sItem);

            if (gnrPOIAry == null)
            {
                return new DMCollection<TGnrPOI>();
            }

            return gnrPOIAry.Where(gnrPOI =>
                {
                    return !IsExclude(gnrPOI, codes);
                });
        }

        /// <summary>
        /// 除外対象の目的地コードの配列インデックスを取得する
        /// </summary>
        /// <param name="sItem">空間実体</param>
        /// <param name="codes">除外ジャンルコードリスト</param>
        /// <returns>除外目的地コードの配列インデックス</returns>
        public static IEnumerable<int> GetIndexOfExcludeDstCode(SItemBase sItem, List<ExclusionGenreCode> codes)
        {
            var gnrPOIAry = GetGnrPOIAry(sItem);

            if (gnrPOIAry == null || !gnrPOIAry.Any())
            {
                return new DMCollection<int>();
            }

            return gnrPOIAry.Select((gnrPOI, i) =>
            {
                if (IsExclude(gnrPOI, codes))
                {
                    return i;
                }

                return (int?)null;
            }).Where(i => i != null).Select(i => i.Value);
        }

        /// <summary>
        /// 物件ジャンルを参照して除外ジャンルかどうかを判定する
        /// </summary>
        /// <param name="gnrPOI">物件ジャンル</param>
        /// <param name="codes">除外ジャンルコードリスト</param>
        /// <returns>除外物件ジャンルの場合True</returns>
        private static bool IsExclude(TGnrPOI gnrPOI, List<ExclusionGenreCode> codes)
        {
            if (gnrPOI.GetParentTableItems() == null || gnrPOI.GetParentTableItems().OfType<TGnrPOI>().FirstOrDefault() == null)
            {
                throw new InvalidDataException(string.Format("親物件ジャンルが取得できない物件ジャンルが存在します\tOID={0}", gnrPOI.OID));
            }

            var pGnrCode = gnrPOI.GetParentTableItems().OfType<TGnrPOI>().First().GnrCode;
            var cGnrCode = gnrPOI.GnrCode;
            return codes.Any(code =>
            {
                if (code.ChildGnrCode == null)
                {
                    return code.ParentGnrCode == pGnrCode;
                }
                else
                {
                    return code.ParentGnrCode == pGnrCode && code.ChildGnrCode == cGnrCode;
                }
            });
        }

        /// <summary>
        /// ≪物件ジャンル≫属性の特定
        /// </summary>
        /// <param name="dataModel">データモデル</param>
        /// <returns>物件ジャンル</returns>
        /// <remarks>属性が配列のモデルも存在するため共通で配列として取得する</remarks>
        private static IEnumerable<TGnrPOI> GetGnrPOIAry(GeoItem dataModel)
        {
            // ≪物件ジャンル≫属性の特定
            DMCollection<TGnrPOI> gnrPOIAry = null;
            var propertyName = "GnrPOI";
            PropertyInfo propInfo = dataModel.GetType().GetProperty(propertyName);

            if (propInfo != null)
            {
                var gnrPOI = (TGnrPOI)propInfo.GetValue(dataModel, null);

                if (gnrPOI != null)
                {
                    gnrPOIAry = new DMCollection<TGnrPOI>() { gnrPOI };
                }
            }
            else
            {
                // 属性そのものが存在しない場合に物件ジャンルが配列の可能性を考慮
                propertyName = "GnrPOIAry";
                propInfo = dataModel.GetType().GetProperty(propertyName);

                if (propInfo == null)
                {
                    throw new InvalidDataException(string.Format("物件ジャンル(TGnrPOI)属性の取得ができません。OID={0}", dataModel.OID));
                }

                gnrPOIAry = (DMCollection<TGnrPOI>)propInfo.GetValue(dataModel, null);
            }

            if (gnrPOIAry != null)
            {
                var pGnrPOIAry = gnrPOIAry.Where(gnr => gnr.NestLevel == 0);
                if (pGnrPOIAry.Any())
                {
                    LogUtility.Write(UF_Fluere_MsgId.MSGID_UF11000006, new object[] { dataModel.OID, propertyName });
                    return gnrPOIAry.Where(gnr => gnr.NestLevel != 0);
                }
            }

            return gnrPOIAry;
        }

        /// <summary>
        /// ≪目的地コード≫属性の特定
        /// </summary>
        /// <param name="dataModel">データモデル</param>
        /// <returns>目的地コード</returns>
        /// <remarks>属性が配列のモデルも存在するため共通で配列として取得する</remarks>
        private static IEnumerable<DstInfo> GetDstCodeAry(GeoItem dataModel)
        {
            // ≪目的地コード≫属性の特定
            DMCollection<DstInfo> dstCodeAry = null;
            var propertyName = "DstCode";
            PropertyInfo propInfo = dataModel.GetType().GetProperty(propertyName);

            if (propInfo != null)
            {
                var dstInfo = (DstInfo)propInfo.GetValue(dataModel, null);

                if (dstInfo != null)
                {
                    dstCodeAry = new DMCollection<DstInfo>() { dstInfo };
                }
            }
            else
            {
                // 属性そのものが存在しない場合に目的地コードが配列の可能性を考慮
                propertyName = "DstCodeAry";
                propInfo = dataModel.GetType().GetProperty(propertyName);

                if (propInfo == null)
                {
                    throw new InvalidDataException(string.Format("目的地コード(DstInfo)属性の取得ができません。OID={0}", dataModel.OID));
                }

                dstCodeAry = (DMCollection<DstInfo>)propInfo.GetValue(dataModel, null);
            }

            return dstCodeAry;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 接頭語接尾語変換設定ファイルの読込
    /// </summary>
    public class HeadTailConvertFileManager
    {
        /// <summary>
        /// 接頭語接尾語変換設定ファイルの読込
        /// </summary>
        /// <param name="filePath">接頭語接尾語変換設定ファイルパス</param>
        /// <returns>HeadTailConvertDataリスト</returns>
        public static List<HeadTailConvertData> Read(string filePath)
        {
            List<HeadTailConvertData> result = new List<HeadTailConvertData>();

            XElement xmlDef = null;
            FileStream stream = null;
            FileParser fp = null;

            try
            {
                // フォーマットファイル存在チェック
                if (!File.Exists(ConfigFileInfo.HeadTailConvertFormatFile))
                {
                    // フォーマットファイルがオープン出来ない場合
                    throw new FileNotFoundException();
                }

                // バイナリファイルFormat
                xmlDef = XElement.Load(ConfigFileInfo.HeadTailConvertFormatFile);

                // ファイル読込
                stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);

                // バイナリファイル作成
                fp = new FileParser(stream, xmlDef);

                // バイナリファイル読む
                while (fp.NextRecord())
                {
                    if (fp.RowIndex == 1)
                    {
                        continue;
                    }

                    HeadTailConvertData data = new HeadTailConvertData();

                    if (!string.IsNullOrWhiteSpace(fp["VoiceType"].ToString()))
                    {
                        // 音声の区分
                        data.VoiceType = Convert.ToInt32(fp["VoiceType"]);
                    }

                    if (!string.IsNullOrWhiteSpace(fp["CharPosition"].ToString()))
                    {
                        // 文字位置
                        data.CharPosition = Convert.ToInt32(fp["CharPosition"]);
                    }

                    if (!string.IsNullOrWhiteSpace(fp["KanjiStr"].ToString()))
                    {
                        // 漢字文字列
                        data.KanjiStr = (string)fp["KanjiStr"];
                    }

                    if (!string.IsNullOrWhiteSpace(fp["KanaStr"].ToString()))
                    {
                        // カナ文字列
                        data.KanaStr = (string)fp["KanaStr"];
                    }

                    result.Add(data);
                }

                fp.Close();
                stream.Close();
            }
            catch (FrameworkException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // 手動でメモリを解放する
                if (fp != null)
                {
                    fp.Dispose();
                }

                if (stream != null)
                {
                    stream.Dispose();
                }
            }

            return result;
        }
    }
}

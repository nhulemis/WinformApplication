﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// VICSリンクファイルの読込
    /// </summary>
    public class VICSLinkFileManager
    {
        #region VICSリンクファイルの読込
        /// <summary>
        /// VICSリンクファイルの読込
        /// </summary>
        /// <param name="filePath">VICSリンクファイルパス</param>
        /// <returns>VICSリンクファイルデータリスト</returns>
        public static List<VICSLinkFileData> ReadVICSLinkFile(string filePath)
        {
            XElement xmlDef = null;
            FileStream stream = null;
            FileParser fp = null;
            List<VICSLinkFileData> retList = new List<VICSLinkFileData>();
            try
            {
                // フォーマットファイル存在チェック
                if (!File.Exists(ConfigFileInfo.VICSLinkFormatFile))
                {
                    // フォーマットファイルがオープン出来ない場合
                    string msgId = UF_Fluere_MsgId.MSGID_UF10000168;
                    throw new BusinessLogicException(msgId, new string[] { ConfigFileInfo.VICSLinkFormatFile });
                }

                // バイナリファイルFormat
                xmlDef = XElement.Load(ConfigFileInfo.VICSLinkFormatFile);

                // ファイル読込
                stream = new FileStream(filePath, FileMode.Open, FileAccess.Read);

                // バイナリファイル作成
                fp = new FileParser(stream, xmlDef);

                Dictionary<string, VICSLinkFileData> continueDict = new Dictionary<string, VICSLinkFileData>();

                // バイナリファイル読む
                while (fp.NextRecord())
                {
                    // レコードID
                    ushort curRecordID = Convert.ToUInt16(fp["RecordID"]);

                    // レコードIDが"81"固定
                    if (curRecordID != VICSLinkFileData.Code.RecordID_81)
                    {
                        continue;
                    }

                    // リンク区分
                    byte curLinkDiff = Convert.ToByte(fp["LinkDiff"]);

                    // VICSリンク番号(二次メッシュ内では、リンク区分毎に、一意の番号)
                    int curVICSLinkNo = Convert.ToInt32(fp["VICSLinkNo"]);

                    // 継続レコード番号
                    byte curContinueRecordNo = Convert.ToByte(fp["ContinueRecordNo"]);

                    string continueKey = string.Format("{0},{1},{2}", curRecordID, curLinkDiff, curVICSLinkNo);
                    bool bIsContinue = false;

                    VICSLinkFileData vicsLinkFileData = new VICSLinkFileData();
                    if (continueDict.ContainsKey(continueKey))
                    {
                        vicsLinkFileData = continueDict[continueKey];
                        bIsContinue = true;
                    }
                    else
                    {
                        continueDict.Add(continueKey, vicsLinkFileData);
                    }

                    if (!bIsContinue)
                    {
                        if (!string.IsNullOrWhiteSpace(fp["RecordID"].ToString()))
                        {
                            // レコードID
                            vicsLinkFileData.RecordID = Convert.ToUInt16(fp["RecordID"]);
                        }

                        if (!string.IsNullOrWhiteSpace(fp["ContinueRecordNo"].ToString()))
                        {
                            // 継続レコード番号
                            vicsLinkFileData.ContinueRecordNo = Convert.ToByte(fp["ContinueRecordNo"]);
                        }

                        if (!string.IsNullOrWhiteSpace(fp["LinkDiff"].ToString()))
                        {
                            // リンク区分
                            vicsLinkFileData.LinkDiff = Convert.ToByte(fp["LinkDiff"]);
                        }

                        if (!string.IsNullOrWhiteSpace(fp["VICSLinkNo"].ToString()))
                        {
                            // VICSリンク番号
                            vicsLinkFileData.VICSLinkNo = Convert.ToInt32(fp["VICSLinkNo"]);
                        }

                        if (!string.IsNullOrWhiteSpace(fp["UpdateCode"].ToString()))
                        {
                            // 更新コード
                            vicsLinkFileData.UpdateCode = Convert.ToByte(fp["UpdateCode"]);
                        }

                        if (!string.IsNullOrWhiteSpace(fp["AddNewLinkCode"].ToString()))
                        {
                            // 新規追加リンク識別コード
                            vicsLinkFileData.AddNewLinkCode = Convert.ToByte(fp["AddNewLinkCode"]);
                        }

                        // 流入側ノード情報---基本道路ノード番号
                        vicsLinkFileData.InflowBasicRoadNodeNo = (string)fp["InflowBasicRoadNodeNo"];

                        if (!string.IsNullOrWhiteSpace(fp["InflowBasicRoadNodeKbn"].ToString()))
                        {
                            // 流入側ノード情報---基本道路ノード種別
                            vicsLinkFileData.InflowBasicRoadNodeKbn = Convert.ToByte(fp["InflowBasicRoadNodeKbn"]);
                        }

                        if (!string.IsNullOrWhiteSpace(fp["InflowCrossPointDis"].ToString()))
                        {
                            // 流入側ノード情報---統合交差点識別
                            vicsLinkFileData.InflowCrossPointDis = Convert.ToByte(fp["InflowCrossPointDis"]);
                        }

                        // 流出側ノード情報---基本道路ノード番号
                        vicsLinkFileData.OutflowBasicRoadNodeNo = (string)fp["OutflowBasicRoadNodeNo"];

                        if (!string.IsNullOrWhiteSpace(fp["OutflowBasicRoadNodeKbn"].ToString()))
                        {
                            // 流出側ノード情報---基本道路ノード種別
                            vicsLinkFileData.OutflowBasicRoadNodeKbn = Convert.ToByte(fp["OutflowBasicRoadNodeKbn"]);
                        }

                        if (!string.IsNullOrWhiteSpace(fp["OutflowCrossPointDis"].ToString()))
                        {
                            // 流出側ノード情報---統合交差点識別
                            vicsLinkFileData.OutflowCrossPointDis = Convert.ToByte(fp["OutflowCrossPointDis"]);
                        }

                        if (!string.IsNullOrWhiteSpace(fp["NodeDataCount"].ToString()))
                        {
                            // 構成基本道路ノードデータ総数
                            vicsLinkFileData.NodeDataCount = Convert.ToInt32(fp["NodeDataCount"]);
                        }

                        // フィラー
                        vicsLinkFileData.Filler = (string)fp["Filler"];

                        if (!string.IsNullOrWhiteSpace(fp["ContinueFlag"].ToString()))
                        {
                            // 継続フラグ
                            vicsLinkFileData.ContinueFlag = Convert.ToByte(fp["ContinueFlag"]);
                        }
                    }

                    int maxIndex = 45;

                    if (vicsLinkFileData.NodeDataCount.HasValue)
                    {
                        if (!bIsContinue)
                        {
                            vicsLinkFileData.BasicRoadNodeSeqList.Capacity = vicsLinkFileData.NodeDataCount.Value;
                        }

                        if (vicsLinkFileData.NodeDataCount.Value < 45)
                        {
                            maxIndex = vicsLinkFileData.NodeDataCount.Value;
                        }
                    }

                    // 構成基本道路ノード列（１～４５）
                    for (int i = 1; i <= maxIndex; i++)
                    {
                        string colunmName = "BasicRoadNodeSeq" + i.ToString();

                        string value = (string)fp[colunmName];

                        if (!string.IsNullOrWhiteSpace(value))
                        {
                            vicsLinkFileData.BasicRoadNodeSeqList.Add(value);
                        }
                    }

                    if (!bIsContinue)
                    {
                        retList.Add(vicsLinkFileData);
                    }
                }

                fp.Close();
                stream.Close();
            }
            catch (FrameworkException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                // 手動でメモリを解放する
                if (fp != null)
                {
                    fp.Dispose();
                }

                if (stream != null)
                {
                    stream.Dispose();
                }
            }

            return retList;
        }
        #endregion
    }
}

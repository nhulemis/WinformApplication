﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using CREO.Fluere.Common.DataSources.Linq;
using CREO.Fluere.Common.DataSources.OpenXml;
using CREO.Fluere.Biz.FileOperators.Data;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 目印取得基準リストファイル管理クラス
    /// </summary>
    public class MarkObtainStandardListFileManager
    {
        /// <summary>
        /// シート名
        /// </summary>
        private const string SHEET_NAME = @"Sheet1";

        #region 目印取得基準リストファイルを読み込み-TMIs
        /// <summary>
        /// 目印取得基準リストファイルを読み込み
        /// </summary>
        /// <param name="filePath">目印取得基準リストファイルパス</param>
        /// <returns>目印取得基準リストファイル</returns>
        public static List<MarkObtainStandardListData> ReadMarkGetStandardList(string filePath)
        {   
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(filePath))
            {
                throw new FileNotFoundException(filePath);
            }

            // 戻りリスト
            List<MarkObtainStandardListData> markObtainStandardListDataList =
                new List<MarkObtainStandardListData>();

            // 読込結果の整形
            using (SpreadSheetDataRepository repository = new SpreadSheetDataRepository(
                    filePath, CultureInfo.InvariantCulture, false, false))
            {
                repository.Open();

                // ファイルの読込
                IEnumerable<object[]> context = repository.Target(SHEET_NAME);

                int lineNum = 0;
                foreach (object[] record in context)
                {
                    lineNum++;

                    // データインスタンス
                    MarkObtainStandardListData markObtainData = new MarkObtainStandardListData();

                    bool bEffective = false;

                    // 目印コード
                    if (record.Length > 0 && null != record[0])
                    {
                        markObtainData.MarkCode = record[0].ToString();
                        bEffective = true;
                    }

                    // NTT分類コード
                    if (record.Length > 1 && null != record[1])
                    {
                        markObtainData.NTTGroupCode = record[1].ToString();
                        bEffective = true;
                    }

                    // 漢字掲載名
                    if (record.Length > 2 && null != record[2])
                    {
                        markObtainData.KanjiName = record[2].ToString();
                        bEffective = true;
                    }

                    // カナ掲載名
                    if (record.Length > 3 && null != record[3])
                    {
                        markObtainData.KanaName = record[3].ToString();
                        bEffective = true;
                    }

                    // 目印調査要否
                    if (record.Length > 4 && null != record[4])
                    {
                        markObtainData.ConfirmFlag = record[4].ToString();
                        bEffective = true;
                    }

                    // カーディーラー(レクサス、トヨタ以外)
                    if (record.Length > 5 && null != record[5])
                    {
                        markObtainData.CarDealerFlag = record[5].ToString();
                        bEffective = true;
                    }

                    if (bEffective)
                    {
                        markObtainData.LineNum = lineNum;
                        markObtainStandardListDataList.Add(markObtainData);
                    }
                }
            }

            return markObtainStandardListDataList;
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.BusinessObject;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 今回出典-スクールゾーンファイル-外国人以外管理クラス
    /// </summary>
    public class SchoolzoneFileManager
    {
        #region 出典-スクールゾーンデータの読込
        /// <summary>
        /// 出典-スクールゾーンデータの読込
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="readKbn">読込区分:0 外国人 1 外国人以外 2 変更なし外国人 3 変更なし外国人以外 </param>
        /// <returns>出典-スクールゾーンデータリスト</returns>
        public static List<SchoolzoneFileData> ReadSchoolzoneFile(string filePath, string readKbn)
        {
            // 出典-スクールゾーンデータリスト
            List<SchoolzoneFileData> schoolzoneFileDataList = new List<SchoolzoneFileData>();

            // 出典差分･今回出典･前回出典･外国人･外国人以外スクールゾーンファイルの定義ファイル
            string formatFilePath = ConfigFileInfo.SchoolZoneDataFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;

            try
            {
                // ファイルが存在するか確認
                if (!System.IO.File.Exists(filePath))
                {
                    throw new FileNotFoundException(filePath);
                }

                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fs, xmlDef);

                while (fp.NextRecord())
                {
                    SchoolzoneFileData schoolzoneFileData = new SchoolzoneFileData();

                    // 差分区分
                    string diffKbn = fp["DiffKbn"].ToString();
                    if (!string.IsNullOrEmpty(readKbn))
                    {
                        CheckDiffFlg(diffKbn, readKbn);

                        switch (readKbn)
                        {
                            case "0":
                                // 読込むファイル区分
                                schoolzoneFileData.FileType = "F";
                                break;
                            case "1":
                                // 読込むファイル区分
                                schoolzoneFileData.FileType = "L";
                                break;
                            case "2":
                                // 読込むファイル区分
                                schoolzoneFileData.FileType = "FN";
                                break;
                            case "3":
                                // 読込むファイル区分
                                schoolzoneFileData.FileType = "LN";
                                break;
                            default:
                                // 読込むファイル区分
                                schoolzoneFileData.FileType = string.Empty;
                                break;
                        }
                    }

                    schoolzoneFileData.DiffKbn = diffKbn;

                    // 差分明細
                    schoolzoneFileData.DiffDetail = fp["DiffDetail"].ToString();

                    // 施設物件拡張のOID
                    schoolzoneFileData.FacilityMExOID = fp["FacilityMExOID"].ToString();

                    // 出典ID
                    schoolzoneFileData.MaterialID = fp["MaterialID"].ToString();

                    // 物件住所（漢字）
                    schoolzoneFileData.ResidenceKanji = fp["ResidenceKanji"].ToString();

                    // 電話番号
                    schoolzoneFileData.PhoneNum = fp["PhoneNum"].ToString();

                    // 正式漢字名称
                    schoolzoneFileData.FormalKanjiNm = fp["FormalKanjiNm"].ToString();

                    // 正式カナ名称
                    schoolzoneFileData.FormalKanaNm = fp["FormalKanaNm"].ToString();

                    // 表示漢字名称
                    schoolzoneFileData.DisplayKanjiNm = fp["DisplayKanjiNm"].ToString();

                    // 2次メッシュコード
                    schoolzoneFileData.TwiceMeshCd = fp["TwiceMeshCd"].ToString();

                    // 絶対座標：東経
                    schoolzoneFileData.EastLongitude = fp["EastLongitude"].ToString();

                    // 絶対座標：北緯
                    schoolzoneFileData.NorthLatitude = fp["NorthLatitude"].ToString();

                    schoolzoneFileDataList.Add(schoolzoneFileData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fs != null)
                    {
                        fs.Dispose();
                    }
                }
                finally
                {
                    fs = null;
                }
            }

            return schoolzoneFileDataList;
        }
        #endregion

        #region 出典-スクールゾーンデータの書き込み
        /// <summary>
        /// 出典-スクールゾーンデータの書き込み
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="dataList">出典-スクールゾーンデータリスト</param>
        public static void WriteSchoolzoneFile(string filePath, List<SchoolzoneFileData> dataList)
        {
            // 出典差分･今回出典･前回出典･外国人･外国人以外スクールゾーンファイルの定義ファイル
            string formatFilePath = ConfigFileInfo.SchoolZoneDataFile;

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (SchoolzoneFileData fileData in dataList)
                {
                    fp.AddRecord();

                    SetCurData(fp, fileData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion

        #region 出典-スクールゾーンデータの書き込み
        /// <summary>
        /// 出典-スクールゾーンデータの書き込み
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="dataList">出典-スクールゾーンデータリスト</param>
        public static void ModifySchoolzoneFile(string filePath, List<SchoolzoneFileData> dataList)
        {
            // 出典差分･今回出典･前回出典･外国人･外国人以外スクールゾーンファイルの定義ファイル
            string formatFilePath = ConfigFileInfo.SchoolZoneDataFile;

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.ReadWrite);
                fp = new FileParser(fstream, xmlDef);

                foreach (SchoolzoneFileData fileData in dataList)
                {
                    fp.AppendRecord();

                    SetCurData(fp, fileData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion

        #region 差分区分チェック
        /// <summary>
        /// 差分区分チェック
        /// </summary>
        /// <param name="value">差分区分値</param>
        /// <param name="readKbn">:0 外国人 1 外国人以外 2 変更なし外国人 3 変更なし外国人以外</param>
        private static void CheckDiffFlg(string value, string readKbn)
        {
            if (!string.IsNullOrEmpty(value) || !string.IsNullOrWhiteSpace(value))
            {
                switch (readKbn)
                {
                    case "0":
                        if (("N" != value) && ("C" != value) && ("D" != value))
                        {
                            throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF10000123,
                                new string[] { "出典差分-スクールゾーンファイル-外国人ファイル", "差分区分-DiffFlg" });
                        }

                        break;
                    case "1":
                        if (("N" != value) && ("C" != value) && ("D" != value))
                        {
                            throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF10000125, new string[] { "出典差分-スクールゾーンファイル-外国人以外ファイル", "差分区分-DiffFlg" });
                        }

                        break;
                    case "2":
                        if (!string.IsNullOrEmpty(value) || !string.IsNullOrWhiteSpace(value))
                        {
                            throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF10000145,
                                new string[] { "出典差分-スクールゾーン変更なしファイル-外国人ファイル", "差分区分-DiffFlg" });
                        }

                        break;
                    case "3":
                        if (!string.IsNullOrEmpty(value) || !string.IsNullOrWhiteSpace(value))
                        {
                            throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF10000146,
                                new string[] { "出典差分-スクールゾーン変更なしファイル-外国人以外ファイル", "差分区分-DiffFlg" });
                        }

                        break;
                    default:
                        break;
                }
            }
        }
        #endregion

        #region  一つデータを設定する
        /// <summary>
        /// 一つデータを設定する
        /// </summary>
        /// <param name="fp">ファイルパーサ</param>
        /// <param name="fileData">出典-スクールゾーンデータ</param>
        private static void SetCurData(FileParser fp, SchoolzoneFileData fileData)
        {
            // 差分区分
            if (string.IsNullOrEmpty(fileData.DiffKbn))
            {
                fp["DiffKbn"] = string.Empty;
            }
            else
            {
                fp["DiffKbn"] = fileData.DiffKbn;
            }

            // 差分明細
            if (string.IsNullOrEmpty(fileData.DiffDetail))
            {
                fp["DiffDetail"] = string.Empty;
            }
            else
            {
                fp["DiffDetail"] = fileData.DiffDetail;
            }

            // 施設物件拡張のOID
            if (string.IsNullOrEmpty(fileData.FacilityMExOID))
            {
                fp["FacilityMExOID"] = string.Empty;
            }
            else
            {
                fp["FacilityMExOID"] = fileData.FacilityMExOID;
            }

            // 出典ID
            if (string.IsNullOrEmpty(fileData.MaterialID))
            {
                fp["MaterialID"] = string.Empty;
            }
            else
            {
                fp["MaterialID"] = fileData.MaterialID;
            }

            // 物件住所（漢字）
            if (string.IsNullOrEmpty(fileData.ResidenceKanji))
            {
                fp["ResidenceKanji"] = string.Empty;
            }
            else
            {
                fp["ResidenceKanji"] = fileData.ResidenceKanji;
            }

            // 電話番号
            if (string.IsNullOrEmpty(fileData.PhoneNum))
            {
                fp["PhoneNum"] = string.Empty;
            }
            else
            {
                fp["PhoneNum"] = fileData.PhoneNum;
            }

            // 正式漢字名称
            if (string.IsNullOrEmpty(fileData.FormalKanjiNm))
            {
                fp["FormalKanjiNm"] = string.Empty;
            }
            else
            {
                fp["FormalKanjiNm"] = fileData.FormalKanjiNm;
            }

            // 正式カナ名称
            if (string.IsNullOrEmpty(fileData.FormalKanaNm))
            {
                fp["FormalKanaNm"] = string.Empty;
            }
            else
            {
                fp["FormalKanaNm"] = fileData.FormalKanaNm;
            }

            // 表示漢字名称
            if (string.IsNullOrEmpty(fileData.DisplayKanjiNm))
            {
                fp["DisplayKanjiNm"] = string.Empty;
            }
            else
            {
                fp["DisplayKanjiNm"] = fileData.DisplayKanjiNm;
            }

            // 2次メッシュコード
            if (string.IsNullOrEmpty(fileData.TwiceMeshCd))
            {
                fp["TwiceMeshCd"] = string.Empty;
            }
            else
            {
                fp["TwiceMeshCd"] = fileData.TwiceMeshCd;
            }

            // 絶対座標：東経
            if (string.IsNullOrEmpty(fileData.EastLongitude))
            {
                fp["EastLongitude"] = string.Empty;
            }
            else
            {
                fp["EastLongitude"] = fileData.EastLongitude;
            }

            // 絶対座標：北緯
            if (string.IsNullOrEmpty(fileData.NorthLatitude))
            {
                fp["NorthLatitude"] = string.Empty;
            }
            else
            {
                fp["NorthLatitude"] = fileData.NorthLatitude;
            }

            // ファイルパーサーにアップデート
            fp.Update();
        }
        #endregion
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Log;
using CREO.FW.Message;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 高速路線ファイル
    /// </summary>
    public class TRouteHwFileManager
    {
        /// <summary>
        /// 高速路線ファイルの読込
        /// </summary>
        /// <param name="file">高速路線ファイル</param>
        /// <returns>高速路線ファイルデータ</returns>
        public static List<TRouteHwData> ReadTRouteHwFile(string file)
        {
            List<TRouteHwData> dataList = new List<TRouteHwData>();

            string formatFilePath = ConfigFileInfo.TRouteHwFormatFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;

            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fs, xmlDef);

                string strRouteHwTemp = string.Empty;
                string strOutputTemp = string.Empty;

                while (fp.NextRecord())
                {
                    TRouteHwData data = new TRouteHwData();

                    if (string.IsNullOrEmpty((string)fp["TRouteHwOID"]) == false)
                    {
                        if (string.IsNullOrEmpty((string)fp["IsOutputTRouteHw"]))
                        {
                            // 入力必須項目「高速路線の出力対象」が入力されない場合
                            string msgId = UF_Fluere_MsgId.MSGID_UF00000002;
                            string[] parameters = new string[] { "高速路線の出力対象" };

                            throw new BusinessLogicException(msgId, parameters);
                        }

                        TRouteHwData tRouteHwData = dataList.Find(p => p.TRouteHwOID == (string)fp["TRouteHwOID"]);

                        // 高速路線の重複データが存在するか判断
                        if (tRouteHwData != null)
                        {
                            // 高速路線の重複フラグ
                            data.IsDuplicateOfTRouteHw = true;
                        }

                        strRouteHwTemp = (string)fp["TRouteHwOID"];
                        strOutputTemp = (string)fp["IsOutputTRouteHw"];

                        // 高速路線OID
                        data.TRouteHwOID = (string)fp["TRouteHwOID"];

                        // 高速路線OIDが出力対象フラグ
                        data.IsOutputTRouteHw = (string)fp["IsOutputTRouteHw"];
                    }
                    else
                    {
                        // 高速路線OID
                        data.TRouteHwOID = strRouteHwTemp;

                        // 高速路線OIDが出力対象フラグ
                        data.IsOutputTRouteHw = strOutputTemp;
                    }

                    // 高速施設OID
                    if (string.IsNullOrEmpty((string)fp["TFacilityHwOID"]) == false)
                    {
                        if (string.IsNullOrEmpty((string)fp["IsOutputTFacilityHw"]))
                        {
                            // 入力必須項目「高速路線の出力対象」が入力されない場合
                            string msgId = UF_Fluere_MsgId.MSGID_UF00000002;
                            string[] parameters = new string[] { "高速施設の出力対象" };

                            throw new BusinessLogicException(msgId, parameters);
                        }

                        TRouteHwData tFacilityHwData = dataList.Find(p => p.TFacilityHwOID == (string)fp["TFacilityHwOID"]);

                        // 高速施設の重複データが存在するか判断
                        if (tFacilityHwData != null)
                        {
                            // 高速施設の重複フラグ
                            data.IsDuplicateOfTFacilityHw = true;
                        }

                        data.TFacilityHwOID = (string)fp["TFacilityHwOID"];
                    }

                    // 高速施設OIDが出力対象フラグ
                    if (string.IsNullOrEmpty((string)fp["IsOutputTFacilityHw"]) == false)
                    {
                        data.IsOutputTFacilityHw = (string)fp["IsOutputTFacilityHw"];
                    }

                    dataList.Add(data);
                }
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (fp != null)
                {
                    fp.Dispose();
                }

                fp = null;

                if (fs != null)
                {
                    fs.Dispose();
                }

                fs = null;
            }

            return dataList;
        }
    }
}

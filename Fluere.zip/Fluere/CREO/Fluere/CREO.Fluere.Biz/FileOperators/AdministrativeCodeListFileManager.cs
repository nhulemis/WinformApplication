﻿using System.IO;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 市区町村リストファイルを読み込み
    /// </summary>
    public static class AdministrativeCodeListFileManager
    {
        /// <summary>
        /// 市区町村リストファイルを読み込み
        /// </summary>
        /// <param name="filePath">市区町村リストファイルパス</param>
        /// <returns>市区町村リストファイル</returns>
        public static AdministrativeCodeListFileData ReadAdministrativeCodeList(string filePath)
        {
            try
            {
                // ファイルが存在するか確認
                if (!File.Exists(filePath))
                {
                    throw new FileNotFoundException();
                }

                // 市区町村リストファイル初期化
                AdministrativeCodeListFileData adminListData = new AdministrativeCodeListFileData();

                // テキストファイル読込む
                string content = FileUtil.ReadFile(filePath);

                // 市区町村コード分割
                string[] stringLines = StringUtil.SpiltToLines(content);

                // adminListData.AdministrativeCodeList = new List<string>();
                // コードリスト作成
                foreach (string currentLine in stringLines)
                {
                    string admin = currentLine.Trim();
                    if (!string.IsNullOrWhiteSpace(admin))
                    {
                        if (!adminListData.AdministrativeCodeList.Contains(admin))
                        {
                            adminListData.AdministrativeCodeList.Add(admin);
                        }
                    }
                }

                return adminListData;
            }
            catch (FileNotFoundException ex)
            {
                // 市区町村リストファイルがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000046;
                throw new BusinessLogicException(msgId, new string[] { filePath }, ex);
            }
            catch (FileLoadException ex)
            {
                // 市区町村リストファイルがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000046;
                throw new BusinessLogicException(msgId, new string[] { filePath }, ex);
            }
        }
    }
}
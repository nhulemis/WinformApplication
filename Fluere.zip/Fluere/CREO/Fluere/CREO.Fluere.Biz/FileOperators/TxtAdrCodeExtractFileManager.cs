﻿using System;
using System.IO;
using System.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 住所コード付与対象リストファイル読み込み管理クラス
    /// </summary>
    public class TxtAdrCodeExtractFileManager
    {
        /// <summary>
        /// テキスト住所コード付与対象リストファイルを読み込む。
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="splitCode">区切り文字</param>
        /// <param name="hasHeader">ヘッダー有無</param>
        /// <param name="inputMaxLine">入力列の最大値(純粋に設定されている値の最大値でよい)</param>
        /// <param name="outputMaxLine">出力列の最大値</param>
        /// <param name="coordLine">座標設定の入力列(nullの場合はチェックしない)</param>
        /// <param name="is2Mesh">true：２次メッシュ相対座標; false：絶対座標</param>
        /// <returns>設定値チェック済みの1ファイルから読み込んだ情報</returns>
        public static TxtAdrCodeExtractFileDataContainer Load(
            string filePath,
            char splitCode,
            bool hasHeader,
            int inputMaxLine,
            int outputMaxLine,
            int? coordLine,
            bool is2Mesh)
        {
            // 戻り値定義
            var fileInfo = new TxtAdrCodeExtractFileDataContainer();

            string content = string.Empty;
            try
            {
                // ファイルを読み込む
                content = FileUtil.ReadFile(filePath);
            }
            catch (IOException ex)
            {
                // テキスト住所コード付与対象リストファイルがオープン出来ません
                string msgId = UF_Fluere_MsgId.MSGID_UF40002128;
                string[] parameters = new string[] { Path.GetFullPath(filePath) };
                throw new BusinessLogicException(msgId, parameters, ex);
            }

            if (!hasHeader)
            {
                CheckContent(filePath);
            }

            // 行データの分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // テキスト住所コード付与対象リストファイルに、データが存在チェック
            if (hasHeader)
            {
                CheckContent(filePath, stringLines.Count());
            }

            // 列数
            int lineCount = 0;
            for (int i = 0; i < stringLines.Count(); i++)
            {
                // 行番号
                int rowID = i + 1;

                // 行データ
                string currentLine = stringLines[i];

                // 行単位、指定された文字列の配列の要素で区切る
                string[] rowDataStr = currentLine.Split(splitCode);

                if (hasHeader && i == 0)
                {
                    LogUtility.WriteTrace("【▼ヘッダ行有り、ヘッダが処理対象以外】");

                    // ヘッダ行有り場合、一行目のヘッダを格納
                    fileInfo.Header = rowDataStr.ToList<string>();
                    continue;
                }

                // 実際列数
                lineCount = rowDataStr.Length;

                // 入力列、出力列の整合性チェック
                CheckInputLine(inputMaxLine, coordLine, is2Mesh, lineCount);
                CheckOutLine(lineCount, outputMaxLine);

                if (lineCount > 0)
                {
                    var column = new TxtAdrCodeExtractFileData(rowID);

                    LogUtility.WriteTrace("【▼列数】{0}", lineCount);

                    if (coordLine != null)
                    {
                        // 有効座標であるかをチェックする
                        CheckValidCoordinate(column, rowDataStr, rowID, coordLine.Value, is2Mesh);
                    }

                    column.Columns = rowDataStr.ToList<string>();
                    fileInfo.Datas.Add(column);
                }
            }

            return fileInfo;
        }

        #region 入力対象のデータが存在するかをチェックする

        /// <summary>
        /// チェック データが存在
        /// </summary>
        /// <param name="fileName">入力ファイル</param>
        private static void CheckContent(string fileName)
        {
            FileInfo cFileInfo = new FileInfo(fileName);
            if (cFileInfo.Length == 0)
            {
                LogUtility.WriteTrace("【▼テキスト住所コード付与対象リストファイルに、データが存在しない】入力ファイル{0}", fileName);
                string msgID = UF_Fluere_MsgId.MSGID_UF40002141;
                throw new BusinessLogicException(msgID);
            }
        }

        /// <summary>
        /// チェック データが存在
        /// </summary>
        /// <param name="fileName">入力ファイル</param>
        /// <param name="rowCount">行数</param>
        private static void CheckContent(string fileName, int rowCount)
        {
            if (rowCount < 2)
            {
                LogUtility.WriteTrace("【▼テキスト住所コード付与対象リストファイルに、データが存在しない】入力ファイル{0}", fileName);
                string msgID = UF_Fluere_MsgId.MSGID_UF40002141;
                throw new BusinessLogicException(msgID);
            }
        }

        #endregion 入力対象のデータが存在するかをチェックする

        #region 列指定の整合性チェック

        /// <summary>
        /// 入力列指定の設定値チェック
        /// </summary>
        /// <param name="inputMaxLine">入力列指定の最大値</param>
        /// <param name="coordLine">入力列指定(座標列)</param>
        /// <param name="is2Mesh">true:２次メッシュ相対座標;false:絶対座標</param>
        /// <param name="lineCount">実際列数</param>
        private static void CheckInputLine(
            int inputMaxLine,
            int? coordLine,
            bool is2Mesh,
            int lineCount)
        {
            if (inputMaxLine > lineCount)
            {
                // テキスト住所コード付与設定ファイルに、入力ファイルの最大列番号より大きな値が出力列指定で設定されている場合
                string msgID = UF_Fluere_MsgId.MSGID_UF40002140;
                string[] parameters =
                    new string[] { inputMaxLine.ToString(), lineCount.ToString() };
                throw new BusinessLogicException(msgID, parameters);
            }

            if (coordLine != null)
            {
                if (is2Mesh)
                {
                    //// 2次メッシュ相対座標の場合
                    if (coordLine > lineCount - 2)
                    {
                        // テキスト住所コード付与設定ファイルに、入力ファイルの最大列番号-2より大きな値が入力列指定(座標)で設定されている場合
                        string msgID = UF_Fluere_MsgId.MSGID_UF40002140;
                        string[] parameters =
                            new string[] { coordLine.ToString(), lineCount.ToString() };
                        throw new BusinessLogicException(msgID, parameters);
                    }
                }
                else
                {
                    //// 絶対座標の場合
                    if (coordLine > lineCount - 1)
                    {
                        // テキスト住所コード付与設定ファイルに、入力ファイルの最大列番号-1より大きな値が入力列指定(座標)で設定されている場合
                        string msgID = UF_Fluere_MsgId.MSGID_UF40002140;
                        string[] parameters =
                            new string[] { coordLine.ToString(), lineCount.ToString() };
                        throw new BusinessLogicException(msgID, parameters);
                    }
                }
            }
        }

        /// <summary>
        /// 出力列指定の設定値チェック
        /// </summary>
        /// <param name="lineCount">実際列数</param>
        /// <param name="maxOutLine">出力列指定の最大値</param>
        private static void CheckOutLine(int lineCount, int maxOutLine)
        {
            if (maxOutLine > lineCount)
            {
                // テキスト住所コード付与設定ファイルに、入力ファイルの最大列番号より大きな値が出力列指定で設定されている場合
                string msgID = UF_Fluere_MsgId.MSGID_UF40002142;
                string[] parameters =
                    new string[] { maxOutLine.ToString(), lineCount.ToString() };
                throw new BusinessLogicException(msgID, parameters);
            }
        }

        #endregion 列指定の整合性チェック

        #region 座標設定値の整合性チェック

        /// <summary>
        /// 座標設定値の整合性をチェックする。
        /// </summary>
        /// <param name="column">1項目の格納エンティティ</param>
        /// <param name="rowDataStr">1行分のデータ</param>
        /// <param name="rowID">行番号</param>
        /// <param name="coordLine">座標設定の入力列</param>
        /// <param name="is2Mesh">true：２次メッシュ相対座標; false：絶対座標</param>
        private static void CheckValidCoordinate(TxtAdrCodeExtractFileData column, string[] rowDataStr, int rowID, int coordLine, bool is2Mesh)
        {
            string meshCode = string.Empty;
            string longitude = string.Empty;
            string latitude = string.Empty;

            if (is2Mesh)
            {
                // 指定した列番号データを左から、2次メッシュ・座標ｘ・座標ｙのデータとして連続的に三つ列のデータを読み込む
                meshCode = rowDataStr[coordLine - 1];

                // チェック meshCode
                if (!IsMeshCode(rowID, meshCode))
                {
                    LogUtility.WriteTrace("【▼2次メッシュの値が無効である場合】{0}", meshCode);

                    // 座標点をエラー座標点としてフラグを付ける。
                    column.ErrorFlg = true;
                }

                // チェック 経度,緯度
                longitude = rowDataStr[coordLine];
                latitude = rowDataStr[coordLine + 1];
                if (IsLongitudeLatitude(rowID, longitude, latitude))
                {
                    LogUtility.WriteTrace("【▼座標が有効】longitude:{0};latitude{1}", longitude, latitude);
                    column.MeshCode = meshCode;
                    column.Longitude = long.Parse(longitude);
                    column.Latitude = long.Parse(latitude);
                }
                else
                {
                    LogUtility.WriteTrace("【▼座標が無効】longitude:{0};latitude{1}", longitude, latitude);

                    // 座標点をエラー座標点としてフラグを付ける。
                    column.ErrorFlg = true;
                }
            }
            else
            {
                // チェック 経度,緯度
                longitude = rowDataStr[coordLine - 1];
                latitude = rowDataStr[coordLine];
                if (IsLongitudeLatitude(rowID, longitude, latitude))
                {
                    LogUtility.WriteTrace("【▼座標が有効】longitude:{0};latitude{1}", longitude, latitude);

                    // 指定した列番号データを左から、座標ｘ・座標ｙののデータとして連続的に二つ列のデータを読み込む
                    column.Longitude = long.Parse(longitude);
                    column.Latitude = long.Parse(latitude);
                }
                else
                {
                    LogUtility.WriteTrace("【▼座標が無効】longitude:{0};latitude{1}", longitude, latitude);

                    // 座標点をエラー座標点としてフラグを付ける。
                    column.ErrorFlg = true;
                }
            }
        }

        /// <summary>
        /// 2次メッシュの設定値の有効性をチェックする
        /// </summary>
        /// <param name="rowID">rowID</param>
        /// <param name="meshCode">入力列指定</param>
        /// <returns>true:2次メッシュの値が有効である；false:無効</returns>
        private static bool IsMeshCode(int rowID, string meshCode)
        {
            bool isIsMeshCode = true;
            if (string.IsNullOrEmpty(meshCode) || meshCode.Length != 6)
            {
                // テキスト住所コード付与対象リストファイルに、2次メッシュの値が無効である場合
                string msgID = UF_Fluere_MsgId.MSGID_UF40002133;
                string[] parameters = new string[] { rowID.ToString(), meshCode };
                LogUtility.Write(msgID, parameters);
                isIsMeshCode = false;
            }

            try
            {
                int.Parse(meshCode);
            }
            catch (Exception)
            {
                // テキスト住所コード付与対象リストファイルに、2次メッシュの値が無効である場合
                string msgID = UF_Fluere_MsgId.MSGID_UF40002133;
                string[] parameters = new string[] { rowID.ToString(), meshCode };
                LogUtility.Write(msgID, parameters);
                isIsMeshCode = false;
            }

            return isIsMeshCode;
        }

        /// <summary>
        /// 経緯度設定値のチェック
        /// </summary>
        /// <param name="rowID">rowID</param>
        /// <param name="longitude">経度</param>
        /// <param name="latitude">緯度</param>
        /// <returns>true:座標が有効;false:座標が無効;</returns>
        private static bool IsLongitudeLatitude(int rowID, string longitude, string latitude)
        {
            string msgID = string.Empty;
            string[] parameters;
            if (string.IsNullOrEmpty(longitude))
            {
                // テキスト住所コード付与対象リストファイルに、座標xがありません
                msgID = UF_Fluere_MsgId.MSGID_UF40002131;
                parameters = new string[] { rowID.ToString() };
                LogUtility.Write(msgID, parameters);
                return false;
            }

            if (string.IsNullOrEmpty(latitude))
            {
                // テキスト住所コード付与対象リストファイルに、座標yがありません
                msgID = UF_Fluere_MsgId.MSGID_UF40002132;
                parameters = new string[] { rowID.ToString() };
                LogUtility.Write(msgID, parameters);
                return false;
            }

            try
            {
                long.Parse(longitude);
            }
            catch (Exception)
            {
                // テキスト住所コード付与対象リストファイルに、座標xが無効な値です
                msgID = UF_Fluere_MsgId.MSGID_UF40002134;
                parameters = new string[] { rowID.ToString(), longitude };
                LogUtility.Write(msgID, parameters);
                return false;
            }

            try
            {
                long.Parse(latitude);
            }
            catch (Exception)
            {
                // テキスト住所コード付与対象リストファイルに、座標yが無効な値です
                msgID = UF_Fluere_MsgId.MSGID_UF40002135;
                parameters = new string[] { rowID.ToString(), latitude };
                LogUtility.Write(msgID, parameters);
                return false;
            }

            return true;
        }

        #endregion 座標設定値の整合性チェック
    }
}
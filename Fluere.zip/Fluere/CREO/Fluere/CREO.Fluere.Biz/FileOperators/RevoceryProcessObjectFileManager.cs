﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// コンテンツリカバリ処理対象リストファイル
    /// </summary>
    public class RevoceryProcessObjectFileManager
    {
        /// <summary>
        /// コンテンツリカバリ処理対象リストファイルを読み込み
        /// </summary>
        /// <param name="filePath">コンテンツリカバリ処理対象リストファイルパス</param>
        /// <returns>コンテンツリカバリ処理対象リストファイルリスト</returns>
        public static List<RevoceryProcessObjectFileData> ReadRevoceryProcessObjectFileData(string filePath)
        {
            List<RevoceryProcessObjectFileData> dataList = new List<RevoceryProcessObjectFileData>();

            string formatFilePath = ConfigFileInfo.RevoceryProcessObjectDataFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    RevoceryProcessObjectFileData areaNameData = new RevoceryProcessObjectFileData();

                    // 抽出コンテンツ和称
                    areaNameData.OutPutDataName = fp["OutPutDataName"].ToString();

                    // 抽出コンテンツ英名
                    areaNameData.OutPutDataEnglish = fp["OutPutDataEnglish"].ToString();

                    // 入力チェック
                    if (!string.IsNullOrEmpty(areaNameData.OutPutDataName) || !string.IsNullOrEmpty(areaNameData.OutPutDataEnglish))
                    {
                        dataList.Add(areaNameData);
                    }
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 調査原稿テキストファイル（Pingo連携用）
    /// </summary>
    public class SearchInfoPingoFileManager
    {
        #region 調査原稿テキストファイル（Pingo連携用）作成
        /// <summary>
        /// 調査原稿テキストファイル（Pingo連携用作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="searchInfoPingoList">調査原稿テキストリスト</param>
        public static void WriteSurveyManuscriptPingoToDoFile(
            string filePath,
            string formatFilePath,
            List<SearchInfoPingoData> searchInfoPingoList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (
                    SearchInfoPingoData surveyManuscriptPingo in searchInfoPingoList)
                {
                    fp.AddRecord();

                    #region 交差点目印
                    // 2次メッシュコード
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.MeshCode))
                    {
                        fp["MeshCode"] = string.Empty;
                    }
                    else
                    {
                        fp["MeshCode"] = surveyManuscriptPingo.MeshCode;
                    }

                    // 交差点データ番号
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.CrsDataNumber))
                    {
                        fp["CrsDataNumber"] = string.Empty;
                    }
                    else
                    {
                        fp["CrsDataNumber"] = surveyManuscriptPingo.CrsDataNumber;
                    }

                    // 目印連番
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.Crs_MarkSpate))
                    {
                        fp["Crs_MarkSpate"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_MarkSpate"] = surveyManuscriptPingo.Crs_MarkSpate;
                    }

                    // 目印名称
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.Crs_MarkName))
                    {
                        fp["Crs_MarkName"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_MarkName"] = surveyManuscriptPingo.Crs_MarkName;
                    }

                    // 目印コード
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.Crs_MarkCode))
                    {
                        fp["Crs_MarkCode"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_MarkCode"] = surveyManuscriptPingo.Crs_MarkCode;
                    }

                    // 経度
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.Crs_Longitude))
                    {
                        fp["Crs_Longitude"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_Longitude"] = surveyManuscriptPingo.Crs_Longitude;
                    }

                    // 緯度
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.Crs_Latitude))
                    {
                        fp["Crs_Latitude"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_Latitude"] = surveyManuscriptPingo.Crs_Latitude;
                    }

                    // プロット番号
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.PlotNo))
                    {
                        fp["PlotNo"] = string.Empty;
                    }
                    else
                    {
                        fp["PlotNo"] = surveyManuscriptPingo.PlotNo;
                    }

                    #endregion

                    #region タウン物件の情報

                    // 経度
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.STwn_Longitude))
                    {
                        fp["STwn_Longitude"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_Longitude"] = surveyManuscriptPingo.STwn_Longitude;
                    }

                    // 緯度
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.STwn_Latitude))
                    {
                        fp["STwn_Latitude"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_Latitude"] = surveyManuscriptPingo.STwn_Latitude;
                    }

                    #endregion

                    #region 施設物件

                    // 経度
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.SPOI_Longitude))
                    {
                        fp["SPOI_Longitude"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_Longitude"] = surveyManuscriptPingo.SPOI_Longitude;
                    }

                    // 緯度
                    if (string.IsNullOrEmpty(surveyManuscriptPingo.SPOI_Latitude))
                    {
                        fp["SPOI_Latitude"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_Latitude"] = surveyManuscriptPingo.SPOI_Latitude;
                    }

                    #endregion

                    // ファイルパーサーにアップデート
                    fp.Update();
                }
            }
            catch (Exception)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000211;
                throw new BusinessLogicException(msgId, new string[] { filePath });
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion
    }
}
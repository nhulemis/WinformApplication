﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 特殊街区の大字小字変換ログファイル
    /// </summary>
    public class GaikuConvertLogFileManager
    {
        #region 特殊街区の大字小字変換ログファイル作成
        /// <summary>
        /// 特殊街区の大字小字変換ログファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="gaikuConvertDataList">特殊街区の大字小字変換ログリスト</param>
        public static void WriteGaikuConvertLogToDoFile(
            string filePath,
            string formatFilePath,
            List<GaikuConvertData> gaikuConvertDataList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (
                    GaikuConvertData gaikuConvertData in gaikuConvertDataList)
                {
                    fp.AddRecord();

                    // 変換前の住所コード
                    if (string.IsNullOrEmpty(gaikuConvertData.OldSAdrPntCode))
                    {
                        fp["OldSAdrPntCode"] = string.Empty;
                    }
                    else
                    {
                        fp["OldSAdrPntCode"] = gaikuConvertData.OldSAdrPntCode;
                    }

                    // 変換前の住所名称
                    if (string.IsNullOrEmpty(gaikuConvertData.OldAdrNameCode))
                    {
                        fp["OldAdrNameCode"] = string.Empty;
                    }
                    else
                    {
                        fp["OldAdrNameCode"] = gaikuConvertData.OldAdrNameCode;
                    }

                    // 変換後の住所コード
                    if (string.IsNullOrEmpty(gaikuConvertData.NewSAdrPntCode))
                    {
                        fp["NewSAdrPntCode"] = string.Empty;
                    }
                    else
                    {
                        fp["NewSAdrPntCode"] = gaikuConvertData.NewSAdrPntCode;
                    }

                    // 変換後の住所名称
                    if (string.IsNullOrEmpty(gaikuConvertData.NewAdrNameCode))
                    {
                        fp["NewAdrNameCode"] = string.Empty;
                    }
                    else
                    {
                        fp["NewAdrNameCode"] = gaikuConvertData.NewAdrNameCode;
                    }

                    // 住所代表点のOID
                    if (string.IsNullOrEmpty(gaikuConvertData.SAdrPntOID))
                    {
                        fp["SAdrPntOID"] = string.Empty;
                    }
                    else
                    {
                        fp["SAdrPntOID"] = gaikuConvertData.SAdrPntOID;
                    }

                    // 住所代表点の座標の経度
                    if (string.IsNullOrEmpty(gaikuConvertData.SAdrPntLongitude))
                    {
                        fp["SAdrPntLongitude"] = string.Empty;
                    }
                    else
                    {
                        fp["SAdrPntLongitude"] = gaikuConvertData.SAdrPntLongitude;
                    }

                    // 住所代表点の座標の緯度
                    if (string.IsNullOrEmpty(gaikuConvertData.SAdrPntLatitude))
                    {
                        fp["SAdrPntLatitude"] = string.Empty;
                    }
                    else
                    {
                        fp["SAdrPntLatitude"] = gaikuConvertData.SAdrPntLatitude;
                    }

                    // ファイルパーサーにアップデート
                    fp.Update();
                }
            }
            catch (Exception ex)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF20001007;
                throw new BusinessLogicException(msgId, new string[] { filePath }, ex);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion
    }
}
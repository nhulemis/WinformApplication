﻿using System.IO;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 比較対象外文字リストファイル読み込み
    /// </summary>
    public class TwnAdrExclusionCharactersFileManager
    {
        #region 比較対象外文字リストファイル読み込み
        /// <summary>
        /// 比較対象外文字リストファイル読み込み
        /// </summary>
        /// <param name="addressNoCompareFilePath">比較対象外文字ファイルパス</param>
        /// <returns>比較対象外文字リストファイルデータ</returns>
        public static TwnAdrExclusionCharactersData ReadAdrExclusionCharacters(string addressNoCompareFilePath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(addressNoCompareFilePath))
            {
                throw new FileNotFoundException();
            }

            // 比較対象外文字ファイルデータ初期化
            TwnAdrExclusionCharactersData addressNoCompareListData = new TwnAdrExclusionCharactersData();

            // テキストファイル読込む
            string content = FileUtil.ReadFile(addressNoCompareFilePath);

            // 比較対象外文字分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // コードリスト作成
            foreach (string currentLine in stringLines)
            {
                string address = currentLine.Trim();
                if (!string.IsNullOrWhiteSpace(address))
                {
                    addressNoCompareListData.AddNoCompareList.Add(address);
                }
            }

            return addressNoCompareListData;
        }
    }
        #endregion
}

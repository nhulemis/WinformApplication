﻿using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 施設物件リスト管理クラス
    /// </summary>
    public class FacilityListManager
    {
        /// <summary>
        /// 施設物件リスト読み込み
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <returns>施設物件リスト</returns>
        public static List<FacilityListData> ReadFacilityList(string filePath)
        {
            var dataList = new List<FacilityListData>();

            // 施設物件リスト読み込み
            var xmlDef = XElement.Load(ConfigFileInfo.FacilityListFormatFile);
            using (var fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read))
            {
                using (var fp = new FileParser(fstream, xmlDef))
                {
                    // 1レコードずつ処理
                    while (fp.NextRecord())
                    {
                        // データ格納
                        var data = new FacilityListData()
                        {
                            WorkType = fp["WorkType"] as string,
                            OID = fp["OID"] as string,
                            InquestObjectId = fp["InquestObjectId"] as string,
                            GnrCode = fp["GnrCode"] as string,
                            OpenDate = fp["OpenDate"] as string,
                            DispNameCheckCode = fp["DispNameCheckCode"] as string,
                            DispNameKanji = fp["DispNameKanji"] as string,
                            DispNameKana = fp["DispNameKana"] as string,
                            DispNameEnglish = fp["DispNameEnglish"] as string,
                            DispNameTraditional = fp["DispNameTraditional"] as string,
                            DispNameSimplified = fp["DispNameSimplified"] as string,
                            DispNameHangle = fp["DispNameHangle"] as string,
                            FormalNameKanji = fp["FormalNameKanji"] as string,
                            FormalNameKana = fp["FormalNameKana"] as string,
                            FormalNameEnglish = fp["FormalNameEnglish"] as string,
                            FormalNameTraditional = fp["FormalNameTraditional"] as string,
                            FormalNameSimplified = fp["FormalNameSimplified"] as string,
                            FormalNameHangle = fp["FormalNameHangle"] as string,
                            PrefecturesCode = fp["PrefecturesCode"] as string,
                            MunicipalityCode = fp["MunicipalityCode"] as string,
                            OazaCode = fp["OazaCode"] as string,
                            KoazaCode = fp["KoazaCode"] as string,
                            AdrKanjiName = fp["AdrKanjiName"] as string,
                            SAdrPntLongitude = fp["SAdrPntLongitude"] as string,
                            SAdrPntLatitude = fp["SAdrPntLatitude"] as string,
                            ArrivalPntLongitude = fp["ArrivalPntLongitude"] as string,
                            ArrivalPntLatitude = fp["ArrivalPntLatitude"] as string,
                            RoadOID = fp["RoadOID"] as string,
                            ArrivalDirLongitude = fp["ArrivalDirLongitude"] as string,
                            ArrivalDirLatitude = fp["ArrivalDirLatitude"] as string,
                            CampgroundInfo0 = fp["CampgroundInfo0"] as string,
                            CampSite = fp["CampSite"] as string,
                            CeremonyHallInfo0 = fp["CeremonyHallInfo0"] as string,
                            CeremonyHallInfo1 = fp["CeremonyHallInfo1"] as string,
                            CeremonyHallInfo2 = fp["CeremonyHallInfo2"] as string,
                            CommonInfo0 = fp["CommonInfo0"] as string,
                            CommonInfo1 = fp["CommonInfo1"] as string,
                            CommonInfo2 = fp["CommonInfo2"] as string,
                            CommonInfo3 = fp["CommonInfo3"] as string,
                            CommonInfo4 = fp["CommonInfo4"] as string,
                            CommonInfo5 = fp["CommonInfo5"] as string,
                            CommonInfo6 = fp["CommonInfo6"] as string,
                            ContactName = fp["ContactName"] as string,
                            ContactTel = fp["ContactTel"] as string,
                            GolfCourse = fp["GolfCourse"] as string,
                            GolfHall = fp["GolfHall"] as string,
                            GolfInfo0 = fp["GolfInfo0"] as string,
                            GolfInfo1 = fp["GolfInfo1"] as string,
                            GolfInfo2 = fp["GolfInfo2"] as string,
                            GolfInfo3 = fp["GolfInfo3"] as string,
                            GolfPar = fp["GolfPar"] as string,
                            HallInfo0 = fp["HallInfo0"] as string,
                            HallInfo1 = fp["HallInfo1"] as string,
                            HallInfo2 = fp["HallInfo2"] as string,
                            HeadCopy = fp["HeadCopy"] as string,
                            HospitalInfo0 = fp["HospitalInfo0"] as string,
                            HospitalInfo1 = fp["HospitalInfo1"] as string,
                            HospitalInfo2 = fp["HospitalInfo2"] as string,
                            HotelInfo0 = fp["HotelInfo0"] as string,
                            HotelRoom = fp["HotelRoom"] as string,
                            Introduction = fp["Introduction"] as string,
                            CrsMarkCode = fp["CrsMarkCode"] as string,
                            HWFacilityName = fp["HWFacilityName"] as string,
                            StationFacilityName = fp["StationFacilityName"] as string,
                            FerryFacilityName = fp["FerryFacilityName"] as string,
                            ParkArea = fp["ParkArea"] as string,
                            ParkInfo0 = fp["ParkInfo0"] as string,
                            ParkInfo1 = fp["ParkInfo1"] as string,
                            RateStructureCode = fp["RateStructureCode"] as string,
                            SAPAMemo = fp["SAPAMemo"] as string,
                            SellTypeCode = fp["SellTypeCode"] as string,
                            ShoppingMallArea = fp["ShoppingMallArea"] as string,
                            ShoppingMallInfo0 = fp["ShoppingMallInfo0"] as string,
                            ShrineInfo0 = fp["ShrineInfo0"] as string,
                            SpaInfo0 = fp["SpaInfo0"] as string,
                            SpaInfo1 = fp["SpaInfo1"] as string,
                            TelInfoAry = fp["TelInfoAry"] as string,
                            ToyotaDealerInfo0 = fp["ToyotaDealerInfo0"] as string,
                            ToyotaDealerInfo1 = fp["ToyotaDealerInfo1"] as string,
                            URL = fp["URL"] as string,
                            WeddingInfo0 = fp["WeddingInfo0"] as string,
                            WeddingInfo1 = fp["WeddingInfo1"] as string,
                            WellnessID = fp["WellnessID"] as string,
                            ShoppingCenterFlg = fp["ShoppingCenterFlg"] as string,
                            ClosedStartDay = fp["ClosedStartDay"] as string,
                            ClosedEndDay = fp["ClosedEndDay"] as string,
                            RestRoom = fp["RestRoom"] as string,
                            BarrierFree = fp["BarrierFree"] as string,
                            ParkingLot = fp["ParkingLot"] as string,
                            Open24h = fp["Open24h"] as string,
                            YearHalfClosed = fp["YearHalfClosed"] as string,
                            SSignTxtViewDispNameKanji = fp["SSignTxtViewDispNameKanji"] as string,
                            SSignTxtViewDispNameKana = fp["SSignTxtViewDispNameKana"] as string,
                            SSignTxtViewTxtTypCode = fp["SSignTxtViewTxtTypCode"] as string,
                            SSignTxtViewDeliveryDateStr = fp["SSignTxtViewDeliveryDateStr"] as string,
                            SSignTxtViewBankInfo0 = fp["SSignTxtViewBankInfo0"] as string,
                            SSignTxtViewCommonInfo0 = fp["SSignTxtViewCommonInfo0"] as string,
                            SSignTxtViewCommonInfo1 = fp["SSignTxtViewCommonInfo1"] as string,
                            SSignTxtViewCommonInfo2 = fp["SSignTxtViewCommonInfo2"] as string,
                            SSignTxtViewCommonInfo3 = fp["SSignTxtViewCommonInfo3"] as string,
                            SSignTxtViewContactName = fp["SSignTxtViewContactName"] as string,
                            SSignTxtViewContactTel = fp["SSignTxtViewContactTel"] as string,
                            SSignTxtViewPostOfficeInfo0 = fp["SSignTxtViewPostOfficeInfo0"] as string,
                            SSignTxtViewSchoolInfo0 = fp["SSignTxtViewSchoolInfo0"] as string,
                            SSignTxtViewToyotaSupplierCode = fp["SSignTxtViewToyotaSupplierCode"] as string,
                            InquestMemo = fp["InquestMemo"] as string,
                        };
                        dataList.Add(data);
                    }
                }
            }

            return dataList;
        }

        /// <summary>
        /// 施設物件リスト書き込み
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="dataList">施設物件リスト</param>
        public static void WriteFacilityList(string filePath, List<FacilityListData> dataList)
        {
            var formatFilePath = ConfigFileInfo.FacilityListFormatFile;
            var xmlDef = XElement.Load(formatFilePath);
            using (var fstream = new FileStream(filePath, FileMode.Create, FileAccess.Write))
            {
                using (var fp = new FileParser(fstream, xmlDef))
                {
                    foreach (var fileData in dataList)
                    {
                        fp.AddRecord();
                        SetData(fp, fileData);
                    }
                }
            }
        }

        /// <summary>
        /// 1レコード分のデータを設定
        /// </summary>
        /// <param name="fp">ファイルパーサ―</param>
        /// <param name="fileData">施設物件リスト</param>
        private static void SetData(FileParser fp, FacilityListData fileData)
        {
            fp["WorkType"] = fileData.WorkType;
            fp["OID"] = fileData.OID;
            fp["InquestObjectId"] = fileData.InquestObjectId;
            fp["GnrCode"] = fileData.GnrCode;
            fp["OpenDate"] = fileData.OpenDate;
            fp["DispNameCheckCode"] = fileData.DispNameCheckCode;
            fp["DispNameKanji"] = fileData.DispNameKanji;
            fp["DispNameKana"] = fileData.DispNameKana;
            fp["DispNameEnglish"] = fileData.DispNameEnglish;
            fp["DispNameTraditional"] = fileData.DispNameTraditional;
            fp["DispNameSimplified"] = fileData.DispNameSimplified;
            fp["DispNameHangle"] = fileData.DispNameHangle;
            fp["FormalNameKanji"] = fileData.FormalNameKanji;
            fp["FormalNameKana"] = fileData.FormalNameKana;
            fp["FormalNameEnglish"] = fileData.FormalNameEnglish;
            fp["FormalNameTraditional"] = fileData.FormalNameTraditional;
            fp["FormalNameSimplified"] = fileData.FormalNameSimplified;
            fp["FormalNameHangle"] = fileData.FormalNameHangle;
            fp["PrefecturesCode"] = fileData.PrefecturesCode;
            fp["MunicipalityCode"] = fileData.MunicipalityCode;
            fp["OazaCode"] = fileData.OazaCode;
            fp["KoazaCode"] = fileData.KoazaCode;
            fp["AdrKanjiName"] = fileData.AdrKanjiName;
            fp["SAdrPntLongitude"] = fileData.SAdrPntLongitude;
            fp["SAdrPntLatitude"] = fileData.SAdrPntLatitude;
            fp["ArrivalPntLongitude"] = fileData.ArrivalPntLongitude;
            fp["ArrivalPntLatitude"] = fileData.ArrivalPntLatitude;
            fp["RoadOID"] = fileData.RoadOID;
            fp["ArrivalDirLongitude"] = fileData.ArrivalDirLongitude;
            fp["ArrivalDirLatitude"] = fileData.ArrivalDirLatitude;
            fp["CampgroundInfo0"] = fileData.CampgroundInfo0;
            fp["CampSite"] = fileData.CampSite;
            fp["CeremonyHallInfo0"] = fileData.CeremonyHallInfo0;
            fp["CeremonyHallInfo1"] = fileData.CeremonyHallInfo1;
            fp["CeremonyHallInfo2"] = fileData.CeremonyHallInfo2;
            fp["CommonInfo0"] = fileData.CommonInfo0;
            fp["CommonInfo1"] = fileData.CommonInfo1;
            fp["CommonInfo2"] = fileData.CommonInfo2;
            fp["CommonInfo3"] = fileData.CommonInfo3;
            fp["CommonInfo4"] = fileData.CommonInfo4;
            fp["CommonInfo5"] = fileData.CommonInfo5;
            fp["CommonInfo6"] = fileData.CommonInfo6;
            fp["ContactName"] = fileData.ContactName;
            fp["ContactTel"] = fileData.ContactTel;
            fp["GolfCourse"] = fileData.GolfCourse;
            fp["GolfHall"] = fileData.GolfHall;
            fp["GolfInfo0"] = fileData.GolfInfo0;
            fp["GolfInfo1"] = fileData.GolfInfo1;
            fp["GolfInfo2"] = fileData.GolfInfo2;
            fp["GolfInfo3"] = fileData.GolfInfo3;
            fp["GolfPar"] = fileData.GolfPar;
            fp["HallInfo0"] = fileData.HallInfo0;
            fp["HallInfo1"] = fileData.HallInfo1;
            fp["HallInfo2"] = fileData.HallInfo2;
            fp["HeadCopy"] = fileData.HeadCopy;
            fp["HospitalInfo0"] = fileData.HospitalInfo0;
            fp["HospitalInfo1"] = fileData.HospitalInfo1;
            fp["HospitalInfo2"] = fileData.HospitalInfo2;
            fp["HotelInfo0"] = fileData.HotelInfo0;
            fp["HotelRoom"] = fileData.HotelRoom;
            fp["Introduction"] = fileData.Introduction;
            fp["CrsMarkCode"] = fileData.CrsMarkCode;
            fp["HWFacilityName"] = fileData.HWFacilityName;
            fp["StationFacilityName"] = fileData.StationFacilityName;
            fp["FerryFacilityName"] = fileData.FerryFacilityName;
            fp["ParkArea"] = fileData.ParkArea;
            fp["ParkInfo0"] = fileData.ParkInfo0;
            fp["ParkInfo1"] = fileData.ParkInfo1;
            fp["RateStructureCode"] = fileData.RateStructureCode;
            fp["SAPAMemo"] = fileData.SAPAMemo;
            fp["SellTypeCode"] = fileData.SellTypeCode;
            fp["ShoppingMallArea"] = fileData.ShoppingMallArea;
            fp["ShoppingMallInfo0"] = fileData.ShoppingMallInfo0;
            fp["ShrineInfo0"] = fileData.ShrineInfo0;
            fp["SpaInfo0"] = fileData.SpaInfo0;
            fp["SpaInfo1"] = fileData.SpaInfo1;
            fp["TelInfoAry"] = fileData.TelInfoAry;
            fp["ToyotaDealerInfo0"] = fileData.ToyotaDealerInfo0;
            fp["ToyotaDealerInfo1"] = fileData.ToyotaDealerInfo1;
            fp["URL"] = fileData.URL;
            fp["WeddingInfo0"] = fileData.WeddingInfo0;
            fp["WeddingInfo1"] = fileData.WeddingInfo1;
            fp["WellnessID"] = fileData.WellnessID;
            fp["ShoppingCenterFlg"] = fileData.ShoppingCenterFlg;
            fp["ClosedStartDay"] = fileData.ClosedStartDay;
            fp["ClosedEndDay"] = fileData.ClosedEndDay;
            fp["RestRoom"] = fileData.RestRoom;
            fp["BarrierFree"] = fileData.BarrierFree;
            fp["ParkingLot"] = fileData.ParkingLot;
            fp["Open24h"] = fileData.Open24h;
            fp["YearHalfClosed"] = fileData.YearHalfClosed;
            fp["SSignTxtViewDispNameKanji"] = fileData.SSignTxtViewDispNameKanji;
            fp["SSignTxtViewDispNameKana"] = fileData.SSignTxtViewDispNameKana;
            fp["SSignTxtViewTxtTypCode"] = fileData.SSignTxtViewTxtTypCode;
            fp["SSignTxtViewDeliveryDateStr"] = fileData.SSignTxtViewDeliveryDateStr;
            fp["SSignTxtViewBankInfo0"] = fileData.SSignTxtViewBankInfo0;
            fp["SSignTxtViewCommonInfo0"] = fileData.SSignTxtViewCommonInfo0;
            fp["SSignTxtViewCommonInfo1"] = fileData.SSignTxtViewCommonInfo1;
            fp["SSignTxtViewCommonInfo2"] = fileData.SSignTxtViewCommonInfo2;
            fp["SSignTxtViewCommonInfo3"] = fileData.SSignTxtViewCommonInfo3;
            fp["SSignTxtViewContactName"] = fileData.SSignTxtViewContactName;
            fp["SSignTxtViewContactTel"] = fileData.SSignTxtViewContactTel;
            fp["SSignTxtViewPostOfficeInfo0"] = fileData.SSignTxtViewPostOfficeInfo0;
            fp["SSignTxtViewSchoolInfo0"] = fileData.SSignTxtViewSchoolInfo0;
            fp["SSignTxtViewToyotaSupplierCode"] = fileData.SSignTxtViewToyotaSupplierCode;
            fp["InquestMemo"] = fileData.InquestMemo;

            // ファイルパーサーにアップデート
            fp.Update();
        }
    }
}

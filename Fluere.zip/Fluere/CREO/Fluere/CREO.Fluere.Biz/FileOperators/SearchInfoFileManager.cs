﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 調査原稿テキストファイル
    /// </summary>
    public class SearchInfoFileManager
    {
        #region 調査原稿テキストファイル作成
        /// <summary>
        /// 調査原稿テキストファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="searchInfoDataList">調査原稿テキストリスト</param>
        public static void WriteSurveyManuscriptTextToDoFile(
            string filePath,
            string formatFilePath,
            List<SearchInfoData> searchInfoDataList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (
                    SearchInfoData surveyManuscriptText in searchInfoDataList)
                {
                    fp.AddRecord();

                    #region 交差点目印
                    // 2次メッシュコード
                    if (string.IsNullOrEmpty(surveyManuscriptText.MeshCode))
                    {
                        fp["MeshCode"] = string.Empty;
                    }
                    else
                    {
                        fp["MeshCode"] = surveyManuscriptText.MeshCode;
                    }

                    // 交差点データ番号
                    if (string.IsNullOrEmpty(surveyManuscriptText.CrsDataNumber))
                    {
                        fp["CrsDataNumber"] = string.Empty;
                    }
                    else
                    {
                        fp["CrsDataNumber"] = surveyManuscriptText.CrsDataNumber;
                    }

                    // 目印連番
                    if (string.IsNullOrEmpty(surveyManuscriptText.Crs_MarkSpate))
                    {
                        fp["Crs_MarkSpate"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_MarkSpate"] = surveyManuscriptText.Crs_MarkSpate;
                    }

                    // 目印コード
                    if (string.IsNullOrEmpty(surveyManuscriptText.Crs_MarkCode))
                    {
                        fp["Crs_MarkCode"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_MarkCode"] = surveyManuscriptText.Crs_MarkCode;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.Crs_KANAName))
                    {
                        fp["Crs_KANAName"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_KANAName"] = surveyManuscriptText.Crs_KANAName;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.Crs_KanJiNames))
                    {
                        fp["Crs_KanJiNames"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_KanJiNames"] = surveyManuscriptText.Crs_KanJiNames;
                    }

                    // 経度
                    if (string.IsNullOrEmpty(surveyManuscriptText.Crs_Longitude))
                    {
                        fp["Crs_Longitude"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_Longitude"] = surveyManuscriptText.Crs_Longitude;
                    }

                    // 緯度
                    if (string.IsNullOrEmpty(surveyManuscriptText.Crs_Latitude))
                    {
                        fp["Crs_Latitude"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_Latitude"] = surveyManuscriptText.Crs_Latitude;
                    }

                    // 交差点目印のOID
                    if (string.IsNullOrEmpty(surveyManuscriptText.CrsMarkOID))
                    {
                        fp["CrsMarkOID"] = string.Empty;
                    }
                    else
                    {
                        fp["CrsMarkOID"] = surveyManuscriptText.CrsMarkOID;
                    }

                    // メンテナンス日
                    if (string.IsNullOrEmpty(surveyManuscriptText.MaintenanceDay))
                    {
                        fp["MaintenanceDay"] = string.Empty;
                    }
                    else
                    {
                        fp["MaintenanceDay"] = surveyManuscriptText.MaintenanceDay;
                    }

                    // プロット番号
                    if (string.IsNullOrEmpty(surveyManuscriptText.PlotNo))
                    {
                        fp["PlotNo"] = string.Empty;
                    }
                    else
                    {
                        fp["PlotNo"] = surveyManuscriptText.PlotNo;
                    }

                    #endregion

                    #region タウン物件の情報

                    // OID
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_STwnPOIOID))
                    {
                        fp["STwn_STwnPOIOID"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_STwnPOIOID"] = surveyManuscriptText.STwn_STwnPOIOID;
                    }

                    // 市外局番
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_AreaNo))
                    {
                        fp["STwn_AreaNo"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_AreaNo"] = surveyManuscriptText.STwn_AreaNo;
                    }

                    // 電話番号
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_TelNumber))
                    {
                        fp["STwn_TelNumber"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_TelNumber"] = surveyManuscriptText.STwn_TelNumber;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_KANAName_1))
                    {
                        fp["STwn_KANAName_1"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_KANAName_1"] = surveyManuscriptText.STwn_KANAName_1;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_KanJiNames_1))
                    {
                        fp["STwn_KanJiNames_1"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_KanJiNames_1"] = surveyManuscriptText.STwn_KanJiNames_1;
                    }

                    // 基本分類コード
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_GnrTwnCode))
                    {
                        fp["STwn_GnrTwnCode"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_GnrTwnCode"] = surveyManuscriptText.STwn_GnrTwnCode;
                    }

                    // 基本分類名
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_GnrTwnName))
                    {
                        fp["STwn_GnrTwnName"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_GnrTwnName"] = surveyManuscriptText.STwn_GnrTwnName;
                    }

                    // NTT分類コード
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_NTTCode))
                    {
                        fp["STwn_NTTCode"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_NTTCode"] = surveyManuscriptText.STwn_NTTCode;
                    }

                    // NTT分類名
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_NTTName))
                    {
                        fp["STwn_NTTName"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_NTTName"] = surveyManuscriptText.STwn_NTTName;
                    }

                    // 目印コード
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_MarkCode))
                    {
                        fp["STwn_MarkCode"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_MarkCode"] = surveyManuscriptText.STwn_MarkCode;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_KANAName_2))
                    {
                        fp["STwn_KANAName_2"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_KANAName_2"] = surveyManuscriptText.STwn_KANAName_2;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.STwn_KanJiNames_2))
                    {
                        fp["STwn_KanJiNames_2"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_KanJiNames_2"] = surveyManuscriptText.STwn_KanJiNames_2;
                    }

                    #endregion

                    #region 施設物件

                    // OID
                    if (string.IsNullOrEmpty(surveyManuscriptText.SPOI_SPOIFacilityOID))
                    {
                        fp["SPOI_SPOIFacilityOID"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_SPOIFacilityOID"] = surveyManuscriptText.SPOI_SPOIFacilityOID;
                    }

                    // 電話番号
                    if (string.IsNullOrEmpty(surveyManuscriptText.SPOI_TelNumber))
                    {
                        fp["SPOI_TelNumber"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_TelNumber"] = surveyManuscriptText.SPOI_TelNumber;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.SPOI_KANAName))
                    {
                        fp["SPOI_KANAName"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_KANAName"] = surveyManuscriptText.SPOI_KANAName;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.SPOI_KanJiNames))
                    {
                        fp["SPOI_KanJiNames"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_KanJiNames"] = surveyManuscriptText.SPOI_KanJiNames;
                    }

                    #endregion

                    #region 物件ジャンル

                    // OID
                    if (string.IsNullOrEmpty(surveyManuscriptText.Gnr_GnrTwnOID))
                    {
                        fp["Gnr_GnrTwnOID"] = string.Empty;
                    }
                    else
                    {
                        fp["Gnr_GnrTwnOID"] = surveyManuscriptText.Gnr_GnrTwnOID;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.Gnr_KANAName))
                    {
                        fp["Gnr_KANAName"] = string.Empty;
                    }
                    else
                    {
                        fp["Gnr_KANAName"] = surveyManuscriptText.Gnr_KANAName;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(surveyManuscriptText.Gnr_KanJiNames))
                    {
                        fp["Gnr_KanJiNames"] = string.Empty;
                    }
                    else
                    {
                        fp["Gnr_KanJiNames"] = surveyManuscriptText.Gnr_KanJiNames;
                    }

                    #endregion

                    // ファイルパーサーにアップデート
                    fp.Update();
                }
            }
            catch (Exception)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000210;
                throw new BusinessLogicException(msgId, new string[] { filePath });
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion
    }
}
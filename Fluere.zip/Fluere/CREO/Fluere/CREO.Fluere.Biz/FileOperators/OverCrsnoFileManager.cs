﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 対象外交差点
    /// </summary>
    public class OverCrsnoFileManager
    {
        /// <summary>
        /// Readメソッド
        /// </summary>
        /// <param name="filePath">filePath</param>
        /// <returns>対象外交差点</returns>
        public static List<OverCrsnoData> Read(string filePath)
        {
            List<OverCrsnoData> dataList = new List<OverCrsnoData>();

            string formatFilePath = ConfigFileInfo.SpaceOverCrsnoFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // lstファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    OverCrsnoData overCrsnoData = new OverCrsnoData();

                    // 2次メッシュコード
                    overCrsnoData.MeshCode = (string)fp["MeshCode"];

                    // 交差点番号
                    overCrsnoData.CrsID = (string)fp["CrsID"];

                    // 目印コード
                    overCrsnoData.MarkCode = (string)fp["MarkCode"];

                    dataList.Add(overCrsnoData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

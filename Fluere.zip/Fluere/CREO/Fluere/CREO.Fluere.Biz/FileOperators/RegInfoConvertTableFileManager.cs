﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 規制情報変換テーブルファイルの読込.
    /// </summary>
    public class RegInfoConvertTableFileManager
    {
        #region 規制情報変換テーブルファイルの読込.
        /// <summary>
        /// 規制情報変換テーブルファイルの読込.
        /// </summary>
        /// <param name="file">規制情報変換ファイル</param>
        /// <returns>規制情報変換データ</returns>
        public static List<RegInfoConvertTableData> ReadRegInfoTableFile(string file)
        {
            List<RegInfoConvertTableData> dataList = new List<RegInfoConvertTableData>();

            string formatFilePath = ConfigFileInfo.RegInfoConvertFormatFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;

            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fs, xmlDef);

                // 前のレコード
                RegInfoConvertTableData lastData = null;

                while (fp.NextRecord())
                {
                    RegInfoConvertTableData currData = new RegInfoConvertTableData();

                    // 変更前ID
                    currData.IsEffective = true;
                    currData.ID = fp["ID"].ToString();
                    
                    // 規制曜日（月曜）
                    currData.DayOfWeek2 = fp["DayOfWeek2"].ToString();

                    // 規制曜日（火曜）
                    currData.DayOfWeek3 = fp["DayOfWeek3"].ToString();

                    // 規制曜日（水曜）
                    currData.DayOfWeek4 = fp["DayOfWeek4"].ToString();

                    // 規制曜日（木曜）
                    currData.DayOfWeek5 = fp["DayOfWeek5"].ToString();

                    // 規制曜日（金曜）
                    currData.DayOfWeek6 = fp["DayOfWeek6"].ToString();

                    // 規制曜日（土曜）
                    currData.DayOfWeek7 = fp["DayOfWeek7"].ToString();

                    // 規制曜日（日曜）
                    currData.DayOfWeek1 = fp["DayOfWeek1"].ToString();

                    // 規制曜日（祝）
                    currData.DayOfWeek0 = fp["DayOfWeek0"].ToString();

                    // 規制曜日（祝前日）
                    currData.DayOfWeek8 = fp["DayOfWeek8"].ToString();

                    // 規制曜日：除く
                    currData.OmitDayOfWeek = fp["OmitDayOfWeek"].ToString();

                    // 規制時刻：開始時
                    currData.StartHour = fp["StartHour"].ToString();

                    // 規制時刻：開始分
                    currData.StartMinute = fp["StartMinute"].ToString();

                    // 規制時刻：終了時
                    currData.EndHour = fp["EndHour"].ToString();

                    // 規制時刻：終了分
                    currData.EndMinute = fp["EndMinute"].ToString();

                    // 規制時刻：除く
                    currData.OmitRegTime = fp["OmitRegTime"].ToString();

                    // 規制月日：開始月
                    currData.StartMonth = fp["StartMonth"].ToString();

                    // 規制月日：開始日
                    currData.StartDay = fp["StartDay"].ToString();

                    // 規制月日：終了月
                    currData.EndMonth = fp["EndMonth"].ToString();

                    // 規制月日：終了日
                    currData.EndDay = fp["EndDay"].ToString();

                    // 規制月日：除く
                    currData.OmitRegDays = fp["OmitRegDays"].ToString();

                    // 規制週間（1週）
                    currData.WeekCondition0 = fp["WeekCondition0"].ToString();

                    // 規制週間（2週）
                    currData.WeekCondition1 = fp["WeekCondition1"].ToString();

                    // 規制週間（3週）
                    currData.WeekCondition2 = fp["WeekCondition2"].ToString();

                    // 規制週間（4週）
                    currData.WeekCondition3 = fp["WeekCondition3"].ToString();

                    // 規制週間（5週）
                    currData.WeekCondition4 = fp["WeekCondition4"].ToString();

                    // 規制週間（6週）
                    currData.WeekCondition5 = fp["WeekCondition5"].ToString();

                    // 規制状態コード
                    currData.RegStateCode = fp["RegStateCode"].ToString();

                    // 日またぎ有無
                    currData.Flag = fp["Flag"].ToString();

                    // 変更後ID
                    currData.IsUpdateEffective = true;
                    currData.UpdateID = fp["UpdateID"].ToString();

                    // 規制曜日（月曜）
                    currData.UpdateDayOfWeek2 = fp["UpdateDayOfWeek2"].ToString();

                    // 規制曜日（火曜）
                    currData.UpdateDayOfWeek3 = fp["UpdateDayOfWeek3"].ToString();

                    // 規制曜日（水曜）
                    currData.UpdateDayOfWeek4 = fp["UpdateDayOfWeek4"].ToString();

                    // 規制曜日（木曜）
                    currData.UpdateDayOfWeek5 = fp["UpdateDayOfWeek5"].ToString();

                    // 規制曜日（金曜）
                    currData.UpdateDayOfWeek6 = fp["UpdateDayOfWeek6"].ToString();

                    // 規制曜日（土曜）
                    currData.UpdateDayOfWeek7 = fp["UpdateDayOfWeek7"].ToString();

                    // 規制曜日（日曜）
                    currData.UpdateDayOfWeek1 = fp["UpdateDayOfWeek1"].ToString();

                    // 規制曜日（祝）
                    currData.UpdateDayOfWeek0 = fp["UpdateDayOfWeek0"].ToString();

                    // 規制曜日（祝前日）
                    currData.UpdateDayOfWeek8 = fp["UpdateDayOfWeek8"].ToString();

                    // 規制時刻：開始時
                    currData.UpdateStartHour = fp["UpdateStartHour"].ToString();

                    // 規制時刻：開始分
                    currData.UpdateStartMinute = fp["UpdateStartMinute"].ToString();

                    // 規制時刻：終了時
                    currData.UpdateEndHour = fp["UpdateEndHour"].ToString();

                    // 規制時刻：終了分
                    currData.UpdateEndMinute = fp["UpdateEndMinute"].ToString();

                    // 規制月日：開始月
                    currData.UpdateStartMonth = fp["UpdateStartMonth"].ToString();

                    // 規制月日：開始日
                    currData.UpdateStartDay = fp["UpdateStartDay"].ToString();

                    // 規制月日：終了月
                    currData.UpdateEndMonth = fp["UpdateEndMonth"].ToString();

                    // 規制月日：終了日
                    currData.UpdateEndDay = fp["UpdateEndDay"].ToString();

                    // 規制週間（1週）
                    currData.UpdateWeekCondition0 = fp["UpdateWeekCondition0"].ToString();

                    // 規制週間（2週）
                    currData.UpdateWeekCondition1 = fp["UpdateWeekCondition1"].ToString();

                    // 規制週間（3週）
                    currData.UpdateWeekCondition2 = fp["UpdateWeekCondition2"].ToString();

                    // 規制週間（4週）
                    currData.UpdateWeekCondition3 = fp["UpdateWeekCondition3"].ToString();

                    // 規制週間（5週）
                    currData.UpdateWeekCondition4 = fp["UpdateWeekCondition4"].ToString();

                    // 規制週間（6週）
                    currData.UpdateWeekCondition5 = fp["UpdateWeekCondition5"].ToString();

                    // 規制状態コード
                    currData.UpdateRegStateCode = fp["UpdateRegStateCode"].ToString();

                    // 変更IDが空白の場合、前のレコードを今回レコードにコピーする
                    if (lastData != null)
                    {
                        CopyLastData(lastData, currData);
                    }

                    // 規制単位に、変更後IDが存在する場合、変更前IDと変更後IDが同一ではない場合
                    if (currData.ID != currData.UpdateID)
                    {
                        string[] param = new string[] { file, currData.ID };
                        throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF40002063, param);
                    }

                    dataList.Add(currData);

                    // メモリに格納
                    lastData = currData;
                }

                // テーブルファイル中に、データ件数は1件でも入力されない場合
                if (dataList.Count == 0)
                {
                    string[] param = new string[] { file };
                    throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF40002062, param);
                }

                //// 変更前IDの昇順でソートする。
                // dataList.Sort((RegInfoConvertTableData data1, RegInfoConvertTableData data2) =>
                //                Convert.ToInt32(data2.ID) - Convert.ToInt32(data1.ID));
            }
            catch (FileNotFoundException)
            {
                // 規制情報変換テーブルファイルがオープン出来ません
                string[] param = new string[] { file };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF10000102, param);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (fp != null)
                {
                    fp.Dispose();
                }

                fp = null;

                if (fs != null)
                {
                    fs.Dispose();
                }

                fs = null;
            }

            return dataList;
        }
        #endregion

        #region 変更IDが空白の場合、前回のレコードを今回レコードにコピーする
        /// <summary>
        /// 前のレコードを今回レコードにコピー
        /// </summary>
        /// <param name="lastData">前回のレコード</param>
        /// <param name="currData">今回のレコード</param>
        private static void CopyLastData(RegInfoConvertTableData lastData, RegInfoConvertTableData currData)
        {
            // 日またぎの比較
            if (string.IsNullOrEmpty(currData.ID) || string.IsNullOrWhiteSpace(currData.ID))
            {
                currData.Flag = lastData.Flag;
            }

            // 変更前の比較
            if (string.IsNullOrEmpty(currData.ID) || string.IsNullOrWhiteSpace(currData.ID))
            {
                currData.IsEffective = false;

                // 変更前ID
                currData.ID = lastData.ID;

                // 規制曜日（月曜）
                currData.DayOfWeek2 = lastData.DayOfWeek2;

                // 規制曜日（火曜）
                currData.DayOfWeek3 = lastData.DayOfWeek3;

                // 規制曜日（水曜）
                currData.DayOfWeek4 = lastData.DayOfWeek4;

                // 規制曜日（木曜）
                currData.DayOfWeek5 = lastData.DayOfWeek5;

                // 規制曜日（金曜）
                currData.DayOfWeek6 = lastData.DayOfWeek6;

                // 規制曜日（土曜）
                currData.DayOfWeek7 = lastData.DayOfWeek7;

                // 規制曜日（日曜）
                currData.DayOfWeek1 = lastData.DayOfWeek1;

                // 規制曜日（祝）
                currData.DayOfWeek0 = lastData.DayOfWeek0;

                // 規制曜日（祝前日）
                currData.DayOfWeek8 = lastData.DayOfWeek8;

                // 規制曜日：除く
                currData.OmitDayOfWeek = lastData.OmitDayOfWeek;

                // 規制時刻：開始時
                currData.StartHour = lastData.StartHour;

                // 規制時刻：開始分
                currData.StartMinute = lastData.StartMinute;

                // 規制時刻：終了時
                currData.EndHour = lastData.EndHour;

                // 規制時刻：終了分
                currData.EndMinute = lastData.EndMinute;

                // 規制時刻：除く
                currData.OmitRegTime = lastData.OmitRegTime;

                // 規制月日：開始月
                currData.StartMonth = lastData.StartMonth;

                // 規制月日：開始日
                currData.StartDay = lastData.StartDay;

                // 規制月日：終了月
                currData.EndMonth = lastData.EndMonth;

                // 規制月日：終了日
                currData.EndDay = lastData.EndDay;

                // 規制月日：除く
                currData.OmitRegDays = lastData.OmitRegDays;

                // 規制週間（1週）
                currData.WeekCondition0 = lastData.WeekCondition0;

                // 規制週間（2週）
                currData.WeekCondition1 = lastData.WeekCondition1;

                // 規制週間（3週）
                currData.WeekCondition2 = lastData.WeekCondition2;

                // 規制週間（4週）
                currData.WeekCondition3 = lastData.WeekCondition3;

                // 規制週間（5週）
                currData.WeekCondition4 = lastData.WeekCondition4;

                // 規制週間（6週）
                currData.WeekCondition5 = lastData.WeekCondition5;

                // 規制状態コード
                currData.RegStateCode = lastData.RegStateCode;

                return;
            }

            // 変更後の比較
            if (string.IsNullOrEmpty(currData.UpdateID) || string.IsNullOrWhiteSpace(currData.UpdateID))
            {
                currData.IsUpdateEffective = false;

                // 変更後ID
                currData.UpdateID = lastData.UpdateID;

                // 規制曜日（月曜）
                currData.UpdateDayOfWeek2 = lastData.UpdateDayOfWeek2;

                // 規制曜日（火曜）
                currData.UpdateDayOfWeek3 = lastData.UpdateDayOfWeek3;

                // 規制曜日（水曜）
                currData.UpdateDayOfWeek4 = lastData.UpdateDayOfWeek4;

                // 規制曜日（木曜）
                currData.UpdateDayOfWeek5 = lastData.UpdateDayOfWeek5;

                // 規制曜日（金曜）
                currData.UpdateDayOfWeek6 = lastData.UpdateDayOfWeek6;

                // 規制曜日（土曜）
                currData.UpdateDayOfWeek7 = lastData.UpdateDayOfWeek7;

                // 規制曜日（日曜）
                currData.UpdateDayOfWeek1 = lastData.UpdateDayOfWeek1;

                // 規制曜日（祝）
                currData.UpdateDayOfWeek0 = lastData.UpdateDayOfWeek0;

                // 規制曜日（祝前日）
                currData.UpdateDayOfWeek8 = lastData.UpdateDayOfWeek8;

                // 規制時刻：開始時
                currData.UpdateStartHour = lastData.UpdateStartHour;

                // 規制時刻：開始分
                currData.UpdateStartMinute = lastData.UpdateStartMinute;

                // 規制時刻：終了時
                currData.UpdateEndHour = lastData.UpdateEndHour;

                // 規制時刻：終了分
                currData.UpdateEndMinute = lastData.UpdateEndMinute;

                // 規制月日：開始月
                currData.UpdateStartMonth = lastData.UpdateStartMonth;

                // 規制月日：開始日
                currData.UpdateStartDay = lastData.UpdateStartDay;

                // 規制月日：終了月
                currData.UpdateEndMonth = lastData.UpdateEndMonth;

                // 規制月日：終了日
                currData.UpdateEndDay = lastData.UpdateEndDay;

                // 規制週間（1週）
                currData.UpdateWeekCondition0 = lastData.UpdateWeekCondition0;

                // 規制週間（2週）
                currData.UpdateWeekCondition1 = lastData.UpdateWeekCondition1;

                // 規制週間（3週）
                currData.UpdateWeekCondition2 = lastData.UpdateWeekCondition2;

                // 規制週間（4週）
                currData.UpdateWeekCondition3 = lastData.UpdateWeekCondition3;

                // 規制週間（5週）
                currData.UpdateWeekCondition4 = lastData.UpdateWeekCondition4;

                // 規制週間（6週）
                currData.UpdateWeekCondition5 = lastData.UpdateWeekCondition5;

                // 規制状態コード
                currData.UpdateRegStateCode = lastData.UpdateRegStateCode;
            }
        }    
        #endregion
    }
}

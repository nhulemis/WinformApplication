﻿using System.Collections.Generic;
using System.IO;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// タウンジャンル基本分類変換リストファイル或いはタウンジャンルNTT分類変換リストファイルの処理
    /// </summary>
    public class TGnrTwnSortConvertFileManager
    {
        /// <summary>
        /// タウンジャンル分類変換リストファイルの読み込み
        /// </summary>
        /// <param name="strPath">タウンジャンル分類変換リストファイルのパス</param>
        /// <returns>タウンジャンル分類変換リストデータ</returns>
        public static List<TGnrTwnSortConvertData> ReadTGnrTwnSortConvertFile(string strPath)
        {
            // ファイルが存在するか確認
            if (!System.IO.File.Exists(strPath))
            {
                throw new FileNotFoundException();
            }

            // タウンジャンル分類変換リストファイルデータ初期化
            List<TGnrTwnSortConvertData> lsttGnrTwnSortConvertData = new List<TGnrTwnSortConvertData>();

            // テキストファイル読込む
            string content = FileUtil.ReadFile(strPath);

            // 行データの分割
            string[] stringLines = StringUtil.SpiltToLines(content);

            // コードリスト作成
            foreach (string currentLine in stringLines)
            {
                string[] strData = StringUtil.SpiltDataByTab(currentLine);

                if (strData.Length > 0)
                {
                    TGnrTwnSortConvertData tGnrTwnSortConvertData = new TGnrTwnSortConvertData();

                    tGnrTwnSortConvertData.OldSortCode = strData[0];
                    tGnrTwnSortConvertData.OldSortName = strData[1];
                    tGnrTwnSortConvertData.NewSortCode = strData[2];
                    tGnrTwnSortConvertData.NewSortName = strData[3];

                    lsttGnrTwnSortConvertData.Add(tGnrTwnSortConvertData);
                }
            }

            return lsttGnrTwnSortConvertData;
        }
    }
}

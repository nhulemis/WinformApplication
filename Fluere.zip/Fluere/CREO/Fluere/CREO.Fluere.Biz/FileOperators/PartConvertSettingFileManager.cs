﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Biz.Utility;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 部分変換設定ファイル
    /// </summary>
    public class PartConvertSettingFileManager
    {
        /// <summary>
        /// 部分変換設定ファイルの読込
        /// </summary>
        /// <param name="filePath">部分変換設定ファイルパス</param>
        /// <returns>部分変換設定データのリスト</returns>
        public static List<PartConvertSettingData> ReadPartConvertSettingFile(string filePath)
        {
            List<PartConvertSettingData> dataList = new List<PartConvertSettingData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.PartConvertSettingFormatFile);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                int i = 0;
                string temp = null;

                while (fp.NextRecord())
                {
                    if (i == 0)
                    {
                        i++;
                        continue;
                    }

                    PartConvertSettingData partConvertSettingData = new PartConvertSettingData();

                    // 親ジャンルコード
                    ushort value;
                    temp = fp["P_GenreCode"] as string;

                    if (!ushort.TryParse(temp, out value))
                    {
                        throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF21003433, temp);
                    }

                    partConvertSettingData.P_GenreCode = value;

                    // 子ジャンル範囲（前）
                    temp = fp["C_GenreRangeFront"] as string;
                    if (string.IsNullOrWhiteSpace(temp))
                    {
                        partConvertSettingData.C_CodeRangeFront = null;
                    }
                    else
                    {
                        partConvertSettingData.C_CodeRangeFront = Convert.ToUInt16(temp);
                    }

                    // 子ジャンル範囲（後）
                    temp = fp["C_GenreRangeAfter"] as string;
                    if (string.IsNullOrWhiteSpace(temp))
                    {
                        partConvertSettingData.C_CodeRangeAfter = null;
                    }
                    else
                    {
                        partConvertSettingData.C_CodeRangeAfter = Convert.ToUInt16(temp);
                    }

                    // 部分一致箇所
                    partConvertSettingData.JapanPartMatch = fp["JapanPartMatch"] as string;

                    // 漢字名称
                    partConvertSettingData.KanjiName = fp["KanjiName"] as string;

                    // カナ名称
                    partConvertSettingData.KanaName = fp["KanaName"] as string;

                    // 英字付与箇所
                    partConvertSettingData.EnPartMatch = fp["EnPartMatch"] as string;

                    // 部分変換英字
                    partConvertSettingData.EnConvertPart = fp["EnConvertPart"] as string;

                    // スペース付与有無
                    partConvertSettingData.IsSpace = fp["IsSpace"] as string;

                    // 全文字一致の変換実施有無
                    partConvertSettingData.IsAllMatchConvert = fp["IsAllMatchConvert"] as string;

                    // 完全一致英字 = 部分変換英字
                    partConvertSettingData.AllMatchEn = partConvertSettingData.EnConvertPart;

                    // カナ特殊処理「無」を設定
                    partConvertSettingData.KanaSpecial = "無";

                    dataList.Add(partConvertSettingData);
                }
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }
    }
}

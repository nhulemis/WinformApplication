﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 表示レベル設定:文字種別の設定ファイルの読込
    /// </summary>
    public class TypeCodeSettingDataFileManager
    {
        #region 文字種別の設定ファイルを読み込む
        /// <summary>
        /// 文字種別の設定ファイルを読み込む
        /// </summary>
        /// <param name="filePath">文字種別の設定ファイルのパス</param>
        /// <returns>文字種別の設定ファイルリスト</returns>
        public static List<TypeCodeSettingData> ReadTypeCodeSettingDataFile(string filePath)
        {
            var dataList = new List<TypeCodeSettingData>();

            string formatFilePath = ConfigFileInfo.TypeCodeSettingFormatFile;

            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(filePath, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    var typeCodeSettingData = new TypeCodeSettingData();

                    // 有効フラグ
                    typeCodeSettingData.EffectiveFlag = GetNumberRange((int)fp["EffectiveFlag"], 0, 1);

                    // 文字種別
                    typeCodeSettingData.TypeCode = (int)fp["TypeCode"];

                    // 優先順位
                    typeCodeSettingData.Priority = GetNumberRange((int)fp["Priority"], 0, 9999999);

                    // レベル一致
                    typeCodeSettingData.LevelMatch = GetNumberRange((int)fp["LevelMatch"], 0, 1);

                    // 中抜け許容
                    typeCodeSettingData.Permissible = GetNumberRange((int)fp["Permissible"], 0, 1);

                    // 文字種別名
                    typeCodeSettingData.TypeName = fp["TypeName"].ToString();

                    dataList.Add(typeCodeSettingData);
                }
            }
            catch (Exception ex)
            {
                // 文字種別の設定ファイルがオープン出来ません
                throw new BusinessLogicException(
                    UF_Fluere_MsgId.MSGID_UF10000179, new string[] { filePath }, ex);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return dataList;
        }

        /// <summary>
        /// 指定の範囲の整数値を取得する
        /// </summary>
        /// <param name="targetNum">対象の数値</param>
        /// <param name="min">最小値</param>
        /// <param name="max">最大値</param>
        /// <returns>指定の範囲の数値</returns>
        private static int GetNumberRange(int targetNum, int? min, int? max)
        {
            if (min != null && targetNum < min.Value)
            {
                throw new ArgumentOutOfRangeException();
            }
            else if (max != null && targetNum > max.Value)
            {
                throw new ArgumentOutOfRangeException();
            }

            return targetNum;
        }
        #endregion
    }
}

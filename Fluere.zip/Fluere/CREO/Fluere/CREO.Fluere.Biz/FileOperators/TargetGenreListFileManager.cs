﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;
using CREO.DataModel;
using CREO.DS;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.Fluere.Common.Diagnostics;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 対象ジャンルリストファイル管理
    /// </summary>
    public class TargetGenreListFileManager
    {
        /// <summary>
        /// ファイルの読込
        /// </summary>
        /// <param name="path">ファイルパス</param>
        /// <returns>ファイル内容</returns>
        public static List<TargetGenreData> Load(string path)
        {
            var result = new List<TargetGenreData>();

            XElement xmlDef = XElement.Load(ConfigFileInfo.TargetGenreListFile);
            FileStream fstream = null;
            FileParser fp = null;

            try
            {
                fstream = new FileStream(path, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fstream, xmlDef);

                while (fp.NextRecord())
                {
                    ushort pGnrCode;
                    ushort cGnrCodeStart;
                    ushort cGnrCodeEnd;

                    string p_temp = fp["P_GenreCode"] as string;
                    string c_s_temp = fp["C_GenreCode_S"] as string;
                    string c_e_temp = fp["C_GenreCode_E"] as string;

                    // 設定値チェック
                    CheckNullValue(path, p_temp, c_s_temp, c_e_temp);
                    CheckParseValue(path, p_temp, c_s_temp, c_e_temp);

                    // 数値変換
                    pGnrCode = ushort.Parse(p_temp);
                    cGnrCodeStart = ushort.Parse(c_s_temp);
                    cGnrCodeEnd = ushort.Parse(c_e_temp);

                    result.Add(new TargetGenreData(pGnrCode, cGnrCodeStart, cGnrCodeEnd));
                }
            }
            catch (FileNotFoundException ex)
            {
                // 対象ジャンルリストがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF11000007;
                throw new BusinessLogicException(msgId, new string[] { Path.GetFullPath(path) }, ex);
            }
            catch (UnauthorizedAccessException ex)
            {
                // 対象ジャンルリストがオープン出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF11000007;
                throw new BusinessLogicException(msgId, new string[] { Path.GetFullPath(path) }, ex);
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }

            return result;
        }

        /// <summary>
        /// 対象ジャンルレコードより範囲内にあたる物件ジャンルのリストを取得する。
        /// </summary>
        /// <param name="ds">データサービス</param>
        /// <param name="target">対象ジャンルコード</param>
        /// <returns>対象物件ジャンルリスト</returns>
        public static List<TGnrPOI> GetRangeGenre(DataService ds, TargetGenreData target)
        {
            // 親物件ジャンル検索
            var pq1 = new SqlConditionExpression("GnrCode", QueryItemOperator.Equal, target.ParentGnrCode);
            var pq2 = new SqlConditionExpression("NestLevel", QueryItemOperator.Equal, 0);

            var pqic = new QueryItemsCondition()
            {
                TypeIDs = new List<string>() { DataModelTypeID.CONTENTS_TYPE_TGNRPOI },
                ConditionExpression = SqlConditionExpression.And(pq1, pq2),
            };

            var pGnrResult = ds.QueryItems(pqic).OfType<TGnrPOI>().ToList();

            if (!pGnrResult.Any())
            {
                // 親物件ジャンルが存在しない場合
                var param = new object[] { target.ParentGnrCode, 0, ds.GetCurrentDataSourceInfo().Id };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000009, param);
            }

            // 子物件ジャンル検索
            var poid = pGnrResult.First().OIDString;
            var cq1 = new SqlConditionExpression("GnrCode", QueryItemOperator.GreatEqual, target.ChildGnrCodeStart);
            var cq2 = new SqlConditionExpression("GnrCode", QueryItemOperator.LessEqual, target.ChildGnrCodeEnd);
            var cq3 = new SqlConditionExpression("NestLevel", QueryItemOperator.Equal, 1);
            var cq4 = new SqlConditionExpression("ParentTableOID", QueryItemOperator.Equal, poid);

            var cqic = new QueryItemsCondition()
            {
                TypeIDs = new List<string>() { DataModelTypeID.CONTENTS_TYPE_TGNRPOI },
                ConditionExpression = SqlConditionExpression.And(cq1, SqlConditionExpression.And(cq2, SqlConditionExpression.And(cq3, cq4))),
            };

            var cGnrResult = ds.QueryItems(cqic).OfType<TGnrPOI>().ToList();

            if (!cGnrResult.Any())
            {
                // 子物件ジャンルが存在しない場合
                var param = new object[] { string.Join("-", target.ChildGnrCodeStart, target.ChildGnrCodeEnd) + "(親表実体OID：" + poid + ")", 1, ds.GetCurrentDataSourceInfo().Id };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000009, param);
            }
            else if (!cGnrResult.Any(n => n.GnrCode == target.ChildGnrCodeStart))
            {
                // 子物件ジャンルが存在しない場合
                var param = new object[] { target.ChildGnrCodeStart + "(親表実体OID：" + poid + ")", 1, ds.GetCurrentDataSourceInfo().Id };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000009, param);
            }
            else if (!cGnrResult.Any(n => n.GnrCode == target.ChildGnrCodeEnd))
            {
                // 子物件ジャンルが存在しない場合
                var param = new object[] { target.ChildGnrCodeEnd + "(親表実体OID：" + poid + ")", 1, ds.GetCurrentDataSourceInfo().Id };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000009, param);
            }

            return cGnrResult;
        }

        /// <summary>
        /// 設定値のチェック(NULL不許可)を行います。
        /// </summary>
        /// <param name="path">ファイルパス</param>
        /// <param name="pGnrValue">親ジャンルコード設定値</param>
        /// <param name="cGnrStartValue">子ジャンル範囲(開始)設定値</param>
        /// <param name="cGnrEndValue">子ジャンル範囲(終了)設定値</param>
        private static void CheckNullValue(string path, string pGnrValue, string cGnrStartValue, string cGnrEndValue)
        {
            if (string.IsNullOrWhiteSpace(pGnrValue))
            {
                // 親ジャンルがNULLの場合エラー
                var param = new string[] { Path.GetFullPath(path), "親ジャンルコード", pGnrValue, "設定値がNULL" };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000008, param);
            }

            if (string.IsNullOrWhiteSpace(cGnrStartValue))
            {
                // 子ジャンル範囲(開始)がNULLの場合エラー
                var param = new string[] { Path.GetFullPath(path), "子ジャンル範囲(開始)", cGnrStartValue, "設定値がNULL" };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000008, param);
            }

            if (string.IsNullOrWhiteSpace(cGnrEndValue))
            {
                // 子ジャンル範囲(終了)がNULLの場合エラー
                var param = new string[] { Path.GetFullPath(path), "子ジャンル範囲(終了)", cGnrEndValue, "設定値がNULL" };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000008, param);
            }
        }

        /// <summary>
        /// 設定値のチェック(数値変換)を行います。
        /// </summary>
        /// <param name="path">ファイルパス</param>
        /// <param name="pGnrValue">親ジャンルコード設定値</param>
        /// <param name="cGnrStartValue">子ジャンル範囲(開始)設定値</param>
        /// <param name="cGnrEndValue">子ジャンル範囲(終了)設定値</param>
        private static void CheckParseValue(string path, string pGnrValue, string cGnrStartValue, string cGnrEndValue)
        {
            // NULLチェック後に行うこと
            Assertion.Condition(pGnrValue != null);
            Assertion.Condition(cGnrStartValue != null);
            Assertion.Condition(cGnrEndValue != null);

            ushort pGnrCode;
            ushort cGnrCodeStart;
            ushort cGnrCodeEnd;

            if (!ushort.TryParse(pGnrValue, out pGnrCode))
            {
                // 数値以外の場合エラー
                var param = new string[] { Path.GetFullPath(path), "親ジャンルコード", pGnrValue, "数値型に変換できない" };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000008, param);
            }

            if (!ushort.TryParse(cGnrStartValue, out cGnrCodeStart))
            {
                // 数値以外の場合エラー
                var param = new string[] { Path.GetFullPath(path), "子ジャンル範囲(開始)", cGnrStartValue, "数値型に変換できない" };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000008, param);
            }

            if (!ushort.TryParse(cGnrEndValue, out cGnrCodeEnd))
            {
                // 数値以外の場合エラー
                var param = new string[] { Path.GetFullPath(path), "子ジャンル範囲(終了)", cGnrEndValue, "数値型に変換できない" };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000008, param);
            }

            if (cGnrCodeStart > cGnrCodeEnd)
            {
                // 開始コードが終了コードより大きい場合エラー
                var param = new string[] { Path.GetFullPath(path), "子ジャンル範囲(開始,終了)", string.Join(",", cGnrCodeStart, cGnrCodeEnd), "子ジャンル範囲(開始)の値が子ジャンル範囲(終了)の値より大きい" };
                throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF11000008, param);
            }
        }
    }
}
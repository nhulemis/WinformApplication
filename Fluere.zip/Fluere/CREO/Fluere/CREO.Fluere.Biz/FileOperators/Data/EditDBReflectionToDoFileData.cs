﻿// -----------------------------------------------------------------------
// <copyright file="EditDBReflectionToDoFileData.cs" company="Hewlett-Packard Company">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 編集DB反映用ToDoリストファイル
    /// </summary>
    [Obsolete("CommToDoDataWrapper を使用して下さい")]
    public class EditDBReflectionToDoFileData
    {
        #region フィールド定義
        /// <summary>
        /// 調査対象ID
        /// </summary>
        private string inquestObjectID = string.Empty;

        /// <summary>
        /// 経度
        /// </summary>
        private string longitude = string.Empty;

        /// <summary>
        /// 緯度
        /// </summary>
        private string latitude = string.Empty;

        /// <summary>
        /// 検索対象DB
        /// </summary>
        private string queryObjectDB = string.Empty;

        /// <summary>
        /// OID
        /// </summary>
        private string oID = string.Empty;

        /// <summary>
        /// 確認
        /// </summary>
        private string workStatus = string.Empty;

        /// <summary>
        /// 差分区分
        /// </summary>
        private string column1 = string.Empty;

        /// <summary>
        /// タイプ
        /// </summary>
        private string column2 = string.Empty;
        #endregion

        #region getter and setter
        /// <summary>
        /// 調査対象ID
        /// </summary>
        public string InquestObjectID
        {
            get { return inquestObjectID; }
            set { inquestObjectID = value; }
        }

        /// <summary>
        /// 経度
        /// </summary>
        public string Longitude
        {
            get { return longitude; }
            set { longitude = value; }
        }

        /// <summary>
        /// 緯度
        /// </summary>
        public string Latitude
        {
            get { return latitude; }
            set { latitude = value; }
        }

        /// <summary>
        /// 検索対象DB
        /// </summary>
        public string QueryObjectDB
        {
            get { return queryObjectDB; }
            set { queryObjectDB = value; }
        }

        /// <summary>
        /// OID
        /// </summary>
        public string OID
        {
            get { return oID; }
            set { oID = value; }
        }

        /// <summary>
        /// 確認
        /// </summary>
        public string WorkStatus
        {
            get { return workStatus; }
            set { workStatus = value; }
        }

        /// <summary>
        /// 差分区分
        /// </summary>
        public string Column1
        {
            get { return column1; }
            set { column1 = value; }
        }

        /// <summary>
        /// タイプ
        /// </summary>
        public string Column2
        {
            get { return column2; }
            set { column2 = value; }
        }
        #endregion
    }
}

﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// タウンデータ区分対応リストファイルのデータ
    /// </summary>
    public class TwnDataDivConvertData
    {
        /// <summary>
        /// データ区分
        /// </summary>
        public string DataCode { get; set; }

        /// <summary>
        /// 出力コード：納品データ
        /// </summary>
        public string InputCode { get; set; }

        /// <summary>
        /// TMI作成タウン物件コード
        /// </summary>
        public string TwnCode { get; set; }
    }
}

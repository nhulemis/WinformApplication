﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// タウンジャンル基本分類変換リストとタウンジャンルNTT分類変換リストのデータ
    /// </summary>
    public class TGnrTwnSortConvertData
    {
        /// <summary>
        /// 変換前分類コード
        /// </summary>
        public string OldSortCode { get; set; }

        /// <summary>
        /// 変換後分類コード
        /// </summary>
        public string NewSortCode { get; set; }

        /// <summary>
        /// 変換前分類名称
        /// </summary>
        public string OldSortName { get; set; }

        /// <summary>
        /// 変換後分類名称
        /// </summary>
        public string NewSortName { get; set; }
    }
}

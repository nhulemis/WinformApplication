﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// FreeAndIpPhoneFileDataクラス
    /// </summary>
    public class FreeAndIpPhoneFileData
    {
        /// <summary>
        /// 電話番号
        /// </summary>
        public string TelNo { get; set; }

        /// <summary>
        /// 電話分類
        /// </summary>
        public string TelType { get; set; }
    }
}

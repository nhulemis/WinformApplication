﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 予約VICS区間削除対象リストファイル
    /// </summary>
    public class VicsSectionFileData
    {
        /// <summary>
        /// 2次メッシュコード
        /// </summary>
        public string MeshCode { get; set; }

        /// <summary>
        /// VICSリンク区分コード
        /// </summary>
        public string VICSDivisionCode { get; set; }

        /// <summary>
        /// VICSリンク番号
        /// </summary>
        public string VICSNumber { get; set; }
    }
}

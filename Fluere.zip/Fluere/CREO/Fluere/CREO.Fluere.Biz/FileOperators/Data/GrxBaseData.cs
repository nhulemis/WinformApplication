﻿using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// GRX基本データファイル
    /// </summary>
    public class GrxBaseData
    {
        #region フィールド定義
        /// <summary>
        /// 区分図ファイル識別文字列
        /// </summary>
        private string _fileFlg;

        /// <summary>
        /// ファイルサイズ
        /// </summary>
        private int _fileSize;

        /// <summary>
        /// バージョン情報
        /// </summary>
        private string _versionInfo;

        /// <summary>
        /// 発行年月日
        /// </summary>
        private ulong? _publicationDate;

        /// <summary>
        /// 市区町村コード
        /// </summary>
        private string _municipalityCode;

        /// <summary>
        /// 分冊コード
        /// </summary>
        private string _partCode;

        /// <summary>
        /// 住宅地図名称
        /// </summary>
        private string _housingMapName;

        /// <summary>
        /// 住宅地図の幅
        /// </summary>
        private double? _housingMapWidth;

        /// <summary>
        /// 住宅地図の高さ
        /// </summary>
        private double? _housingMapHight;

        /// <summary>
        /// グループ数
        /// </summary>
        private int _groupNum;

        /// <summary>
        /// GRXグループデータリスト
        /// </summary>
        private List<GrxGroupData> _grxGroupDataList;
        #endregion

        #region getter and setter
        /// <summary>
        /// 区分図ファイル識別文字列
        /// </summary>
        public string FileFlg
        {
            get { return _fileFlg; }
            set { _fileFlg = value; }
        }

        /// <summary>
        /// ファイルサイズ
        /// </summary>
        public int FileSize
        {
            get { return _fileSize; }
            set { _fileSize = value; }
        }

        /// <summary>
        /// バージョン情報
        /// </summary>
        public string VersionInfo
        {
            get { return _versionInfo; }
            set { _versionInfo = value; }
        }

        /// <summary>
        /// 発行年月日
        /// </summary>
        public ulong? PublicationDate
        {
            get { return _publicationDate; }
            set { _publicationDate = value; }
        }

        /// <summary>
        /// 市区町村コ－ド
        /// </summary>
        public string MunicipalityCode
        {
            get { return _municipalityCode; }
            set { _municipalityCode = value; }
        }

        /// <summary>
        /// 分冊コード
        /// </summary>
        public string PartCode
        {
            get { return _partCode; }
            set { _partCode = value; }
        }

        /// <summary>
        /// 住宅地図名称
        /// </summary>
        public string HousingMapName
        {
            get { return _housingMapName; }
            set { _housingMapName = value; }
        }

        /// <summary>
        /// 住宅地図の幅
        /// </summary>
        public double? HousingMapWidth
        {
            get { return _housingMapWidth; }
            set { _housingMapWidth = value; }
        }

        /// <summary>
        /// 住宅地図の高さ
        /// </summary>
        public double? HousingMapHight
        {
            get { return _housingMapHight; }
            set { _housingMapHight = value; }
        }

        /// <summary>
        /// グループ数
        /// </summary>
        public int GroupNum
        {
            get { return _groupNum; }
            set { _groupNum = value; }
        }

        /// <summary>
        /// GRXグループデータリスト
        /// </summary>
        public List<GrxGroupData> GrxGroupDataList
        {
            get { return _grxGroupDataList; }
            set { _grxGroupDataList = value; }
        }
        #endregion
    }
}

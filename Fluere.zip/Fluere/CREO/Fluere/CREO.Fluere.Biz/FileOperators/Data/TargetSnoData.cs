﻿using System;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// マッチング対応交差点目印ファイル
    /// </summary>
    public class TargetSnoData
    {
        /// <summary>
        /// 交差点目印の【目印名称】[目印コード]
        /// </summary>
        public string MarkCode { get; set; }

        /// <summary>
        /// 交差点目印漢字名称
        /// </summary>
        public string MarkName { get; set; }

        /// <summary>
        /// 交差点目印カナ名称
        /// </summary>
        public string MarkKanaName { get; set; }

        /// <summary>
        /// 半角数字（Null、1、2）
        /// </summary>
        public string MarkNumber { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 語頭語尾変換設定ファイル
    /// </summary>
    public class MjcGotouGobiData
    {
        /// <summary>
        /// 文字種別コード
        /// </summary>
        public ushort? TxtType { get; set; }

        /// <summary>
        /// 語頭語尾フラグ
        /// ※1：語頭に変換英字を追加する。
        /// ※2：語尾に変換英字を追加する。
        /// </summary>
        public string Flag { get; set; }

        /// <summary>
        /// 変換英字
        /// </summary>
        public string ConvertEn { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 大字表記対応リスト
    /// </summary>
    public class OoazMappingData
    {
        #region フィールド定義
        /// <summary>
        /// アルファベット表記 ＃１
        /// </summary>
        private string _oazaCodeStr;

        /// <summary>
        /// 10 進表記 ＃２
        /// </summary>
        private string _oazaCodeNum;
        #endregion

        #region getter and setter
        /// <summary>
        /// 大字コード：アルファベット表記 ＃１
        /// </summary>
        public string OazaCodeStr
        {
            get { return this._oazaCodeStr; }
            set { this._oazaCodeStr = value; }
        }

        /// <summary>
        /// 大字コード：10 進表記 ＃２
        /// </summary>
        public string OazaCodeNum
        {
            get { return this._oazaCodeNum; }
            set { this._oazaCodeNum = value; }
        }
        #endregion
    }
}

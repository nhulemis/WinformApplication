﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// アンマッチ結果ファイル
    /// </summary>
    public class UnmatchResultsData
    {
        /// <summary>
        /// 2次メッシュコード
        /// </summary>
        public string MeshCode { get; set; }

        /// <summary>
        /// 交差点データ番号
        /// </summary>
        public string CrsDateNumber { get; set; }

        /// <summary>
        /// 目印連番
        /// </summary>
        public string MarkSpate { get; set; }

        /// <summary>
        /// 目印コード
        /// </summary>
        public string MarkCode { get; set; }

        /// <summary>
        /// カナ名称
        /// </summary>
        public string KANAName { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string KanJiNames { get; set; }

        /// <summary>
        /// 経度
        /// </summary>
        public string Longitude { get; set; }

        /// <summary>
        /// 緯度
        /// </summary>
        public string Latitude { get; set; }

        /// <summary>
        /// 交差点目印のOID
        /// </summary>
        public string CrsMarkOID { get; set; }
    }
}

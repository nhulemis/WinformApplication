﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// TMIDB外部データ（住所代表点）
    /// </summary>
    public class TMIDBAdrPntData
    {
        #region フィールド定義
        /// <summary>
        /// 都道府県コ－ド
        /// </summary>
        private ushort _a0;

        /// <summary>
        /// 市区町村コ－ド
        /// </summary>
        private ushort _a1;

        /// <summary>
        /// 大字コード
        /// </summary>
        private ushort _a2;

        /// <summary>
        /// 小字コード
        /// </summary>
        private ushort _a3;

        /// <summary>
        /// 街区コ－ド
        /// </summary>
        private ushort _a4;

        /// <summary>
        /// 地番・戸番
        /// </summary>
        private ushort _a5;

        /// <summary>
        /// 枝番
        /// </summary>
        private ushort _a6;

        /// <summary>
        /// 郡コード
        /// </summary>
        private ushort _a7;

        /// <summary>
        /// 経度（１／１２８秒）
        /// </summary>
        private long _longitude;

        /// <summary>
        /// 緯度（１／１２８秒）
        /// </summary>
        private long _latitude;

        /// <summary>
        /// 年
        /// </summary>
        private string _year;

        /// <summary>
        /// 月（空白 or ｍｍ）
        /// </summary>
        private string _month;

        /// <summary>
        /// 分冊コード（空白orＡ～）
        /// </summary>
        private string _volumeCode;

        /// <summary>
        /// ページ番号
        /// </summary>
        private string _pageNo;

        /// <summary>
        /// 左右識別コード(Ｒ，Ｌ)
        /// </summary>
        private string _leftRightCode;

        /// <summary>
        /// 記号座標　横（Ａ～）
        /// </summary>
        private string _symbol;

        /// <summary>
        /// 縦（１～）
        /// </summary>
        private string _vertical;

        /// <summary>
        /// ポリゴン検査コード
        /// </summary>
        private string _polygonCheckCode;
        #endregion

        #region getter and setter
        /// <summary>
        /// 都道府県コ－ド
        /// </summary>
        public ushort A0
        {
            get { return _a0; }
            set { _a0 = value; }
        }

        /// <summary>
        /// 市区町村コ－ド
        /// </summary>
        public ushort A1
        {
            get { return _a1; }
            set { _a1 = value; }
        }

        /// <summary>
        /// 大字コード
        /// </summary>
        public ushort A2
        {
            get { return _a2; }
            set { _a2 = value; }
        }

        /// <summary>
        /// 小字コード
        /// </summary>
        public ushort A3
        {
            get { return _a3; }
            set { _a3 = value; }
        }

        /// <summary>
        /// 街区コ－ド
        /// </summary>
        public ushort A4
        {
            get { return _a4; }
            set { _a4 = value; }
        }

        /// <summary>
        /// 地番・戸番
        /// </summary>
        public ushort A5
        {
            get { return _a5; }
            set { _a5 = value; }
        }

        /// <summary>
        /// 枝番
        /// </summary>
        public ushort A6
        {
            get { return _a6; }
            set { _a6 = value; }
        }

        /// <summary>
        /// 郡コード
        /// </summary>
        public ushort A7
        {
            get { return _a7; }
            set { _a7 = value; }
        }

        /// <summary>
        /// 経度（１／１２８秒）
        /// </summary>
        public long Longitude
        {
            get { return _longitude; }
            set { _longitude = value; }
        }

        /// <summary>
        /// 緯度（１／１２８秒）
        /// </summary>
        public long Latitude
        {
            get { return _latitude; }
            set { _latitude = value; }
        }

        /// <summary>
        /// 年
        /// </summary>
        public string Year
        {
            get { return _year; }
            set { _year = value; }
        }

        /// <summary>
        /// 月（空白 or ｍｍ）
        /// </summary>
        public string Month
        {
            get { return _month; }
            set { _month = value; }
        }

        /// <summary>
        /// 分冊コード（空白orＡ～）
        /// </summary>
        public string VolumeCode
        {
            get { return _volumeCode; }
            set { _volumeCode = value; }
        }

        /// <summary>
        /// ページ番号
        /// </summary>
        public string PageNo
        {
            get { return _pageNo; }
            set { _pageNo = value; }
        }

        /// <summary>
        /// 左右識別コード(Ｒ，Ｌ)
        /// </summary>
        public string LeftRightCode
        {
            get { return _leftRightCode; }
            set { _leftRightCode = value; }
        }

        /// <summary>
        /// 記号座標　横（Ａ～）
        /// </summary>
        public string HorizontalOrdinate
        {
            get { return _symbol; }
            set { _symbol = value; }
        }

        /// <summary>
        /// 縦（１～）
        /// </summary>
        public string VerticalOrdinate
        {
            get { return _vertical; }
            set { _vertical = value; }
        }

        /// <summary>
        /// ポリゴン検査コード
        /// </summary>
        public string PolygonCheckCode
        {
            get { return _polygonCheckCode; }
            set { _polygonCheckCode = value; }
        }
        #endregion
    }
}

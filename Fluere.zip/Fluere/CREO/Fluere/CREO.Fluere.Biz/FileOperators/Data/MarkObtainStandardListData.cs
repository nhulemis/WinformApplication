﻿// -----------------------------------------------------------------------
// <copyright file="MarkObtainStandardListEntity.cs" company="Hewlett-Packard Company">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 目印取得基準リストファイル
    /// </summary>
    public class MarkObtainStandardListData
    {
        #region フィールド定義
        /// <summary>
        /// タウン物件に付与する目印コード
        /// </summary>
        private string markCode = string.Empty;

        /// <summary>
        /// NTT分類コード（目印付与のキーワード）
        /// </summary>
        private string nTTGroupCode = string.Empty;

        /// <summary>
        /// カナ掲載名と部分一致させるキー（目印付与のキーワード）
        /// </summary>
        private string kanjiName = string.Empty;

        /// <summary>
        /// 漢字掲載名と部分一致させるキー（目印付与のキーワード）
        /// </summary>
        private string kanaName = string.Empty;

        /// <summary>
        /// 目印調査要／不要を表すコード
        /// </summary>
        private string confirmFlag = string.Empty;

        /// <summary>
        /// カーディーラー(レクサス、トヨタ以外)フラグ
        /// </summary>
        private string carDealerFlag = string.Empty;
        #endregion

        #region プロパティ定義
        /// <summary>
        /// 行番号
        /// </summary>
        public int LineNum { get; set; }
        #endregion

        #region getter and setter
        /// <summary>
        /// タウン物件に付与する目印コード
        /// </summary>
        public string MarkCode
        {
            get { return markCode; }
            set { markCode = value; }
        }

        /// <summary>
        /// NTT分類コード（目印付与のキーワード）
        /// </summary>
        public string NTTGroupCode
        {
            get { return nTTGroupCode; }
            set { nTTGroupCode = value; }
        }

        /// <summary>
        /// カナ掲載名と部分一致させるキー（目印付与のキーワード）
        /// </summary>
        public string KanjiName
        {
            get { return kanjiName; }
            set { kanjiName = value; }
        }

        /// <summary>
        /// 漢字掲載名と部分一致させるキー（目印付与のキーワード）
        /// </summary>
        public string KanaName
        {
            get { return kanaName; }
            set { kanaName = value; }
        }

        /// <summary>
        /// 目印調査要／不要を表すコード
        /// </summary>
        public string ConfirmFlag
        {
            get { return confirmFlag; }
            set { confirmFlag = value; }
        }

        /// <summary>
        /// カーディーラー(レクサス、トヨタ以外)フラグ
        /// </summary>
        public string CarDealerFlag
        {
            get { return carDealerFlag; }
            set { carDealerFlag = value; }
        }
        #endregion
    }
}

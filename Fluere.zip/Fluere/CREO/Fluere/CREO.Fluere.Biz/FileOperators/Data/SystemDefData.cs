﻿// -----------------------------------------------------------------------
// <copyright file="SystemDefDataEntity.cs" company="Hewlett-Packard Company">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// システム定義ファイル
    /// </summary>
    public class SystemDefData
    {
        #region フィールド定義
        /// <summary>
        /// データソースID
        /// </summary>
        private string id = null;

        /// <summary>
        /// データソースの
        /// </summary>
        private string caption = null;

        /// <summary>
        /// データソースのコメント
        /// </summary>
        private string comment = null;

        /// <summary>
        /// 親ジョブID
        /// </summary>
        private string parentjob_id = null;

        /// <summary>
        /// 親作業グループID
        /// </summary>
        private string wgid = null;

        /// <summary>
        /// トリガID
        /// </summary>
        private string trigger_id = null;

        /// <summary>
        /// 子ジョブID
        /// </summary>
        private string childjob_id = null;

        /// <summary>
        /// 子作業グループID
        /// </summary>
        private string swgid = null;

        /// <summary>
        /// ロットID
        /// </summary>
        private string lot_id = null;

        /// <summary>
        /// 作業工程ID
        /// </summary>
        private string sgprocess_id = null;

        /// <summary>
        /// 工程情報ID
        /// </summary>
        private string process_id = null;

        /// <summary>
        /// ToDoリストへのフルパス
        /// </summary>
        private string todopath = null;

        /// <summary>
        /// メッシュリスト
        /// </summary>
        private List<string> meshCode = null;

        /// <summary>
        /// 任意パラメータ
        /// </summary>
        private List<string> parameter = null;

        #endregion

        #region getter and setter
        /// <summary>
        /// データソースID
        /// </summary>
        public string Id
        {
            get { return this.id; }
            set { this.id = value; }
        }

        /// <summary>
        /// データソースの
        /// </summary>
        public string Caption
        {
            get { return this.caption; }
            set { this.caption = value; }
        }

        /// <summary>
        /// データソースのコメント
        /// </summary>
        public string Comment
        {
            get { return this.comment; }
            set { this.comment = value; }
        }

        /// <summary>
        /// 親ジョブID
        /// </summary>
        public string Parentjob_Id
        {
            get { return this.parentjob_id; }
            set { this.parentjob_id = value; }
        }

        /// <summary>
        /// 親作業グループID
        /// </summary>
        public string Wgid
        {
            get { return this.wgid; }
            set { this.wgid = value; }
        }

        /// <summary>
        /// トリガID
        /// </summary>
        public string Trigger_Id
        {
            get { return this.trigger_id; }
            set { this.trigger_id = value; }
        }

        /// <summary>
        /// 子ジョブID
        /// </summary>
        public string Childjob_Id
        {
            get { return this.childjob_id; }
            set { this.childjob_id = value; }
        }

        /// <summary>
        /// 子作業グループID
        /// </summary>
        public string Swgid
        {
            get { return this.swgid; }
            set { this.swgid = value; }
        }

        /// <summary>
        /// ロットID
        /// </summary>
        public string Lot_Id
        {
            get { return this.lot_id; }
            set { this.lot_id = value; }
        }

        /// <summary>
        /// 作業工程ID
        /// </summary>
        public string Sgprocess_Id
        {
            get { return this.sgprocess_id; }
            set { this.sgprocess_id = value; }
        }

        /// <summary>
        /// 工程情報ID
        /// </summary>
        public string Process_Id
        {
            get { return this.process_id; }
            set { this.process_id = value; }
        }

        /// <summary>
        /// ToDoリストへのフルパス
        /// </summary>
        public string Todopath
        {
            get { return this.todopath; }
            set { this.todopath = value; }
        }

        /// <summary>
        /// メッシュリスト
        /// </summary>
        public List<string> MeshCode
        {
            get { return this.meshCode; }
            set { this.meshCode = value; }
        }

        /// <summary>
        /// 任意パラメータ
        /// </summary>
        public List<string> Parameter
        {
            get { return this.parameter; }
            set { this.parameter = value; }
        }
        #endregion
    }
}

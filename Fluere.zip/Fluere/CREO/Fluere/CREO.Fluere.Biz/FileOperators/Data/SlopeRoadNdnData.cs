﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 対応付けデータ
    /// </summary>
    public class SlopeRoadNdnData
    {
        /// <summary>
        /// 2mc
        /// </summary>
        public int MeshNo { get; set; }

        /// <summary>
        /// 05表示交差点番号
        /// </summary>
        public uint CrsNo { get; set; }
    }
}

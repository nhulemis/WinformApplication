﻿using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// アンマッチ追跡対象抽出条件設定ファイルデータ
    /// </summary>
    public class UnmatchExtractConditionListData
    {
        /// <summary>
        /// 個別条件
        /// </summary>
        private List<ConditionExpressData> lstConditionData = new List<ConditionExpressData>();

        /// <summary>
        /// マッチングレベル
        /// </summary>
        public int MatchingLevel { get; set; }

        /// <summary>
        /// 絞込み条件
        /// </summary>
        public int GroupCondition { get; set; }

        /// <summary>
        /// 個別条件リスト
        /// </summary>
        public List<ConditionExpressData> ConditionExpressList 
        {
            get { return lstConditionData; } 
        }
    }
}

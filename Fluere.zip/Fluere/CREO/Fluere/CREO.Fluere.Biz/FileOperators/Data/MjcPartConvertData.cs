﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 描画系部分変換設定ファイルデータ
    /// </summary>
    public class MjcPartConvertData
    {
        /// <summary>
        /// 文字種別コード
        /// </summary>
        public ushort? TxtType { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string KanjiName { get; set; }

        /// <summary>
        /// カナ名称
        /// </summary>
        public string KanaName { get; set; }

        /// <summary>
        /// チェック位置
        /// ※1：語頭
        /// ※2：語尾
        /// </summary>
        public string CheckPosition { get; set; }

        /// <summary>
        /// 部分変換語句
        /// </summary>
        public string ConvetWord { get; set; }

        /// <summary>
        /// 変換仕様
        /// ※1：カナを半角スペース+英字に置換し、語尾につける
        /// ※2：カナを英字+半角スペースにし、語頭につける
        /// ※3：部分一致したカナの先頭にハイフン（-）を付けて残しつつ、英字変換＋半角スペースにし語頭につける
        /// ※4：カナを単純に英字に置換（※半角スペースは含まない）し、語尾につける
        /// </summary>
        public string ConvertSpecification { get; set; }

        /// <summary>
        /// 完全一致の対応
        /// ※1：一定の英字に変換
        /// ※2：英字変換しない（記号のみor英字化しない）
        /// </summary>
        public string AllMatchSupport { get; set; }

        /// <summary>
        /// 完全一致英字
        /// ※完全一致した場合、完全一致の対応が1の場合、変換する英字
        /// </summary>
        public string AllMatchEn { get; set; }

        /// <summary>
        /// 優先度
        /// ※文字種別コードに対する変換の優先順位を定義する。
        /// </summary>
        public string Priority { get; set; }
    }
}

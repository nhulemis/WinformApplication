﻿using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 形状マッチングデータ
    /// </summary>
    public class ShapeMatchingResultData
    {
        /// <summary>
        /// コンストラクター
        /// </summary>
        public ShapeMatchingResultData()
        {
            TZRoadData = new List<ShapeMatchingTZRoadData>();
            EditRoadData = new List<ShapeMatchingEditRoadData>();
        }

        /// <summary>
        /// コンストラクター
        /// </summary>
        /// <param name="tzRoadData">TZ道路データ</param>
        /// <param name="editRoadData">基幹道路データ</param>
        public ShapeMatchingResultData(List<ShapeMatchingTZRoadData> tzRoadData,
                                        List<ShapeMatchingEditRoadData> editRoadData)
        {
            TZRoadData = tzRoadData;
            EditRoadData = editRoadData;
        }

        /// <summary>
        /// TZ道路データ
        /// </summary>
        public List<ShapeMatchingTZRoadData> TZRoadData { get; set; }

        /// <summary>
        /// 基幹道路データ
        /// </summary>
        public List<ShapeMatchingEditRoadData> EditRoadData { get; set; }
    }

    /// <summary>
    /// 形状マッチングTZ道路データ
    /// </summary>
    public class ShapeMatchingTZRoadData : IEqualityComparer<ShapeMatchingTZRoadData>
    {
        /// <summary>
        /// コンストラクター
        /// </summary>
        public ShapeMatchingTZRoadData()
        {
            MeshCode = string.Empty;
            RoadNo = string.Empty;
            Direction = string.Empty;
        }

        /// <summary>
        /// コンストラクター
        /// </summary>
        /// <param name="meshCode">2次メッシュ</param>
        /// <param name="roadNo">道路番号</param>
        /// <param name="direction">リンク方向</param>
        public ShapeMatchingTZRoadData(string meshCode, string roadNo, string direction)
        {
            MeshCode = meshCode;
            RoadNo = roadNo;
            Direction = direction;
        }

        /// <summary>
        /// 2次メッシュ
        /// </summary>
        public string MeshCode { get; set; }

        /// <summary>
        /// 道路番号
        /// </summary>
        public string RoadNo { get; set; }

        /// <summary>
        /// リンク方向
        /// </summary>
        public string Direction { get; set; }

        /// <summary>
        /// 同じ判定
        /// </summary>
        /// <param name="x">対象x</param>
        /// <param name="y">>対象y</param>
        /// <returns>判定フラグ</returns>
        public bool Equals(ShapeMatchingTZRoadData x, ShapeMatchingTZRoadData y)
        {
            // Check whether the compared objects reference the same data.
            if (object.ReferenceEquals(x, y))
            {
                return true;
            }

            // Check whether any of the compared objects is null.
            if (object.ReferenceEquals(x, null) || object.ReferenceEquals(y, null))
            {
                return false;
            }

            // Check whether the properties are equal.
            return x.MeshCode == y.MeshCode && x.RoadNo == y.RoadNo;
        }

        /// <summary>
        /// ハッシュコードの取得
        /// </summary>
        /// <param name="data">指定対象</param>
        /// <returns>ハッシュコード</returns>
        public int GetHashCode(ShapeMatchingTZRoadData data)
        {
            // Check whether the object is null
            if (object.ReferenceEquals(data, null))
            {
                return 0;
            }

            // Get hash code for the MeshCode field if it is not null.
            int hashMeshCode = data.MeshCode == null ? 0 : data.MeshCode.GetHashCode();

            // Get hash code for the RoadNo field if it is not null.
            int hashRoadNo = data.RoadNo == null ? 0 : data.RoadNo.GetHashCode();

            // Calculate the hash code.
            return hashMeshCode ^ hashRoadNo;
        }
    }

    /// <summary>
    /// 形状マッチング基幹道路データ
    /// </summary>
    public class ShapeMatchingEditRoadData : IEqualityComparer<ShapeMatchingEditRoadData>
    {
        /// <summary>
        /// コンストラクター
        /// </summary>
        public ShapeMatchingEditRoadData()
        {
            OID = string.Empty;
            Direction = string.Empty;
        }

        /// <summary>
        /// コンストラクター
        /// </summary>
        /// <param name="oid">基幹道路OID</param>
        /// <param name="direction">リンク方向</param>
        public ShapeMatchingEditRoadData(string oid, string direction)
        {
            OID = oid;
            Direction = direction;
        }

        /// <summary>
        /// 基幹道路OID
        /// </summary>
        public string OID { get; set; }

        /// <summary>
        /// リンク方向
        /// </summary>
        public string Direction { get; set; }

        /// <summary>
        /// 同じ判定
        /// </summary>
        /// <param name="x">対象x</param>
        /// <param name="y">>対象y</param>
        /// <returns>判定フラグ</returns>
        public bool Equals(ShapeMatchingEditRoadData x, ShapeMatchingEditRoadData y)
        {
            // Check whether the compared objects reference the same data.
            if (object.ReferenceEquals(x, y))
            {
                return true;
            }

            // Check whether any of the compared objects is null.
            if (object.ReferenceEquals(x, null) || object.ReferenceEquals(y, null))
            {
                return false;
            }

            // Check whether the  properties are equal.
            return x.OID == y.OID;
        }

        /// <summary>
        /// ハッシュコードの取得
        /// </summary>
        /// <param name="data">指定対象</param>
        /// <returns>ハッシュコード</returns>
        public int GetHashCode(ShapeMatchingEditRoadData data)
        {
            // Check whether the object is null
            if (object.ReferenceEquals(data, null))
            {
                return 0;
            }

            // Get hash code for the OID field if it is not null.
            int hashProductName = data.OID == null ? 0 : data.OID.GetHashCode();

            // Calculate the hash code for the product.
            return hashProductName;
        }
    }
}

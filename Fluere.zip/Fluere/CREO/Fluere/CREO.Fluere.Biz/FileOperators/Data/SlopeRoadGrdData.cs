﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 道路勾配データ
    /// </summary>
    public class SlopeRoadGrdData
    {
        /// <summary>
        /// 北緯
        /// </summary>
        public double Latitude { get; set; }

        /// <summary>
        /// 東経
        /// </summary>
        public double Longitude { get; set; }

        /// <summary>
        /// 高さ
        /// </summary>
        public double Height { get; set; }

        /// <summary>
        /// 勾配値
        /// </summary>
        public double RelativeSlope { get; set; } 
    }
}

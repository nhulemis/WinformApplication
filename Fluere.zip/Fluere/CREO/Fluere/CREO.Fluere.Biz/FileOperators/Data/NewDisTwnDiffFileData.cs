﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 新規・廃止差分タウンファイル
    /// ※【適用バッチ】タウン受入、行政変更
    /// </summary>
    public class NewDisTwnDiffFileData : IComparable, System.IComparable<NewDisTwnDiffFileData>
    {
        /// <summary>
        /// タウン物件OID：oid：数値：8（文字列16）
        /// </summary>
        private long? _oidstring;

        /// <summary>
        /// データ区分：ddiv：数値：2
        /// </summary>
        private short? _ddiv;

        /// <summary>
        /// 差分フラグ：dflg：文字列：1
        /// N:新規　D:廃止
        /// </summary>
        private string _dflg = string.Empty;

        /// <summary>
        /// 情報種別：ity：文字列：1
        /// </summary>
        private string _ity = string.Empty;

        /// <summary>
        /// ファイル区分：fcl：文字列：1
        /// </summary>
        private string _fcl = string.Empty;

        /// <summary>
        /// 市外局番：t0：文字列：6
        /// </summary>
        private string _t0 = string.Empty;

        /// <summary>
        /// 電話番号：tn：文字列：12
        /// </summary>
        private string _tn = string.Empty;

        /// <summary>
        /// カナ掲載名：kn：文字列：74
        /// </summary>
        private string _kn = string.Empty;

        /// <summary>
        /// 漢字掲載名：kj：文字列：70
        /// </summary>
        private string _kj = string.Empty;

        /// <summary>
        /// 都道府県コード：a0：数値：8
        /// </summary>
        private long? _a0;

        /// <summary>
        /// 市区町村コード：a1：数値：8
        /// </summary>
        private long? _a1;

        /// <summary>
        /// 大字コード：a2：文字列：3
        /// </summary>
        private string _a2 = string.Empty;

        /// <summary>
        /// 字・丁目コード：a3：文字列：3
        /// </summary>
        private string _a3 = string.Empty;

        /// <summary>
        /// 都道府県名：an0：文字列：8
        /// </summary>
        private string _an0 = string.Empty;

        /// <summary>
        /// 市区町村名：an1：文字列：24
        /// </summary>
        private string _an1 = string.Empty;

        /// <summary>
        /// 大字名：an2：文字列：36
        /// </summary>
        private string _an2 = string.Empty;

        /// <summary>
        /// 字・丁目名：an3：文字列：24
        /// </summary>
        private string _an3 = string.Empty;

        /// <summary>
        /// 街区番号・部屋番号：an4：文字列：26
        /// </summary>
        private string _an4 = string.Empty;

        /// <summary>
        /// 方書：co：文字列：58
        /// </summary>
        private string _co = string.Empty;

        /// <summary>
        /// 基本分類コード：bc：文字列：4
        /// </summary>
        private string _bc = string.Empty;

        /// <summary>
        /// 基本分類名：bcn：文字列：36
        /// </summary>
        private string _bcn = string.Empty;

        /// <summary>
        /// 付記：ps：文字列：24
        /// </summary>
        private string _ps = string.Empty;

        /// <summary>
        /// 電番略符号：tac：文字列：20
        /// </summary>
        private string _tac = string.Empty;

        /// <summary>
        /// ＮＴＴ分類コード：nc：文字列：7
        /// </summary>
        private string _nc = string.Empty;

        /// <summary>
        /// ＮＴＴ分類名：ncn：文字列：24
        /// </summary>
        private string _ncn = string.Empty;

        /// <summary>
        /// 法人種別コード：apt：文字列：2
        /// </summary>
        private string _apt = string.Empty;

        /// <summary>
        /// 郵便番号１：m0：文字列：3
        /// </summary>
        private string _m0 = string.Empty;

        /// <summary>
        /// 郵便番号２：m1：文字列：5
        /// </summary>
        private string _m1 = string.Empty;

        /// <summary>
        /// 外字識別表示：xkj：文字列：1
        /// </summary>
        private string _xkj = string.Empty;

        /// <summary>
        /// 通称識別表示：xan：文字列：1
        /// </summary>
        private string _xan = string.Empty;

        /// <summary>
        /// 主掲載フラグ：mfg：文字列：1
        /// </summary>
        private string _mfg = string.Empty;

        /// <summary>
        /// 予備：rsv：数値：8
        /// </summary>
        private long? _rsv;

        /// <summary>
        /// 目印コード：sno：文字列：4
        /// </summary>
        private string _sno;

        /// <summary>
        /// 経度：e：：4
        /// </summary>
        private long? _e;

        /// <summary>
        /// 緯度：n：：4
        /// </summary>
        private long? _n;

        /// <summary>
        /// マッチングレベル：mlv：：4
        /// </summary>
        private int? _mlv;

        /// <summary>
        /// 住所マッチングフラグ：amflg：：1bit×32
        /// </summary>
        private int? _amflg;

        /// <summary>
        /// タウン物件OID：oid：数値：8
        /// </summary>
        public long? OidString
        {
            get { return _oidstring; }
            set { _oidstring = value; }
        }

        /// <summary>
        /// データ区分：ddiv：数値：2
        /// </summary>
        public short? Ddiv
        {
            get { return _ddiv; }
            set { _ddiv = value; }
        }

        /// <summary>
        /// 差分フラグ：dflg：文字列：1
        /// </summary>
        public string Dflg
        {
            get { return _dflg; }
            set { _dflg = value; }
        }

        /// <summary>
        /// 情報種別：ity：文字列：1
        /// </summary>
        public string Ity
        {
            get { return _ity; }
            set { _ity = value; }
        }

        /// <summary>
        /// ファイル区分：fcl：文字列：1
        /// </summary>
        public string Fcl
        {
            get { return _fcl; }
            set { _fcl = value; }
        }

        /// <summary>
        /// 市外局番：t0：文字列：6
        /// </summary>
        public string T0
        {
            get { return _t0; }
            set { _t0 = value; }
        }

        /// <summary>
        /// 電話番号：tn：文字列：12
        /// </summary>
        public string Tn
        {
            get { return _tn; }
            set { _tn = value; }
        }

        /// <summary>
        /// カナ掲載名：kn：文字列：74
        /// </summary>
        public string Kn
        {
            get { return _kn; }
            set { _kn = value; }
        }

        /// <summary>
        /// 漢字掲載名：kj：文字列：70
        /// </summary>
        public string Kj
        {
            get { return _kj; }
            set { _kj = value; }
        }

        /// <summary>
        /// 都道府県コード：a0：数値：8
        /// </summary>
        public long? A0
        {
            get { return _a0; }
            set { _a0 = value; }
        }

        /// <summary>
        /// 市区町村コード：a1：数値：8
        /// </summary>
        public long? A1
        {
            get { return _a1; }
            set { _a1 = value; }
        }

        /// <summary>
        /// 大字コード：a2：文字列：3
        /// </summary>
        public string A2
        {
            get { return _a2; }
            set { _a2 = value; }
        }

        /// <summary>
        /// 字・丁目コード：a3：文字列：3
        /// </summary>
        public string A3
        {
            get { return _a3; }
            set { _a3 = value; }
        }

        /// <summary>
        /// 都道府県名：an0：文字列：8
        /// </summary>
        public string An0
        {
            get { return _an0; }
            set { _an0 = value; }
        }

        /// <summary>
        /// 市区町村名：an1：文字列：24
        /// </summary>
        public string An1
        {
            get { return _an1; }
            set { _an1 = value; }
        }

        /// <summary>
        /// 大字名：an2：文字列：36
        /// </summary>
        public string An2
        {
            get { return _an2; }
            set { _an2 = value; }
        }

        /// <summary>
        /// 字・丁目名：an3：文字列：24
        /// </summary>
        public string An3
        {
            get { return _an3; }
            set { _an3 = value; }
        }

        /// <summary>
        /// 街区番号・部屋番号：an4：文字列：26
        /// </summary>
        public string An4
        {
            get { return _an4; }
            set { _an4 = value; }
        }

        /// <summary>
        /// 方書：co：文字列：58
        /// </summary>
        public string Co
        {
            get { return _co; }
            set { _co = value; }
        }

        /// <summary>
        /// 基本分類コード：bc：文字列：4
        /// </summary>
        public string Bc
        {
            get { return _bc; }
            set { _bc = value; }
        }

        /// <summary>
        /// 基本分類名：bcn：文字列：36
        /// </summary>
        public string Bcn
        {
            get { return _bcn; }
            set { _bcn = value; }
        }

        /// <summary>
        /// 付記：ps：文字列：24
        /// </summary>
        public string Ps
        {
            get { return _ps; }
            set { _ps = value; }
        }

        /// <summary>
        /// 電番略符号：tac：文字列：20
        /// </summary>
        public string Tac
        {
            get { return _tac; }
            set { _tac = value; }
        }

        /// <summary>
        /// ＮＴＴ分類コード：nc：文字列：7
        /// </summary>
        public string Nc
        {
            get { return _nc; }
            set { _nc = value; }
        }

        /// <summary>
        /// ＮＴＴ分類名：ncn：文字列：24
        /// </summary>
        public string Ncn
        {
            get { return _ncn; }
            set { _ncn = value; }
        }

        /// <summary>
        /// 法人種別コード：apt：文字列：2
        /// </summary>
        public string Apt
        {
            get { return _apt; }
            set { _apt = value; }
        }

        /// <summary>
        /// 郵便番号１：m0：文字列：3
        /// </summary>
        public string M0
        {
            get { return _m0; }
            set { _m0 = value; }
        }

        /// <summary>
        /// 郵便番号２：m1：文字列：5
        /// </summary>
        public string M1
        {
            get { return _m1; }
            set { _m1 = value; }
        }

        /// <summary>
        /// 外字識別表示：xkj：文字列：1
        /// </summary>
        public string Xkj
        {
            get { return _xkj; }
            set { _xkj = value; }
        }

        /// <summary>
        /// 通称識別表示：xan：文字列：1
        /// </summary>
        public string Xan
        {
            get { return _xan; }
            set { _xan = value; }
        }

        /// <summary>
        /// 主掲載フラグ：mfg：文字列：1
        /// </summary>
        public string Mfg
        {
            get { return _mfg; }
            set { _mfg = value; }
        }

        /// <summary>
        /// 予備：rsv：数値：8
        /// </summary>
        public long? Rsv
        {
            get { return _rsv; }
            set { _rsv = value; }
        }

        /// <summary>
        /// 目印コード：sno：文字列：4
        /// </summary>
        public string Sno
        {
            get { return _sno; }
            set { _sno = value; }
        }

        /// <summary>
        /// 経度：e：：4
        /// </summary>
        public long? E
        {
            get { return _e; }
            set { _e = value; }
        }

        /// <summary>
        /// 緯度：n：：4
        /// </summary>
        public long? N
        {
            get { return _n; }
            set { _n = value; }
        }

        /// <summary>
        /// マッチングレベル：mlv：：4
        /// </summary>
        public int? Mlv
        {
            get { return _mlv; }
            set { _mlv = value; }
        }

        /// <summary>
        /// 住所マッチングフラグ：amflg：：1bit×32
        /// </summary>
        public int? Amflg
        {
            get { return _amflg; }
            set { _amflg = value; }
        }

        /// <summary>
        /// 比較ロジック
        /// </summary>
        /// <param name="obj">比較対象</param>
        /// <returns>比較結果</returns>
        public int CompareTo(object obj)
        {
            // nullより大きい
            if (obj == null)
            {
                return 1;
            }

            // 違う型とは比較できない
            if (this.GetType() != obj.GetType())
            {
                throw new ArgumentException("別の型とは比較できません。", "obj");
            }

            return this.CompareTo(obj as NewDisTwnDiffFileData);
        }

        /// <summary>
        /// 比較ロジック(NewDisTwnDiffFileData型と比較)
        /// </summary>
        /// <param name="other">比較対象</param>
        /// <returns>比較結果</returns>
        public int CompareTo(NewDisTwnDiffFileData other)
        {
            int result = 0;

            if (this.A0.Equals(other.A0) &&
                this.A1.Equals(other.A1) &&
                this.A2.Equals(other.A2) &&
                this.A3.Equals(other.A3))
            {
                result = 1;
            }
            else
            {
                result = -1;
            }

            return result;
        }

        #region 値のコピー
        /// <summary>
        /// 値のコピー
        /// </summary>
        /// <param name="otherData">Copy対象</param>
        public void SetValue(NewDisTwnDiffFileData otherData)
        {
            this.A2 = otherData.A2;
            this.A3 = otherData.A3;
        }
        #endregion
    }

    #region タウン受入ビジネスを利用し、並べ替えるロジック
    /// <summary>
    /// タウン受入ビジネスを利用し、並べ替えるロジック
    /// </summary>
    public class CompareToByTwnAccept : IComparer<NewDisTwnDiffFileData>
    {
        /// <summary>
        /// ２行のデータを比較するメソッドを実装する
        /// </summary>
        /// <param name="firstObj">比較する最初のオブジェクトです</param>
        /// <param name="secondObj">比較する 2 番目のオブジェクト</param>
        /// <returns>比較結果</returns>
        public int Compare(NewDisTwnDiffFileData firstObj, NewDisTwnDiffFileData secondObj)
        {
            int rc;

            rc = (int)(firstObj.A0 - secondObj.A0);
            if (rc != 0)
            {
                return rc;
            }

            rc = (int)(firstObj.A1 - secondObj.A1);
            if (rc != 0)
            {
                return rc;
            }

            rc = string.Compare(firstObj.A2, secondObj.A2);
            if (rc != 0)
            {
                return rc;
            }

            rc = string.Compare(firstObj.A3, secondObj.A3);
            if (rc != 0)
            {
                return rc;
            }

            rc = string.Compare(firstObj.An2, secondObj.An2);
            if (rc != 0)
            {
                return rc;
            }

            rc = string.Compare(firstObj.An3, secondObj.An3);
            if (rc != 0)
            {
                return rc;
            }

            string hanAn4First = StringUtil.ZenToHan(firstObj.An4);
            string hanAn4Second = StringUtil.ZenToHan(secondObj.An4);

            rc = int.Parse(StringUtil.HanCut(hanAn4First, 1)) -
                 int.Parse(StringUtil.HanCut(hanAn4Second, 1));
            if (rc != 0)
            {
                return rc;
            }

            rc = int.Parse(StringUtil.HanCut(hanAn4First, 2)) -
                 int.Parse(StringUtil.HanCut(hanAn4Second, 2));
            if (rc != 0)
            {
                return rc;
            }

            rc = int.Parse(StringUtil.HanCut(hanAn4First, 3)) -
                 int.Parse(StringUtil.HanCut(hanAn4Second, 3));
            if (rc != 0)
            {
                return rc;
            }

            rc = string.Compare(firstObj.Co, secondObj.Co);
            if (rc != 0)
            {
                return rc;
            }

            rc = string.Compare(firstObj.Kn, secondObj.Kn);
            if (rc != 0)
            {
                return rc;
            }

            rc = string.Compare(firstObj.Kj, secondObj.Kj);
            if (rc != 0)
            {
                return rc;
            }

            rc = string.Compare(firstObj.Tn, secondObj.Tn);
            if (rc != 0)
            {
                return rc;
            }

            rc = string.Compare(firstObj.Nc, secondObj.Nc);
            if (rc != 0)
            {
                return rc;
            }

            rc = (int)(firstObj.Amflg - secondObj.Amflg);
            if (rc != 0)
            {
                return rc;
            }

            return rc;
        }
    }
    #endregion
}

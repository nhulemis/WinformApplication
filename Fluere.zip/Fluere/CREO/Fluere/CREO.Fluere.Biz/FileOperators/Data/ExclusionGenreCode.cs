﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 除外ジャンルコード
    /// </summary>
    public class ExclusionGenreCode
    {
        /// <summary>
        /// 親ジャンルコード
        /// </summary>
        private readonly ushort? parentGnrCode;

        /// <summary>
        /// 子ジャンルコード
        /// </summary>
        private readonly ushort? childGnrCode;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="pGnrCode">親ジャンルコード</param>
        /// <param name="cGnrCode">子ジャンルコード</param>
        public ExclusionGenreCode(ushort? pGnrCode, ushort? cGnrCode)
        {
            this.parentGnrCode = pGnrCode;
            this.childGnrCode = cGnrCode;
        }

        /// <summary>
        /// 親ジャンルコードを取得します。
        /// </summary>
        public ushort? ParentGnrCode
        {
            get
            {
                return this.parentGnrCode;
            }
        }

        /// <summary>
        /// 子ジャンルコードを取得します。
        /// </summary>
        public ushort? ChildGnrCode
        {
            get
            {
                return this.childGnrCode;
            }
        }
    }
}
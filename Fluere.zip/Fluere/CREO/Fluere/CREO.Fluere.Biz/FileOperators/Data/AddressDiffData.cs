﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 町字更新インプットデータファイル
    /// </summary>
    public class AddressDiffData
    {
        /// <summary>
        /// 差分区分（1：[住所名称]新規　3：[住所名称]変更　5：[住所名称]廃止　9：[住所名称]削除　11：[廃止住所名称]新規　13：[廃止住所名称]変更　15：[廃止住所名称]削除）
        /// </summary>
        public ushort DiffFlag
        {
            get;
            set;
        }

        /// <summary>
        /// 特殊処理有無（0：特殊処理なし　1：特殊処理あり）
        /// </summary>
        public ushort SpecialProcess
        {
            get;
            set;
        }

        /// <summary>
        /// 処理住所コード（文字列,例aabbb-cccc-dd）AdrNameKanji
        /// </summary>
        public string AdrCode
        {
            get;
            set;
        }

        /// <summary>
        /// 行政区域コード（文字列）
        /// </summary>
        public string ActionAdrCode
        {
            get;
            set;
        }

        /// <summary>
        /// 住所名称（漢字）
        /// </summary>
        public string AdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 住所名称（全角カナ）
        /// </summary>
        public string AdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 出典住所名称（漢字）
        /// </summary>
        public string MateriaAdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 出典住所名称（全角カナ）
        /// </summary>
        public string MateriaAdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// DTVコード
        /// </summary>
        public ushort? DtvCode
        {
            get;
            set;
        }

        /// <summary>
        /// 出力コード
        /// </summary>
        public ushort? IndexDivision
        {
            get;
            set;
        }

        /// <summary>
        /// 捏造コード
        /// </summary>
        public byte? InventCode
        {
            get;
            set;
        }

        /// <summary>
        /// 郵便：町字コード
        /// </summary>
        public ushort? MachiazaCode
        {
            get;
            set;
        }

        /// <summary>
        /// 郵便：市区町村コード
        /// </summary>
        public ushort? MunicipalityCode
        {
            get;
            set;
        }

        /// <summary>
        /// 同一住所名称の識別名称
        /// </summary>
        public string OazaDistinctNameMultiLang
        {
            get;
            set;
        }

        /// <summary>
        /// 人口
        /// </summary>
        public ulong? Population
        {
            get;
            set;
        }

        /// <summary>
        /// 通称/公称コード
        /// </summary>
        public ushort? PublicCode
        {
            get;
            set;
        }

        /// <summary>
        /// 観光地コード
        /// </summary>
        public string ResortCodeAry
        {
            get;
            set;
        }

        /// <summary>
        /// 観光地名称（漢字）
        /// </summary>
        public string ResortNameMultiLangAryKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 観光地名称（ひながら）
        /// </summary>
        public string ResortNameMultiLangAryKana
        {
            get;
            set;
        }

        /// <summary>
        /// 観光地名称（音声認識）
        /// </summary>
        public string ResortNameMultiLangAryAware
        {
            get;
            set;
        }

        /// <summary>
        /// 観光地名称（音声合成）
        /// </summary>
        public string ResortNameMultiLangAryComp
        {
            get;
            set;
        }

        /// <summary>
        /// 旧郵便：町字コード
        /// </summary>
        public ushort? MachiazaOldCode
        {
            get;
            set;
        }

        /// <summary>
        /// 旧郵便：市区町村コード
        /// </summary>
        public ushort? MunicipalityOldCode
        {
            get;
            set;
        }
    }
}

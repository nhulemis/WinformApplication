﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 自動継承ログファイル
    /// </summary>
    public class AutoMatchingLogData
    {
        #region フィールド定義
        /// <summary>
        /// 新旧区分
        /// </summary>
        private string _newOrOld = null;

        /// <summary>
        /// OID
        /// </summary>
        private ulong _oid = 1;

        /// <summary>
        /// 電話番号
        /// </summary>
        private string _telNumber = null;

        /// <summary>
        /// 漢字掲載名
        /// </summary>
        private string _twnKanji = null;

        /// <summary>
        /// 都道府県コード
        /// </summary>
        private int _provinceCode = -1;

        /// <summary>
        /// 市区町村コード
        /// </summary>
        private int _cityCode = -1;

        /// <summary>
        /// 大字コード
        /// </summary>
        private string _oazaCode = null;

        /// <summary>
        /// 字・丁目コード 
        /// </summary>
        private string _sectionCode = null;

        /// <summary>
        /// 字・丁目名
        /// </summary>
        private string _sectionName = null;

        /// <summary>
        /// 都道府県名
        /// </summary>
        private string _provinceName = null;

        /// <summary>
        /// 市区郡町村名
        /// </summary>
        private string _cityName = null;

        /// <summary>
        /// 大字・通称名
        /// </summary>
        private string _oazaName = null;

        /// <summary>
        /// 街区番号・部屋番号
        /// </summary>
        private string _gaikuRoom = null;

        /// <summary>
        /// 方書
        /// </summary>
        private string _katagaki = null;

        /// <summary>
        /// NTT分類コード
        /// </summary>
        private string _nTTGroupCode = null;

        /// <summary>
        /// NTT分類名
        /// </summary>
        private string _nTTGroupName = null;

        /// <summary>
        /// 経度
        /// </summary>
        private long _longitude = -1L;

        /// <summary>
        /// 緯度
        /// </summary>
        private long _latitude = -1L;

        /// <summary>
        /// マッチングレベル
        /// </summary>
        private int _matchingLv = -1;
        #endregion

        #region getter and setter
        /// <summary>
        /// 新旧区分
        /// </summary>
        public string NewOrOld
        {
            get { return _newOrOld; }
            set { _newOrOld = value; }
        }

        /// <summary>
        /// OID
        /// </summary>
        public ulong OID
        {
            get { return _oid; }
            set { _oid = value; }
        }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string TelNumber
        {
            get { return _telNumber; }
            set { _telNumber = value; }
        }

        /// <summary>
        /// 漢字掲載名
        /// </summary>
        public string TwnKanji
        {
            get { return _twnKanji; }
            set { _twnKanji = value; }
        }

        /// <summary>
        /// 都道府県コード
        /// </summary>
        public int ProvinceCode
        {
            get { return _provinceCode; }
            set { _provinceCode = value; }
        }

        /// <summary>
        /// 市区町村コード
        /// </summary>
        public int CityCode
        {
            get { return _cityCode; }
            set { _cityCode = value; }
        }

        /// <summary>
        /// 大字コード
        /// </summary>
        public string OazaCode
        {
            get { return _oazaCode; }
            set { _oazaCode = value; }
        }

        /// <summary>
        /// 字・丁目コード 
        /// </summary>
        public string SectionCode
        {
            get { return _sectionCode; }
            set { _sectionCode = value; }
        }

        /// <summary>
        /// 都道府県名
        /// </summary>
        public string ProvinceName
        {
            get { return _provinceName; }
            set { _provinceName = value; }
        }

        /// <summary>
        /// 市区郡町村名
        /// </summary>
        public string CityName
        {
            get { return _cityName; }
            set { _cityName = value; }
        }

        /// <summary>
        /// 大字・通称名
        /// </summary>
        public string OazaName
        {
            get { return _oazaName; }
            set { _oazaName = value; }
        }

        /// <summary>
        /// 字・丁目名
        /// </summary>
        public string SectionName
        {
            get { return _sectionName; }
            set { _sectionName = value; }
        }

        /// <summary>
        /// 街区番号・部屋番号
        /// </summary>
        public string GaikuRoom
        {
            get { return _gaikuRoom; }
            set { _gaikuRoom = value; }
        }

        /// <summary>
        /// 方書
        /// </summary>
        public string Katagaki
        {
            get { return _katagaki; }
            set { _katagaki = value; }
        }

        /// <summary>
        /// NTT分類コード
        /// </summary>
        public string NTTGroupCode
        {
            get { return _nTTGroupCode; }
            set { _nTTGroupCode = value; }
        }

        /// <summary>
        /// NTT分類名
        /// </summary>
        public string NTTGroupName
        {
            get { return _nTTGroupName; }
            set { _nTTGroupName = value; }
        }

        /// <summary>
        /// 経度
        /// </summary>
        public long Longitude
        {
            get { return _longitude; }
            set { _longitude = value; }
        }

        /// <summary>
        /// 緯度
        /// </summary>
        public long Latitude
        {
            get { return _latitude; }
            set { _latitude = value; }
        }

        /// <summary>
        /// マッチングレベル
        /// </summary>
        public int MatchingLv
        {
            get { return _matchingLv; }
            set { _matchingLv = value; }
        }
        #endregion
    }
}

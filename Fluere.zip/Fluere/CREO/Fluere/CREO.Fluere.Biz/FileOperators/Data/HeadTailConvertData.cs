﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 接頭語接尾語変換設定ファイル
    /// </summary>
    public class HeadTailConvertData
    {
        /// <summary>
        /// 音声の区分
        /// ※1：高速施設、2：高速方面標識
        /// </summary>
        public int VoiceType { get; set; }

        /// <summary>
        /// 文字位置
        /// ※1：語頭、2：語尾
        /// </summary>
        public int CharPosition { get; set; }

        /// <summary>
        /// 漢字文字列
        /// </summary>
        public string KanjiStr { get; set; }

        /// <summary>
        /// カナ文字列
        /// </summary>
        public string KanaStr { get; set; }
    }
}

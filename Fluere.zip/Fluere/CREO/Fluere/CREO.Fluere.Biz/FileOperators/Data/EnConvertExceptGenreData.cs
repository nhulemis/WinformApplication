﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 英字変換対象外ジャンルファイル
    /// </summary>
    public class EnConvertExceptGenreData
    {
        /// <summary>
        /// 英字変換対象外の親ジャンルコード
        /// </summary>
        public ushort P_GenreCode { get; set; }

        /// <summary>
        /// 英字変換対象外の子ジャンルコード
        /// </summary>
        public ushort? C_GenreCode { get; set; }
    }
}

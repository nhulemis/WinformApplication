﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// スペース対象抽出定義ファイルデータ
    /// </summary>
    public class SpaceObjectDefData
    {
        /// <summary>
        /// 文字種別コードリスト(private変数)
        /// </summary>
        private List<ushort> _txtTypeList = null;

        /// <summary>
        /// 文字種別コード
        /// </summary>
        public string TxtType { get; set; }

        /// <summary>
        /// 抽出キー
        /// </summary>
        public string ExtractKey { get; set; }

        /// <summary>
        /// 文字種別コードのリスト
        /// </summary>
        public List<ushort> TxtTypeList
        {
            get
            {
                if (_txtTypeList == null)
                {
                    this._txtTypeList = new List<ushort>();

                    string[] temp = TxtType.Split(',');

                    foreach (string txt in temp)
                    {
                        if (!string.IsNullOrWhiteSpace(txt))
                        {
                            this._txtTypeList.Add(Convert.ToUInt16(txt));
                        }
                    }
                }

                return this._txtTypeList;
            }
        }
    }
}

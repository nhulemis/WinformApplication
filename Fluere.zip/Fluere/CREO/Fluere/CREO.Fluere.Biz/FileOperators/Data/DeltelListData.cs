﻿using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// deltelファイルデータ
    /// </summary>
    public class DeltelListData
    {
        /// <summary>
        /// 電話番号リストの初期化
        /// </summary>
        private List<string> telNo = new List<string>();

        /// <summary>
        /// 電話番号リスト
        /// </summary>
        public List<string> TelNoList 
        { 
            get { return telNo; } 
        }
    }
}

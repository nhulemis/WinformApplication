﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 複数名称一括変換設定ファイルデータ
    /// </summary>
    public class File1vsNData
    {
        /// <summary>
        /// 英字名称
        /// </summary>
        public string EnName { get; set; }

        /// <summary>
        /// 文字種別コード
        /// </summary>
        public ushort? TxtType { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string KanjiName { get; set; }

        /// <summary>
        /// カナ名称
        /// </summary>
        public string KanaName { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 種別毎変換設定ファイルデータ
    /// </summary>
    public class MjcAllData
    {
        /// <summary>
        /// 文字種別コード
        /// </summary>
        public ushort? TxtType { get; set; }

        /// <summary>
        /// 一律一定ワード設定文字
        /// </summary>
        public string OneWordSetting { get; set; }

        /// <summary>
        /// 変換パターン
        /// ※1：一律一定ワード
        /// ※2：一律記号
        /// ※3：1vsNにない場合⇒一律一定ワード
        /// ※4：1vsNにない場合⇒一律記号
        /// ※5：1vsNにない場合⇒英字化しない
        /// ※6：1vsNにない場合⇒ローマ字変換不可⇒一律一定ワード
        /// ※7：1vsNにない場合⇒ローマ字変換不可⇒一律記号
        /// ※8：1vsNにない場合⇒ローマ字変換不可⇒英字化しない
        /// </summary>
        public string ConvertPattern { get; set; }

        /// <summary>
        /// 強制ローマ字変換
        /// ※変換パターン8とセットとすること。
        /// ※1vsNにない場合⇒カナ変換不可⇒カナを元に強制変換
        /// </summary>
        public string ForceConvertRomaji { get; set; }
    }
}

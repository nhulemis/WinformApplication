﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 調査原稿テキストファイル（Pingo連携用）
    /// </summary>
    public class SearchInfoPingoData
    {
        #region 交差点目印
        /// <summary>
        /// 2次メッシュコード
        /// </summary>
        public string MeshCode { get; set; }

        /// <summary>
        /// 交差点データ番号
        /// </summary>
        public string CrsDataNumber { get; set; }

        /// <summary>
        /// 目印連番
        /// </summary>
        public string Crs_MarkSpate { get; set; }

        /// <summary>
        /// 目印名称
        /// </summary>
        public string Crs_MarkName { get; set; }

        /// <summary>
        /// 目印コード
        /// </summary>
        public string Crs_MarkCode { get; set; }
   
        /// <summary>
        /// 経度
        /// </summary>
        public string Crs_Longitude { get; set; }

        /// <summary>
        /// 緯度
        /// </summary>
        public string Crs_Latitude { get; set; }

        /// <summary>
        /// プロット番号
        /// </summary>
        public string PlotNo { get; set; }

        #endregion

        #region タウン物件座標（1/1024秒単位）
        /// <summary>
        /// 経度
        /// </summary>
        public string STwn_Longitude { get; set; }

        /// <summary>
        /// 緯度
        /// </summary>
        public string STwn_Latitude { get; set; }

        #endregion

        #region 施設物件座標（1/1024秒単位）
        /// <summary>
        /// 経度
        /// </summary>
        public string SPOI_Longitude { get; set; }

        /// <summary>
        /// 緯度
        /// </summary>
        public string SPOI_Latitude { get; set; }

        #endregion
    }
}

﻿using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 駐車場差分リストインプットデータファイル
    /// </summary>
    public class ParkingDiffListData
    {
        /// <summary>
        /// 行番号
        /// </summary>
        public ulong LineNo
        {
            get;
            set;
        }

        /// <summary>
        /// 差分情報（1：新規　2：変更　3：削除）
        /// </summary>
        public ushort DiffType
        {
            get;
            set;
        }

        /// <summary>
        /// 駐車場ＩＤ
        /// </summary>
        public string ParkingID
        {
            get;
            set;
        }

        /// <summary>
        /// 変更内容
        /// </summary>
        public string ChangeColumnList
        {
            get;
            set;
        }

        /// <summary>
        /// 駐車場差分項目リスト
        /// </summary>
        public Dictionary<string, string> DiffColumnList
        {
            get;
            set;
        }

        /// <summary>
        /// 駐車場全項目Dictionary
        /// </summary>
        public Dictionary<string, string> AllColumnValueDict
        {
            get;
            set;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 省略単語設定ファイル
    /// </summary>
    public class AbbreviationSettingData
    {
        /// <summary>
        /// 省略前単語
        /// 省略前の単語
        /// </summary>
        public string AbbreviationBeforeWord { get; set; }

        /// <summary>
        /// 省略語単語
        /// 省略後の単語
        /// </summary>
        public string AbbreviationWord { get; set; }
    }
}

﻿using System;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 対象外交差点
    /// </summary>
    public class OverCrsnoData
    {
        /// <summary>
        /// 2次メッシュコード
        /// </summary>
        public string MeshCode { get; set; }

        /// <summary>
        /// 交差点番号
        /// </summary>
        public string CrsID { get; set; }

        /// <summary>
        /// 目印コード
        /// </summary>
        public string MarkCode { get; set; }
    }
}

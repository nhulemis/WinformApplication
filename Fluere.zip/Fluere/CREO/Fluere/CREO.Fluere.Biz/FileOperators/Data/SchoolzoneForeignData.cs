﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 今回出典-スクールゾーンファイル-外国人インプットデータファイル
    /// </summary>
    public class SchoolzoneForeignData
    {
        /// <summary>
        /// OID
        /// </summary>
        public string SchoolzoneForeignOID
        {
            get;
            set;
        }

        /// <summary>
        /// 差分区分（N：新規　C：変更　D：削除）
        /// </summary>
        public string DiffFlag
        {
            get;
            set;
        }

        /// <summary>
        /// 差分明細
        /// </summary>
        public string DiffDetail
        {
            get;
            set;
        }

        /// <summary>
        /// 施設物件拡張のOID
        /// </summary>
        public string OID
        {
            get;
            set;
        }

        /// <summary>
        /// 出典ID
        /// </summary>
        public string MaterialID
        {
            get;
            set;
        }

        /// <summary>
        /// 物件住所（漢字）
        /// </summary>
        public string AdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string Telno
        {
            get;
            set;
        }

        /// <summary>
        /// 正式漢字名称
        /// </summary>
        public string FormalNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 正式カナ名称
        /// </summary>
        public string FormalNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 表示漢字名称
        /// </summary>
        public string DispNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 2次メッシュコード
        /// </summary>
        public string Meshcode
        {
            get;
            set;
        }

        /// <summary>
        /// 絶対座標：東経
        /// </summary>
        public string Longitude
        {
            get;
            set;
        }

        /// <summary>
        /// 絶対座標：北緯
        /// </summary>
        public string Latitude
        {
            get;
            set;
        }
    }
}

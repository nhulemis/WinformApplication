﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 英字変換分類一覧設定ファイルデータ
    /// </summary>
    public class EnConvertTypeData
    {
        /// <summary>
        /// 番号
        /// </summary>
        public string No { get; set; }

        /// <summary>
        /// 納品対象
        /// </summary>
        public string DeliverObject { get; set; }

        /// <summary>
        /// 文字種別コード
        /// </summary>
        public ushort? TxtType { get; set; }

        /// <summary>
        /// 文字種別名称
        /// </summary>
        public string TypName { get; set; }

        /// <summary>
        /// 変換パターン1
        /// </summary>
        public string ConvertPattern_1 { get; set; }

        /// <summary>
        /// 変換パターン2
        /// </summary>
        public string ConvertPattern_2 { get; set; }

        /// <summary>
        /// 変換パターン3
        /// </summary>
        public string ConvertPattern_3 { get; set; }

        /// <summary>
        /// 変換パターン4
        /// </summary>
        public string ConvertPattern_4 { get; set; }

        /// <summary>
        /// 変換パターン5
        /// </summary>
        public string ConvertPattern_5 { get; set; }

        /// <summary>
        /// 変換パターン6
        /// </summary>
        public string ConvertPattern_6 { get; set; }

        /// <summary>
        /// 変換パターン7
        /// </summary>
        public string ConvertPattern_7 { get; set; }

        /// <summary>
        /// 変換パターン8
        /// </summary>
        public string ConvertPattern_8 { get; set; }

        /// <summary>
        /// 変換パターン強制
        /// </summary>
        public string ForceConvertPattern { get; set; }

        /// <summary>
        /// 変換パラメータ①
        /// </summary>
        public string ConvertParameter_1 { get; set; }

        /// <summary>
        /// 変換パラメータ②
        /// </summary>
        public string ConvertParameter_2 { get; set; }

        /// <summary>
        /// 変換パラメータ③
        /// </summary>
        public string ConvertParameter_3 { get; set; }

        /// <summary>
        /// 変換パラメータ④
        /// </summary>
        public string ConvertParameter_4 { get; set; }

        /// <summary>
        /// 変換パラメータ⑤
        /// </summary>
        public string ConvertParameter_5 { get; set; }

        /// <summary>
        /// 変換パラメータ⑥
        /// </summary>
        public string ConvertParameter_6 { get; set; }
    }
}

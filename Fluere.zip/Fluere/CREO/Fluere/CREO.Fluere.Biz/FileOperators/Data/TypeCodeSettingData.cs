﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 文字種別の設定ファイル
    /// </summary>
    public class TypeCodeSettingData
    {
        /// <summary>
        /// 有効フラグ
        /// </summary>
        public int EffectiveFlag { get; set; }

        /// <summary>
        /// 文字種別
        /// </summary>
        public int TypeCode { get; set; }

        /// <summary>
        /// 優先順位
        /// </summary>
        public int Priority { get; set; }

        /// <summary>
        /// レベル一致
        /// </summary>
        public int LevelMatch { get; set; }

        /// <summary>
        /// 中抜け許容
        /// </summary>
        public int Permissible { get; set; }

        /// <summary>
        /// 文字種別名
        /// </summary>
        public string TypeName { get; set; }
    }
}

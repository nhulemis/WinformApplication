﻿using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 形状マッチングファイル（正方向）
    /// </summary>
    public class PositiveShapeMatchingData
    {
        /// <summary>
        /// 表示MM道路
        /// </summary>
        public string RoadNoWithMesh { get; set; }

        /// <summary>
        /// NG検査パターン番号
        /// </summary>
        public string NGPatternNo { get; set; }

        /// <summary>
        /// 領域フラグ
        /// </summary>
        public string AreaFlag { get; set; }

        /// <summary>
        /// 対応数
        /// </summary>
        public string LinkCount { get; set; }

        /// <summary>
        /// 対応リンク(方向・基幹道路)
        /// </summary>
        public List<PositiveShapeMatchingRelateData> RelateData { get; set; }
    }

    /// <summary>
    /// 形状マッチングファイル（正方向）の対応リンク情報
    /// </summary>
    public class PositiveShapeMatchingRelateData
    {
        /// <summary>
        /// コンストラクター
        /// </summary>
        public PositiveShapeMatchingRelateData()
        {
            OID = string.Empty;
            Direction = string.Empty;
        }

        /// <summary>
        /// 基幹道路OID
        /// </summary>
        public string OID { get; set; }

        /// <summary>
        /// リンク方向
        /// </summary>
        public string Direction { get; set; }
    }
}

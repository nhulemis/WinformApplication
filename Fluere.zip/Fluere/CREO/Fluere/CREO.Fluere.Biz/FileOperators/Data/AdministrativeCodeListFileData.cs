﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 市区町村リストファイルのデータクラス
    /// </summary>
    public class AdministrativeCodeListFileData
    {
        /// <summary>
        /// 市区町村リスト
        /// </summary>
        private List<string> administrativeCodeList = new List<string>();

        /// <summary>
        /// 市区町村リスト
        /// </summary>
        public List<string> AdministrativeCodeList
        {
            get { return administrativeCodeList; }
            set { administrativeCodeList = value; }
        }
    }
}

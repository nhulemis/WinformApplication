﻿using System;
using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// マッチングリストファイル
    /// </summary>
    public class MatchingListMeshData
    {
        /// <summary>
        /// 交差点目印のOID
        /// </summary>
        public string CrsMarkOID { get; set; }

        /// <summary>
        /// マッチングステータス
        /// </summary>
        public string MatchingStatus { get; set; }

        /// <summary>
        /// 交差点目印整備対象フラグ
        /// </summary>
        public string CrsMarkCodeFlg { get; set; }

        /// <summary>
        /// 目印コード整備対象フラグ
        /// </summary>
        public string MarkCodeFlg { get; set; }

        /// <summary>
        /// メンテナンス日
        /// </summary>
        public string MaintenanceDay { get; set; }

        /// <summary>
        /// 手動マッチングOID
        /// </summary>
        public string ManualOID { get; set; }

        /// <summary>
        /// 交差点データ番号
        /// </summary>
        public List<string> CrsNo { get; set; }

        /// <summary>
        /// 2次メッシュコード
        /// </summary>
        public string MeshCode { get; set; }

        /// <summary>
        /// 交差点目印コード
        /// </summary>
        public string CrsMarkCode { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 方書複合条件ファイルと漢字掲載名複合条件ファイルが共有
    /// </summary>
    public class MatrixCoKanjiData
    {
        /// <summary>
        /// 条件種別
        /// </summary>
        private string _condCatalog;

        /// <summary>
        /// 複合可/否(0=複合許可, 1=複合禁止)
        /// </summary>
        private List<int> _multipleCondFlagList;

        /// <summary>
        /// 条件種別
        /// </summary>
        public string CondCatalog
        {
            get { return this._condCatalog; }
            set { this._condCatalog = value; }
        }

        /// <summary>
        /// 複合可/否(0=複合許可, 1=複合禁止)
        /// </summary>
        public List<int> MultipleCondFlagList
        {
            get { return this._multipleCondFlagList; }
            set { this._multipleCondFlagList = value; }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 音声発注リストファイル
    /// </summary>
    public class VoiceOrderFileData
    {
        /// <summary>
        /// V_FILE+VoiceTypCode
        /// </summary>
        public string V_FILE_VoiceTypCode { get; set; }

        /// <summary>
        /// よみがなキー
        /// </summary>
        public string YomiKey { get; set; }
        
        /// <summary>
        /// よみ名称
        /// </summary>
        public string YomiName { get; set; }

        /// <summary>
        /// 音声種別コード
        /// </summary>
        public string VoiceTypCode { get; set; }

        /// <summary>
        /// 音声ID
        /// </summary>
        public string VoiceID { get; set; }

        /// <summary>
        /// ファイル名
        /// </summary>
        public string VoiceFileName { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string VoiceKanjiName { get; set; }

        /// <summary>
        /// 整備状況コード
        /// </summary>
        public string MaintStateCode { get; set; }
    }
}

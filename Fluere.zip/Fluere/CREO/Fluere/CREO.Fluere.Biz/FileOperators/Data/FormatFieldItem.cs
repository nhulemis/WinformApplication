﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// ファイルフォーマット設定ファイルを読み込み用クラス
    /// </summary>
    /// <returns>ファイルフォーマット</returns>
    public class FormatFieldItem
    {
        /// <summary>
        /// フィルタ名
        /// </summary>
        public string StrFieldName { get; set; }

        /// <summary>
        /// フィルタタイプ
        /// </summary>
        public string StrTitleName { get; set; }

        /// <summary>
        /// フィルタ編集可/編集不可
        /// </summary>
        public string StrReadOnly { get; set; }

        /// <summary>
        /// フィルタ表示/非表示
        /// </summary>
        public string StrVisibility { get; set; }

        /// <summary>
        /// フィルタ固定/非固定
        /// </summary>
        public string StrFixColumnFlag { get; set; }
    }
}

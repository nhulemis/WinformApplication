﻿using System;
using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 特殊街区の大字小字変換ログファイル
    /// </summary>
    public class GaikuConvertData
    {
        /// <summary>
        /// 変換前の住所コード
        /// </summary>
        public string OldSAdrPntCode { get; set; }

        /// <summary>
        /// 変換前の住所名称
        /// </summary>
        public string OldAdrNameCode { get; set; }

        /// <summary>
        /// 変換後の住所コード
        /// </summary>
        public string NewSAdrPntCode { get; set; }

        /// <summary>
        /// 変換後の住所名称
        /// </summary>
        public string NewAdrNameCode { get; set; }

        /// <summary>
        /// 住所代表点のOID
        /// </summary>
        public string SAdrPntOID { get; set; }

        /// <summary>
        /// 住所代表点の座標の経度
        /// </summary>
        public string SAdrPntLongitude { get; set; }

        /// <summary>
        /// 住所代表点の座標の緯度
        /// </summary>
        public string SAdrPntLatitude { get; set; }
    }
}

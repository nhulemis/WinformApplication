﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 比較対象外文字リストデータ
    /// </summary>
    public class TwnAdrExclusionCharactersData
    {
        /// <summary>
        /// 比較対象外文字リストの初期化
        /// </summary>
        private List<string> addNoCompare = new List<string>();

        /// <summary>
        /// 比較対象外文字リスト
        /// </summary>
        public List<string> AddNoCompareList
        {
            get { return addNoCompare; }
        }
    }
}

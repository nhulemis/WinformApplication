﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// GRXグループデータファイル
    /// </summary>
    public class GrxGroupData
    {
        #region フィールド定義
        /// <summary>
        /// 入力年月日
        /// </summary>
        private string _inputDate;

        /// <summary>
        /// ユーザー名
        /// </summary>
        private string _userName;

        /// <summary>
        /// グループ種別コード
        /// </summary>
        private int _groTypeCode;

        /// <summary>
        /// グリッド生成マトリクス11
        /// </summary>
        private int _grdMatrix11;

        /// <summary>
        /// グリッド生成マトリクス12
        /// </summary>
        private int _grdMatrix12;

        /// <summary>
        /// グリッド生成マトリクス13
        /// </summary>
        private int _grdMatrix13;

        /// <summary>
        /// グリッド生成マトリクス21
        /// </summary>
        private int _grdMatrix21;

        /// <summary>
        /// グリッド生成マトリクス22
        /// </summary>
        private int _grdMatrix22;

        /// <summary>
        /// グリッド生成マトリクス23
        /// </summary>
        private int _grdMatrix23;

        /// <summary>
        /// ノーマライズマトリクス11
        /// </summary>
        private int _normalMatrix11;

        /// <summary>
        /// ノーマライズマトリクス12
        /// </summary>
        private int _normalMatrix12;

        /// <summary>
        /// ノーマライズマトリクス13
        /// </summary>
        private int _normalMatrix13;

        /// <summary>
        /// ノーマライズマトリクス21
        /// </summary>
        private int _normalMatrix21;

        /// <summary>
        /// ノーマライズマトリクス22
        /// </summary>
        private int _normalMatrix22;

        /// <summary>
        /// ノーマライズマトリクス23
        /// </summary>
        private int _normalMatrix23;

        /// <summary>
        /// セル数
        /// </summary>
        private int _cellNum;

        /// <summary>
        /// GRXセルデータリスト
        /// </summary>
        private List<GrxCellData> _grxCellDataList;
        #endregion

        #region getter and setter

        /// <summary>
        /// Grx ファイル名前
        /// </summary>
        public string InputGrxFolderName
        {
            get;
            set;
        }

        /// <summary>
        /// 入力年月日
        /// </summary>
        public string InputDate
        {
            get { return _inputDate; }
            set { _inputDate = value; }
        }

        /// <summary>
        /// ユーザー名
        /// </summary>
        public string UserName
        {
            get { return _userName; }
            set { _userName = value; }
        }

        /// <summary>
        /// グループ種別コード
        /// </summary>
        public int GroTypeCode
        {
            get { return _groTypeCode; }
            set { _groTypeCode = value; }
        }

        /// <summary>
        /// グリッド生成マトリクス11
        /// </summary>
        public int GrdMatrix11
        {
            get { return _grdMatrix11; }
            set { _grdMatrix11 = value; }
        }

        /// <summary>
        /// グリッド生成マトリクス12
        /// </summary>
        public int GrdMatrix12
        {
            get { return _grdMatrix12; }
            set { _grdMatrix12 = value; }
        }

        /// <summary>
        /// グリッド生成マトリクス13
        /// </summary>
        public int GrdMatrix13
        {
            get { return _grdMatrix13; }
            set { _grdMatrix13 = value; }
        }

        /// <summary>
        /// グリッド生成マトリクス21
        /// </summary>
        public int GrdMatrix21
        {
            get { return _grdMatrix21; }
            set { _grdMatrix21 = value; }
        }

        /// <summary>
        /// グリッド生成マトリクス22
        /// </summary>
        public int GrdMatrix22
        {
            get { return _grdMatrix22; }
            set { _grdMatrix22 = value; }
        }

        /// <summary>
        /// グリッド生成マトリクス23
        /// </summary>
        public int GrdMatrix23
        {
            get { return _grdMatrix23; }
            set { _grdMatrix23 = value; }
        }

        /// <summary>
        /// ノーマライズマトリクス11
        /// </summary>
        public int NormalMatrix11
        {
            get { return _normalMatrix11; }
            set { _normalMatrix11 = value; }
        }

        /// <summary>
        /// ノーマライズマトリクス12
        /// </summary>
        public int NormalMatrix12
        {
            get { return _normalMatrix12; }
            set { _normalMatrix12 = value; }
        }

        /// <summary>
        ///  ノーマライズマトリクス13
        /// </summary>
        public int NormalMatrix13
        {
            get { return _normalMatrix13; }
            set { _normalMatrix13 = value; }
        }

        /// <summary>
        /// ノーマライズマトリクス21
        /// </summary>
        public int NormalMatrix21
        {
            get { return _normalMatrix21; }
            set { _normalMatrix21 = value; }
        }

        /// <summary>
        /// ノーマライズマトリクス22
        /// </summary>
        public int NormalMatrix22
        {
            get { return _normalMatrix22; }
            set { _normalMatrix22 = value; }
        }

        /// <summary>
        ///  ノーマライズマトリクス23
        /// </summary>
        public int NormalMatrix23
        {
            get { return _normalMatrix23; }
            set { _normalMatrix23 = value; }
        }

        /// <summary>
        /// セル数
        /// </summary>
        public int CellNum
        {
            get { return _cellNum; }
            set { _cellNum = value; }
        }

        /// <summary>
        /// GRXセルデータリスト
        /// </summary>
        public List<GrxCellData> GrxCellDataList
        {
            get { return _grxCellDataList; }
            set { _grxCellDataList = value; }
        }
        #endregion
    }
}

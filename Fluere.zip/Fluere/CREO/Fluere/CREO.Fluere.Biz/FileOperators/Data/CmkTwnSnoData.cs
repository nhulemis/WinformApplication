﻿using System;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 交差点目印丸
    /// </summary>
    public class CmkTwnSnoData
    {
        /// <summary>
        /// 交差点目印の【目印名称】[目印コード]
        /// </summary>
        public string MarkCode_1 { get; set; }

        /// <summary>
        /// 交差点目印に対応するタウン物件か施設物件の【目印名称】[目印コード]
        /// </summary>
        public string MarkCode_2 { get; set; }
    }
}

﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// TopoMapDataクラス
    /// </summary>
    public class TopoMapData
    {
        /// <summary>
        /// 2次メッシュ
        /// </summary>
        public string MeshNo
        {
            get;
            set;
        }

        /// <summary>
        /// 地形図名称（漢字）
        /// </summary>
        public string MapNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 発行年月日
        /// </summary>
        public string PublishDate
        {
            get;
            set;
        }

        /// <summary>
        /// 改測年月日
        /// </summary>
        public string ResurveyDate
        {
            get;
            set;
        }

        /// <summary>
        /// 2万5千分の1地形図番号
        /// </summary>
        public ushort? TopoMap25kNo
        {
            get;
            set;
        }

        /// <summary>
        /// ５万分の１地形図番号
        /// </summary>
        public ushort? TopoMap50kNo
        {
            get;
            set;
        }

        /// <summary>
        /// 地勢図名称
        /// </summary>
        public string GeographicMapName
        {
            get;
            set;
        }

        /// <summary>
        /// 左上経度（度）
        /// </summary>
        public long leftUpLongitude
        {
            get;
            set;
        }

        /// <summary>
        /// 左上経度（分）
        /// </summary>
        public long leftUpLongitudeMinute
        {
            get;
            set;
        }

        /// <summary>
        /// 左上経度（秒）
        /// </summary>
        public long leftUpLongitudeSecond
        {
            get;
            set;
        }

        /// <summary>
        /// 左下経度（度）
        /// </summary>
        public long leftDownLongitude
        {
            get;
            set;
        }

        /// <summary>
        /// 左下経度（分）
        /// </summary>
        public long leftDownLongitudeMinute
        {
            get;
            set;
        }

        /// <summary>
        /// 左下経度（秒）
        /// </summary>
        public long leftDownLongitudeSecond
        {
            get;
            set;
        }

        /// <summary>
        /// 左下緯度（度）
        /// </summary>
        public long leftDownLatitude
        {
            get;
            set;
        }

        /// <summary>
        /// 左下緯度（分）
        /// </summary>
        public long leftDownLatitudeMinute
        {
            get;
            set;
        }

        /// <summary>
        /// 左下緯度（秒）
        /// </summary>
        public long leftDownLatitudeSecond
        {
            get;
            set;
        }

        /// <summary>
        /// 左上緯度（度）
        /// </summary>
        public long leftUpLatitude
        {
            get;
            set;
        }

        /// <summary>
        /// 左上緯度（分）
        /// </summary>
        public long leftUpLatitudeMinute
        {
            get;
            set;
        }

        /// <summary>
        /// 左上緯度（秒）
        /// </summary>
        public long leftUpLatitudeSecond
        {
            get;
            set;
        }

        /// <summary>
        /// 右上経度（度）
        /// </summary>
        public long rightUpLongitude
        {
            get;
            set;
        }

        /// <summary>
        /// 右上経度（分）
        /// </summary>
        public long rightUpLongitudeMinute
        {
            get;
            set;
        }

        /// <summary>
        /// 右上経度（秒）
        /// </summary>
        public long rightUpLongitudeSecond
        {
            get;
            set;
        }

        /// <summary>
        /// 右下経度（度）
        /// </summary>
        public long rightDownLongitude
        {
            get;
            set;
        }

        /// <summary>
        /// 右下経度（分）
        /// </summary>
        public long rightDownLongitudeMinute
        {
            get;
            set;
        }

        /// <summary>
        /// 右下経度（秒）
        /// </summary>
        public long rightDownLongitudeSecond
        {
            get;
            set;
        }

        /// <summary>
        /// 右下緯度（度）
        /// </summary>
        public long rightDownLatitude
        {
            get;
            set;
        }

        /// <summary>
        /// 右下緯度（分）
        /// </summary>
        public long rightDownLatitudeMinute
        {
            get;
            set;
        }

        /// <summary>
        /// 右下緯度（秒）
        /// </summary>
        public long rightDownLatitudeSecond
        {
            get;
            set;
        }

        /// <summary>
        /// 右上緯度（度）
        /// </summary>
        public long rightUpLatitude
        {
            get;
            set;
        }

        /// <summary>
        /// 右上緯度（分）
        /// </summary>
        public long rightUpLatitudeMinute
        {
            get;
            set;
        }

        /// <summary>
        /// 右上緯度（秒）
        /// </summary>
        public long rightUpLatitudeSecond
        {
            get;
            set;
        }
    }
}

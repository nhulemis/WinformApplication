﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 特別対応リストファイル
    /// </summary>
    public class SpecialListInputListData
    {
        /// <summary>
        /// Ｎｏ
        /// </summary>
        public int SpecialListNo
        {
            get;
            set;
        }

        /// <summary>
        /// 都道府県コード
        /// </summary>
        public string ProvinceCode
        {
            get;
            set;
        }

        /// <summary>
        /// 市区町村コード
        /// </summary>
        public string CityCode
        {
            get;
            set;
        }

        /// <summary>
        /// 大字コード
        /// </summary>
        public string OazaCode
        {
            get;
            set;
        }

        /// <summary>
        /// 小字コード
        /// </summary>
        public string SectionCode
        {
            get;
            set;
        }

        /// <summary>
        /// 街区符号
        /// </summary>
        public string GaikuCode
        {
            get;
            set;
        }

        /// <summary>
        /// 住居番号
        /// </summary>
        public string HouseNo
        {
            get;
            set;
        }

        /// <summary>
        /// 地番
        /// </summary>
        public string LotNo
        {
            get;
            set;
        }

        /// <summary>
        /// 枝番
        /// </summary>
        public string SuffixNo
        {
            get;
            set;
        }

        /// <summary>
        /// 住所名称
        /// </summary>
        public string AdrName
        {
            get;
            set;
        }

        /// <summary>
        /// ２MC
        /// </summary>
        public int MC
        {
            get;
            set;
        }

        /// <summary>
        /// X座標
        /// </summary>
        public long Longitude
        {
            get;
            set;
        }

        /// <summary>
        /// Y座標
        /// </summary>
        public long Latitude
        {
            get;
            set;
        }

        /// <summary>
        /// 確認項目
        /// </summary>
        public string ConfirmType
        {
            get;
            set;
        }

        /// <summary>
        /// 確認内容
        /// </summary>
        public string ConfirmContent
        {
            get;
            set;
        }

        /// <summary>
        /// 問連管理No
        /// </summary>
        public string RelatedMngNo
        {
            get;
            set;
        }

        /// <summary>
        /// 管理表登録日
        /// </summary>
        public string EntryDate
        {
            get;
            set;
        }
    }
}

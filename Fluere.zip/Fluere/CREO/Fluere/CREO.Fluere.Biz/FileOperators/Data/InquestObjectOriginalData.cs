﻿// -----------------------------------------------------------------------
// <copyright file="InquestObjectOriginal.cs" company="Hewlett-Packard Company">
// TODO: Update copyright text.
// </copyright>
// -----------------------------------------------------------------------

using CREO.DataModel;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 目印調査対象原稿
    /// </summary>
    public class InquestObjectOriginalData
    {
        #region フィールド定義
        /// <summary>
        /// タウン物件OID
        /// </summary>
        private string oid = null;

        /// <summary>
        /// 行政JISコード
        /// </summary>
        private string adrc = null;

        /// <summary>
        /// 電話番号
        /// </summary>
        private string tn = null;

        /// <summary>
        /// NTT分類コード
        /// </summary>
        private string nc = null;

        /// <summary>
        /// NTT分類名
        /// </summary>
        private string ncn = null;

        /// <summary>
        /// 目印コード
        /// </summary>
        private string mnf = null;

        /// <summary>
        /// 目印名称
        /// </summary>
        private string ckj = null;

        /// <summary>
        /// 漢字掲載名
        /// </summary>
        private string kj = null;

        /// <summary>
        /// カナ掲載名
        /// </summary>
        private string kn = null;

        /// <summary>
        /// 住所名称
        /// </summary>
        private string an = null;

        /// <summary>
        /// 設定可否コード
        /// </summary>
        private string cd = null;

        /// <summary>
        /// 備考
        /// </summary>
        private string bk = null;
        #endregion

        #region Constructor
        /// <summary>
        /// Constructor
        /// </summary>
        public InquestObjectOriginalData()
        {
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="stwnPOI">タウン物件</param>
        /// <param name="provinceCode">タウン物件が参照する住所名称の都道府県コード0詰め2桁）</param>
        /// <param name="adminCode">タウン物件が参照する住所名称の市区町村コード（0詰め3桁）</param>
        /// <param name="provinceName">タウン物件が参照する住所名称の都道府県名称</param>
        /// <param name="adminName">タウン物件が参照する住所名称の市区町村名称</param>
        public InquestObjectOriginalData(
            STwnPOI stwnPOI,
            string provinceCode,
            string adminCode,
            string provinceName,
            string adminName)
        {
            // oid タウン物件OID タウン物件（STwnPOI）の実体OID
            this.oid = stwnPOI.OID.ToString();

            // 行政JISコード
            this.SetAdrc(provinceCode, adminCode);

            // tn 電話番号 タウン物件の電話番号
            this.tn = stwnPOI.Tel;

            // nc NTT分類コード タウン物件が参照するタウンジャンルより取得（NTT分類：コード）
            if (stwnPOI.GnrTwn != null && stwnPOI.GnrTwn.NTTCode != null)
            {
                this.nc = stwnPOI.GnrTwn.NTTCode;
            }

            // ncn NTT分類名 タウン物件が参照するタウンジャンルより取得（NTT分類：名称（漢字））
            if (stwnPOI.GnrTwn != null && stwnPOI.GnrTwn.NTTGroupNameMultiLang != null)
            {
                MultiLangCollection nTTName = stwnPOI.GnrTwn.NTTGroupNameMultiLang;

                if (nTTName[CommonConstants.MULTLANG_JA_JAPAN] != null &&
                    nTTName[CommonConstants.MULTLANG_JA_JAPAN].Name != null)
                {
                    this.ncn = nTTName[CommonConstants.MULTLANG_JA_JAPAN].Name;
                }
            }

            // 「目印コード」を「目印取得基準リストファイル」の目印コードに設定する
            ////// mnf 目印コード タウン物件が参照する目印名称より取得（目印コード）
            ////if ((stwnPOI.MarkName != null) && (stwnPOI.MarkName.MarkCode != null))
            ////{
            ////    this.mnf = stwnPOI.MarkName.MarkCode.ToString();
            ////}
            ////// ckj 目印名称 タウン物件が参照する目印名称より取得（正式名称（漢字））
            ////if (stwnPOI.MarkName != null && stwnPOI.MarkName.FormalNameMultiLang != null)
            ////{
            ////    MultiLangCollection forMalName = stwnPOI.MarkName.FormalNameMultiLang;

            ////    if (forMalName[CommonConstants.MULTLANG_JA_JAPAN] != null &&
            ////        forMalName[CommonConstants.MULTLANG_JA_JAPAN].Name != null)
            ////    {
            ////        this.ckj = forMalName[CommonConstants.MULTLANG_JA_JAPAN].Name;
            ////    }
            ////}

            // kj 漢字掲載名 タウン物件の掲載名（漢字）
            if (stwnPOI.TwnMultiLang != null && 
                stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN] != null &&
                stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name != null)
            {
                this.kj = stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_JAPAN].Name;
            }

            // kn カナ掲載名 タウン物件の掲載名（片仮名）
            if (stwnPOI.TwnMultiLang != null &&
                stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_KANA] != null &&
                stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_KANA].Name != null)
            {
                this.kn = stwnPOI.TwnMultiLang[CommonConstants.MULTLANG_JA_KANA].Name;
            }

            // 住所名称
            this.SetAn(
                provinceName,
                adminName,
                stwnPOI);

            // cd 設定可否コード NULL固定
            this.cd = null;

            // bk 備考 NULL許容
            this.bk = null;
        }
        #endregion

        #region getter and setter
        /// <summary>
        /// タウン物件OID
        /// </summary>
        public string Oid
        {
            get { return oid; }
            set { oid = value; }
        }

        /// <summary>
        /// 行政JISコード
        /// </summary>
        public string Adrc
        {
            get { return adrc; }
            set { adrc = value; }
        }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string Tn
        {
            get { return tn; }
            set { tn = value; }
        }

        /// <summary>
        /// NTT分類コード
        /// </summary>
        public string Nc
        {
            get { return nc; }
            set { nc = value; }
        }

        /// <summary>
        /// NTT分類名
        /// </summary>
        public string Ncn
        {
            get { return ncn; }
            set { ncn = value; }
        }

        /// <summary>
        /// 目印コード
        /// </summary>
        public string Mnf
        {
            get { return mnf; }
            set { mnf = value; }
        }

        /// <summary>
        /// 目印名称
        /// </summary>
        public string Ckj
        {
            get { return ckj; }
            set { ckj = value; }
        }

        /// <summary>
        /// 漢字掲載名
        /// </summary>
        public string Kj
        {
            get { return kj; }
            set { kj = value; }
        }

        /// <summary>
        /// カナ掲載名
        /// </summary>
        public string Kn
        {
            get { return kn; }
            set { kn = value; }
        }

        /// <summary>
        /// 住所名称
        /// </summary>
        public string An
        {
            get { return an; }
            set { an = value; }
        }

        /// <summary>
        /// 設定可否コード
        /// </summary>
        public string Cd
        {
            get { return cd; }
            set { cd = value; }
        }

        /// <summary>
        /// 備考
        /// </summary>
        public string Bk
        {
            get { return bk; }
            set { bk = value; }
        }

        /// <summary>
        /// 行政JISコード<br/>
        /// タウン物件が参照する住所名称の都道府県コード（0詰め2桁）<br/>
        /// タウン物件が参照する住所名称の市区町村コード（0詰め3桁）<br/>
        /// を連結
        /// </summary>
        /// <param name="provinceCode">タウン物件が参照する住所名称の都道府県コード<br/>
        /// （0詰め2桁）</param>
        /// <param name="adminCode">タウン物件が参照する住所名称の市区町村コード（0詰め3桁）</param>
        public void SetAdrc(string provinceCode, string adminCode)
        {
            // adrc 行政JISコード タウン物件が参照する住所名称の都道府県コード（0詰め2桁）
            provinceCode = StringUtil.FillLengthAtHeadByZero(provinceCode, 2);

            // タウン物件が参照する住所名称の市区町村コード（0詰め3桁）
            adminCode = StringUtil.FillLengthAtHeadByZero(adminCode, 3);

            // 連結
            this.adrc = provinceCode + adminCode;
        }

        /// <summary>
        /// 住所名称<br/>
        /// タウン物件が参照する住所名称の都道府県名<br/>
        /// タウン物件が参照する住所名称の市区町村名<br/>
        /// タウン物件の大字・通称名<br/>
        /// タウン物件の字・丁目名<br/>
        /// タウン物件の街区番号・部屋番号<br/>
        /// タウン物件の方書<br/>
        /// を「／」（区切り文字）で連結
        /// </summary>
        /// <param name="provinceName">provinceName</param>
        /// <param name="adminName">adminName</param>
        /// <param name="stwnPOI">stwnPOI</param>
        public void SetAn(string provinceName, string adminName, STwnPOI stwnPOI)
        {
            const string KANJI_KEY = "ja-Jpan";

            string anValue = string.Empty;

            // タウン物件が参照する住所名称の都道府県名
            anValue = anValue + provinceName;

            // タウン物件が参照する住所名称の市区町村名
            anValue = anValue + '／' + adminName;

            // タウン物件の大字・通称名
            if (stwnPOI.OazaMultiLang != null && stwnPOI.OazaMultiLang[KANJI_KEY] != null &&
                stwnPOI.OazaMultiLang[KANJI_KEY].Name != null)
            {
                anValue = anValue + '／' + stwnPOI.OazaMultiLang[KANJI_KEY].Name;
            }
            else
            {
                anValue = anValue + '／';
            }

            // タウン物件の字・丁目名
            if (stwnPOI.AzaMultiLang != null && stwnPOI.AzaMultiLang[KANJI_KEY] != null &&
                stwnPOI.AzaMultiLang[KANJI_KEY].Name != null)
            {
                anValue = anValue + '／' + stwnPOI.AzaMultiLang[KANJI_KEY].Name;
            }
            else
            {
                anValue = anValue + '／';
            }

            // タウン物件の街区番号・部屋番号
            if (stwnPOI.GaikuRoomMultiLang != null &&
                stwnPOI.GaikuRoomMultiLang[KANJI_KEY] != null &&
                stwnPOI.GaikuRoomMultiLang[KANJI_KEY].Name != null)
            {
                anValue = anValue + '／' + stwnPOI.GaikuRoomMultiLang[KANJI_KEY].Name;
            }
            else
            {
                anValue = anValue + '／';
            }

            // タウン物件の方書
            if (stwnPOI.KatagakiMultiLang != null &&
                stwnPOI.KatagakiMultiLang[KANJI_KEY] != null &&
                stwnPOI.KatagakiMultiLang[KANJI_KEY].Name != null)
            {
                anValue = anValue + '／' + stwnPOI.KatagakiMultiLang[KANJI_KEY].Name;
            }
            else
            {
                anValue = anValue + '／';
            }

            this.an = anValue;
        }

        /// <summary>
        /// 合致する目印取得基準データ情報を設定する
        /// </summary>
        /// <param name="markCode">目印コード</param>
        /// <param name="markName">目印名称</param>
        public void SetMarkObtainStandardData(string markCode, string markName)
        {
            this.Mnf = markCode;
            this.Ckj = markName;
        }
        #endregion

        /// <summary>
        /// Equals
        /// </summary>
        /// <param name="obj">目印調査対象原稿</param>
        /// <returns>bool</returns>
        public override bool Equals(object obj)
        {
            if (obj is InquestObjectOriginalData)
            {
                InquestObjectOriginalData inquestObjectOriginal = obj as InquestObjectOriginalData;

                return this.Oid.Equals(inquestObjectOriginal.Oid);
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// GetHashCode
        /// </summary>
        /// <returns>HashCode</returns>
        public override int GetHashCode()
        {
            return base.GetHashCode();
        }
    }
}

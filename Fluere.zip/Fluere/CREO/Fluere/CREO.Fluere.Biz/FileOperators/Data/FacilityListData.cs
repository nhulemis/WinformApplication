﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 施設物件リストデータ(文字列)
    /// </summary>
    public class FacilityListData
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public FacilityListData()
        {
            this.WorkType = string.Empty;
            this.OID = string.Empty;
            this.InquestObjectId = string.Empty;
            this.GnrCode = string.Empty;
            this.OpenDate = string.Empty;
            this.DispNameCheckCode = string.Empty;
            this.DispNameKanji = string.Empty;
            this.DispNameKana = string.Empty;
            this.DispNameEnglish = string.Empty;
            this.DispNameTraditional = string.Empty;
            this.DispNameSimplified = string.Empty;
            this.DispNameHangle = string.Empty;
            this.FormalNameKanji = string.Empty;
            this.FormalNameKana = string.Empty;
            this.FormalNameEnglish = string.Empty;
            this.FormalNameTraditional = string.Empty;
            this.FormalNameSimplified = string.Empty;
            this.FormalNameHangle = string.Empty;
            this.PrefecturesCode = string.Empty;
            this.MunicipalityCode = string.Empty;
            this.OazaCode = string.Empty;
            this.KoazaCode = string.Empty;
            this.AdrKanjiName = string.Empty;
            this.SAdrPntLongitude = string.Empty;
            this.SAdrPntLatitude = string.Empty;
            this.ArrivalPntLongitude = string.Empty;
            this.ArrivalPntLatitude = string.Empty;
            this.RoadOID = string.Empty;
            this.ArrivalDirLongitude = string.Empty;
            this.ArrivalDirLatitude = string.Empty;
            this.CampgroundInfo0 = string.Empty;
            this.CampSite = string.Empty;
            this.CeremonyHallInfo0 = string.Empty;
            this.CeremonyHallInfo1 = string.Empty;
            this.CeremonyHallInfo2 = string.Empty;
            this.CommonInfo0 = string.Empty;
            this.CommonInfo1 = string.Empty;
            this.CommonInfo2 = string.Empty;
            this.CommonInfo3 = string.Empty;
            this.CommonInfo4 = string.Empty;
            this.CommonInfo5 = string.Empty;
            this.CommonInfo6 = string.Empty;
            this.ContactName = string.Empty;
            this.ContactTel = string.Empty;
            this.GolfCourse = string.Empty;
            this.GolfHall = string.Empty;
            this.GolfInfo0 = string.Empty;
            this.GolfInfo1 = string.Empty;
            this.GolfInfo2 = string.Empty;
            this.GolfInfo3 = string.Empty;
            this.GolfPar = string.Empty;
            this.HallInfo0 = string.Empty;
            this.HallInfo1 = string.Empty;
            this.HallInfo2 = string.Empty;
            this.HeadCopy = string.Empty;
            this.HospitalInfo0 = string.Empty;
            this.HospitalInfo1 = string.Empty;
            this.HospitalInfo2 = string.Empty;
            this.HotelInfo0 = string.Empty;
            this.HotelRoom = string.Empty;
            this.Introduction = string.Empty;
            this.CrsMarkCode = string.Empty;
            this.HWFacilityName = string.Empty;
            this.StationFacilityName = string.Empty;
            this.FerryFacilityName = string.Empty;
            this.ParkArea = string.Empty;
            this.ParkInfo0 = string.Empty;
            this.ParkInfo1 = string.Empty;
            this.RateStructureCode = string.Empty;
            this.SAPAMemo = string.Empty;
            this.SellTypeCode = string.Empty;
            this.ShoppingMallArea = string.Empty;
            this.ShoppingMallInfo0 = string.Empty;
            this.ShrineInfo0 = string.Empty;
            this.SpaInfo0 = string.Empty;
            this.SpaInfo1 = string.Empty;
            this.TelInfoAry = string.Empty;
            this.ToyotaDealerInfo0 = string.Empty;
            this.ToyotaDealerInfo1 = string.Empty;
            this.URL = string.Empty;
            this.WeddingInfo0 = string.Empty;
            this.WeddingInfo1 = string.Empty;
            this.WellnessID = string.Empty;
            this.ShoppingCenterFlg = string.Empty;
            this.ClosedStartDay = string.Empty;
            this.ClosedEndDay = string.Empty;
            this.RestRoom = string.Empty;
            this.BarrierFree = string.Empty;
            this.ParkingLot = string.Empty;
            this.Open24h = string.Empty;
            this.YearHalfClosed = string.Empty;
            this.SSignTxtViewDispNameKanji = string.Empty;
            this.SSignTxtViewDispNameKana = string.Empty;
            this.SSignTxtViewTxtTypCode = string.Empty;
            this.SSignTxtViewDeliveryDateStr = string.Empty;
            this.SSignTxtViewBankInfo0 = string.Empty;
            this.SSignTxtViewCommonInfo0 = string.Empty;
            this.SSignTxtViewCommonInfo1 = string.Empty;
            this.SSignTxtViewCommonInfo2 = string.Empty;
            this.SSignTxtViewCommonInfo3 = string.Empty;
            this.SSignTxtViewContactName = string.Empty;
            this.SSignTxtViewContactTel = string.Empty;
            this.SSignTxtViewPostOfficeInfo0 = string.Empty;
            this.SSignTxtViewSchoolInfo0 = string.Empty;
            this.SSignTxtViewToyotaSupplierCode = string.Empty;
            this.InquestMemo = string.Empty;
        }

        /// <summary>
        /// 作業種類
        /// </summary>
        public string WorkType
        {
            get;
            set;
        }

        /// <summary>
        /// OID
        /// </summary>
        public string OID
        {
            get;
            set;
        }

        /// <summary>
        /// 調査対象ID
        /// </summary>
        public string InquestObjectId
        {
            get;
            set;
        }

        /// <summary>
        /// ジャンルコード
        /// </summary>
        public string GnrCode
        {
            get;
            set;
        }

        /// <summary>
        /// オープン日付
        /// </summary>
        public string OpenDate
        {
            get;
            set;
        }

        /// <summary>
        /// 表示名称確認コード
        /// </summary>
        public string DispNameCheckCode
        {
            get;
            set;
        }

        /// <summary>
        /// 表示名称：漢字
        /// </summary>
        public string DispNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 表示名称：カナ
        /// </summary>
        public string DispNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 表示名称：英字
        /// </summary>
        public string DispNameEnglish
        {
            get;
            set;
        }

        /// <summary>
        /// 表示名称：中国語(繁体)
        /// </summary>
        public string DispNameTraditional
        {
            get;
            set;
        }

        /// <summary>
        /// 表示名称：中国語(簡体)
        /// </summary>
        public string DispNameSimplified
        {
            get;
            set;
        }

        /// <summary>
        /// 表示名称：韓国語
        /// </summary>
        public string DispNameHangle
        {
            get;
            set;
        }

        /// <summary>
        /// 正式名称：漢字
        /// </summary>
        public string FormalNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 正式名称：カナ
        /// </summary>
        public string FormalNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 正式名称：英字
        /// </summary>
        public string FormalNameEnglish
        {
            get;
            set;
        }

        /// <summary>
        /// 正式名称：中国語(繁体)
        /// </summary>
        public string FormalNameTraditional
        {
            get;
            set;
        }

        /// <summary>
        /// 正式名称：中国語(簡体)
        /// </summary>
        public string FormalNameSimplified
        {
            get;
            set;
        }

        /// <summary>
        /// 正式名称：韓国語
        /// </summary>
        public string FormalNameHangle
        {
            get;
            set;
        }

        /// <summary>
        /// 都道府県コード
        /// </summary>
        public string PrefecturesCode
        {
            get;
            set;
        }

        /// <summary>
        /// 市区町村コード
        /// </summary>
        public string MunicipalityCode
        {
            get;
            set;
        }

        /// <summary>
        /// 大字コード
        /// </summary>
        public string OazaCode
        {
            get;
            set;
        }

        /// <summary>
        /// 小字コード
        /// </summary>
        public string KoazaCode
        {
            get;
            set;
        }

        /// <summary>
        /// 住所名称：方書
        /// </summary>
        public string AdrKanjiName
        {
            get;
            set;
        }

        /// <summary>
        /// 代表点：経度
        /// </summary>
        public string SAdrPntLongitude
        {
            get;
            set;
        }

        /// <summary>
        /// 代表点：緯度
        /// </summary>
        public string SAdrPntLatitude
        {
            get;
            set;
        }

        /// <summary>
        /// 到着点：経度
        /// </summary>
        public string ArrivalPntLongitude
        {
            get;
            set;
        }

        /// <summary>
        /// 到着点：緯度
        /// </summary>
        public string ArrivalPntLatitude
        {
            get;
            set;
        }

        /// <summary>
        /// 基幹道路OID
        /// </summary>
        public string RoadOID
        {
            get;
            set;
        }

        /// <summary>
        /// 到着方向基点：経度
        /// </summary>
        public string ArrivalDirLongitude
        {
            get;
            set;
        }

        /// <summary>
        /// 到着方向基点：緯度
        /// </summary>
        public string ArrivalDirLatitude
        {
            get;
            set;
        }

        /// <summary>
        /// デイキャンプフラグ
        /// </summary>
        public string CampgroundInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// キャンプ場施設数
        /// </summary>
        public string CampSite
        {
            get;
            set;
        }

        /// <summary>
        /// セレモニーホール機能フラグ：ペット専用フラグ
        /// </summary>
        public string CeremonyHallInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// セレモニーホール機能フラグ：火葬場形態フラグ
        /// </summary>
        public string CeremonyHallInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// セレモニーホール機能フラグ：法要形態フラグ
        /// </summary>
        public string CeremonyHallInfo2
        {
            get;
            set;
        }

        /// <summary>
        /// 共通フラグ：跡地確認フラグ
        /// </summary>
        public string CommonInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 共通フラグ：基準外カナフラグ
        /// </summary>
        public string CommonInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// 共通フラグ：電話調査有無フラグ
        /// </summary>
        public string CommonInfo2
        {
            get;
            set;
        }

        /// <summary>
        /// 共通フラグ：有料道到着点フラグ
        /// </summary>
        public string CommonInfo3
        {
            get;
            set;
        }

        /// <summary>
        /// 共通フラグ：離島到着点フラグ
        /// </summary>
        public string CommonInfo4
        {
            get;
            set;
        }

        /// <summary>
        /// 共通フラグ：道路追加要否フラグ
        /// </summary>
        public string CommonInfo5
        {
            get;
            set;
        }

        /// <summary>
        /// 共通フラグ：POI配信対象フラグ
        /// </summary>
        public string CommonInfo6
        {
            get;
            set;
        }

        /// <summary>
        /// 連絡先施設名称
        /// </summary>
        public string ContactName
        {
            get;
            set;
        }

        /// <summary>
        /// 連絡先施設電話番号
        /// </summary>
        public string ContactTel
        {
            get;
            set;
        }

        /// <summary>
        /// ゴルフ場コース数
        /// </summary>
        public string GolfCourse
        {
            get;
            set;
        }

        /// <summary>
        /// ゴルフ場ホール数
        /// </summary>
        public string GolfHall
        {
            get;
            set;
        }

        /// <summary>
        /// ゴルフ場機能フラグ：パークゴルフ場フラグ
        /// </summary>
        public string GolfInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// ゴルフ場機能フラグ：マレットゴルフ場フラグ
        /// </summary>
        public string GolfInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// ゴルフ場機能フラグ：ケイマンゴルフ場フラグ
        /// </summary>
        public string GolfInfo2
        {
            get;
            set;
        }

        /// <summary>
        /// ゴルフ場機能フラグ：パターゴルフ場フラグ
        /// </summary>
        public string GolfInfo3
        {
            get;
            set;
        }

        /// <summary>
        /// ゴルフ場パー数
        /// </summary>
        public string GolfPar
        {
            get;
            set;
        }

        /// <summary>
        /// ホール機能フラグ：ホール座席フラグ
        /// </summary>
        public string HallInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// ホール機能フラグ：ホール音響フラグ
        /// </summary>
        public string HallInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// ホール機能フラグ：ライブハウスフラグ
        /// </summary>
        public string HallInfo2
        {
            get;
            set;
        }

        /// <summary>
        /// ヘッドコピー
        /// </summary>
        public string HeadCopy
        {
            get;
            set;
        }

        /// <summary>
        /// 病院機能フラグ：診療所フラグ
        /// </summary>
        public string HospitalInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 病院機能フラグ：クリニックフラグ
        /// </summary>
        public string HospitalInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// 病院機能フラグ：医院フラグ
        /// </summary>
        public string HospitalInfo2
        {
            get;
            set;
        }

        /// <summary>
        /// ホテル機能フラグ：会員制フラグ
        /// </summary>
        public string HotelInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// ホテルルーム数
        /// </summary>
        public string HotelRoom
        {
            get;
            set;
        }

        /// <summary>
        /// 紹介文
        /// </summary>
        public string Introduction
        {
            get;
            set;
        }

        /// <summary>
        /// 目印コード
        /// </summary>
        public string CrsMarkCode
        {
            get;
            set;
        }

        /// <summary>
        /// 高速：施設名
        /// </summary>
        public string HWFacilityName
        {
            get;
            set;
        }

        /// <summary>
        /// 駅：施設名
        /// </summary>
        public string StationFacilityName
        {
            get;
            set;
        }

        /// <summary>
        /// フェリー：施設名
        /// </summary>
        public string FerryFacilityName
        {
            get;
            set;
        }

        /// <summary>
        /// 公園面積
        /// </summary>
        public string ParkArea
        {
            get;
            set;
        }

        /// <summary>
        /// 公園機能フラグ：国立公園フラグ：国立公園・国定公園
        /// </summary>
        public string ParkInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 公園機能フラグ：国定公園フラグ
        /// </summary>
        public string ParkInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// 宿泊料金体系コード
        /// </summary>
        public string RateStructureCode
        {
            get;
            set;
        }

        /// <summary>
        /// 一口メモ
        /// </summary>
        public string SAPAMemo
        {
            get;
            set;
        }

        /// <summary>
        /// 販売形態コード
        /// </summary>
        public string SellTypeCode
        {
            get;
            set;
        }

        /// <summary>
        /// ショッピングモール面積
        /// </summary>
        public string ShoppingMallArea
        {
            get;
            set;
        }

        /// <summary>
        /// ショッピングモール機能フラグ：SC総称有無フラグ
        /// </summary>
        public string ShoppingMallInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 神社・仏閣機能フラグ：重要文化財フラグ
        /// </summary>
        public string ShrineInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 温泉機能フラグ：一軒宿フラグ
        /// </summary>
        public string SpaInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 温泉機能フラグ：スーパー銭湯フラグ
        /// </summary>
        public string SpaInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string TelInfoAry
        {
            get;
            set;
        }

        /// <summary>
        /// トヨタディーラー機能フラグ：車両展示販売フラグ
        /// </summary>
        public string ToyotaDealerInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// トヨタディーラー機能フラグ：買い取り専門フラグ
        /// </summary>
        public string ToyotaDealerInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// URL
        /// </summary>
        public string URL
        {
            get;
            set;
        }

        /// <summary>
        /// 結婚式場機能フラグ：披露宴会場フラグ
        /// </summary>
        public string WeddingInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 結婚式場機能フラグ：式場形態フラグ
        /// </summary>
        public string WeddingInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// ウェルネスID
        /// </summary>
        public string WellnessID
        {
            get;
            set;
        }

        /// <summary>
        /// 休業開始日
        /// </summary>
        public string ClosedStartDay
        {
            get;
            set;
        }

        /// <summary>
        /// 休業終了日
        /// </summary>
        public string ClosedEndDay
        {
            get;
            set;
        }

        /// <summary>
        /// トイレ有無
        /// </summary>
        public string RestRoom
        {
            get;
            set;
        }

        /// <summary>
        /// バリアフリー対応可否
        /// </summary>
        public string BarrierFree
        {
            get;
            set;
        }

        /// <summary>
        /// 駐車場有無
        /// </summary>
        public string ParkingLot
        {
            get;
            set;
        }

        /// <summary>
        /// 24H営業フラグ
        /// </summary>
        public string Open24h
        {
            get;
            set;
        }

        /// <summary>
        /// 年間半分休業フラグ
        /// </summary>
        public string YearHalfClosed
        {
            get;
            set;
        }

        /// <summary>
        /// 複合商業施設フラグ
        /// </summary>
        public string ShoppingCenterFlg
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：表示名称．漢字名称
        /// </summary>
        public string SSignTxtViewDispNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：表示名称．カナ名称
        /// </summary>
        public string SSignTxtViewDispNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：文字種別コード
        /// </summary>
        public string SSignTxtViewTxtTypCode
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：納品日付
        /// </summary>
        public string SSignTxtViewDeliveryDateStr
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：銀行機能フラグ：JA金融窓口フラグ
        /// </summary>
        public string SSignTxtViewBankInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：共通フラグ：跡地確認フラグ
        /// </summary>
        public string SSignTxtViewCommonInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：共通フラグ：基準外カナフラグ
        /// </summary>
        public string SSignTxtViewCommonInfo1
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：共通フラグ：POI配信対象フラグ
        /// </summary>
        public string SSignTxtViewCommonInfo2
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：共通フラグ：電話調査フラグ
        /// </summary>
        public string SSignTxtViewCommonInfo3
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：連絡先施設名称
        /// </summary>
        public string SSignTxtViewContactName
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：連絡先施設電話番号
        /// </summary>
        public string SSignTxtViewContactTel
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：郵便局集配フラグ
        /// </summary>
        public string SSignTxtViewPostOfficeInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：単独校舎フラグ
        /// </summary>
        public string SSignTxtViewSchoolInfo0
        {
            get;
            set;
        }

        /// <summary>
        /// 描画記号文字：トヨタサプライヤー種別コード
        /// </summary>
        public string SSignTxtViewToyotaSupplierCode
        {
            get;
            set;
        }

        /// <summary>
        /// 調査メモ
        /// </summary>
        public string InquestMemo
        {
            get;
            set;
        }
    }
}

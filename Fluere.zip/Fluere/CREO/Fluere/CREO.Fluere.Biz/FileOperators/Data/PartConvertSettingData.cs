﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 部分変換設定ファイル
    /// </summary>
    public class PartConvertSettingData
    {
        /// <summary>
        /// 親ジャンルコード
        /// </summary>
        public ushort? P_GenreCode { get; set; }

        /// <summary>
        /// ジャンル/文字種別コード範囲（前）
        /// </summary>
        public ushort? C_CodeRangeFront { get; set; }

        /// <summary>
        /// ジャンル/文字種別コード範囲（後）
        /// </summary>
        public ushort? C_CodeRangeAfter { get; set; }

        /// <summary>
        /// 部分一致箇所
        /// 語頭、語尾の二つの値を設定する
        /// </summary>
        public string JapanPartMatch { get; set; }

        /// <summary>
        /// 漢字名称
        /// 変換対象文字の部分一致箇所と一致する漢字名称
        /// </summary>
        public string KanjiName { get; set; }

        /// <summary>
        /// カナ名称
        /// 変換対象文字の部分一致箇所と一致するカナ名称
        /// </summary>
        public string KanaName { get; set; }

        /// <summary>
        /// 英字付与箇所
        /// 語頭、語尾の二つの値を設定する、部分一致箇所と逆になる可能
        /// </summary>
        public string EnPartMatch { get; set; }

        /// <summary>
        /// 部分変換英字
        /// No.1～No5の条件を全て満たす場合、英字付与箇所によって、変換すべき英字を表す
        /// </summary>
        public string EnConvertPart { get; set; }

        /// <summary>
        /// スペース付与有無
        /// 部分変換英字の前後にスペースの付与有無を表す。語頭に付与する場合、英字の後ろにスペースを付与、語尾の場合、英字の前にスペースを付与する
        /// </summary>
        public string IsSpace { get; set; }

        /// <summary>
        /// 全文字一致の変換実施有無
        /// 有の場合、全文字が一致の場合にも英字変換を実施、無の場合、英字の変換を実施しない
        /// </summary>
        public string IsAllMatchConvert { get; set; }

        /// <summary>
        /// 完全一致英字
        /// </summary>
        public string AllMatchEn { get; set; }

        /// <summary>
        /// カナ特殊処理
        /// </summary>
        public string KanaSpecial { get; set; }
    }
}

﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// FluereToDoListPattern03.xmlに対するToDoリストファイルデータ
    /// </summary>
    public class FluereToDoListPattern03Data
    {
        /// <summary>
        /// 調査対象ID
        /// </summary>
        public string InquestObjectID { get; set; }

        /// <summary>
        /// 経度
        /// </summary>
        public string Longitude { get; set; }

        /// <summary>
        /// 緯度
        /// </summary>
        public string Latitude { get; set; }

        /// <summary>
        /// 検索対象DB
        /// </summary>
        public string QueryObjectDB { get; set; }

        /// <summary>
        /// OID
        /// </summary>
        public string OID { get; set; }

        /// <summary>
        /// 確認
        /// </summary>
        public string WorkStatus { get; set; }

        /// <summary>
        /// 都道府県名
        /// </summary>
        public string Column1 { get; set; }

        /// <summary>
        /// 市区町村名
        /// </summary>
        public string Column2 { get; set; }

        /// <summary>
        /// 大字・通称名
        /// </summary>
        public string Column3 { get; set; }

        /// <summary>
        /// 字・丁目名
        /// </summary>
        public string Column4 { get; set; }

        /// <summary>
        /// 方書
        /// </summary>
        public string Column5 { get; set; }

        /// <summary>
        /// 正式名称
        /// </summary>
        public string Column6 { get; set; }
    }
}

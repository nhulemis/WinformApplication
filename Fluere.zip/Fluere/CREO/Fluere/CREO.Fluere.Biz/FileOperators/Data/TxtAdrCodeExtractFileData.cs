﻿using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// ファイル内の全行を格納するクラス
    /// </summary>
    public class TxtAdrCodeExtractFileDataContainer
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public TxtAdrCodeExtractFileDataContainer()
        {
            Header = null;
            Datas = new List<TxtAdrCodeExtractFileData>();
        }

        /// <summary>
        /// ヘッダー行列
        /// </summary>
        public List<string> Header
        {
            get;
            set;
        }

        /// <summary>
        /// データ部分列
        /// </summary>
        public List<TxtAdrCodeExtractFileData> Datas
        {
            get;
            set;
        }
    }

    /// <summary>
    /// ファイル内の1行を格納するクラス
    /// </summary>
    public class TxtAdrCodeExtractFileData
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="rowID">行数</param>
        public TxtAdrCodeExtractFileData(int rowID)
        {
            LineCount = rowID;

            MeshCode = null;
            Longitude = null;
            Latitude = null;

            ErrorFlg = false;
        }

        /// <summary>
        /// 行数
        /// </summary>
        public int LineCount
        {
            get;
            private set;
        }

        /// <summary>
        /// データ部分行
        /// </summary>
        public List<string> Columns
        {
            get;
            set;
        }

        /// <summary>
        /// ２次メッシュ
        /// </summary>
        public string MeshCode
        {
            get;
            set;
        }

        /// <summary>
        /// 座標ｘ(経度)
        /// </summary>
        public long? Longitude
        {
            get;
            set;
        }

        /// <summary>
        /// 座標y(緯度)
        /// </summary>
        public long? Latitude
        {
            get;
            set;
        }

        /// <summary>
        /// エラーフラグ
        /// </summary>
        public bool ErrorFlg
        {
            get;
            set;
        }
    }
}
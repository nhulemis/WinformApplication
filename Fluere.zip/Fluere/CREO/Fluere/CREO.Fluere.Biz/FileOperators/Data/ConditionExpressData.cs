﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 個別条件データ
    /// </summary>
    public class ConditionExpressData
    {
        /// <summary>
        /// 条件のグループ番号
        /// </summary>
        public string GroupId { get; set; }

        /// <summary>
        /// AND/OR設定
        /// </summary>
        public string AndOr { get; set; }

        /// <summary>
        /// データ識別番号
        /// </summary>
        public string Column { get; set; }

        /// <summary>
        /// 判定基準
        /// </summary>
        public string Expression { get; set; }

        /// <summary>
        /// 抽出条件
        /// </summary>
        public string Value { get; set; }
    }
}

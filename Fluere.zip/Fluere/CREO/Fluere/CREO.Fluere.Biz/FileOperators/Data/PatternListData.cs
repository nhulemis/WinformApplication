﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 組合せリストファイルデータ
    /// </summary>
    public class PatternListData
    {
        /// <summary>
        /// ステータス初期化
        /// </summary>
        private List<string> statusNo = new List<string>();

        /// <summary>
        /// ステータスリスト
        /// </summary>
        public List<string>StatusNoList
        {
            get { return statusNo; }
        }
    }
}

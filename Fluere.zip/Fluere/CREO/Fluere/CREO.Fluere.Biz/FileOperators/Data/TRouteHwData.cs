﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 高速路線、高速施設のOIDリストファイル
    /// </summary>
    public class TRouteHwData
    {
        /// <summary>
        /// 高速路線OID
        /// </summary>
        public string TRouteHwOID
        {
            get;
            set;
        }

        /// <summary>
        /// 高速施設OIDが出力対象か
        /// </summary>
        public string IsOutputTRouteHw
        {
            get;
            set;
        }

        /// <summary>
        /// 高速路線が重複かどうか
        /// </summary>
        public bool IsDuplicateOfTRouteHw
        {
            get;
            set;
        }

        /// <summary>
        /// 高速施設OID
        /// </summary>
        public string TFacilityHwOID
        {
            get;
            set;
        }

        /// <summary>
        /// 高速施設OIDが出力対象か
        /// </summary>
        public string IsOutputTFacilityHw
        {
            get;
            set;
        }
        
        /// <summary>
        /// 高速施設が重複かどうか
        /// </summary>
        public bool IsDuplicateOfTFacilityHw
        {
            get;
            set;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// インディクスファイル
    /// </summary>
    public class IndexFileData
    {
        #region フィールド定義
        /// <summary>
        /// 市外局番
        /// </summary>
        private string areaNo;

        /// <summary>
        /// 市内局番 
        /// </summary>
        private string localNo;

        /// <summary>
        /// 住所コード1
        /// </summary>
        private string adrCode1;

        /// <summary>
        /// 住所コード2
        /// </summary>
        private string adrCode2;

        /// <summary>
        /// 住所コード3
        /// </summary>
        private string adrCode3;

        /// <summary>
        /// 住所コード4
        /// </summary>
        private string adrCode4;

        /// <summary>
        /// 住所コード5
        /// </summary>
        private string adrCode5;

        /// <summary>
        /// 住所コード6
        /// </summary>
        private string adrCode6;

        /// <summary>
        /// 住所コード7
        /// </summary>
        private string adrCode7;

        /// <summary>
        /// 住所コード8
        /// </summary>
        private string adrCode8;

        /// <summary>
        /// 住所コード9
        /// </summary>
        private string adrCode9;

        /// <summary>
        /// 住所コード10
        /// </summary>
        private string adrCode10;

        /// <summary>
        /// 住所コード11
        /// </summary>
        private string adrCode11;

        /// <summary>
        /// 住所コード12
        /// </summary>
        private string adrCode12;

        /// <summary>
        /// 住所コード13
        /// </summary>
        private string adrCode13;

        /// <summary>
        /// 住所コード14
        /// </summary>
        private string adrCode14;

        /// <summary>
        /// 住所コード15
        /// </summary>
        private string adrCode15;

        /// <summary>
        /// 住所コード16
        /// </summary>
        private string adrCode16;

        /// <summary>
        /// 住所コード17
        /// </summary>
        private string adrCode17;

        /// <summary>
        /// 住所コード18
        /// </summary>
        private string adrCode18;

        /// <summary>
        /// 住所コード19
        /// </summary>
        private string adrCode19;

        /// <summary>
        /// 住所コード20
        /// </summary>
        private string adrCode20;

        /// <summary>
        /// 住所コード21
        /// </summary>
        private string adrCode21;

        /// <summary>
        /// 住所コード22
        /// </summary>
        private string adrCode22;

        /// <summary>
        /// 住所コード23
        /// </summary>
        private string adrCode23;

        /// <summary>
        /// 住所コード24
        /// </summary>
        private string adrCode24;

        /// <summary>
        /// 住所コード25
        /// </summary>
        private string adrCode25;

        /// <summary>
        /// 住所コード26
        /// </summary>
        private string adrCode26;

        /// <summary>
        /// 住所コード27
        /// </summary>
        private string adrCode27;

        /// <summary>
        /// 住所コード28
        /// </summary>
        private string adrCode28;

        /// <summary>
        /// 住所コード29
        /// </summary>
        private string adrCode29;

        /// <summary>
        /// 住所コード30
        /// </summary>
        private string adrCode30;

        /// <summary>
        /// 廃止フラグ
        /// </summary>
        private string disAdrFlag;

        /// <summary>
        /// 予備
        /// </summary>
        private string prep;
        #endregion

        #region getter and setter
        /// <summary>
        /// 市外局番
        /// </summary>
        public string AreaNo
        {
            get { return areaNo; }
            set { areaNo = value; }
        }

        /// <summary>
        /// 市内局番 
        /// </summary>
        public string LocalNo
        {
            get { return localNo; }
            set { localNo = value; }
        }

        /// <summary>
        /// 住所コード1
        /// </summary>
        public string AdrCode1
        {
            get { return adrCode1; }
            set { adrCode1 = value; }
        }

        /// <summary>
        /// 住所コード2
        /// </summary>
        public string AdrCode2
        {
            get { return adrCode2; }
            set { adrCode2 = value; }
        }

        /// <summary>
        /// 住所コード3
        /// </summary>
        public string AdrCode3
        {
            get { return adrCode3; }
            set { adrCode3 = value; }
        }

        /// <summary>
        /// 住所コード4
        /// </summary>
        public string AdrCode4
        {
            get { return adrCode4; }
            set { adrCode4 = value; }
        }

        /// <summary>
        /// 住所コード5
        /// </summary>
        public string AdrCode5
        {
            get { return adrCode5; }
            set { adrCode5 = value; }
        }

        /// <summary>
        /// 住所コード6
        /// </summary>
        public string AdrCode6
        {
            get { return adrCode6; }
            set { adrCode6 = value; }
        }

        /// <summary>
        /// 住所コード7
        /// </summary>
        public string AdrCode7
        {
            get { return adrCode7; }
            set { adrCode7 = value; }
        }

        /// <summary>
        /// 住所コード8
        /// </summary>
        public string AdrCode8
        {
            get { return adrCode8; }
            set { adrCode8 = value; }
        }

        /// <summary>
        /// 住所コード9
        /// </summary>
        public string AdrCode9
        {
            get { return adrCode9; }
            set { adrCode9 = value; }
        }

        /// <summary>
        /// 住所コード10
        /// </summary>
        public string AdrCode10
        {
            get { return adrCode10; }
            set { adrCode10 = value; }
        }

        /// <summary>
        /// 住所コード11
        /// </summary>
        public string AdrCode11
        {
            get { return adrCode11; }
            set { adrCode11 = value; }
        }

        /// <summary>
        /// 住所コード12
        /// </summary>
        public string AdrCode12
        {
            get { return adrCode12; }
            set { adrCode12 = value; }
        }

        /// <summary>
        /// 住所コード13
        /// </summary>
        public string AdrCode13
        {
            get { return adrCode13; }
            set { adrCode13 = value; }
        }

        /// <summary>
        /// 住所コード14
        /// </summary>
        public string AdrCode14
        {
            get { return adrCode14; }
            set { adrCode14 = value; }
        }

        /// <summary>
        /// 住所コード15
        /// </summary>
        public string AdrCode15
        {
            get { return adrCode15; }
            set { adrCode15 = value; }
        }

        /// <summary>
        /// 住所コード16
        /// </summary>
        public string AdrCode16
        {
            get { return adrCode16; }
            set { adrCode16 = value; }
        }

        /// <summary>
        /// 住所コード17
        /// </summary>
        public string AdrCode17
        {
            get { return adrCode17; }
            set { adrCode17 = value; }
        }

        /// <summary>
        /// 住所コード18
        /// </summary>
        public string AdrCode18
        {
            get { return adrCode18; }
            set { adrCode18 = value; }
        }

        /// <summary>
        /// 住所コード19
        /// </summary>
        public string AdrCode19
        {
            get { return adrCode19; }
            set { adrCode19 = value; }
        }

        /// <summary>
        /// 住所コード20
        /// </summary>
        public string AdrCode20
        {
            get { return adrCode20; }
            set { adrCode20 = value; }
        }

        /// <summary>
        /// 住所コード21
        /// </summary>
        public string AdrCode21
        {
            get { return adrCode21; }
            set { adrCode21 = value; }
        }

        /// <summary>
        /// 住所コード22
        /// </summary>
        public string AdrCode22
        {
            get { return adrCode22; }
            set { adrCode22 = value; }
        }

        /// <summary>
        /// 住所コード23
        /// </summary>
        public string AdrCode23
        {
            get { return adrCode23; }
            set { adrCode23 = value; }
        }

        /// <summary>
        /// 住所コード24
        /// </summary>
        public string AdrCode24
        {
            get { return adrCode24; }
            set { adrCode24 = value; }
        }

        /// <summary>
        /// 住所コード25
        /// </summary>
        public string AdrCode25
        {
            get { return adrCode25; }
            set { adrCode25 = value; }
        }

        /// <summary>
        /// 住所コード26
        /// </summary>
        public string AdrCode26
        {
            get { return adrCode26; }
            set { adrCode26 = value; }
        }

        /// <summary>
        /// 住所コード27
        /// </summary>
        public string AdrCode27
        {
            get { return adrCode27; }
            set { adrCode27 = value; }
        }

        /// <summary>
        /// 住所コード28
        /// </summary>
        public string AdrCode28
        {
            get { return adrCode28; }
            set { adrCode28 = value; }
        }

        /// <summary>
        /// 住所コード29
        /// </summary>
        public string AdrCode29
        {
            get { return adrCode29; }
            set { adrCode29 = value; }
        }

        /// <summary>
        /// 住所コード30
        /// </summary>
        public string AdrCode30
        {
            get { return adrCode30; }
            set { adrCode30 = value; }
        }

        /// <summary>
        /// 廃止フラグ
        /// </summary>
        public string DisAdrFlag
        {
            get { return disAdrFlag; }
            set { disAdrFlag = value; }
        }

        /// <summary>
        /// 予備
        /// </summary>
        public string Prep
        {
            get { return prep; }
            set { prep = value; }
        }

        /// <summary>
        /// 住所コードリスト
        /// </summary>
        public List<string> AdrCodeList
        {
            get;
            set;
        }
        #endregion
    }
}

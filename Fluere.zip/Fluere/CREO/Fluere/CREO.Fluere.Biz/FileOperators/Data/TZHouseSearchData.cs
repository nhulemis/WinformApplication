﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// TZ住所検索データファイルファイル
    /// </summary>
    public class TZHouseSearchData
    {
        #region フィールド定義
        /// <summary>
        /// レコード種別
        /// </summary>
        private string reCodeType;

        /// <summary>
        /// ゼンリン独自住所フラグ
        /// </summary>
        private string zenRinAloneTAdrFlag;

        /// <summary>
        /// 都道府県コード
        /// </summary>
        private string provinceCode;

        /// <summary>
        /// 市区町村コード
        /// </summary>
        private string cityCode;

        /// <summary>
        /// 大字・町コード
        /// </summary>
        private string oazaCode;

        /// <summary>
        /// 字・丁目コード
        /// </summary>
        private string sectionCode;

        /// <summary>
        /// 街区コード
        /// </summary>
        private string gaikuCode;

        /// <summary>
        /// 地番・戸番
        /// </summary>
        private string lotOrHouseNo;

        /// <summary>
        /// 建物連番
        /// </summary>
        private string buildingNo;

        /// <summary>
        /// 都道府県名称
        /// </summary>
        private string provinceName;

        /// <summary>
        /// 市区町村名称
        /// </summary>
        private string cityName;

        /// <summary>
        /// 大字・町名称
        /// </summary>
        private string oazaName;

        /// <summary>
        /// 字・丁目名称
        /// </summary>
        private string sectionName;

        /// <summary>
        /// 街区番号
        /// </summary>
        private string gaikuNo;

        /// <summary>
        /// 市区町村名称カナ
        /// </summary>
        private string cityNameKana;

        /// <summary>
        /// 大字・町名称カナ
        /// </summary>
        private string oazaNameKana;

        /// <summary>
        /// 字・丁目名称カナ
        /// </summary>
        private string sectionNameKana;

        /// <summary>
        /// 住所座標　経度
        /// </summary>
        private string adrTpoiLongitude;

        /// <summary>
        /// 住所座標　緯度
        /// </summary>
        private string adrTpoiLatitude;

        /// <summary>
        /// 建物到着地点座標　経度
        /// </summary>
        private string buildingLongitude;

        /// <summary>
        /// 建物到着地点座標　緯度
        /// </summary>
        private string buildingLatitude;
        #endregion

        #region getter and setter
        /// <summary>
        /// レコード種別
        /// </summary>
        public string ReCodeType
        {
            get { return reCodeType; }
            set { reCodeType = value; }
        }

        /// <summary>
        /// ゼンリン独自住所フラグ
        /// </summary>
        public string ZenRinAloneTAdrFlag
        {
            get { return zenRinAloneTAdrFlag; }
            set { zenRinAloneTAdrFlag = value; }
        }

        /// <summary>
        /// 都道府県コード
        /// </summary>
        public string ProvinceCode
        {
            get { return provinceCode; }
            set { provinceCode = value; }
        }

        /// <summary>
        /// 市区町村コード
        /// </summary>
        public string CityCode
        {
            get { return cityCode; }
            set { cityCode = value; }
        }

        /// <summary>
        /// 大字・町コード
        /// </summary>
        public string OazaCode
        {
            get { return oazaCode; }
            set { oazaCode = value; }
        }

        /// <summary>
        /// 字・丁目コード
        /// </summary>
        public string SectionCode
        {
            get { return sectionCode; }
            set { sectionCode = value; }
        }

        /// <summary>
        /// 街区コード
        /// </summary>
        public string GaikuCode
        {
            get { return gaikuCode; }
            set { gaikuCode = value; }
        }

        /// <summary>
        /// 地番・戸番
        /// </summary>
        public string LotOrHouseNo
        {
            get { return lotOrHouseNo; }
            set { lotOrHouseNo = value; }
        }

        /// <summary>
        /// 建物連番
        /// </summary>
        public string BuildingNo
        {
            get { return buildingNo; }
            set { buildingNo = value; }
        }

        /// <summary>
        /// 都道府県名称
        /// </summary>
        public string ProvinceName
        {
            get { return provinceName; }
            set { provinceName = value; }
        }

        /// <summary>
        /// 市区町村名称
        /// </summary>
        public string CityName
        {
            get { return cityName; }
            set { cityName = value; }
        }

        /// <summary>
        /// 大字・町名称
        /// </summary>
        public string OazaName
        {
            get { return oazaName; }
            set { oazaName = value; }
        }

        /// <summary>
        /// 字・丁目名称
        /// </summary>
        public string SectionName
        {
            get { return sectionName; }
            set { sectionName = value; }
        }

        /// <summary>
        /// 街区番号
        /// </summary>
        public string GaikuNo
        {
            get { return gaikuNo; }
            set { gaikuNo = value; }
        }

        /// <summary>
        /// 市区町村名称カナ
        /// </summary>
        public string CityNameKana
        {
            get { return cityNameKana; }
            set { cityNameKana = value; }
        }

        /// <summary>
        /// 大字・町名称カナ
        /// </summary>
        public string OazaNameKana
        {
            get { return oazaNameKana; }
            set { oazaNameKana = value; }
        }

        /// <summary>
        /// 字・丁目名称カナ
        /// </summary>
        public string SectionNameKana
        {
            get { return sectionNameKana; }
            set { sectionNameKana = value; }
        }

        /// <summary>
        /// 住所座標　経度
        /// </summary>
        public string AdrTpoiLongitude
        {
            get { return adrTpoiLongitude; }
            set { adrTpoiLongitude = value; }
        }

        /// <summary>
        /// 住所座標　緯度
        /// </summary>
        public string AdrTpoiLatitude
        {
            get { return adrTpoiLatitude; }
            set { adrTpoiLatitude = value; }
        }

        /// <summary>
        /// 建物到着地点座標　経度
        /// </summary>
        public string BuildingLongitude
        {
            get { return buildingLongitude; }
            set { buildingLongitude = value; }
        }

        /// <summary>
        /// 建物到着地点座標　緯度
        /// </summary>
        public string BuildingLatitude
        {
            get { return buildingLatitude; }
            set { buildingLatitude = value; }
        }
        #endregion
    }
}

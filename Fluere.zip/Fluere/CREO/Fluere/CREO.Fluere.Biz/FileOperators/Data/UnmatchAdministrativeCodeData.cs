﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// アンマッチ追跡市区町村リストファイルデータ
    /// </summary>
    public class UnmatchAdministrativeCodeData
    {
        /// <summary>
        /// 市区町村コード
        /// </summary>
        public string AdministrativeCode { get; set; }

        /// <summary>
        /// 備考
        /// </summary>
        public string Comment { get; set; }
    }
}

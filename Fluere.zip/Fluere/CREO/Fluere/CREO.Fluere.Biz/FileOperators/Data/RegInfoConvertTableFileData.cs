﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 規制情報変換テーブルファイル.
    /// </summary>
    public class RegInfoConvertTableData
    {
        // 変更前

        /// <summary>
        /// 変更前データが有効か
        /// </summary>
        public bool IsEffective { get; set; }

        /// <summary>
        /// 変更前ID
        /// </summary>
        public string ID { get; set; }

        /// <summary>
        /// 規制曜日（月曜）
        /// </summary>
        public string DayOfWeek2 { get; set; }

        /// <summary>
        /// 規制曜日（火曜）
        /// </summary>
        public string DayOfWeek3 { get; set; }

        /// <summary>
        /// 規制曜日（水曜）
        /// </summary>
        public string DayOfWeek4 { get; set; }

        /// <summary>
        /// 規制曜日（木曜）
        /// </summary>
        public string DayOfWeek5 { get; set; }

        /// <summary>
        /// 規制曜日（金曜）
        /// </summary>
        public string DayOfWeek6 { get; set; }

        /// <summary>
        /// 規制曜日（土曜）
        /// </summary>
        public string DayOfWeek7 { get; set; }

        /// <summary>
        /// 規制曜日（日曜）
        /// </summary>
        public string DayOfWeek1 { get; set; }

        /// <summary>
        /// 規制曜日（祝）
        /// </summary>
        public string DayOfWeek0 { get; set; }

        /// <summary>
        /// 規制曜日（祝前日）
        /// </summary>
        public string DayOfWeek8 { get; set; }

        /// <summary>
        /// 規制曜日：除く
        /// </summary>
        public string OmitDayOfWeek { get; set; }

        /// <summary>
        /// 規制時刻：開始時
        /// </summary>
        public string StartHour { get; set; }

        /// <summary>
        /// 規制時刻：開始分
        /// </summary>
        public string StartMinute { get; set; }

        /// <summary>
        /// 規制時刻：終了時
        /// </summary>
        public string EndHour { get; set; }

        /// <summary>
        /// 規制時刻：終了分
        /// </summary>
        public string EndMinute { get; set; }

        /// <summary>
        /// 規制時刻：除く
        /// </summary>
        public string OmitRegTime { get; set; }

        /// <summary>
        /// 規制月日：開始月
        /// </summary>
        public string StartMonth { get; set; }

        /// <summary>
        /// 規制月日：開始日
        /// </summary>
        public string StartDay { get; set; }

        /// <summary>
        /// 規制月日：終了月
        /// </summary>
        public string EndMonth { get; set; }

        /// <summary>
        /// 規制月日：終了日
        /// </summary>
        public string EndDay { get; set; }

        /// <summary>
        /// 規制月日：除く
        /// </summary>
        public string OmitRegDays { get; set; }

        /// <summary>
        /// 規制週間（1週）
        /// </summary>
        public string WeekCondition0 { get; set; }

        /// <summary>
        /// 規制週間（2週）
        /// </summary>
        public string WeekCondition1 { get; set; }

        /// <summary>
        /// 規制週間（3週）
        /// </summary>
        public string WeekCondition2 { get; set; }

        /// <summary>
        /// 規制週間（4週）
        /// </summary>
        public string WeekCondition3 { get; set; }

        /// <summary>
        /// 規制週間（5週）
        /// </summary>
        public string WeekCondition4 { get; set; }

        /// <summary>
        /// 規制週間（6週）
        /// </summary>
        public string WeekCondition5 { get; set; }

        /// <summary>
        /// 規制状態コード
        /// </summary>
        public string RegStateCode { get; set; }

        /// <summary>
        /// 日またぎ有無
        /// </summary>
        public string Flag { get; set; }

        // 変更後

        /// <summary>
        /// 更新後データが有効ですか
        /// </summary>
        public bool IsUpdateEffective { get; set; }

        /// <summary>
        /// 変更後ID
        /// </summary>
        public string UpdateID { get; set; }

        /// <summary>
        /// 規制曜日（月曜）
        /// </summary>
        public string UpdateDayOfWeek2 { get; set; }

        /// <summary>
        /// 規制曜日（火曜）
        /// </summary>
        public string UpdateDayOfWeek3 { get; set; }

        /// <summary>
        /// 規制曜日（水曜）
        /// </summary>
        public string UpdateDayOfWeek4 { get; set; }

        /// <summary>
        /// 規制曜日（木曜）
        /// </summary>
        public string UpdateDayOfWeek5 { get; set; }

        /// <summary>
        /// 規制曜日（金曜）
        /// </summary>
        public string UpdateDayOfWeek6 { get; set; }

        /// <summary>
        /// 規制曜日（土曜）
        /// </summary>
        public string UpdateDayOfWeek7 { get; set; }

        /// <summary>
        /// 規制曜日（日曜）
        /// </summary>
        public string UpdateDayOfWeek1 { get; set; }

        /// <summary>
        /// 規制曜日（祝）
        /// </summary>
        public string UpdateDayOfWeek0 { get; set; }

        /// <summary>
        /// 規制曜日（祝前日）
        /// </summary>
        public string UpdateDayOfWeek8 { get; set; }

        /// <summary>
        /// 規制時刻：開始時
        /// </summary>
        public string UpdateStartHour { get; set; }

        /// <summary>
        /// 規制時刻：開始分
        /// </summary>
        public string UpdateStartMinute { get; set; }

        /// <summary>
        /// 規制時刻：終了時
        /// </summary>
        public string UpdateEndHour { get; set; }

        /// <summary>
        /// 規制時刻：終了分
        /// </summary>
        public string UpdateEndMinute { get; set; }

        /// <summary>
        /// 規制月日：開始月
        /// </summary>
        public string UpdateStartMonth { get; set; }

        /// <summary>
        /// 規制月日：開始日
        /// </summary>
        public string UpdateStartDay { get; set; }

        /// <summary>
        /// 規制月日：終了月
        /// </summary>
        public string UpdateEndMonth { get; set; }

        /// <summary>
        /// 規制月日：終了日
        /// </summary>
        public string UpdateEndDay { get; set; }

        /// <summary>
        /// 規制週間（1週）
        /// </summary>
        public string UpdateWeekCondition0 { get; set; }

        /// <summary>
        /// 規制週間（2週）
        /// </summary>
        public string UpdateWeekCondition1 { get; set; }

        /// <summary>
        /// 規制週間（3週）
        /// </summary>
        public string UpdateWeekCondition2 { get; set; }

        /// <summary>
        /// 規制週間（4週）
        /// </summary>
        public string UpdateWeekCondition3 { get; set; }

        /// <summary>
        /// 規制週間（5週）
        /// </summary>
        public string UpdateWeekCondition4 { get; set; }

        /// <summary>
        /// 規制週間（6週）
        /// </summary>
        public string UpdateWeekCondition5 { get; set; }

        /// <summary>
        /// 規制状態コード
        /// </summary>
        public string UpdateRegStateCode { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// ToDoリスト作成用の情報インプットデータファイル
    /// </summary>
    public class MakeToDoInfoData
    {
        /// <summary>
        /// 施設物件拡張のOID
        /// </summary>
        public string OID
        {
            get;
            set;
        }

        /// <summary>
        /// グループID
        /// </summary>
        public string GroupID
        {
            get;
            set;
        }

        /// <summary>
        /// 物件住所（漢字）
        /// </summary>
        public string AdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string Telno
        {
            get;
            set;
        }

        /// <summary>
        /// 正式漢字名称
        /// </summary>
        public string FormalNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 正式カナ名称
        /// </summary>
        public string FormalNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 表示漢字名称
        /// </summary>
        public string DispNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 分類コード
        /// </summary>
        public string TypeCode
        {
            get;
            set;
        }

        /// <summary>
        /// 絶対座標：東経
        /// </summary>
        public string Longitude
        {
            get;
            set;
        }

        /// <summary>
        /// 絶対座標：北緯
        /// </summary>
        public string Latitude
        {
            get;
            set;
        }
    }
}

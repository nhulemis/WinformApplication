﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 分類コードと施設物件ジャンルコードの対応ファイル
    /// </summary>
    public class TGnrPOICodeData
    {
        /// <summary>
        /// 分類コード
        /// </summary>
        public string POICode
        {
            get;
            set;
        }

        /// <summary>
        /// 親施設物件ジャンルコード
        /// </summary>
        public string TParentGnrCode
        {
            get;
            set;
        }

        /// <summary>
        /// 施設物件ジャンルコード
        /// </summary>
        public string TGnrCode
        {
            get;
            set;
        }
    }
}

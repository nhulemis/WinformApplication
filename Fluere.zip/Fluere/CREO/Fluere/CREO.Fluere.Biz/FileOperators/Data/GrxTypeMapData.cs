﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// GrxTypeMapDataクラス
    /// </summary>
    public class GrxTypeMapData
    {
        /// <summary>
        /// 入力年月日
        /// </summary>
        private string _typeMapInputDate;

        /// <summary>
        /// ユーザー名
        /// </summary>
        private string _typeMapUserName;

        /// <summary>
        /// 東経（1/2048秒単位）
        /// </summary>
        private ulong _longitudeCoordinates;

        /// <summary>
        /// 北緯（1/2048秒単位）
        /// </summary>
        private ulong _northLatitude;

        /// <summary>
        /// ノーマライズ座標：X
        /// </summary>
        private double _normalMatrixX;

        /// <summary>
        /// ノーマライズ座標：Y
        /// </summary>
        private double _normalMatrixY;

        /// <summary>
        /// セル
        /// </summary>
        private GrxCellData _ownerCell;

        /// <summary>
        /// 入力年月日
        /// </summary>
        public string TypeMapInputDate
        {
            get { return _typeMapInputDate; }
            set { _typeMapInputDate = value; }
        }

        /// <summary>
        /// ユーザー名
        /// </summary>
        public string TypeMapUserName
        {
            get { return _typeMapUserName; }
            set { _typeMapUserName = value; }
        }

        /// <summary>
        /// 東経（1/2048秒単位）
        /// </summary>
        public ulong LongitudeCoordinates
        {
            get { return _longitudeCoordinates; }
            set { _longitudeCoordinates = value; }
        }

        /// <summary>
        ///  北緯（1/2048秒単位）
        /// </summary>
        public ulong NorthLatitude
        {
            get { return _northLatitude; }
            set { _northLatitude = value; }
        }

        /// <summary>
        /// ノーマライズ座標：X
        /// </summary>
        public double NormalMatrixX
        {
            get { return _normalMatrixX; }
            set { _normalMatrixX = value; }
        }

        /// <summary>
        /// ノーマライズ座標：Y
        /// </summary>
        public double NormalMatrixY
        {
            get { return _normalMatrixY; }
            set { _normalMatrixY = value; }
        }

        /// <summary>
        /// セル
        /// </summary>
        public GrxCellData OwnerCell
        {
            get { return _ownerCell; }
            set { _ownerCell = value; }
        }      
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// タウンファイル
    /// ※【適用バッチ】行政変更：町字（行政変更）処理
    /// </summary>
    public class TMITownpageData : NewDisTwnDiffFileData, System.IComparable<TMITownpageData>
    {
        /// <summary>
        /// 継承前マッチングレベル：kml：：4
        /// </summary>
        private int? _kml;

        /// <summary>
        /// 継承元DB 情報：kdb：：4
        /// </summary>
        private int? _kdb;

        /// <summary>
        /// 変更フラグ：flg：：1bit×16
        /// </summary>
        private short? _flg;

        /// <summary>
        /// 未定義エリア：rsv4：文字列：1
        /// </summary>
        private string _rsv4 = string.Empty;

        /// <summary>
        /// 継承前マッチングレベル：kml：：4
        /// </summary>
        public int? Kml
        {
            get { return _kml; }
            set { _kml = value; }
        }

        /// <summary>
        /// 継承元DB 情報：kdb：：4
        /// </summary>
        public int? Kdb
        {
            get { return _kdb; }
            set { _kdb = value; }
        }

        /// <summary>
        /// 変更フラグ：flg：：1bit×16
        /// </summary>
        public short? Flg
        {
            get { return _flg; }
            set { _flg = value; }
        }

        /// <summary>
        /// 未定義エリア：rsv4：文字列：1
        /// </summary>
        public string Rsv4
        {
            get { return _rsv4; }
            set { _rsv4 = value; }
        }

        /// <summary>
        /// 比較ロジック
        /// </summary>
        /// <param name="other">比較なオブジェクト</param>
        /// <returns>比較結果</returns>
        public int CompareTo(TMITownpageData other)
        {
            int result = 0;

            if (this.A0.Equals(other.A0) &&
                this.A1.Equals(other.A1) &&
                this.A2.Equals(other.A2) &&
                this.A3.Equals(other.A3))
            {
                result = 1;
            }
            else
            {
                result = -1;
            }

            return result;
        }
    }
}

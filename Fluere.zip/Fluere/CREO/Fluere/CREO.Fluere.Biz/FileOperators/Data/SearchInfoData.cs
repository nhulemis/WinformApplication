﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 調査原稿テキストファイル
    /// </summary>
    public class SearchInfoData
    {
        #region 交差点目印
        /// <summary>
        /// 2次メッシュコード
        /// </summary>
        public string MeshCode { get; set; }

        /// <summary>
        /// 交差点データ番号
        /// </summary>
        public string CrsDataNumber { get; set; }

        /// <summary>
        /// 目印連番
        /// </summary>
        public string Crs_MarkSpate { get; set; }

        /// <summary>
        /// 目印コード
        /// </summary>
        public string Crs_MarkCode { get; set; }

        /// <summary>
        /// カナ名称
        /// </summary>
        public string Crs_KANAName { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string Crs_KanJiNames { get; set; }

        /// <summary>
        /// 経度
        /// </summary>
        public string Crs_Longitude { get; set; }

        /// <summary>
        /// 緯度
        /// </summary>
        public string Crs_Latitude { get; set; }

        /// <summary>
        /// 交差点目印のOID
        /// </summary>
        public string CrsMarkOID { get; set; }

        /// <summary>
        /// メンテナンス日
        /// </summary>
        public string MaintenanceDay { get; set; }

        /// <summary>
        /// プロット番号
        /// </summary>
        public string PlotNo { get; set; }

        #endregion

        #region タウン物件の情報
        /// <summary>
        /// OID
        /// </summary>
        public string STwn_STwnPOIOID { get; set; }

        /// <summary>
        /// 市外局番
        /// </summary>
        public string STwn_AreaNo { get; set; }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string STwn_TelNumber { get; set; }

        /// <summary>
        /// カナ名称
        /// </summary>
        public string STwn_KANAName_1 { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string STwn_KanJiNames_1 { get; set; }

        /// <summary>
        /// 基本分類コード
        /// </summary>
        public string STwn_GnrTwnCode { get; set; }

        /// <summary>
        /// 基本分類名
        /// </summary>
        public string STwn_GnrTwnName { get; set; }

        /// <summary>
        /// NTT分類コード
        /// </summary>
        public string STwn_NTTCode { get; set; }

        /// <summary>
        /// NTT分類名
        /// </summary>
        public string STwn_NTTName { get; set; }

        /// <summary>
        /// 目印コード
        /// </summary>
        public string STwn_MarkCode { get; set; }

        /// <summary>
        /// カナ名称
        /// </summary>
        public string STwn_KANAName_2 { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string STwn_KanJiNames_2 { get; set; }
        #endregion

        #region 施設物件
        /// <summary>
        /// OID
        /// </summary>
        public string SPOI_SPOIFacilityOID { get; set; }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string SPOI_TelNumber { get; set; }

        /// <summary>
        /// カナ名称
        /// </summary>
        public string SPOI_KANAName { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string SPOI_KanJiNames { get; set; }
        #endregion

        #region 物件ジャンル
        /// <summary>
        /// OID
        /// </summary>
        public string Gnr_GnrTwnOID { get; set; }

        /// <summary>
        /// カナ名称
        /// </summary>
        public string Gnr_KANAName { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string Gnr_KanJiNames { get; set; }
        #endregion
    }
}

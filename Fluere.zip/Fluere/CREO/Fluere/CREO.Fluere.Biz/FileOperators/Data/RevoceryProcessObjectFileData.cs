﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// RevoceryProcessObjectFileDataクラス
    /// </summary>
    public class RevoceryProcessObjectFileData
    {
        /// <summary>
        /// 抽出コンテンツ和称
        /// </summary>
        public string OutPutDataName
        {
            get;
            set;
        }

        /// <summary>
        /// 抽出コンテンツ英名
        /// </summary>
        public string OutPutDataEnglish
        {
            get;
            set;
        }
    }
}

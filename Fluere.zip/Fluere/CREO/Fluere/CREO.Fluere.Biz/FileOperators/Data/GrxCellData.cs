﻿using System.Collections.Generic;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// GRXセルデータファイル
    /// </summary>
    public class GrxCellData
    {
        #region フィールド定義
        /// <summary>
        /// 入力年月日
        /// </summary>
        private string _cellInputDate;

        /// <summary>
        /// ユーザー名
        /// </summary>
        private string _cellUserName;

        /// <summary>
        /// 住宅図データファイルID
        /// </summary>
        private string _housingMapFileID;

        /// <summary>
        /// セル位置情報 左
        /// </summary>
        private long _geometryBaseLeft;

        /// <summary>
        /// セル位置情報 下
        /// </summary>
        private long _geometryBaseDown;

        /// <summary>
        /// セル位置情報 右
        /// </summary>
        private long _geometryBaseRight;

        /// <summary>
        /// セル位置情報 上
        /// </summary>
        private long _geometryBaseUp;

        /// <summary>
        /// ページ基準点 入力年月日
        /// </summary>
        private string _pageInputDate;

        /// <summary>
        /// ユーザー名
        /// </summary>
        private string _pageUserName;
        
        /// <summary>
        /// ビットマップの４隅の基準点左下のX
        /// </summary>
        private double _bitMapLeftDownX;

        /// <summary>
        /// ビットマップの４隅の基準点左下のY
        /// </summary>
        private double _bitMapLeftDownY;

        /// <summary>
        /// ビットマップの４隅の基準点左上のX
        /// </summary>
        private double _bitMapLeftUpX;

        /// <summary>
        ///  ビットマップの４隅の基準点左上のY
        /// </summary>
        private double _bitMapLeftUpY;

        /// <summary>
        /// ビットマップの４隅の基準点右上のX
        /// </summary>
        private double _bitMapRightUpX;

        /// <summary>
        /// ビットマップの４隅の基準点右上のY
        /// </summary>
        private double _bitMapRightUpY;

        /// <summary>
        /// ビットマップの４隅の基準点右下のX
        /// </summary>
        private double _bitMapRightDownX;

        /// <summary>
        /// ビットマップの４隅の基準点右下のY
        /// </summary>
        private double _bitMapRightDownY;

        /// <summary>
        /// 区分図基準点数
        /// </summary>
        private int _typeMapNum;

        /// <summary>
        /// GrxTypeMapDataリスト
        /// </summary>
        private List<GrxTypeMapData> _grxTypeDataList;

        /// <summary>
        /// ビットマップ幅(private変数)
        /// </summary>
        private long _bitmapWidth;

        /// <summary>
        /// ビットマップ高さ(private変数)
        /// </summary>
        private long _bitmapHeight;
        #endregion

        #region getter and setter
        /// <summary>
        /// 入力年月日
        /// </summary>
        public string CellInputDate
        {
            get { return _cellInputDate; }
            set { _cellInputDate = value; }
        }

        /// <summary>
        /// ユーザー名
        /// </summary>
        public string CellUserName
        {
            get { return _cellUserName; }
            set { _cellUserName = value; }
        }

        /// <summary>
        /// 住宅図データファイルID
        /// </summary>
        public string HousingMapFileID
        {
            get { return _housingMapFileID; }
            set { _housingMapFileID = value; }
        }

        /// <summary>
        /// セル位置情報 左
        /// </summary>
        public long GeometryBaseLeft
        {
            get { return _geometryBaseLeft; }
            set { _geometryBaseLeft = value; }
        }

        /// <summary>
        /// セル位置情報 下
        /// </summary>
        public long GeometryBaseDown
        {
            get { return _geometryBaseDown; }
            set { _geometryBaseDown = value; }
        }

        /// <summary>
        /// セル位置情報 右
        /// </summary>
        public long GeometryBaseRight
        {
            get { return _geometryBaseRight; }
            set { _geometryBaseRight = value; }
        }

        /// <summary>
        /// セル位置情報 上
        /// </summary>
        public long GeometryBaseUp
        {
            get { return _geometryBaseUp; }
            set { _geometryBaseUp = value; }
        }

        /// <summary>
        /// ページ基準点 入力年月日
        /// </summary>
        public string PageInputDate
        {
            get { return _pageInputDate; }
            set { _pageInputDate = value; }
        }

        /// <summary>
        /// ユーザー名
        /// </summary>
        public string PageUserName
        {
            get { return _pageUserName; }
            set { _pageUserName = value; }
        }

        /// <summary>
        /// ビットマップの４隅の基準点左下のX
        /// </summary>
        public double BitMapLeftDownX
        {
            get { return _bitMapLeftDownX; }
            set { _bitMapLeftDownX = value; }
        }

        /// <summary>
        ///  ビットマップの４隅の基準点左下のY
        /// </summary>
        public double BitMapLeftDownY
        {
            get { return _bitMapLeftDownY; }
            set { _bitMapLeftDownY = value; }
        }

        /// <summary>
        /// ビットマップの４隅の基準点左上のX
        /// </summary>
        public double BitMapLeftUpX
        {
            get { return _bitMapLeftUpX; }
            set { _bitMapLeftUpX = value; }
        }

        /// <summary>
        /// ビットマップの４隅の基準点左上のY
        /// </summary>
        public double BitMapLeftUpY
        {
            get { return _bitMapLeftUpY; }
            set { _bitMapLeftUpY = value; }
        }

        /// <summary>
        /// ビットマップの４隅の基準点右上のX
        /// </summary>
        public double BitMapRightUpX
        {
            get { return _bitMapRightUpX; }
            set { _bitMapRightUpX = value; }
        }

        /// <summary>
        /// ビットマップの４隅の基準点右上のY
        /// </summary>
        public double BitMapRightUpY
        {
            get { return _bitMapRightUpY; }
            set { _bitMapRightUpY = value; }
        }

        /// <summary>
        /// ビットマップの４隅の基準点右下のX
        /// </summary>
        public double BitMapRightDownX
        {
            get { return _bitMapRightDownX; }
            set { _bitMapRightDownX = value; }
        }

        /// <summary>
        /// ビットマップの４隅の基準点右下のY
        /// </summary>
        public double BitMapRightDownY
        {
            get { return _bitMapRightDownY; }
            set { _bitMapRightDownY = value; }
        }

        /// <summary>
        /// 区分図基準点数
        /// </summary>
        public int TypeMapNum
        {
            get { return _typeMapNum; }
            set { _typeMapNum = value; }
        }

        /// <summary>
        /// GRXセルデータリスト
        /// </summary>
        public List<GrxTypeMapData> GrxTypeDataList
        {
            get { return _grxTypeDataList; }
            set { _grxTypeDataList = value; }
        }

        /// <summary>
        /// ビットマップの幅
        /// </summary>
        public long BitmapWidth
        {
            get { return _bitmapWidth; }
            set { _bitmapWidth = value; }
        }

        /// <summary>
        /// ビットマップの高さ
        /// </summary>
        public long BitmapHeight
        {
            get { return _bitmapHeight; }
            set { _bitmapHeight = value; }
        }
        
        #endregion
    }
} 
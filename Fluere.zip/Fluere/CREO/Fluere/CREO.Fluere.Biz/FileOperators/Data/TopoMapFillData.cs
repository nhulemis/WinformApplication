﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// TopoMapFillDataクラス
    /// </summary>
    public class TopoMapFillData
    {
        /// <summary>
        /// 地形図名称（漢字）
        /// </summary>
        public string MapNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 改測年月日
        /// </summary>
        public string ResurveyDate
        {
            get;
            set;
        }

        /// <summary>
        /// 2万5千分の1地形図番号
        /// </summary>
        public ushort? TopoMap25kNo
        {
            get;
            set;
        }

        /// <summary>
        /// ５万分の１地形図番号
        /// </summary>
        public ushort? TopoMap50kNo
        {
            get;
            set;
        }

        /// <summary>
        /// 地勢図名称
        /// </summary>
        public string GeographicMapName
        {
            get;
            set;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 目視対象ジャンルファイル
    /// </summary>
    public class VisualCheckGenreData
    {
        /// <summary>
        /// 親ジャンルコード
        /// </summary>
        public ushort P_GenreRange { get; set; }

        /// <summary>
        /// ジャンル範囲（前）
        /// 目視対象ジャンルの範囲の前の値、高速施設と高速路線の場合、空白である。
        /// </summary>
        public ushort? C_GenreRangeFront { get; set; }

        /// <summary>
        /// ジャンル範囲（後）
        /// 目視対象ジャンルの範囲の後の値、ジャンル範囲（前）と同じの場合、ジャンルの範囲は一つしかないと表す、高速施設と高速路線の場合、空白である。
        /// </summary>
        public ushort? C_GenreRangeAfter { get; set; }

        /// <summary>
        /// 対象条件文字列（カナ）
        /// 対象のカナ文字が対象検索条件を満たす場合のみ目視対象とする。＊が入力された場合、対象条件は無効となる。
        /// </summary>
        public string Condition { get; set; }
    }
}

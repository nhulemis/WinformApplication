﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 出典-スクールゾーンファイルデータ
    /// </summary>
    public class SchoolzoneFileData : IComparable, System.IComparable<SchoolzoneFileData>
    {
        /// <summary>
        /// OID
        /// </summary>
        public string SchoolzoneForeignOID
        {
            get;
            set;
        }

        /// <summary>
        /// 差分区分
        /// </summary>
        public string DiffKbn { get; set; }

        /// <summary>
        /// 差分明細
        /// </summary>
        public string DiffDetail { get; set; }

        /// <summary>
        /// 施設物件拡張のOID
        /// </summary>
        public string FacilityMExOID { get; set; }

        /// <summary>
        /// 出典ID
        /// </summary>
        public string MaterialID { get; set; }

        /// <summary>
        /// 物件住所（漢字）
        /// </summary>
        public string ResidenceKanji { get; set; }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string PhoneNum { get; set; }

        /// <summary>
        /// 正式漢字名称
        /// </summary>
        public string FormalKanjiNm { get; set; }

        /// <summary>
        /// 正式カナ名称
        /// </summary>
        public string FormalKanaNm { get; set; }

        /// <summary>
        /// 表示漢字名称
        /// </summary>
        public string DisplayKanjiNm { get; set; }

        /// <summary>
        /// 2次メッシュコード
        /// </summary>
        public string TwiceMeshCd { get; set; }

        /// <summary>
        /// 絶対座標：東経
        /// </summary>
        public string EastLongitude { get; set; }

        /// <summary>
        /// 絶対座標：北緯
        /// </summary>
        public string NorthLatitude { get; set; }

        /// <summary>
        /// 読込むファイル区分
        /// </summary>
        public string FileType { get; set; }

        /// <summary>
        /// 並べ替えるロジック
        /// </summary>
        /// <param name="other">出典-スクールゾーンファイルデータ</param>
        /// <returns>int</returns>
        public int CompareTo(SchoolzoneFileData other)
        {
            return MaterialID.CompareTo(other.MaterialID);
        }

        /// <summary>
        /// 比較ロジック
        /// </summary>
        /// <param name="obj">object</param>
        /// <returns>int</returns>
        public int CompareTo(object obj)
        {
            // nullより大きい
            if (obj == null)
            {
                return 1;
            }

            // 違う型とは比較できない
            if (this.GetType() != obj.GetType())
            {
                throw new ArgumentException("別の型とは比較できません。", "obj");
            }

            return this.CompareTo(obj as SchoolzoneFileData);
        }
    }
}

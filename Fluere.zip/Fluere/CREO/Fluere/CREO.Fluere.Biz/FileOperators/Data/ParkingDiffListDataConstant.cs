﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 駐車場差分リストファイルの定数クラス
    /// </summary>
    public static class ParkingDiffListDataConstant
    {
        #region 処理区分定義
        /// <summary>
        /// 新規
        /// </summary>
        public const ushort DIFF_NEW = 1;

        /// <summary>
        /// 変更
        /// </summary>
        public const ushort DIFF_CHANGE = 2;

        /// <summary>
        /// 削除
        /// </summary>
        public const ushort DIFF_DELETE = 3;
        #endregion

        #region キー定義
        /// <summary>
        /// 差分情報、項番：1
        /// </summary>
        public const string DiffTypekey = "DiffType";

        /// <summary>
        /// 駐車場ＩＤ、項番：2
        /// </summary>
        public const string ParkingIDkey = "ParkingID";

        /// <summary>
        /// 市外局番、項番：3
        /// </summary>
        public const string OutAreaCodekey = "OutAreaCode";

        /// <summary>
        /// 市内局番、項番：4
        /// </summary>
        public const string InAreaCodekey = "InAreaCode";

        /// <summary>
        /// 個人番号、項番：5
        /// </summary>
        public const string MemberCodekey = "MemberCode";

        /// <summary>
        /// 漢字名称、項番：6
        /// </summary>
        public const string KanjiNamekey = "KanjiName";

        /// <summary>
        /// カナ名称、項番：7
        /// </summary>
        public const string KanaNamekey = "KanaName";

        /// <summary>
        /// 都道府県、項番：8
        /// </summary>
        public const string ProvinceNamekey = "ProvinceName";

        /// <summary>
        /// 市区郡町村、項番：9
        /// </summary>
        public const string AdminNamekey = "AdminName";

        /// <summary>
        /// 大字・町丁、項番：10
        /// </summary>
        public const string Oazakey = "Oaza";

        /// <summary>
        /// 丁・町目、項番：11
        /// </summary>
        public const string SectionNamekey = "SectionName";

        /// <summary>
        /// 番号、項番：12
        /// </summary>
        public const string Numberkey = "Number";

        /// <summary>
        /// 郵便番号、項番：13
        /// </summary>
        public const string TPostCodekey = "TPostCode";

        /// <summary>
        /// 市町村コード、項番：14
        /// </summary>
        public const string AdminCodekey = "AdminCode";

        /// <summary>
        /// 東経、項番：15
        /// </summary>
        public const string Longitudekey = "Longitude";

        /// <summary>
        /// 北緯、項番：16
        /// </summary>
        public const string Latitudekey = "Latitude";

        /// <summary>
        /// 東経（入口）、項番：17
        /// </summary>
        public const string LongitudeInkey = "LongitudeIn";

        /// <summary>
        /// 北緯（入口）、項番：18
        /// </summary>
        public const string LatitudeInkey = "LatitudeIn";

        /// <summary>
        /// 定休日設定数、項番：19
        /// </summary>
        public const string RegularHolidayInfoNumkey = "RegularHolidayInfoNum";

        /// <summary>
        /// 定休日種別１、項番：20
        /// </summary>
        public const string RegularHolidayTyp1key = "RegularHolidayTyp1";

        /// <summary>
        /// 定休日内容１、項番：21
        /// </summary>
        public const string RegularHolidayInfo1key = "RegularHolidayInfo1";

        /// <summary>
        /// 定休日種別２、項番：22
        /// </summary>
        public const string RegularHolidayTyp2key = "RegularHolidayTyp2";

        /// <summary>
        /// 定休日内容２、項番：23
        /// </summary>
        public const string RegularHolidayInfo2key = "RegularHolidayInfo2";

        /// <summary>
        /// 定休日種別３、項番：24
        /// </summary>
        public const string RegularHolidayTyp3key = "RegularHolidayTyp3";

        /// <summary>
        /// 定休日内容３、項番：25
        /// </summary>
        public const string RegularHolidayInfo3key = "RegularHolidayInfo3";

        /// <summary>
        /// 定休日種別４、項番：26
        /// </summary>
        public const string RegularHolidayTyp4key = "RegularHolidayTyp4";

        /// <summary>
        /// 定休日内容４、項番：27
        /// </summary>
        public const string RegularHolidayInfo4key = "RegularHolidayInfo4";

        /// <summary>
        /// 定休日種別５、項番：28
        /// </summary>
        public const string RegularHolidayTyp5key = "RegularHolidayTyp5";

        /// <summary>
        /// 定休日内容５、項番：29
        /// </summary>
        public const string RegularHolidayInfo5key = "RegularHolidayInfo5";

        /// <summary>
        /// 定休日備考、項番：30
        /// </summary>
        public const string RegularHolidayMemokey = "RegularHolidayMemo";

        /// <summary>
        /// 営業時間設定数、項番：31
        /// </summary>
        public const string BizTimeNumkey = "BizTimeNum";

        /// <summary>
        /// 営業時間１、項番：32
        /// </summary>
        public const string BizTimeAry1key = "BizTimeAry1";

        /// <summary>
        /// 種別１、項番：33
        /// </summary>
        public const string BizTimeTyp1key = "BizTimeTyp1";

        /// <summary>
        /// 種別その他１、項番：34
        /// </summary>
        public const string BizTimeTypAnother1key = "BizTimeTypAnother1";

        /// <summary>
        /// 開始時刻１、項番：35
        /// </summary>
        public const string StartHour1key = "StartHour1";

        /// <summary>
        /// 終了時刻１、項番：36
        /// </summary>
        public const string EndHour1key = "EndHour1";

        /// <summary>
        /// 単位時間１、項番：37
        /// </summary>
        public const string UnitTime1key = "UnitTime1";

        /// <summary>
        /// 単位料金１、項番：38
        /// </summary>
        public const string Rate1key = "Rate1";

        /// <summary>
        /// 営業時間２、項番：39
        /// </summary>
        public const string BizTimeAry2key = "BizTimeAry2";

        /// <summary>
        /// 種別２、項番：40
        /// </summary>
        public const string BizTimeTyp2key = "BizTimeTyp2";

        /// <summary>
        /// 種別その他２、項番：41
        /// </summary>
        public const string BizTimeTypAnother2key = "BizTimeTypAnother2";

        /// <summary>
        /// 開始時刻２、項番：42
        /// </summary>
        public const string StartHour2key = "StartHour2";

        /// <summary>
        /// 終了時刻２、項番：43
        /// </summary>
        public const string EndHour2key = "EndHour2";

        /// <summary>
        /// 単位時間２、項番：44
        /// </summary>
        public const string UnitTime2key = "UnitTime2";

        /// <summary>
        /// 単位料金２、項番：45
        /// </summary>
        public const string Rate2key = "Rate2";

        /// <summary>
        /// 営業時間３、項番：46
        /// </summary>
        public const string BizTimeAry3key = "BizTimeAry3";

        /// <summary>
        /// 種別３、項番：47
        /// </summary>
        public const string BizTimeTyp3key = "BizTimeTyp3";

        /// <summary>
        /// 種別その他３、項番：48
        /// </summary>
        public const string BizTimeTypAnother3key = "BizTimeTypAnother3";

        /// <summary>
        /// 開始時刻３、項番：49
        /// </summary>
        public const string StartHour3key = "StartHour3";

        /// <summary>
        /// 終了時刻３、項番：50
        /// </summary>
        public const string EndHour3key = "EndHour3";

        /// <summary>
        /// 単位時間３、項番：51
        /// </summary>
        public const string UnitTime3key = "UnitTime3";

        /// <summary>
        /// 単位料金３、項番：52
        /// </summary>
        public const string Rate3key = "Rate3";

        /// <summary>
        /// 営業時間４、項番：53
        /// </summary>
        public const string BizTimeAry4key = "BizTimeAry4";

        /// <summary>
        /// 種別４、項番：54
        /// </summary>
        public const string BizTimeTyp4key = "BizTimeTyp4";

        /// <summary>
        /// 種別その他４、項番：55
        /// </summary>
        public const string BizTimeTypAnother4key = "BizTimeTypAnother4";

        /// <summary>
        /// 開始時刻４、項番：56
        /// </summary>
        public const string StartHour4key = "StartHour4";

        /// <summary>
        /// 終了時刻４、項番：57
        /// </summary>
        public const string EndHour4key = "EndHour4";

        /// <summary>
        /// 単位時間４、項番：58
        /// </summary>
        public const string UnitTime4key = "UnitTime4";

        /// <summary>
        /// 単位料金４、項番：59
        /// </summary>
        public const string Rate4key = "Rate4";

        /// <summary>
        /// 営業時間５、項番：60
        /// </summary>
        public const string BizTimeAry5key = "BizTimeAry5";

        /// <summary>
        /// 種別５、項番：61
        /// </summary>
        public const string BizTimeTyp5key = "BizTimeTyp5";

        /// <summary>
        /// 種別その他５、項番：62
        /// </summary>
        public const string BizTimeTypAnother5key = "BizTimeTypAnother5";

        /// <summary>
        /// 開始時刻５、項番：63
        /// </summary>
        public const string StartHour5key = "StartHour5";

        /// <summary>
        /// 終了時刻５、項番：64
        /// </summary>
        public const string EndHour5key = "EndHour5";

        /// <summary>
        /// 単位料金５、項番：65
        /// </summary>
        public const string Rate5key = "Rate5";

        /// <summary>
        /// 単位時間５、項番：66
        /// </summary>
        public const string UnitTime5key = "UnitTime5";

        /// <summary>
        /// 定休日（Ｔ）、項番：67
        /// </summary>
        public const string RegularHolidaykey = "RegularHoliday";

        /// <summary>
        /// 営業時間（Ｔ）１、項番：68
        /// </summary>
        public const string BizTime1key = "BizTime1";

        /// <summary>
        /// 営業時間（Ｔ）２、項番：69
        /// </summary>
        public const string BizTime2key = "BizTime2";

        /// <summary>
        /// 料金情報１、項番：70
        /// </summary>
        public const string RateInfo1key = "RateInfo1";

        /// <summary>
        /// 料金情報２、項番：71
        /// </summary>
        public const string RateInfo2key = "RateInfo2";

        /// <summary>
        /// 料金情報３、項番：72
        /// </summary>
        public const string RateInfo3key = "RateInfo3";

        /// <summary>
        /// 料金情報４、項番：73
        /// </summary>
        public const string RateInfo4key = "RateInfo4";

        /// <summary>
        /// 回数券、項番：74
        /// </summary>
        public const string CouponTicketkey = "CouponTicket";

        /// <summary>
        /// プリペイドカード、項番：75
        /// </summary>
        public const string PrepaidCardkey = "PrepaidCard";

        /// <summary>
        /// クレジットカード、項番：76
        /// </summary>
        public const string CreditCardkey = "CreditCard";

        /// <summary>
        /// クレジット種類、項番：77
        /// </summary>
        public const string CreditCardTypkey = "CreditCardTyp";

        /// <summary>
        /// 現金、項番：78
        /// </summary>
        public const string Cashkey = "Cash";

        /// <summary>
        /// 千円札使用、項番：79
        /// </summary>
        public const string Use1000Yenkey = "Use1000Yen";

        /// <summary>
        /// 五千円札使用、項番：80
        /// </summary>
        public const string Use5000Yenkey = "Use5000Yen";

        /// <summary>
        /// 一万円札使用、項番：81
        /// </summary>
        public const string Use10000Yenkey = "Use10000Yen";

        /// <summary>
        /// 領収書の有無、項番：82
        /// </summary>
        public const string Receiptkey = "Receipt";

        /// <summary>
        /// ジャンル、項番：83
        /// </summary>
        public const string Genrekey = "Genre";

        /// <summary>
        /// タイプ設定数、項番：84
        /// </summary>
        public const string TypKindInfoNumkey = "TypKindInfoNum";

        /// <summary>
        /// タイプＡ１、項番：85
        /// </summary>
        public const string TypKindInfoTypA1key = "TypKindInfoTypA1";

        /// <summary>
        /// タイプＢ１、項番：86
        /// </summary>
        public const string TypKindInfoTypB1key = "TypKindInfoTypB1";

        /// <summary>
        /// タイプＡ２、項番：87
        /// </summary>
        public const string TypKindInfoTypA2key = "TypKindInfoTypA2";

        /// <summary>
        /// タイプＢ２、項番：88
        /// </summary>
        public const string TypKindInfoTypB2key = "TypKindInfoTypB2";

        /// <summary>
        /// タイプＡ３、項番：89
        /// </summary>
        public const string TypKindInfoTypA3key = "TypKindInfoTypA3";

        /// <summary>
        /// タイプＢ３、項番：90
        /// </summary>
        public const string TypKindInfoTypB3key = "TypKindInfoTypB3";

        /// <summary>
        /// タイプＡ４、項番：91
        /// </summary>
        public const string TypKindInfoTypA4key = "TypKindInfoTypA4";

        /// <summary>
        /// タイプＢ４、項番：92
        /// </summary>
        public const string TypKindInfoTypB4key = "TypKindInfoTypB4";

        /// <summary>
        /// タイプＡ５、項番：93
        /// </summary>
        public const string TypKindInfoTypA5key = "TypKindInfoTypA5";

        /// <summary>
        /// タイプＢ５、項番：94
        /// </summary>
        public const string TypKindInfoTypB5key = "TypKindInfoTypB5";

        /// <summary>
        /// 収容台数、項番：95
        /// </summary>
        public const string TakeInUnitkey = "TakeInUnit";

        /// <summary>
        /// 有人・無人、項番：96
        /// </summary>
        public const string Humankey = "Human";

        /// <summary>
        /// 障害者専用スペース台数、項番：97
        /// </summary>
        public const string HandicappedOnlySpaceCntkey = "HandicappedOnlySpaceCnt";

        /// <summary>
        /// 女性専用スペース台数、項番：98
        /// </summary>
        public const string WomanOnlySpaceCntkey = "WomanOnlySpaceCnt";

        /// <summary>
        /// 高さ制限、項番：99
        /// </summary>
        public const string LimitInfoHeightkey = "LimitInfoHeight";

        /// <summary>
        /// 幅制限、項番：100
        /// </summary>
        public const string LimitInfoWidthkey = "LimitInfoWidth";

        /// <summary>
        /// 長さ制限、項番：101
        /// </summary>
        public const string LimitInfoLengthkey = "LimitInfoLength";

        /// <summary>
        /// 重量制限、項番：102
        /// </summary>
        public const string LimitInfoWeightkey = "LimitInfoWeight";

        /// <summary>
        /// ３NO制限、項番：103
        /// </summary>
        public const string LimitInfo3Nokey = "LimitInfo3No";

        /// <summary>
        /// ＲＶ制限、項番：104
        /// </summary>
        public const string LimitInfoRVkey = "LimitInfoRV";

        /// <summary>
        /// 1BOX制限、項番：105
        /// </summary>
        public const string LimitInfo1BOXkey = "LimitInfo1BOX";

        /// <summary>
        /// 外車制限、項番：106
        /// </summary>
        public const string LimitInfoImportedkey = "LimitInfoImported";

        /// <summary>
        /// その他制限、項番：107
        /// </summary>
        public const string LimitInfoAnotherkey = "LimitInfoAnother";

        /// <summary>
        /// 提携店舗設定数、項番：108
        /// </summary>
        public const string CooperationStoreCntkey = "CooperationStoreCnt";

        /// <summary>
        /// 提携店舗１、項番：109
        /// </summary>
        public const string CooperationStore1key = "CooperationStore1";

        /// <summary>
        /// 店舗電話１、項番：110
        /// </summary>
        public const string StoreTel1key = "StoreTel1";

        /// <summary>
        /// 割引条件１、項番：111
        /// </summary>
        public const string DiscountCondition1key = "DiscountCondition1";

        /// <summary>
        /// 提携店舗２、項番：112
        /// </summary>
        public const string CooperationStore2key = "CooperationStore2";

        /// <summary>
        /// 店舗電話２、項番：113
        /// </summary>
        public const string StoreTel2key = "StoreTel2";

        /// <summary>
        /// 割引条件２、項番：114
        /// </summary>
        public const string DiscountCondition2key = "DiscountCondition2";

        /// <summary>
        /// 提携店舗３、項番：115
        /// </summary>
        public const string CooperationStore3key = "CooperationStore3";

        /// <summary>
        /// 店舗電話３、項番：116
        /// </summary>
        public const string StoreTel3key = "StoreTel3";

        /// <summary>
        /// 割引条件３、項番：117
        /// </summary>
        public const string DiscountCondition3key = "DiscountCondition3";

        /// <summary>
        /// 提携店舗４、項番：118
        /// </summary>
        public const string CooperationStore4key = "CooperationStore4";

        /// <summary>
        /// 店舗電話４、項番：119
        /// </summary>
        public const string StoreTel4key = "StoreTel4";

        /// <summary>
        /// 割引条件４、項番：120
        /// </summary>
        public const string DiscountCondition4key = "DiscountCondition4";

        /// <summary>
        /// 提携店舗５、項番：121
        /// </summary>
        public const string CooperationStore5key = "CooperationStore5";

        /// <summary>
        /// 店舗電話５、項番：122
        /// </summary>
        public const string StoreTel5key = "StoreTel5";

        /// <summary>
        /// 割引条件５、項番：123
        /// </summary>
        public const string DiscountCondition5key = "DiscountCondition5";

        /// <summary>
        /// 変更内容、項番：124
        /// </summary>
        public const string UpdateContentkey = "UpdateContent";

        #endregion

        #region 読み取りファイルキーディクショナリー

        /// <summary>
        ///  読み取りファイルキーディクショナリー
        /// </summary>
        public static Dictionary<string, string> ParkingKeyDictionary;

        #endregion

        #region 項目名定義
        /// <summary>
        /// 差分情報、項番：1
        /// </summary>
        public static string DiffType
        {
            get
            {
                return ParkingKeyDictionary[DiffTypekey];
            }
        }

        /// <summary>
        /// 駐車場ＩＤ、項番：2
        /// </summary>
        public static string ParkingID
        {
            get
            {
                return ParkingKeyDictionary[ParkingIDkey];
            }
        }

        /// <summary>
        /// 市外局番、項番：3
        /// </summary>
        public static string OutAreaCode
        {
            get
            {
                return ParkingKeyDictionary[OutAreaCodekey];
            }
        }

        /// <summary>
        /// 市内局番、項番：4
        /// </summary>
        public static string InAreaCode
        {
            get
            {
                return ParkingKeyDictionary[InAreaCodekey];
            }
        }

        /// <summary>
        /// 個人番号、項番：5
        /// </summary>
        public static string MemberCode
        {
            get
            {
                return ParkingKeyDictionary[MemberCodekey];
            }
        }

        /// <summary>
        /// 漢字名称、項番：6
        /// </summary>
        public static string KanjiName
        {
            get
            {
                return ParkingKeyDictionary[KanjiNamekey];
            }
        }

        /// <summary>
        /// カナ名称、項番：7
        /// </summary>
        public static string KanaName
        {
            get
            {
                return ParkingKeyDictionary[KanaNamekey];
            }
        }

        /// <summary>
        /// 都道府県、項番：8
        /// </summary>
        public static string ProvinceName
        {
            get
            {
                return ParkingKeyDictionary[ProvinceNamekey];
            }
        }

        /// <summary>
        /// 市区郡町村、項番：9
        /// </summary>
        public static string AdminName
        {
            get
            {
                return ParkingKeyDictionary[AdminNamekey];
            }
        }

        /// <summary>
        /// 大字・町丁、項番：10
        /// </summary>
        public static string Oaza
        {
            get
            {
                return ParkingKeyDictionary[Oazakey];
            }
        }

        /// <summary>
        /// 丁・町目、項番：11
        /// </summary>
        public static string SectionName
        {
            get
            {
                return ParkingKeyDictionary[SectionNamekey];
            }
        }

        /// <summary>
        /// 番号、項番：12
        /// </summary>
        public static string Number
        {
            get
            {
                return ParkingKeyDictionary[Numberkey];
            }
        }

        /// <summary>
        /// 郵便番号、項番：13
        /// </summary>
        public static string TPostCode
        {
            get
            {
                return ParkingKeyDictionary[TPostCodekey];
            }
        }

        /// <summary>
        /// 市町村コード、項番：14
        /// </summary>
        public static string AdminCode
        {
            get
            {
                return ParkingKeyDictionary[AdminCodekey];
            }
        }

        /// <summary>
        /// 東経、項番：15
        /// </summary>
        public static string Longitude
        {
            get
            {
                return ParkingKeyDictionary[Longitudekey];
            }
        }

        /// <summary>
        /// 北緯、項番：16
        /// </summary>
        public static string Latitude
        {
            get
            {
                return ParkingKeyDictionary[Latitudekey];
            }
        }

        /// <summary>
        /// 東経（入口）、項番：17
        /// </summary>
        public static string LongitudeIn
        {
            get
            {
                return ParkingKeyDictionary[LongitudeInkey];
            }
        }

        /// <summary>
        /// 北緯（入口）、項番：18
        /// </summary>
        public static string LatitudeIn
        {
            get
            {
                return ParkingKeyDictionary[LatitudeInkey];
            }
        }

        /// <summary>
        /// 定休日設定数、項番：19
        /// </summary>
        public static string RegularHolidayInfoNum
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayInfoNumkey];
            }
        }

        /// <summary>
        /// 定休日種別１、項番：20
        /// </summary>
        public static string RegularHolidayTyp1
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayTyp1key];
            }
        }

        /// <summary>
        /// 定休日内容１、項番：21
        /// </summary>
        public static string RegularHolidayInfo1
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayInfo1key];
            }
        }

        /// <summary>
        /// 定休日種別２、項番：22
        /// </summary>
        public static string RegularHolidayTyp2
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayTyp2key];
            }
        }

        /// <summary>
        /// 定休日内容２、項番：23
        /// </summary>
        public static string RegularHolidayInfo2
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayInfo2key];
            }
        }

        /// <summary>
        /// 定休日種別３、項番：24
        /// </summary>
        public static string RegularHolidayTyp3
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayTyp3key];
            }
        }

        /// <summary>
        /// 定休日内容３、項番：25
        /// </summary>
        public static string RegularHolidayInfo3
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayInfo3key];
            }
        }

        /// <summary>
        /// 定休日種別４、項番：26
        /// </summary>
        public static string RegularHolidayTyp4
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayTyp4key];
            }
        }

        /// <summary>
        /// 定休日内容４、項番：27
        /// </summary>
        public static string RegularHolidayInfo4
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayInfo4key];
            }
        }

        /// <summary>
        /// 定休日種別５、項番：28
        /// </summary>
        public static string RegularHolidayTyp5
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayTyp5key];
            }
        }

        /// <summary>
        /// 定休日内容５、項番：29
        /// </summary>
        public static string RegularHolidayInfo5
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayInfo5key];
            }
        }

        /// <summary>
        /// 定休日備考、項番：30
        /// </summary>
        public static string RegularHolidayMemo
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidayMemokey];
            }
        }

        /// <summary>
        /// 営業時間設定数、項番：31
        /// </summary>
        public static string BizTimeNum
        {
            get
            {
                return ParkingKeyDictionary[BizTimeNumkey];
            }
        }

        /// <summary>
        /// 営業時間１、項番：32
        /// </summary>
        public static string BizTimeAry1
        {
            get
            {
                return ParkingKeyDictionary[BizTimeAry1key];
            }
        }

        /// <summary>
        /// 種別１、項番：33
        /// </summary>
        public static string BizTimeTyp1
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTyp1key];
            }
        }

        /// <summary>
        /// 種別その他１、項番：34
        /// </summary>
        public static string BizTimeTypAnother1
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTypAnother1key];
            }
        }

        /// <summary>
        /// 開始時刻１、項番：35
        /// </summary>
        public static string StartHour1
        {
            get
            {
                return ParkingKeyDictionary[StartHour1key];
            }
        }

        /// <summary>
        /// 終了時刻１、項番：36
        /// </summary>
        public static string EndHour1
        {
            get
            {
                return ParkingKeyDictionary[EndHour1key];
            }
        }

        /// <summary>
        /// 単位時間１、項番：37
        /// </summary>
        public static string UnitTime1
        {
            get
            {
                return ParkingKeyDictionary[UnitTime1key];
            }
        }

        /// <summary>
        /// 単位料金１、項番：38
        /// </summary>
        public static string Rate1
        {
            get
            {
                return ParkingKeyDictionary[Rate1key];
            }
        }

        /// <summary>
        /// 営業時間２、項番：39
        /// </summary>
        public static string BizTimeAry2
        {
            get
            {
                return ParkingKeyDictionary[BizTimeAry2key];
            }
        }

        /// <summary>
        /// 種別２、項番：40
        /// </summary>
        public static string BizTimeTyp2
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTyp2key];
            }
        }

        /// <summary>
        /// 種別その他２、項番：41
        /// </summary>
        public static string BizTimeTypAnother2
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTypAnother2key];
            }
        }

        /// <summary>
        /// 開始時刻２、項番：42
        /// </summary>
        public static string StartHour2
        {
            get
            {
                return ParkingKeyDictionary[StartHour2key];
            }
        }

        /// <summary>
        /// 終了時刻２、項番：43
        /// </summary>
        public static string EndHour2
        {
            get
            {
                return ParkingKeyDictionary[EndHour2key];
            }
        }

        /// <summary>
        /// 単位時間２、項番：44
        /// </summary>
        public static string UnitTime2
        {
            get
            {
                return ParkingKeyDictionary[UnitTime2key];
            }
        }

        /// <summary>
        /// 単位料金２、項番：45
        /// </summary>
        public static string Rate2
        {
            get
            {
                return ParkingKeyDictionary[Rate2key];
            }
        }

        /// <summary>
        /// 営業時間３、項番：46
        /// </summary>
        public static string BizTimeAry3
        {
            get
            {
                return ParkingKeyDictionary[BizTimeAry3key];
            }
        }

        /// <summary>
        /// 種別３、項番：47
        /// </summary>
        public static string BizTimeTyp3
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTyp3key];
            }
        }

        /// <summary>
        /// 種別その他３、項番：48
        /// </summary>
        public static string BizTimeTypAnother3
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTypAnother3key];
            }
        }

        /// <summary>
        /// 開始時刻３、項番：49
        /// </summary>
        public static string StartHour3
        {
            get
            {
                return ParkingKeyDictionary[StartHour3key];
            }
        }

        /// <summary>
        /// 終了時刻３、項番：50
        /// </summary>
        public static string EndHour3
        {
            get
            {
                return ParkingKeyDictionary[EndHour3key];
            }
        }

        /// <summary>
        /// 単位時間３、項番：51
        /// </summary>
        public static string UnitTime3
        {
            get
            {
                return ParkingKeyDictionary[UnitTime3key];
            }
        }

        /// <summary>
        /// 単位料金３、項番：52
        /// </summary>
        public static string Rate3
        {
            get
            {
                return ParkingKeyDictionary[Rate3key];
            }
        }

        /// <summary>
        /// 営業時間４、項番：53
        /// </summary>
        public static string BizTimeAry4
        {
            get
            {
                return ParkingKeyDictionary[BizTimeAry4key];
            }
        }

        /// <summary>
        /// 種別４、項番：54
        /// </summary>
        public static string BizTimeTyp4
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTyp4key];
            }
        }

        /// <summary>
        /// 種別その他４、項番：55
        /// </summary>
        public static string BizTimeTypAnother4
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTypAnother4key];
            }
        }

        /// <summary>
        /// 開始時刻４、項番：56
        /// </summary>
        public static string StartHour4
        {
            get
            {
                return ParkingKeyDictionary[StartHour4key];
            }
        }

        /// <summary>
        /// 終了時刻４、項番：57
        /// </summary>
        public static string EndHour4
        {
            get
            {
                return ParkingKeyDictionary[EndHour4key];
            }
        }
      
        /// <summary>
        /// 単位時間４、項番：58
        /// </summary>
        public static string UnitTime4
        {
            get
            {
                return ParkingKeyDictionary[UnitTime4key];
            }
        }
      
        /// <summary>
        /// 単位料金４、項番：59 
        /// </summary>
        public static string Rate4
        {
            get
            {
                return ParkingKeyDictionary[Rate4key];
            }
        }

        /// <summary>
        /// 営業時間５、項番：60
        /// </summary>
        public static string BizTimeAry5
        {
            get
            {
                return ParkingKeyDictionary[BizTimeAry5key];
            }
        }

        /// <summary>
        /// 種別５、項番：61
        /// </summary>
        public static string BizTimeTyp5
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTyp5key];
            }
        }

        /// <summary>
        /// 種別その他５、項番：62
        /// </summary>
        public static string BizTimeTypAnother5
        {
            get
            {
                return ParkingKeyDictionary[BizTimeTypAnother5key];
            }
        }

        /// <summary>
        /// 開始時刻５、項番：63
        /// </summary>
        public static string StartHour5
        {
            get
            {
                return ParkingKeyDictionary[StartHour5key];
            }
        }

        /// <summary>
        /// 終了時刻５、項番：64
        /// </summary>
        public static string EndHour5
        {
            get
            {
                return ParkingKeyDictionary[EndHour5key];
            }
        }

        /// <summary>
        /// 単位時間５、項番：65
        /// </summary>
        public static string UnitTime5
        {
            get
            {
                return ParkingKeyDictionary[UnitTime5key];
            }
        }

        /// <summary>
        /// 単位料金５、項番：66
        /// </summary>
        public static string Rate5
        {
            get
            {
                return ParkingKeyDictionary[Rate5key];
            }
        }

        /// <summary>
        /// 定休日（Ｔ）、項番：67
        /// </summary>
        public static string RegularHoliday
        {
            get
            {
                return ParkingKeyDictionary[RegularHolidaykey];
            }
        }

        /// <summary>
        /// 営業時間（Ｔ）１、項番：68
        /// </summary>
        public static string BizTime1
        {
            get
            {
                return ParkingKeyDictionary[BizTime1key];
            }
        }

        /// <summary>
        /// 営業時間（Ｔ）２、項番：69
        /// </summary>
        public static string BizTime2
        {
            get
            {
                return ParkingKeyDictionary[BizTime2key];
            }
        }

        /// <summary>
        /// 料金情報１、項番：70
        /// </summary>
        public static string RateInfo1
        {
            get
            {
                return ParkingKeyDictionary[RateInfo1key];
            }
        }

        /// <summary>
        /// 料金情報２、項番：71
        /// </summary>
        public static string RateInfo2
        {
            get
            {
                return ParkingKeyDictionary[RateInfo2key];
            }
        }

        /// <summary>
        /// 料金情報３、項番：72
        /// </summary>
        public static string RateInfo3
        {
            get
            {
                return ParkingKeyDictionary[RateInfo3key];
            }
        }

        /// <summary>
        /// 料金情報４、項番：73
        /// </summary>
        public static string RateInfo4
        {
            get
            {
                return ParkingKeyDictionary[RateInfo4key];
            }
        }

        /// <summary>
        /// 回数券、項番：74
        /// </summary>
        public static string CouponTicket
        {
            get
            {
                return ParkingKeyDictionary[CouponTicketkey];
            }
        }

        /// <summary>
        /// プリペイドカード、項番：75
        /// </summary>
        public static string PrepaidCard
        {
            get
            {
                return ParkingKeyDictionary[PrepaidCardkey];
            }
        }

        /// <summary>
        /// クレジットカード、項番：76
        /// </summary>
        public static string CreditCard
        {
            get
            {
                return ParkingKeyDictionary[CreditCardkey];
            }
        }

        /// <summary>
        /// クレジット種類、項番：77
        /// </summary>
        public static string CreditCardTyp
        {
            get
            {
                return ParkingKeyDictionary[CreditCardTypkey];
            }
        }

        /// <summary>
        /// 現金、項番：78
        /// </summary>
        public static string Cash
        {
            get
            {
                return ParkingKeyDictionary[Cashkey];
            }
        }

        /// <summary>
        /// 千円札使用、項番：79
        /// </summary>
        public static string Use1000Yen
        {
            get
            {
                return ParkingKeyDictionary[Use1000Yenkey];
            }
        }

        /// <summary>
        /// 五千円札使用、項番：80
        /// </summary>
        public static string Use5000Yen
        {
            get
            {
                return ParkingKeyDictionary[Use5000Yenkey];
            }
        }

        /// <summary>
        /// 一万円札使用、項番：81
        /// </summary>
        public static string Use10000Yen
        {
            get
            {
                return ParkingKeyDictionary[Use10000Yenkey];
            }
        }

        /// <summary>
        /// 領収書の有無、項番：82
        /// </summary>
        public static string Receipt
        {
            get
            {
                return ParkingKeyDictionary[Receiptkey];
            }
        }

        /// <summary>
        /// ジャンル、項番：83
        /// </summary>
        public static string Genre
        {
            get
            {
                return ParkingKeyDictionary[Genrekey];
            }
        }

        /// <summary>
        /// タイプ設定数、項番：84
        /// </summary>
        public static string TypKindInfoNum
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoNumkey];
            }
        }

        /// <summary>
        /// タイプＡ１、項番：85
        /// </summary>
        public static string TypKindInfoTypA1
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypA1key];
            }
        }

        /// <summary>
        /// タイプＢ１、項番：86
        /// </summary>
        public static string TypKindInfoTypB1
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypB1key];
            }
        }

        /// <summary>
        /// タイプＡ２、項番：87
        /// </summary>
        public static string TypKindInfoTypA2
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypA2key];
            }
        }

        /// <summary>
        /// タイプＢ２、項番：88
        /// </summary>
        public static string TypKindInfoTypB2
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypB2key];
            }
        }

        /// <summary>
        /// タイプＡ３、項番：89
        /// </summary>
        public static string TypKindInfoTypA3
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypA3key];
            }
        }

        /// <summary>
        /// タイプＢ３、項番：90
        /// </summary>
        public static string TypKindInfoTypB3
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypB3key];
            }
        }

        /// <summary>
        /// タイプＡ４、項番：91
        /// </summary>
        public static string TypKindInfoTypA4
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypA4key];
            }
        }

        /// <summary>
        /// タイプＢ４、項番：92
        /// </summary>
        public static string TypKindInfoTypB4
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypB4key];
            }
        }

        /// <summary>
        /// タイプＡ５、項番：93
        /// </summary>
        public static string TypKindInfoTypA5
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypA5key];
            }
        }

        /// <summary>
        /// タイプＢ５、項番：94
        /// </summary>
        public static string TypKindInfoTypB5
        {
            get
            {
                return ParkingKeyDictionary[TypKindInfoTypB5key];
            }
        }

        /// <summary>
        /// 収容台数、項番：95
        /// </summary>
        public static string TakeInUnit
        {
            get
            {
                return ParkingKeyDictionary[TakeInUnitkey];
            }
        }

        /// <summary>
        /// 有人・無人、項番：96
        /// </summary>
        public static string Human
        {
            get
            {
                return ParkingKeyDictionary[Humankey];
            }
        }

        /// <summary>
        /// 障害者専用スペース台数、項番：97
        /// </summary>
        public static string HandicappedOnlySpaceCnt
        {
            get
            {
                return ParkingKeyDictionary[HandicappedOnlySpaceCntkey];
            }
        }

        /// <summary>
        /// 女性専用スペース台数、項番：98
        /// </summary>
        public static string WomanOnlySpaceCnt
        {
            get
            {
                return ParkingKeyDictionary[WomanOnlySpaceCntkey];
            }
        }

        /// <summary>
        /// 高さ制限、項番：99
        /// </summary>
        public static string LimitInfoHeight
        {
            get
            {
                return ParkingKeyDictionary[LimitInfoHeightkey];
            }
        }

        /// <summary>
        /// 幅制限、項番：100
        /// </summary>
        public static string LimitInfoWidth
        {
            get
            {
                return ParkingKeyDictionary[LimitInfoWidthkey];
            }
        }

        /// <summary>
        /// 長さ制限、項番：101
        /// </summary>
        public static string LimitInfoLength
        {
            get
            {
                return ParkingKeyDictionary[LimitInfoLengthkey];
            }
        }

        /// <summary>
        /// 重量制限、項番：102
        /// </summary>
        public static string LimitInfoWeight
        {
            get
            {
                return ParkingKeyDictionary[LimitInfoWeightkey];
            }
        }

        /// <summary>
        /// ３NO制限、項番：103
        /// </summary>
        public static string LimitInfo3No
        {
            get
            {
                return ParkingKeyDictionary[LimitInfo3Nokey];
            }
        }

        /// <summary>
        /// ＲＶ制限、項番：104
        /// </summary>
        public static string LimitInfoRV
        {
            get
            {
                return ParkingKeyDictionary[LimitInfoRVkey];
            }
        }

        /// <summary>
        /// 1BOX制限、項番：105
        /// </summary>
        public static string LimitInfo1BOX
        {
            get
            {
                return ParkingKeyDictionary[LimitInfo1BOXkey];
            }
        }

        /// <summary>
        /// 外車制限、項番：106
        /// </summary>
        public static string LimitInfoImported
        {
            get
            {
                return ParkingKeyDictionary[LimitInfoImportedkey];
            }
        }

        /// <summary>
        /// その他制限、項番：107
        /// </summary>
        public static string LimitInfoAnother
        {
            get
            {
                return ParkingKeyDictionary[LimitInfoAnotherkey];
            }
        }

        /// <summary>
        /// 提携店舗設定数、項番：108
        /// </summary>
        public static string CooperationStoreCnt
        {
            get
            {
                return ParkingKeyDictionary[CooperationStoreCntkey];
            }
        }

        /// <summary>
        /// 提携店舗１、項番：109
        /// </summary>
        public static string CooperationStore1
        {
            get
            {
                return ParkingKeyDictionary[CooperationStore1key];
            }
        }

        /// <summary>
        /// 店舗電話１、項番：110
        /// </summary>
        public static string StoreTel1
        {
            get
            {
                return ParkingKeyDictionary[StoreTel1key];
            }
        }

        /// <summary>
        /// 割引条件１、項番：111
        /// </summary>
        public static string DiscountCondition1
        {
            get
            {
                return ParkingKeyDictionary[DiscountCondition1key];
            }
        }

        /// <summary>
        /// 提携店舗２、項番：112
        /// </summary>
        public static string CooperationStore2
        {
            get
            {
                return ParkingKeyDictionary[CooperationStore2key];
            }
        }

        /// <summary>
        /// 店舗電話２、項番：113
        /// </summary>
        public static string StoreTel2
        {
            get
            {
                return ParkingKeyDictionary[StoreTel2key];
            }
        }

        /// <summary>
        /// 割引条件２、項番：114
        /// </summary>
        public static string DiscountCondition2
        {
            get
            {
                return ParkingKeyDictionary[DiscountCondition2key];
            }
        }

        /// <summary>
        /// 提携店舗３、項番：115
        /// </summary>
        public static string CooperationStore3
        {
            get
            {
                return ParkingKeyDictionary[CooperationStore3key];
            }
        }

        /// <summary>
        /// 店舗電話３、項番：116
        /// </summary>
        public static string StoreTel3
        {
            get
            {
                return ParkingKeyDictionary[StoreTel3key];
            }
        }

        /// <summary>
        /// 割引条件３、項番：117
        /// </summary>
        public static string DiscountCondition3
        {
            get
            {
                return ParkingKeyDictionary[DiscountCondition3key];
            }
        }

        /// <summary>
        /// 提携店舗４、項番：118
        /// </summary>
        public static string CooperationStore4
        {
            get
            {
                return ParkingKeyDictionary[CooperationStore4key];
            }
        }

        /// <summary>
        /// 店舗電話４、項番：119
        /// </summary>
        public static string StoreTel4
        {
            get
            {
                return ParkingKeyDictionary[StoreTel4key];
            }
        }

        /// <summary>
        /// 割引条件４、項番：120
        /// </summary>
        public static string DiscountCondition4
        {
            get
            {
                return ParkingKeyDictionary[DiscountCondition4key];
            }
        }

        /// <summary>
        /// 提携店舗５、項番：121
        /// </summary>
        public static string CooperationStore5
        {
            get
            {
                return ParkingKeyDictionary[CooperationStore5key];
            }
        }

        /// <summary>
        /// 店舗電話５、項番：122
        /// </summary>
        public static string StoreTel5
        {
            get
            {
                return ParkingKeyDictionary[StoreTel5key];
            }
        }

        /// <summary>
        /// 割引条件５、項番：123
        /// </summary>
        public static string DiscountCondition5
        {
            get
            {
                return ParkingKeyDictionary[DiscountCondition5key];
            }
        }

          /// <summary>
        /// 変更内容、項番：124
        /// </summary>
        public static string UpdateContent
        {
            get
            {
                return ParkingKeyDictionary[UpdateContentkey];
            }
        }

        #endregion
    }
}

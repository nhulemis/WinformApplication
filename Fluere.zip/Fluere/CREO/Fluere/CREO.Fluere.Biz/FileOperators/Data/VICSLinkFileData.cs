﻿using System.Collections.Generic;
using CREO.DataModel;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// VICSリンクファイル
    /// </summary>
    public class VICSLinkFileData
    {
        /// <summary>
        /// リンク構成ノード列
        /// </summary>
        private List<string> basicRoadNodeSeqList = new List<string>();

        /// <summary>
        /// レコードID
        /// </summary>
        public ushort? RecordID { get; set; }

        /// <summary>
        /// 継続レコード番号
        /// </summary>
        public byte? ContinueRecordNo { get; set; }

        /// <summary>
        /// リンク区分：１高速道路、２都市高速道路（含指定都市高速道路）、３一般道路、４その他
        /// </summary>
        public byte? LinkDiff { get; set; }

        /// <summary>
        /// VICSリンク番号
        /// </summary>
        public int? VICSLinkNo { get; set; }

        /// <summary>
        /// 更新コード
        /// </summary>
        public byte? UpdateCode { get; set; }

        /// <summary>
        /// 新規追加リンク識別コード
        /// </summary>
        public byte? AddNewLinkCode { get; set; }

        /// <summary>
        /// 流入側ノード情報基本道路ノード番号
        /// </summary>
        public string InflowBasicRoadNodeNo { get; set; }

        /// <summary>
        /// 流入側ノード情報基本道路ノード種別
        /// </summary>
        public byte? InflowBasicRoadNodeKbn { get; set; }

        /// <summary>
        /// 流入側ノード情報統合交差点識別
        /// </summary>
        public byte? InflowCrossPointDis { get; set; }

        /// <summary>
        /// 流出側ノード情報基本道路ノード番号
        /// </summary>
        public string OutflowBasicRoadNodeNo { get; set; }

        /// <summary>
        /// 流出側ノード情報基本道路ノード種別
        /// </summary>
        public byte? OutflowBasicRoadNodeKbn { get; set; }

        /// <summary>
        /// 流出側ノード情報統合交差点識別
        /// </summary>
        public byte? OutflowCrossPointDis { get; set; }

        /// <summary>
        /// 構成基本道路ノードデータ総数
        /// </summary>
        public int? NodeDataCount { get; set; }

        /// <summary>
        /// フィラー
        /// </summary>
        public string Filler { get; set; }

        /// <summary>
        /// 継続フラグ
        /// </summary>
        public byte? ContinueFlag { get; set; }

        /// <summary>
        /// リンク構成ノード列
        /// </summary>
        public List<string> BasicRoadNodeSeqList
        {
            get { return basicRoadNodeSeqList; }
            set { basicRoadNodeSeqList = value; }
        }

        /// <summary>
        /// 予約VICS区間はVICSリンクデータに合うかどうかを判断する
        /// </summary>
        /// <param name="dVicsSectionBase">予約VICS区間データ</param>
        /// <returns>VICSリンクデータに合うかどうか</returns>
        public bool IsMachDVicsSectionRsrvd(DVicsSectionBase dVicsSectionBase)
        {
            // 予約VICS区間．VICSリンク番号 = VICSリンクデータ．VICSリンク番号
            if (this.VICSLinkNo != dVicsSectionBase.VicsLinkNo)
            {
                return false;
            }

            // 予約VICS区間．VICSリンク区分コード = VICSリンクデータ．リンク区分
            if (this.LinkDiff == dVicsSectionBase.VicsLinkSectionCode)
            {
                return true;
            }

            // ※VICSリンクデータ．リンク区分：１高速道路、２都市高速道路（含指定都市高速道路）、３一般道路、４その他
            // ※VICS区間．VICSリンク区分コード: null未設定、０無効、１高速、２都市高速、３一般、99その他
            if (this.LinkDiff == Code.VicsLinkSectionCode_4 &&
                dVicsSectionBase.VicsLinkSectionCode == Code.VicsLinkSectionCode_99)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// コード定義
        /// </summary>
        public class Code
        {
            /// <summary>
            /// VICSリンクファイルのレコードIDが81
            /// </summary>
            public static readonly ushort? RecordID_81 = 81;

            /// <summary>
            /// VICSリンクデータ．リンク区分：　４その他
            /// </summary>
            public static readonly byte? VicsLinkSectionCode_4 = 4;

            /// <summary>
            /// VICS区間．VICSリンク区分コード：99その他
            /// </summary>
            public static readonly byte? VicsLinkSectionCode_99 = 99;
        }
    }
}

﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// FluereToDoListPattern04.xmlに対するToDoリストファイルデータ
    /// </summary>
    public class FluereToDoListPattern04Data
    {
        /// <summary>
        /// 調査対象ID
        /// </summary>
        public string InquestObjectID { get; set; }

        /// <summary>
        /// 経度
        /// </summary>
        public string Longitude { get; set; }

        /// <summary>
        /// 緯度
        /// </summary>
        public string Latitude { get; set; }

        /// <summary>
        /// 検索対象DB
        /// </summary>
        public string QueryObjectDB { get; set; }

        /// <summary>
        /// OID
        /// </summary>
        public string OID { get; set; }

        /// <summary>
        /// 確認
        /// </summary>
        public string WorkStatus { get; set; }

        /// <summary>
        /// 表示名称
        /// </summary>
        public string Column1 { get; set; }

        /// <summary>
        /// 文字種別
        /// </summary>
        public string Column2 { get; set; }

        /// <summary>
        /// ２次メッシュコード
        /// </summary>
        public string Column3 { get; set; }

        /// <summary>
        /// 漢字名称
        /// </summary>
        public string Column4 { get; set; }

        /// <summary>
        /// 住所名称（方書含む）
        /// </summary>
        public string Column5 { get; set; }

        /// <summary>
        /// 電話番号
        /// </summary>
        public string Column6 { get; set; }
    }
}

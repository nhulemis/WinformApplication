﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CREO.Fluere.Biz.Utility;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 新旧対応表ファイル（カナ・地番有り）
    /// </summary>
    public class NewOldAreaMappingData : IComparable, System.IComparable<NewOldAreaMappingData>
    {
        /// <summary>
        /// 地番リスト(private変数)
        /// </summary>
        private List<string> _areaCodeList = null;

        /// <summary>
        /// 旧住所コード（aabbb-ccc-ddd）
        /// ※cccは、a~zが含まれる可能
        /// </summary>
        public string OldAdrCode
        {
            get;
            set;
        }

        /// <summary>
        /// 旧郡名称（漢字）
        /// </summary>
        public string OldPrefectureAdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 旧市区町村名称（漢字）
        /// </summary>
        public string OldMunicipalityAdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 旧大字名称（漢字）
        /// </summary>
        public string OldOoazAdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 旧小字名称（漢字）
        /// </summary>
        public string OldKoazAdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 旧郡名称（全角カナ）
        /// </summary>
        public string OldPrefectureAdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 旧市区町村名称（全角カナ）
        /// </summary>
        public string OldMunicipalityAdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 旧大字名称（全角カナ）
        /// </summary>
        public string OldOoazAdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 旧小字名称（全角カナ）
        /// </summary>
        public string OldKoazAdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 地番（フォーマット例：102～109,111～120,201）
        /// </summary>
        public string AreaCode
        {
            get;
            set;
        }

        ///////////////////////////////

        /// <summary>
        /// 新住所コード（aabbb-ccc-ddd）
        /// ※cccは、a~zが含まれる可能
        /// </summary>
        public string NewAdrCode
        {
            get;
            set;
        }

        /// <summary>
        /// 新郡名称（漢字）
        /// </summary>
        public string NewPrefectureAdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 新市区町村名称（漢字）
        /// </summary>
        public string NewMunicipalityAdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 新大字名称（漢字）
        /// </summary>
        public string NewOoazAdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 新小字名称（漢字）
        /// </summary>
        public string NewKoazAdrNameKanji
        {
            get;
            set;
        }

        /// <summary>
        /// 新郡名称（全角カナ）
        /// </summary>
        public string NewPrefectureAdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 新市区町村名称（全角カナ）
        /// </summary>
        public string NewMunicipalityAdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 新大字名称（全角カナ）
        /// </summary>
        public string NewOoazAdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 新小字名称（全角カナ）
        /// </summary>
        public string NewKoazAdrNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 郵便番号（aaa-bbbb）
        /// </summary>
        public string TelNo
        {
            get;
            set;
        }

        /// <summary>
        /// 旧市区町村コード
        /// </summary>
        public string OldAdminCode
        {
            get;
            set;
        }

        /// <summary>
        /// 新市区町村コード
        /// </summary>
        public string NewAdminCode
        {
            get;
            set;
        }

        /// <summary>
        /// マッピング関係
        /// </summary>
        public string MappingRelation
        {
            get;
            set;
        }

        /// <summary>
        /// 旧住所コード（aabbb-cccc-ddd）
        /// ※大字コード：10 進表記
        /// </summary>
        public string OldAdrCodeNum
        {
            get;
            set;
        }

        /// <summary>
        /// 新住所コード（aabbb-cccc-ddd）
        /// ※大字コード：10 進表記
        /// </summary>
        public string NewAdrCodeNum
        {
            get;
            set;
        }

        /// <summary>
        /// 地番リスト（フォーマット例：1,2,3,4,5,6..）
        /// </summary>
        public List<string> AreaCodeList
        {
            get
            {
                if (this._areaCodeList == null)
                {
                    List<string> codeList = new List<string>();

                    if (!string.IsNullOrWhiteSpace(this.AreaCode))
                    {
                        if (this.AreaCode.IndexOf(',') >= 0)
                        {
                            string[] codeArray = this.AreaCode.Split(',');

                            foreach (string codeItem in codeArray)
                            {
                                if (codeItem.IndexOf('～') < 0)
                                {
                                    codeList.Add(codeItem);
                                }
                                else
                                {
                                    string[] codeItemChildArray = codeItem.Split('～');

                                    int startCode = Convert.ToInt32(codeItemChildArray[0]);

                                    int endCode = Convert.ToInt32(codeItemChildArray[1]);

                                    for (int i = startCode; i <= endCode; i++)
                                    {
                                        codeList.Add(i.ToString());
                                    }
                                }
                            }
                        }
                        else if (this.AreaCode.IndexOf('～') > 0)
                        {
                            string[] codeArray = this.AreaCode.Split('～');

                            int startCode = Convert.ToInt32(codeArray[0]);

                            int endCode = Convert.ToInt32(codeArray[1]);

                            for (int i = startCode; i <= endCode; i++)
                            {
                                codeList.Add(i.ToString());
                            }
                        }
                        else
                        {
                            codeList.Add(this.AreaCode.Trim());
                        }

                        var orderbyCode = from orderCode in codeList
                                          orderby orderCode
                                          select orderCode;

                        codeList = orderbyCode.ToList();
                    }

                    this._areaCodeList = codeList;
                }

                return this._areaCodeList;
            }
        }

        /// <summary>
        /// Objectと比較する
        /// </summary>
        /// <param name="obj">比較対象</param>
        /// <returns>比較結果</returns>
        public int CompareTo(object obj)
        {
            // nullより大きい
            if (obj == null)
            {
                return 1;
            }

            // 違う型とは比較できない
            if (this.GetType() != obj.GetType())
            {
                throw new ArgumentException("別の型とは比較できません。", "obj");
            }

            return this.CompareTo(obj as NewOldAreaMappingData);
        }

        /// <summary>
        /// NewOldAreaMappingDataと比較する
        /// </summary>
        /// <param name="other">比較対象</param>
        /// <returns>比較結果</returns>
        public int CompareTo(NewOldAreaMappingData other)
        {
            int result = 0;

            if (this.NewAdrCode.Equals(other.NewAdrCode))
            {
                result = 1;
            }
            else
            {
                result = -1;
            }

            return result;
        }
    }
}

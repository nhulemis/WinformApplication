﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 差分住所データファイル
    /// </summary>
    public class DiffAdrDataListInputListData
    {
        /// <summary>
        /// 差分情報（削除、追加、更新）
        /// </summary>
        public int DiffType
        {
            get;
            set;
        }

        /// <summary>
        /// 都道府県コード
        /// </summary>
        public int ProvinceCode
        {
            get;
            set;
        }

        /// <summary>
        /// 市区町村コード
        /// </summary>
        public int CityCode
        {
            get;
            set;
        }

        /// <summary>
        /// 大字コード(4桁の数値)
        /// </summary>
        public int OazaCode
        {
            get;
            set;
        }

        /// <summary>
        /// 小字コード
        /// </summary>
        public int SectionCode
        {
            get;
            set;
        }

        /// <summary>
        /// 街区コード
        /// </summary>
        public int GaikuCode
        {
            get;
            set;
        }

        /// <summary>
        /// 都道府県名称
        /// </summary>
        public string ProvinceName
        {
            get;
            set;
        }

        /// <summary>
        /// 市区町村名称
        /// </summary>
        public string CityName
        {
            get;
            set;
        }

        /// <summary>
        /// 大字・町名称
        /// </summary>
        public string OazaName
        {
            get;
            set;
        }

        /// <summary>
        /// 字・丁目名称
        /// </summary>
        public string SectionName
        {
            get;
            set;
        }

        /// <summary>
        /// 市区町村名称読み
        /// </summary>
        public string CityNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 大字・町名称読み
        /// </summary>
        public string OazaNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 字・丁目名称読み
        /// </summary>
        public string SectionNameKana
        {
            get;
            set;
        }

        /// <summary>
        /// 地番・住居番号
        /// </summary>
        public int LotOrHouseNo
        {
            get;
            set;
        }

        /// <summary>
        /// 枝番
        /// </summary>
        public int SuffixNo
        {
            get;
            set;
        }

        /// <summary>
        /// 住所座標　経度
        /// </summary>
        public long Longitude
        {
            get;
            set;
        }

        /// <summary>
        /// 住所座標　緯度
        /// </summary>
        public long Latitude
        {
            get;
            set;
        }
    }
}

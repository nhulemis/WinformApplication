﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 自動継承条件ファイル
    /// </summary>
    public class AutoMatchPatternData
    {
        /// <summary>
        /// 条件種別
        /// </summary>
        private string _condCatalog;

        /// <summary>
        /// 適用フィールド
        /// </summary>
        private int _field;

        /// <summary>
        /// 特殊条件
        /// </summary>
        private int _specialCond;

        /// <summary>
        /// 文字列1のリスト（全角文字列）
        /// </summary>
        private List<string> _baseList;

        /// <summary>
        /// 文字列2のリスト（文字列１と一致と判定する全角文字列）
        /// </summary>
        private List<string> _sameList;

        /// <summary>
        /// 条件種別
        /// </summary>
        public string CondCatalog
        {
            get { return this._condCatalog; }
            set { this._condCatalog = value; }
        }

        /// <summary>
        /// 適用フィールド
        /// </summary>
        public int Field
        {
            get { return this._field; }
            set { this._field = value; }
        }

        /// <summary>
        /// 特殊条件
        /// </summary>
        public int SpecialCond
        {
            get { return this._specialCond; }
            set { this._specialCond = value; }
        }

        /// <summary>
        /// 文字列1
        /// </summary>
        public List<string> BaseList
        {
            get { return this._baseList; }
            set { this._baseList = value; }
        }

        /// <summary>
        /// 文字列2
        /// </summary>
        public List<string> SameList
        {
            get { return this._sameList; }
            set { this._sameList = value; }
        }
    }
}

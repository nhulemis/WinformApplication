﻿namespace CREO.Fluere.Biz.FileOperators.Data
{
    /// <summary>
    /// 対象ジャンルリスト
    /// </summary>
    public class TargetGenreData
    {
        /// <summary>
        /// 親ジャンルコード
        /// </summary>
        private readonly ushort parentGnrCode;

        /// <summary>
        /// 子ジャンル範囲(開始)
        /// </summary>
        private readonly ushort childGnrCodeStart;

        /// <summary>
        /// 子ジャンル範囲(終了)
        /// </summary>
        private readonly ushort childGnrCodeEnd;

        /// <summary>
        /// コンストラクタ
        /// </summary>
        /// <param name="pGnrCode">親ジャンルコード</param>
        /// <param name="cGnrCodeStart">子ジャンル範囲(開始)</param>
        /// <param name="cGnrCodeEnd">子ジャンル範囲(終了)</param>
        public TargetGenreData(ushort pGnrCode, ushort cGnrCodeStart, ushort cGnrCodeEnd)
        {
            this.parentGnrCode = pGnrCode;
            this.childGnrCodeStart = cGnrCodeStart;
            this.childGnrCodeEnd = cGnrCodeEnd;
        }

        /// <summary>
        /// 親ジャンルコードを取得します。
        /// </summary>
        public ushort ParentGnrCode
        {
            get
            {
                return this.parentGnrCode;
            }
        }

        /// <summary>
        /// 子ジャンル範囲(開始)を取得します。
        /// </summary>
        public ushort ChildGnrCodeStart
        {
            get
            {
                return this.childGnrCodeStart;
            }
        }

        /// <summary>
        /// 子ジャンル範囲(終了)を取得します。
        /// </summary>
        public ushort ChildGnrCodeEnd
        {
            get
            {
                return this.childGnrCodeEnd;
            }
        }
    }
}
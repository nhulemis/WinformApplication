﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// マッチング結果ファイル
    /// </summary>
    public class MatchingResultsFileManager
    {
        #region マッチング結果ファイル作成
        /// <summary>
        /// マッチング結果ファイル作成
        /// </summary>
        /// <param name="filePath">ファイルパス</param>
        /// <param name="formatFilePath">フォーマットファイルパス</param>
        /// <param name="matchingResultsDataList">マッチング結果リスト</param>
        public static void WriteMatchingResultsToDoFile(
            string filePath,
            string formatFilePath,
            List<MatchingResultsData> matchingResultsDataList)
        {
            XElement xmlDef = XElement.Load(formatFilePath);

            // Tsvファイル作成
            FileStream fstream = null;
            FileParser fp = null;
            try
            {
                fstream = new FileStream(filePath, FileMode.OpenOrCreate, FileAccess.Write);
                fp = new FileParser(fstream, xmlDef);

                foreach (
                    MatchingResultsData matchingResults in matchingResultsDataList)
                {
                    fp.AddRecord();

                    #region 交差点目印
                    // 2次メッシュコード
                    if (string.IsNullOrEmpty(matchingResults.MeshCode))
                    {
                        fp["MeshCode"] = string.Empty;
                    }
                    else
                    {
                        fp["MeshCode"] = matchingResults.MeshCode;
                    }

                    // 交差点データ番号
                    if (string.IsNullOrEmpty(matchingResults.CrsDataNumber))
                    {
                        fp["CrsDataNumber"] = string.Empty;
                    }
                    else
                    {
                        fp["CrsDataNumber"] = matchingResults.CrsDataNumber;
                    }

                    // 目印連番
                    if (string.IsNullOrEmpty(matchingResults.Crs_MarkSpate))
                    {
                        fp["Crs_MarkSpate"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_MarkSpate"] = matchingResults.Crs_MarkSpate;
                    }

                    // 目印コード
                    if (string.IsNullOrEmpty(matchingResults.Crs_MarkCode))
                    {
                        fp["Crs_MarkCode"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_MarkCode"] = matchingResults.Crs_MarkCode;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(matchingResults.Crs_KANAName))
                    {
                        fp["Crs_KANAName"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_KANAName"] = matchingResults.Crs_KANAName;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(matchingResults.Crs_KanJiNames))
                    {
                        fp["Crs_KanJiNames"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_KanJiNames"] = matchingResults.Crs_KanJiNames;
                    }

                    // 経度
                    if (string.IsNullOrEmpty(matchingResults.Crs_Longitude))
                    {
                        fp["Crs_Longitude"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_Longitude"] = matchingResults.Crs_Longitude;
                    }

                    // 緯度
                    if (string.IsNullOrEmpty(matchingResults.Crs_Latitude))
                    {
                        fp["Crs_Latitude"] = string.Empty;
                    }
                    else
                    {
                        fp["Crs_Latitude"] = matchingResults.Crs_Latitude;
                    }

                    // 交差点目印のOID
                    if (string.IsNullOrEmpty(matchingResults.CrsMarkOID))
                    {
                        fp["CrsMarkOID"] = string.Empty;
                    }
                    else
                    {
                        fp["CrsMarkOID"] = matchingResults.CrsMarkOID;
                    }

                    #endregion

                    #region タウン物件の情報

                    // OID
                    if (string.IsNullOrEmpty(matchingResults.STwn_STwnPOIOID))
                    {
                        fp["STwn_STwnPOIOID"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_STwnPOIOID"] = matchingResults.STwn_STwnPOIOID;
                    }

                    // 市外局番
                    if (string.IsNullOrEmpty(matchingResults.STwn_AreaNo))
                    {
                        fp["STwn_AreaNo"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_AreaNo"] = matchingResults.STwn_AreaNo;
                    }

                    // 電話番号
                    if (string.IsNullOrEmpty(matchingResults.STwn_TelNumber))
                    {
                        fp["STwn_TelNumber"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_TelNumber"] = matchingResults.STwn_TelNumber;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(matchingResults.STwn_KANAName_1))
                    {
                        fp["STwn_KANAName_1"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_KANAName_1"] = matchingResults.STwn_KANAName_1;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(matchingResults.STwn_KanJiNames_1))
                    {
                        fp["STwn_KanJiNames_1"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_KanJiNames_1"] = matchingResults.STwn_KanJiNames_1;
                    }

                    // 基本分類コード
                    if (string.IsNullOrEmpty(matchingResults.STwn_GnrTwnCode))
                    {
                        fp["STwn_GnrTwnCode"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_GnrTwnCode"] = matchingResults.STwn_GnrTwnCode;
                    }

                    // 基本分類名
                    if (string.IsNullOrEmpty(matchingResults.STwn_GnrTwnName))
                    {
                        fp["STwn_GnrTwnName"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_GnrTwnName"] = matchingResults.STwn_GnrTwnName;
                    }

                    // NTT分類コード
                    if (string.IsNullOrEmpty(matchingResults.STwn_NTTCode))
                    {
                        fp["STwn_NTTCode"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_NTTCode"] = matchingResults.STwn_NTTCode;
                    }

                    // NTT分類名
                    if (string.IsNullOrEmpty(matchingResults.STwn_NTTName))
                    {
                        fp["STwn_NTTName"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_NTTName"] = matchingResults.STwn_NTTName;
                    }

                    // 目印コード
                    if (string.IsNullOrEmpty(matchingResults.STwn_MarkCode))
                    {
                        fp["STwn_MarkCode"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_MarkCode"] = matchingResults.STwn_MarkCode;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(matchingResults.STwn_KANAName_2))
                    {
                        fp["STwn_KANAName_2"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_KANAName_2"] = matchingResults.STwn_KANAName_2;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(matchingResults.STwn_KanJiNames_2))
                    {
                        fp["STwn_KanJiNames_2"] = string.Empty;
                    }
                    else
                    {
                        fp["STwn_KanJiNames_2"] = matchingResults.STwn_KanJiNames_2;
                    }

                    #endregion

                    #region 施設物件

                    // OID
                    if (string.IsNullOrEmpty(matchingResults.SPOI_SPOIFacilityOID))
                    {
                        fp["SPOI_SPOIFacilityOID"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_SPOIFacilityOID"] = matchingResults.SPOI_SPOIFacilityOID;
                    }

                    // 電話番号
                    if (string.IsNullOrEmpty(matchingResults.SPOI_TelNumber))
                    {
                        fp["SPOI_TelNumber"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_TelNumber"] = matchingResults.SPOI_TelNumber;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(matchingResults.SPOI_KANAName))
                    {
                        fp["SPOI_KANAName"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_KANAName"] = matchingResults.SPOI_KANAName;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(matchingResults.SPOI_KanJiNames))
                    {
                        fp["SPOI_KanJiNames"] = string.Empty;
                    }
                    else
                    {
                        fp["SPOI_KanJiNames"] = matchingResults.SPOI_KanJiNames;
                    }

                    #endregion

                    #region 物件ジャンル

                    // OID
                    if (string.IsNullOrEmpty(matchingResults.Gnr_GnrTwnOID))
                    {
                        fp["Gnr_GnrTwnOID"] = string.Empty;
                    }
                    else
                    {
                        fp["Gnr_GnrTwnOID"] = matchingResults.Gnr_GnrTwnOID;
                    }

                    // カナ名称
                    if (string.IsNullOrEmpty(matchingResults.Gnr_KANAName))
                    {
                        fp["Gnr_KANAName"] = string.Empty;
                    }
                    else
                    {
                        fp["Gnr_KANAName"] = matchingResults.Gnr_KANAName;
                    }

                    // 漢字名称
                    if (string.IsNullOrEmpty(matchingResults.Gnr_KanJiNames))
                    {
                        fp["Gnr_KanJiNames"] = string.Empty;
                    }
                    else
                    {
                        fp["Gnr_KanJiNames"] = matchingResults.Gnr_KanJiNames;
                    }

                    #endregion

                    // ファイルパーサーにアップデート
                    fp.Update();
                }
            }
            catch (Exception)
            {
                // 出力ファイルが作成することが出来ない場合
                string msgId = UF_Fluere_MsgId.MSGID_UF10000209;
                throw new BusinessLogicException(msgId, new string[] { filePath });
            }
            finally
            {
                try
                {
                    if (fp != null)
                    {
                        fp.Dispose();
                    }
                }
                finally
                {
                    fp = null;
                }

                try
                {
                    if (fstream != null)
                    {
                        fstream.Dispose();
                    }
                }
                finally
                {
                    fstream = null;
                }
            }
        }
        #endregion
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using CREO.Fluere.Biz.Constants;
using CREO.Fluere.Biz.FileOperators.Data;
using CREO.FW.ExceptionHandling;
using CREO.FW.Parser;

namespace CREO.Fluere.Biz.FileOperators
{
    /// <summary>
    /// 新旧対応表ファイル（カナ・地番有り）
    /// </summary>
    public class NewOldAreaMappingFileManager
    {
        #region 新旧対応表ファイルの読込
        /// <summary>
        /// 新旧対応表ファイルの読込
        /// </summary>
        /// <param name="file">新旧対応表ファイル</param>
        /// <returns>新旧対応表データ</returns>
        public static List<NewOldAreaMappingData> ReadNewOldAreaFile(string file)
        {
            List<NewOldAreaMappingData> dataList = new List<NewOldAreaMappingData>();

            string formatFilePath = ConfigFileInfo.NewOldAreaMappingDataFile;

            // Tsvファイル作成
            FileStream fs = null;
            FileParser fp = null;

            try
            {
                XElement xmlDef = XElement.Load(formatFilePath);

                // FileParserで直接に項目で取得する
                fs = new FileStream(file, FileMode.Open, FileAccess.Read);
                fp = new FileParser(fs, xmlDef);

                while (fp.NextRecord())
                {
                    NewOldAreaMappingData data = new NewOldAreaMappingData();

                    // 旧住所コード
                    data.OldAdrCode = fp["OldAdrCode"].ToString();

                    // 旧郡名称（漢字）
                    data.OldPrefectureAdrNameKanji = fp["OldPrefectureAdrNameKanji"].ToString();

                    // 旧市区町村名称（漢字）
                    data.OldMunicipalityAdrNameKanji = fp["OldMunicipalityAdrNameKanji"].ToString();

                    // 旧大字名称（漢字）
                    data.OldOoazAdrNameKanji = fp["OldOoazAdrNameKanji"].ToString();

                    // 旧小字名称（漢字）
                    data.OldKoazAdrNameKanji = fp["OldKoazAdrNameKanji"].ToString();

                    // 旧郡名称（全角カナ）
                    data.OldPrefectureAdrNameKana = fp["OldPrefectureAdrNameKana"].ToString();

                    // 旧市区町村名称（全角カナ）
                    data.OldMunicipalityAdrNameKana = fp["OldMunicipalityAdrNameKana"].ToString();

                    // 旧大字名称（全角カナ）
                    data.OldOoazAdrNameKana = fp["OldOoazAdrNameKana"].ToString();

                    // 旧小字名称（全角カナ）
                    data.OldKoazAdrNameKana = fp["OldKoazAdrNameKana"].ToString();

                    // 地番（フォーマット例：102～109,111～120,201）
                    data.AreaCode = fp["AreaCode"].ToString();

                    // 新住所コード
                    data.NewAdrCode = fp["NewAdrCode"].ToString();

                    // 新郡名称（漢字）
                    data.NewPrefectureAdrNameKanji = fp["NewPrefectureAdrNameKanji"].ToString();

                    // 新市区町村名称（漢字）
                    data.NewMunicipalityAdrNameKanji = fp["NewMunicipalityAdrNameKanji"].ToString();

                    // 新大字名称（漢字）
                    data.NewOoazAdrNameKanji = fp["NewOoazAdrNameKanji"].ToString();

                    // 新小字名称（漢字）
                    data.NewKoazAdrNameKanji = fp["NewKoazAdrNameKanji"].ToString();

                    // 新郡名称（全角カナ）
                    data.NewPrefectureAdrNameKana = fp["NewPrefectureAdrNameKana"].ToString();

                    // 新市区町村名称（全角カナ）
                    data.NewMunicipalityAdrNameKana = fp["NewMunicipalityAdrNameKana"].ToString();

                    // 新大字名称（全角カナ）
                    data.NewOoazAdrNameKana = fp["NewOoazAdrNameKana"].ToString();

                    // 新小字名称（全角カナ）
                    data.NewKoazAdrNameKana = fp["NewKoazAdrNameKana"].ToString();

                    // 郵便番号（aaa-bbbb）
                    data.TelNo = fp["TelNo"].ToString();

                    if (data.OldAdrCode.Length >= 5)
                    {
                        data.OldAdminCode = data.OldAdrCode.Substring(0, 5);
                    }

                    if (data.NewAdrCode.Length >= 5)
                    {
                        data.NewAdminCode = data.NewAdrCode.Substring(0, 5);
                    }

                    if (data.OldAdrCode == data.NewAdrCode)
                    {
                        string[] param = new string[] { file, data.OldAdrCode };
                        throw new BusinessLogicException(UF_Fluere_MsgId.MSGID_UF40002026, param);
                    }

                    dataList.Add(data);
                }
            }
            catch (FrameworkException fwEx)
            {
                throw fwEx;
            }
            catch (BusinessLogicException buEx)
            {
                throw buEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (fp != null)
                {
                    fp.Dispose();
                }

                fp = null;

                if (fs != null)
                {
                    fs.Dispose();
                }

                fs = null;
            }

            return dataList;
        }
        #endregion
    }
}

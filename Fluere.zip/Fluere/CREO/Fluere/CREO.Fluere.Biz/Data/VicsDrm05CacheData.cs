﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Data
{
    /// <summary>
    /// VicsDrmCacheData
    /// </summary>
    public class VicsDrmCacheData
    {
        /// <summary>
        /// 2次メッシュタイプ
        /// </summary>
        public int MeshCode { get; set; }

        /// <summary>
        /// 前回読み出し時間
        /// </summary>
        public long LastTime { get; set; }

        /// <summary>
        /// メモリの大小
        /// </summary>
        public double Size { get; set; }
    }
}

﻿using System.Collections.Generic;
using System.Linq;

namespace CREO.Fluere.Biz.Data
{
    /// <summary>
    /// DRM道路結果リスト
    /// </summary>
    public class DRMRoadData
    {
        /// <summary>
        /// コンストラクタ
        /// </summary>
        public DRMRoadData()
        {
            RoadInfoByVicsMeshCode = new Dictionary<int, RoadInfo>();
        }

        /// <summary>
        /// VICS方向
        /// </summary>
        public byte VicsDirect { get; set; }

        /// <summary>
        /// DRM道路のノード番号
        /// </summary>
        public string DRMRoadNodeNo { get; set; }

        /// <summary>
        /// 道路情報（キー：予約VICS区間/VICS区間の2次メッシュコード）
        /// </summary>
        public Dictionary<int, RoadInfo> RoadInfoByVicsMeshCode { get; set; }

        /// <summary>
        /// 道路情報クラス
        /// </summary>
        /// <remarks>2次メッシュコードをキーとして管理する場合はこちらに属性を定義</remarks>
        public class RoadInfo
        {
            /// <summary>
            /// コンストラクタ
            /// </summary>
            /// <param name="basicRoadNodeNo">DRM基本道路のノード番号</param>
            /// <param name="sLimitCode">規制速度コード</param>
            /// <param name="exRoadTypCode">自動車専用道路コード</param>
            /// <param name="roadLengList">DRM毎道路の距離リスト</param>
            public RoadInfo(string basicRoadNodeNo, byte? sLimitCode, byte? exRoadTypCode, List<long> roadLengList)
            {
                DRMBasicRoadNodeNo = basicRoadNodeNo;
                SpeedLimitCode = sLimitCode;
                ExclusiveRoadTypCode = exRoadTypCode;
                RoadLengthList = roadLengList ?? new List<long>();
            }

            /// <summary>
            /// DRM基本道路のノード番号
            /// </summary>
            public string DRMBasicRoadNodeNo { get; set; }

            /// <summary>
            /// DRM道路の規制速度コード
            /// </summary>
            public byte? SpeedLimitCode { get; private set; }

            /// <summary>
            /// DRM道路の自動車専用道路コード
            /// </summary>
            public byte? ExclusiveRoadTypCode { get; private set; }

            /// <summary>
            /// DRM毎道路の距離リスト（cm単位）
            /// </summary>
            public List<long> RoadLengthList { get; private set; }

            /// <summary>
            /// DRM道路の距離（cm単位）
            /// </summary>
            public long RoadLength
            {
                get
                {
                    return RoadLengthList.Sum();
                }
            }
        }
    }
}

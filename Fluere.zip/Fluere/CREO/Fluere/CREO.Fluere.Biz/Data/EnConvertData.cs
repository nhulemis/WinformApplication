﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Data
{
    /// <summary>
    /// 英字変換情報
    /// </summary>
    public class EnConvertData
    {
        /// <summary>
        /// 漢字名称
        /// </summary>
        public string KanjiName { get; set; }

        /// <summary>
        /// カナ名称
        /// </summary>
        public string KanaName { get; set; }

        /// <summary>
        /// 英字
        /// </summary>
        public string EnName { get; set; }

        /// <summary>
        /// 括弧後大文字フラグ
        /// </summary>
        public bool UpperFlag { get; set; }
    }
}

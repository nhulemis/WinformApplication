﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CREO.Fluere.Biz.Data
{
    /// <summary>
    /// Mecabの単語分割した結果
    /// </summary>
    public class MecabUnitData
    {
        /// <summary>
        /// カナ単語
        /// カナ名称の分割結果
        /// </summary>
        public string KanaWord { get; set; }

        /// <summary>
        /// 読み
        /// Mecabの単語分割した結果の読み
        /// </summary>
        public string Read { get; set; }

        /// <summary>
        /// 発音
        /// Mecabの単語分割した結果の発音
        /// </summary>
        public string Pronounce { get; set; }
    }
}

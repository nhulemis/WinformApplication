﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.08.08 TMI K.Matsui

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Lifetime;
using System.Threading;

using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.HostingServices
{
    /// <summary>
    /// ホスティングサービスクラスです。
    /// </summary>
    internal sealed class HostingService : MarshalByRefObject, IHostingService
    {
        /// <summary>
        /// リモート参照のためのサロゲータです。
        /// </summary>
        private static readonly RemotingProxyTypeSurrogator Surrogator = new RemotingProxyTypeSurrogator();

        /// <summary>
        /// 終了を検出する手動リセットイベントです。
        /// </summary>
        private readonly ManualResetEvent _abort = new ManualResetEvent(false);

        /// <summary>
        /// パスとアセンブリの辞書です。
        /// </summary>
        private readonly Dictionary<string, Assembly> _assemblies = new Dictionary<string, Assembly>();

        /// <summary>
        /// 型名とTypeの辞書です。
        /// </summary>
        private readonly Dictionary<string, Type> _types = new Dictionary<string, Type>();

        /// <summary>
        /// GUIDとインスタンスの辞書です。
        /// </summary>
        private readonly Dictionary<Guid, object> _instances = new Dictionary<Guid, object>();

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public HostingService()
        {
            this._assemblies.Add(new Uri(typeof(object).Assembly.CodeBase).LocalPath, typeof(object).Assembly);
            this._assemblies.Add(new Uri(typeof(Uri).Assembly.CodeBase).LocalPath, typeof(Uri).Assembly);
            this._assemblies.Add(new Uri(typeof(ReaderWriterLockSlim).Assembly.CodeBase).LocalPath, typeof(ReaderWriterLockSlim).Assembly);
        }

        /// <summary>
        /// ファイナライザです。
        /// </summary>
        ~HostingService()
        {
            this.Dispose();
        }

        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        /// <remarks>ホスティングサービスを終了させます。</remarks>
        public void Dispose()
        {
            this._abort.Set();
        }

        /// <summary>
        /// リモーティングオブジェクトの生存期間を定義するオブジェクトを返します。
        /// </summary>
        /// <returns>インスタンス</returns>
        public override object InitializeLifetimeService()
        {
            ILease lease = (ILease)base.InitializeLifetimeService();
            if (lease.CurrentState == LeaseState.Initial)
            {
                // ほぼ無期限
                lease.InitialLeaseTime = TimeSpan.FromDays(30);
                lease.SponsorshipTimeout = TimeSpan.FromDays(30);
                lease.RenewOnCallTime = TimeSpan.FromDays(30);
            }

            return lease;
        }

        /// <summary>
        /// ホスティングサービスが終了するのを待ちます。
        /// </summary>
        public void Join()
        {
            this._abort.WaitOne();
        }

        /// <summary>
        /// 指定された厳密名のアセンブリを、ホスト内のアプリケーションドメインにロードします。
        /// </summary>
        /// <param name="assemblyName">厳密名を持つアセンブリ名</param>
        public void Load(string assemblyName)
        {
            lock (this._assemblies)
            {
                var assembly = Assembly.Load(assemblyName);
                var path = new Uri(assembly.CodeBase).LocalPath;

                if (this._assemblies.ContainsKey(path) == false)
                {
                    this._assemblies.Add(path, assembly);
                }
            }
        }

        /// <summary>
        /// 指定されたパスのアセンブリを、ホスト内のアプリケーションドメインにロードします。
        /// </summary>
        /// <param name="assemblyPath">アセンブリのローカルパス</param>
        public void LoadFrom(string assemblyPath)
        {
            lock (this._assemblies)
            {
                var assembly = Assembly.LoadFrom(assemblyPath);
                var path = new Uri(assembly.CodeBase).LocalPath;

                if (this._assemblies.ContainsKey(path) == false)
                {
                    this._assemblies.Add(path, assembly);
                }
            }
        }

        /// <summary>
        /// 指定された型名に対応するメタデータ情報を取得します。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <returns>メタデータ情報</returns>
        private Type InternalGetType(string typeName)
        {
            lock (this._types)
            {
                Type type;
                if (this._types.TryGetValue(typeName, out type) == false)
                {
                    lock (this._assemblies)
                    {
                        type =
                            (from assembly in this._assemblies.Values.AsParallel()
                             let t = assembly.GetType(typeName)
                             where t != null
                             select t).FirstOrDefault();
                    }

                    if (type == null)
                    {
                        throw new TypeLoadException(typeName);
                    }

                    if (this._types.ContainsKey(type.FullName) == false)
                    {
                        this._types.Add(type.FullName, type);
                    }
                }

                return type;
            }
        }

        /// <summary>
        /// ロード済のアセンブリ内の型に定義されている、スタティックメソッドを呼び出します。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <param name="staticMethodName">スタティックメソッド名</param>
        /// <param name="args">引数群</param>
        /// <returns>戻り値</returns>
        public object InvokeStatic(string typeName, string staticMethodName, params object[] args)
        {
            var type = this.InternalGetType(typeName);

            return type.InvokeMember(
                staticMethodName,
                BindingFlags.Public | BindingFlags.Static | BindingFlags.DeclaredOnly,
                null,
                null,
                args);
        }

        /// <summary>
        /// ホスト内のアプリケーションドメインに、インスタンスを生成します。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <param name="args">コンストラクタの引数群</param>
        /// <returns>インスタンスを識別するGUID</returns>
        public Guid CreateInstance(string typeName, params object[] args)
        {
            var type = this.InternalGetType(typeName);
            var instance = Activator.CreateInstance(type, args);

            Guid instanceGuid = Guid.NewGuid();
            lock (this._instances)
            {
                this._instances.Add(instanceGuid, instance);
            }

            return instanceGuid;
        }

        /// <summary>
        /// 指定されたインスタンスのメソッドを呼び出します。
        /// </summary>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        /// <param name="methodName">インスタンスメソッド名</param>
        /// <param name="args">引数群</param>
        /// <returns>戻り値</returns>
        public object Invoke(Guid instanceGuid, string methodName, params object[] args)
        {
            object instance;
            lock (this._instances)
            {
                instance = this._instances[instanceGuid];
            }

            var type = instance.GetType();
            return type.InvokeMember(methodName, BindingFlags.Public | BindingFlags.Instance, null, instance, args);
        }

        /// <summary>
        /// ホスト内のアプリケーションドメインから、インスタンスを削除します。
        /// </summary>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        public void DeleteInstance(Guid instanceGuid)
        {
            lock (this._instances)
            {
                var instance = this._instances[instanceGuid];

                var disposable = instance as IDisposable;
                if (disposable != null)
                {
                    disposable.Dispose();
                }

                this._instances.Remove(instanceGuid);
            }
        }

        /// <summary>
        /// リモーティングプロキシを生成します。
        /// </summary>
        /// <typeparam name="T">リモート参照を形成するインターフェイス</typeparam>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        /// <returns>リモート参照</returns>
        public T CreateRemotingProxy<T>(Guid instanceGuid)
            where T : class
        {
            if ((typeof(T).IsInterface == false) &&
                (typeof(MarshalByRefObject).IsAssignableFrom(typeof(T)) == false))
            {
                throw new InvalidOperationException();
            }

            object instance;
            lock (this._instances)
            {
                instance = this._instances[instanceGuid];
            }

            // チェック
            if ((instance is MarshalByRefObject) == false)
            {
                instance = TypeWrapper.GetWrapper(typeof(T), instance, Surrogator);
            }

            RemotingServices.Marshal((MarshalByRefObject)instance);

            return (T)instance;
        }
    }
}

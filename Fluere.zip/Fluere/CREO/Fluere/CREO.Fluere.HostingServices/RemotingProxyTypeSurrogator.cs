﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.08.08 TMI K.Matsui

using System;
using System.Runtime.Remoting.Lifetime;

using CREO.Fluere.Common.TypeServices;

namespace CREO.Fluere.Common.HostingServices
{
    /// <summary>
    /// ラッパークラスの動作に介入する実装です。
    /// </summary>
    internal sealed class RemotingProxyTypeSurrogator : DefaultSurrogator
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        public RemotingProxyTypeSurrogator()
        {
        }

        /// <summary>
        /// 対象のインスタンスの有効期間ポリシーを制御する、有効期間サービスオブジェクトを取得します。
        /// </summary>
        /// <param name="realObj">インスタンス</param>
        /// <returns>対象のインスタンスの有効期間ポリシーを制御するときに使用する、ILease 型のオブジェクト</returns>
        public override object InitializeLifetimeService(object realObj)
        {
            ILease lease = (ILease)base.InitializeLifetimeService(realObj);
            if (lease.CurrentState == LeaseState.Initial)
            {
                // ほぼ無期限
                lease.InitialLeaseTime = TimeSpan.FromDays(30);
                lease.SponsorshipTimeout = TimeSpan.FromDays(30);
                lease.RenewOnCallTime = TimeSpan.FromDays(30);
            }

            return lease;
        }
    }
}

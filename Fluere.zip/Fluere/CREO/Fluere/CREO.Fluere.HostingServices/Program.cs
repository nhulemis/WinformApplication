﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.08.08 TMI K.Matsui

using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Ipc;
using System.Threading;

namespace CREO.Fluere.Common.HostingServices
{
    /// <summary>
    /// ホストプロセスのメインコードです。
    /// </summary>
    public static class Program
    {
        /// <summary>
        /// MessageBox
        /// </summary>
        /// <param name="hWnd">hWnd</param>
        /// <param name="text">text</param>
        /// <param name="caption">caption</param>
        /// <param name="options">options</param>
        /// <returns>DialogResult</returns>
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern int MessageBox(IntPtr hWnd, string text, string caption, int options);

        /// <summary>
        /// GetCurrentProcessId
        /// </summary>
        /// <returns>ProcessID</returns>
        [DllImport("kernel32.dll")]
        private static extern int GetCurrentProcessId();

        /// <summary>
        /// 指定されたGUIDのIPC Channelで処理を実行します。
        /// </summary>
        /// <param name="guid">IPC ChannelのGUID</param>
        private static void Execute(Guid guid)
        {
            var channel = new IpcChannel(guid.ToString("D"));
            ChannelServices.RegisterChannel(channel, false);

            try
            {
                var hostingService = new HostingService();
                RemotingServices.Marshal(hostingService, "HostingService", typeof(IHostingService));

                try
                {
                    using (var ready = new EventWaitHandle(false, EventResetMode.ManualReset, guid.ToString()))
                    {
                        ready.Set();
                    }

                    hostingService.Join();
                }
                finally
                {
                    RemotingServices.Disconnect(hostingService);
                }
            }
            finally
            {
                ChannelServices.UnregisterChannel(channel);
            }
        }

        /// <summary>
        /// エントリポイントです。
        /// </summary>
        /// <param name="args">コマンドライン引数群</param>
        /// <returns>戻り値</returns>
        [MTAThread]
        public static int Main(string[] args)
        {
            try
            {
                if (args.Length == 0)
                {
                    throw new ArgumentException("usage: CREO.Fluere.HostingServices.exe <ipc guid>");
                }

                if ((args.Length >= 2) && (args[1].ToLower() == "/debug"))
                {
                    MessageBox(
                        IntPtr.Zero,
                        "Waiting for attach\r\nProcessID=" + GetCurrentProcessId(),
                        "CREO.Fluere.HostingServices [DEBUG]",
                        0x00000030);
                }

                var guid = new Guid(args[0]);

                Execute(guid);
            }
            catch (Exception ex)
            {
                Trace.WriteLine(ex.ToString());
                return Marshal.GetHRForException(ex);
            }
            finally
            {
                GC.Collect();
                GC.Collect();
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            return 0;
        }
    }
}

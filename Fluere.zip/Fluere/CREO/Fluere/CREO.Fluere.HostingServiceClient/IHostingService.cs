﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.08.08 TMI K.Matsui

using System;

namespace CREO.Fluere.Common.HostingServices
{
    /// <summary>
    /// アウトプロセスでフレームワークコードをホストするクライアント端点のインターフェイスです。
    /// </summary>
    public interface IHostingService : IDisposable
    {
        /// <summary>
        /// 指定された厳密名のアセンブリを、ホスト内のアプリケーションドメインにロードします。
        /// </summary>
        /// <param name="assemblyName">厳密名を持つアセンブリ名</param>
        void Load(string assemblyName);

        /// <summary>
        /// 指定されたパスのアセンブリを、ホスト内のアプリケーションドメインにロードします。
        /// </summary>
        /// <param name="assemblyPath">アセンブリのローカルパス</param>
        void LoadFrom(string assemblyPath);

        /// <summary>
        /// ロード済のアセンブリ内の型に定義されている、スタティックメソッドを呼び出します。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <param name="staticMethodName">スタティックメソッド名</param>
        /// <param name="args">引数群</param>
        /// <returns>戻り値</returns>
        object InvokeStatic(string typeName, string staticMethodName, params object[] args);

        /// <summary>
        /// ホスト内のアプリケーションドメインに、インスタンスを生成します。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <param name="args">コンストラクタの引数群</param>
        /// <returns>インスタンスを識別するGUID</returns>
        Guid CreateInstance(string typeName, params object[] args);

        /// <summary>
        /// 指定されたインスタンスのメソッドを呼び出します。
        /// </summary>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        /// <param name="methodName">インスタンスメソッド名</param>
        /// <param name="args">引数群</param>
        /// <returns>戻り値</returns>
        object Invoke(Guid instanceGuid, string methodName, params object[] args);

        /// <summary>
        /// ホスト内のアプリケーションドメインから、インスタンスを削除します。
        /// </summary>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        void DeleteInstance(Guid instanceGuid);

        /// <summary>
        /// リモーティングプロキシを生成します。
        /// </summary>
        /// <typeparam name="T">リモート参照を形成するインターフェイス</typeparam>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        /// <returns>リモート参照</returns>
        T CreateRemotingProxy<T>(Guid instanceGuid)
            where T : class;
    }
}

﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.08.08 TMI K.Matsui

using System;
using System.Threading;

using Microsoft.Win32.SafeHandles;

namespace CREO.Fluere.Common.HostingServices
{
    /// <summary>
    /// プロセスの待機ハンドルです。
    /// </summary>
    /// <remarks>このクラスは内部で使用します。</remarks>
    internal sealed class ProcessWaitHandle : WaitHandle
    {
        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="processHandle">プロセスハンドル</param>
        public ProcessWaitHandle(IntPtr processHandle)
        {
            this.SafeWaitHandle = new SafeWaitHandle(processHandle, false);
        }
    }
}

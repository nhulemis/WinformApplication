﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.08.08 TMI K.Matsui

using System;
using System.Diagnostics;

namespace CREO.Fluere.Common.HostingServices
{
    /// <summary>
    /// アウトプロセスでフレームワークコードをホストするクライアント端点のクラスです。
    /// </summary>
    /// <remarks>32ビットのレガシーコード等から、CREOフレームワークのコードを呼び出すためのプロキシ・スタブを提供します。
    /// 使用後はDisposeメソッドを呼び出して、ホストプロセスを終了させる必要があります。</remarks>
    public sealed class HostingServiceClient : IHostingService
    {
        /// <summary>
        /// ロックオブジェクトです。
        /// </summary>
        private static object _lockObject = new object();

        /// <summary>
        /// カウンタです。
        /// </summary>
        private static int _count = 0;

        /// <summary>
        /// HostingServiceHolderです。
        /// </summary>
        private static HostingServiceHolder _hostingService = null;

        /// <summary>
        /// 現在のHostingServiceHolderです。
        /// </summary>
        private HostingServiceHolder _currentService;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="isDebugging">デバッグ一時停止を行う場合はtrue</param>
        /// <remarks>ホスト処理可能にします。</remarks>
        public HostingServiceClient(bool isDebugging)
        {
            lock (_lockObject)
            {
                if (_count == 0)
                {
                    Debug.Assert(_hostingService == null, "_hostingService");

                    _hostingService = new HostingServiceHolder(isDebugging);
                }
                else
                {
                    Debug.Assert(_hostingService != null, "_hostingService");
                }

                _count++;

                this._currentService = _hostingService;
            }
        }

        /// <summary>
        /// ファイナライザです。
        /// </summary>
        ~HostingServiceClient()
        {
            this.Dispose();
        }

        /// <summary>
        /// ホスティングサービスを識別するGUIDを取得します。
        /// </summary>
        public Guid Guid
        {
            get
            {
                return this._currentService.Guid;
            }
        }

        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        /// <remarks>ホストプロセスを終了させます。</remarks>
        public void Dispose()
        {
            if (this._currentService != null)
            {
                lock (_lockObject)
                {
                    Debug.Assert(_count >= 1, "_count");
                    if (_count == 1)
                    {
                        _hostingService.Dispose();
                        _hostingService = null;
                    }

                    _count--;
                }

                this._currentService = null;
            }
        }

        /// <summary>
        /// 指定された厳密名のアセンブリを、ホスト内のアプリケーションドメインにロードします。
        /// </summary>
        /// <param name="assemblyName">厳密名を持つアセンブリ名</param>
        public void Load(string assemblyName)
        {
            this._currentService.Load(assemblyName);
        }

        /// <summary>
        /// 指定されたパスのアセンブリを、ホスト内のアプリケーションドメインにロードします。
        /// </summary>
        /// <param name="assemblyPath">アセンブリのローカルパス</param>
        public void LoadFrom(string assemblyPath)
        {
            this._currentService.LoadFrom(assemblyPath);
        }

        /// <summary>
        /// ロード済のアセンブリ内の型に定義されている、スタティックメソッドを呼び出します。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <param name="staticMethodName">スタティックメソッド名</param>
        /// <param name="args">引数群</param>
        /// <returns>戻り値</returns>
        public object InvokeStatic(string typeName, string staticMethodName, params object[] args)
        {
            return this._currentService.InvokeStatic(typeName, staticMethodName, args);
        }

        /// <summary>
        /// ホスト内のアプリケーションドメインに、インスタンスを生成します。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <param name="args">コンストラクタの引数群</param>
        /// <returns>インスタンスを識別するGUID</returns>
        public Guid CreateInstance(string typeName, params object[] args)
        {
            return this._currentService.CreateInstance(typeName, args);
        }

        /// <summary>
        /// 指定されたインスタンスのメソッドを呼び出します。
        /// </summary>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        /// <param name="methodName">インスタンスメソッド名</param>
        /// <param name="args">引数群</param>
        /// <returns>戻り値</returns>
        public object Invoke(Guid instanceGuid, string methodName, params object[] args)
        {
            return this._currentService.Invoke(instanceGuid, methodName, args);
        }

        /// <summary>
        /// ホスト内のアプリケーションドメインから、インスタンスを削除します。
        /// </summary>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        public void DeleteInstance(Guid instanceGuid)
        {
            this._currentService.DeleteInstance(instanceGuid);
        }

        /// <summary>
        /// リモーティングプロキシを生成します。
        /// </summary>
        /// <typeparam name="T">リモート参照を形成するインターフェイス</typeparam>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        /// <returns>リモート参照</returns>
        public T CreateRemotingProxy<T>(Guid instanceGuid)
            where T : class
        {
            return this._currentService.CreateRemotingProxy<T>(instanceGuid);
        }
    }
}

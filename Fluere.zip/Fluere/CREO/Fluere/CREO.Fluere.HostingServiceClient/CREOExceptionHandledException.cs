﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.10.04 TMI K.Matsui

using System;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Security;

namespace CREO.Fluere.Common.HostingServices
{
    /// <summary>
    /// CREO.FW.ExceptionHandling.CREOExceptionの情報を内包する例外クラスです。
    /// </summary>
    /// <remarks>ホストプロセスがCREO.FWLibをロード出来ない場合を想定した、CREO.FWLibに依存しない例外クラスです。</remarks>
    [Serializable]
    public sealed class CREOExceptionHandledException : Exception
    {
        /// <summary>
        /// スタックトレース
        /// </summary>
        private readonly string _stackTrace;

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="inner">CREOExceptionで表現される例外</param>
        public CREOExceptionHandledException(Exception inner)
            : base(inner.GetType().FullName + ": " + inner.Message)
        {
            this.HResult = Marshal.GetHRForException(inner);
            this.Source = inner.Source;
            this._stackTrace = inner.StackTrace;
        }

        /// <summary>
        /// 逆シリアル化コンストラクタです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecuritySafeCritical]
        private CREOExceptionHandledException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            this._stackTrace = info.GetString("stackTrace");
        }

        /// <summary>
        /// スタックトレースを取得します。
        /// </summary>
        public override string StackTrace
        {
            get
            {
                return "Server StackTrace:\r\n" + this._stackTrace +
                    "------------------------------\r\n" + base.StackTrace;
            }
        }

        /// <summary>
        /// シリアル化メソッドです。
        /// </summary>
        /// <param name="info">シリアル化情報</param>
        /// <param name="context">ストリームコンテキスト</param>
        [SecurityCritical]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("stackTrace", this._stackTrace);
        }
    }
}

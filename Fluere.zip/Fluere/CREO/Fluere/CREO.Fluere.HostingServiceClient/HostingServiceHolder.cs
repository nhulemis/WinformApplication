﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.09.03 TMI K.Matsui

using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.ConstrainedExecution;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Ipc;
using System.Threading;
using Microsoft.Win32.SafeHandles;

namespace CREO.Fluere.Common.HostingServices
{
    /// <summary>
    /// アウトプロセスでフレームワークコードをホストするクラスです。
    /// </summary>
    internal sealed class HostingServiceHolder : CriticalFinalizerObject, IHostingService
    {
        /// <summary>
        /// Job Guid
        /// </summary>
        private readonly Guid _jobGuid = Guid.NewGuid();

        /// <summary>
        /// IPC Channel Guid
        /// </summary>
        private readonly Guid _channelGuid = Guid.NewGuid();

        /// <summary>
        /// Job handle
        /// </summary>
        private SafeWaitHandle _job;

        /// <summary>
        /// Child process
        /// </summary>
        private Process _process;

        /// <summary>
        /// Host service reference
        /// </summary>
        private IHostingService _hostingService;

        /// <summary>
        /// タイプイニシャライザです。
        /// </summary>
        static HostingServiceHolder()
        {
            var channel = new IpcChannel();
            ChannelServices.RegisterChannel(channel, false);
        }

        /// <summary>
        /// コンストラクタです。
        /// </summary>
        /// <param name="isDebugging">デバッグ一時停止を行う場合はtrue</param>
        /// <remarks>ホストプロセスを生成し、ホスト処理可能にします。</remarks>
        public HostingServiceHolder(bool isDebugging)
        {
            IntPtr handle = NativeMethods.CreateJobObject(IntPtr.Zero, this._jobGuid.ToString("D"));
            if (handle == IntPtr.Zero)
            {
                Marshal.ThrowExceptionForHR(Marshal.GetLastWin32Error());
            }

            this._job = new SafeWaitHandle(handle, true);

            try
            {
                NativeMethods.JOBOBJECT_EXTENDED_LIMIT_INFORMATION extendedInfo =
                    new NativeMethods.JOBOBJECT_EXTENDED_LIMIT_INFORMATION();
                extendedInfo.BasicLimitInformation.LimitFlags = 0x2000;

                if (NativeMethods.SetInformationJobObject(
                    handle,
                    NativeMethods.JobObjectInfoType.ExtendedLimitInformation,
                    ref extendedInfo,
                    (uint)Marshal.SizeOf(extendedInfo)) == false)
                {
                    Marshal.ThrowExceptionForHR(Marshal.GetLastWin32Error());
                }

                using (var ready = new EventWaitHandle(false, EventResetMode.ManualReset, this._channelGuid.ToString("D")))
                {
                    var psi = new ProcessStartInfo();

                    psi.CreateNoWindow = true;
                    psi.ErrorDialog = false;
                    psi.RedirectStandardInput = false;
                    psi.RedirectStandardOutput = false;
                    psi.UseShellExecute = false;

                    if (isDebugging == true)
                    {
                        psi.Arguments = string.Format("{0:D} /debug", this._channelGuid);
                    }
                    else
                    {
                        psi.Arguments = this._channelGuid.ToString("D");
                    }

                    psi.FileName = Path.Combine(
                        Path.GetDirectoryName(
                        new Uri(this.GetType().Assembly.CodeBase).LocalPath),
                        "CREO.Fluere.HostingServices.exe");

                    this._process = Process.Start(psi);

                    if (NativeMethods.AssignProcessToJobObject(handle, this._process.Handle) == false)
                    {
                        Marshal.ThrowExceptionForHR(Marshal.GetLastWin32Error());
                    }

                    var processHandle = new ProcessWaitHandle(this._process.Handle);

                    var result = WaitHandle.WaitAny(new WaitHandle[] { processHandle, ready });
                    if (result == 0)
                    {
                        if (this._process.HasExited == true)
                        {
                            throw new InvalidOperationException(
                                string.Format(
                                "Abnormal termination executed host: ExitCode=0x{0:X8}",
                                this._process.ExitCode));
                        }
                        else
                        {
                            throw new InvalidOperationException("Abnormal termination executed host");
                        }
                    }

                    var uri = string.Format("ipc://{0:D}/HostingService", this._channelGuid);
                    this._hostingService = (IHostingService)Activator.GetObject(typeof(IHostingService), uri);

                    Debug.WriteLine(
                        "HostingServiceHolder created: ProcessID={0}, JobGuid={1:D}, ChannelGuid={2:D}",
                        this._process.Id,
                        this._jobGuid,
                        this._channelGuid);
                }
            }
            catch
            {
                this._job.Close();
                throw;
            }
        }

        /// <summary>
        /// デストラクタです。
        /// </summary>
        ~HostingServiceHolder()
        {
            this.Dispose();
        }

        /// <summary>
        /// ホスティングサービスを識別するGUIDを取得します。
        /// </summary>
        public Guid Guid
        {
            get
            {
                return this._jobGuid;
            }
        }

        /// <summary>
        /// Disposeメソッドです。
        /// </summary>
        /// <remarks>ホストプロセスを終了させます。</remarks>
        public void Dispose()
        {
            if (this._hostingService != null)
            {
                try
                {
                    this._hostingService.Dispose();
                }
                catch
                {
                }

                this._hostingService = null;
            }

            if (this._job.IsClosed == false)
            {
                this._job.Close();
            }

            if (this._process != null)
            {
                int id = this._process.Id;

                this._process.WaitForExit(1000);
                this._process.Dispose();
                this._process = null;

                Debug.WriteLine(
                    "HostingServiceHolder disposed: ProcessID={0}, JobGuid={1:D}, ChannelGuid={2:D}",
                    id,
                    this._jobGuid,
                    this._channelGuid);
            }
        }

        /// <summary>
        /// 指定された厳密名のアセンブリを、ホスト内のアプリケーションドメインにロードします。
        /// </summary>
        /// <param name="assemblyName">厳密名を持つアセンブリ名</param>
        public void Load(string assemblyName)
        {
            this._hostingService.Load(assemblyName);
        }

        /// <summary>
        /// 指定されたパスのアセンブリを、ホスト内のアプリケーションドメインにロードします。
        /// </summary>
        /// <param name="assemblyPath">アセンブリのローカルパス</param>
        public void LoadFrom(string assemblyPath)
        {
            this._hostingService.LoadFrom(assemblyPath);
        }

        /// <summary>
        /// ロード済のアセンブリ内の型に定義されている、スタティックメソッドを呼び出します。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <param name="staticMethodName">スタティックメソッド名</param>
        /// <param name="args">引数群</param>
        /// <returns>戻り値</returns>
        public object InvokeStatic(string typeName, string staticMethodName, params object[] args)
        {
            return this._hostingService.InvokeStatic(typeName, staticMethodName, args);
        }

        /// <summary>
        /// ホスト内のアプリケーションドメインに、インスタンスを生成します。
        /// </summary>
        /// <param name="typeName">型名</param>
        /// <param name="args">コンストラクタの引数群</param>
        /// <returns>インスタンスを識別するGUID</returns>
        public Guid CreateInstance(string typeName, params object[] args)
        {
            return this._hostingService.CreateInstance(typeName, args);
        }

        /// <summary>
        /// 指定されたインスタンスのメソッドを呼び出します。
        /// </summary>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        /// <param name="methodName">インスタンスメソッド名</param>
        /// <param name="args">引数群</param>
        /// <returns>戻り値</returns>
        public object Invoke(Guid instanceGuid, string methodName, params object[] args)
        {
            return this._hostingService.Invoke(instanceGuid, methodName, args);
        }

        /// <summary>
        /// ホスト内のアプリケーションドメインから、インスタンスを削除します。
        /// </summary>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        public void DeleteInstance(Guid instanceGuid)
        {
            this._hostingService.DeleteInstance(instanceGuid);
        }

        /// <summary>
        /// リモーティングプロキシを生成します。
        /// </summary>
        /// <typeparam name="T">リモート参照を形成するインターフェイス</typeparam>
        /// <param name="instanceGuid">インスタンスを識別するGUID</param>
        /// <returns>リモート参照</returns>
        public T CreateRemotingProxy<T>(Guid instanceGuid)
            where T : class
        {
            return this._hostingService.CreateRemotingProxy<T>(instanceGuid);
        }
    }
}

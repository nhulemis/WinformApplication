﻿////////////////////////////////////////////////////////////////////////
// This is part of CREO Fluere source codes.
// Copyright (c) 2012 TOYOTA MAPMASTER INC., All rights reserved.
////////////////////////////////////////////////////////////////////////
// Initial version: 2012.08.28 TMI K.Matsui

using System;
using System.Runtime.InteropServices;

namespace CREO.Fluere.Common.HostingServices
{
    /// <summary>
    /// API Wrapper
    /// </summary>
    internal static class NativeMethods
    {
        /// <summary>
        /// JobObjectInfoType
        /// </summary>
        public enum JobObjectInfoType
        {
            /// <summary>
            /// AssociateCompletionPortInformation
            /// </summary>
            AssociateCompletionPortInformation = 7,

            /// <summary>
            /// BasicLimitInformation
            /// </summary>
            BasicLimitInformation = 2,

            /// <summary>
            /// BasicUIRestrictions
            /// </summary>
            BasicUIRestrictions = 4,

            /// <summary>
            /// EndOfJobTimeInformation
            /// </summary>
            EndOfJobTimeInformation = 6,

            /// <summary>
            /// ExtendedLimitInformation
            /// </summary>
            ExtendedLimitInformation = 9,

            /// <summary>
            /// SecurityLimitInformation
            /// </summary>
            SecurityLimitInformation = 5,

            /// <summary>
            /// GroupInformation
            /// </summary>
            GroupInformation = 11
        }

        /// <summary>
        /// CreateJobObject
        /// </summary>
        /// <param name="securityAttributes">securityAttributes</param>
        /// <param name="jobName">jobName</param>
        /// <returns>Handle</returns>
        [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
        public static extern IntPtr CreateJobObject(IntPtr securityAttributes, string jobName);

        /// <summary>
        /// AssignProcessToJobObject
        /// </summary>
        /// <param name="job">job</param>
        /// <param name="process">process</param>
        /// <returns>Result</returns>
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);

        /// <summary>
        /// SetInformationJobObject
        /// </summary>
        /// <param name="job">job</param>
        /// <param name="infoType">infoType</param>
        /// <param name="jobObjectInfo">jobObjectInfo</param>
        /// <param name="cbJobObjectInfoLength">cbJobObjectInfoLength</param>
        /// <returns>Result</returns>
        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool SetInformationJobObject(IntPtr job,
            JobObjectInfoType infoType,
            [In] ref JOBOBJECT_EXTENDED_LIMIT_INFORMATION jobObjectInfo,
            uint cbJobObjectInfoLength);

        /// <summary>
        /// JOBOBJECT_BASIC_LIMIT_INFORMATION
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct JOBOBJECT_BASIC_LIMIT_INFORMATION
        {
            /// <summary>
            /// PerProcessUserTimeLimit
            /// </summary>
            public long PerProcessUserTimeLimit;

            /// <summary>
            /// PerJobUserTimeLimit
            /// </summary>
            public long PerJobUserTimeLimit;

            /// <summary>
            /// LimitFlags
            /// </summary>
            public short LimitFlags;

            /// <summary>
            /// MinimumWorkingSetSize
            /// </summary>
            public uint MinimumWorkingSetSize;

            /// <summary>
            /// MaximumWorkingSetSize
            /// </summary>
            public uint MaximumWorkingSetSize;

            /// <summary>
            /// ActiveProcessLimit
            /// </summary>
            public short ActiveProcessLimit;

            /// <summary>
            /// Affinity
            /// </summary>
            public long Affinity;

            /// <summary>
            /// PriorityClass
            /// </summary>
            public short PriorityClass;

            /// <summary>
            /// SchedulingClass
            /// </summary>
            public short SchedulingClass;
        }

        /// <summary>
        /// IO_COUNTERS
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct IO_COUNTERS
        {
            /// <summary>
            /// ReadOperationCount
            /// </summary>
            public ulong ReadOperationCount;

            /// <summary>
            /// WriteOperationCount
            /// </summary>
            public ulong WriteOperationCount;

            /// <summary>
            /// OtherOperationCount
            /// </summary>
            public ulong OtherOperationCount;

            /// <summary>
            /// ReadTransferCount
            /// </summary>
            public ulong ReadTransferCount;

            /// <summary>
            /// WriteTransferCount
            /// </summary>
            public ulong WriteTransferCount;

            /// <summary>
            /// OtherTransferCount
            /// </summary>
            public ulong OtherTransferCount;
        }

        /// <summary>
        /// JOBOBJECT_EXTENDED_LIMIT_INFORMATION
        /// </summary>
        [StructLayout(LayoutKind.Sequential)]
        public struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION
        {
            /// <summary>
            /// BasicLimitInformation
            /// </summary>
            public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;

            /// <summary>
            /// IoInfo
            /// </summary>
            public IO_COUNTERS IoInfo;

            /// <summary>
            /// ProcessMemoryLimit
            /// </summary>
            public uint ProcessMemoryLimit;

            /// <summary>
            /// JobMemoryLimit
            /// </summary>
            public uint JobMemoryLimit;

            /// <summary>
            /// PeakProcessMemoryUsed
            /// </summary>
            public uint PeakProcessMemoryUsed;

            /// <summary>
            /// PeakJobMemoryUsed
            /// </summary>
            public uint PeakJobMemoryUsed;
        }
    }
}
